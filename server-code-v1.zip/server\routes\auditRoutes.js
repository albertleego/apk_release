const express = require('express');
const router = express.Router();
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');
const storeAwareMiddleware = require('../middleware/store-aware');

// 為所有路由添加分店上下文中間件
router.use(storeAwareMiddleware.initStoreContext);

/**
 * @route GET /api/audit-logs
 * @desc 獲取操作日誌列表（僅管理員）
 * @access Private/Admin
 */
router.get('/', authMiddleware.authenticate, authMiddleware.requireAdmin, (req, res) => {
    try {
        const storeId = req.storeContext?.store_id || 'default_store';
        const {
            employee_id,
            action_type,
            start_date,
            end_date,
            page = 1,
            limit = 20
        } = req.query;

        let query = `
            SELECT al.*,
                   e.username as employee_username,
                   e.full_name as employee_name
            FROM audit_logs al
            LEFT JOIN employees e ON al.employee_id = e.id
            WHERE 1=1
            AND (e.store_id = ? OR al.employee_id IS NULL)
        `;

        const params = [storeId];

        // 添加篩選條件
        if (employee_id) {
            query += ` AND al.employee_id = ?`;
            params.push(employee_id);
        }

        if (action_type) {
            query += ` AND al.action_type = ?`;
            params.push(action_type);
        }

        if (start_date) {
            query += ` AND al.created_at >= ?`;
            params.push(start_date);
        }

        if (end_date) {
            query += ` AND al.created_at <= ?`;
            params.push(end_date);
        }

        query += ` ORDER BY al.created_at DESC`;

        // 獲取總數
        const countQuery = query.replace(
            'SELECT al.*, e.username as employee_username, e.full_name as employee_name',
            'SELECT COUNT(*) as total'
        );

        db.get(countQuery, params, (countErr, countRow) => {
            if (countErr) {
                console.error('查詢操作日誌總數錯誤:', countErr);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: countErr.message
                });
            }

            const total = countRow.total || 0;
            const totalPages = Math.ceil(total / limit);
            const offset = (page - 1) * limit;

            // 添加分頁
            query += ` LIMIT ? OFFSET ?`;
            params.push(limit, offset);

            db.all(query, params, (err, logs) => {
                if (err) {
                    console.error('查詢操作日誌錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                // 統計操作類型分佈
                const actionTypeStats = logs.reduce((acc, log) => {
                    acc[log.action_type] = (acc[log.action_type] || 0) + 1;
                    return acc;
                }, {});

                res.json({
                    success: true,
                    data: {
                        logs,
                        pagination: {
                            total,
                            total_pages: totalPages,
                            current_page: parseInt(page),
                            page_size: parseInt(limit),
                            has_next: page < totalPages,
                            has_prev: page > 1
                        },
                        summary: {
                            total_records: total,
                            action_types: actionTypeStats,
                            time_range: {
                                start_date: logs.length > 0 ? logs[logs.length - 1].created_at : null,
                                end_date: logs.length > 0 ? logs[0].created_at : null
                            }
                        }
                    }
                });
            });
        });
    } catch (error) {
        console.error('獲取操作日誌錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取操作日誌失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/audit-logs/stats
 * @desc 獲取操作日誌統計信息（僅管理員）
 * @access Private/Admin
 */
router.get('/stats', authMiddleware.authenticate, authMiddleware.requireAdmin, (req, res) => {
    try {
        const storeId = req.storeContext?.store_id || 'default_store';
        const { start_date, end_date } = req.query;

        let dateCondition = '';
        const params = [];

        if (start_date && end_date) {
            dateCondition = 'WHERE created_at BETWEEN ? AND ?';
            params.push(start_date, end_date);
        } else if (start_date) {
            dateCondition = 'WHERE created_at >= ?';
            params.push(start_date);
        } else if (end_date) {
            dateCondition = 'WHERE created_at <= ?';
            params.push(end_date);
        }

        // 添加分店過濾參數
        params.push(storeId);

        // 獲取總數和操作類型統計
        const statsQuery = `
            SELECT
                COUNT(*) as total_logs,
                COUNT(DISTINCT employee_id) as unique_employees,
                COUNT(DISTINCT action_type) as unique_action_types,
                COUNT(DISTINCT ip_address) as unique_ips,
                MIN(created_at) as earliest_log,
                MAX(created_at) as latest_log
            FROM audit_logs al LEFT JOIN employees e ON al.employee_id = e.id
            ${dateCondition} ${dateCondition ? 'AND' : 'WHERE'} (e.store_id = ? OR al.employee_id IS NULL)
        `;

        db.get(statsQuery, params, (statsErr, stats) => {
            if (statsErr) {
                console.error('查詢操作日誌統計錯誤:', statsErr);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: statsErr.message
                });
            }

            // 獲取操作類型分佈
            const actionTypeQuery = `
                SELECT al.action_type, COUNT(*) as count
                FROM audit_logs al LEFT JOIN employees e ON al.employee_id = e.id
                ${dateCondition} ${dateCondition ? 'AND' : 'WHERE'} (e.store_id = ? OR al.employee_id IS NULL)
                GROUP BY al.action_type
                ORDER BY count DESC
                LIMIT 10
            `;

            db.all(actionTypeQuery, params, (actionErr, actionTypes) => {
                if (actionErr) {
                    console.error('查詢操作類型統計錯誤:', actionErr);
                    // 繼續返回基礎統計，忽略錯誤
                }

                // 獲取活躍員工排名
                const employeeQuery = `
                    SELECT e.username, e.full_name, COUNT(al.id) as log_count
                    FROM audit_logs al
                    LEFT JOIN employees e ON al.employee_id = e.id
                    ${dateCondition} ${dateCondition ? 'AND' : 'WHERE'} (e.store_id = ? OR al.employee_id IS NULL)
                    GROUP BY al.employee_id
                    ORDER BY log_count DESC
                    LIMIT 10
                `;

                db.all(employeeQuery, params, (employeeErr, topEmployees) => {
                    if (employeeErr) {
                        console.error('查詢員工統計錯誤:', employeeErr);
                    }

                    res.json({
                        success: true,
                        data: {
                            overview: stats,
                            top_action_types: actionTypes || [],
                            top_employees: topEmployees || [],
                            period: {
                                start_date,
                                end_date
                            },
                            timestamp: new Date().toISOString()
                        }
                    });
                });
            });
        });
    } catch (error) {
        console.error('獲取操作日誌統計錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取操作日誌統計失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/audit-logs/sensitive-operations
 * @desc 獲取敏感操作列表（刪桌、刪品）
 * @access Private
 */
router.get('/sensitive-operations', authMiddleware.authenticate, (req, res) => {
    try {
        console.log('[sensitive-operations] Request received:', req.method, req.url, 'query:', req.query, 'headers:', req.headers.authorization ? 'has auth header' : 'no auth header');
        const storeContext = req.storeContext || {};
        const storeId = storeContext.store_id;
        const canAccessAllStores = storeContext.can_access_all_stores || false;
        const { page = 1, limit = 20 } = req.query;
        const currentPage = parseInt(page);
        const pageSize = parseInt(limit);
        const offset = (currentPage - 1) * pageSize;

        // 構建基礎查詢（不含分頁）
        let baseQuery = `
            SELECT al.*,
                   e.username as employee_username,
                   e.full_name as employee_name
            FROM audit_logs al
            LEFT JOIN employees e ON al.employee_id = e.id
            WHERE al.action_type IN ('sensitive_delete_table', 'sensitive_delete_product', 'sensitive_reverse_checkout')
        `;

        const params = [];

        // 添加分店過濾條件 — 只顯示操作員（employee）屬於該分店的記錄
        if (storeId) {
            baseQuery += ` AND e.store_id = ?`;
            params.push(storeId);
        } else if (!canAccessAllStores) {
            // 沒有分店權限：不返回任何記錄
            baseQuery += ' AND 1=0';
        }
        // 總部管理員（無指定分店）：查看所有分店，無需過濾

        // 先查詢總數
        const countQuery = `SELECT COUNT(*) as total FROM (${baseQuery})`;

        db.get(countQuery, params, (countErr, countRow) => {
            if (countErr) {
                console.error('查詢敏感操作總數錯誤:', countErr);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: countErr.message
                });
            }

            const total = countRow.total || 0;
            const totalPages = Math.ceil(total / pageSize);

            // 構建分頁查詢
            const dataQuery = baseQuery + ` ORDER BY al.created_at DESC LIMIT ? OFFSET ?`;
            const dataParams = [...params, pageSize, offset];

            console.log('sensitive-operations query:', dataQuery, 'params:', dataParams);

            db.all(dataQuery, dataParams, (err, logs) => {
                if (err) {
                    console.error('查詢敏感操作錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                // 解析action_details JSON
                const parsedLogs = logs.map(log => {
                    let details = {};
                    try {
                        details = JSON.parse(log.action_details || '{}');
                    } catch (e) {
                        console.warn(`無法解析action_details JSON for log ${log.id}:`, e);
                    }

                    // 確定動作顯示名稱
                    let actionDisplay = '';
                    if (log.action_type === 'sensitive_delete_table') {
                        actionDisplay = '刪桌';
                    } else if (log.action_type === 'sensitive_delete_product') {
                        actionDisplay = '刪品';
                    } else if (log.action_type === 'sensitive_reverse_checkout') {
                        actionDisplay = '反結賬';
                    } else {
                        actionDisplay = log.action_type;
                    }

                    return {
                        id: log.id,
                        created_at: log.created_at,
                        action_type: log.action_type,
                        action_display: actionDisplay,
                        employee_username: log.employee_username,
                        employee_name: log.employee_name,
                        ip_address: log.ip_address,
                        details: details
                    };
                });

                res.json({
                    success: true,
                    data: {
                        operations: parsedLogs,
                        total: total,
                        pagination: {
                            current_page: currentPage,
                            page_size: pageSize,
                            total_pages: totalPages,
                            total_records: total,
                            has_next: currentPage < totalPages,
                            has_prev: currentPage > 1
                        }
                    }
                });
            });
        });
    } catch (error) {
        console.error('獲取敏感操作錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取敏感操作失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/audit-logs/:id
 * @desc 獲取單個操作日誌詳情（僅管理員）
 * @access Private/Admin
 */
router.get('/:id', authMiddleware.authenticate, authMiddleware.requireAdmin, (req, res) => {
    try {
        const storeId = req.storeContext?.store_id || 'default_store';
        const { id } = req.params;

        db.get(`
            SELECT al.*,
                   e.username as employee_username,
                   e.full_name as employee_name,
                   e.role as employee_role
            FROM audit_logs al
            LEFT JOIN employees e ON al.employee_id = e.id
            WHERE al.id = ? AND (e.store_id = ? OR al.employee_id IS NULL)
        `, [id, storeId], (err, log) => {
            if (err) {
                console.error('查詢操作日誌詳情錯誤:', err);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: err.message
                });
            }

            if (!log) {
                return res.status(404).json({
                    success: false,
                    error: '日誌不存在',
                    message: '指定的操作日誌不存在'
                });
            }

            // 如果存在員工ID，獲取相關的會話信息
            let relatedSessions = [];
            if (log.employee_id) {
                db.all(`
                    SELECT id, ip_address, user_agent, expires_at, created_at
                    FROM sessions
                    WHERE employee_id = ? AND created_at <= ?
                    ORDER BY created_at DESC
                    LIMIT 5
                `, [log.employee_id, log.created_at], (sessionErr, sessions) => {
                    if (sessionErr) console.error('查詢相關會話錯誤:', sessionErr);

                    relatedSessions = sessions || [];

                    res.json({
                        success: true,
                        data: {
                            log,
                            related_sessions: relatedSessions,
                            context: {
                                employee_exists: !!log.employee_id,
                                has_ip_address: !!log.ip_address,
                                log_age_days: Math.floor((new Date() - new Date(log.created_at)) / (1000 * 60 * 60 * 24))
                            }
                        }
                    });
                });
            } else {
                res.json({
                    success: true,
                    data: {
                        log,
                        related_sessions: [],
                        context: {
                            employee_exists: false,
                            has_ip_address: !!log.ip_address,
                            log_age_days: Math.floor((new Date() - new Date(log.created_at)) / (1000 * 60 * 60 * 24))
                        }
                    }
                });
            }
        });
    } catch (error) {
        console.error('獲取操作日誌詳情錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取操作日誌詳情失敗',
            message: error.message
        });
    }
});

/**
 * @route DELETE /api/audit-logs/cleanup
 * @desc 清理舊的操作日誌（僅管理員）
 * @access Private/Admin
 */
router.delete('/cleanup', authMiddleware.authenticate, authMiddleware.requireAdmin, (req, res) => {
    try {
        const { older_than_days = 90 } = req.body;
        const storeId = req.storeContext?.store_id || 'default_store';

        if (older_than_days < 7) {
            return res.status(400).json({
                success: false,
                error: '無效的參數',
                message: '清理天數必須大於等於7天'
            });
        }

        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - older_than_days);
        const cutoffISO = cutoffDate.toISOString();

        // 先獲取將要刪除的日誌數量
        db.get(
            `SELECT COUNT(*) as count FROM audit_logs al LEFT JOIN employees e ON al.employee_id = e.id WHERE al.created_at < ? AND (e.store_id = ? OR al.employee_id IS NULL)`,
            [cutoffISO, storeId],
            (countErr, countRow) => {
                if (countErr) {
                    console.error('計算清理日誌數量錯誤:', countErr);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: countErr.message
                    });
                }

                const logsToDelete = countRow.count || 0;

                if (logsToDelete === 0) {
                    return res.json({
                        success: true,
                        message: '沒有需要清理的舊日誌',
                        data: { logs_deleted: 0 }
                    });
                }

                // 創建清理日誌記錄
                const cleanupLogId = require('uuid').v4();
                const { employee } = req;
                const ipAddress = req.ip || req.connection.remoteAddress;

                db.run(
                    `INSERT INTO audit_logs (id, employee_id, action_type, action_details, ip_address)
                     VALUES (?, ?, ?, ?, ?)`,
                    [cleanupLogId, employee.id, 'audit_cleanup', `清理 ${logsToDelete} 條超過 ${older_than_days} 天的舊日誌`, ipAddress],
                    (logErr) => {
                        if (logErr) console.error('創建清理日誌記錄錯誤:', logErr);

                        // 執行清理
                        db.run(
                            `DELETE FROM audit_logs WHERE created_at < ? AND (employee_id IN (SELECT id FROM employees WHERE store_id = ?) OR employee_id IS NULL)`,
                            [cutoffISO, storeId],
                            (deleteErr) => {
                                if (deleteErr) {
                                    console.error('清理操作日誌錯誤:', deleteErr);
                                    return res.status(500).json({
                                        success: false,
                                        error: '服務器錯誤',
                                        message: deleteErr.message
                                    });
                                }

                                res.json({
                                    success: true,
                                    message: `成功清理 ${logsToDelete} 條舊日誌`,
                                    data: {
                                        logs_deleted: logsToDelete,
                                        cutoff_date: cutoffISO,
                                        older_than_days,
                                        cleanup_log_id: cleanupLogId
                                    }
                                });
                            }
                        );
                    }
                );
            }
        );
    } catch (error) {
        console.error('清理操作日誌錯誤:', error);
        res.status(500).json({
            success: false,
            error: '清理操作日誌失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/audit-logs/sensitive-operations
 * @desc 獲取敏感操作列表（刪桌、刪品）
 * @access Private
 */

/**
 * @route GET /api/audit-logs/sensitive-operations/:id
 * @desc 獲取單個敏感操作詳情
 * @access Private
 */
router.get('/sensitive-operations/:id', authMiddleware.authenticate, (req, res) => {
    try {
        const storeContext = req.storeContext || {};
        const storeId = storeContext.store_id;
        const canAccessAllStores = storeContext.can_access_all_stores || false;
        const { id } = req.params;

        // 構建基礎查詢
        let baseQuery = `
            SELECT al.*,
                   e.username as employee_username,
                   e.full_name as employee_name
            FROM audit_logs al
            LEFT JOIN employees e ON al.employee_id = e.id
            WHERE al.id = ?
            AND al.action_type IN ('sensitive_delete_table', 'sensitive_delete_product', 'sensitive_reverse_checkout')`;

        const params = [id];

        // 添加分店過濾條件 — 只顯示操作員（employee）屬於該分店的記錄
        if (storeId) {
            baseQuery += ` AND e.store_id = ?`;
            params.push(storeId);
        } else if (!canAccessAllStores) {
            // 沒有分店權限：不返回任何記錄
            baseQuery += ' AND 1=0';
        }
        // 總部管理員（無指定分店）：查看所有分店，無需過濾

        db.get(baseQuery, params, (err, log) => {
            if (err) {
                console.error('查詢敏感操作詳情錯誤:', err);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: err.message
                });
            }

            if (!log) {
                return res.status(404).json({
                    success: false,
                    error: '操作不存在',
                    message: '指定的敏感操作不存在或無權訪問'
                });
            }

            // 解析action_details JSON
            let details = {};
            try {
                details = JSON.parse(log.action_details || '{}');
            } catch (e) {
                console.warn(`無法解析action_details JSON for log ${log.id}:`, e);
            }

            // 確定動作顯示名稱
            let actionDisplay = '';
            if (log.action_type === 'sensitive_delete_table') {
                actionDisplay = '刪桌';
            } else if (log.action_type === 'sensitive_delete_product') {
                actionDisplay = '刪品';
            } else if (log.action_type === 'sensitive_reverse_checkout') {
                actionDisplay = '反結賬';
            } else {
                actionDisplay = log.action_type;
            }

            const operation = {
                id: log.id,
                created_at: log.created_at,
                action_type: log.action_type,
                action_display: actionDisplay,
                employee_username: log.employee_username,
                employee_name: log.employee_name,
                details: details,
                ip_address: log.ip_address
            };

            res.json({
                success: true,
                data: {
                    operation: operation
                }
            });
        });
    } catch (error) {
        console.error('獲取敏感操作詳情錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取敏感操作詳情失敗',
            message: error.message
        });
    }
});

module.exports = router;