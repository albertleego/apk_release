const axios = require('axios');
const { db } = require('./database/db');
require('dotenv').config({ path: './.env' });

const ALIYUN_SERVER = process.env.ALIYUN_SERVER || 'http://47.239.121.13:3000';
const ALIYUN_SYNC_USERNAME = process.env.ALIYUN_SYNC_USERNAME || '';
const ALIYUN_SYNC_PASSWORD = process.env.ALIYUN_SYNC_PASSWORD || '';
const ALIYUN_API_KEY = process.env.ALIYUN_API_KEY || '';
const STORE_ID = process.env.STORE_ID || 'store_1';

class BillUploadManager {
    constructor() {
        this.aliyunServer = ALIYUN_SERVER.replace(/\/$/, '');
        this.authToken = null;
        this.tokenExpiry = null;
        this.timeout = 30000; // 30秒超時

        // 輸出配置信息（隱藏敏感信息）
        console.log('=== BillUploadManager 配置 ===');
        console.log('阿里雲服務器:', this.aliyunServer);
        console.log('分店ID:', STORE_ID);
        console.log('API密鑰存在:', !!ALIYUN_API_KEY);
        console.log('同步用戶名存在:', !!ALIYUN_SYNC_USERNAME);
        console.log('同步密碼存在:', !!ALIYUN_SYNC_PASSWORD);
        console.log('============================');

        // 初始化數據庫字段
        this.initializeDatabaseFields();
    }

    /**
     * 初始化數據庫字段，確保cloud_uploaded字段存在
     */
    initializeDatabaseFields() {
        console.log('檢查數據庫字段...');

        // 添加cloud_uploaded字段到customers表
        db.run(
            `ALTER TABLE customers ADD COLUMN cloud_uploaded INTEGER DEFAULT 0`,
            (err) => {
                if (err && !err.message.includes('duplicate column name')) {
                    console.error('添加cloud_uploaded字段錯誤:', err);
                } else {
                    console.log('✓ customers.cloud_uploaded字段已就緒');
                }
            }
        );

        // 添加cloud_uploaded_at字段到customers表
        db.run(
            `ALTER TABLE customers ADD COLUMN cloud_uploaded_at DATETIME`,
            (err) => {
                if (err && !err.message.includes('duplicate column name')) {
                    console.error('添加cloud_uploaded_at字段錯誤:', err);
                } else {
                    console.log('✓ customers.cloud_uploaded_at字段已就緒');
                }
            }
        );

        // 添加cloud_uploaded字段到audit_logs表（用於敏感操作）
        db.run(
            `ALTER TABLE audit_logs ADD COLUMN cloud_uploaded INTEGER DEFAULT 0`,
            (err) => {
                if (err && !err.message.includes('duplicate column name')) {
                    console.error('添加audit_logs.cloud_uploaded字段錯誤:', err);
                } else {
                    console.log('✓ audit_logs.cloud_uploaded字段已就緒');
                }
            }
        );

        // 添加cloud_uploaded_at字段到audit_logs表
        db.run(
            `ALTER TABLE audit_logs ADD COLUMN cloud_uploaded_at DATETIME`,
            (err) => {
                if (err && !err.message.includes('duplicate column name')) {
                    console.error('添加audit_logs.cloud_uploaded_at字段錯誤:', err);
                } else {
                    console.log('✓ audit_logs.cloud_uploaded_at字段已就緒');
                }
            }
        );
    }

    /**
     * 認證到阿里雲服務器
     */
    async authenticate() {
        try {
            // 如果已有有效令牌，直接返回成功
            if (this.authToken && this.tokenExpiry && new Date(this.tokenExpiry) > new Date()) {
                console.log('使用現有有效令牌');
                return true;
            }

            // 嘗試使用API密鑰
            if (ALIYUN_API_KEY) {
                console.log('使用API密鑰認證');
                return true; // API密鑰會在請求頭中設置
            }

            // 嘗試使用用戶名/密碼認證
            if (ALIYUN_SYNC_USERNAME && ALIYUN_SYNC_PASSWORD) {
                console.log('使用用戶名/密碼認證...');
                const authUrl = `${this.aliyunServer}/api/auth/login`;
                const response = await axios.post(authUrl, {
                    username: ALIYUN_SYNC_USERNAME,
                    password: ALIYUN_SYNC_PASSWORD
                }, { timeout: this.timeout });

                if (response.data.success && response.data.data?.token) {
                    this.authToken = response.data.data.token;
                    this.tokenExpiry = response.data.data.expires_at;
                    console.log('遠程服務器認證成功，令牌已保存');
                    return true;
                }
            }

            console.error('所有認證方法都失敗');
            return false;
        } catch (error) {
            console.error('認證錯誤:', error.message);
            return false;
        }
    }

    /**
     * 獲取需要上傳的結賬單據
     * 只獲取尚未上傳到雲端的記錄
     */
    async getBillsToUpload() {
        console.log('獲取尚未上傳的結賬單據...');

        // 1. 獲取已結賬但未上傳的顧客
        const customers = await new Promise((resolve, reject) => {
            db.all(
                `SELECT * FROM customers
                 WHERE is_checked_out = 1
                 AND (cloud_uploaded = 0 OR cloud_uploaded IS NULL)
                 ORDER BY checkout_time
                 LIMIT 100`, // 每次最多上傳100個，避免數據量過大
                [],
                (err, rows) => {
                    if (err) reject(err);
                    else resolve(rows);
                }
            );
        });

        console.log(`找到 ${customers.length} 個未上傳的結賬顧客`);

        const bills = [];

        // 2. 為每個顧客獲取完整的結賬單據
        for (const customer of customers) {
            try {
                // 獲取訂單項目
                const orderItems = await new Promise((resolve, reject) => {
                    db.all(
                        `SELECT * FROM order_items
                         WHERE customer_id = ?
                         ORDER BY purchased_at`,
                        [customer.id],
                        (err, rows) => {
                            if (err) reject(err);
                            else resolve(rows);
                        }
                    );
                });

                // 獲取交易記錄
                const transactions = await new Promise((resolve, reject) => {
                    db.all(
                        `SELECT * FROM transactions
                         WHERE customer_id = ?
                         AND transaction_type IN ('checkout', 'purchase')
                         ORDER BY created_at`,
                        [customer.id],
                        (err, rows) => {
                            if (err) reject(err);
                            else resolve(rows);
                        }
                    );
                });

                // 使用顧客記錄中的store_id，如果沒有則使用環境變量
                const billStoreId = customer.store_id || STORE_ID;
                bills.push({
                    customer,
                    orderItems,
                    transactions,
                    store_id: billStoreId,
                    upload_timestamp: new Date().toISOString()
                });

                console.log(`顧客 ${customer.id} (桌位: ${customer.table_number}): ${orderItems.length} 個訂單項目, ${transactions.length} 筆交易`);

            } catch (error) {
                console.error(`處理顧客 ${customer.id} 錯誤:`, error.message);
            }
        }

        return bills;
    }

    /**
     * 獲取需要上傳的敏感操作
     * 只獲取尚未上傳到雲端的敏感刪除記錄
     */
    async getSensitiveOperationsToUpload() {
        console.log('獲取尚未上傳的敏感操作...');

        // 獲取已記錄但未上傳的敏感操作
        const operations = await new Promise((resolve, reject) => {
            db.all(
                `SELECT * FROM audit_logs
                 WHERE action_type IN ('sensitive_delete_table', 'sensitive_delete_product', 'sensitive_reverse_checkout')
                 AND (cloud_uploaded = 0 OR cloud_uploaded IS NULL)
                 ORDER BY created_at
                 LIMIT 100`, // 每次最多上傳100個，避免數據量過大
                [],
                (err, rows) => {
                    if (err) reject(err);
                    else resolve(rows);
                }
            );
        });

        console.log(`找到 ${operations.length} 個未上傳的敏感操作`);

        // 解析action_details JSON
        const parsedOperations = operations.map(op => {
            let details = {};
            try {
                details = JSON.parse(op.action_details || '{}');
            } catch (error) {
                console.warn(`無法解析action_details JSON for operation ${op.id}:`, error);
            }

            return {
                ...op,
                parsed_details: details,
                store_id: op.store_id || STORE_ID,
                upload_timestamp: new Date().toISOString()
            };
        });

        return parsedOperations;
    }

    /**
     * 標記結賬單據為已上傳
     */
    async markBillsAsUploaded(bills) {
        if (bills.length === 0) {
            return;
        }

        console.log(`標記 ${bills.length} 個結賬單據為已上傳...`);

        const now = new Date().toISOString();
        let markedCount = 0;

        for (const bill of bills) {
            try {
                await new Promise((resolve, reject) => {
                    db.run(
                        `UPDATE customers SET
                         cloud_uploaded = 1,
                         cloud_uploaded_at = ?
                         WHERE id = ?`,
                        [now, bill.customer.id],
                        function(err) {
                            if (err) reject(err);
                            else {
                                markedCount++;
                                resolve();
                            }
                        }
                    );
                });
            } catch (error) {
                console.error(`標記顧客 ${bill.customer.id} 錯誤:`, error.message);
            }
        }

        console.log(`✓ 已標記 ${markedCount} 個結賬單據為已上傳`);
    }

    /**
     * 標記敏感操作為已上傳
     */
    async markSensitiveOperationsAsUploaded(operations) {
        if (operations.length === 0) {
            return;
        }

        console.log(`標記 ${operations.length} 個敏感操作為已上傳...`);

        const now = new Date().toISOString();
        let markedCount = 0;

        for (const operation of operations) {
            try {
                await new Promise((resolve, reject) => {
                    db.run(
                        `UPDATE audit_logs SET
                         cloud_uploaded = 1,
                         cloud_uploaded_at = ?
                         WHERE id = ?`,
                        [now, operation.id],
                        function(err) {
                            if (err) reject(err);
                            else {
                                markedCount++;
                                resolve();
                            }
                        }
                    );
                });
            } catch (error) {
                console.error(`標記敏感操作 ${operation.id} 錯誤:`, error.message);
            }
        }

        console.log(`✓ 已標記 ${markedCount} 個敏感操作為已上傳`);
    }

    /**
     * 上傳結賬單據到阿里雲
     */
    async uploadBills(bills) {
        if (bills.length === 0) {
            console.log('沒有需要上傳的結賬單據');
            return { success: true, uploaded: 0 };
        }

        console.log(`開始上傳 ${bills.length} 個結賬單據到阿里雲...`);

        // 準備請求配置
        const config = {
            timeout: this.timeout,
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        };

        // 添加認證
        if (this.authToken && this.tokenExpiry && new Date(this.tokenExpiry) > new Date()) {
            config.headers['Authorization'] = `Bearer ${this.authToken}`;
            console.log('使用Bearer令牌認證');
        } else if (ALIYUN_API_KEY) {
            config.headers['X-API-Key'] = ALIYUN_API_KEY;
            console.log('使用API密鑰認證');
        } else {
            console.log('警告：無認證信息，嘗試無認證上傳');
        }

        try {
            const uploadUrl = `${this.aliyunServer}/api/sync/upload-bills`;
            console.log(`上傳到: ${uploadUrl}`);

            // 確定主要store_id（使用第一個bill的store_id）
            const primaryStoreId = bills.length > 0 ? bills[0].store_id : STORE_ID;

            const response = await axios.post(uploadUrl, {
                bills,
                store_id: primaryStoreId,
                timestamp: new Date().toISOString(),
                count: bills.length
            }, config);

            if (response.data.success) {
                console.log(`✓ 成功上傳 ${bills.length} 個結賬單據`);

                // 標記記錄為已上傳
                await this.markBillsAsUploaded(bills);

                return {
                    success: true,
                    uploaded: bills.length,
                    response: response.data
                };
            } else {
                console.error(`上傳失敗: ${response.data.message || '未知錯誤'}`);
                return {
                    success: false,
                    error: response.data.message || '上傳失敗',
                    response: response.data
                };
            }

        } catch (error) {
            console.error('上傳請求錯誤:', error.message);
            if (error.response) {
                console.error('錯誤響應:', error.response.status, error.response.data);
            }
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * 上傳敏感操作到阿里雲
     */
    async uploadSensitiveOperations(operations) {
        if (operations.length === 0) {
            console.log('沒有需要上傳的敏感操作');
            return { success: true, uploaded: 0 };
        }

        console.log(`開始上傳 ${operations.length} 個敏感操作到阿里雲...`);

        // 準備請求配置
        const config = {
            timeout: this.timeout,
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        };

        // 添加認證
        if (this.authToken && this.tokenExpiry && new Date(this.tokenExpiry) > new Date()) {
            config.headers['Authorization'] = `Bearer ${this.authToken}`;
            console.log('使用Bearer令牌認證');
        } else if (ALIYUN_API_KEY) {
            config.headers['X-API-Key'] = ALIYUN_API_KEY;
            console.log('使用API密鑰認證');
        } else {
            console.log('警告：無認證信息，嘗試無認證上傳');
        }

        try {
            const uploadUrl = `${this.aliyunServer}/api/sync/upload-sensitive-operations`;
            console.log(`上傳敏感操作到: ${uploadUrl}`);

            // 確定主要store_id（使用第一個operation的store_id）
            const primaryStoreId = operations.length > 0 ? operations[0].store_id : STORE_ID;

            const response = await axios.post(uploadUrl, {
                sensitive_operations: operations,
                store_id: primaryStoreId,
                timestamp: new Date().toISOString(),
                count: operations.length
            }, config);

            if (response.data.success) {
                console.log(`✓ 成功上傳 ${operations.length} 個敏感操作`);

                // 標記記錄為已上傳
                await this.markSensitiveOperationsAsUploaded(operations);

                return {
                    success: true,
                    uploaded: operations.length,
                    response: response.data
                };
            } else {
                console.error(`上傳敏感操作失敗: ${response.data.message || '未知錯誤'}`);
                return {
                    success: false,
                    error: response.data.message || '上傳失敗',
                    response: response.data
                };
            }

        } catch (error) {
            console.error('上傳敏感操作請求錯誤:', error.message);
            if (error.response) {
                console.error('錯誤響應:', error.response.status, error.response.data);

                // 如果阿里雲服務器沒有這個端點（404），跳過敏感操作上傳
                if (error.response.status === 404) {
                    console.warn('阿里雲服務器缺少 /api/sync/upload-sensitive-operations 端點，跳過敏感操作上傳');
                    console.warn('請在阿里雲服務器上添加此端點以接收敏感操作數據');
                    return {
                        success: true,
                        uploaded: 0,
                        skipped: true,
                        warning: '阿里雲缺少敏感操作上傳端點，數據未上傳'
                    };
                }
            }
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * 執行完整的上傳流程
     */
    async executeUpload() {
        console.log('=== 開始數據上傳流程（結賬單據 + 敏感操作）===');
        const startTime = Date.now();

        try {
            // 1. 認證
            const authSuccess = await this.authenticate();
            if (!authSuccess) {
                console.error('認證失敗，無法上傳');
                return { success: false, error: '認證失敗' };
            }

            // 2. 獲取需要上傳的數據
            const bills = await this.getBillsToUpload();
            const sensitiveOperations = await this.getSensitiveOperationsToUpload();

            console.log(`需要上傳: ${bills.length} 個結賬單據, ${sensitiveOperations.length} 個敏感操作`);

            let billsResult = { success: true, uploaded: 0 };
            let operationsResult = { success: true, uploaded: 0 };

            // 3. 上傳結賬單據（如果有）
            if (bills.length > 0) {
                billsResult = await this.uploadBills(bills);
            } else {
                console.log('沒有需要上傳的結賬單據');
            }

            // 4. 上傳敏感操作（如果有）
            if (sensitiveOperations.length > 0) {
                operationsResult = await this.uploadSensitiveOperations(sensitiveOperations);
            } else {
                console.log('沒有需要上傳的敏感操作');
            }

            const duration = Date.now() - startTime;
            console.log(`=== 數據上傳流程完成 (${duration}ms) ===`);
            console.log(`結果: 結賬單據 ${billsResult.uploaded || 0}/${bills.length}, 敏感操作 ${operationsResult.uploaded || 0}/${sensitiveOperations.length}`);

            // 如果任一上傳失敗（且不是跳過的敏感操作），返回失敗
            if (!billsResult.success || (!operationsResult.success && !operationsResult.skipped)) {
                return {
                    success: false,
                    billsCount: bills.length,
                    billsUploaded: billsResult.uploaded || 0,
                    operationsCount: sensitiveOperations.length,
                    operationsUploaded: operationsResult.uploaded || 0,
                    error: billsResult.error || operationsResult.error,
                    duration
                };
            }

            const result = {
                success: true,
                billsCount: bills.length,
                billsUploaded: billsResult.uploaded || 0,
                operationsCount: sensitiveOperations.length,
                operationsUploaded: operationsResult.uploaded || 0,
                duration
            };

            // 如果敏感操作被跳過，添加標記
            if (operationsResult.skipped) {
                result.operationsSkipped = true;
                result.warning = operationsResult.warning || '敏感操作上傳被跳過（阿里雲缺少端點）';
            }

            return result;

        } catch (error) {
            console.error('上傳流程錯誤:', error);
            const duration = Date.now() - startTime;
            return {
                success: false,
                error: error.message,
                duration
            };
        }
    }
}

/**
 * 主要執行函數
 */
async function main() {
    const uploadManager = new BillUploadManager();
    const result = await uploadManager.executeUpload();

    if (result.success) {
        console.log(`上傳成功: ${result.uploaded || 0} 個結賬單據`);
        process.exit(0);
    } else {
        console.error(`上傳失敗: ${result.error}`);
        process.exit(1);
    }
}

// 如果直接運行此腳本
if (require.main === module) {
    // 等待數據庫初始化完成
    setTimeout(async () => {
        await main();
    }, 1000);
}

module.exports = BillUploadManager;