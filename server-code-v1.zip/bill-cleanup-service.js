let BillCleanupManager;
try {
    BillCleanupManager = require('./cleanup-bills');
    console.log('✓ cleanup-bills 模塊加載成功 (bill-cleanup-service)');
} catch (e) {
    console.warn('⚠️ cleanup-bills 模塊未找到，將使用空實現 (bill-cleanup-service):', e.message);
    BillCleanupManager = class {
        constructor() {
            this.cleanupThresholdHours = 48;
        }
        async getCleanupStats() {
            return {
                cleanup_eligible: 0,
                total_uploaded: 0,
                earliest_uploaded: null,
                latest_uploaded: null,
                cleanup_threshold_hours: 48,
                threshold_time: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString()
            };
        }
        async executeCleanup() {
            console.warn('⚠️ 清理功能不可用（cleanup-bills 模塊缺失）');
            return {
                success: true,
                cleaned: 0,
                duration: 0,
                warning: '清理功能不可用（cleanup-bills 模塊缺失）'
            };
        }
    };
}

class BillCleanupService {
    constructor() {
        this.cleanupManager = new BillCleanupManager();
        this.cleanupInterval = 6 * 60 * 60 * 1000; // 6小時（毫秒）
        this.isRunning = false;
        this.cleanupTimer = null;
        this.stats = {
            totalRuns: 0,
            successfulRuns: 0,
            failedRuns: 0,
            totalBillsCleaned: 0,
            totalOrderItemsCleaned: 0,
            totalTransactionsCleaned: 0,
            lastRun: null,
            lastError: null
        };
    }

    /**
     * 啟動清理服務
     */
    start() {
        if (this.isRunning) {
            console.log('清理服務已在運行中');
            return;
        }

        console.log('啟動結賬單據清理服務...');
        console.log(`清理間隔: ${this.cleanupInterval / 1000 / 60 / 60} 小時`);
        console.log(`清理閾值: ${this.cleanupManager.cleanupThresholdHours} 小時`);
        console.log(`分店ID: ${process.env.STORE_ID || 'store_1'}`);

        this.isRunning = true;

        // 立即執行一次清理檢查
        this.runCleanup();

        // 設置定時清理
        this.cleanupTimer = setInterval(() => {
            this.runCleanup();
        }, this.cleanupInterval);

        console.log('清理服務已啟動');
    }

    /**
     * 停止清理服務
     */
    stop() {
        if (!this.isRunning) {
            return;
        }

        console.log('停止結賬單據清理服務...');

        if (this.cleanupTimer) {
            clearInterval(this.cleanupTimer);
            this.cleanupTimer = null;
        }

        this.isRunning = false;
        console.log('清理服務已停止');
    }

    /**
     * 執行清理任務
     */
    async runCleanup() {
        console.log('\n--- 執行清理任務 ---');
        console.log(`時間: ${new Date().toISOString()}`);

        this.stats.totalRuns++;
        this.stats.lastRun = new Date();

        try {
            // 先獲取統計信息
            const stats = await this.cleanupManager.getCleanupStats();
            console.log('清理前統計:', stats);

            if (stats.cleanup_eligible > 0) {
                console.log(`發現 ${stats.cleanup_eligible} 個需要清理的記錄`);

                const result = await this.cleanupManager.executeCleanup();

                if (result.success) {
                    this.stats.successfulRuns++;
                    this.stats.totalBillsCleaned += (result.cleaned || 0);
                    this.stats.totalOrderItemsCleaned += (result.details?.orderItems || 0);
                    this.stats.totalTransactionsCleaned += (result.details?.transactions || 0);
                    console.log(`✓ 清理任務成功: 清理了 ${result.cleaned || 0} 個結賬單據`);
                } else {
                    this.stats.failedRuns++;
                    this.stats.lastError = result.error;
                    console.error(`✗ 清理任務失敗: ${result.error}`);
                }
            } else {
                console.log('沒有需要清理的記錄');
                this.stats.successfulRuns++; // 沒有記錄也算成功
            }

            // 打印統計信息
            this.printStats();

        } catch (error) {
            this.stats.failedRuns++;
            this.stats.lastError = error.message;
            console.error(`清理任務異常:`, error);
            this.printStats();
        }
    }

    /**
     * 打印統計信息
     */
    printStats() {
        console.log('統計信息:');
        console.log(`  總運行次數: ${this.stats.totalRuns}`);
        console.log(`  成功次數: ${this.stats.successfulRuns}`);
        console.log(`  失敗次數: ${this.stats.failedRuns}`);
        console.log(`  總清理結賬單據數: ${this.stats.totalBillsCleaned}`);
        console.log(`  總清理訂單項目數: ${this.stats.totalOrderItemsCleaned}`);
        console.log(`  總清理交易記錄數: ${this.stats.totalTransactionsCleaned}`);
        console.log(`  最後運行時間: ${this.stats.lastRun ? this.stats.lastRun.toISOString() : '從未運行'}`);
        if (this.stats.lastError) {
            console.log(`  最後錯誤: ${this.stats.lastError}`);
        }
        console.log(`  下次運行時間: ${this.isRunning ? new Date(Date.now() + this.cleanupInterval).toISOString() : '服務未運行'}`);
    }

    /**
     * 獲取服務狀態
     */
    getStatus() {
        return {
            isRunning: this.isRunning,
            nextCleanup: this.isRunning ? new Date(Date.now() + this.cleanupInterval) : null,
            stats: { ...this.stats },
            cleanupThresholdHours: this.cleanupManager.cleanupThresholdHours
        };
    }

    /**
     * 手動執行一次清理
     */
    async triggerCleanup() {
        console.log('手動觸發清理...');
        return await this.runCleanup();
    }
}

/**
 * 主程序
 */
async function main() {
    console.log('=== 結賬單據自動清理服務 ===');

    // 創建服務實例
    const service = new BillCleanupService();

    // 啟動服務
    service.start();

    // 處理進程信號
    process.on('SIGINT', () => {
        console.log('\n收到SIGINT信號，停止服務...');
        service.stop();
        process.exit(0);
    });

    process.on('SIGTERM', () => {
        console.log('\n收到SIGTERM信號，停止服務...');
        service.stop();
        process.exit(0);
    });

    // 保持進程運行
    console.log('服務運行中，按Ctrl+C停止...');
}

// 如果直接運行此腳本
if (require.main === module) {
    // 等待數據庫初始化完成
    setTimeout(async () => {
        await main();
    }, 2000);
}

module.exports = BillCleanupService;