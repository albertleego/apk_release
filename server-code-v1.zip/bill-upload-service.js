const BillUploadManager = require('./upload-bills');

class BillUploadService {
    constructor() {
        this.uploadManager = new BillUploadManager();
        this.uploadInterval = 15 * 60 * 1000; // 15分鐘（毫秒）
        this.isRunning = false;
        this.uploadTimer = null;
        this.stats = {
            totalRuns: 0,
            successfulRuns: 0,
            failedRuns: 0,
            totalBillsUploaded: 0,
            lastRun: null,
            lastError: null
        };
    }

    /**
     * 啟動上傳服務
     */
    start() {
        if (this.isRunning) {
            console.log('上傳服務已在運行中');
            return;
        }

        console.log('啟動結賬單據上傳服務...');
        console.log(`上傳間隔: ${this.uploadInterval / 1000 / 60} 分鐘`);
        console.log(`分店ID: ${process.env.STORE_ID || 'store_1'}`);
        console.log(`阿里雲服務器: ${process.env.ALIYUN_SERVER || 'http://47.239.121.13:3000'}`);

        this.isRunning = true;

        // 立即執行一次上傳
        this.runUpload();

        // 設置定時上傳
        this.uploadTimer = setInterval(() => {
            this.runUpload();
        }, this.uploadInterval);

        console.log('上傳服務已啟動');
    }

    /**
     * 停止上傳服務
     */
    stop() {
        if (!this.isRunning) {
            return;
        }

        console.log('停止結賬單據上傳服務...');

        if (this.uploadTimer) {
            clearInterval(this.uploadTimer);
            this.uploadTimer = null;
        }

        this.isRunning = false;
        console.log('上傳服務已停止');
    }

    /**
     * 執行上傳任務
     */
    async runUpload() {
        console.log('\n--- 執行上傳任務 ---');
        console.log(`時間: ${new Date().toISOString()}`);

        this.stats.totalRuns++;
        this.stats.lastRun = new Date();

        try {
            const result = await this.uploadManager.executeUpload();

            if (result.success) {
                this.stats.successfulRuns++;
                this.stats.totalBillsUploaded += (result.uploaded || 0);
                console.log(`✓ 上傳任務成功: ${result.uploaded || 0} 個單據`);
            } else {
                this.stats.failedRuns++;
                this.stats.lastError = result.error;
                console.error(`✗ 上傳任務失敗: ${result.error}`);
            }

            // 打印統計信息
            this.printStats();

        } catch (error) {
            this.stats.failedRuns++;
            this.stats.lastError = error.message;
            console.error(`上傳任務異常:`, error);
            this.printStats();
        }
    }

    /**
     * 打印統計信息
     */
    printStats() {
        console.log('統計信息:');
        console.log(`  總運行次數: ${this.stats.totalRuns}`);
        console.log(`  成功次數: ${this.stats.successfulRuns}`);
        console.log(`  失敗次數: ${this.stats.failedRuns}`);
        console.log(`  總上傳單據數: ${this.stats.totalBillsUploaded}`);
        console.log(`  最後運行時間: ${this.stats.lastRun ? this.stats.lastRun.toISOString() : '從未運行'}`);
        if (this.stats.lastError) {
            console.log(`  最後錯誤: ${this.stats.lastError}`);
        }
        console.log(`  下次運行時間: ${this.isRunning ? new Date(Date.now() + this.uploadInterval).toISOString() : '服務未運行'}`);
    }

    /**
     * 獲取服務狀態
     */
    getStatus() {
        return {
            isRunning: this.isRunning,
            nextUpload: this.isRunning ? new Date(Date.now() + this.uploadInterval) : null,
            stats: { ...this.stats }
        };
    }
}

/**
 * 主程序
 */
async function main() {
    console.log('=== 結賬單據自動上傳服務 ===');

    // 創建服務實例
    const service = new BillUploadService();

    // 啟動服務
    service.start();

    // 處理進程信號
    process.on('SIGINT', () => {
        console.log('\n收到SIGINT信號，停止服務...');
        service.stop();
        process.exit(0);
    });

    process.on('SIGTERM', () => {
        console.log('\n收到SIGTERM信號，停止服務...');
        service.stop();
        process.exit(0);
    });

    // 保持進程運行
    console.log('服務運行中，按Ctrl+C停止...');
}

// 如果直接運行此腳本
if (require.main === module) {
    // 等待數據庫初始化完成
    setTimeout(async () => {
        await main();
    }, 2000);
}

module.exports = BillUploadService;