#!/data/data/com.termux/files/usr/bin/bash
# 自動咖啡館系統 - 服務器啟動腳本
# 用法: bash start_server.sh

cd /data/data/com.termux/files/home

# 取得 CPU WakeLock，防止 Android 殺進程
echo "取得 WakeLock..."
termux-wake-lock cafe

# 啟動服務器
echo "啟動服務器中..."
node server/index.js
