const express = require('express');
const router = express.Router();
const db = require('../../database/db');
const QRCode = require('qrcode');
const authMiddleware = require('../middleware/auth');
const storeAwareMiddleware = require('../middleware/store-aware');
const ThermalPrinter = require('node-thermal-printer').printer;
const PrinterTypes = require('node-thermal-printer').types;
const { v4: uuidv4 } = require('uuid');
const RawPrinter = require('../printer-raw');
const receiptRouter = require('./receiptRoutes');
const printerStatus = receiptRouter.printerStatus;

// 重新計算客人人數（當手動添加/刪除首小時或全日通商品時調用）
async function recalculateCustomerPeopleCount(customerId, storeId) {
    try {
        console.log(`[DEBUG] 重新計算客人人數: customerId=${customerId}, storeId=${storeId}`);

        // 查詢該客人的所有訂單項目，並獲取商品名稱
        const orderItems = await new Promise((resolve, reject) => {
            const query = `
                SELECT oi.quantity, p.name
                FROM order_items oi
                LEFT JOIN products p ON oi.product_id = p.id
                WHERE oi.customer_id = ?
                AND p.store_id = ?
            `;
            db.db.all(query, [customerId, storeId], (err, rows) => {
                if (err) reject(err);
                else resolve(rows);
            });
        });

        // 計算首小時和全日通商品的總數量
        let totalPeopleCount = 0;
        orderItems.forEach(item => {
            if (item.name && (item.name.includes('首小時') || item.name.includes('全日通'))) {
                totalPeopleCount += item.quantity || 0;
            }
        });

        console.log(`[DEBUG] 計算出的客人人數: ${totalPeopleCount} (來自 ${orderItems.length} 個訂單項目)`);

        // 更新 customers 表的 people_count
        if (totalPeopleCount >= 0) {
            await new Promise((resolve, reject) => {
                const updateQuery = `UPDATE customers SET people_count = ? WHERE id = ? AND store_id = ?`;
                db.db.run(updateQuery, [totalPeopleCount, customerId, storeId], function(err) {
                    if (err) reject(err);
                    else resolve(this.changes);
                });
            });

            console.log(`[DEBUG] 已更新客人 ${customerId} 的人數為 ${totalPeopleCount}`);
            return totalPeopleCount;
        }

        return -1; // 表示未更新
    } catch (error) {
        console.error(`[ERROR] 重新計算客人人數失敗:`, error);
        throw error;
    }
}

// 軟驗證：有 token 就延長 session，沒有/無效就放行
router.use(authMiddleware.softAuthenticate);
// 應用分店上下文中間件到所有路由（身份驗證可選，向後兼容）
router.use(storeAwareMiddleware.initStoreContext);

// 獲取所有客人（未結賬）
router.get('/customers', (req, res) => {
  try {
    console.log('[DEBUG] /api/cashier/customers 請求:', {
      query: req.query,
      storeContext: req.storeContext,
      employee: req.employee ? { id: req.employee.id, role: req.employee.role, store_id: req.employee.store_id } : null
    });

    // 構建分店過濾條件
    const { whereClause, params } = storeAwareMiddleware.buildStoreWhereClause(req, {
      tableAlias: 'c.'
    });

    console.log('[DEBUG] /api/cashier/customers 分店過濾:', {
      whereClause,
      params,
      storeContext: req.storeContext
    });

    // 構建完整的WHERE子句
    let fullWhereClause = 'c.is_checked_out = 0';
    let queryParams = [];

    if (whereClause) {
      fullWhereClause += ` AND ${whereClause}`;
      queryParams = [...params];
    }

    console.log('[DEBUG] /api/cashier/customers 完整WHERE子句:', fullWhereClause, '參數:', queryParams);

    db.db.all(
      `SELECT
        c.*,
        t.capacity,
        (SELECT COUNT(*) FROM order_items oi WHERE oi.customer_id = c.id) as item_count,
        (SELECT SUM(oi.quantity * oi.price_at_time) FROM order_items oi WHERE oi.customer_id = c.id) as total_spent,
        (
          SELECT GROUP_CONCAT(l.locker_number, ', ')
          FROM lockers l
          WHERE l.customer_id = c.id
            AND l.is_occupied = 1
            AND l.store_id = c.store_id
        ) as lockers_used
       FROM customers c
       LEFT JOIN tables t ON c.table_number = t.table_number AND c.store_id = t.store_id
       WHERE ${fullWhereClause}
       ORDER BY
         CASE WHEN SUBSTR(c.table_number, 1, 1) BETWEEN '0' AND '9' THEN '' ELSE SUBSTR(c.table_number, 1, 1) END,
         CAST(
           CASE WHEN SUBSTR(c.table_number, 1, 1) BETWEEN '0' AND '9'
                THEN c.table_number
                ELSE SUBSTR(c.table_number, 2)
           END AS INTEGER
         )`,
      queryParams,
      (err, rows) => {
        if (err) {
          console.error('獲取客人錯誤:', err);
          return res.status(500).json({ error: '獲取客人失敗', message: err.message });
        }
        // 調試日誌：顯示每個客人的詳細信息
        console.log('[DEBUG] /api/cashier/customers 返回數據:');
        rows.forEach((row, index) => {
          console.log(`[DEBUG] 客人 ${index + 1}: id=${row.id}, table_number=${row.table_number}, people_count=${row.people_count}, entry_time=${row.entry_time}, store_id=${row.store_id}, lockers_used=${row.lockers_used}`);
        });
        res.json({
          success: true,
          customers: rows
        });
      }
    );
  } catch (error) {
    console.error('獲取客人錯誤:', error);
    res.status(500).json({
      error: '獲取客人失敗',
      message: error.message
    });
  }
});

// 獲取特定客人詳細信息
router.get('/customer/:id', (req, res) => {
  try {
    const { id } = req.params;
    console.log(`[DEBUG] 客戶詳情 API 請求: customer_id=${id}`);

    // 構建分店過濾條件
    const { whereClause, params } = storeAwareMiddleware.buildStoreWhereClause(req, {
      tableAlias: 'c.'
    });

    // 獲取客人基本信息（包含分店驗證）
    let customerQuery = `SELECT c.*, t.capacity FROM customers c
       LEFT JOIN tables t ON c.table_number = t.table_number AND c.store_id = t.store_id
       WHERE c.id = ?`;
    let customerParams = [id];

    if (whereClause) {
      customerQuery += ` AND ${whereClause}`;
      customerParams = [...customerParams, ...params];
    }

    db.db.get(customerQuery, customerParams, (err, customer) => {
      if (err) {
        console.error('獲取客人詳細信息錯誤:', err);
        return res.status(500).json({ error: '獲取客人失敗', message: err.message });
      }

      if (!customer) {
        return res.status(404).json({ error: '客人不存在或無權訪問' });
      }

      // 獲取客人的訂單項目
      db.db.all(
        `SELECT oi.*, p.name as product_name, p.description as product_description, p.category
         FROM order_items oi
         LEFT JOIN products p ON oi.product_id = p.id
         WHERE oi.customer_id = ?
         ORDER BY
           CASE WHEN p.name LIKE '%全日通%' THEN 0 ELSE 1 END,
           oi.purchased_at ASC`,
        [id],
        (err2, orderItems) => {
          if (err2) {
            console.error('獲取訂單項目錯誤:', err2);
            return res.status(500).json({ error: '獲取訂單項目失敗', message: err2.message });
          }

          // 獲取分店過濾條件用於lockers查詢
          const { whereClause: lockerWhereClause, params: lockerParams } = storeAwareMiddleware.buildStoreWhereClause(req, {
            tableAlias: 'l.'
          });

          // 構建lockers查詢
          let lockerQuery = `SELECT locker_number FROM lockers l WHERE l.customer_id = ? AND l.is_occupied = 1`;
          let lockerQueryParams = [id];

          if (lockerWhereClause) {
            lockerQuery += ` AND ${lockerWhereClause}`;
            lockerQueryParams = [...lockerQueryParams, ...lockerParams];
          }

          console.log(`[DEBUG] 查詢客戶 ${id} 的儲物柜: ${lockerQuery}`);
          db.db.all(lockerQuery, lockerQueryParams, (err3, lockers) => {
            if (err3) {
              console.error('獲取儲物柜錯誤:', err3);
              return res.status(500).json({ error: '獲取儲物柜失敗', message: err3.message });
            }

            console.log(`[DEBUG] 客戶 ${id} 的儲物柜查詢結果:`, lockers);
            console.log(`[DEBUG] 儲物柜編號數組:`, lockers.map(l => l.locker_number));

            // 計算總金額（含立減/折扣優惠），允許折扣商品（原價為負）顯示負數
            const total_amount = orderItems.reduce((sum, item) => {
              const basePrice = item.price_at_time || 0;
              const flatDisc = item.flat_discount || 0;
              const pctDisc = item.percent_discount || 0;
              let effPrice = basePrice - flatDisc;
              if (pctDisc > 0) {
                effPrice = effPrice * (100 - pctDisc) / 100;
              }
              const effective = basePrice >= 0 ? Math.max(0, effPrice) : effPrice;
              return sum + (effective * item.quantity);
            }, 0);

            console.log(`[DEBUG] 客戶 ${id} 的總金額計算:`, {
              orderItemsCount: orderItems.length,
              total_amount,
              orderItemsSample: orderItems.slice(0, 3).map(item => ({
                id: item.id,
                product_name: item.product_name,
                quantity: item.quantity,
                price_at_time: item.price_at_time
              }))
            });

            res.json({
              success: true,
              customer: {
                ...customer,
                order_items: orderItems,
                lockers: lockers.map(l => l.locker_number),
                total_items: orderItems.reduce((sum, item) => sum + item.quantity, 0),
                total_amount: total_amount
              }
            });
          });
        }
      );
    });
  } catch (error) {
    console.error('獲取客人詳細信息錯誤:', error);
    res.status(500).json({
      error: '獲取客人詳細信息失敗',
      message: error.message
    });
  }
});

// 獲取所有商品
router.get('/products', (req, res) => {
  try {
    // 構建分店過濾條件
    const { whereClause, params } = storeAwareMiddleware.buildStoreWhereClause(req, {
      tableAlias: ''
    });

    // 構建完整的WHERE子句
    let fullWhereClause = 'is_available = 1 AND (stock > 0 OR track_inventory = 0)';
    let queryParams = [];

    if (whereClause) {
      fullWhereClause += ` AND ${whereClause}`;
      queryParams = [...params];
    }

    db.db.all(
      `SELECT * FROM products WHERE ${fullWhereClause} ORDER BY name`,
      queryParams,
      (err, rows) => {
        if (err) {
          console.error('獲取商品錯誤:', err);
          return res.status(500).json({ error: '獲取商品失敗', message: err.message });
        }
        res.json({
          success: true,
          products: rows
        });
      }
    );
  } catch (error) {
    console.error('獲取商品錯誤:', error);
    res.status(500).json({
      error: '獲取商品失敗',
      message: error.message
    });
  }
});

// 添加商品到客人訂單
router.post('/add-order-item', async (req, res) => {
  try {
    const { customer_id, product_id, quantity } = req.body;

    if (!customer_id || !product_id || !quantity) {
      return res.status(400).json({ error: '請提供客人ID、商品ID和數量' });
    }

    // 構建分店過濾條件
    const { whereClause: customerWhereClause, params: customerParams } = storeAwareMiddleware.buildStoreWhereClause(req, {
      tableAlias: ''
    });
    const { whereClause: productWhereClause, params: productParams } = storeAwareMiddleware.buildStoreWhereClause(req, {
      tableAlias: ''
    });

    // 檢查客人是否存在且未結賬（包含分店過濾）
    let customerQuery = `SELECT * FROM customers WHERE id = ? AND is_checked_out = 0`;
    let customerQueryParams = [customer_id];
    if (customerWhereClause) {
      customerQuery += ` AND ${customerWhereClause}`;
      customerQueryParams = [...customerQueryParams, ...customerParams];
    }

    const customer = await new Promise((resolve, reject) => {
      db.db.get(customerQuery, customerQueryParams, (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!customer) {
      return res.status(404).json({ error: '客人不存在、已結賬或無權訪問' });
    }

    // 檢查商品庫存（包含分店過濾）
    let productQuery = `SELECT * FROM products WHERE id = ? AND is_available = 1`;
    let productQueryParams = [product_id];
    if (productWhereClause) {
      productQuery += ` AND ${productWhereClause}`;
      productQueryParams = [...productQueryParams, ...productParams];
    }

    const product = await new Promise((resolve, reject) => {
      db.db.get(productQuery, productQueryParams, (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!product) {
      return res.status(404).json({ error: '商品不存在、已下架或無權訪問' });
    }

    // 驗證客戶和商品屬於同一分店
    if (customer.store_id !== product.store_id) {
      return res.status(400).json({ error: '客戶和商品不屬於同一分店' });
    }

    // 檢查商品庫存（僅當 track_inventory = 1 時）
    if (product.track_inventory === 1 && product.stock < quantity) {
      return res.status(400).json({ error: '商品庫存不足' });
    }

    // 添加訂單項目
    const orderId = await db.addOrderItem(customer_id, product_id, quantity, product.price);

    // 觸發Socket事件通知商品售賣機開啟對應儲物柜
    const io = req.app.get('io');
    io.emit('device-control', {
      device: 'vending',
      action: 'dispense',
      product_id: product_id,
      locker_number: product.locker_number,
      customer_id: customer_id,
      store_id: customer.store_id
    });

    // 通知客戶端更新
    io.emit('order-updated', {
      customer_id: customer_id,
      order_id: orderId,
      product_name: product.name,
      quantity: quantity,
      price: product.price,
      store_id: customer.store_id
    });

    // 如果添加的商品是「首小時」或「全日通」，重新計算客人人數
    if (product.name && (product.name.includes('首小時') || product.name.includes('全日通'))) {
        try {
            console.log(`[DEBUG] 檢測到首小時/全日通商品 "${product.name}"，重新計算客人人數`);
            await recalculateCustomerPeopleCount(customer_id, customer.store_id);
        } catch (recalcError) {
            console.error(`[WARNING] 重新計算客人人數失敗:`, recalcError);
            // 不影響主操作，僅記錄警告
        }
    }

    res.json({
      success: true,
      message: '商品已添加到訂單',
      order_id: orderId,
      product_name: product.name,
      quantity: quantity,
      price: product.price,
      locker_number: product.locker_number,
      store_id: customer.store_id
    });

  } catch (error) {
    console.error('添加訂單項目錯誤:', error);
    res.status(500).json({
      error: '添加訂單項目失敗',
      message: error.message
    });
  }
});

// 移除訂單項目
router.delete('/order-item/:id', authMiddleware.authenticate, (req, res) => {
  try {
    const { id } = req.params;

    // 先獲取訂單項目的詳細信息以調整庫存和金額
    db.db.get(
      `SELECT oi.*, p.price as current_price, p.track_inventory, p.name as product_name,
              c.store_id as customer_store_id, c.table_number FROM order_items oi
       LEFT JOIN products p ON oi.product_id = p.id
       LEFT JOIN customers c ON oi.customer_id = c.id
       WHERE oi.id = ?`,
      [id],
      (err, orderItem) => {
        if (err) {
          console.error('獲取訂單項目錯誤:', err);
          return res.status(500).json({ error: '獲取訂單項目失敗', message: err.message });
        }

        if (!orderItem) {
          return res.status(404).json({ error: '訂單項目不存在' });
        }

        // 刪除訂單項目
        db.db.run(
          `DELETE FROM order_items WHERE id = ?`,
          [id],
          function(err2) {
            if (err2) {
              console.error('刪除訂單項目錯誤:', err2);
              return res.status(500).json({ error: '刪除訂單項目失敗', message: err2.message });
            }

            // 更新客人總金額（減去刪除項目的金額）
            const refundAmount = orderItem.quantity * orderItem.price_at_time;
            db.db.run(
              `UPDATE customers SET total_amount = total_amount - ? WHERE id = ?`,
              [refundAmount, orderItem.customer_id],
              (err3) => {
                if (err3) console.error('更新客人金額錯誤:', err3);
              }
            );

            // 恢復商品庫存（僅當 track_inventory = 1 時）
            if (orderItem.track_inventory === 1) {
              db.db.run(
                `UPDATE products SET stock = stock + ? WHERE id = ?`,
                [orderItem.quantity, orderItem.product_id],
                (err4) => {
                  if (err4) console.error('恢復庫存錯誤:', err4);
                }
              );
            }

            // 觸發Socket事件
            const io = req.app.get('io');
            io.emit('order-item-removed', {
              customer_id: orderItem.customer_id,
              order_item_id: id,
              refund_amount: refundAmount
            });

            // 記錄敏感操作審計日誌（刪品）
            try {
              const employeeId = req.employee?.id || null;
              const storeId = orderItem.customer_store_id || 'default_store';
              const ipAddress = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;

              // 構建操作詳情
              const actionDetails = {
                operation: 'delete_product_item',
                order_item_id: id,
                customer_id: orderItem.customer_id,
                product_id: orderItem.product_id,
                product_name: orderItem.product_name,
                table_number: orderItem.table_number,
                old_quantity: orderItem.quantity,
                new_quantity: 0,
                price_at_time: orderItem.price_at_time,
                refund_amount: refundAmount
              };

              // 使用authMiddleware創建審計日誌
              authMiddleware.createAuditLog(
                employeeId,
                'sensitive_delete_product',
                JSON.stringify(actionDetails),
                ipAddress,
                storeId
              );
              console.log(`已記錄刪品敏感操作審計日誌，訂單項目ID: ${id}`);
            } catch (auditError) {
              console.error('記錄刪品審計日誌時發生錯誤（但不影響操作）:', auditError);
            }

            // 如果刪除的商品是「首小時」或「全日通」，重新計算客人人數
            if (orderItem.product_name && (orderItem.product_name.includes('首小時') || orderItem.product_name.includes('全日通'))) {
                try {
                    console.log(`[DEBUG] 檢測到刪除首小時/全日通商品 "${orderItem.product_name}"，重新計算客人人數`);
                    // 注意：recalculateCustomerPeopleCount 是異步函數，但在回調中我們無法 await，所以使用 Promise
                    recalculateCustomerPeopleCount(orderItem.customer_id, orderItem.customer_store_id)
                        .then(newCount => {
                            console.log(`[DEBUG] 刪除後客人人數已更新為: ${newCount}`);
                        })
                        .catch(recalcError => {
                            console.error(`[WARNING] 刪除後重新計算客人人數失敗:`, recalcError);
                        });
                } catch (recalcError) {
                    console.error(`[WARNING] 刪除後重新計算客人人數失敗:`, recalcError);
                    // 不影響主操作，僅記錄警告
                }
            }

            res.json({
              success: true,
              message: '訂單項目已刪除',
              refund_amount: refundAmount
            });
          }
        );
      }
    );
  } catch (error) {
    console.error('刪除訂單項目錯誤:', error);
    res.status(500).json({
      error: '刪除訂單項目失敗',
      message: error.message
    });
  }
});

// 更新訂單項目數量（視為刪品敏感操作）
router.put('/order-item/:id', authMiddleware.authenticate, (req, res) => {
  try {
    const { id } = req.params;
    const { quantity, flat_discount, percent_discount } = req.body;

    if (quantity === undefined || quantity < 0) {
      return res.status(400).json({ error: '請提供有效的數量' });
    }

    if (quantity === 0) {
      return res.status(400).json({ error: '如需刪除請使用刪除功能' });
    }

    // 先獲取訂單項目的當前信息
    db.db.get(
      `SELECT oi.*, p.track_inventory, p.name as product_name,
              c.store_id as customer_store_id, c.table_number FROM order_items oi
       LEFT JOIN products p ON oi.product_id = p.id
       LEFT JOIN customers c ON oi.customer_id = c.id
       WHERE oi.id = ?`,
      [id],
      (err, orderItem) => {
        if (err) {
          console.error('獲取訂單項目錯誤:', err);
          return res.status(500).json({ error: '獲取訂單項目失敗', message: err.message });
        }

        if (!orderItem) {
          return res.status(404).json({ error: '訂單項目不存在' });
        }

        const oldQuantity = orderItem.quantity;
        const newQuantity = parseInt(quantity) || 1;
        const qtyDiff = oldQuantity - newQuantity;

        // 計算折扣變更
        const hasDiscountChange = flat_discount !== undefined || percent_discount !== undefined;
        const oldFlatDisc = orderItem.flat_discount || 0;
        const oldPctDisc = orderItem.percent_discount || 0;
        const newFlatDisc = hasDiscountChange ? (parseFloat(flat_discount) || 0) : oldFlatDisc;
        const newPctDisc = hasDiscountChange ? (parseFloat(percent_discount) || 0) : oldPctDisc;
        const discountChanged = (newFlatDisc !== oldFlatDisc) || (newPctDisc !== oldPctDisc);

        // 計算有效價格（含折扣）
        const calcEffectivePrice = (basePrice, flatDisc, pctDisc) => {
          let effective = basePrice - flatDisc;
          if (pctDisc > 0) {
            effective = effective * (100 - pctDisc) / 100;
          }
          return Math.max(0, effective);
        };

        const oldEffectivePrice = calcEffectivePrice(orderItem.price_at_time, oldFlatDisc, oldPctDisc);
        const newEffectivePrice = calcEffectivePrice(orderItem.price_at_time, newFlatDisc, newPctDisc);
        const oldTotal = oldQuantity * oldEffectivePrice;
        const newTotal = newQuantity * newEffectivePrice;
        const amountDiff = oldTotal - newTotal;

        // 如果沒有任何變更，提早返回
        if (qtyDiff === 0 && !discountChanged) {
          return res.json({ success: true, message: '數量未變更', quantity: oldQuantity });
        }

        // 更新訂單項目
        db.db.run(
          `UPDATE order_items SET quantity = ?, flat_discount = ?, percent_discount = ? WHERE id = ?`,
          [newQuantity, newFlatDisc, newPctDisc, id],
          function(err2) {
            if (err2) {
              console.error('更新訂單項目錯誤:', err2);
              return res.status(500).json({ error: '更新訂單項目失敗', message: err2.message });
            }

            // 調整客人總金額
            if (amountDiff !== 0) {
              db.db.run(
                `UPDATE customers SET total_amount = total_amount - ? WHERE id = ?`,
                [amountDiff, orderItem.customer_id],
                (err3) => {
                  if (err3) console.error('更新客人金額錯誤:', err3);
                }
              );
            }

            // 調整庫存（僅數量變更時）
            if (qtyDiff > 0 && orderItem.track_inventory === 1) {
              db.db.run(
                `UPDATE products SET stock = stock + ? WHERE id = ?`,
                [qtyDiff, orderItem.product_id],
                (err4) => {
                  if (err4) console.error('恢復庫存錯誤:', err4);
                }
              );
            } else if (qtyDiff < 0 && orderItem.track_inventory === 1) {
              const addQty = Math.abs(qtyDiff);
              db.db.run(
                `UPDATE products SET stock = stock - ? WHERE id = ?`,
                [addQty, orderItem.product_id],
                (err5) => {
                  if (err5) console.error('扣減庫存錯誤:', err5);
                }
              );
            }

            // 觸發Socket事件
            const io = req.app.get('io');
            io.emit('order-item-updated', {
              customer_id: orderItem.customer_id,
              order_item_id: id,
              old_quantity: oldQuantity,
              new_quantity: newQuantity,
              amount_diff: amountDiff,
              old_flat_discount: oldFlatDisc,
              new_flat_discount: newFlatDisc,
              old_percent_discount: oldPctDisc,
              new_percent_discount: newPctDisc
            });

            // 記錄敏感操作審計日誌（數量變更或折扣變更均視為刪品敏感操作）
            try {
              const employeeId = req.employee?.id || null;
              const storeId = orderItem.customer_store_id || 'default_store';
              const ipAddress = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;

              const isPriceChangeOnly = qtyDiff === 0;
              const actionType = isPriceChangeOnly ? 'sensitive_price_change' : 'sensitive_delete_product';

              const actionDetails = {
                operation: isPriceChangeOnly
                  ? 'price_change'
                  : (qtyDiff > 0 ? 'decrease_product_quantity' : 'increase_product_quantity'),
                order_item_id: id,
                customer_id: orderItem.customer_id,
                product_id: orderItem.product_id,
                product_name: orderItem.product_name,
                table_number: orderItem.table_number,
                old_quantity: oldQuantity,
                new_quantity: newQuantity,
                quantity_diff: Math.abs(qtyDiff),
                price_at_time: orderItem.price_at_time,
                old_flat_discount: oldFlatDisc,
                new_flat_discount: newFlatDisc,
                old_percent_discount: oldPctDisc,
                new_percent_discount: newPctDisc,
                old_effective_price: oldEffectivePrice,
                new_effective_price: newEffectivePrice,
                amount_diff: amountDiff
              };

              authMiddleware.createAuditLog(
                employeeId,
                actionType,
                JSON.stringify(actionDetails),
                ipAddress,
                storeId
              );
              console.log(`已記錄商品購買變更敏感操作審計日誌，訂單項目ID: ${id}`);
            } catch (auditError) {
              console.error('記錄商品購買變更審計日誌時發生錯誤（但不影響操作）:', auditError);
            }

            // 重新計算客人人數
            if (orderItem.product_name && (orderItem.product_name.includes('首小時') || orderItem.product_name.includes('全日通'))) {
                try {
                    recalculateCustomerPeopleCount(orderItem.customer_id, orderItem.customer_store_id)
                        .then(newCount => console.log(`[DEBUG] 數量變更後客人人數已更新為: ${newCount}`))
                        .catch(recalcError => console.error('重新計算客人人數失敗:', recalcError));
                } catch (recalcError) {
                    console.error('重新計算客人人數失敗:', recalcError);
                }
            }

            res.json({
              success: true,
              message: '訂單項目已更新',
              old_quantity: oldQuantity,
              new_quantity: newQuantity,
              quantity_diff: qtyDiff,
              flat_discount: newFlatDisc,
              percent_discount: newPctDisc,
              old_effective_price: oldEffectivePrice,
              new_effective_price: newEffectivePrice,
              amount_diff: amountDiff
            });
          }
        );
      }
    );
  } catch (error) {
    console.error('更新訂單項目錯誤:', error);
    res.status(500).json({
      error: '更新訂單項目失敗',
      message: error.message
    });
  }
});

// 結賬
router.post('/checkout', async (req, res) => {
  try {
    const { customer_id } = req.body;

    if (!customer_id) {
      return res.status(400).json({ error: '請提供客人ID' });
    }

    // 檢查客人是否存在且未結賬
    const customer = await new Promise((resolve, reject) => {
      db.db.get(
        `SELECT * FROM customers WHERE id = ? AND is_checked_out = 0`,
        [customer_id],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!customer) {
      return res.status(404).json({ error: '客人不存在或已結賬' });
    }

    // 執行結賬
    await db.checkoutCustomer(customer_id);

    // 添加交易記錄
    const transactionId = require('uuid').v4();
    db.db.run(
      `INSERT INTO transactions (id, customer_id, transaction_type, amount, description)
       VALUES (?, ?, ?, ?, ?)`,
      [
        transactionId,
        customer_id,
        'checkout',
        customer.total_amount,
        `桌號 ${customer.table_number} 結賬`
      ],
      (err) => {
        if (err) console.error('添加交易記錄錯誤:', err);
      }
    );

    // 觸發Socket事件
    const io = req.app.get('io');
    io.emit('checkout-complete', {
      customer_id: customer_id,
      table_number: customer.table_number,
      total_amount: customer.total_amount,
      checkout_time: new Date().toISOString()
    });

    // 通知門鎖系統允許離開
    io.emit('device-control', {
      device: 'door-lock',
      action: 'allow-exit',
      qr_code: customer.qr_code,
      valid_until: Date.now() + 300000 // 5分鐘有效期
    });

    res.json({
      success: true,
      message: '結賬成功',
      customer_id: customer_id,
      table_number: customer.table_number,
      total_amount: customer.total_amount,
      checkout_time: new Date().toISOString()
    });

  } catch (error) {
    console.error('結賬錯誤:', error);
    res.status(500).json({
      error: '結賬失敗',
      message: error.message
    });
  }
});

// 獲取今日銷售統計
router.get('/stats/today', (req, res) => {
  try {
    // 使用本地日期（YYYY-MM-DD格式）
    const now = new Date();
    const today = now.getFullYear() + '-' +
                  String(now.getMonth() + 1).padStart(2, '0') + '-' +
                  String(now.getDate()).padStart(2, '0');

    const days = parseInt(req.query.days) || 1;

    // 構建分店過濾條件（用於customers表）
    const { whereClause: storeWhereClause, params: storeParams } = storeAwareMiddleware.buildStoreWhereClause(req, {
      tableAlias: ''
    });

    // 構建完整的WHERE子句 - 包括所有結賬記錄（不含已反結賬）
    let fullWhereClause = 'is_checked_out = 1 AND COALESCE(is_reversed, 0) = 0 AND strftime(\'%Y-%m-%d\', checkout_time, \'localtime\') = ?';
    let queryParams = [today];

    if (storeWhereClause) {
      fullWhereClause += ` AND ${storeWhereClause}`;
      queryParams = [...queryParams, ...storeParams];
    }

    db.db.all(
      `SELECT
        -- 只計算有桌號的客人數
        COUNT(CASE WHEN table_number != '' THEN 1 END) as total_customers,
        -- 計算所有結賬的總收入（包括無桌號）
        SUM(total_amount) as total_revenue,
        -- 計算所有結賬客人的人數（含無桌號）
        SUM(people_count) as total_people,
        -- 平均每有桌號客人消費（總收入/有桌號客人數）
        CASE
          WHEN COUNT(CASE WHEN table_number != '' THEN 1 END) > 0
          THEN SUM(total_amount) / COUNT(CASE WHEN table_number != '' THEN 1 END)
          ELSE 0
        END as avg_per_customer
       FROM customers
       WHERE ${fullWhereClause}`,
      queryParams,
      (err, stats) => {
        if (err) {
          console.error('獲取統計錯誤:', err);
          return res.status(500).json({ error: '獲取統計失敗', message: err.message });
        }

        // 獲取最暢銷商品（需要通過products表進行分店過濾）
        // 構建分店過濾條件（用於products表）
        const { whereClause: productStoreWhereClause, params: productStoreParams } = storeAwareMiddleware.buildStoreWhereClause(req, {
          tableAlias: 'p.'
        });

        let topProductsQuery = `SELECT p.name, SUM(oi.quantity) as total_sold, SUM(oi.quantity * oi.price_at_time) as revenue
           FROM order_items oi
           LEFT JOIN products p ON oi.product_id = p.id`;

        let topProductsWhereClause = `strftime('%Y-%m-%d', oi.purchased_at, 'localtime') = ? AND COALESCE(oi.is_reversed, 0) = 0`;
        let topProductsParams = [today];

        if (productStoreWhereClause) {
          topProductsWhereClause += ` AND ${productStoreWhereClause}`;
          topProductsParams = [...topProductsParams, ...productStoreParams];
        }

        topProductsQuery += ` WHERE ${topProductsWhereClause} GROUP BY oi.product_id ORDER BY total_sold DESC LIMIT 5`;

        db.db.all(
          topProductsQuery,
          topProductsParams,
          (err2, topProducts) => {
            if (err2) {
              console.error('獲取暢銷商品錯誤:', err2);
              return res.status(500).json({ error: '獲取暢銷商品失敗', message: err2.message });
            }

            const response = {
              success: true,
              date: today,
              stats: stats[0] || {
                total_customers: 0,
                total_revenue: 0,
                total_people: 0,
                avg_per_customer: 0
              },
              top_products: topProducts
            };

            // 如果 days > 1，額外查詢過去 (days-1) 天的每日明細（不含今天）
            if (days > 1) {
              const pastDays = days - 1;
              const breakEnd = new Date(now);
              breakEnd.setDate(breakEnd.getDate() - 1);
              const breakStart = new Date(now);
              breakStart.setDate(breakStart.getDate() - pastDays);

              const bEnd = breakEnd.getFullYear() + '-' +
                           String(breakEnd.getMonth() + 1).padStart(2, '0') + '-' +
                           String(breakEnd.getDate()).padStart(2, '0');
              const bStart = breakStart.getFullYear() + '-' +
                             String(breakStart.getMonth() + 1).padStart(2, '0') + '-' +
                             String(breakStart.getDate()).padStart(2, '0');

              let breakdownWhere = 'is_checked_out = 1 AND COALESCE(is_reversed, 0) = 0 AND strftime(\'%Y-%m-%d\', checkout_time, \'localtime\') BETWEEN ? AND ?';
              let breakdownParams = [bStart, bEnd];

              if (storeWhereClause) {
                breakdownWhere += ` AND ${storeWhereClause}`;
                breakdownParams = [...breakdownParams, ...storeParams];
              }

              db.db.all(
                `SELECT
                  strftime('%Y-%m-%d', checkout_time, 'localtime') as date,
                  SUM(total_amount) as revenue,
                  SUM(people_count) as people
                 FROM customers
                 WHERE ${breakdownWhere}
                 GROUP BY strftime('%Y-%m-%d', checkout_time, 'localtime')
                 ORDER BY date DESC`,
                breakdownParams,
                (err3, dailyBreakdown) => {
                  if (err3) {
                    console.error('獲取每日明細錯誤:', err3);
                    response.daily_breakdown = [];
                  } else {
                    // 填充缺失日期（營業額/客數為 0 的天數仍顯示）
                    const breakdownMap = {};
                    (dailyBreakdown || []).forEach(d => {
                      breakdownMap[d.date] = { revenue: d.revenue || 0, people: d.people || 0 };
                    });
                    const filled = [];
                    const iterDate = new Date(bStart + 'T00:00:00');
                    const endDate = new Date(bEnd + 'T00:00:00');
                    while (iterDate <= endDate) {
                      const key = iterDate.getFullYear() + '-' +
                                  String(iterDate.getMonth() + 1).padStart(2, '0') + '-' +
                                  String(iterDate.getDate()).padStart(2, '0');
                      filled.push({
                        date: key,
                        revenue: breakdownMap[key] ? breakdownMap[key].revenue : 0,
                        people: breakdownMap[key] ? breakdownMap[key].people : 0
                      });
                      iterDate.setDate(iterDate.getDate() + 1);
                    }
                    filled.sort((a, b) => b.date.localeCompare(a.date));
                    response.daily_breakdown = filled;
                  }
                  res.json(response);
                }
              );
            } else {
              res.json(response);
            }
          }
        );
      }
    );
  } catch (error) {
    console.error('獲取統計錯誤:', error);
    res.status(500).json({
      error: '獲取統計失敗',
      message: error.message
    });
  }
});

// 獲取今日結賬詳細記錄
router.get('/checkout-records/today', (req, res) => {
  console.log('=== /api/cashier/checkout-records/today 路由被調用 ===');
  console.log('請求查詢參數:', req.query);
  console.log('請求路徑:', req.path);
  console.log('請求方法:', req.method);
  console.log('當前時間:', new Date().toISOString());

  try {
    // 使用本地日期（YYYY-MM-DD格式）
    const now = new Date();
    const today = now.getFullYear() + '-' +
                  String(now.getMonth() + 1).padStart(2, '0') + '-' +
                  String(now.getDate()).padStart(2, '0');

    // 構建分店過濾條件
    const { whereClause: storeWhereClause, params: storeParams } = storeAwareMiddleware.buildStoreWhereClause(req, {
      tableAlias: 'c.'
    });
    console.log('[DEBUG] /api/cashier/checkout-records/today 分店過濾:', {
      storeWhereClause,
      storeParams,
      storeContext: req.storeContext,
      employee: req.employee ? { id: req.employee.id, role: req.employee.role, store_id: req.employee.store_id } : null
    });

    // 構建完整的WHERE子句
    let fullWhereClause = 'c.is_checked_out = 1 AND SUBSTR(c.checkout_time, 1, 10) = ?';
    let queryParams = [today];

    if (storeWhereClause) {
      fullWhereClause += ` AND ${storeWhereClause}`;
      queryParams = [...queryParams, ...storeParams];
    }

    console.log('[DEBUG] /api/cashier/checkout-records/today 完整SQL條件:', {
      fullWhereClause,
      queryParams,
      sql: `SELECT c.id, c.table_number, c.store_id, c.checkout_time, ... FROM customers c WHERE ${fullWhereClause} ORDER BY c.checkout_time DESC`
    });

    db.db.all(
      `SELECT
        c.id,
        c.store_id,
        c.table_number,
        c.people_count,
        c.entry_time,
        c.checkout_time,
        c.total_amount,
        c.is_checked_out,
        c.is_reversed,
        c.is_member,
        c.member_card_id,
        c.created_at,
        c.qr_code,
        c.reverse_employee_name,
        -- 商品列表（使用子查詢去重）
        COALESCE((
          SELECT GROUP_CONCAT(product_name, ', ')
          FROM (
            SELECT p.name || ' ×' || SUM(oi.quantity) as product_name
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            WHERE oi.customer_id = c.id
            GROUP BY oi.product_id
          )
        ), '無') as products,
        -- 儲物柜列表（優先使用lockers_used字段，後備查詢lockers表）
        COALESCE(
          c.lockers_used,
          (
            SELECT GROUP_CONCAT('#' || l.locker_number, ', ')
            FROM lockers l
            WHERE l.customer_id = c.id
          ),
          '無'
        ) as lockers
       FROM customers c
       WHERE ${fullWhereClause}
       ORDER BY c.checkout_time DESC`,
      queryParams,
      (err, rows) => {
        if (err) {
          console.error('獲取今日結賬記錄錯誤:', err);
          console.error('錯誤堆棧:', err.stack);
          return res.status(500).json({
            success: false,
            error: '獲取今日結賬記錄失敗',
            message: err.message,
            stack: err.stack // 僅用於調試
          });
        }

        // 調試日誌
        console.log('今日結賬記錄原始數據（含store_id）:', rows.map(row => ({
          id: row.id,
          store_id: row.store_id,
          table_number: row.table_number,
          products: row.products,
          lockers: row.lockers,
          lockers_raw: row.lockers,
          has_lockers: !!row.lockers,
          is_lockers_null: row.lockers === null,
          is_lockers_empty_string: row.lockers === ''
        })));

        // 格式化數據
        const formattedRecords = rows.map(row => ({
          id: row.id,
          store_id: row.store_id,  // 添加store_id用於調試
          table_number: row.table_number,
          people_count: row.people_count,
          entry_time: row.entry_time,
          checkout_time: row.checkout_time,
          total_amount: row.total_amount || 0,
          is_checked_out: row.is_checked_out === 1,
          is_reversed: row.is_reversed === 1,
          reverse_employee_name: row.reverse_employee_name || '',
          is_member: row.is_member === 1,
          member_card_id: row.member_card_id,
          created_at: row.created_at,
          qr_code: row.qr_code || row.id,
          products: (row.products && row.products.trim() !== '') ? row.products : '無',
          lockers: (row.lockers && row.lockers.trim() !== '') ? row.lockers : '無'
        }));

        res.json({
          success: true,
          date: today,
          records: formattedRecords,
          count: formattedRecords.length
        });
      }
    );
  } catch (error) {
    console.error('獲取今日結賬記錄錯誤:', error);
    res.status(500).json({
      success: false,
      error: '獲取今日結賬記錄失敗',
      message: error.message
    });
  }
});

// 獲取入場紀錄
router.get('/entry-records', (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];

    // 構建分店過濾條件
    const { whereClause: storeWhereClause, params: storeParams } = storeAwareMiddleware.buildStoreWhereClause(req, {
      tableAlias: ''
    });

    // 構建完整的WHERE子句
    let fullWhereClause = '1=1';
    let queryParams = [];

    if (storeWhereClause) {
      fullWhereClause = storeWhereClause;
      queryParams = [...storeParams];
    }

    // 獲取所有入場紀錄（包括已結賬的）
    let entriesQuery = `SELECT
        id,
        table_number,
        people_count,
        entry_time,
        is_checked_out,
        CASE
          WHEN is_checked_out = 0 THEN 'active'
          ELSE 'checked_out'
        END as status
       FROM customers
       WHERE ${fullWhereClause}
       ORDER BY entry_time DESC
       LIMIT 50`;

    db.db.all(
      entriesQuery,
      queryParams,
      (err, rows) => {
        if (err) {
          console.error('獲取入場紀錄錯誤:', err);
          return res.status(500).json({ error: '獲取入場紀錄失敗', message: err.message });
        }

        // 獲取今日入場計數（使用相同的分店過濾）
        let todayCountQuery = `SELECT COUNT(*) as today_count FROM customers WHERE DATE(entry_time) = ?`;
        let todayCountParams = [today];

        if (storeWhereClause) {
          todayCountQuery += ` AND ${storeWhereClause}`;
          todayCountParams = [...todayCountParams, ...storeParams];
        }

        db.db.get(
          todayCountQuery,
          todayCountParams,
          (err2, countResult) => {
            if (err2) {
              console.error('獲取今日計數錯誤:', err2);
              return res.status(500).json({ error: '獲取今日計數失敗', message: err2.message });
            }

            res.json({
              success: true,
              entries: rows,
              today_count: countResult.today_count || 0
            });
          }
        );
      }
    );
  } catch (error) {
    console.error('獲取入場紀錄錯誤:', error);
    res.status(500).json({
      error: '獲取入場紀錄失敗',
      message: error.message
    });
  }
});

// 獨立無桌號結賬通道
router.post('/no-table-checkout', async (req, res) => {
  try {
    const { items, peopleCount = 0, memberCardId } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';
    const employee = req.employee;

    console.log('無桌號結賬請求:', {
      itemsCount: items ? items.length : 0,
      peopleCount,
      memberCardId,
      storeId,
      employee: employee ? { id: employee.id, name: employee.name } : null
    });

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        error: '購物車為空',
        message: '請添加商品後再結賬'
      });
    }

    // 驗證商品
    for (const item of items) {
      if (!item.product_id || !item.quantity || item.quantity <= 0) {
        return res.status(400).json({
          error: '商品數據不完整',
          message: `商品ID: ${item.product_id}, 數量: ${item.quantity}`
        });
      }
    }

    // 創建無桌號客人（跳過桌位、儲物柜、首小時商品）
    const customerId = uuidv4();
    const qrCode = `NO-TABLE-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const entryTime = new Date().toISOString();

    // 檢查會員卡（如果有提供）
    let isMember = false;
    if (memberCardId) {
      try {
        const member = await new Promise((resolve) => {
          db.db.get(
            `SELECT * FROM members WHERE card_id = ?`,
            [memberCardId],
            (err, row) => {
              if (err) {
                console.error('檢查會員卡錯誤:', err);
                resolve(null);
              } else {
                resolve(row);
              }
            }
          );
        });

        if (member) {
          isMember = true;
        }
      } catch (error) {
        console.error('檢查會員卡錯誤:', error);
        // 不阻礙流程，繼續作為非會員處理
      }
    }

    // 插入客人記錄
    await new Promise((resolve, reject) => {
      db.db.run(
        `INSERT INTO customers (
          id, table_number, people_count, is_member, member_card_id,
          qr_code, entry_time, store_id, is_checked_out, checkout_time, total_amount
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          customerId,
          '', // table_number 空字符串表示無桌號
          peopleCount,
          isMember ? 1 : 0,
          memberCardId || null,
          qrCode,
          entryTime,
          storeId,
          0, // is_checked_out
          null, // checkout_time
          0   // total_amount 初始為0，添加商品後更新
        ],
        function(err) {
          if (err) reject(err);
          else resolve(this.lastID);
        }
      );
    });

    console.log(`無桌號客人創建成功: ${customerId}`);

    // 批量添加購物車商品
    let totalAmount = 0;
    const orderItems = [];

    for (const item of items) {
      // 獲取商品信息 - 先嘗試當前分店，再嘗試default_store
      let product = await new Promise((resolve, reject) => {
        db.db.get(
          `SELECT id, name, price, category FROM products WHERE id = ? AND store_id = ?`,
          [item.product_id, storeId],
          (err, row) => {
            if (err) reject(err);
            else resolve(row);
          }
        );
      });

      // 如果當前分店找不到，嘗試default_store
      if (!product && storeId !== 'default_store') {
        console.log(`商品 ${item.product_id} 在分店 ${storeId} 中未找到，嘗試 default_store`);
        product = await new Promise((resolve, reject) => {
          db.db.get(
            `SELECT id, name, price, category FROM products WHERE id = ? AND store_id = ?`,
            [item.product_id, 'default_store'],
            (err, row) => {
              if (err) reject(err);
              else resolve(row);
            }
          );
        });
      }

      if (!product) {
        throw new Error(`商品不存在: ${item.product_id} (分店: ${storeId} 或 default_store)`);
      }

      // 創建訂單項目
      const orderItemId = uuidv4();
      const itemPrice = product.price;
      const itemTotal = itemPrice * item.quantity;
      totalAmount += itemTotal;

      await new Promise((resolve, reject) => {
        db.db.run(
          `INSERT INTO order_items (
            id, customer_id, product_id, quantity, price_at_time, store_id
          ) VALUES (?, ?, ?, ?, ?, ?)`,
          [
            orderItemId,
            customerId,
            product.id,
            item.quantity,
            itemPrice,
            storeId
          ],
          function(err) {
            if (err) reject(err);
            else resolve();
          }
        );
      });

      orderItems.push({
        id: orderItemId,
        product_id: product.id,
        product_name: product.name,
        quantity: item.quantity,
        price: itemPrice,
        total_price: itemTotal
      });
    }

    // 更新客人總金額
    await new Promise((resolve, reject) => {
      db.db.run(
        `UPDATE customers SET total_amount = ? WHERE id = ?`,
        [totalAmount, customerId],
        function(err) {
          if (err) reject(err);
          else resolve();
        }
      );
    });

    // 執行結賬
    const checkoutTime = new Date().toISOString();
    await new Promise((resolve, reject) => {
      db.db.run(
        `UPDATE customers SET is_checked_out = 1, checkout_time = ? WHERE id = ?`,
        [checkoutTime, customerId],
        function(err) {
          if (err) reject(err);
          else resolve();
        }
      );
    });

    // 添加交易記錄
    const transactionId = uuidv4();
    db.db.run(
      `INSERT INTO transactions (id, customer_id, transaction_type, amount, description)
       VALUES (?, ?, ?, ?, ?)`,
      [
        transactionId,
        customerId,
        'checkout',
        totalAmount,
        `無桌號結賬 - ${orderItems.length} 件商品`
      ],
      (err) => {
        if (err) console.error('添加交易記錄錯誤:', err);
      }
    );

    // 觸發Socket事件（通知收銀系統更新）
    const io = req.app.get('io');
    io.emit('no-table-checkout-complete', {
      customer_id: customerId,
      total_amount: totalAmount,
      checkout_time: checkoutTime,
      item_count: orderItems.length
    });

    // 如果需要打印小票，觸發打印事件
    io.emit('print-no-table-receipt', {
      customer_id: customerId,
      qr_code: qrCode,
      total_amount: totalAmount,
      checkout_time: checkoutTime,
      items: orderItems,
      employee: employee ? { name: employee.name, id: employee.id } : null
    });

    // 構建返回數據
    const customerRecord = await new Promise((resolve, reject) => {
      db.db.get(
        `SELECT * FROM customers WHERE id = ?`,
        [customerId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    res.json({
      success: true,
      message: '無桌號結賬成功',
      customer: customerRecord,
      order_items: orderItems,
      total_amount: totalAmount,
      checkout_time: checkoutTime,
      receipt_data: {
        customer_id: customerId,
        qr_code: qrCode,
        total_amount: totalAmount,
        checkout_time: new Date().toLocaleString('zh-TW'),
        item_count: orderItems.length,
        items: orderItems.map(item => ({
          name: item.product_name,
          quantity: item.quantity,
          price: item.price,
          total: item.total_price
        }))
      }
    });

  } catch (error) {
    console.error('無桌號結賬錯誤:', error);
    res.status(500).json({
      error: '無桌號結賬失敗',
      message: error.message,
      details: error.stack
    });
  }
});

// 獲取設備狀態
router.get('/device-status', (req, res) => {
  try {
    // 模擬設備狀態（實際應從各設備獲取）
    const devices = {
      printer: { status: 'online', last_seen: new Date().toISOString() },
      locker: { status: 'online', last_seen: new Date().toISOString() },
      doorlock: { status: 'online', last_seen: new Date().toISOString() },
      audio: { status: 'online', last_seen: new Date().toISOString() },
      nfc: { status: 'online', last_seen: new Date().toISOString() }
    };

    res.json({
      success: true,
      devices: devices
    });
  } catch (error) {
    console.error('獲取設備狀態錯誤:', error);
    res.status(500).json({
      error: '獲取設備狀態失敗',
      message: error.message
    });
  }
});

// 設備控制操作

// 測試打印機
router.post('/test-printer', (req, res) => {
  try {
    // 這裡應該調用打印機測試邏輯
    res.json({
      success: true,
      message: '打印機測試成功'
    });
  } catch (error) {
    console.error('測試打印機錯誤:', error);
    res.status(500).json({
      error: '測試打印機失敗',
      message: error.message
    });
  }
});

// 重設打印機
router.post('/reset-printer', (req, res) => {
  try {
    res.json({
      success: true,
      message: '打印機已重設'
    });
  } catch (error) {
    console.error('重設打印機錯誤:', error);
    res.status(500).json({
      error: '重設打印機失敗',
      message: error.message
    });
  }
});

// 掃描藍牙設備（小票機）
router.post('/scan-bluetooth', (req, res) => {
  try {
    // 模擬掃描藍牙設備
    // 實際實現應調用藍牙掃描API
    const bluetoothDevices = [
      { name: 'Receipt Printer-001', address: '00:11:22:33:44:55', rssi: -45 },
      { name: 'EPSON TM-T88V', address: 'AA:BB:CC:DD:EE:FF', rssi: -52 },
      { name: 'Star TSP100', address: '11:22:33:44:55:66', rssi: -60 },
      { name: 'HP OfficeJet', address: '77:88:99:AA:BB:CC', rssi: -65 }
    ];

    console.log('掃描藍牙設備完成，找到設備數:', bluetoothDevices.length);

    res.json({
      success: true,
      message: '藍牙掃描完成',
      devices: bluetoothDevices,
      count: bluetoothDevices.length
    });
  } catch (error) {
    console.error('掃描藍牙設備錯誤:', error);
    res.status(500).json({
      error: '掃描藍牙設備失敗',
      message: error.message
    });
  }
});

// 連接小票機（真實連接）
router.post('/connect-receipt-printer', async (req, res) => {
  try {
    const { connectionType, ipAddress, port, bluetoothAddress, printerType = 'epson', storeId } = req.body;
    const currentStoreId = storeId || req.storeContext?.store_id || 'default_store';

    if (!connectionType) {
      return res.status(400).json({
        error: '連接類型未指定',
        message: '請選擇WiFi或藍牙連接類型'
      });
    }

    let connectionDetails = {};
    let printer = null;
    let printerPort;
    let ipAddressForLog, portForLog;

    if (connectionType === 'wifi') {
      if (!ipAddress) {
        return res.status(400).json({
          error: 'WiFi連接參數不完整',
          message: '請提供IP地址'
        });
      }

      printerPort = port || 9100;
      ipAddressForLog = ipAddress;
      portForLog = printerPort;
      const selectedPrinterType = printerType === 'star' ? PrinterTypes.STAR : PrinterTypes.EPSON;

      // 創建原始打印機實例（兼容佳博 GP-D801）
      printer = new RawPrinter({
        ip_address: ipAddress,
        port: printerPort,
        encoding: 'ascii',
        timeout: 30000
      });

      connectionDetails = {
        type: 'wifi',
        ip: ipAddress,
        port: printerPort,
        protocol: 'TCP',
        printer_type: printerType,
        driver: 'raw-escpos'
      };

      console.log(`嘗試小票機WiFi連接 (原始ESC/POS): IP=${ipAddress}, 端口=${printerPort}`);

    } else if (connectionType === 'bluetooth') {
      if (!bluetoothAddress) {
        return res.status(400).json({
          error: '藍牙連接參數不完整',
          message: '請選擇藍牙設備'
        });
      }

      // 注意：node-thermal-printer對藍牙支持有限，需要額外配置
      printer = new ThermalPrinter({
        type: PrinterTypes.EPSON,
        interface: `bt://${bluetoothAddress}`,
        options: { timeout: 10000 }
      });

      connectionDetails = {
        type: 'bluetooth',
        address: bluetoothAddress,
        profile: 'SPP',
        printer_type: printerType
      };

      console.log(`嘗試小票機藍牙連接: 地址=${bluetoothAddress}`);
      ipAddressForLog = bluetoothAddress;
      portForLog = 'N/A';

    } else {
      return res.status(400).json({
        error: '無效的連接類型',
        message: '連接類型必須是wifi或bluetooth'
      });
    }

    // 測試實際連接
    try {
      console.log(`嘗試連接打印機: ${ipAddressForLog}:${portForLog}, 類型: ${printerType}, 超時: 30000ms`);

      printer.clear();
      // 先不設置任何格式，直接打印最簡單的測試
      printer.println('TEST');
      printer.println('---');
      printer.println('Auto Cafe System');
      printer.println('---');
      // 不執行cut，有些打印機對cut命令敏感
      // printer.cut();

      // 檢查是否為模擬設備（iPod或測試IP）
      const isSimulatedDevice =
        (connectionType === 'bluetooth' && bluetoothAddress === 'CC:08:FA:EF:FB:5F') ||
        (connectionType === 'wifi' && ipAddress === '192.168.1.100');

      if (isSimulatedDevice) {
        console.log(`檢測到模擬設備 (${connectionType}: ${connectionType === 'bluetooth' ? bluetoothAddress : ipAddress})，跳過實際連接測試`);
        // 模擬成功連接
        // 不實際執行打印機命令
      } else {
        await printer.execute(); // RawPrinter.execute() 成功時返回true，失敗時拋出錯誤
      }

      const message = `已成功連接到小票機 ${connectionType === 'wifi' ? `${ipAddress}:${port || 9100}` : bluetoothAddress}${isSimulatedDevice ? ' (模擬模式)' : ''}`;

      // 連接成功，自動保存或更新配置
      const { configName } = req.body;
      const actualConfigName = configName || `自動配置_${new Date().toISOString().slice(0, 10)}`;

      // 檢查該分店是否已有默認配置
      db.db.get(
        `SELECT id FROM printer_configs WHERE store_id = ? AND is_default = 1 LIMIT 1`,
        [currentStoreId],
        (err, existingDefault) => {
          if (err) {
            console.error('檢查默認配置錯誤:', err);
            return;
          }

          if (existingDefault) {
            // 更新現有的默認配置
            db.db.run(
              `UPDATE printer_configs SET
                printer_name = ?,
                connection_type = ?,
                ip_address = ?,
                port = ?,
                printer_type = ?,
                updated_at = datetime('now')
               WHERE id = ?`,
              [
                actualConfigName,
                connectionType,
                ipAddress,
                port || 9100,
                printerType,
                existingDefault.id
              ],
              (updateErr) => {
                if (updateErr) {
                  console.error('更新打印機配置錯誤:', updateErr);
                } else {
                  console.log(`打印機配置已更新: ${actualConfigName} (ID: ${existingDefault.id})`);
                }
              }
            );
          } else {
            // 檢查是否已有同名配置
            db.db.get(
              `SELECT id FROM printer_configs WHERE store_id = ? AND printer_name = ? LIMIT 1`,
              [currentStoreId, actualConfigName],
              (checkErr, existingConfig) => {
                if (checkErr) {
                  console.error('檢查同名配置錯誤:', checkErr);
                  return;
                }

                if (existingConfig) {
                  // 更新現有配置
                  db.db.run(
                    `UPDATE printer_configs SET
                      connection_type = ?,
                      ip_address = ?,
                      port = ?,
                      printer_type = ?,
                      is_default = 1,
                      updated_at = datetime('now')
                     WHERE id = ?`,
                    [
                      connectionType,
                      ipAddress,
                      port || 9100,
                      printerType,
                      existingConfig.id
                    ],
                    (updateErr) => {
                      if (updateErr) {
                        console.error('更新打印機配置錯誤:', updateErr);
                      } else {
                        console.log(`打印機配置已更新為默認: ${actualConfigName} (ID: ${existingConfig.id})`);
                      }
                    }
                  );
                } else {
                  // 創建新配置（設為默認）
                  const configId = uuidv4();
                  db.db.run(
                    `INSERT INTO printer_configs (id, store_id, printer_name, connection_type, ip_address, port, printer_type, is_default, created_at, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`,
                    [
                      configId,
                      currentStoreId,
                      actualConfigName,
                      connectionType,
                      ipAddress,
                      port || 9100,
                      printerType,
                      1, // 設為默認
                    ],
                    (insertErr) => {
                      if (insertErr) {
                        console.error('保存打印機配置錯誤:', insertErr);
                      } else {
                        console.log(`打印機配置已保存為默認: ${actualConfigName} (ID: ${configId})`);
                      }
                    }
                  );
                }
              }
            );
          }
        }
      );

      // 更新打印機狀態為在線
      if (printerStatus) {
        printerStatus.status = 'online';
        printerStatus.last_seen = new Date().toISOString();
        printerStatus.type = printerType || printerStatus.type;
        console.log('打印機狀態已更新為在線');
      }

      res.json({
        success: true,
        message: message,
        connection: connectionDetails,
        status: 'connected',
        store_id: currentStoreId,
        timestamp: new Date().toISOString(),
        config_saved: !!configName,
        simulated: isSimulatedDevice
      });

    } catch (printError) {
      console.error('打印機連接測試失敗 - 詳細錯誤:', printError);
      console.error('錯誤堆棧:', printError.stack);

      // 嘗試使用更簡單的測試 - 只發送換行和空白
      try {
        console.log('嘗試最簡單的測試...');
        printer.clear();
        printer.println('');
        printer.println(' ');
        const simpleSuccess = await printer.execute();

        if (simpleSuccess) {
          console.log('簡單測試成功');
          // 更新打印機狀態為在線
          if (printerStatus) {
            printerStatus.status = 'online';
            printerStatus.last_seen = new Date().toISOString();
            printerStatus.type = printerType || printerStatus.type;
            console.log('打印機狀態已更新為在線（簡單測試成功）');
          }

          res.json({
            success: true,
            message: `連接到小票機成功，但完整測試打印失敗`,
            connection: connectionDetails,
            status: 'connected_with_warning',
            store_id: currentStoreId,
            timestamp: new Date().toISOString(),
            warning: '打印機已連接但可能命令集不兼容，請檢查設置'
          });
        } else {
          throw new Error('簡單測試也失敗');
        }
      } catch (simpleError) {
        console.error('簡單測試也失敗:', simpleError);
        console.error('simpleError類型:', typeof simpleError);
        console.error('simpleError原始值:', simpleError);
        console.error('simpleError keys:', Object.keys(simpleError || {}));

        console.error('printError類型:', typeof printError);
        console.error('printError原始值:', printError);
        console.error('printError keys:', Object.keys(printError || {}));

        // 安全地獲取錯誤消息
        const getErrorMessage = (error) => {
          if (!error) return '未知錯誤';
          if (typeof error === 'string') return error;
          if (error.message) return error.message;
          if (error.toString && typeof error.toString === 'function') {
            return error.toString();
          }
          return JSON.stringify(error);
        };

        const originalErrorMessage = getErrorMessage(printError);
        const simpleErrorMessage = getErrorMessage(simpleError);

        console.error('originalErrorMessage:', originalErrorMessage);
        console.error('simpleErrorMessage:', simpleErrorMessage);

        res.status(500).json({
          error: '連接小票機失敗',
          message: `無法連接到打印機: ${originalErrorMessage}`,
          details: `請檢查: 1. IP地址 ${ipAddressForLog} 是否正確, 2. 端口 ${portForLog} 是否開放, 3. 打印機電源和網絡連接`,
          connection: connectionDetails,
          store_id: currentStoreId,
          debug: {
            original_error: originalErrorMessage,
            simple_error: simpleErrorMessage,
            printError_type: typeof printError,
            simpleError_type: typeof simpleError
          }
        });
      }
    }

  } catch (error) {
    console.error('連接小票機錯誤:', error);
    res.status(500).json({
      error: '連接小票機失敗',
      message: error.message,
      store_id: req.storeContext?.store_id || 'default_store'
    });
  }
});

// 斷開小票機連接
router.post('/disconnect-receipt-printer', (req, res) => {
  try {
    const { connectionType } = req.body;

    console.log(`斷開小票機連接: ${connectionType || '未知類型'}`);

    // 模擬斷開連接
    // 實際實現應關閉連接

    res.json({
      success: true,
      message: '小票機已斷開連接',
      status: 'disconnected',
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('斷開小票機連接錯誤:', error);
    res.status(500).json({
      error: '斷開小票機連接失敗',
      message: error.message
    });
  }
});

// 測試小票機（真實測試打印）
router.post('/test-receipt-printer', async (req, res) => {
  try {
    const { connectionType, ipAddress, port, bluetoothAddress, printerType = 'epson', storeId } = req.body;
    const currentStoreId = storeId || req.storeContext?.store_id || 'default_store';

    console.log(`測試小票機: ${connectionType || '未知類型'}, 分店: ${currentStoreId}`);

    // 創建打印機實例
    let printer = null;
    let connectionDetails = {};
    let printerPort;
    let ipAddressForLog, portForLog;

    if (connectionType === 'wifi') {
      if (!ipAddress) {
        return res.status(400).json({
          error: 'WiFi連接參數不完整',
          message: '請提供IP地址'
        });
      }

      printerPort = port || 9100;
      ipAddressForLog = ipAddress;
      portForLog = printerPort;
      const selectedPrinterType = printerType === 'star' ? PrinterTypes.STAR : PrinterTypes.EPSON;

      // 使用原始ESC/POS打印機（兼容佳博 GP-D801）
      printer = new RawPrinter({
        ip_address: ipAddress,
        port: printerPort,
        encoding: 'GBK',
        timeout: 15000
      });

      connectionDetails = {
        type: 'wifi',
        ip: ipAddress,
        port: printerPort,
        printer_type: printerType
      };

    } else if (connectionType === 'bluetooth') {
      if (!bluetoothAddress) {
        return res.status(400).json({
          error: '藍牙連接參數不完整',
          message: '請選擇藍牙設備'
        });
      }

      printer = new ThermalPrinter({
        type: PrinterTypes.EPSON,
        interface: `bt://${bluetoothAddress}`,
        options: { timeout: 15000 }
      });

      connectionDetails = {
        type: 'bluetooth',
        address: bluetoothAddress,
        printer_type: printerType
      };
      ipAddressForLog = bluetoothAddress;
      portForLog = 'N/A';

    } else {
      return res.status(400).json({
        error: '無效的連接類型',
        message: '連接類型必須是wifi或bluetooth'
      });
    }

    // 提取模板配置和測試類型
    const { templateConfig, test_type } = req.body;

    let testContent;
    let useChineseEncoding = false;
    let config = null;

    // 根據測試類型生成不同的小票內容
    if (test_type === 'template_preview' && templateConfig) {
      // 使用模板配置生成測試小票
      useChineseEncoding = true; // 模板可能包含中文

      // 合併默認配置（簡單版本）
      const defaultConfig = {
        company_name: '自動咖啡館系統',
        store_name: '',
        header_text: '測試小票',
        footer_text: '感謝光臨',
        contact_info: ''
      };

      config = { ...defaultConfig, ...templateConfig };

      // 生成與前端預覽完全一致的小票內容
      const storeDisplay = config.store_name || currentStoreId;
      const testDate = new Date().toLocaleString('zh-TW');

      // 輔助函數：左對齊標籤和值，考慮中文字符寬度
      function formatLine(label, value, width = 48) {
        const labelPart = label.toString();
        const valuePart = value.toString();
        const labelWidth = getDisplayWidth(labelPart);
        const valueWidth = getDisplayWidth(valuePart);
        const padding = Math.max(0, width - labelWidth - valueWidth);
        return labelPart + ' '.repeat(padding) + valuePart;
      }

      const contentLines = [];

      // 頂部邊界線
      contentLines.push('='.repeat(48));

      // LOGO打印（如果配置啟用）
      if (config.show_logo === true && config.logo_base64 && config.logo_base64.length > 0) {
        // TODO: 實現LOGO圖片打印
        console.log('LOGO打印已啟用，base64數據長度:', config.logo_base64.length);
        // 圖像LOGO將單獨打印，不添加文本佔位符
      }

      // 公司名稱（居中，處理多行）
      if (config.company_name && config.company_name.trim()) {
        const centeredCompany = centerMultilineText(config.company_name);
        const lines = centeredCompany.split('\n');
        lines.forEach(line => {
          contentLines.push(line);
        });
      }

      // 分店名稱（居中，處理多行）
      if (config.store_name && config.store_name.trim()) {
        const centeredStore = centerMultilineText(config.store_name);
        const lines = centeredStore.split('\n');
        lines.forEach(line => {
          contentLines.push(line);
        });
      }

      // Header文字（居中，處理多行）
      if (config.header_text && config.header_text.trim()) {
        const centeredHeader = centerMultilineText(config.header_text);
        const lines = centeredHeader.split('\n');
        lines.forEach(line => {
          contentLines.push(line);
        });
      }

      // 內容分隔線
      contentLines.push('='.repeat(48));

      // 桌號（固定為A10，模仿前端預覽）
      contentLines.push(formatLine('桌號:', 'A10'));

      // 結賬時間（使用當前時間，但格式模仿前端預覽）
      const formattedTime = new Date().toLocaleString('zh-TW', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      }).replace(/\//g, '-');
      contentLines.push(formatLine('結賬時間:', formattedTime));

      // 儲物柜信息（根據配置顯示）
      if (config.show_locker_info !== false) {
        contentLines.push(formatLine('儲物柜:', 'L01, L02'));
      }

      // QR Code信息（根據配置顯示）
      if (config.show_qr_code !== false) {
        contentLines.push(''); // 空行
        contentLines.push(centerText('QR Code (測試用)'));
        contentLines.push(centerText('TSUENWAN-2026-ABCDEF'));
        contentLines.push(''); // 空行
      }

      // 商品列表標題
      contentLines.push('購買項目:');
      contentLines.push('-'.repeat(48));

      // 商品列表（與前端預覽完全一致）
      const items = [
        { name: '美式咖啡', quantity: 2, price: 80 },
        { name: '巧克力蛋糕', quantity: 1, price: 150 },
        { name: '奶茶', quantity: 1, price: 90 }
      ];

      // 計算每項小計和總計
      let total = 0;
      items.forEach(item => {
        const itemTotal = item.quantity * item.price;
        total += itemTotal;
        // 格式化商品行：名稱 x數量 單價 = 小計
        const namePart = `${item.name} x${item.quantity}`;
        const pricePart = `$${item.price} = $${itemTotal}`;
        contentLines.push(formatLine(namePart, pricePart));
      });

      // 商品列表後分隔線
      contentLines.push('-'.repeat(48));

      // 總金額（與前端預覽一致）
      contentLines.push(formatLine('總金額:', `$${total}`));

      // 底部邊界線
      contentLines.push('='.repeat(48));

      // Footer文字（居中，處理多行）
      if (config.footer_text && config.footer_text.trim()) {
        const centeredFooter = centerMultilineText(config.footer_text);
        const lines = centeredFooter.split('\n');
        lines.forEach(line => {
          contentLines.push(line);
        });
      }

      // 聯繫信息（居中，處理多行）
      if (config.contact_info && config.contact_info.trim()) {
        const centeredContact = centerMultilineText(config.contact_info);
        const lines = centeredContact.split('\n');
        lines.forEach(line => {
          contentLines.push(line);
        });
      }

      // 底部邊界線
      contentLines.push('='.repeat(48));

      testContent = contentLines.join('\n');

    } else {
      // 簡單ASCII測試（原始版本）
      const testDate = new Date().toLocaleString('en-US');
      testContent = [
        'AUTO CAFE SYSTEM',
        'TEST RECEIPT',
        '--------------',
        `Time: ${testDate}`,
        `Store: ${currentStoreId}`,
        `Type: ${connectionType}`,
        connectionType === 'wifi' ? `IP: ${ipAddress}:${port || 9100}` : `BT: ${bluetoothAddress}`,
        `Printer: ${printerType}`,
        '--------------',
        'TEST PRINT',
        'Printer connection',
        'verification test',
        '--------------',
        'Item       Price Qty Total',
        '--------------',
        'Test Item1 $10   1   $10',
        'Test Item2 $20   2   $40',
        'Test Item3 $15   1   $15',
        '--------------',
        'TOTAL:            $65',
        '===============',
        'Thank you',
        '==============='
      ].join('\n');
    }

    // 文本置中輔助函數
    // 處理轉義的換行符，將 \n 轉換為實際換行
    function processNewlines(str) {
      if (!str) return '';
      return str.replace(/\\n/g, '\n');
    }

    // 計算字符串在熱敏打印機上的顯示寬度（中文字符=2，英文字符=1）
    function getDisplayWidth(str) {
      if (!str) return 0;
      let width = 0;
      for (let i = 0; i < str.length; i++) {
        const char = str.charAt(i);
        // 中文字符範圍判斷（簡化版）
        const charCode = str.charCodeAt(i);
        if (charCode >= 0x4e00 && charCode <= 0x9fff) {
          width += 2; // 中文字符
        } else if (charCode >= 0x3040 && charCode <= 0x30ff) {
          width += 2; // 日文字符
        } else if (charCode >= 0xac00 && charCode <= 0xd7af) {
          width += 2; // 韓文字符
        } else {
          width += 1; // 英文字符、數字、標點
        }
      }
      return width;
    }

    function centerText(text, width = 48) {
      if (!text || text.trim().length === 0) return '';
      const processedText = processNewlines(text);
      const trimmedText = processedText.trim();
      const textWidth = getDisplayWidth(trimmedText);
      const padding = Math.max(0, Math.floor((width - textWidth) / 2));
      return ' '.repeat(padding) + trimmedText;
    }

    // 處理多行文本，每行分別居中
    function centerMultilineText(text, width = 48) {
      if (!text || text.trim().length === 0) return '';
      const processedText = processNewlines(text);
      const lines = processedText.split('\n');
      return lines.map(line => {
        const trimmedLine = line.trim();
        if (trimmedLine.length === 0) return ''; // 保留空行
        const textWidth = getDisplayWidth(trimmedLine);
        const padding = Math.max(0, Math.floor((width - textWidth) / 2));
        return ' '.repeat(padding) + trimmedLine;
      }).join('\n');
    }

    try {
      // 執行真實測試打印
      // 如果使用中文編碼，設置打印機編碼為GBK
      if (useChineseEncoding && printer.encoding) {
        printer.encoding = 'GBK';
      }
      printer.clear();
      printer.alignCenter();

      // LOGO打印（重新嘗試）
      if (config && config.show_logo === true && config.logo_base64 && config.logo_base64.length > 0) {
        console.log('LOGO打印已配置，嘗試打印LOGO...');
        console.log('LOGO base64數據長度:', config.logo_base64.length);

        try {
          // 檢查打印機是否支持圖片打印
          if (printer && typeof printer.printImageBase64 === 'function') {
            console.log('打印機支持printImageBase64方法，開始打印LOGO...');
            await printer.printImageBase64(config.logo_base64, config.logo_width || 48);
            console.log('LOGO打印命令已發送');
            printer.newLine(1); // 添加空行分隔，保持格式
          } else if (printer && printer.constructor && printer.constructor.name === 'RawPrinter') {
            // 如果是RawPrinter實例，即使沒有printImageBase64方法，也可以嘗試動態調用
            console.log('打印機是RawPrinter實例，但缺少printImageBase64方法');
            printer.newLine(1); // 添加空行分隔，保持格式
          } else {
            console.log('打印機不支持圖片打印，跳過LOGO');
            printer.newLine(1); // 添加空行分隔，保持格式
          }
        } catch (logoError) {
          console.error('LOGO打印失敗:', logoError.message);
          console.error('錯誤詳情:', logoError.stack);
          console.log('LOGO打印失敗，跳過LOGO繼續打印文本內容');
          printer.newLine(1); // 添加空行分隔，保持格式
        }
      }

      printer.alignLeft();

      // 逐行發送測試內容 - 不使用任何格式
      const lines = testContent.split('\n');
      lines.forEach(line => {
        printer.println(line);
      });

      // 有些打印機對cut命令敏感，改為幾行空白
      printer.println('');
      printer.println('');
      // printer.cut();

      const success = await printer.execute();

      if (!success) {
        throw new Error('打印機執行返回失敗');
      }

      res.json({
        success: true,
        message: '小票機測試成功，測試小票已發送',
        test_content: testContent,
        connection: connectionDetails,
        store_id: currentStoreId,
        status: 'tested',
        timestamp: new Date().toISOString(),
        printed: true
      });

    } catch (printError) {
      console.error('測試小票機打印錯誤:', printError);

      // 嘗試更簡單的測試
      try {
        printer.clear();
        printer.alignLeft();
        printer.println('測試');
        printer.cut();

        const simpleSuccess = await printer.execute();

        if (simpleSuccess) {
          res.json({
            success: true,
            message: '測試打印成功（簡單版本）',
            test_content: '測試\n（簡單測試）',
            connection: connectionDetails,
            store_id: currentStoreId,
            status: 'tested_simple',
            timestamp: new Date().toISOString(),
            printed: true,
            warning: '完整格式測試失敗，但基本打印功能正常'
          });
        } else {
          throw new Error('簡單測試也失敗');
        }
      } catch (simpleError) {
        res.status(500).json({
          error: '測試小票機失敗',
          message: `無法發送測試打印: ${printError.message}`,
          details: '請檢查打印機連接、電源和設置',
          connection: connectionDetails,
          store_id: currentStoreId,
          printed: false
        });
      }
    }

  } catch (error) {
    console.error('測試小票機錯誤:', error);
    res.status(500).json({
      error: '測試小票機失敗',
      message: error.message,
      store_id: req.storeContext?.store_id || 'default_store'
    });
  }
});

// 測試儲物柜
router.post('/test-locker', (req, res) => {
  try {
    res.json({
      success: true,
      message: '儲物柜測試成功'
    });
  } catch (error) {
    console.error('測試儲物柜錯誤:', error);
    res.status(500).json({
      error: '測試儲物柜失敗',
      message: error.message
    });
  }
});

// 重設儲物柜
router.post('/reset-locker', (req, res) => {
  try {
    res.json({
      success: true,
      message: '儲物柜已重設'
    });
  } catch (error) {
    console.error('重設儲物柜錯誤:', error);
    res.status(500).json({
      error: '重設儲物柜失敗',
      message: error.message
    });
  }
});

// 開啟門鎖
router.post('/open-doorlock', (req, res) => {
  try {
    res.json({
      success: true,
      message: '門鎖已開啟'
    });
  } catch (error) {
    console.error('開啟門鎖錯誤:', error);
    res.status(500).json({
      error: '開啟門鎖失敗',
      message: error.message
    });
  }
});

// 關閉門鎖
router.post('/close-doorlock', (req, res) => {
  try {
    res.json({
      success: true,
      message: '門鎖已關閉'
    });
  } catch (error) {
    console.error('關閉門鎖錯誤:', error);
    res.status(500).json({
      error: '關閉門鎖失敗',
      message: error.message
    });
  }
});

// 測試音響
router.post('/test-audio', (req, res) => {
  try {
    res.json({
      success: true,
      message: '音響測試成功'
    });
  } catch (error) {
    console.error('測試音響錯誤:', error);
    res.status(500).json({
      error: '測試音響失敗',
      message: error.message
    });
  }
});

// 停止音響
router.post('/stop-audio', (req, res) => {
  try {
    res.json({
      success: true,
      message: '音響已停止'
    });
  } catch (error) {
    console.error('停止音響錯誤:', error);
    res.status(500).json({
      error: '停止音響失敗',
      message: error.message
    });
  }
});

// 測試NFC讀卡器
router.post('/test-nfc', (req, res) => {
  try {
    res.json({
      success: true,
      message: 'NFC讀卡器測試成功'
    });
  } catch (error) {
    console.error('測試NFC讀卡器錯誤:', error);
    res.status(500).json({
      error: '測試NFC讀卡器失敗',
      message: error.message
    });
  }
});

// 重設NFC讀卡器
router.post('/reset-nfc', (req, res) => {
  try {
    res.json({
      success: true,
      message: 'NFC讀卡器已重設'
    });
  } catch (error) {
    console.error('重設NFC讀卡器錯誤:', error);
    res.status(500).json({
      error: '重設NFC讀卡器失敗',
      message: error.message
    });
  }
});

// 獲取客人QR Code資訊
router.get('/customer/:id/qr-code', (req, res) => {
  try {
    const { id } = req.params;

    db.db.get(
      `SELECT c.*, GROUP_CONCAT(l.locker_number) as lockers
       FROM customers c
       LEFT JOIN lockers l ON c.id = l.customer_id AND l.is_occupied = 1
       WHERE c.id = ?
       GROUP BY c.id`,
      [id],
      (err, customer) => {
        if (err) {
          console.error('獲取客人QR Code錯誤:', err);
          return res.status(500).json({ error: '獲取QR Code失敗', message: err.message });
        }

        if (!customer) {
          return res.status(404).json({ error: '客人不存在' });
        }

        const entryTime = new Date(customer.entry_time).toLocaleString('zh-TW', {
          hour: '2-digit',
          minute: '2-digit'
        });

        const qrText = customer.qr_code || `桌號: ${customer.table_number}, 入場時間: ${entryTime}`;

        // 生成QR Code圖片
        QRCode.toDataURL(qrText, {
          width: 200,
          height: 200,
          margin: 1,
          color: {
            dark: '#000000',
            light: '#ffffff'
          }
        }, (err, qrDataURL) => {
          if (err) {
            console.error('生成QR Code圖片錯誤:', err);
            console.error('QR Code文本內容:', qrText);
            // 如果生成失敗，返回原始文本
            res.json({
              success: true,
              qr_data: qrText,
              table_number: customer.table_number,
              entry_time: entryTime,
              lockers: customer.lockers || '無',
              qr_code: qrText
            });
          } else {
            console.log('QR Code生成成功，長度:', qrDataURL.length);
            // 返回base64格式的QR Code圖片
            res.json({
              success: true,
              qr_data: qrDataURL, // base64圖片格式
              table_number: customer.table_number,
              entry_time: entryTime,
              lockers: customer.lockers || '無',
              qr_code: qrText
            });
          }
        });
      }
    );
  } catch (error) {
    console.error('獲取客人QR Code錯誤:', error);
    res.status(500).json({
      error: '獲取QR Code失敗',
      message: error.message
    });
  }
});

// 重新打印QR Code小票
router.post('/customer/:id/reprint-qr', (req, res) => {
  try {
    const { id } = req.params;

    // 檢查客人是否存在
    db.db.get(
      `SELECT * FROM customers WHERE id = ?`,
      [id],
      (err, customer) => {
        if (err) {
          console.error('重新打印QR Code錯誤:', err);
          return res.status(500).json({ error: '重新打印失敗', message: err.message });
        }

        if (!customer) {
          return res.status(404).json({ error: '客人不存在' });
        }

        // 觸發打印事件（這裡可以調用打印機系統）
        const io = req.app.get('io');
        io.emit('device-control', {
          device: 'printer',
          action: 'reprint-qr',
          customer_id: id,
          qr_code: customer.qr_code,
          table_number: customer.table_number
        });

        res.json({
          success: true,
          message: 'QR Code小票已重新打印'
        });
      }
    );
  } catch (error) {
    console.error('重新打印QR Code錯誤:', error);
    res.status(500).json({
      error: '重新打印失敗',
      message: error.message
    });
  }
});

// 刪除客人（桌號）
router.delete('/customer/:id', authMiddleware.authenticate, (req, res) => {
  try {
    const { id } = req.params;

    // 檢查客人是否存在
    db.db.get(
      `SELECT * FROM customers WHERE id = ?`,
      [id],
      (err, customer) => {
        if (err) {
          console.error('刪除客人錯誤:', err);
          return res.status(500).json({ error: '刪除客人失敗', message: err.message });
        }

        if (!customer) {
          return res.status(404).json({ error: '客人不存在' });
        }

        // 先查詢客人的訂單項目（用於審計日誌）
        db.db.all(
          `SELECT oi.*, p.name as product_name, p.price FROM order_items oi
           LEFT JOIN products p ON oi.product_id = p.id
           WHERE oi.customer_id = ?`,
          [id],
          (err, orderItems) => {
            if (err) {
              console.error('查詢訂單項目錯誤:', err);
              return res.status(500).json({ error: '刪除客人失敗', message: err.message });
            }

            // 開始事務 - 使用序列化模式
            db.db.serialize(() => {
              // 1. 釋放儲物柜（保持customer_id以便歷史查詢）
              db.db.run(
                `UPDATE lockers SET is_occupied = 0 WHERE customer_id = ?`,
                [id],
                function(err) {
                  if (err) {
                    console.error('釋放儲物柜錯誤:', err);
                    throw err;
                  }
                  console.log(`已釋放 ${this.changes} 個儲物柜`);
                }
              );

              // 2. 釋放桌位
              db.db.run(
                `UPDATE tables SET is_occupied = 0, current_customer_id = NULL WHERE current_customer_id = ?`,
                [id],
                function(err) {
                  if (err) {
                    console.error('釋放桌位錯誤:', err);
                    throw err;
                  }
                  console.log(`已釋放桌位 ${customer.table_number}`);
                }
              );

              // 3. 刪除訂單項目
              db.db.run(
                `DELETE FROM order_items WHERE customer_id = ?`,
                [id],
                function(err) {
                  if (err) {
                    console.error('刪除訂單項目錯誤:', err);
                    throw err;
                  }
                  console.log(`已刪除 ${this.changes} 個訂單項目`);
                }
              );

              // 4. 刪除客人記錄
              db.db.run(
                `DELETE FROM customers WHERE id = ?`,
                [id],
                function(err) {
                  if (err) {
                    console.error('刪除客人錯誤:', err);
                    throw err;
                  }
                  console.log(`已刪除客人 ${customer.table_number}`);

                  // 觸發Socket事件通知客戶端更新
                  const io = req.app.get('io');
                  io.emit('customer-deleted', {
                    customer_id: id,
                    table_number: customer.table_number
                  });

                  // 記錄敏感操作審計日誌（刪桌）
                  try {
                    const employeeId = req.employee?.id || null;
                    const storeId = customer.store_id || 'default_store';
                    const ipAddress = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;

                    // 構建操作詳情（包含訂單項目）
                    const actionDetails = {
                      operation: 'delete_table',
                      customer_id: customer.id,
                      table_number: customer.table_number,
                      people_count: customer.people_count,
                      entry_time: customer.entry_time,
                      total_amount: customer.total_amount,
                      lockers_used: customer.lockers_used,
                      is_member: customer.is_member,
                      member_card_id: customer.member_card_id,
                      order_items: orderItems.map(item => ({
                        product_id: item.product_id,
                        product_name: item.product_name || '未知商品',
                        quantity: item.quantity,
                        price: item.price,
                        price_at_time: item.price_at_time,
                        purchased_at: item.purchased_at
                      }))
                    };

                    // 使用authMiddleware創建審計日誌
                    authMiddleware.createAuditLog(
                      employeeId,
                      'sensitive_delete_table',
                      JSON.stringify(actionDetails),
                      ipAddress,
                      storeId
                    );
                    console.log(`已記錄刪桌敏感操作審計日誌，桌號: ${customer.table_number}，包含 ${orderItems.length} 個訂單項目`);
                  } catch (auditError) {
                    console.error('記錄刪桌審計日誌時發生錯誤（但不影響操作）:', auditError);
                  }

                  res.json({
                    success: true,
                    message: '客人已刪除',
                    table_number: customer.table_number
                  });
                }
              );
            });
          }
        );
      }
    );
  } catch (error) {
    console.error('刪除客人錯誤:', error);
    res.status(500).json({
      error: '刪除客人失敗',
      message: error.message
    });
  }
});

// 調試路由：獲取最新客人
router.get('/debug/latest-customer', (req, res) => {
  try {
    db.db.get(
      `SELECT * FROM customers ORDER BY entry_time DESC LIMIT 1`,
      (err, row) => {
        if (err) {
          console.error('獲取最新客人錯誤:', err);
          return res.status(500).json({ error: '獲取最新客人失敗', message: err.message });
        }
        res.json({
          success: true,
          customer: row || null
        });
      }
    );
  } catch (error) {
    console.error('調試路由錯誤:', error);
    res.status(500).json({ error: '調試路由失敗', message: error.message });
  }
});

// 更新客人桌號
router.post('/update-table', (req, res) => {
  try {
    const { customer_id, table_number } = req.body;

    if (!customer_id || !table_number) {
      return res.status(400).json({
        error: '參數不完整',
        message: '請提供 customer_id 和 table_number'
      });
    }

    // 獲取當前顧客信息
    db.db.get(
      `SELECT id, store_id, table_number FROM customers WHERE id = ?`,
      [customer_id],
      (err, customer) => {
        if (err) {
          console.error('查詢顧客錯誤:', err);
          return res.status(500).json({ error: '查詢顧客失敗', message: err.message });
        }

        if (!customer) {
          return res.status(404).json({ error: '顧客不存在', message: '找不到指定的顧客' });
        }

        // 檢查新桌號是否已被其他顧客使用（同一家店內）
        db.db.get(
          `SELECT id FROM customers WHERE store_id = ? AND table_number = ? AND id != ? AND is_checked_out = 0`,
          [customer.store_id, table_number, customer_id],
          (err, existing) => {
            if (err) {
              console.error('檢查桌號錯誤:', err);
              return res.status(500).json({ error: '檢查桌號失敗', message: err.message });
            }

            if (existing) {
              return res.status(409).json({
                error: '桌號已存在',
                message: `桌號 ${table_number} 已被其他客人使用`
              });
            }

            // 更新顧客桌號
            db.db.run(
              `UPDATE customers SET table_number = ? WHERE id = ?`,
              [table_number, customer_id],
              function(err) {
                if (err) {
                  console.error('更新桌號錯誤:', err);
                  return res.status(500).json({ error: '更新桌號失敗', message: err.message });
                }

                console.log(`顧客 ${customer_id} 桌號更新: ${customer.table_number} → ${table_number}`);

                // 觸發Socket事件通知客戶端更新
                const io = req.app.get('io');
                io.emit('table-updated', {
                  customer_id: customer_id,
                  old_table_number: customer.table_number,
                  new_table_number: table_number
                });

                // 記錄審計日誌
                try {
                  const employeeId = req.employee?.id || null;
                  const storeId = customer.store_id || 'default_store';
                  const ipAddress = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;

                  const actionDetails = {
                    operation: 'update_table',
                    customer_id: customer.id,
                    old_table_number: customer.table_number,
                    new_table_number: table_number,
                    store_id: customer.store_id
                  };

                  authMiddleware.createAuditLog(
                    employeeId,
                    'update_table',
                    JSON.stringify(actionDetails),
                    ipAddress,
                    storeId
                  );
                  console.log(`已記錄換桌審計日誌，桌號: ${customer.table_number} → ${table_number}`);
                } catch (auditError) {
                  console.error('記錄換桌審計日誌時發生錯誤（但不影響操作）:', auditError);
                }

                res.json({
                  success: true,
                  message: '桌號更新成功',
                  old_table_number: customer.table_number,
                  new_table_number: table_number
                });
              }
            );
          }
        );
      }
    );
  } catch (error) {
    console.error('更新桌號路由錯誤:', error);
    res.status(500).json({
      error: '更新桌號失敗',
      message: error.message
    });
  }
});

// ==================== 打印機配置管理API ====================

// 獲取打印機配置列表（支持指定分店）
router.get('/printer-configs', (req, res) => {
  try {
    // 優先使用查詢參數中的store_id，否則使用storeContext
    const queryStoreId = req.query.store_id;
    const storeId = queryStoreId || req.storeContext?.store_id || 'default_store';
    const { include_all } = req.query;

    let query = `SELECT * FROM printer_configs WHERE store_id = ?`;
    const params = [storeId];

    // 如果請求包含所有分店（僅限管理員）
    if (include_all === 'true' && req.employee?.role === 'admin') {
      query = `SELECT * FROM printer_configs ORDER BY store_id, is_default DESC, created_at DESC`;
      params.length = 0;
    } else {
      query += ` ORDER BY is_default DESC, created_at DESC`;
    }

    db.db.all(query, params, (err, configs) => {
      if (err) {
        console.error('獲取打印機配置錯誤:', err);
        return res.status(500).json({
          success: false,
          error: '獲取配置失敗',
          message: err.message
        });
      }

      res.json({
        success: true,
        data: configs,
        store_id: storeId,
        requested_store_id: queryStoreId,
        count: configs.length
      });
    });
  } catch (error) {
    console.error('獲取打印機配置錯誤:', error);
    res.status(500).json({
      success: false,
      error: '獲取配置失敗',
      message: error.message
    });
  }
});

// 獲取單個打印機配置
router.get('/printer-configs/:id', (req, res) => {
  try {
    const { id } = req.params;
    const storeId = req.storeContext?.store_id || 'default_store';

    db.db.get(
      `SELECT * FROM printer_configs WHERE id = ? AND (store_id = ? OR ? = 'admin_all')`,
      [id, storeId, req.employee?.role === 'admin' ? 'admin_all' : storeId],
      (err, config) => {
        if (err) {
          console.error('獲取單個打印機配置錯誤:', err);
          return res.status(500).json({
            success: false,
            error: '獲取配置失敗',
            message: err.message
          });
        }

        if (!config) {
          return res.status(404).json({
            success: false,
            error: '配置不存在',
            message: '指定的打印機配置不存在或無權訪問'
          });
        }

        res.json({
          success: true,
          data: config
        });
      }
    );
  } catch (error) {
    console.error('獲取單個打印機配置錯誤:', error);
    res.status(500).json({
      success: false,
      error: '獲取配置失敗',
      message: error.message
    });
  }
});

// 創建打印機配置
router.post('/printer-configs', (req, res) => {
  try {
    const storeId = req.storeContext?.store_id || 'default_store';
    const {
      printer_name,
      connection_type,
      ip_address,
      port = 9100,
      bluetooth_address,
      printer_type = 'epson',
      is_default = false
    } = req.body;

    // 驗證必要字段
    if (!printer_name || !connection_type) {
      return res.status(400).json({
        success: false,
        error: '參數錯誤',
        message: '打印機名稱和連接類型為必填項'
      });
    }

    if (connection_type === 'wifi' && !ip_address) {
      return res.status(400).json({
        success: false,
        error: '參數錯誤',
        message: 'WiFi連接需要IP地址'
      });
    }

    if (connection_type === 'bluetooth' && !bluetooth_address) {
      return res.status(400).json({
        success: false,
        error: '參數錯誤',
        message: '藍牙連接需要藍牙地址'
      });
    }

    // 如果設為默認，先取消其他默認配置
    if (is_default) {
      db.db.run(
        `UPDATE printer_configs SET is_default = 0 WHERE store_id = ?`,
        [storeId],
        (err) => {
          if (err) console.error('重置默認配置錯誤:', err);
        }
      );
    }

    const id = uuidv4();
    const query = `
      INSERT INTO printer_configs (
        id, store_id, printer_name, connection_type,
        ip_address, port, bluetooth_address, printer_type,
        is_default, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `;

    const params = [
      id,
      storeId,
      printer_name,
      connection_type,
      connection_type === 'wifi' ? ip_address : null,
      connection_type === 'wifi' ? port : null,
      connection_type === 'bluetooth' ? bluetooth_address : null,
      printer_type,
      is_default ? 1 : 0
    ];

    db.db.run(query, params, function(err) {
      if (err) {
        console.error('創建打印機配置錯誤:', err);
        return res.status(500).json({
          success: false,
          error: '創建失敗',
          message: err.message
        });
      }

      res.status(201).json({
        success: true,
        data: {
          id,
          store_id: storeId,
          printer_name,
          connection_type,
          ip_address: connection_type === 'wifi' ? ip_address : null,
          port: connection_type === 'wifi' ? port : null,
          bluetooth_address: connection_type === 'bluetooth' ? bluetooth_address : null,
          printer_type,
          is_default: is_default ? 1 : 0,
          created_at: new Date().toISOString()
        },
        message: '打印機配置創建成功'
      });
    });
  } catch (error) {
    console.error('創建打印機配置錯誤:', error);
    res.status(500).json({
      success: false,
      error: '創建失敗',
      message: error.message
    });
  }
});

// 更新打印機配置
router.put('/printer-configs/:id', (req, res) => {
  try {
    const { id } = req.params;
    const storeId = req.storeContext?.store_id || 'default_store';
    const {
      printer_name,
      connection_type,
      ip_address,
      port,
      bluetooth_address,
      printer_type,
      is_default
    } = req.body;

    // 檢查配置是否存在
    db.db.get(
      `SELECT * FROM printer_configs WHERE id = ? AND store_id = ?`,
      [id, storeId],
      (err, existing) => {
        if (err) {
          console.error('檢查打印機配置錯誤:', err);
          return res.status(500).json({
            success: false,
            error: '檢查失敗',
            message: err.message
          });
        }

        if (!existing) {
          return res.status(404).json({
            success: false,
            error: '配置不存在',
            message: '指定的打印機配置不存在或無權訪問'
          });
        }

        // 如果設為默認，先取消其他默認配置
        if (is_default) {
          db.db.run(
            `UPDATE printer_configs SET is_default = 0 WHERE store_id = ? AND id != ?`,
            [storeId, id],
            (err) => {
              if (err) console.error('重置默認配置錯誤:', err);
            }
          );
        }

        // 構建更新語句
        const updates = [];
        const params = [];

        if (printer_name !== undefined) {
          updates.push('printer_name = ?');
          params.push(printer_name);
        }

        if (connection_type !== undefined) {
          updates.push('connection_type = ?');
          params.push(connection_type);

          // 根據連接類型清理無關字段
          if (connection_type === 'wifi') {
            updates.push('bluetooth_address = NULL');
          } else if (connection_type === 'bluetooth') {
            updates.push('ip_address = NULL, port = NULL');
          }
        }

        if (ip_address !== undefined && connection_type !== 'bluetooth') {
          updates.push('ip_address = ?');
          params.push(ip_address);
        }

        if (port !== undefined && connection_type !== 'bluetooth') {
          updates.push('port = ?');
          params.push(port);
        }

        if (bluetooth_address !== undefined && connection_type !== 'wifi') {
          updates.push('bluetooth_address = ?');
          params.push(bluetooth_address);
        }

        if (printer_type !== undefined) {
          updates.push('printer_type = ?');
          params.push(printer_type);
        }

        if (is_default !== undefined) {
          updates.push('is_default = ?');
          params.push(is_default ? 1 : 0);
        }

        updates.push('updated_at = datetime("now")');

        if (updates.length === 0) {
          return res.status(400).json({
            success: false,
            error: '參數錯誤',
            message: '沒有提供更新字段'
          });
        }

        params.push(id, storeId);

        const query = `UPDATE printer_configs SET ${updates.join(', ')} WHERE id = ? AND store_id = ?`;

        db.db.run(query, params, function(err) {
          if (err) {
            console.error('更新打印機配置錯誤:', err);
            return res.status(500).json({
              success: false,
              error: '更新失敗',
              message: err.message
            });
          }

          if (this.changes === 0) {
            return res.status(404).json({
              success: false,
              error: '配置不存在',
              message: '指定的打印機配置不存在或無權訪問'
            });
          }

          res.json({
            success: true,
            data: {
              id,
              store_id: storeId,
              printer_name: printer_name !== undefined ? printer_name : existing.printer_name,
              connection_type: connection_type !== undefined ? connection_type : existing.connection_type,
              ip_address: ip_address !== undefined ? ip_address : existing.ip_address,
              port: port !== undefined ? port : existing.port,
              bluetooth_address: bluetooth_address !== undefined ? bluetooth_address : existing.bluetooth_address,
              printer_type: printer_type !== undefined ? printer_type : existing.printer_type,
              is_default: is_default !== undefined ? (is_default ? 1 : 0) : existing.is_default
            },
            message: '打印機配置更新成功'
          });
        });
      }
    );
  } catch (error) {
    console.error('更新打印機配置錯誤:', error);
    res.status(500).json({
      success: false,
      error: '更新失敗',
      message: error.message
    });
  }
});

// 刪除打印機配置
router.delete('/printer-configs/:id', (req, res) => {
  try {
    const { id } = req.params;
    const storeId = req.storeContext?.store_id || 'default_store';

    // 檢查配置是否存在
    db.db.get(
      `SELECT is_default FROM printer_configs WHERE id = ? AND store_id = ?`,
      [id, storeId],
      (err, config) => {
        if (err) {
          console.error('檢查打印機配置錯誤:', err);
          return res.status(500).json({
            success: false,
            error: '檢查失敗',
            message: err.message
          });
        }

        if (!config) {
          return res.status(404).json({
            success: false,
            error: '配置不存在',
            message: '指定的打印機配置不存在或無權訪問'
          });
        }

        // 禁止刪除默認配置
        if (config.is_default) {
          return res.status(400).json({
            success: false,
            error: '禁止操作',
            message: '不能刪除默認配置'
          });
        }

        db.db.run(
          `DELETE FROM printer_configs WHERE id = ? AND store_id = ?`,
          [id, storeId],
          function(err) {
            if (err) {
              console.error('刪除打印機配置錯誤:', err);
              return res.status(500).json({
                success: false,
                error: '刪除失敗',
                message: err.message
              });
            }

            if (this.changes === 0) {
              return res.status(404).json({
                success: false,
                error: '配置不存在',
                message: '指定的打印機配置不存在或無權訪問'
              });
            }

            res.json({
              success: true,
              message: '打印機配置刪除成功'
            });
          }
        );
      }
    );
  } catch (error) {
    console.error('刪除打印機配置錯誤:', error);
    res.status(500).json({
      success: false,
      error: '刪除失敗',
      message: error.message
    });
  }
});

// 設為默認打印機配置
router.post('/printer-configs/:id/set-default', (req, res) => {
  try {
    const { id } = req.params;
    const storeId = req.storeContext?.store_id || 'default_store';

    // 檢查配置是否存在
    db.db.get(
      `SELECT * FROM printer_configs WHERE id = ? AND store_id = ?`,
      [id, storeId],
      (err, config) => {
        if (err) {
          console.error('檢查打印機配置錯誤:', err);
          return res.status(500).json({
            success: false,
            error: '檢查失敗',
            message: err.message
          });
        }

        if (!config) {
          return res.status(404).json({
            success: false,
            error: '配置不存在',
            message: '指定的打印機配置不存在或無權訪問'
          });
        }

        // 已經是最默認配置
        if (config.is_default) {
          return res.json({
            success: true,
            message: '此配置已經是默認配置',
            data: config
          });
        }

        // 開始事務：取消所有默認，設置新的默認
        db.db.serialize(() => {
          // 1. 取消所有默認配置
          db.db.run(
            `UPDATE printer_configs SET is_default = 0 WHERE store_id = ?`,
            [storeId],
            (err) => {
              if (err) {
                console.error('取消默認配置錯誤:', err);
                throw err;
              }
            }
          );

          // 2. 設置新的默認配置
          db.db.run(
            `UPDATE printer_configs SET is_default = 1, updated_at = datetime('now') WHERE id = ? AND store_id = ?`,
            [id, storeId],
            function(err) {
              if (err) {
                console.error('設置默認配置錯誤:', err);
                return res.status(500).json({
                  success: false,
                  error: '設置失敗',
                  message: err.message
                });
              }

              if (this.changes === 0) {
                return res.status(404).json({
                  success: false,
                  error: '配置不存在',
                  message: '指定的打印機配置不存在或無權訪問'
                });
              }

              res.json({
                success: true,
                message: '已設為默認打印機配置',
                data: {
                  id,
                  store_id: storeId,
                  is_default: 1
                }
              });
            }
          );
        });
      }
    );
  } catch (error) {
    console.error('設置默認打印機配置錯誤:', error);
    res.status(500).json({
      success: false,
      error: '設置失敗',
      message: error.message
    });
  }
});

// 測試特定配置的打印機連接
router.post('/printer-configs/:id/test-connection', async (req, res) => {
  try {
    const { id } = req.params;
    const storeId = req.storeContext?.store_id || 'default_store';

    // 獲取配置
    db.db.get(
      `SELECT * FROM printer_configs WHERE id = ? AND store_id = ?`,
      [id, storeId],
      async (err, config) => {
        if (err) {
          console.error('獲取打印機配置錯誤:', err);
          return res.status(500).json({
            success: false,
            error: '獲取配置失敗',
            message: err.message
          });
        }

        if (!config) {
          return res.status(404).json({
            success: false,
            error: '配置不存在',
            message: '指定的打印機配置不存在或無權訪問'
          });
        }

        // 根據配置創建打印機實例
        let printer = null;
        try {
          const selectedPrinterType = config.printer_type === 'star' ? PrinterTypes.STAR : PrinterTypes.EPSON;

          if (config.connection_type === 'wifi') {
            if (!config.ip_address) {
              return res.status(400).json({
                success: false,
                error: '配置錯誤',
                message: 'WiFi配置缺少IP地址'
              });
            }

            printer = new ThermalPrinter({
              type: selectedPrinterType,
              interface: `tcp://${config.ip_address}:${config.port || 9100}`,
              options: { timeout: 10000, encoding: 'GBK' }
            });
          } else if (config.connection_type === 'bluetooth') {
            if (!config.bluetooth_address) {
              return res.status(400).json({
                success: false,
                error: '配置錯誤',
                message: '藍牙配置缺少藍牙地址'
              });
            }

            printer = new ThermalPrinter({
              type: selectedPrinterType,
              interface: `bt://${config.bluetooth_address}`,
              options: { timeout: 10000 }
            });
          } else {
            return res.status(400).json({
              success: false,
              error: '配置錯誤',
              message: '不支持的連接類型'
            });
          }

          // 測試連接
          printer.clear();
          printer.alignCenter();
          printer.println(`連接測試: ${config.printer_name}`);
          printer.println(`分店: ${storeId}`);
          printer.cut();

          const success = await printer.execute();

          if (!success) {
            throw new Error('打印機執行返回失敗');
          }

          res.json({
            success: true,
            message: '打印機連接測試成功',
            config: config,
            store_id: storeId,
            printed: true
          });

        } catch (printError) {
          console.error('打印機連接測試錯誤:', printError);
          res.status(500).json({
            success: false,
            error: '連接測試失敗',
            message: `無法連接到打印機: ${printError.message}`,
            config: config,
            store_id: storeId,
            printed: false
          });
        }
      }
    );
  } catch (error) {
    console.error('測試打印機連接錯誤:', error);
    res.status(500).json({
      success: false,
      error: '測試失敗',
      message: error.message
    });
  }
});

// 獲取默認打印機配置
router.get('/printer-configs/default', (req, res) => {
  try {
    const storeId = req.storeContext?.store_id || 'default_store';

    db.db.get(
      `SELECT * FROM printer_configs WHERE store_id = ? AND is_default = 1 LIMIT 1`,
      [storeId],
      (err, config) => {
        if (err) {
          console.error('獲取默認打印機配置錯誤:', err);
          return res.status(500).json({
            success: false,
            error: '獲取失敗',
            message: err.message
          });
        }

        if (!config) {
          // 返回空而不是錯誤，因為可能沒有配置
          return res.json({
            success: true,
            data: null,
            message: '沒有默認打印機配置'
          });
        }

        res.json({
          success: true,
          data: config
        });
      }
    );
  } catch (error) {
    console.error('獲取默認打印機配置錯誤:', error);
    res.status(500).json({
      success: false,
      error: '獲取失敗',
      message: error.message
    });
  }
});

module.exports = router;