// 設置香港時區 (UTC+8)
process.env.TZ = 'Asia/Hong_Kong';

// 加載環境變量（支援多個路徑：CWD、~/、專案根目錄）
const path = require('path');
require('dotenv').config();
require('dotenv').config({ path: path.resolve(__dirname, '..', '..', '.env') });
require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

// 重啟觸發：環境變量更新

// 初始化檔案 Logger（攔截 console.log/error 輸出到 logs/ 目錄）
const Logger = require('./utils/logger');
const logger = new Logger({
  storeName: process.env.STORE_NAME || process.env.STORE_ID || 'unknown'
});

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const os = require('os');
const fs = require('fs');
const https = require('https');
const crypto = require('crypto');
const { createServer } = require('http');
const { Server } = require('socket.io');
const net = require('net');

// 全域異常處理
process.on('uncaughtException', (error) => {
    console.error('=== 未捕獲的異常 ===');
    console.error('錯誤:', error);
    console.error('堆疊:', error.stack);
    console.error('發生時間:', new Date().toISOString());
    console.error('=== 未捕獲的異常結束 ===');
    // 不退出進程，讓錯誤處理中間件處理
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('=== 未處理的 Promise 拒絕 ===');
    console.error('原因:', reason);
    console.error('Promise:', promise);
    console.error('發生時間:', new Date().toISOString());
    console.error('=== 未處理的 Promise 拒絕結束 ===');
});

// 優雅關閉：先 checkpoint WAL 再退出，避免資料遺失
function gracefulShutdown(signal) {
  console.log(`收到 ${signal} 信號，正在優雅關閉...`);
  const forceExit = setTimeout(() => {
    console.error('優雅關閉超時，強制退出');
    process.exit(1);
  }, 10000);

  try {
    db.db.run('PRAGMA wal_checkpoint(TRUNCATE)', (err) => {
      if (err) {
        console.error('WAL checkpoint 錯誤:', err.message);
      } else {
        console.log('WAL checkpoint 完成，資料已寫入主檔');
      }
      clearTimeout(forceExit);
      httpServer.close(() => {
        console.log('HTTP 伺服器已關閉');
        process.exit(0);
      });
    });
  } catch (error) {
    clearTimeout(forceExit);
    console.error('優雅關閉錯誤:', error);
    process.exit(1);
  }
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// 導入路由
const entryRoutes = require('./routes/entryRoutes');
const cashierRoutes = require('./routes/cashierRoutes');
const vendingRoutes = require('./routes/vendingRoutes');
const exitRoutes = require('./routes/exitRoutes');
const lockRoutes = require('./routes/lockRoutes');
const lockerRoutes = require('./routes/lockerRoutes');
const receiptRoutes = require('./routes/receiptRoutes');
const authRoutes = require('./routes/authRoutes');
const employeeRoutes = require('./routes/employeeRoutes');
const productRoutes = require('./routes/productRoutes');
const inventoryRoutes = require('./routes/inventoryRoutes');
const auditRoutes = require('./routes/auditRoutes');
const reportRoutes = require('./routes/reportRoutes');
const holidaysRoutes = require('./routes/holidaysRoutes');
const storeRoutes = require('./routes/storeRoutes');
const bookingRoutes = require('./routes/bookingRoutes');
const waitinglistRoutes = require('./routes/waitinglistRoutes');
const twilioRoutes = require('./routes/twilioRoutes');
const aliyunProxyRoutes = require('./routes/aliyunProxyRoutes');

// 導入數據庫
const db = require('../database/db');

// 導入結賬單據上傳服務
const BillUploadService = require('../bill-upload-service');

// 初始化應用
const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// 中間件
app.use(cors({
    origin: function(origin, callback) {
        // 允許的來源列表
        const allowedOrigins = [
            // 公網ECS服務器
            'http://47.239.121.13',

            // 本地開發環境（支持多端口）
            /^http:\/\/(localhost|127\.0\.0\.1)(?::\d+)?$/,
            'http://localhost:3000',
            'http://127.0.0.1:3000',
            'http://localhost:3001',
            'http://127.0.0.1:3001',
            'http://localhost:3002',
            'http://127.0.0.1:3002',

            // 局域網IP段（動態匹配，支持任意端口）
            /^http:\/\/192\.168\.\d+\.\d+(?::\d+)?$/,    // 192.168.x.x
            /^http:\/\/10\.\d+\.\d+\.\d+(?::\d+)?$/,     // 10.x.x.x
            /^http:\/\/172\.(1[6-9]|2[0-9]|3[0-1])\.\d+\.\d+(?::\d+)?$/, // 172.16.x.x - 172.31.x.x

            // 允許不帶端口的本地訪問（如直接IP訪問）
            /^http:\/\/(localhost|127\.0\.0\.1)$/,
            /^http:\/\/192\.168\.\d+\.\d+$/,
            /^http:\/\/10\.\d+\.\d+\.\d+$/,
            /^http:\/\/172\.(1[6-9]|2[0-9]|3[0-1])\.\d+\.\d+$/
        ];

        // 如果沒有origin（例如：直接服務器訪問、Postman等工具）
        if (!origin) {
            return callback(null, true);
        }

        // 檢查origin是否在允許列表中
        const isAllowed = allowedOrigins.some(pattern => {
            if (typeof pattern === 'string') {
                return pattern === origin;
            } else if (pattern instanceof RegExp) {
                return pattern.test(origin);
            }
            return false;
        });

        if (isAllowed) {
            callback(null, true);
        } else {
            console.warn('CORS阻止的來源:', origin);
            callback(new Error('CORS不允許的來源'));
        }
    },
    credentials: true,
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
    exposedHeaders: ['Set-Cookie']
}));
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.static(path.join(__dirname, '../public')));

// 客戶端靜態文件服務
app.use('/entry-machine', express.static(path.join(__dirname, '../client/entry-machine')));
app.use('/cashier', express.static(path.join(__dirname, '../client/cashier')));
app.use('/vending-machine', express.static(path.join(__dirname, '../client/vending-machine')));
app.use('/exit-machine', express.static(path.join(__dirname, '../client/exit-machine')));
app.use('/booking', express.static(path.join(__dirname, '../client/booking')));

// ===== 更新鎖中間件（更新期間阻擋 API 請求）=====
app.use((req, res, next) => {
    // 唔 block update-related endpoints 自己
    if (req.path.startsWith('/api/update/') || req.path === '/api/update-status' || req.path === '/health') {
        return next();
    }
    // check .updating flag file
    if (fs.existsSync(UPDATE_FLAG_FILE)) {
        const stat = fs.statSync(UPDATE_FLAG_FILE);
        const age = Date.now() - stat.mtimeMs;
        // 超過 30 分鐘視為 crash residue，自動清除
        if (age > UPDATE_TIMEOUT_MS) {
            try {
                fs.unlinkSync(UPDATE_FLAG_FILE);
                if (fs.existsSync(BACKUP_DONE_FLAG)) fs.unlinkSync(BACKUP_DONE_FLAG);
                if (fs.existsSync(CP_DONE_FLAG)) fs.unlinkSync(CP_DONE_FLAG);
                logUpdate('更新鎖過期自動清除 (crash residue)', 'WARN');
            } catch (_) {}
            return next();
        }
        return res.status(503).json({
            success: false,
            error: '系統更新中',
            message: '更新期間將不能使用收銀系統，請稍後再試'
        });
    }
    next();
});

// ─── 公開節假日 daytype 查詢 ───
app.get('/api/holidays/public/batch', (req, res) => {
    const { year, month } = req.query;
    // 從 DB holidays table 找出標記為節假日的日期（含 description 中的 daytype 標記）
    let query = `SELECT date, description FROM holidays WHERE 1=1`;
    const params = [];
    if (year) { query += ` AND strftime('%Y', date) = ?`; params.push(year); }
    if (month) { query += ` AND strftime('%m', date) = ?`; params.push(month.padStart(2, '0')); }
    query += ` ORDER BY date ASC`;
    db.db.all(query, params, (err, rows) => {
        if (err) return res.status(500).json({ success: false, error: err.message });
        // 建立日期→daytype 對照（從 description 欄位中提取 "daytype=X"）
        const daytypeOverride = {};
        (rows || []).forEach(r => {
            const m = (r.description || '').match(/daytype=([A-Z])/);
            if (m) daytypeOverride[r.date] = m[1];
        });
        const daytypeMap = {};
        // 產生該年所有日期
        const y = parseInt(year) || new Date().getFullYear();
        const startM = month ? parseInt(month) : 1;
        const endM = month ? parseInt(month) : 12;
        for (let m = startM; m <= endM; m++) {
            const daysInMonth = new Date(y, m, 0).getDate();
            for (let d = 1; d <= daysInMonth; d++) {
                const ds = y + '-' + String(m).padStart(2,'0') + '-' + String(d).padStart(2,'0');
                const dow = new Date(ds + 'T00:00+08:00').getDay();
                let daytype = '';
                if (daytypeOverride[ds]) daytype = daytypeOverride[ds];
                else if (dow === 0) daytype = 'U';
                else if (dow === 6) daytype = 'S';
                else if (dow === 5) daytype = 'F';
                daytypeMap[ds] = { daytype, is_holiday: (daytype === 'H' || daytype === 'S' || daytype === 'U' || daytype === 'B') ? 1 : 0 };
            }
        }
        res.json({ success: true, data: daytypeMap });
    });
});

// Socket.IO 連接處理
io.on('connection', (socket) => {
  console.log('客戶端連接:', socket.id);

  // 處理設備狀態更新
  socket.on('device-status', (data) => {
    // 廣播設備狀態給所有客戶端
    socket.broadcast.emit('device-update', data);
  });

  // 處理新客人通知
  socket.on('new-customer', (customerData) => {
    // 廣播新客人信息給收銀系統
    socket.broadcast.emit('customer-added', customerData);
  });

  // 處理結賬通知
  socket.on('checkout-complete', (tableData) => {
    // 廣結結賬信息給所有相關設備
    socket.broadcast.emit('table-checked-out', tableData);
  });

  socket.on('disconnect', () => {
    console.log('客戶端斷開:', socket.id);
  });
});

// 將io對象附加到app，方便路由使用
app.set('io', io);

// 路由
app.use('/api/entry', entryRoutes);
app.use('/api/cashier', cashierRoutes);
app.use('/api/vending', vendingRoutes);
app.use('/api/exit', exitRoutes);
app.use('/api/lock', lockRoutes);
app.use('/api/locker', lockerRoutes);
app.use('/api/receipt', receiptRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/employees', employeeRoutes);
app.use('/api/products', productRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/audit-logs', auditRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/holidays', holidaysRoutes);
app.use('/api/stores', storeRoutes);
app.use('/api/sync', require('./routes/syncRoutes'));
app.use('/api', require('./routes/reverseCheckoutRoutes'));
app.use('/api/self-service', require('./routes/selfServiceRoutes'));
app.use('/api/booking', bookingRoutes);
app.use('/api/waitinglist', waitinglistRoutes);
app.use('/api/twilio', twilioRoutes);
app.use('/api/aliyun-proxy', aliyunProxyRoutes);

// 客戶端界面路由
app.get('/entry-machine', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/entry-machine/index.html'));
});

app.get('/cashier', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/cashier/index.html'));
});

app.get('/vending-machine', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/vending-machine/index.html'));
});

app.get('/exit-machine', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/exit-machine/index.html'));
});

app.get('/booking', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/booking/index.html'));
});

// 主頁面
app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="zh-TW">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>自動咖啡館系統 - 控制面板</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        h1 { color: #333; }
        .dashboard { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-top: 30px; }
        .card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .card h2 { margin-top: 0; color: #444; }
        .card a { display: inline-block; margin-top: 10px; padding: 10px 15px; background: #4CAF50; color: white; text-decoration: none; border-radius: 5px; }
        .card a:hover { background: #45a049; }
      </style>
    </head>
    <body>
      <h1>自動咖啡館系統 - 控制面板</h1>
      <div class="dashboard">
        <div class="card">
          <h2>入場機器</h2>
          <p>客人入場處理界面</p>
          <a href="/entry-machine" target="_blank">打開入場機器</a>
        </div>
        <div class="card">
          <h2>收銀系統</h2>
          <p>員工收銀管理界面</p>
          <a href="/cashier" target="_blank">打開收銀系統</a>
        </div>
        <div class="card">
          <h2>商品售賣機</h2>
          <p>客人購買商品界面</p>
          <a href="/vending-machine" target="_blank">打開售賣機</a>
        </div>
        <div class="card">
          <h2>離場機器</h2>
          <p>客人結賬離場界面</p>
          <a href="/exit-machine" target="_blank">打開離場機器</a>
        </div>
      </div>
    </body>
    </html>
  `);
});

// 健康檢查端點
// 優雅關閉端點：更新 server code 前先呼叫此端點，避免 WAL 損壞
app.post('/api/shutdown', (req, res) => {
  console.log('收到 shutdown 請求，準備優雅關閉...');
  res.json({ success: true, message: '伺服器正在關閉...' });
  // 延遲一點讓 response 送出去
  setTimeout(() => gracefulShutdown('API'), 500);
});

app.get('/health', (req, res) => {
  const homeDir = path.resolve(__dirname, '..');
  const ver = readLocalVersion(homeDir) || process.env.SERVER_VERSION || '18';
  res.json({
    status: 'healthy',
    server_version: String(ver),
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage()
  });
});

// 錯誤處理中間件
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: '伺服器錯誤', message: err.message });
});

// 第二小時自動收費檢查
function startSecondHourScheduler() {
  // 每1分鐘檢查一次
  setInterval(async () => {
    try {
      const now = new Date();

      // 查詢所有未結賬的客人
      const customers = await new Promise((resolve, reject) => {
        db.db.all(
          `SELECT c.id, c.people_count, c.entry_time, c.store_id
           FROM customers c
           WHERE c.is_checked_out = 0`,
          (err, rows) => {
            if (err) reject(err);
            else resolve(rows);
          }
        );
      });

      for (const customer of customers) {
        try {
          // 計算在場時間（分鐘）
          const entryTime = new Date(customer.entry_time);
          const timeInMinutes = Math.floor((now.getTime() - entryTime.getTime()) / (1000 * 60));

          // 計算應有的次小時商品數量（按時間段累計）
          // 規則：69分鐘內不收次小時，70分鐘起每60分鐘收一次次小時
          let requiredSecondHourCount = 0;
          if (timeInMinutes >= 70) {
            // 公式：floor((總分鐘數 - 70) / 60) + 1
            requiredSecondHourCount = Math.floor((timeInMinutes - 70) / 60) + 1;
          }

          // 檢查是否已經有全日通，如果有則完全跳過自動收費
          const hasDayPass = await new Promise((resolve, reject) => {
            db.db.get(
              `SELECT 1 FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.customer_id = ? AND p.name LIKE '%全日通%'`,
              [customer.id],
              (err, row) => {
                if (err) reject(err);
                else resolve(!!row);
              }
            );
          });

          if (hasDayPass) {
            console.log(`客人 ${customer.id} 已有全日通商品，跳過次小時商品處理`);
            continue;
          }

          // 計算有效時段人數（首小時數量 - 套票減免數量）
          const hourCounts = await new Promise((resolve, reject) => {
            db.db.get(
              `SELECT
                COALESCE(SUM(CASE WHEN p.name LIKE '%首小時%' THEN oi.quantity ELSE 0 END), 0) as first_hour_qty,
                COALESCE(SUM(CASE WHEN p.name LIKE '%套票減免%' THEN oi.quantity ELSE 0 END), 0) as discount_qty
               FROM order_items oi
               JOIN products p ON oi.product_id = p.id
               WHERE oi.customer_id = ?`,
              [customer.id],
              (err, row) => {
                if (err) reject(err);
                else resolve(row);
              }
            );
          });

          const effectiveCount = hourCounts.first_hour_qty - hourCounts.discount_qty;
          if (effectiveCount <= 0) {
            console.log(`客人 ${customer.id} 套票減免已覆蓋所有時段 (首小時=${hourCounts.first_hour_qty}, 套票減免=${hourCounts.discount_qty})`);
            continue;
          }

          if (requiredSecondHourCount > 0) {
            // 需要次小時商品，進行處理

            // 查詢現有的次小時商品數量
            const existingSecondHourCount = await new Promise((resolve, reject) => {
              db.db.get(
                `SELECT COUNT(*) as count
                 FROM order_items oi
                 JOIN products p ON oi.product_id = p.id
                 WHERE oi.customer_id = ?
                 AND p.name LIKE '%次小時%'`,
                [customer.id],
                (err, row) => {
                  if (err) reject(err);
                  else resolve(row ? row.count : 0);
                }
              );
            });

            // 計算需要添加的次小時商品數量
            const countToAdd = requiredSecondHourCount - existingSecondHourCount;
            if (countToAdd > 0) {
              // 需要添加次小時商品

              // 獲取當前有效的次小時商品
              const secondHourProduct = await db.getValidHourProduct('次小時', now, customer.store_id);
              if (secondHourProduct) {
                // 添加缺失的次小時商品（使用有效人數）
                await db.addOrderItem(customer.id, secondHourProduct.id, effectiveCount * countToAdd, secondHourProduct.price);
                console.log(`已為客人 ${customer.id} 添加 ${effectiveCount * countToAdd} 個次小時商品 (${countToAdd}小時): ${secondHourProduct.name}`);

                // 觸發 Socket 事件通知前端更新
                io.emit('order-updated', {
                  customer_id: customer.id,
                  product_name: secondHourProduct.name,
                  quantity: effectiveCount * countToAdd,
                  store_id: customer.store_id
                });
              }
            }

            // 檢查是否需要轉換為全日通
            try {
              // 檢查是否已經有全日通（再次確認，防止併發問題）
              const hasDayPassAgain = await new Promise((resolve, reject) => {
                db.db.get(
                  `SELECT 1 FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.customer_id = ? AND p.name LIKE '%全日通%'`,
                  [customer.id],
                  (err, row) => {
                    if (err) reject(err);
                    else resolve(!!row);
                  }
                );
              });

              if (!hasDayPassAgain) {
                // 查詢首小時單價和次小時總額
                const hourPriceData = await new Promise((resolve, reject) => {
                  db.db.get(
                    `SELECT
                      SUM(CASE WHEN p.name LIKE '%首小時%' THEN oi.quantity * oi.price_at_time ELSE 0 END) as first_hour_total,
                      SUM(CASE WHEN p.name LIKE '%首小時%' THEN oi.quantity ELSE 0 END) as first_hour_qty,
                      SUM(CASE WHEN p.name LIKE '%次小時%' THEN oi.quantity * oi.price_at_time ELSE 0 END) as second_hour_total
                     FROM order_items oi
                     JOIN products p ON oi.product_id = p.id
                     WHERE oi.customer_id = ?
                     AND (p.name LIKE '%首小時%' OR p.name LIKE '%次小時%')`,
                    [customer.id],
                    (err, row) => {
                      if (err) reject(err);
                      else resolve(row);
                    }
                  );
                });

                // 計算調整後的總價：次小時總額 + 有效人數 × 首小時單價
                const firstHourUnitPrice = hourPriceData.first_hour_qty > 0
                  ? hourPriceData.first_hour_total / hourPriceData.first_hour_qty
                  : 0;
                const adjustedTotalPrice = (hourPriceData.second_hour_total || 0) + (effectiveCount * firstHourUnitPrice);
                const perPersonPrice = effectiveCount > 0 ? adjustedTotalPrice / effectiveCount : 0;

                // 獲取當前有效的全日通商品
                const dayPassProduct = await db.getValidDayPassProduct(now, customer.store_id);
                if (dayPassProduct && perPersonPrice > dayPassProduct.price) {
                  // 移除所有首小時和次小時商品
                  const removalResult = await db.removeHourProducts(customer.id);
                  console.log(`已為客人 ${customer.id} 移除 ${removalResult.removedCount} 個時段商品，總金額 ${removalResult.totalAmount}`);

                  // 添加全日通商品（使用有效人數）
                  await db.addOrderItem(customer.id, dayPassProduct.id, effectiveCount, dayPassProduct.price);
                  console.log(`已為客人 ${customer.id} 添加全日通商品: ${dayPassProduct.name} x ${effectiveCount}`);

                  // 觸發 Socket 事件通知前端更新
                  io.emit('order-updated', {
                    customer_id: customer.id,
                    product_name: dayPassProduct.name,
                    quantity: effectiveCount,
                    store_id: customer.store_id
                  });
                }
              }
            } catch (error) {
              console.error(`為客人 ${customer.id} 檢查全日通時發生錯誤:`, error);
            }
          }
        } catch (error) {
          console.error(`為客人 ${customer.id} 處理次小時商品時發生錯誤:`, error);
        }
      }
    } catch (error) {
      console.error('第二小時檢查任務錯誤:', error);
    }
  }, 1 * 60 * 1000); // 1分鐘
}

/**
 * 入口打印機健康檢查 (192.168.3.120:9100)
 * 每30秒檢查一次，透過 socket.io 廣播狀態
 */
function startEntryPrinterHealthCheck(ioInstance) {
  const ENTRY_PRINTER_IP = '192.168.3.120';
  const ENTRY_PRINTER_PORT = 9100;

  function check() {
    const sock = new net.Socket();
    sock.setTimeout(5000);

    sock.on('connect', () => {
      sock.destroy();
      ioInstance.emit('device-update', { device: 'entry-printer', status: 'online' });
    });

    sock.on('error', () => {
      sock.destroy();
      ioInstance.emit('device-update', { device: 'entry-printer', status: 'offline' });
    });

    sock.on('timeout', () => {
      sock.destroy();
      ioInstance.emit('device-update', { device: 'entry-printer', status: 'offline' });
    });

    sock.connect(ENTRY_PRINTER_PORT, ENTRY_PRINTER_IP);
  }

  check();
  setInterval(check, 30000);
  console.log('[entry-printer] printer health check started (192.168.3.120:9100, every 30s)');
}

// 獲取本機IP地址
function getLocalIpAddresses() {
    const interfaces = os.networkInterfaces();
    const addresses = [];

    for (const interfaceName in interfaces) {
        for (const iface of interfaces[interfaceName]) {
            // 跳過IPv6和內部地址
            if (iface.family === 'IPv4' && !iface.internal) {
                addresses.push({
                    address: iface.address,
                    interface: interfaceName,
                    mac: iface.mac
                });
            }
        }
    }

    return addresses;
}

// 啟動服務器
const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0'; // 監聽所有網絡接口

httpServer.listen({ port: PORT, host: HOST, reuseAddress: true }, () => {
    const localIpAddresses = getLocalIpAddresses();

    console.log('='.repeat(60));
    console.log(`自動咖啡館系統服務器已啟動`);
    console.log('='.repeat(60));

    console.log(`\n📡 服務器監聽: ${HOST}:${PORT}`);
    console.log(`🏠 本地訪問: http://localhost:${PORT}`);

    if (localIpAddresses.length > 0) {
        console.log('\n🌐 局域網訪問地址:');
        localIpAddresses.forEach((ipInfo, index) => {
            console.log(`   ${index + 1}. http://${ipInfo.address}:${PORT} (${ipInfo.interface})`);
        });
    } else {
        console.log('\n⚠️  未檢測到局域網IP地址，請檢查網絡連接');
    }

    console.log('\n🔗 系統界面:');
    console.log(`   • 控制面板: http://localhost:${PORT}`);
    console.log(`   • 入場機器: http://localhost:${PORT}/entry-machine`);
    console.log(`   • 收銀系統: http://localhost:${PORT}/cashier`);
    console.log(`   • 商品售賣機: http://localhost:${PORT}/vending-machine`);
    console.log(`   • 離場機器: http://localhost:${PORT}/exit-machine`);

    // 顯示局域網訪問URL（使用第一個檢測到的IP）
    if (localIpAddresses.length > 0) {
        const primaryIp = localIpAddresses[0].address;
        console.log(`\n🖥️  主服務器地址（供客戶端連接）: ${primaryIp}:${PORT}`);
        console.log(`   🔗 收銀系統: http://${primaryIp}:${PORT}/cashier`);
    }

    console.log('\n' + '='.repeat(60));

    startSecondHourScheduler();

    // 啟動入口打印機健康檢查
    startEntryPrinterHealthCheck(io);

    // 啟動員工名單同步排程（每天香港時間 3:00 AM 從 Google Sheet 同步）
    try {
        const employeeSheetSync = require('./utils/employeeSheetSync');
        employeeSheetSync.startEmployeeSyncSchedule();
        console.log('✅ 員工名單同步排程已啟動（每天 3:00 AM 香港時間）');
    } catch (error) {
        console.error('啟動員工名單同步排程失敗:', error);
    }

    // 啟動結賬單據自動上傳服務（僅在主機模式下）
    try {
        const hostRole = process.env.HOST_ROLE || 'master'; // master 或 client
        console.log('📋 主機角色檢查:', { HOST_ROLE: hostRole, STORE_ID: process.env.STORE_ID, ALIYUN_SERVER: process.env.ALIYUN_SERVER ? '已設置' : '未設置' });
        if (hostRole === 'master') {
            const uploadService = new BillUploadService();
            uploadService.start();
            console.log('✅ 結賬單據自動上傳服務已啟動（主機模式）');
        } else {
            console.log('⏭️  分機模式：跳過結賬單據自動上傳服務');
        }
    } catch (error) {
        console.error('❌ 啟動結賬單據上傳服務失敗:', error);
        console.log('⚠️  結賬單據上傳功能將不可用，請手動啟動 bill-upload-service.js');
    }

});

// ============================================================
// 伺服器自動更新機制（Self-Update）
// 定時檢查 GitHub 上的最新版本，自動下載、驗證、更新、重啟
//
// 使用 curl 取代 https.get()：Termux 的 curl 使用系統憑證，
// 而 Node.js 內建 https 在 Termux 上可能因憑證問題失敗
// ============================================================

const UPDATE_CHECK_INTERVAL = 60 * 60 * 1000; // 1 小時
const UPDATE_JSON_URL = 'https://raw.githubusercontent.com/albertleego/apk_release/main/latest-version.json';
const UPDATE_LOG_PATH = path.join(__dirname, '..', 'logs', 'update.log');
const UPDATE_TIMEOUT_MS = 30 * 60 * 1000; // 30 分鐘更新超時
const HOME_DIR = path.resolve(__dirname, '..');
const UPDATE_FLAG_FILE = path.join(HOME_DIR, '.updating');
const BACKUP_DONE_FLAG = path.join(HOME_DIR, '.backup_done');
const CP_DONE_FLAG = path.join(HOME_DIR, '.cp_done');
let _isUpdating = false;
let _lastUpdateVer = 0;      // 本地版本（從 .server_version 讀取，更新時一併更新以正確暴露）
let _lastUpdateCheck = null; // 最後檢查時間
let _lastUpdateError = null; // 最後錯誤訊息

// 確保 logs 目錄存在
try {
    const logDir = path.dirname(UPDATE_LOG_PATH);
    if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });
} catch (_) {}

// 專用更新日誌（獨立於 console，確保可追蹤）
function logUpdate(msg, level = 'INFO') {
    const ts = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const line = `[${ts}][${level}] ${msg}`;
    console.log(line);
    try { fs.appendFileSync(UPDATE_LOG_PATH, line + '\n'); } catch (_) {}
}

// 使用 fetch（優先）或 curl 抓 JSON
async function fetchJsonViaCurl(url) {
    // 先試 Node 內置 fetch (Node 18+)
    if (typeof fetch === 'function') {
        try {
            const ac = new AbortController();
            const timer = setTimeout(() => ac.abort(), 15000);
            const resp = await fetch(url, { signal: ac.signal });
            clearTimeout(timer);
            if (resp.ok) return await resp.json();
        } catch (_) {}
    }
    // 再用 https 模組
    try {
        return await new Promise((resolve, reject) => {
            const u = new URL(url);
            const mod = u.protocol === 'https:' ? require('https') : require('http');
            mod.get(url, { timeout: 15000 }, (res) => {
                let data = '';
                res.on('data', (chunk) => data += chunk);
                res.on('end', () => {
                    try { resolve(JSON.parse(data)); } catch (e) { reject(e); }
                });
            }).on('error', reject).on('timeout', function() { this.destroy(); reject(new Error('timeout')); });
        });
    } catch (_) {}
    // 最後用 curl（Termux 場合）
    const stdout = await execPromise(`curl -sL --connect-timeout 10 '${url}'`, { timeout: 30000 });
    if (!stdout) throw new Error('curl 回傳空內容');
    return JSON.parse(stdout);
}

// 使用 fetch（優先）或 curl 下載檔案
async function downloadFileViaCurl(url, dest) {
    // 先試 Node 18+ 內置 fetch
    if (typeof fetch === 'function') {
        try {
            const resp = await fetch(url, { signal: AbortSignal.timeout(60000) });
            if (resp.ok) {
                const buf = Buffer.from(await resp.arrayBuffer());
                fs.writeFileSync(dest, buf);
                return;
            }
        } catch (_) {}
    }
    // 再用 curl
    await execPromise(`curl -sL --connect-timeout 10 '${url}' -o '${dest}'`, { timeout: 120000 });
    if (!fs.existsSync(dest) || fs.statSync(dest).size === 0) {
        throw new Error(`下載失敗或檔案為空: ${url}`);
    }
}

// 工具函數：exec Promise 包裝（含 stdout/stderr 合併輸出）
function execPromise(cmd, opts = {}) {
    const { exec } = require('child_process');
    return new Promise((resolve, reject) => {
        exec(cmd, { timeout: 120000, ...opts }, (err, stdout, stderr) => {
            if (err) {
                const detail = (stdout || '') + (stderr || '');
                err.message += `\n[cmd] ${cmd}\n[output] ${detail.substring(0, 500)}`;
                reject(err);
            } else {
                resolve(stdout || '');
            }
        });
    });
}

// 讀取 .server_version
function readLocalVersion(homeDir) {
    const versionFile = path.join(homeDir, '.server_version');
    try {
        return parseInt(fs.readFileSync(versionFile, 'utf8').trim(), 10) || 0;
    } catch (_) {
        return 0;
    }
}

// 讀取本地 APK 版本
function readLocalApkVersion(homeDir) {
    const apkFile = path.join(homeDir, '.apk_version');
    try {
        const raw = fs.readFileSync(apkFile, 'utf8').trim();
        // 可能是數字或 "1.64" 格式
        return raw;
    } catch (_) {
        return '';
    }
}

// 核心：檢查並執行更新（支援從指定 URL 下載，用於手動推送）
async function checkSelfUpdate(reason = 'scheduled', overrideUrl = null, force = false) {
    if (_isUpdating) {
        logUpdate(`已有更新進行中，跳過 (${reason})`);
        return;
    }

    // 只在香港時間 00:00-08:00 執行實際下載更新（避免白天重啟中斷服務）
    // 但版本檢測不受限制，以便 log 記錄新版本已可用
    const hkHour = (new Date().getUTCHours() + 8) % 24;
    const inUpdateWindow = hkHour >= 0 && hkHour < 8;

    _isUpdating = true;
    _lastUpdateError = null;

    const homeDir = path.resolve(__dirname, '..');

    try {
        // 讀取本地版本
        _lastUpdateVer = readLocalVersion(homeDir);
        const localVer = _lastUpdateVer;

        // 從 GitHub 取得最新版本資訊
        logUpdate(`檢查更新 (local=${localVer}, reason=${reason})`);
        const jsonUrl = overrideUrl || UPDATE_JSON_URL;
        const remote = await fetchJsonViaCurl(jsonUrl);
        const remoteVer = remote.server_version;
        if (!remoteVer || remoteVer <= localVer) {
            logUpdate(`已是最新 (local=${localVer}, remote=${remoteVer})`);
            _lastUpdateCheck = new Date().toISOString();
            return;
        }

        logUpdate(`發現新版本 v${remoteVer} (目前 v${localVer})，來源: ${reason}`);

        if (!inUpdateWindow && !force) {
            logUpdate(`非更新時段 (HKT ${hkHour}:00)，排程至 00:00-08:00 執行`);
            _lastUpdateCheck = new Date().toISOString();
            return;
        }

        if (force) {
            logUpdate('強制更新模式，跳過時段限制');
        }

        // ─── flag file: 開始更新 ───
        fs.writeFileSync(UPDATE_FLAG_FILE, String(Date.now()));

        // 下載 server zip
        const zipUrl = remote.server_zip_url;
        const zipPath = path.join(homeDir, 'update.zip');
        logUpdate(`下載中: ${zipUrl}`);
        await downloadFileViaCurl(zipUrl, zipPath);
        logUpdate(`下載完成 (${fs.statSync(zipPath).size} bytes)`);

        // 驗證 MD5
        const buf = fs.readFileSync(zipPath);
        const md5 = crypto.createHash('md5').update(buf).digest('hex');
        if (md5 !== remote.server_zip_md5) {
            throw new Error(`MD5 不符: 預期 ${remote.server_zip_md5}，實際 ${md5}`);
        }
        logUpdate('MD5 驗證通過');

        // 備份目前程式碼
        const backupFile = path.join(homeDir, `backup-v${localVer}.tgz`);
        logUpdate(`備份中: ${backupFile}`);
        await execPromise(
            `tar czf '${backupFile}' --exclude='database/*.db*' server/ client/ database/ scripts/ package.json package-lock.json 2>/dev/null`,
            { cwd: homeDir }
        );
        logUpdate('備份完成');
        fs.writeFileSync(BACKUP_DONE_FLAG, String(Date.now())); // backup 完成

        // 解壓到暫存目錄
        const stagingDir = path.join(homeDir, '.staging');
        if (fs.existsSync(stagingDir)) fs.rmSync(stagingDir, { recursive: true });
        fs.mkdirSync(stagingDir);

        logUpdate('解壓中...');
        await execPromise(
            `unzip -o '${zipPath}' -d '${stagingDir}' -x 'node_modules/*' 'database/*.db*' 'logs/*'`,
            { cwd: homeDir }
        );
        logUpdate('解壓完成，搬移檔案中...');

        // 搬移到 home 目錄（含隱藏檔）
        await execPromise(`cp -r '${stagingDir}'/. '${homeDir}'`);
        logUpdate('搬移完成');
        fs.writeFileSync(CP_DONE_FLAG, String(Date.now())); // cp 完成

        // 清理暫存
        fs.rmSync(stagingDir, { recursive: true });
        fs.unlinkSync(zipPath);
        logUpdate('暫存已清理');

        // npm install
        try {
            logUpdate('執行 npm install...');
            const npmOut = await execPromise('npm install --production 2>&1', { cwd: homeDir });
            logUpdate(`npm install 完成 (${npmOut.substring(0, 200)})`);
        } catch (e) {
            logUpdate(`npm install 警告: ${e.message}`, 'WARN');
        }

        // 清除 flag files
        try {
            if (fs.existsSync(UPDATE_FLAG_FILE)) fs.unlinkSync(UPDATE_FLAG_FILE);
            if (fs.existsSync(BACKUP_DONE_FLAG)) fs.unlinkSync(BACKUP_DONE_FLAG);
            if (fs.existsSync(CP_DONE_FLAG)) fs.unlinkSync(CP_DONE_FLAG);
        } catch (_) {}

        // 寫入新版本號
        fs.writeFileSync(path.join(homeDir, '.server_version'), String(remoteVer));
        _lastUpdateVer = remoteVer;
        _lastUpdateCheck = new Date().toISOString();
        logUpdate(`更新至 v${remoteVer} 完成，準備重啟...`);

        // 重啟：cd 到上一層（~/.env 所在目錄），確保 dotenv 能找到 STORE_ID
        const userRoot = path.resolve(homeDir, '..');
        const serverEntry = path.join(homeDir, 'server/index.js');
        const restartCmd = `cd '${userRoot}' && nohup node '${serverEntry}' >> '${UPDATE_LOG_PATH}' 2>&1 &`;
        await execPromise(restartCmd);
        logUpdate('新實例已啟動，退出目前行程');
        process.exit(0);
    } catch (error) {
        _lastUpdateError = `${error.message}\n${error.stack}`;
        logUpdate(`更新失敗: ${error.message}`, 'ERROR');
        logUpdate(`完整錯誤: ${error.stack}`, 'ERROR');

        // 嘗試回滾
        try {
            if (reason === 'startup') {
                logUpdate('啟動時更新失敗，跳過回滾（保留當前資料庫）');
                return;
            }
            const files = fs.readdirSync(homeDir).filter(f => f.startsWith('backup-v') && f.endsWith('.tgz'));
            if (files.length > 0) {
                const latest = files.sort().pop();
                logUpdate(`嘗試回滾: ${latest}`);
                const dbBackupPath = path.join(homeDir, 'database/cafe.db.pre-rollback');
                try { fs.copyFileSync(path.join(homeDir, 'database/cafe.db'), dbBackupPath); } catch (e) {}
                await execPromise(`tar xzf '${path.join(homeDir, latest)}' --exclude='database/*.db*' -C '${homeDir}'`, { cwd: homeDir });
                logUpdate('回滾完成');
            }
        } catch (rbError) {
            logUpdate(`回滾也失敗: ${rbError.message}`, 'ERROR');
        }
    } finally {
        _isUpdating = false;
        // 清除 flag files
        try {
            if (fs.existsSync(UPDATE_FLAG_FILE)) fs.unlinkSync(UPDATE_FLAG_FILE);
            if (fs.existsSync(BACKUP_DONE_FLAG)) fs.unlinkSync(BACKUP_DONE_FLAG);
            if (fs.existsSync(CP_DONE_FLAG)) fs.unlinkSync(CP_DONE_FLAG);
        } catch (_) {}
    }
}

// 啟動後 10 秒檢查一次
setTimeout(() => {
    // 先檢查上次更新是否 crash（有 .updating + .backup_done 但冇 .cp_done）
    if (fs.existsSync(UPDATE_FLAG_FILE) && fs.existsSync(BACKUP_DONE_FLAG) && !fs.existsSync(CP_DONE_FLAG)) {
        logUpdate('偵測到上次更新未完成（cp 中斷），啟動回滾', 'WARN');
        try {
            const files = fs.readdirSync(HOME_DIR).filter(f => f.startsWith('backup-v') && f.endsWith('.tgz'));
            if (files.length > 0) {
                const latest = files.sort().pop();
                logUpdate(`回滾: ${latest}`);
                require('child_process').execSync(`tar xzf '${path.join(HOME_DIR, latest)}' --exclude='database/*.db*' -C '${HOME_DIR}'`, { cwd: HOME_DIR });
                logUpdate('回滾完成');
            }
        } catch (rbError) {
            logUpdate(`回滾也失敗: ${rbError.message}`, 'ERROR');
        }
        // 清除 flag files
        try {
            if (fs.existsSync(UPDATE_FLAG_FILE)) fs.unlinkSync(UPDATE_FLAG_FILE);
            if (fs.existsSync(BACKUP_DONE_FLAG)) fs.unlinkSync(BACKUP_DONE_FLAG);
            if (fs.existsSync(CP_DONE_FLAG)) fs.unlinkSync(CP_DONE_FLAG);
        } catch (_) {}
    }
    checkSelfUpdate('startup');
}, 10000);

// 定時檢查（每 15 分鐘）
setInterval(() => checkSelfUpdate('interval'), UPDATE_CHECK_INTERVAL);

// APK 敲門 endpoint：提示伺服器立刻檢查更新（fire-and-forget）
app.post('/api/check-update', (req, res) => {
    logUpdate('收到 APK 觸發檢查（跳過時段限制）');
    checkSelfUpdate('apk-trigger', null, true);
    res.json({ status: 'ok', message: 'Update check queued' });
});

// ─── 新 API: 查詢版本和更新可用性（不下載）───
app.get('/api/update/check-available', async (req, res) => {
    try {
        const localVer = readLocalVersion(HOME_DIR);
        const hkHour = (new Date().getUTCHours() + 8) % 24;
        const inManualWindow = hkHour >= 22 || hkHour < 11;
        let remoteVer = 0;
        let hasUpdate = false;
        let remoteData = null;

        try {
            const remote = await fetchJsonViaCurl(UPDATE_JSON_URL);
            remoteVer = remote.server_version || 0;
            hasUpdate = remoteVer > localVer;
            remoteData = remote;
        } catch (fetchErr) {
            logUpdate(`check-available fetch 失敗: ${fetchErr.message}`, 'WARN');
        }

        // APK 版本
        const localApkVerStr = readLocalApkVersion(HOME_DIR);
        const remoteApkVer = remoteData ? (remoteData.version || '') : '';
        const apkHasUpdate = !!(remoteApkVer && localApkVerStr && remoteApkVer !== localApkVerStr);

        // 查阿里雲 HOT FIX 狀態（本地機房共用同一旗標）
        let hotFixEnabled = false;
        try {
            const hfResp = await fetch('http://47.239.121.13:3000/api/update/hot-fix', { signal: AbortSignal.timeout(3000) });
            if (hfResp.ok) {
                const hfData = await hfResp.json();
                hotFixEnabled = hfData.success && hfData.hot_fix_enabled === true;
            }
        } catch (_) {}

        res.json({
            success: true,
            data: {
                local_ver: localVer,
                remote_ver: remoteVer,
                has_update: hasUpdate,
                in_manual_window: inManualWindow,
                is_updating: _isUpdating || fs.existsSync(UPDATE_FLAG_FILE),
                manual_window_label: '22:10 - 11:10',
                hot_fix_enabled: hotFixEnabled,
                apk_local_ver: localApkVerStr || 'N/A',
                apk_remote_ver: remoteApkVer || 'N/A',
                apk_has_update: apkHasUpdate,
                remote_info: remoteData ? {
                    server_zip_url: remoteData.server_zip_url,
                    release_date: remoteData.release_date
                } : null,
                recent_log: (() => {
                    try {
                        if (fs.existsSync(UPDATE_LOG_PATH)) {
                            const c = fs.readFileSync(UPDATE_LOG_PATH, 'utf8');
                            return c.trim().split('\n').slice(-5).join('\n');
                        }
                    } catch (_) {}
                    return '';
                })()
            }
        });
    } catch (err) {
        res.json({ success: false, error: err.message });
    }
});

// ─── 新 API: 手動觸發更新 ───
app.post('/api/update/trigger', async (req, res) => {
    const hkHour = (new Date().getUTCHours() + 8) % 24;
    const inManualWindow = hkHour >= 22 || hkHour < 11;

    if (_isUpdating || fs.existsSync(UPDATE_FLAG_FILE)) {
        return res.json({ success: false, error: '已有更新進行中' });
    }

    // 如果 client 傳入 hot_fix=true，查阿里雲確認後跳過時段限制
    let hotFixBypass = false;
    if (req.body && req.body.hot_fix === true) {
        try {
            const hfResp = await fetch('http://47.239.121.13:3000/api/update/hot-fix', { signal: AbortSignal.timeout(3000) });
            if (hfResp.ok) {
                const hfData = await hfResp.json();
                hotFixBypass = hfData.success && hfData.hot_fix_enabled === true;
            }
        } catch (_) {}
    }

    if (!inManualWindow && !hotFixBypass) {
        return res.json({ success: false, error: '請於香港時間 22:10 - 11:10 之間進行更新' });
    }

    logUpdate('收到前端手動觸發更新' + (hotFixBypass ? ' (Hot Fix bypass)' : ''));
    // fire-and-forget but timeout enforced
    checkSelfUpdate('manual-trigger', null, true);

    res.json({ success: true, message: '更新已開始，需時約 1-20 分鐘' });
});

// 查詢更新狀態（增強版）
app.get('/api/update-status', (req, res) => {
    const currentVer = readLocalVersion(HOME_DIR);
    const updateLogExists = fs.existsSync(UPDATE_LOG_PATH);
    let recentLog = '';
    try {
        if (updateLogExists) {
            const content = fs.readFileSync(UPDATE_LOG_PATH, 'utf8');
            const lines = content.trim().split('\n');
            recentLog = lines.slice(-20).join('\n');
        }
    } catch (_) {}

    res.json({
        server_version: currentVer,
        is_updating: _isUpdating || fs.existsSync(UPDATE_FLAG_FILE),
        last_check: _lastUpdateCheck,
        last_error: _lastUpdateError,
        has_log: updateLogExists,
        recent_log: recentLog
    });
});

// ─── API: 讀取/設定 HOT FIX 狀態（僅阿里雲有此功能）───
// 本地版不需要此路由

module.exports = { app, io };