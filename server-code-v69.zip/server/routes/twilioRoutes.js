const express = require('express');
const router = express.Router();
const { db } = require('../../database/db');

/**
 * @route GET /api/twilio/respond
 * @desc 用戶 Click WhatsApp URL Button → 直接更新 DB status
 * @access Public
 * URL: /api/twilio/respond?action=confirm&id=xxx-xxx-xxx
 *       /api/twilio/respond?action=cancel&id=xxx-xxx-xxx
 */
router.get('/respond', (req, res) => {
    const action = req.query.action || '';
    const waitinglistId = req.query.id || '';

    const targetStatus = action === 'cancel' ? 'cancelled' : 'confirmed';
    const label = action === 'cancel' ? '取消' : '確認';

    const STORE_PHONES = {
        'store_1': '53635287',
        'store_2': '55884627',
        'store_3': '54450336',
        'store_4': '84028472'
    };
    const STORE_NAMES = { 'store_1': '荃灣店', 'store_2': '尖沙咀店', 'store_3': '旺角店', 'store_4': '銅鑼灣店' };

    function sendPage(title, message, icon) {
        res.send(`<!DOCTYPE html>
<html lang="zh-TW">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>${title} - Auto Cafe</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:-apple-system,'Noto Sans TC',sans-serif;background:#f5f5f5;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px;}
.card{background:white;border-radius:16px;box-shadow:0 2px 12px rgba(0,0,0,.1);padding:40px 30px;text-align:center;max-width:420px;width:100%;}
.icon{font-size:64px;margin-bottom:16px;}
h1{font-size:24px;color:#333;margin-bottom:8px;}
p{font-size:17px;color:#888;margin-bottom:6px;line-height:1.6;}
a.tel{display:inline-block;margin:10px 0;padding:10px 24px;background:#E8F5E9;color:#2E7D32;border-radius:10px;font-size:22px;font-weight:700;text-decoration:none;border:2px solid #A5D6A7;}
.btn{display:inline-block;margin-top:16px;padding:12px 32px;border:none;border-radius:10px;background:#8B4513;color:white;font-size:18px;font-weight:600;cursor:pointer;text-decoration:none;}
</style>
</head>
<body>
<div class="card">
<div class="icon">${icon}</div>
<h1>${title}</h1>
<p>${message}</p>
<a class="btn" href="/booking/">返回首頁</a>
</div>
</body>
</html>`);
    }

    function showConfirmPage(storeId) {
        const storePhone = STORE_PHONES[storeId] || '53635287';
        sendPage(
            '已確認留位！',
            `座位保留10分鐘<br>如未能於10分鐘內到店，請致電<br><a class="tel" href="tel:+852${storePhone}">${storePhone}</a>`,
            '✅'
        );
    }

    function showCancelPage() {
        sendPage('已取消留位', '我哋已經收到你嘅取消。<br>下次有機會再為你服務！😊', '✅');
    }

    if (!waitinglistId) {
        return sendPage('連結無效', '請確保使用完整嘅連結', '❌');
    }

    db.get(`SELECT id, store_id, status FROM waitinglist WHERE id = ?`, [waitinglistId], (err, item) => {
        if (err) {
            console.error('twilio/respond DB 錯誤:', err.message);
            return sendPage('系統錯誤', '請稍後再試', '⚠️');
        }
        if (!item) {
            console.log(`twilio/respond: 找不到 id ${waitinglistId} 的候位記錄`);
            return sendPage(
                label === '確認' ? '未能確認留位' : '未能取消留位',
                '找不到對應嘅候位記錄，可能已經處理過。<br>如有疑問請致電店舖查詢。',
                '🔍'
            );
        }

        const nowHK = new Date(Date.now() + 8*60*60*1000).toISOString().replace('Z', '');
        db.run(
            `UPDATE waitinglist SET status = ?, updated_at = ? WHERE id = ?`,
            [targetStatus, nowHK, item.id],
            function(updateErr) {
                if (updateErr) {
                    console.error('twilio/respond 更新錯誤:', updateErr.message);
                    return sendPage('更新失敗', '請稍後再試', '⚠️');
                }

                console.log(`twilio/respond: 候位 ${item.id} (${item.store_id}) → ${targetStatus}`);

                if (targetStatus === 'confirmed') {
                    showConfirmPage(item.store_id);
                } else {
                    showCancelPage();
                }
            }
        );
    });
});

/**
 * @route POST /api/twilio/whatsapp-callback
 * @desc 接收 WhatsApp 按鈕回調（備用 webhook 方式）
 * @access Public (Twilio webhook)
 */
router.post('/whatsapp-callback', (req, res) => {
    try {
        const from = req.body.From || '';
        const buttonResult = req.body.ButtonResult || '';
        const body = (req.body.Body || '').toLowerCase();

        console.log(`Twilio webhook: From=${from}, ButtonResult=${buttonResult}, Body=${body}`);

        const phone = from.replace('whatsapp:', '').replace('+', '').replace(/[^0-9]/g, '');
        const phoneWithPrefix = '+' + phone;

        if (!phone) {
            return res.status(200).send('<Response></Response>');
        }

        let targetStatus = null;
        if (buttonResult === 'Confirm' || body.includes('confirm')) targetStatus = 'confirmed';
        else if (buttonResult === 'Cancel' || body.includes('cancel')) targetStatus = 'cancelled';

        if (!targetStatus) {
            return res.status(200).send('<Response></Response>');
        }

        const todayHK = new Date(Date.now() + 8*60*60*1000).toISOString().slice(0,10);
        const query = `SELECT id, store_id, status FROM waitinglist
            WHERE (phone = ? OR phone = ?)
            AND status IN ('waiting', 'contacted', 'confirmed')
            AND created_at LIKE ?
            ORDER BY created_at DESC LIMIT 1`;

        db.get(query, [phoneWithPrefix, phone, todayHK + '%'], (err, item) => {
            if (err || !item) {
                return res.status(200).send('<Response></Response>');
            }
            const nowHK = new Date(Date.now() + 8*60*60*1000).toISOString().replace('Z', '');
            db.run(`UPDATE waitinglist SET status = ?, updated_at = ? WHERE id = ?`,
                [targetStatus, nowHK, item.id]);
        });

        res.status(200).send('<Response></Response>');
    } catch (error) {
        console.error('Twilio webhook 錯誤:', error);
        res.status(200).send('<Response></Response>');
    }
});

module.exports = router;
