// 從URL參數自動設定角色（APK主機/分機模式傳入）
(function() {
    const params = new URLSearchParams(window.location.search);
    const mode = params.get('mode');
    if (mode === 'host') {
        localStorage.setItem('hostRole', 'master');
    } else if (mode === 'client') {
        localStorage.setItem('hostRole', 'client');
        const host = params.get('host');
        const port = params.get('port') || '3000';
        if (host) {
            // 儲存 IP:PORT 格式，讓 testMasterConnection 能正確連接
            localStorage.setItem('masterServerIp', host + ':' + port);
        }
    }
})();

// 自動為同源 API 請求附加 Authorization header，確保 session 自動續期
(function() {
    const originalFetch = window.fetch;
    window.fetch = function(url, options = {}) {
        options = options || {};
        // 只對同源 API 請求附加 token
        if (typeof url === 'string' && url.startsWith('/api/')) {
            let token = localStorage.getItem('cashier_token');
            if (!token) {
                try { if (window.cashierSystem && window.cashierSystem.currentToken) token = window.cashierSystem.currentToken; } catch(e) {}
            }
            if (token) {
                options.headers = options.headers || {};
                if (!options.headers['Authorization']) {
                    options.headers['Authorization'] = 'Bearer ' + token;
                }
            }
        }
        return originalFetch.call(this, url, options);
    };
})();

// 增強收銀系統 - 包含身份驗證和標籤頁功能
class EnhancedCashierSystem extends CashierSystem {
    constructor() {
        super();
        console.log('EnhancedCashierSystem constructor called');
        this.currentEmployee = null;
        this.currentToken = null;
        this.tokenExpiresAt = null;
        this.currentTab = 'dashboard';
        this.isAuthenticated = false;
        this.rememberMe = false;
        // 清除所有保存的登入信息，強制重新登入（暫時註釋以測試登入持久性）
        // this.clearAllLoginStorage();
        this.showAuthenticatedUIRetryCount = 0; // 防止無限重試
        this.hasShownStoreLoadWarning = false; // 防止重複顯示分店加載警告
        this._historicalControlsClickHandler = null; // 歷史銷售控制容器點擊事件處理器
        this.isCheckingOut = false; // 防雙擊標誌
        this._eventsBound = false; // 事件綁定標誌，防止重複綁定
        this._addingTable = false; // 防止新增桌號重複執行
        this._sessionSubTables = new Set(); // 追蹤本次 session 已使用過的子桌號（避免重複編號）
        // 合單結賬模式狀態
        this.isMergeMode = false;
        this.mergeCustomerIds = new Set();
        this._mergeCheckoutData = null;
        this._mergeCaptureHandler = null;
        this._mergeCancelHandler = null;
        this._parentEventsBound = false; // 防止父類事件重複綁定
        this.isSuperInitializing = false; // 標記父類初始化期間
        this._initialized = false; // 標記是否已經初始化
        this._syncModalShown = false; // 標記同步進度條是否已顯示
        this._employeeTableEventHandler = null; // 員工表格事件處理器引用
        this._employeeTableEventsBound = false; // 員工表格事件是否已綁定
        this._deletingEmployee = false; // 防止員工刪除操作重複執行
        this._masterReconnectInterval = null; // 主服務器自動重連間隔
        this._sensitiveUploadTimer = null; // 敏感操作定時上傳
        this.masterConnectionStatus = 'unknown'; // 主服務器連接狀態: 'connected', 'disconnected', 'error', 'unknown'
        this.machineMasterConnectionStatus = 'unknown'; // 機器主服務器連接狀態
        this._printerRetryCount = 0; // 小票機重試次數
        this._printerRetryTimer = null; // 小票機重試定時器
        this._printerAutoConnectAttempted = false; // 標記是否已嘗試自動連接

        // 新的小票機連接管理器狀態變量
        this._printerConnecting = false; // 防止並行連接嘗試
        this._printerConnectionAbortController = null; // 用於取消fetch請求
        this._printerLastAttemptTime = 0; // 上次嘗試時間戳
        this._printerMaxRetries = 3; // 最大重試次數
        this._printerRetryDelay = 180000; // 重試延遲（3分鐘），單位：毫秒

        // 重寫父類的分店管理方法，確保使用覆蓋的版本
        this.saveStore = this.saveStore.bind(this);
        this.loadStoreForEdit = this.loadStoreForEdit.bind(this);
        this.clearStoreForm = this.clearStoreForm.bind(this);

        // 保存事件處理器引用以便正確移除
        this.storeFormSubmitHandler = (e) => this.saveStore(e);

        // 替換全局 cashierSystem 實例（如果存在）
        if (window.cashierSystem) {
            console.log('替換全局 cashierSystem 實例為 EnhancedCashierSystem');
            window.cashierSystem = this;
        }

        // 保存全局增強實例引用
        window.enhancedCashierSystem = this;
        console.log('保存全局增強實例引用到 window.enhancedCashierSystem');

        // 覆蓋父類的原型方法，確保所有實例都使用增強版本
        if (CashierSystem && CashierSystem.prototype) {
            console.log('重寫CashierSystem原型方法');
            const originalSaveStore = CashierSystem.prototype.saveStore;
            CashierSystem.prototype.saveStore = async function(event) {
                console.log('重寫的saveStore被調用，檢查是否是EnhancedCashierSystem實例');
                // 如果是EnhancedCashierSystem實例，調用增強版本
                if (this instanceof EnhancedCashierSystem && typeof this.saveStore === 'function') {
                    console.log('調用EnhancedCashierSystem.saveStore');
                    return this.saveStore(event);
                }
                // 如果全局增強實例存在，調用它的saveStore方法
                if (window.enhancedCashierSystem && typeof window.enhancedCashierSystem.saveStore === 'function') {
                    console.log('調用全局增強實例的saveStore');
                    return window.enhancedCashierSystem.saveStore(event);
                }
                // 否則調用原始版本
                console.log('調用原始CashierSystem.saveStore');
                return originalSaveStore.call(this, event);
            };
        }
        // 商品管理狀態
        this.productsList = [];
        this.filteredProducts = [];
        this.productCategories = [];
        this.products = []; // 父類商品數組，用於向後兼容
        this.productFilters = {
            search: '',
            category: '',
            stock: ''
        };
        this.productPagination = {
            currentPage: 1,
            itemsPerPage: 1000, // 設置為大數以顯示所有商品
            totalItems: 0,
            totalPages: 1
        };
        // 審計日誌狀態
        this.auditLogsPage = 1;
        this.auditLogsFilters = {
            action_type: '',
            start_date: '',
            end_date: ''
        };
        // 歷史銷售狀態
        this.historicalSalesPage = 1;
        this.historicalSalesFilters = {
            start_date: '',
            end_date: '',
            view_type: 'summary'
        };

        // 節假日管理狀態
        this.holidaysList = [];
        this.holidaysYearFilter = new Date().getFullYear().toString();
        this.holidaysMonthFilter = '';
        // 模擬數據設置
        // 從本地存儲讀取設置，如果沒有則使用默認值
        const savedShowMockData = localStorage.getItem('cashier_showMockData');
        this.showMockData = savedShowMockData !== null ? savedShowMockData === 'true' : false; // 顯示模擬桌號數據
        const savedAlwaysShowMockData = localStorage.getItem('cashier_alwaysShowMockData');
        this.alwaysShowMockData = savedAlwaysShowMockData !== null ? savedAlwaysShowMockData === 'true' : false; // 總是顯示模擬數據（即使有真實數據）
        this.mockCustomers = [];

        // 購物車狀態
        this.shoppingCart = [];
        this.cartTotalItems = 0;
        this.cartTotalAmount = 0;

        // 商品操作選擇模式狀態
        this.productSelectionMode = false;
        this.selectedProductId = null;

        // 清空操作狀態
        this.isClearingAllCustomers = false;

        // 掛單操作狀態
        this.isPendingSuspend = false;

        // 儲物柜管理狀態
        this.lockersList = [];
        this.lockerFilters = {
            status: '',
            search: ''
        };
        this.lockerStats = {
            total: 0,
            occupied: 0,
            available: 0,
            usage: 0
        };
        // 事件處理器引用，避免重複綁定
        this.lockerGridEventHandler = null;

        // 加單功能狀態
        this.addOrderTargetCustomer = null;
    }

    /**
     * 顯示同步進度條模態框
     */
    showSyncProgressModal() {
        console.log('showSyncProgressModal() called');
        this._syncModalShown = true;
        const modal = document.getElementById('sync-progress-modal');
        if (modal) {
            console.log('Found sync-progress-modal element, removing hidden class');
            console.log('Modal has hidden class?', modal.classList.contains('hidden'));
            modal.classList.remove('hidden');
            console.log('After removal, has hidden class?', modal.classList.contains('hidden'));
            // 重置進度條
            document.getElementById('sync-progress-fill').style.width = '0%';
            document.getElementById('sync-progress-text').textContent = '0%';
            // 重置狀態
            const statusElements = [
                'sync-products-status',
                'sync-employees-status',
                'sync-stores-status',
                'sync-templates-status',
                'sync-holidays-status'
            ];
            statusElements.forEach(id => {
                const el = document.getElementById(id);
                if (el) {
                    el.textContent = '等待中...';
                    el.className = 'detail-status waiting';
                }
            });
            // 隱藏錯誤和重試按鈕
            document.getElementById('sync-error-message').style.display = 'none';
            document.getElementById('sync-retry-btn').style.display = 'none';

            // 確保登入模態框在同步期間是隱藏的
            const loginModal = document.getElementById('login-modal');
            if (loginModal) {
                console.log('同步期間隱藏登入模態框');
                loginModal.classList.add('hidden');
            }
        }
    }

    /**
     * 隱藏同步進度條模態框
     */
    hideSyncProgressModal() {
        console.log('hideSyncProgressModal() called');
        this._syncModalShown = false;
        const modal = document.getElementById('sync-progress-modal');
        if (modal) {
            console.log('Found sync-progress-modal element, adding hidden class');
            console.log('Modal has hidden class before?', modal.classList.contains('hidden'));
            modal.classList.add('hidden');
            console.log('After addition, has hidden class?', modal.classList.contains('hidden'));
        }
    }

    /**
     * 更新同步進度
     * @param {number} percentage 進度百分比 (0-100)
     * @param {string} statusText 狀態文本
     */
    updateSyncProgress(percentage, statusText = '') {
        const fill = document.getElementById('sync-progress-fill');
        const text = document.getElementById('sync-progress-text');
        if (fill) {
            fill.style.width = `${percentage}%`;
        }
        if (text) {
            text.textContent = `${Math.round(percentage)}%`;
            if (statusText) {
                text.textContent += ` - ${statusText}`;
            }
        }
    }

    /**
     * 更新單個數據類型的同步狀態
     * @param {string} type 數據類型: 'products', 'employees', 'stores', 'templates', 'holidays'
     * @param {string} status 狀態: 'waiting', 'loading', 'success', 'error'
     * @param {string} message 狀態消息
     */
    updateSyncStatus(type, status, message = '') {
        const elementId = `sync-${type}-status`;
        const element = document.getElementById(elementId);
        if (element) {
            element.textContent = message || this.getStatusText(status);
            element.className = `detail-status ${status}`;
        }
    }

    /**
     * 獲取狀態文本
     * @param {string} status 狀態
     * @returns {string} 狀態文本
     */
    getStatusText(status) {
        const texts = {
            'waiting': '等待中...',
            'loading': '同步中...',
            'success': '同步成功',
            'error': '同步失敗'
        };
        return texts[status] || status;
    }

    /**
     * 顯示同步錯誤
     * @param {string} errorMessage 錯誤消息
     */
    showSyncError(errorMessage) {
        const errorElement = document.getElementById('sync-error-message');
        const errorText = document.getElementById('sync-error-text');
        const retryBtn = document.getElementById('sync-retry-btn');
        if (errorElement && errorText) {
            errorText.textContent = errorMessage;
            errorElement.style.display = 'flex';
        }
        if (retryBtn) {
            retryBtn.style.display = 'inline-block';
            // 綁定重試事件（如果尚未綁定）
            retryBtn.onclick = () => this.syncMasterData();
        }
    }

    /**
     * 從中央服務器同步主數據
     * @returns {Promise<boolean>} 同步是否成功
     */
    async syncMasterData() {
        console.log('syncMasterData() called');
        // 只在進度條未顯示時才顯示它
        if (!this._syncModalShown) {
            console.log('Calling showSyncProgressModal()...');
            this.showSyncProgressModal();
        } else {
            console.log('進度條已顯示，跳過 showSyncProgressModal()');
        }
        const startTime = Date.now();

        try {
            // 更新總體進度
            console.log('updateSyncProgress');
            this.updateSyncProgress(10, '開始同步...');

            // 發送同步請求
            console.log('執行call /api/sync/master-data');
            const response = await this.fetchWithAuth('/api/sync/master-data', {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                credentials: 'include'
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.message || '同步失敗');
            }

            // 返回一個Promise，等待所有動畫完成
            return new Promise((resolve) => {
                // 更新各數據類型狀態
                const dataTypes = [
                    { key: 'products', label: '商品' },
                    { key: 'employees', label: '員工' },
                    { key: 'stores', label: '分店' },
                    { key: 'templates', label: '小票模板' },
                    { key: 'holidays', label: '節假日' }
                ];

                let completedCount = 0;
                dataTypes.forEach((type, index) => {
                    setTimeout(() => {
                        // 模擬進度更新
                        const progress = 20 + (index * 15);
                        this.updateSyncProgress(progress, `同步${type.label}...`);

                        // 檢查該數據類型是否成功
                        const count = result.counts?.[type.key] || 0;
                        const hasData = count > 0;
                        const hasError = result.errors?.some(err => err.includes(type.label)) || false;

                        if (hasError) {
                            this.updateSyncStatus(type.key, 'error', `同步失敗`);
                        } else if (hasData) {
                            this.updateSyncStatus(type.key, 'success', `已同步 ${count} 條`);
                            completedCount++;
                        } else {
                            this.updateSyncStatus(type.key, 'success', '無數據');
                            completedCount++;
                        }

                        // 如果所有數據類型都處理完成，更新總進度
                        if (index === dataTypes.length - 1) {
                            const finalProgress = 95;
                            this.updateSyncProgress(finalProgress, '同步完成');

                            // 稍等片刻後隱藏進度條，確保至少顯示3秒
                            const minDisplayTime = 3000;
                            const elapsed = Date.now() - startTime;
                            const remainingTime = Math.max(0, minDisplayTime - elapsed);

                            setTimeout(() => {
                                this.updateSyncProgress(100, '同步完成');
                                setTimeout(() => {
                                    this.hideSyncProgressModal();
                                    console.log('主數據同步成功，進度條已隱藏:', result);
                                    resolve(true);
                                }, 500);
                            }, remainingTime + 500);
                        }
                    }, index * 300); // 延遲顯示每個數據類型的進度
                });
            });

        } catch (error) {
            console.error('同步主數據失敗:', error);
            this.updateSyncProgress(0, '同步失敗');
            this.showSyncError(`同步失敗: ${error.message}`);

            // 在錯誤情況下，也需要等待一段時間再隱藏進度條，以便用戶看到錯誤信息
            const minDisplayTime = 3000;
            const elapsed = Date.now() - startTime;
            const remainingTime = Math.max(0, minDisplayTime - elapsed);

            setTimeout(() => {
                this.hideSyncProgressModal();
            }, remainingTime + 1000);

            return false;
        }
    }

    async init() {
        console.log('EnhancedCashierSystem.init called');

        // 防止重複初始化
        if (this._initialized) {
            console.log('EnhancedCashierSystem 已經初始化，跳過');
            return;
        }

        // 先執行父類初始化
        console.log('Calling super.init()...');
        this.isSuperInitializing = true; // 標記父類初始化期間
        try {
            // 設置超時，防止父類初始化卡住
            const initTimeout = 10000; // 10秒超時
            const timeoutPromise = new Promise((_, reject) => {
                setTimeout(() => reject(new Error(`父類初始化超時 (${initTimeout}ms)`)), initTimeout);
            });

            await Promise.race([super.init(), timeoutPromise]);
            console.log('super.init() completed');
        } catch (error) {
            console.error('super.init() failed:', error.message);
            console.error('錯誤堆棧:', error.stack);
            console.warn('父類初始化失敗，繼續執行增強初始化...');
        } finally {
            this.isSuperInitializing = false; // 清除標記
            console.log('父類初始化完成，isSuperInitializing設置為false');
        }

        // 系統啟動時不進行同步，等待用戶登入後再同步

        // 綁定事件（清理重複監聽器並重新綁定）
        this.bindEvents();

        // 綁定增強事件
        this.bindEnhancedEvents();

        // 重新綁定分店管理事件，確保使用覆蓋的方法
        this.setupStoreManagementEvents();

        // 檢查本地存儲中的登入狀態
        const hasSavedLogin = this.checkSavedLogin();

        // 根據登入狀態處理登入模態框
        if (this.isAuthenticated) {
            // 已登入，隱藏登入模態框
            this.hideLoginModal();

            // 登入後同步主數據（顯示進度條）
            console.log('開始登入後數據同步...');
            this.showSyncProgressModal();
            this.updateSyncProgress(5, '同步數據中...');
            const syncStartTime = Date.now();
            try {
                // 設置同步超時（30秒）
                console.log('Calling syncMasterData()...');
                const syncPromise = this.syncMasterData();
                console.log('syncMasterData() called, setting up timeout...');
                const timeoutPromise = new Promise((_, reject) => {
                    setTimeout(() => reject(new Error('同步超時 (30秒)')), 30000);
                });

                // 等待同步完成或超時
                console.log('Waiting for sync or timeout...');
                await Promise.race([syncPromise, timeoutPromise]);
                console.log('登入後數據同步完成');
            } catch (error) {
                console.warn('登入後數據同步失敗，繼續使用本地數據:', error.message);
                // 同步失敗不阻止系統啟動，但記錄錯誤
                // 進度條模態框會顯示錯誤信息，用戶可以手動重試
                // 確保用戶有足夠時間看到錯誤信息（至少2秒）
                const errorDisplayTime = 2000;
                const elapsed = Date.now() - syncStartTime;
                const remainingTime = Math.max(0, errorDisplayTime - elapsed);
                if (remainingTime > 0) {
                    console.log(`等待 ${remainingTime}ms 以確保用戶看到錯誤信息`);
                    await new Promise(resolve => setTimeout(resolve, remainingTime));
                }
            }

            // 確保進度條至少顯示3秒（僅在成功情況下）
            const minDisplayTime = 3000;
            const elapsed = Date.now() - syncStartTime;
            if (elapsed < minDisplayTime) {
                console.log(`等待 ${minDisplayTime - elapsed}ms 以確保進度條顯示`);
                await new Promise(resolve => setTimeout(resolve, minDisplayTime - elapsed));
            }

            // 最終檢查：確保同步進度條已隱藏
            if (this._syncModalShown) {
                console.log('同步完成但進度條仍未隱藏，強制隱藏它');
                this.hideSyncProgressModal();
                // 添加一個小延遲以確保DOM更新
                await new Promise(resolve => setTimeout(resolve, 100));
            }

            // 加載可訪問分店（重要：必須在初始化標籤頁之前）
            console.log(`init: 用戶已登入，準備加載分店列表。isAuthenticated=${this.isAuthenticated}, currentEmployee=${!!this.currentEmployee}, employee.role=${this.currentEmployee?.role}`);
            try {
                await this.loadAccessibleStores();
                console.log('已登入用戶的分店列表加載完成');
            } catch (error) {
                console.error('加載分店列表失敗，但繼續初始化:', error);
                // 即使失敗也繼續，showAuthenticatedUI會處理空分店情況
            }
            // 初始化標籤頁
            this.initTabs();
            // 載入初始數據
            this.loadDashboardData();
        } else {
            // 未登入，顯示登入模態框並隱藏取消按鈕
            this.showLoginModal();
            const cancelBtn = document.getElementById('cancel-login-btn');
            if (cancelBtn) cancelBtn.style.display = 'none';
            // 初始化標籤頁（未登入狀態）
            this.initTabs();
        }

        // 隱藏dashboard中的原始右側面板（客人詳情），因為現在使用模態框
        const dashboardRightPanel = document.querySelector('#tab-dashboard .right-panel');
        if (dashboardRightPanel) {
            dashboardRightPanel.style.display = 'none';
            console.log('已隱藏dashboard中的原始右側面板（客人詳情）');

            // 添加CSS類以擴寬左側面板
            const dashboardLayout = document.querySelector('#tab-dashboard .dashboard-layout');
            if (dashboardLayout) {
                dashboardLayout.classList.add('right-panel-hidden');
                console.log('已添加right-panel-hidden類到dashboard佈局');
            }
        }

        // 確保UI根據登入狀態正確更新
        this.updateEmployeeUI();

        // 標記初始化完成
        this._initialized = true;
        console.log('EnhancedCashierSystem 初始化完成');

        // 自動重連主服務器（如果配置了分機模式）
        this.autoReconnectToMaster();

        // 啟動定時上傳敏感操作（每10分鐘觸發一次）
        this.startSensitiveUploadTimer();

        // 更新在場客人列表的連接警告顯示
        this.updateCustomerListConnectionWarning();

        // 初始化機器主服務器設定
        this.initMachineMasterSettings();
        // 自動連接小票機（註釋掉舊的自動連接方法，避免系統無響應）
        // this.setupPrinterAutoConnect();
        // 使用新的V2方法自動連接小票機（延遲3秒執行）
        this.setupPrinterAutoConnectV2();
    }

    /**
     * 設置小票機自動連接（系統刷新時嘗試連接，限時3秒，失敗不重連，每3分鐘重試一次，最多重試3次）
     */
    setupPrinterAutoConnect() {
        console.log('設置小票機自動連接（延遲10秒執行）');
        // 如果已經嘗試過自動連接，則跳過
        if (this._printerAutoConnectAttempted) {
            console.log('小票機自動連接已嘗試過，跳過');
            return;
        }
        this._printerAutoConnectAttempted = true;

        // 延遲10秒執行，等待系統穩定、用戶登入完成、分店選擇穩定
        setTimeout(() => {
            console.log('延遲10秒後嘗試連接小票機');
            this._attemptPrinterConnection();
        }, 10000); // 10秒延遲
    }

    /**
     * 嘗試連接小票機（帶3秒超時）
     */
    async _attemptPrinterConnection() {
        console.log('嘗試連接小票機（限時3秒）');

        // 檢查重試次數
        if (this._printerRetryCount >= 3) {
            console.log('小票機重試次數已達3次，停止嘗試');
            return;
        }

        // 檢查是否已登入
        if (!this.isAuthenticated) {
            console.log('用戶未登入，跳過小票機自動連接');
            return;
        }

        // 檢查分店選擇
        const storeId = this.selectedStoreId;
        if (!storeId) {
            console.log('未選擇分店，跳過小票機自動連接');
            return;
        }

        // 檢查是否已經有連接狀態
        const statusElement = document.getElementById('receipt-printer-status');
        if (statusElement && statusElement.textContent.includes('已連接')) {
            console.log(`小票機已經是連接狀態，跳過自動連接`);
            return;
        }

        // 設置超時限制（3秒）
        const timeoutPromise = new Promise((_, reject) => {
            setTimeout(() => reject(new Error('連接小票機超時（3秒）')), 3000);
        });

        try {
            console.log(`為分店 ${storeId} 嘗試連接小票機...`);

            // 嘗試連接（調用父類方法）
            const connectPromise = this.autoConnectDefaultPrinter(storeId);
            // 等待連接完成或超時
            await Promise.race([connectPromise, timeoutPromise]);
            console.log('小票機連接成功');
            // 重置重試計數
            this._printerRetryCount = 0;
        } catch (error) {
            console.warn('小票機連接失敗:', error.message);
            // 增加重試次數
            this._printerRetryCount++;
            console.log(`小票機連接失敗，重試次數: ${this._printerRetryCount}`);
            // 如果未達到3次，設置3分鐘後重試
            if (this._printerRetryCount < 3) {
                console.log(`設置 ${3 * 60} 秒後重試`);
                this._printerRetryTimer = setTimeout(() => {
                    this._attemptPrinterConnection();
                }, 3 * 60 * 1000); // 3分鐘
            } else {
                console.log('已達到最大重試次數，停止重試');
            }
        }
    }

    /**
     * 設置小票機自動連接 V2（新的穩健版本）
     * 系統刷新時嘗試連接，限時3秒，失敗不重連，每3分鐘重試一次，最多重試3次
     * 避免並行連接嘗試，支持取消操作
     */
    setupPrinterAutoConnectV2() {
        console.log('[PrinterV2] 設置小票機自動連接 V2（延遲3秒執行）');

        // 如果已經嘗試過自動連接，則跳過
        if (this._printerAutoConnectAttempted) {
            console.log('[PrinterV2] 小票機自動連接已嘗試過，跳過');
            return;
        }

        this._printerAutoConnectAttempted = true;

        // 延遲3秒執行，等待系統穩定、用戶登入完成、分店選擇穩定
        setTimeout(() => {
            console.log('[PrinterV2] 延遲3秒後嘗試連接小票機');
            this._attemptPrinterConnectionV2();
        }, 3000); // 3秒延遲
    }

    /**
     * 嘗試連接小票機 V2（新的穩健版本）
     * 帶3秒超時，防止並行連接，支持取消
     */
    async _attemptPrinterConnectionV2() {
        console.log('[PrinterV2] 嘗試連接小票機 V2（限時3秒）');

        // 防止並行連接嘗試
        if (this._printerConnecting) {
            console.log('[PrinterV2] 小票機連接正在進行中，跳過重複嘗試');
            return;
        }

        // 檢查重試次數
        if (this._printerRetryCount >= this._printerMaxRetries) {
            console.log(`[PrinterV2] 小票機重試次數已達 ${this._printerMaxRetries} 次，停止嘗試`);
            return;
        }

        // 檢查是否已登入
        if (!this.isAuthenticated) {
            console.log('[PrinterV2] 用戶未登入，跳過小票機自動連接');
            return;
        }

        // 檢查分店選擇
        const storeId = this.selectedStoreId;
        if (!storeId) {
            console.log('[PrinterV2] 未選擇分店，跳過小票機自動連接');
            return;
        }

        // 檢查是否已經有連接狀態
        const statusElement = document.getElementById('receipt-printer-status');
        if (statusElement && statusElement.textContent.includes('已連接')) {
            console.log('[PrinterV2] 小票機已經是連接狀態，跳過自動連接');
            return;
        }

        // 設置連接狀態
        this._printerConnecting = true;
        this._printerLastAttemptTime = Date.now();

        // 創建AbortController用於取消請求
        this._printerConnectionAbortController = new AbortController();
        const signal = this._printerConnectionAbortController.signal;

        // 設置超時限制（3秒 - 比服務器端30秒超時短，快速失敗避免阻塞）
        const timeoutPromise = new Promise((_, reject) => {
            setTimeout(() => reject(new Error('連接小票機超時（3秒）')), 3000);
        });

        try {
            console.log(`[PrinterV2] 為分店 ${storeId} 嘗試連接小票機...`);

            // 嘗試連接（調用父類方法），傳遞AbortSignal
            const connectPromise = this.autoConnectDefaultPrinter(storeId, signal);

            // 等待連接完成或超時
            await Promise.race([connectPromise, timeoutPromise]);

            console.log('[PrinterV2] 小票機連接成功');
            // 重置重試計數
            this._printerRetryCount = 0;

        } catch (error) {
            console.warn('[PrinterV2] 小票機連接失敗:', error.message);

            // 在錯誤處理前中止正在進行的fetch請求
            if (this._printerConnectionAbortController) {
                console.log('[PrinterV2] 中止正在進行的打印機連接請求');
                this._printerConnectionAbortController.abort();
            }

            // 增加重試次數
            this._printerRetryCount++;
            console.log(`[PrinterV2] 小票機連接失敗，重試次數: ${this._printerRetryCount}/${this._printerMaxRetries}`);

            // 如果未達到最大重試次數，設置3分鐘後重試
            if (this._printerRetryCount < this._printerMaxRetries) {
                const retryDelay = this._printerRetryDelay; // 3分鐘
                console.log(`[PrinterV2] 設置 ${retryDelay / 1000} 秒後重試`);

                // 清除現有的重試定時器（如果存在）
                if (this._printerRetryTimer) {
                    clearTimeout(this._printerRetryTimer);
                    this._printerRetryTimer = null;
                }

                // 設置新的重試定時器
                this._printerRetryTimer = setTimeout(() => {
                    console.log('[PrinterV2] 重試時間到，重新嘗試連接');
                    this._attemptPrinterConnectionV2();
                }, retryDelay);
            } else {
                console.log('[PrinterV2] 已達到最大重試次數，停止重試');
            }
        } finally {
            // 重置連接狀態，但先中止控制器（如果仍然存在）
            if (this._printerConnectionAbortController) {
                this._printerConnectionAbortController.abort();
            }
            this._printerConnecting = false;
            this._printerConnectionAbortController = null;
        }
    }

    bindEnhancedEvents() {
        console.log('bindEnhancedEvents called');

        // 防止重複綁定
        if (this._eventsBound) {
            console.log('事件已經綁定，跳過');
            return;
        }

        this._eventsBound = true;
        console.log('開始綁定事件...');

        // 員工登入按鈕 - 添加null檢查
        const staffLoginBtn = document.getElementById('staff-login-btn');
        if (staffLoginBtn) {
            // 先移除可能存在的舊監聽器
            staffLoginBtn.removeEventListener('click', () => this.showLoginModal());
            staffLoginBtn.addEventListener('click', () => this.showLoginModal());
        }

        // 登出按鈕
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) logoutBtn.addEventListener('click', () => this.logout());

        // 登入模態框事件
        const cancelLoginBtn = document.getElementById('cancel-login-btn');
        if (cancelLoginBtn) cancelLoginBtn.addEventListener('click', () => this.hideLoginModal());

        const loginForm = document.getElementById('login-form');
        const loginSubmitBtn = document.getElementById('submit-login-btn');
        console.log('Login form found:', !!loginForm, 'Login submit button found:', !!loginSubmitBtn);
        if (loginForm) {
            console.log('Found login form, adding submit event listener');
            loginForm.addEventListener('submit', (e) => this.handleLoginSubmit(e));
        } else {
            console.warn('login-form element not found!');
        }

        // 標籤頁按鈕事件
        document.querySelectorAll('.tab-button').forEach(button => {
            button.addEventListener('click', (e) => this.switchTab(e.currentTarget.dataset.tab));
        });

        // 監聽外部 switchTab 事件（預約管理用）
        document.addEventListener('switchTab', (e) => {
            if (e.detail && e.detail.tab) {
                this.switchTab(e.detail.tab);
            }
        });

        // 新增桌號按鈕
        const addTableBtn = document.getElementById('add-table-btn');
        if (addTableBtn) {
            console.log('Found add-table-btn, adding event listener');
            addTableBtn.addEventListener('click', () => {
                console.log('Add table button clicked');
                this.addNewTable();
            });
        } else {
            console.warn('add-table-btn not found!');
        }

        // 清空所有桌號按鈕
        const clearAllCustomersBtn = document.getElementById('clear-all-customers-btn');
        if (clearAllCustomersBtn) {
            console.log('Found clear-all-customers-btn, adding event listener');
            clearAllCustomersBtn.addEventListener('click', () => {
                console.log('Clear all customers button clicked');
                this.clearAllCustomers();
            });
        } else {
            console.warn('clear-all-customers-btn not found!');
        }

        // 合單結賬按鈕
        const mergeCheckoutBtn = document.getElementById('merge-checkout-btn');
        if (mergeCheckoutBtn) {
            mergeCheckoutBtn.addEventListener('click', () => this.enterMergeMode());
        } else {
            console.warn('merge-checkout-btn not found!');
        }

        // 合單確認按鈕
        const confirmMergeBtn = document.getElementById('confirm-merge-btn');
        if (confirmMergeBtn) {
            confirmMergeBtn.addEventListener('click', () => this.confirmMergeSelection());
        } else {
            console.warn('confirm-merge-btn not found!');
        }

        // 合單取消按鈕
        const cancelMergeBtn = document.getElementById('cancel-merge-btn');
        if (cancelMergeBtn) {
            cancelMergeBtn.addEventListener('click', () => this.exitMergeMode());
        } else {
            console.warn('cancel-merge-btn not found!');
        }

        // 合單模式客戶卡片點擊攔截（捕捉階段）
        if (!this._mergeCaptureHandler) {
            this._mergeCaptureHandler = (e) => {
                if (!this.isMergeMode) return;
                const card = e.target.closest('.customer-item');
                if (!card) return;
                const customerId = card.dataset.customerId;
                if (!customerId) return;
                e.stopPropagation();
                e.preventDefault();
                this.toggleMergeSelection(customerId, card);
            };
        }
        const customerList = document.getElementById('customer-list');
        if (customerList) {
            // 先移除舊的監聽器再添加，避免重複
            customerList.removeEventListener('click', this._mergeCaptureHandler, true);
            customerList.addEventListener('click', this._mergeCaptureHandler, true);
        }

        // 加單按鈕事件
        const addOrderBtn = document.getElementById('add-order-btn');
        if (addOrderBtn) {
            console.log('Found add-order-btn, adding event listener');
            addOrderBtn.addEventListener('click', () => {
                console.log('Add order button clicked');
                this.handleAddOrder();
            });
        } else {
            console.warn('add-order-btn not found!');
        }

        // 客人詳情模態框關閉按鈕
        const customerDetailModalClose = document.getElementById('customer-detail-modal-close');
        if (customerDetailModalClose) {
            console.log('Found customer-detail-modal-close, adding event listener');
            customerDetailModalClose.addEventListener('click', () => {
                console.log('Customer detail modal close button clicked');
                this.deselectCustomer();
            });
        } else {
            console.warn('customer-detail-modal-close not found!');
        }

        // 客人詳情模態框按鈕事件
        const modalCheckoutBtn = document.getElementById('modal-checkout-btn');
        const modalAddOrderBtn = document.getElementById('modal-add-order-btn');
        const modalDeleteTableBtn = document.getElementById('modal-delete-table-btn');

        if (modalCheckoutBtn) {
            console.log('Found modal-checkout-btn, adding event listener');
            modalCheckoutBtn.addEventListener('click', () => {
                console.log('Modal checkout button clicked, triggering original checkout button');
                const originalCheckoutBtn = document.getElementById('checkout-btn');
                if (originalCheckoutBtn && !originalCheckoutBtn.disabled) {
                    // 先關閉客人詳情視窗
                    this.hideCustomerDetailModal();
                    // 再觸發原始結賬按鈕
                    originalCheckoutBtn.click();
                }
            });
        }

        if (modalAddOrderBtn) {
            console.log('Found modal-add-order-btn, adding event listener');
            modalAddOrderBtn.addEventListener('click', () => {
                console.log('Modal add order button clicked, triggering original add-order button');
                const originalAddOrderBtn = document.getElementById('add-order-btn');
                if (originalAddOrderBtn && !originalAddOrderBtn.disabled) {
                    originalAddOrderBtn.click();
                }
            });
        }

        if (modalDeleteTableBtn) {
            console.log('Found modal-delete-table-btn, adding event listener');
            modalDeleteTableBtn.addEventListener('click', () => {
                console.log('Modal delete table button clicked, calling showDeleteTableModal');
                if (!modalDeleteTableBtn.disabled) {
                    this.showDeleteTableModal();
                }
            });
        }

        // 模態框後加客人按鈕
        const modalAddSubtableBtn = document.getElementById('modal-add-subtable-btn');
        if (modalAddSubtableBtn) {
            console.log('Found modal-add-subtable-btn, adding event listener');
            modalAddSubtableBtn.addEventListener('click', () => {
                console.log('Modal add sub-table button clicked');
                if (!modalAddSubtableBtn.disabled) {
                    this.showAddSubTableModal();
                }
            });
        }

        // 模態框備註按鈕
        const modalNoteBtn = document.getElementById('modal-note-btn');
        if (modalNoteBtn) {
            console.log('Found modal-note-btn, adding event listener');
            modalNoteBtn.addEventListener('click', () => {
                console.log('Modal note button clicked, calling openNoteInput');
                if (!modalNoteBtn.disabled) {
                    this.openNoteInput();
                }
            });
        }

        // 模態框部份結賬按鈕
        const modalPartialCheckoutBtn = document.getElementById('modal-partial-checkout-btn');
        if (modalPartialCheckoutBtn) {
            console.log('Found modal-partial-checkout-btn, adding event listener');
            modalPartialCheckoutBtn.addEventListener('click', () => {
                console.log('Modal partial checkout button clicked');
                if (!modalPartialCheckoutBtn.disabled) {
                    this.openPartialCheckoutModal();
                }
            });
        }

        // 模態框QR Code重印按鈕事件
        const modalReprintQRBtn = document.getElementById('reprint-modal-qr-btn');
        if (modalReprintQRBtn) {
            console.log('Found reprint-modal-qr-btn, adding event listener');
            modalReprintQRBtn.addEventListener('click', () => {
                console.log('Modal reprint QR button clicked');
                this.reprintQRCode();
            });
        }

        // 部份結賬模態框按鈕事件
        const partialCheckoutClose = document.getElementById('partial-checkout-modal-close');
        const partialCheckoutCancel = document.getElementById('partial-checkout-cancel-btn');
        const partialCheckoutConfirm = document.getElementById('partial-checkout-confirm-btn');

        if (partialCheckoutClose) {
            partialCheckoutClose.addEventListener('click', () => this.closePartialCheckoutModal());
        }
        if (partialCheckoutCancel) {
            partialCheckoutCancel.addEventListener('click', () => this.closePartialCheckoutModal());
        }
        if (partialCheckoutConfirm) {
            partialCheckoutConfirm.addEventListener('click', () => this.confirmPartialCheckout());
        }

        // 購物車事件綁定
        this.bindCartEvents();

        // 商品管理事件綁定
        this.bindProductEvents();

        // 全局點擊事件：點擊其他地方取消選中桌號
        document.addEventListener('click', (e) => {
            // 檢查點擊目標是否為customer-item或相關元素
            const target = e.target;
            const isCustomerItem = target.closest('.customer-item') || target.closest('[data-customer-id]');

            // 檢查是否為結賬按鈕、刪除桌號按鈕、加單按鈕或模態框內的元素
            const isCheckoutBtn = target.closest('#checkout-btn');
            const isDeleteTableBtn = target.closest('#delete-table-btn');
            const isAddOrderBtn = target.closest('#add-order-btn');
            const isCheckoutModal = target.closest('#checkout-modal');
            const isDeleteTableModal = target.closest('#delete-table-modal');
            const isCustomerDetailModal = target.closest('#customer-detail-modal');
            // 檢查是否為模態框背景層（點擊.modal本身而非.modal-content內容區域）
            const clickedModal = target.classList.contains('modal') ? target : null;
            const isModalContent = target.closest('.modal-content');
            const isModalBackground = clickedModal && !isModalContent;
            const isAnyModal = target.closest('.modal');
            const isPartialModal = target.closest('#partial-checkout-modal');

            // 處理模態框背景點擊關閉
            if (isModalBackground && clickedModal) {
                // 結賬模態框
                if (clickedModal.id === 'checkout-modal') {
                    this.hideCheckoutModal();
                    return; // 停止進一步處理
                }
                // 刪除桌號模態框
                if (clickedModal.id === 'delete-table-modal') {
                    this.hideDeleteTableModal();
                    return;
                }
                // 客人詳情模態框
                if (clickedModal.id === 'customer-detail-modal') {
                    this.hideCustomerDetailModal();
                    return;
                }
                // 部份結賬模態框
                if (clickedModal.id === 'partial-checkout-modal') {
                    this.closePartialCheckoutModal();
                    return;
                }
            }

            // 如果點擊的是模態框背景層，允許關閉；否則排除所有模態框相關元素
            const isExcluded = !isModalBackground && (isCheckoutBtn || isDeleteTableBtn || isAddOrderBtn || isCheckoutModal || isDeleteTableModal || isCustomerDetailModal || isPartialModal || isAnyModal);

            // 調試日誌
            if (this.selectedCustomer && this.currentTab === 'dashboard') {
                console.log('點擊事件調試:', {
                    target: target.tagName,
                    targetId: target.id || '無ID',
                    targetClass: target.className || '無類名',
                    isCustomerItem,
                    isCheckoutBtn: !!isCheckoutBtn,
                    isDeleteTableBtn: !!isDeleteTableBtn,
                    isAddOrderBtn: !!isAddOrderBtn,
                    isCheckoutModal: !!isCheckoutModal,
                    isDeleteTableModal: !!isDeleteTableModal,
                    isCustomerDetailModal: !!isCustomerDetailModal,
                    clickedModal: !!clickedModal,
                    isModalContent: !!isModalContent,
                    isModalBackground,
                    isAnyModal: !!isAnyModal,
                    isExcluded,
                    selectedCustomer: this.selectedCustomer ? '有' : '無',
                    currentTab: this.currentTab
                });
            }


            // 如果點擊的不是customer-item且不是排除元素，且當前有選中桌號，且當前標籤頁是dashboard，則取消選中
            // 包括空白位置、不同分頁等任何非桌號元素
            if (!isCustomerItem && !isExcluded && this.selectedCustomer && this.currentTab === 'dashboard') {
                console.log('點擊其他地方，取消選中桌號');
                this.deselectCustomer();
            }
        });
    }

    // 覆蓋父類bindEvents，防止重複綁定
    bindEvents() {
        console.log('EnhancedCashierSystem.bindEvents called');
        // 防止父類bindEvents被調用兩次
        if (this._parentEventsBound) {
            console.log('父類事件已經綁定，跳過');
            return;
        }

        // 清理可能被原始CashierSystem實例綁定的事件監聽器
        this.cleanupDuplicateEventListeners();

        this._parentEventsBound = true;
        super.bindEvents();
    }

    // 清理重複事件監聽器
    cleanupDuplicateEventListeners() {
        console.log('清理重複事件監聽器');
        const buttonIds = [
            'change-table-btn',
            'modal-change-table-btn',
            'add-table-btn',
            'merge-checkout-btn',
            'confirm-merge-btn',
            'cancel-merge-btn',
            'checkout-btn',
            'delete-table-btn',
            'refresh-customers-btn',
            'refresh-products-btn',
            'cashier-refresh-entries-btn',
            'clear-all-customers-btn',
            'add-order-btn',
            'cart-checkout-btn',
            'cart-suspend-btn',
            // 小票機控制按鈕
            'connect-receipt-printer-btn',
            'disconnect-receipt-printer-btn',
            'test-receipt-printer-btn',
            'scan-bluetooth-btn',
            // 藍牙模式切換按鈕
            'bluetooth-mode-scan',
            'bluetooth-mode-manual',
            // 模態框按鈕
            'modal-add-subtable-btn',
            'modal-note-btn',
            'modal-partial-checkout-btn',
            'partial-checkout-modal-close',
            'partial-checkout-cancel-btn',
            'partial-checkout-confirm-btn',
            'reprint-modal-qr-btn'
        ];

        buttonIds.forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                // 通過克隆和替換移除所有事件監聽器
                const clonedElement = element.cloneNode(true);
                element.parentNode.replaceChild(clonedElement, element);
                console.log(`已清理元素 ${id} 的事件監聽器`);
            }
        });
    }

    // 新增桌號
    async addNewTable(prefillPeople, seatingType) {
        // 防止重複執行
        if (this._addingTable) {
            console.log('addNewTable: 正在執行中，跳過本次調用');
            return false;
        }

        this._addingTable = true;
        try {
            console.log('=== addNewTable called ===');
            console.trace('addNewTable stack trace');
            console.log(`當前選擇分店ID: ${this.selectedStoreId} (類型: ${typeof this.selectedStoreId})`);
            console.log(`當前員工:`, this.currentEmployee ? { id: this.currentEmployee.id, role: this.currentEmployee.role, store_id: this.currentEmployee.store_id } : null);
            console.log(`isAuthenticated: ${this.isAuthenticated}, currentToken: ${this.currentToken ? '有' : '無'}`);
            console.log(`分店查詢條件檢查: this.selectedStoreId = "${this.selectedStoreId}", 真值檢查: ${!!this.selectedStoreId}`);

            let tableNumber = null;
            let peopleCount = 0;

            // 如果選擇了分店，檢查分店是否要求輸入桌號
            console.log(`addNewTable: 檢查分店條件 - this.selectedStoreId="${this.selectedStoreId}", 真值: ${!!this.selectedStoreId}`);
            if (this.selectedStoreId) {
                console.log('addNewTable: 進入分店查詢塊');

                let requireTableNumber = false;

                // 首先嘗試從 accessibleStores 中獲取分店設置
                console.log(`addNewTable: 檢查 accessibleStores, 數量: ${this.accessibleStores?.length || 0}`);
                if (this.accessibleStores && this.accessibleStores.length > 0) {
                    const currentStore = this.accessibleStores.find(store => store.id === this.selectedStoreId);
                    if (currentStore) {
                        console.log('addNewTable: 從 accessibleStores 找到分店:', currentStore);

                        // 檢查是否有 settings 字段
                        if (currentStore.settings) {
                            try {
                                let settings = {};
                                if (typeof currentStore.settings === 'string') {
                                    try {
                                        settings = JSON.parse(currentStore.settings);
                                        console.log('addNewTable: 從 accessibleStores 解析 settings JSON 成功');
                                    } catch (parseErr) {
                                        console.warn('addNewTable: 解析 accessibleStores 中的 settings JSON 失敗:', parseErr);
                                    }
                                } else if (typeof currentStore.settings === 'object') {
                                    settings = currentStore.settings;
                                    console.log('addNewTable: accessibleStores 中的 settings 是對象，直接使用');
                                }

                                console.log('addNewTable: 從 accessibleStores 獲得的處理後 settings:', settings);
                                console.log('addNewTable: require_table_number 原始值:', settings.require_table_number, '類型:', typeof settings.require_table_number);

                                // 處理布林值，支援 true/false 字符串或布林類型
                                requireTableNumber =
                                    settings.require_table_number === true ||
                                    settings.require_table_number === 'true' ||
                                    settings.require_table_number === 1;
                                console.log('addNewTable: 從 accessibleStores 獲得的 require_table_number 評估結果:', requireTableNumber);
                            } catch (error) {
                                console.warn('addNewTable: 處理 accessibleStores 中的 settings 時發生錯誤:', error);
                            }
                        } else {
                            console.log('addNewTable: accessibleStores 中的分店沒有 settings 字段，嘗試檢查 use_lockers 等直接字段');

                            // 如果沒有 settings 字段，檢查是否有直接的 require_table_number 字段
                            // 注意：通常 require_table_number 存儲在 settings JSON 中，但檢查以防萬一
                            if (currentStore.require_table_number !== undefined) {
                                requireTableNumber =
                                    currentStore.require_table_number === true ||
                                    currentStore.require_table_number === 'true' ||
                                    currentStore.require_table_number === 1;
                                console.log('addNewTable: 從分店直接字段獲得的 require_table_number:', requireTableNumber);
                            }
                        }
                    } else {
                        console.warn(`addNewTable: 在 accessibleStores 中找不到分店 ${this.selectedStoreId}`);
                    }
                } else {
                    console.warn('addNewTable: accessibleStores 為空或未定義');
                }

                // 如果無法從 accessibleStores 確定，則使用 API 獲取（僅限管理員）
                if (requireTableNumber === false && this.currentEmployee?.role === 'admin') {
                    console.log('addNewTable: 無法從 accessibleStores 確定設置，使用 API 獲取（管理員權限）');
                    try {
                        // 獲取分店詳細信息
                        const headers = {};
                        if (this.currentToken) {
                            headers['Authorization'] = `Bearer ${this.currentToken}`;
                        }
                        const storeResponse = await fetch(`/api/stores/${this.selectedStoreId}`, { headers });
                        if (storeResponse.ok) {
                            const storeResult = await storeResponse.json();
                            if (storeResult.success && storeResult.data) {
                                const store = storeResult.data;
                                console.log('addNewTable: API store對象:', store);
                                console.log('addNewTable: store.settings 原始值:', store.settings, '類型:', typeof store.settings);

                                // 檢查分店設置中是否要求輸入桌號
                                let settings = {};
                                try {
                                    if (store.settings) {
                                        if (typeof store.settings === 'string') {
                                            // 如果是字符串，嘗試解析為JSON
                                            try {
                                                settings = JSON.parse(store.settings);
                                                console.log('addNewTable: API 成功解析settings JSON字符串');
                                            } catch (parseErr) {
                                                console.warn('addNewTable: API 解析settings JSON失敗:', parseErr, '原始值:', store.settings);
                                                settings = {};
                                            }
                                        } else if (typeof store.settings === 'object') {
                                            // 已經是對象
                                            settings = store.settings;
                                            console.log('addNewTable: API settings是對象，直接使用');
                                        }
                                    }
                                } catch (error) {
                                    console.warn('addNewTable: API 處理settings時發生錯誤:', error);
                                    settings = {};
                                }

                                console.log('addNewTable: API 處理後的settings:', settings);
                                console.log('addNewTable: API require_table_number 原始值:', settings.require_table_number, '類型:', typeof settings.require_table_number);

                                // 處理布林值，支援 true/false 字符串或布林類型
                                requireTableNumber =
                                    settings.require_table_number === true ||
                                    settings.require_table_number === 'true' ||
                                    settings.require_table_number === 1;
                                console.log('addNewTable: API require_table_number 評估結果:', requireTableNumber, '(真值檢查)');
                            }
                        }
                    } catch (error) {
                        console.warn('addNewTable: API 獲取分店設置失敗，繼續使用默認行為:', error);
                    }
                }

                // 如果確定需要輸入桌號，提示用戶
                if (requireTableNumber) {
                    console.log('addNewTable: 分店要求輸入桌號');
                    // 使用自定義數字輸入對話框（支援數字鍵盤）
                    const tableResult = await this.showNumericInputModal({
                        title: '新增桌號',
                        tableNumber: true,
                        peopleCount: true,
                        tableError: null,
                        peopleError: '請輸入有效的人數 (1-70)',
                        prefillPeople: prefillPeople
                    });
                    if (!tableResult) {
                        this._addingTable = false;
                        return false; // 用戶取消
                    }

                    // 格式化為 A+數字 (例如: A10)
                    const proposedTableNumber = `A${tableResult.tableNumber}`;

                    // 檢查桌號是否已存在
                    const isTableOccupied = await this.checkTableOccupied(proposedTableNumber);
                    if (isTableOccupied) {
                        alert(`桌號 ${proposedTableNumber} 已經存在，請選擇其他桌號`);
                        this._addingTable = false;
                        return false;
                    }

                    tableNumber = proposedTableNumber;
                    peopleCount = tableResult.peopleCount;
                    console.log(`分店要求輸入桌號，桌號設置為: ${tableNumber}, 人數: ${peopleCount}`);
                } else {
                    console.log('addNewTable: 分店不要求輸入桌號或無法確定設置');
                }
            }

            // 如果尚未輸入人數（無桌號模式）
            if (!peopleCount) {
                // 使用自定義數字輸入對話框
                const peopleResult = await this.showNumericInputModal({
                    title: '請輸入人數',
                    tableNumber: false,
                    peopleCount: true,
                    peopleError: '請輸入有效的人數 (1-70)',
                    prefillPeople: prefillPeople
                });
                if (!peopleResult) {
                    this._addingTable = false;
                    return false;
                }
                peopleCount = peopleResult.peopleCount;
            }

            // 調用入場API
            const requestBody = {
                peopleCount: peopleCount,
                isMember: false,
                memberCardId: null,
                seating_type: seatingType || 'walk-in'
            };

            // 如果指定了桌號，添加到請求體
            if (tableNumber) {
                requestBody.table_number = tableNumber;
                console.log(`新增桌號：指定桌號 ${tableNumber}`);
            }

            // 構建URL，包含分店ID作為查詢參數（用於store-aware中間件）
            let url = '/api/entry/entry';
            if (this.selectedStoreId) {
                url += `?store_id=${this.selectedStoreId}`;
                console.log(`新增桌號：添加分店ID ${this.selectedStoreId} 到URL查詢參數`);

                // 同時添加到請求體以備用
                requestBody.store_id = this.selectedStoreId;
            } else {
                console.warn('新增桌號：未選擇分店，將使用默認分店或員工所屬分店');
            }

            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(requestBody)
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage(`已成功新增桌號: ${result.data.table_number} (${peopleCount}人)`, 'success');
                this.loadCustomers(); // 刷新在場客人列表
                this.loadEntryRecords(); // 刷新入場記錄
                return result.data && result.data.table_number ? result.data.table_number : true;
            } else {
                this.addMessage(`新增桌號失敗: ${result.message}`, 'error');
                return false;
            }
        } catch (error) {
            console.error('新增桌號錯誤:', error);
            this.addMessage(`新增桌號時發生錯誤: ${error.message}`, 'error');
            return false;
        } finally {
            this._addingTable = false;
        }
    }

    /**
     * 檢查桌號是否已被佔用
     * @param {string} tableNumber - 要檢查的桌號 (例如: A10)
     * @returns {Promise<boolean>} - true表示桌號已存在，false表示可用
     */
    async checkTableOccupied(tableNumber) {
        try {
            console.log(`檢查桌號是否已存在: ${tableNumber}`);

            // 構建請求URL
            let url = '/api/cashier/customers';
            if (this.selectedStoreId) {
                url += `?store_id=${this.selectedStoreId}`;
            }

            // 構建請求頭
            const headers = {};
            if (this.currentToken) {
                headers['Authorization'] = `Bearer ${this.currentToken}`;
            }

            const response = await fetch(url, { headers });
            if (!response.ok) {
                console.warn('無法獲取客人列表，假設桌號可用');
                return false;
            }

            const result = await response.json();
            if (!result.success || !Array.isArray(result.customers)) {
                console.warn('客人數據格式錯誤，假設桌號可用');
                return false;
            }

            // 檢查子桌號：如果此桌號有子桌號 (A7 → A7.X)，則視為已佔用
            const hasSubTables = result.customers.some(c =>
                c.table_number &&
                c.table_number.startsWith(tableNumber + '.')
            );
            if (hasSubTables) {
                console.log(`桌號 ${tableNumber} 已有子桌號，無法新增`);
                return true;
            }

            // 檢查是否有相同桌號的客人
            const existingCustomer = result.customers.find(customer =>
                customer.table_number === tableNumber && customer.is_checked_out === 0
            );

            if (existingCustomer) {
                console.log(`桌號 ${tableNumber} 已存在，客人ID: ${existingCustomer.id}`);
                return true;
            }

            console.log(`桌號 ${tableNumber} 可用`);
            return false;
        } catch (error) {
            console.error('檢查桌號時發生錯誤:', error);
            // 發生錯誤時假設桌號可用，讓服務器端驗證處理
            return false;
        }
    }

    /**
     * 顯示數字輸入對話框（支援數字鍵盤）
     * @param {Object} options
     * @param {string} options.title - 對話框標題
     * @param {boolean} options.tableNumber - 是否顯示桌號輸入
     * @param {boolean} options.peopleCount - 是否顯示人數輸入
     * @param {string|null} options.peopleError - 人數驗證錯誤訊息
     * @param {string|null} options.tableError - 桌號驗證錯誤訊息
     * @param {string|null} options.readOnlyTableNumber - 若設定，桌號欄位預填此值且為唯讀（子桌號用）
     * @returns {Promise<{tableNumber: number, peopleCount: number}|null>} 用戶取消返回 null
     */
    showNumericInputModal(options) {
        // Try custom modal first, fall back to prompt() if modal doesn't appear
        return new Promise((resolve) => {
            const modal = document.getElementById('numeric-input-modal');

            // If modal element doesn't exist, go straight to prompt fallback
            if (!modal) {
                this._promptFallback(options, resolve);
                return;
            }

            const titleEl = document.getElementById('numeric-input-title');
            const tableSection = document.getElementById('numeric-input-table-section');
            const tableInput = document.getElementById('numeric-input-table');
            const peopleInput = document.getElementById('numeric-input-people');
            const errorEl = document.getElementById('numeric-input-error');
            const confirmBtn = document.getElementById('numeric-input-confirm');
            const cancelBtn = document.getElementById('numeric-input-cancel');

            // If any critical element is missing, fall back to prompt
            if (!titleEl || !tableSection || !tableInput || !peopleInput ||
                !errorEl || !confirmBtn || !cancelBtn) {
                this._promptFallback(options, resolve);
                return;
            }

            // 重置
            let resolved = false;
            // 讀取舊的 readonly 狀態以便清理
            const wasReadOnly = tableInput.readOnly;
            tableInput.removeAttribute('readOnly');
            tableInput.style.backgroundColor = '';
            tableInput.style.cursor = '';
            tableInput.type = 'number';
            tableInput.value = '';
            peopleInput.value = '';
            if (options.prefillPeople) { peopleInput.value = options.prefillPeople; }
            errorEl.style.display = 'none';
            tableSection.style.display = options.tableNumber ? 'block' : 'none';

            // 重置人數輸入為默認整數模式
            const peopleLabel = document.querySelector('label[for="numeric-input-people"]');
            if (peopleLabel) peopleLabel.textContent = '人數';
            peopleInput.step = '1';
            peopleInput.min = '1';
            peopleInput.placeholder = '請輸入人數';

            // 金額模式：支援小數輸入
            if (options.decimal) {
                peopleInput.step = '0.01';
                peopleInput.inputMode = 'decimal';
                peopleInput.min = '0';
                peopleInput.placeholder = '請輸入金額';
                if (peopleLabel) peopleLabel.textContent = '金額';
            }

            // 唯讀桌號（子桌號模式）：預填桌號、禁止修改
            if (options.readOnlyTableNumber) {
                tableInput.type = 'text';
                tableInput.value = options.readOnlyTableNumber;
                tableInput.readOnly = true;
                tableInput.style.backgroundColor = '#f0f0f0';
                tableInput.style.cursor = 'not-allowed';
            }

            // 自動聚焦到第一個輸入欄位
            if (options.tableNumber && !options.readOnlyTableNumber) {
                setTimeout(() => tableInput.focus(), 100); // 新增桌號：聚焦桌號
            } else {
                setTimeout(() => peopleInput.focus(), 100); // 只輸入人數 / 子桌號（已預填）：聚焦人數
            }

            titleEl.textContent = options.title || '請輸入';

            const cleanup = () => {
                if (resolved) return;
                resolved = true;
                modal.style.display = 'none';
                modal.classList.add('hidden');
                confirmBtn.removeEventListener('click', onConfirm);
                cancelBtn.removeEventListener('click', onCancel);
                document.removeEventListener('keydown', onKeydown);
            };

            const onConfirm = () => {
                // 金額模式：支援小數
                if (options.decimal) {
                    const amountVal = peopleInput.value.trim();
                    const amount = parseFloat(amountVal);
                    if (!amountVal || isNaN(amount) || amount < 0) {
                        errorEl.textContent = options.peopleError || '請輸入有效的金額';
                        errorEl.style.display = 'block';
                        return;
                    }
                    cleanup();
                    resolve({ tableNumber: null, peopleCount: amount });
                    return;
                }

                const peopleVal = peopleInput.value.trim();
                const people = parseInt(peopleVal);
                if (!peopleVal || isNaN(people) || people < 1 || people > 70) {
                    errorEl.textContent = options.peopleError || '請輸入有效的人數 (1-70)';
                    errorEl.style.display = 'block';
                    return;
                }

                if (options.tableNumber) {
                    if (options.readOnlyTableNumber) {
                        // 子桌號模式：使用預設值，不需驗證
                        cleanup();
                        resolve({ tableNumber: options.readOnlyTableNumber, peopleCount: people });
                    } else {
                        const tableVal = tableInput.value.trim();
                        const table = parseInt(tableVal);
                        if (!tableVal || isNaN(table) || table <= 0) {
                            errorEl.textContent = options.tableError || '請輸入有效的桌號';
                            errorEl.style.display = 'block';
                            return;
                        }
                        cleanup();
                        resolve({ tableNumber: table, peopleCount: people });
                    }
                } else {
                    cleanup();
                    resolve({ tableNumber: null, peopleCount: people });
                }
            };

            const onCancel = () => {
                cleanup();
                resolve(null);
            };

            confirmBtn.addEventListener('click', onConfirm);
            cancelBtn.addEventListener('click', onCancel);

            // Enter 鍵確認
            const onKeydown = (e) => {
                if (e.key === 'Enter') onConfirm();
                if (e.key === 'Escape') onCancel();
            };
            document.addEventListener('keydown', onKeydown);

            // 顯示 modal
            modal.classList.remove('hidden');
            modal.style.display = 'flex';
            modal.style.position = 'fixed';
            modal.style.top = '0';
            modal.style.left = '0';
            modal.style.width = '100%';
            modal.style.height = '100%';
            modal.style.backgroundColor = 'rgba(0,0,0,0.5)';
            modal.style.zIndex = '10000';
            modal.style.alignItems = 'center';
            modal.style.justifyContent = 'center';

            // 移除 fallback prompt
        });
    }

    /**
     * prompt() 後備方案（onJsPrompt 在 WebView 中已啟用）
     */
    _promptFallback(options, resolve) {
        try {
            if (options.tableNumber) {
                const tableStr = prompt(options.title + ' - 請輸入桌號 (數字):');
                if (tableStr === null) { resolve(null); return; }
                const tableNum = parseInt(tableStr.trim());
                if (isNaN(tableNum) || tableNum <= 0) {
                    alert('請輸入有效的桌號');
                    resolve(null); return;
                }
                const peopleStr = prompt('請輸入人數:');
                if (peopleStr === null) { resolve(null); return; }
                const people = parseInt(peopleStr.trim());
                if (isNaN(people) || people < 1 || people > 70) {
                    alert('請輸入有效的人數 (1-70)');
                    resolve(null); return;
                }
                resolve({ tableNumber: tableNum, peopleCount: people });
            } else if (options.decimal) {
                const amountStr = prompt(options.title || '請輸入金額:');
                if (amountStr === null) { resolve(null); return; }
                const amount = parseFloat(amountStr.trim());
                if (isNaN(amount) || amount < 0) {
                    alert('請輸入有效的金額');
                    resolve(null); return;
                }
                resolve({ tableNumber: null, peopleCount: amount });
            } else {
                const peopleStr = prompt(options.title || '請輸入人數:');
                if (peopleStr === null) { resolve(null); return; }
                const people = parseInt(peopleStr.trim());
                if (isNaN(people) || people < 1 || people > 70) {
                    alert('請輸入有效的人數 (1-70)');
                    resolve(null); return;
                }
                resolve({ tableNumber: null, peopleCount: people });
            }
        } catch (e) {
            resolve(null);
        }
    }

    bindCartEvents() {
        console.log('bindCartEvents called');
        // 購物車結賬按鈕
        const cartCheckoutBtn = document.getElementById('cart-checkout-btn');
        console.log('cart-checkout-btn element found?', !!cartCheckoutBtn);
        if (cartCheckoutBtn) {
            cartCheckoutBtn.addEventListener('click', () => {
                console.log('cart-checkout-btn clicked!');
                this.checkoutCart();
            });
        }

        // 購物車掛單按鈕
        const cartSuspendBtn = document.getElementById('cart-suspend-btn');
        console.log('bindCartEvents: cart-suspend-btn found?', !!cartSuspendBtn);
        if (cartSuspendBtn) {
            cartSuspendBtn.addEventListener('click', async (e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('掛單按鈕被點擊，阻止默認行為');
                await this.suspendCart();
            });
        }

        // 購物車清空按鈕（在updateCartDisplay中綁定）
        // 購物車項目按鈕（在updateCartDisplay中動態綁定）
    }

    bindProductEvents() {
        // 新增商品按鈕
        const addProductBtn = document.getElementById('add-product-btn');
        if (addProductBtn) addProductBtn.addEventListener('click', () => this.showProductModal());

        // 刷新商品按鈕
        const refreshProductsTabBtn = document.getElementById('refresh-products-tab-btn');
        if (refreshProductsTabBtn) refreshProductsTabBtn.addEventListener('click', () => this.loadProductsTabData());

        // 商品模態框按鈕
        const cancelProductBtn = document.getElementById('cancel-product-btn');
        if (cancelProductBtn) cancelProductBtn.addEventListener('click', () => this.hideProductModal());

        const productForm = document.getElementById('product-form');
        if (productForm) productForm.addEventListener('submit', (e) => this.handleProductFormSubmit(e));

        // 商品篩選器
        const productSearch = document.getElementById('product-search');
        if (productSearch) productSearch.addEventListener('input', () => this.applyProductFilters());

        const productCategoryFilter = document.getElementById('product-category-filter');
        if (productCategoryFilter) productCategoryFilter.addEventListener('change', () => this.applyProductFilters());

        const productStockFilter = document.getElementById('product-stock-filter');
        if (productStockFilter) productStockFilter.addEventListener('change', () => this.applyProductFilters());

        // 分頁按鈕
        const prevPageBtn = document.getElementById('prev-page-btn');
        if (prevPageBtn) prevPageBtn.addEventListener('click', () => this.previousProductPage());

        const nextPageBtn = document.getElementById('next-page-btn');
        if (nextPageBtn) nextPageBtn.addEventListener('click', () => this.nextProductPage());

        // 商品操作按鈕 - 進入選擇模式
        const productOperationBtn = document.getElementById('product-operation-btn');
        if (productOperationBtn) productOperationBtn.addEventListener('click', () => this.toggleProductSelectionMode());

        // 商品分類標籤（現在由populateCategoryTabs動態生成並綁定事件）
        // 註釋掉靜態綁定，避免重複綁定
        // const categoryTabButtons = document.querySelectorAll('.category-tab-button');
        // console.log('Found category tab buttons:', categoryTabButtons.length);
        // if (categoryTabButtons.length > 0) {
        //     categoryTabButtons.forEach(button => {
        //         button.addEventListener('click', (e) => {
        //             console.log('Category tab clicked:', e.currentTarget.dataset.category);
        //             this.switchProductCategory(e.currentTarget.dataset.category);
        //         });
        //     });
        // }

        // 批量上傳CSV事件綁定
        const batchUploadBtn = document.getElementById('batch-add-products-btn');
        if (batchUploadBtn) batchUploadBtn.addEventListener('click', () => this.showBatchProductModal());

        // 匯出商品CSV事件綁定
        const exportProductsBtn = document.getElementById('export-products-btn');
        if (exportProductsBtn) exportProductsBtn.addEventListener('click', () => this.exportProductsToCSV());

        const cancelBatchBtn = document.getElementById('cancel-batch-btn');
        if (cancelBatchBtn) cancelBatchBtn.addEventListener('click', () => this.hideBatchProductModal());

        const csvFileInput = document.getElementById('csv-file');
        if (csvFileInput) csvFileInput.addEventListener('change', (e) => this.handleCSVFileSelect(e));

        const batchProductForm = document.getElementById('batch-product-form');
        if (batchProductForm) batchProductForm.addEventListener('submit', (e) => this.handleBatchProductSubmit(e));
    }

    // 生成模擬客人數據
    generateMockCustomers() {
        // 生成A1到A50的桌號
        const tableNumbers = Array.from({ length: 50 }, (_, i) => `A${i + 1}`);
        const mockCustomers = [];
        const now = new Date();

        // 生成50個模擬客人
        for (let i = 0; i < 50; i++) {
            const tableIndex = i % tableNumbers.length;
            const peopleCount = Math.floor(Math.random() * 5) + 1; // 1-5人
            const minutesAgo = Math.floor(Math.random() * 120) + 1; // 1-120分鐘前入場
            const entryTime = new Date(now.getTime() - minutesAgo * 60000);
            const totalAmount = Math.floor(Math.random() * 500) + 50; // 50-550元

            // 每個桌號的容納人數上限設定為70人
            const capacity = 70;

            // 為模擬顧客分配儲物柜（如果人數大於2）
            let lockers = [];
            if (peopleCount > 2) {
                // 分配連續的儲物柜號，從 i*10 + 1 開始，避免重複
                const startLocker = i * 10 + 1;
                lockers = Array.from({ length: peopleCount }, (_, j) => startLocker + j);
            }

            mockCustomers.push({
                id: `mock-customer-${i + 1}`,
                table_number: tableNumbers[tableIndex],
                people_count: peopleCount,
                entry_time: entryTime.toISOString(),
                total_amount: totalAmount,
                is_checked_out: 0,
                qr_code: `mock-qr-${i + 1}`,
                is_member: Math.random() > 0.7 ? 1 : 0, // 30%機率是會員
                capacity: capacity,
                item_count: Math.floor(Math.random() * 5) + 1, // 1-5個商品
                total_spent: totalAmount,
                lockers: lockers  // 添加儲物柜屬性
            });
        }

        return mockCustomers;
    }

    // 生成模擬商品數據
    generateMockProducts() {
        const mockProducts = [
            { id: 1, name: '貓草餅乾', category: '貓零食', price: 80, stock: 15, min_stock: 5, product_order: 0 },
            { id: 2, name: '雞肉條', category: '貓零食', price: 120, stock: 8, min_stock: 5, product_order: 0 },
            { id: 3, name: '貓薄荷球', category: '貓零食', price: 150, stock: 20, min_stock: 10, product_order: 0 },
            { id: 4, name: '魚肉泥', category: '貓零食', price: 90, stock: 3, min_stock: 5, product_order: 0 },
            { id: 5, name: '小魚乾', category: '貓零食', price: 100, stock: 12, min_stock: 5, product_order: 0 },
            { id: 6, name: '美式咖啡', category: '沖調飲品', price: 80, stock: 50, min_stock: 10, product_order: 0 },
            { id: 7, name: '拿鐵咖啡', category: '沖調飲品', price: 120, stock: 30, min_stock: 10, product_order: 0 },
            { id: 8, name: '奶茶', category: '沖調飲品', price: 90, stock: 25, min_stock: 10, product_order: 0 },
            { id: 9, name: '綠茶', category: '沖調飲品', price: 70, stock: 40, min_stock: 10, product_order: 0 },
            { id: 10, name: '巧克力蛋糕', category: '甜品輕食', price: 150, stock: 10, min_stock: 5, product_order: 0 },
            { id: 11, name: '起司蛋糕', category: '甜品輕食', price: 160, stock: 8, min_stock: 5, product_order: 0 },
            { id: 12, name: '提拉米蘇', category: '甜品輕食', price: 140, stock: 5, min_stock: 5, product_order: 0 },
            { id: 13, name: '布丁', category: '甜品輕食', price: 80, stock: 15, min_stock: 5, product_order: 0 }
        ];
        return mockProducts;
    }

    // 構建API URL（根據角色決定使用本地還是主機）
    buildApiUrl(path) {
        const role = localStorage.getItem('hostRole') || 'master';
        const masterIp = localStorage.getItem('masterServerIp');

        // 如果是分機模式且有配置主服務器IP，檢查是否需要重定向到主機
        if (role === 'client' && masterIp) {
            // 只對特定的API路徑進行重定向（在場客人和結賬單據相關）
            const syncPaths = [
                '/api/cashier/',
                '/api/customers/',
                '/api/checkout/',
                '/api/bills/',
                '/api/orders/'
            ];

            const shouldRedirect = syncPaths.some(prefix => path.startsWith(prefix));

            if (shouldRedirect) {
                // 確保masterIp有協議前綴
                let baseUrl = masterIp;
                if (!baseUrl.startsWith('http://') && !baseUrl.startsWith('https://')) {
                    baseUrl = `http://${baseUrl}`;
                }
                // 移除末尾的斜杠（如果有）
                baseUrl = baseUrl.replace(/\/$/, '');
                return `${baseUrl}${path}`;
            }
        }

        // 否則使用本地URL
        return path;
    }

    // 重寫loadCustomers方法以支持模擬數據
    async loadCustomers() {
        try {
            // 檢查是否為分機模式
            const role = localStorage.getItem('hostRole') || 'master';
            const masterIp = localStorage.getItem('masterServerIp');

            if (role === 'client' && masterIp) {
                // 分機模式：從主服務器獲取數據
                console.log('分機模式：從主服務器獲取在場客人數據');

                // 構建查詢參數
                const params = new URLSearchParams();
                if (this.selectedStoreId) {
                    params.append('store_id', this.selectedStoreId);
                }

                // 構建API URL
                const apiPath = `/api/cashier/customers${params.toString() ? '?' + params.toString() : ''}`;
                const url = this.buildApiUrl(apiPath);

                console.log('從主服務器獲取客人數據，URL:', url);

                const response = await fetch(url);
                const result = await response.json();

                if (result.success) {
                    this.customers = result.customers;
                    this.displayCustomers();
                    this.updateCustomerCount();

                    // 保存真實客人用於模擬數據處理
                    const realCustomers = this.customers || [];

                    // 如果啟用模擬數據，則添加模擬數據
                    if (this.showMockData) {
                        // 生成模擬客人（如果尚未生成）
                        if (this.mockCustomers.length === 0) {
                            this.mockCustomers = this.generateMockCustomers();
                        }

                        // 合併真實客人和模擬客人
                        this.customers = [...realCustomers, ...this.mockCustomers];

                        // 更新顯示
                        this.displayCustomers();
                        this.updateCustomerCount();

                        // 只有在添加了模擬數據時才顯示訊息
                        if (this.alwaysShowMockData && this.mockCustomers.length > 0) {
                            this.addMessage(`顯示 ${realCustomers.length} 個真實桌號 + ${this.mockCustomers.length} 個模擬桌號`, 'info');
                        } else if (realCustomers.length === 0 && this.mockCustomers.length > 0) {
                            this.addMessage('正在顯示模擬桌號數據', 'info');
                        }
                    }

                    // 直接返回，跳過後續的父類調用
                    this.updateCustomerListConnectionWarning();
                    this.updateMergeSelectionUI();
                    return;
                } else {
                    throw new Error(result.error || '從主服務器獲取數據失敗');
                }
            }

            // 主機模式或未配置IP：調用父類方法獲取真實數據
            await super.loadCustomers();

            // 保存真實客人
            const realCustomers = this.customers || [];

            // 如果啟用模擬數據，則添加模擬數據
            if (this.showMockData) {
                // 生成模擬客人（如果尚未生成）
                if (this.mockCustomers.length === 0) {
                    this.mockCustomers = this.generateMockCustomers();
                }

                // 合併真實客人和模擬客人
                this.customers = [...realCustomers, ...this.mockCustomers];

                // 更新顯示
                this.displayCustomers();
                this.updateCustomerCount();

                // 只有在添加了模擬數據時才顯示訊息
                if (this.alwaysShowMockData && this.mockCustomers.length > 0) {
                    this.addMessage(`顯示 ${realCustomers.length} 個真實桌號 + ${this.mockCustomers.length} 個模擬桌號`, 'info');
                } else if (realCustomers.length === 0 && this.mockCustomers.length > 0) {
                    this.addMessage('正在顯示模擬桌號數據', 'info');
                }
            }
        } catch (error) {
            console.error('載入客人數據失敗:', error);
            // 如果API失敗但啟用模擬數據，則顯示模擬數據
            if (this.showMockData) {
                this.mockCustomers = this.generateMockCustomers();
                this.customers = this.mockCustomers;
                this.displayCustomers();
                this.updateCustomerCount();
                this.addMessage('載入真實數據失敗，正在顯示模擬桌號數據', 'warning');
            } else {
                this.addMessage('載入客人列表失敗: ' + error.message, 'error');
            }
        }

        // 更新連接警告顯示
        this.updateCustomerListConnectionWarning();
        this.updateMergeSelectionUI();
    }

    // 更新客人計數（覆蓋父類方法）
    updateCustomerCount() {
        // 先調用父類方法（如果存在）
        if (super.updateCustomerCount) {
            super.updateCustomerCount();
        }

        // 計算總組數和總人數
        const totalGroups = this.customers ? this.customers.length : 0;
        const totalPeople = this.customers ? this.customers.reduce((sum, customer) => {
            // 安全解析人數，默認1人
            const peopleCount = Number(customer.people_count);
            return sum + (isNaN(peopleCount) || peopleCount <= 0 ? 1 : peopleCount);
        }, 0) : 0;

        console.log(`updateCustomerCount: ${totalGroups} 組客人, ${totalPeople} 位客人`);

        // 更新顯示文本
        const statsElement = document.getElementById('total-customers-stats');
        if (statsElement) {
            statsElement.textContent = `總計: ${totalGroups} 組客人 共 ${totalPeople} 位客人`;
        }
    }

    // 顯示模擬顧客詳情
    displayMockCustomerDetail(customer) {
        const detailElement = document.getElementById('customer-detail');
        const modalDetailElement = document.getElementById('customer-modal-info');
        const modalEmptyState = document.getElementById('customer-modal-empty-state');
        const modalContent = document.getElementById('customer-modal-info');

        const entryTime = this.parseEntryTime(customer.entry_time);
        const formattedTime = entryTime.toLocaleTimeString('zh-TW', {
            hour: '2-digit',
            minute: '2-digit'
        });
        const formattedDate = entryTime.toLocaleDateString('zh-TW');

        // 顯示儲物柜號碼
        const lockersText = customer.lockers && customer.lockers.length > 0
            ? customer.lockers.join(', ')
            : '無';

        const customerDetailHTML = `
            <div class="customer-detail-header">
                <h3><i class="fas fa-user"></i> 桌號 ${customer.table_number}</h3>
                <span class="status-badge">在場</span>
            </div>
            <div class="customer-detail-info">
                ${customer.id && this.customerNotes && this.customerNotes[customer.id] ? `
                <div class="info-row note-row">
                    <span class="label">備註:</span>
                    <span class="value note-text">${this._escapeHtml(this.customerNotes[customer.id])}</span>
                </div>` : ''}
                <div class="info-row">
                    <span class="label">入場時間:</span>
                    <span class="value">${formattedDate} ${formattedTime}</span>
                </div>
                <div class="info-row">
                    <span class="label">人數:</span>
                    <span class="value">${customer.people_count} 位</span>
                </div>
                <div class="info-row">
                    <span class="label">消費金額:</span>
                    <span class="value">$${customer.total_amount}</span>
                </div>
                <div class="info-row">
                    <span class="label">會員狀態:</span>
                    <span class="value">${customer.is_member ? '會員' : '非會員'}</span>
                </div>
                <div class="info-row">
                    <span class="label">儲物柜:</span>
                    <span class="value">${lockersText}</span>
                </div>
            </div>
        `;

        // 更新原始客人詳情面板
        if (detailElement) {
            detailElement.innerHTML = customerDetailHTML;
        }

        // 更新模態框客人詳情
        if (modalDetailElement) {
            modalDetailElement.innerHTML = customerDetailHTML;
            // 顯示客人詳情內容，隱藏空白狀態
            if (modalEmptyState) {
                modalEmptyState.classList.add('hidden');
            }
            modalDetailElement.classList.remove('hidden');
        }
    }

    // 顯示模擬QR Code
    displayMockQRCode(customer) {
        const qrCodeElement = document.getElementById('customer-qr-code');
        const modalQrPlaceholder = document.getElementById('customer-modal-qr-placeholder');
        const modalQrSection = document.getElementById('customer-modal-qr-section');

        // 生成簡單的模擬QR Code顯示
        const mockQrHTML = `
            <div class="mock-qr-code">
                <div class="mock-qr-grid">
                    <div class="mock-qr-title">模擬QR Code</div>
                    <div class="mock-qr-content">桌號: ${customer.table_number}</div>
                    <div class="mock-qr-content">ID: ${customer.id}</div>
                    <div class="mock-qr-note">(模擬數據 - 僅供測試)</div>
                </div>
            </div>
        `;

        // 更新原始QR Code面板
        if (qrCodeElement) {
            qrCodeElement.innerHTML = mockQrHTML;
        }

        // 更新模態框QR Code
        if (modalQrPlaceholder) {
            modalQrPlaceholder.innerHTML = mockQrHTML;
            // 顯示QR Code區域
            if (modalQrSection) {
                modalQrSection.classList.remove('hidden');
            }
        }
    }

    // 顯示模擬訂單項目
    displayMockOrderItems(customerId) {
        const orderItemsContainer = document.getElementById('order-items');
        const modalOrderItemsContainer = document.getElementById('modal-order-items');
        if (!orderItemsContainer && !modalOrderItemsContainer) return;

        // 生成一些模擬訂單項目
        const mockProducts = [
            { name: '美式咖啡', price: 80, quantity: 1 },
            { name: '巧克力蛋糕', price: 150, quantity: 1 },
            { name: '奶茶', price: 90, quantity: 2 },
            { name: '小魚乾', price: 100, quantity: 1 }
        ];

        // 清空容器
        if (orderItemsContainer) orderItemsContainer.innerHTML = '';
        if (modalOrderItemsContainer) modalOrderItemsContainer.innerHTML = '';

        // 隱藏模態框中的空白狀態
        if (modalOrderItemsContainer) {
            const modalEmptyState = modalOrderItemsContainer.querySelector('.empty-state');
            if (modalEmptyState) modalEmptyState.classList.add('hidden');
        }

        // 存儲模擬產品數據以便後續更新
        const mockItems = [...mockProducts];

        // 更新總計函數
        const updateMockTotals = () => {
            const totalItems = mockItems.reduce((sum, product) => sum + product.quantity, 0);
            const totalAmount = mockItems.reduce((sum, product) => sum + (product.price * product.quantity), 0);

            // 更新原始面板總計
            const itemCountEl = document.getElementById('item-count');
            const orderTotalEl = document.getElementById('order-total');
            if (itemCountEl) itemCountEl.textContent = totalItems;
            if (orderTotalEl) orderTotalEl.textContent = `$${totalAmount}`;

            // 更新模態框總計
            const modalItemCountEl = document.getElementById('modal-item-count');
            const modalOrderTotalEl = document.getElementById('modal-order-total');
            if (modalItemCountEl) modalItemCountEl.textContent = totalItems;
            if (modalOrderTotalEl) modalOrderTotalEl.textContent = `$${totalAmount}`;

            // 顯示或隱藏模態框空白狀態
            if (modalOrderItemsContainer) {
                const modalEmptyState = modalOrderItemsContainer.querySelector('.empty-state');
                if (modalEmptyState) {
                    if (mockItems.length === 0) {
                        modalEmptyState.classList.remove('hidden');
                    } else {
                        modalEmptyState.classList.add('hidden');
                    }
                }
            }

            // 如果沒有項目，禁用按鈕
            const checkoutBtn = document.getElementById('checkout-btn');
            const clearOrderBtn = document.getElementById('clear-order-btn');
            const modalCheckoutBtn = document.getElementById('modal-checkout-btn');
            const modalDeleteTableBtn = document.getElementById('modal-delete-table-btn');
            if (checkoutBtn) checkoutBtn.disabled = mockItems.length === 0;
            if (clearOrderBtn) clearOrderBtn.disabled = mockItems.length === 0;
            if (modalCheckoutBtn) modalCheckoutBtn.disabled = mockItems.length === 0;
            if (modalDeleteTableBtn) modalDeleteTableBtn.disabled = mockItems.length === 0;
        };

        // 創建訂單項目的輔助函數
        const createOrderItemElement = (product, index, isModal = false) => {
            const itemEl = document.createElement('div');
            itemEl.className = 'order-item';
            itemEl.innerHTML = `
                <span class="order-item-name">${product.name}</span>
                <span class="order-item-qty">x${product.quantity}</span>
                <span class="order-item-price">$${product.price * product.quantity}</span>
                <button class="order-item-remove" data-mock-index="${index}" data-is-modal="${isModal}">
                    <i class="fas fa-trash"></i>
                </button>
            `;
            return itemEl;
        };

        // 為原始面板創建訂單項目
        if (orderItemsContainer) {
            mockItems.forEach((product, index) => {
                const itemEl = createOrderItemElement(product, index, false);
                orderItemsContainer.appendChild(itemEl);

                // 添加刪除事件監聽器
                const removeBtn = itemEl.querySelector('.order-item-remove');
                if (removeBtn) {
                    removeBtn.addEventListener('click', () => {
                        mockItems.splice(index, 1);
                        itemEl.remove();
                        // 也需要移除模態框中的對應項目
                        const modalItem = modalOrderItemsContainer?.querySelector(`[data-mock-index="${index}"][data-is-modal="true"]`);
                        if (modalItem) modalItem.remove();
                        updateMockTotals();
                    });
                }
            });
        }

        // 為模態框創建訂單項目
        if (modalOrderItemsContainer) {
            mockItems.forEach((product, index) => {
                const itemEl = createOrderItemElement(product, index, true);
                modalOrderItemsContainer.appendChild(itemEl);

                // 添加刪除事件監聽器
                const removeBtn = itemEl.querySelector('.order-item-remove');
                if (removeBtn) {
                    removeBtn.addEventListener('click', () => {
                        mockItems.splice(index, 1);
                        itemEl.remove();
                        // 也需要移除原始面板中的對應項目
                        const originalItem = orderItemsContainer?.querySelector(`[data-mock-index="${index}"][data-is-modal="false"]`);
                        if (originalItem) originalItem.remove();
                        updateMockTotals();
                    });
                }
            });
        }

        // 初始化總計
        updateMockTotals();

    }

    // 覆蓋基類的staffLogin方法，改用增強登入模態框
    staffLogin() {
        this.showLoginModal();
    }

    checkSavedLogin() {
        console.log('checkSavedLogin called');
        // 如果已經認證（例如剛登入），直接返回 true，避免覆蓋現有認證狀態
        if (this.isAuthenticated && this.currentToken && this.currentEmployee) {
            console.log(`checkSavedLogin: 已認證狀態，跳過本地存儲檢查，employee=${this.currentEmployee?.full_name}`);
            return true;
        }
        try {
            const savedToken = localStorage.getItem('cashier_token');
            const savedEmployee = localStorage.getItem('cashier_employee');
            const savedExpires = localStorage.getItem('cashier_token_expires');

            console.log(`checkSavedLogin: 檢查本地存儲: token=${!!savedToken}, employee=${!!savedEmployee}, expires=${!!savedExpires}`);

            if (savedToken && savedEmployee && savedExpires) {
                const expiresAt = new Date(savedExpires);
                console.log(`checkSavedLogin: 令牌過期時間: ${expiresAt}, 當前時間: ${new Date()}`);
                if (expiresAt > new Date()) {
                    // 令牌尚未過期
                    this.currentToken = savedToken;
                    this.currentEmployee = JSON.parse(savedEmployee);
                    this.tokenExpiresAt = expiresAt;
                    this.isAuthenticated = true;

                    console.log(`checkSavedLogin: 令牌有效，設置 isAuthenticated=true, employee=${this.currentEmployee?.full_name}`);

                    // 更新UI
                    this.updateEmployeeUI();
                    this.addMessage(`歡迎回來，${this.currentEmployee.full_name}`, 'success');
                    return true;
                } else {
                    // 令牌已過期，清除保存的登入信息
                    console.log('checkSavedLogin: 令牌已過期，清除保存的登入信息');
                    this.clearSavedLogin();
                    this.isAuthenticated = false;
                }
            } else {
                console.log('checkSavedLogin: 沒有保存的登入信息或信息不完整');
                this.isAuthenticated = false;
            }
        } catch (error) {
            console.error('檢查保存的登入狀態時出錯:', error);
            this.clearSavedLogin();
            this.isAuthenticated = false;
        }
        console.log(`checkSavedLogin: 返回 false, isAuthenticated=${this.isAuthenticated}`);
        return false;
    }

    clearSavedLogin() {
        localStorage.removeItem('cashier_token');
        localStorage.removeItem('cashier_employee');
        localStorage.removeItem('cashier_token_expires');
    }

    saveLoginToStorage(token, employee, expiresAt) {
        if (this.rememberMe) {
            localStorage.setItem('cashier_token', token);
            localStorage.setItem('cashier_employee', JSON.stringify(employee));
            localStorage.setItem('cashier_token_expires', expiresAt.toISOString());
        } else {
            // 不記住登入信息，不保存到任何存儲
            // 這裡什麼都不做，讓令牌僅存在於內存中
        }
    }

    clearSessionStorage() {
        sessionStorage.removeItem('cashier_token');
        sessionStorage.removeItem('cashier_employee');
        sessionStorage.removeItem('cashier_token_expires');
    }

    clearAllLoginStorage() {
        // 清除所有登入相關的存儲
        localStorage.removeItem('cashier_token');
        localStorage.removeItem('cashier_employee');
        localStorage.removeItem('cashier_token_expires');
        sessionStorage.removeItem('cashier_token');
        sessionStorage.removeItem('cashier_employee');
        sessionStorage.removeItem('cashier_token_expires');
    }

    showLoginModal() {
        console.log('showLoginModal called');

        // 確保同步進度條已隱藏
        if (this._syncModalShown) {
            console.log('同步進度條仍在顯示，先隱藏它');
            this.hideSyncProgressModal();
        }

        // 檢查登入模態框元素是否存在
        const loginModal = document.getElementById('login-modal');
        const loginForm = document.getElementById('login-form');

        if (!loginModal) {
            console.error('showLoginModal: 找不到 #login-modal 元素');
            return;
        }

        if (!loginForm) {
            console.error('showLoginModal: 找不到 #login-form 元素');
            return;
        }

        console.log('showLoginModal: 找到登入模態框元素');

        // 重置表單
        loginForm.reset();
        loginModal.classList.remove('hidden');
        // 添加類到body以便樣式化背景內容
        document.body.classList.add('login-modal-visible');

        // 如果未登入，隱藏取消按鈕
        if (!this.isAuthenticated) {
            const cancelBtn = document.getElementById('cancel-login-btn');
            if (cancelBtn) cancelBtn.style.display = 'none';
        } else {
            // 已登入狀態下顯示取消按鈕（例如切換帳戶時）
            const cancelBtn = document.getElementById('cancel-login-btn');
            if (cancelBtn) cancelBtn.style.display = '';
        }

        console.log('showLoginModal: 登入模態框已顯示');
    }

    hideLoginModal() {
        document.getElementById('login-modal').classList.add('hidden');
        // 移除body類
        document.body.classList.remove('login-modal-visible');
    }

    async handleLoginSubmit(event) {
        console.log('handleLoginSubmit called, event:', event.type);
        event.preventDefault();

        const username = document.getElementById('login-username').value.trim();
        const password = document.getElementById('login-password').value;
        this.rememberMe = false; // 強制不記住登入信息

        console.log('Login attempt:', { username, passwordLength: password.length, rememberMe: this.rememberMe });

        if (!username || !password) {
            this.addMessage('請輸入用戶名和密碼', 'warning');
            return;
        }

        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include',
                body: JSON.stringify({
                    username,
                    password
                })
            });

            console.log('Login response status:', response.status);
            const result = await response.json();
            console.log('Login response:', result);

            if (result.success) {
                // 保存登入信息
                this.currentToken = result.data.token;
                this.currentEmployee = result.data.employee;
                this.tokenExpiresAt = new Date(result.data.expires_at);
                this.isAuthenticated = true;

                // 保存到存儲
                this.saveLoginToStorage(this.currentToken, this.currentEmployee, this.tokenExpiresAt);

                // 調試：打印員工信息
                console.log('登入成功的員工信息:', this.currentEmployee);
                console.log('員工store_id:', this.currentEmployee.store_id);
                console.log('員工角色:', this.currentEmployee.role);
                console.log('員工全名:', this.currentEmployee.full_name);

                // 更新UI
                this.updateEmployeeUI();
                this.hideLoginModal();
                this.addMessage(`登入成功，歡迎 ${this.currentEmployee.full_name}`, 'success');

                // 如果是員工(staff)級別登入，自動選擇所屬分店並限制轉換
                if (this.currentEmployee.role === 'staff' && this.currentEmployee.store_id) {
                    console.log(`員工(staff)登入，自動設置分店ID: ${this.currentEmployee.store_id}`);
                    this.selectedStoreId = this.currentEmployee.store_id;

                    // 禁用分店選擇器
                    const storeSelector = document.getElementById('store-selector');
                    if (storeSelector) {
                        storeSelector.disabled = true;
                        storeSelector.style.opacity = '0.5';
                        console.log('已禁用分店選擇器（員工級別）');
                    }

                    // 加載可訪問分店（應該只包含員工所屬分店）
                    await this.loadAccessibleStores();
                } else {
                    // 管理員或無分店的員工，正常加載所有可訪問分店
                    await this.loadAccessibleStores();
                }

                // 啟用所有標籤頁
                this.initTabs(); // 這將調用 showAuthenticatedUI()

                // 重置 settings tab 分店選擇（logout->relogin 後）
                var stSelect = document.getElementById('settingsStoreSelect');
                if (stSelect) { stSelect.disabled = false; stSelect.value = ''; }

                // 載入儀表板數據
                this.loadDashboardData();

                // 登入後同步主數據
                console.log('開始登入後數據同步...');
                this.syncMasterData().catch(error => {
                    console.warn('登入後數據同步失敗，繼續使用本地數據:', error.message);
                });
            } else {
                this.addMessage(`登入失敗: ${result.message}`, 'error');
            }
        } catch (error) {
            this.addMessage(`登入請求失敗: ${error.message}`, 'error');
        }
    }

    async logout() {
        if (!this.currentToken) {
            this.clearLoginState();
            return;
        }

        try {
            const response = await fetch('/api/auth/logout', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                }
            });

            // 無論登出API是否成功，都清除本地狀態
            this.clearLoginState();

            if (response.ok) {
                const result = await response.json();
                if (result.success) {
                    this.addMessage('已成功登出', 'success');
                }
            }
        } catch (error) {
            console.error('登出請求失敗:', error);
            this.addMessage('已登出（本地）', 'info');
        }
    }

    clearLoginState() {
        this.currentToken = null;
        this.currentEmployee = null;
        this.tokenExpiresAt = null;
        this.isAuthenticated = false;
        this.rememberMe = false;

        // 重置分店選擇
        this.selectedStoreId = '';
        this._capData = null;

        // 清除所有存儲
        this.clearSavedLogin();
        this.clearSessionStorage();

        // 更新UI
        this.updateEmployeeUI();

        // 切換到未登入狀態的UI
        this.showUnauthenticatedUI();
    }

    updateEmployeeUI() {
        const staffNameElement = document.getElementById('staff-name');
        const loginBtn = document.getElementById('staff-login-btn');
        const logoutBtn = document.getElementById('logout-btn');
        const clearAllCustomersBtn = document.getElementById('clear-all-customers-btn');

        if (this.isAuthenticated && this.currentEmployee) {
            staffNameElement.textContent = `${this.currentEmployee.full_name} (${this.currentEmployee.role})`;
            loginBtn.disabled = true;
            loginBtn.style.opacity = '0.5';
            logoutBtn.disabled = false;
            logoutBtn.style.opacity = '1';

            // 只有管理員角色才能看到"清空所有桌號"按鈕
            if (clearAllCustomersBtn) {
                if (this.currentEmployee.role === 'admin') {
                    clearAllCustomersBtn.style.display = 'inline-block';
                } else {
                    clearAllCustomersBtn.style.display = 'none';
                }
            }

            // 更新機器主服務器設定卡片可見性 (只有管理員可見)
            const machineMasterConfigSection = document.getElementById('machine-master-config-section');
            if (machineMasterConfigSection) {
                if (this.currentEmployee.role === 'admin') {
                    machineMasterConfigSection.classList.remove('hidden');
                } else {
                    machineMasterConfigSection.classList.add('hidden');
                }
            }
        } else {
            staffNameElement.textContent = '未登入';
            loginBtn.disabled = false;
            loginBtn.style.opacity = '1';
            logoutBtn.disabled = true;
            logoutBtn.style.opacity = '0.5';

            // 未登入時隱藏"清空所有桌號"按鈕
            if (clearAllCustomersBtn) {
                clearAllCustomersBtn.style.display = 'none';
            }
        }
    }

    updateTranslations() {
        // 翻譯功能待實現
        // 目前系統使用固定繁體中文文本，此方法為占位符
        console.log('updateTranslations called - i18n feature not yet implemented');
    }

    showUnauthenticatedUI() {
        console.log('showUnauthenticatedUI called, disabling non-dashboard tabs');
        // 如果未登入，切換到儀表板標籤（唯讀模式）
        this.switchTab('dashboard');

        // 禁用所有需要身份驗證的標籤
        document.querySelectorAll('.tab-button').forEach(button => {
            const tabName = button.dataset.tab;
            if (tabName !== 'dashboard') {
                console.log(`Disabling tab button: ${tabName}`);
                button.disabled = true;
                button.style.opacity = '0.5';
                // 如果是員工管理標籤，直接隱藏
                if (tabName === 'employee-management') {
                    button.style.display = 'none';
                }
            }
        });

        // 顯示登入模態框並隱藏取消按鈕
        this.showLoginModal();
        const cancelBtn = document.getElementById('cancel-login-btn');
        if (cancelBtn) cancelBtn.style.display = 'none';
    }

    showAuthenticatedUI() {
        console.log('showAuthenticatedUI called, enabling all tabs');
        const isAdmin = this.currentEmployee && this.currentEmployee.role === 'admin';
        console.log(`Current employee role: ${this.currentEmployee?.role}, isAdmin: ${isAdmin}`);
        console.log(`showAuthenticatedUI: selectedStoreId=${this.selectedStoreId}, accessibleStores.length=${this.accessibleStores?.length}`);

        // 如果可訪問分店已加載，重置重試計數器
        if (this.accessibleStores && this.accessibleStores.length > 0) {
            this.showAuthenticatedUIRetryCount = 0;
        }

        // 如果沒有可訪問分店或分店未加載，延遲處理
        if (!this.accessibleStores || this.accessibleStores.length === 0) {
            this.showAuthenticatedUIRetryCount++;
            console.log(`showAuthenticatedUI: 可訪問分店尚未加載，等待100ms後重試 (重試次數: ${this.showAuthenticatedUIRetryCount})`);

            // 防止無限重試（最多5次）
            if (this.showAuthenticatedUIRetryCount >= 5) {
                console.error('showAuthenticatedUI: 重試次數超過上限，停止重試。分店列表可能未加載。');
                console.log('showAuthenticatedUI: 繼續顯示UI（不基於分店過濾）');
                // 仍然顯示UI，但不基於分店過濾
                this.showAuthenticatedUIRetryCount = 0; // 重置計數器
            } else {
                setTimeout(() => {
                    console.log('showAuthenticatedUI: 延遲後重新檢查');
                    this.showAuthenticatedUI();
                }, 100);
                return;
            }
        }

        // 根據分店選擇更新分頁顯示
        if (this.selectedStoreId) {
            console.log(`showAuthenticatedUI: 更新分頁顯示基於分店 ${this.selectedStoreId}`);
            this.updateTabsBasedOnStore(this.selectedStoreId);
        } else {
            console.log('showAuthenticatedUI: 沒有選擇分店，使用默認分頁邏輯');

            // 啟用所有標籤
            document.querySelectorAll('.tab-button').forEach(button => {
                const tabName = button.dataset.tab;
                console.log(`Processing tab button: ${tabName}`);

                // 如果是員工管理標籤且不是管理員，則隱藏
                if (tabName === 'employee-management') {
                    if (!isAdmin) {
                        console.log('Hiding employee-management tab (non-admin user)');
                        button.style.display = 'none';
                        return;
                    } else {
                        console.log('Showing employee-management tab (admin user)');
                        button.style.display = '';
                    }
                }

                // 啟用標籤
                button.disabled = false;
                button.style.opacity = '1';
                button.removeAttribute('disabled');
                button.style.cursor = 'pointer';
            });
        }

        // 隱藏非管理員的商品管理按鈕
        this.hideProductManagementButtonsIfNotAdmin(isAdmin);
    }



    loadBookingInternal(skipProxy) {
        if (skipProxy === undefined) skipProxy = false;  // 全部經 aliyun-proxy
        var container = document.getElementById('bookingTabContent');
        if (!container) return;
        container.innerHTML = '<div style="text-align:center;padding:20px;color:#999;">載入中...</div>';
        var storeId = document.getElementById('bookingStoreFilter')?.value || '';
        var date = document.getElementById('bookingDateFilter')?.value || '';
        var phone = document.getElementById('bookingPhoneFilter')?.value || '';
        if (!date) {
            var d = new Date();
            date = d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
            var di = document.getElementById('bookingDateFilter');
            if (di) di.value = date;
        }
        var self = this;
        var url = skipProxy ? window.location.origin + '/api/booking/list?' : window.location.origin + '/api/aliyun-proxy/booking/list?';
        if (storeId) url += 'store_id=' + encodeURIComponent(storeId) + '&';
        url += 'date=' + encodeURIComponent(date) + '&';
        if (phone) url += 'phone=' + encodeURIComponent(phone) + '&';
        // 用 XMLHttpRequest + overrideMimeType 確保文字編碼正確
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.overrideMimeType('text/plain; charset=utf-8');
        xhr.setRequestHeader('x-api-key', '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763');
        xhr.onload = function() {
            if (xhr.status >= 400) {
                container.innerHTML = '<div style="text-align:center;padding:30px;color:#C62828;">❌ 無法連線阿里雲</div>';
                self.showOfflineModal();
                return;
            }
            try {
                var txt = xhr.responseText;
                var result = JSON.parse(txt);
                if (result && result.success) {
                    self._bookingData = result.data;
                    self.renderBookingTabInternal();
                    if (result.warning || result.source === 'offline-cache') {
                        self.showOfflineModal();
                    }
                } else {
                    container.innerHTML = '<div style="text-align:center;padding:30px;color:#C62828;">❌ ' + (result.error || '載入失敗') + '</div>';
                }
            } catch(e) {
                container.innerHTML = '<div style="text-align:center;padding:30px;color:#C62828;">❌ ' + e.message + ' | ' + xhr.responseText.slice(0,80) + '</div>';
            }
        };
        xhr.onerror = function() {
            container.innerHTML = '<div style="text-align:center;padding:30px;color:#C62828;">❌ 無法連線伺服器</div>';
            self.showOfflineModal();
        };
        xhr.send();
        self.loadPausedStatus();
    }

    addTime(timeStr, minutes) {
        var parts = timeStr.split(':');
        var h = parseInt(parts[0]), m = parseInt(parts[1]) + minutes;
        while (m >= 60) { h++; m -= 60; }
        return String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0');
    }

    updateBookingStats() {
        var now = new Date();
        var nowStr = String(now.getHours()).padStart(2,'0') + ':' + String(now.getMinutes()).padStart(2,'0');
        // 預約統計 (confirmed)
        var bookings = this._bookingData || [];
        var confirmedItems = bookings.filter(function(b){ return b.status === 'confirmed'; });
        var c30min = 0, p30min = 0, c1hr = 0, p1hr = 0;
        for (var bi = 0; bi < confirmedItems.length; bi++) {
            var bt = confirmedItems[bi].booking_time;
            if (bt >= nowStr && bt <= this.addTime(nowStr, 30)) { c30min++; p30min += (confirmedItems[bi].adults||0) + (confirmedItems[bi].children||0); }
            if (bt >= nowStr && bt <= this.addTime(nowStr, 60)) { c1hr++; p1hr += (confirmedItems[bi].adults||0) + (confirmedItems[bi].children||0); }
        }
        // 候位統計 (waiting + contacted 計入 30分鐘內)
        var waitingItems = this._waitingData || [];
        var waitingActive = waitingItems.filter(function(b){ return b.status === 'waiting' || b.status === 'contacted' || b.status === 'confirmed'; });
        c30min += waitingActive.length;
        for (var wi = 0; wi < waitingActive.length; wi++) {
            p30min += (waitingActive[wi].adults||0) + (waitingActive[wi].children||0);
        }
        c1hr += waitingActive.length;
        for (var wi2 = 0; wi2 < waitingActive.length; wi2++) {
            p1hr += (waitingActive[wi2].adults||0) + (waitingActive[wi2].children||0);
        }
        if (document.getElementById('book30minCount')) document.getElementById('book30minCount').textContent = c30min;
        if (document.getElementById('book30minPeople')) document.getElementById('book30minPeople').textContent = p30min;
        if (document.getElementById('book1hrCount')) document.getElementById('book1hrCount').textContent = c1hr;
        if (document.getElementById('book1hrPeople')) document.getElementById('book1hrPeople').textContent = p1hr;
        // 候位 pending 數字
        var pendingCount = waitingItems.filter(function(b){ return b.status === 'waiting' || b.status === 'contacted'; }).length;
        if (document.getElementById('waitingPendingCount')) document.getElementById('waitingPendingCount').textContent = pendingCount;
    }

    renderBookingTabInternal() {
        if (!this._bookingSubTab) this._bookingSubTab = 'confirmed';
        var bookings = this._bookingData || [];
        var subTab = this._bookingSubTab;
        var filtered = subTab === 'all' ? bookings : bookings.filter(function(b){ return b.status === subTab; });
        var storeNames = { 'store_1': '荃灣店', 'store_2': '尖沙咀店', 'store_3': '旺角店', 'store_4': '銅鑼灣店' };
        var statusLabels = { 'confirmed': '已預約', 'arrived': '已入座', 'cancelled': '已取消' };
        var total = bookings.length;
        var confirmed = bookings.filter(function(b){ return b.status === 'confirmed'; }).length;
        var arrived = bookings.filter(function(b){ return b.status === 'arrived'; }).length;
        var cancelled = bookings.filter(function(b){ return b.status === 'cancelled'; }).length;
        if (document.getElementById('bookingStatTotal')) document.getElementById('bookingStatTotal').textContent = total;
        if (document.getElementById('bookingStatConfirmed')) document.getElementById('bookingStatConfirmed').textContent = confirmed;
        if (document.getElementById('bookingStatArrived')) document.getElementById('bookingStatArrived').textContent = arrived;
        if (document.getElementById('bookingStatCancelled')) document.getElementById('bookingStatCancelled').textContent = cancelled;
        // 更新即將到來統計
        this.updateBookingStats();
        // 更新 sub-tab 高亮
        document.querySelectorAll('.booking-sub-tab').forEach(function(btn) {
            var t = btn.getAttribute('data-btab');
            btn.classList.toggle('active', t === subTab);
        });
        var container = document.getElementById('bookingTabContent');
        if (!container) return;
        if (filtered.length === 0) {
            container.innerHTML = '<div style="text-align:center;padding:30px;color:#999;">📭 沒有找到預約記錄</div>';
            return;
        }
        var html = '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;background:white;border-radius:8px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.08);">';
        html += '<thead><tr style="background:#D2B48C;color:#000;">';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">時間</th>';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">分店</th>';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">桌號</th>';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">人數</th>';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">電話</th>';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">備註</th>';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">語言</th>';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">狀態</th>';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">操作</th>';
        html += '</tr></thead><tbody>';
        for (var i = 0; i < filtered.length; i++) {
            var b = filtered[i];
            var tp = (b.adults||0) + (b.children||0);
            var ph = this.formatPhone(b.phone);
            var sb = '';
            if (b.status === 'confirmed') sb = 'background:#E3F2FD;color:#1565C0;';
            else if (b.status === 'arrived') sb = 'background:#E8F5E9;color:#2E7D32;';
            else if (b.status === 'cancelled') sb = 'background:#FFEBEE;color:#C62828;';
            html += '<tr style="border-bottom:1px solid #eee;">';
            html += '<td style="padding:8px 10px;font-size:19px;"><strong>' + b.booking_time + '</strong></td>';
            html += '<td style="padding:8px 10px;font-size:19px;">' + (storeNames[b.store_id]||b.store_id) + '</td>';
            html += '<td style="padding:8px 10px;font-size:19px;">' + (b.table_number ? b.table_number : '-') + '</td>';
            html += '<td style="padding:8px 10px;font-size:19px;">' + tp + ' 人<br><span style="font-size:16px;color:#888;">大 ' + (b.adults||0) + ' · 小 ' + (b.children||0) + '</span></td>';
            html += '<td style="padding:8px 10px;font-size:19px;">' + ph + '</td>';
            html += '<td style="padding:8px 10px;font-size:14px;max-width:100px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + (b.notes||'-') + '</td>';
            html += '<td style="padding:8px 10px;font-size:19px;">' + (b.lang||'zh-TW') + '</td>';
            html += '<td style="padding:8px 10px;font-size:19px;"><span style="display:inline-block;padding:4px 12px;border-radius:12px;font-size:22px;font-weight:600;' + sb + '">' + (statusLabels[b.status]||b.status) + '</span></td>';
            html += '<td style="padding:8px 10px;font-size:19px;">' + this.getBookingActionInternal(b) + '</td>';
            html += '</tr>';
        }
        html += '</tbody></table></div>';
        container.innerHTML = html;
    }

    loadWaitinglistInternal(skipProxy) {
        if (skipProxy === undefined) skipProxy = false;  // 全部經 aliyun-proxy
        var container = document.getElementById('waitinglistContent');
        if (!container) return;
        container.innerHTML = '<div style="text-align:center;padding:20px;color:#999;">載入中...</div>';
        var storeId = document.getElementById('waitingStoreFilter')?.value || '';
        var url = skipProxy ? window.location.origin + '/api/waitinglist?' : window.location.origin + '/api/aliyun-proxy/waitinglist?';
        if (storeId) url += 'store_id=' + encodeURIComponent(storeId) + '&';
        var self = this;
        if (!this._waitingReqId) this._waitingReqId = 0;
        var myReqId = ++this._waitingReqId;
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.overrideMimeType('text/plain; charset=utf-8');
        xhr.setRequestHeader('x-api-key', '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763');
        xhr.onload = function() {
            if (xhr.status >= 400) {
                if (myReqId !== self._waitingReqId) return;
                container.innerHTML = '<div style="text-align:center;padding:30px;color:#C62828;">❌ 無法連線阿里雲</div>';
                self.showOfflineModal();
                return;
            }
            try {
                var txt = xhr.responseText;
                var result = JSON.parse(txt);
                if (result && result.success) {
                    if (myReqId === self._waitingReqId) {
                        self._waitingData = result.data || [];
                        self.renderWaitinglistInternal();
                        if (result.warning || result.source === 'offline-cache') {
                            self.showOfflineModal();
                        }
                    }
                } else {
                    if (myReqId === self._waitingReqId) {
                        container.innerHTML = '<div style="text-align:center;padding:30px;color:#C62828;">❌ ' + (result.error || '載入失敗') + '</div>';
                    }
                }
            } catch(e) {
                if (myReqId === self._waitingReqId) {
                    container.innerHTML = '<div style="text-align:center;padding:30px;color:#C62828;">❌ ' + e.message + ' | ' + xhr.responseText.slice(0,80) + '</div>';
                }
            }
        };
        xhr.onerror = function() {
            if (myReqId === self._waitingReqId) {
                container.innerHTML = '<div style="text-align:center;padding:30px;color:#C62828;">❌ 無法連線伺服器</div>';
                self.showOfflineModal();
            }
        };
        xhr.send();
    }

    renderWaitinglistInternal() {
        if (!this._waitingSubTab) this._waitingSubTab = 'waiting';
        var items = this._waitingData || [];
        var subTab = this._waitingSubTab;
        var filtered = subTab === 'all' ? items : (subTab === 'waiting' ? items.filter(function(b){ return b.status === 'waiting' || b.status === 'contacted'; }) : items.filter(function(b){ return b.status === subTab; }));
        var total = items.length;
        var waiting = items.filter(function(b){ return b.status === 'waiting' || b.status === 'contacted'; }).length;
        var confirmed = items.filter(function(b){ return b.status === 'confirmed'; }).length;
        var arrived = items.filter(function(b){ return b.status === 'arrived'; }).length;
        var cancelled = items.filter(function(b){ return b.status === 'cancelled'; }).length;
        if (document.getElementById('waitingStatTotal')) document.getElementById('waitingStatTotal').textContent = total;
        if (document.getElementById('waitingStatWaiting')) document.getElementById('waitingStatWaiting').textContent = waiting;
        if (document.getElementById('waitingStatConfirmed')) document.getElementById('waitingStatConfirmed').textContent = confirmed;
        if (document.getElementById('waitingStatArrived')) document.getElementById('waitingStatArrived').textContent = arrived;
        if (document.getElementById('waitingStatCancelled')) document.getElementById('waitingStatCancelled').textContent = cancelled;
        this.updateBookingStats();
        // 更新 sub-tab 高亮
        document.querySelectorAll('.waiting-sub-tab').forEach(function(btn) {
            var t = btn.getAttribute('data-wtab');
            btn.classList.toggle('active', t === subTab);
        });
        var container = document.getElementById('waitinglistContent');
        if (!container) return;
        if (filtered.length === 0) {
            container.innerHTML = '<div style="text-align:center;padding:30px;color:#999;">📭 沒有候位記錄</div>';
            return;
        }
        var storeNames = { 'store_1': '荃灣店', 'store_2': '尖沙咀店', 'store_3': '旺角店', 'store_4': '銅鑼灣店' };
        var statusLabels = { 'waiting': '候位中', 'contacted': '已聯絡', 'confirmed': '已確認', 'arrived': '已入座', 'cancelled': '已取消' };
        var statusColors = { 'waiting': 'background:#FFF3E0;color:#E65100;', 'contacted': 'background:#E3F2FD;color:#1565C0;', 'confirmed': 'background:#E8F5E9;color:#2E7D32;', 'arrived': 'background:#E8F5E9;color:#2E7D32;', 'cancelled': 'background:#FFEBEE;color:#C62828;' };
        var html = '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;background:white;border-radius:8px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.08);">';
        html += '<thead><tr style="background:#D2B48C;color:#000;">';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">時間</th>';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">分店</th>';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">桌號</th>';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">人數</th>';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">電話</th>';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">語言</th>';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">備註</th>';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">狀態</th>';
        html += '<th style="padding:8px 10px;font-size:13px;text-align:left;">操作</th>';
        html += '</tr></thead><tbody>';
        for (var i = 0; i < filtered.length; i++) {
            var b = filtered[i];
            var tp = (b.adults||0) + (b.children||0);
            var ph = this.formatPhone(b.phone);
            var st = b.status || 'waiting';
            var created = b.created_at ? b.created_at.slice(11,16) : '-';
            // 計算狀態維持時間（由 status 改變到現在）
            var statusStartStr = b.created_at || '';
            if (st === 'contacted' && b.updated_at) statusStartStr = b.updated_at;
            var elapsed = '00:00';
            if (statusStartStr) {
                var parts = statusStartStr.split(/[T ]/);
                var timePart = parts.length > 1 ? parts[1] : parts[0];
                var tm = timePart.split(':');
                var startMin = parseInt(tm[0])*60 + parseInt(tm[1]);
                var now = new Date();
                var nowMin = now.getHours()*60 + now.getMinutes();
                var diff = nowMin - startMin;
                if (diff < 0) diff += 1440;
                elapsed = String(Math.floor(diff/60)).padStart(2,'0') + ':' + String(diff%60).padStart(2,'0');
            }
            html += '<tr style="border-bottom:1px solid #eee;">';
            html += '<td style="padding:8px 10px;font-size:19px;"><strong>' + created + '</strong></td>';
            html += '<td style="padding:8px 10px;font-size:19px;">' + (storeNames[b.store_id]||b.store_id) + '</td>';
            html += '<td style="padding:8px 10px;font-size:19px;">' + (b.table_number ? b.table_number : '-') + '</td>';
            html += '<td style="padding:8px 10px;font-size:19px;">' + tp + ' 人<br><span style="font-size:16px;color:#888;">大 ' + (b.adults||0) + ' · 小 ' + (b.children||0) + '</span></td>';
            html += '<td style="padding:8px 10px;font-size:19px;">' + ph + '</td>';
            html += '<td style="padding:8px 10px;font-size:19px;">' + (b.lang||'zh-TW') + '</td>';
            html += '<td style="padding:8px 10px;font-size:14px;max-width:100px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + (b.notes||'-') + '</td>';
            html += '<td style="padding:8px 10px;font-size:19px;"><span style="display:inline-block;padding:4px 12px;border-radius:12px;font-size:22px;font-weight:600;' + (statusColors[st]||'') + '">' + (statusLabels[st]||st) + '</span>' + (st === 'cancelled' || st === 'arrived' ? '' : '<br><span style="font-size:18px;font-weight:700;color:#000;text-align:center;display:block;">' + elapsed + '</span>') + '</td>';
            html += '<td style="padding:8px 10px;font-size:19px;">' + this.getWaitinglistAction(b) + '</td>';
            html += '</tr>';
        }
        html += '</tbody></table></div>';
        container.innerHTML = html;
    }

    showAddBookingModal() {
        var modal = document.getElementById('addBookingModal');
        if (!modal) return;
        var d = new Date();
        var dateStr = d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
        document.getElementById('addBkDate').value = dateStr;
        document.getElementById('addBkDate').min = dateStr;
        var storeFilter = document.getElementById('bookingStoreFilter');
        if (storeFilter && storeFilter.value) document.getElementById('addBkStore').value = storeFilter.value;
        document.getElementById('addBkError').style.display = 'none';
        this.populateEditTimeSlots(dateStr, '', 'addBkTime');
        modal.style.display = 'flex';
        modal.classList.remove('hidden');
    }

    closeAddBookingModal() {
        var modal = document.getElementById('addBookingModal');
        if (modal) { modal.style.display = 'none'; modal.classList.add('hidden'); }
    }

    saveAddBooking() {
        var storeId = document.getElementById('addBkStore')?.value;
        var date = document.getElementById('addBkDate')?.value;
        var time = document.getElementById('addBkTime')?.value;
        var adults = parseInt(document.getElementById('addBkAdults')?.value) || 2;
        var children = parseInt(document.getElementById('addBkChildren')?.value) || 0;
        var code = document.getElementById('addBkPhoneCode')?.value || '852';
        var rawPhone = document.getElementById('addBkPhone')?.value.trim() || '';
        var phone = code === '852' ? rawPhone : '+' + code + rawPhone;
        var notes = document.getElementById('addBkNotes')?.value.trim() || '';
        var lang = document.getElementById('addBkLang')?.value || 'zh-TW';
        var errEl = document.getElementById('addBkError');
        if (!storeId || !date || !time) { errEl.textContent = '請填寫完整資料'; errEl.style.display = 'block'; return; }
        if (!phone) { errEl.textContent = '請填寫電話'; errEl.style.display = 'block'; return; }
        errEl.style.display = 'none';
        var self = this;
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '/api/aliyun-proxy/booking', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.onload = function() {
            try {
                var r = JSON.parse(xhr.responseText);
                if (r.success) {
                    self.closeAddBookingModal();
                    self.loadBookingInternal();
                    alert('✅ 預約已新增');
                } else {
                    errEl.textContent = r.message || r.error || '新增失敗';
                    errEl.style.display = 'block';
                }
            } catch(e) { errEl.textContent = '伺服器錯誤'; errEl.style.display = 'block'; }
        };
        xhr.onerror = function() { errEl.textContent = '網絡錯誤'; errEl.style.display = 'block'; };
        xhr.send(JSON.stringify({ store_id: storeId, booking_date: date, booking_time: time, adults: adults, children: children, phone: phone, notes: notes, lang: lang }));
    }

    showAddWaitingModal() {
        var modal = document.getElementById('addWaitingModal');
        if (!modal) return;
        document.getElementById('addWtError').style.display = 'none';
        var storeFilter = document.getElementById('waitingStoreFilter');
        if (storeFilter && storeFilter.value) document.getElementById('addWtStore').value = storeFilter.value;
        modal.style.display = 'flex';
        modal.classList.remove('hidden');
    }

    closeAddWaitingModal() {
        var modal = document.getElementById('addWaitingModal');
        if (modal) { modal.style.display = 'none'; modal.classList.add('hidden'); }
    }

    saveAddWaiting() {
        var storeId = document.getElementById('addWtStore')?.value;
        var adults = parseInt(document.getElementById('addWtAdults')?.value) || 2;
        var children = parseInt(document.getElementById('addWtChildren')?.value) || 0;
        var code = document.getElementById('addWtPhoneCode')?.value || '852';
        var rawPhone = document.getElementById('addWtPhone')?.value.trim() || '';
        var phone = code === '852' ? rawPhone : '+' + code + rawPhone;
        var notes = document.getElementById('addWtNotes')?.value.trim() || '';
        var lang = document.getElementById('addWtLang')?.value || 'zh-TW';
        var errEl = document.getElementById('addWtError');
        if (!storeId) { errEl.textContent = '請選擇分店'; errEl.style.display = 'block'; return; }
        if (!phone) { errEl.textContent = '請填寫電話'; errEl.style.display = 'block'; return; }
        errEl.style.display = 'none';
        var self = this;
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '/api/aliyun-proxy/waitinglist', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.onload = function() {
            try {
                var r = JSON.parse(xhr.responseText);
                if (r.success) {
                    self.closeAddWaitingModal();
                    self.loadWaitinglistInternal();
                    alert('✅ 候位已新增');
                } else {
                    errEl.textContent = r.message || r.error || '新增失敗';
                    errEl.style.display = 'block';
                }
            } catch(e) { errEl.textContent = '伺服器錯誤'; errEl.style.display = 'block'; }
        };
        xhr.onerror = function() { errEl.textContent = '網絡錯誤'; errEl.style.display = 'block'; };
        xhr.send(JSON.stringify({ store_id: storeId, adults: adults, children: children, phone: phone, notes: notes, lang: lang }));
    }

    formatPhone(phone) {
        if (!phone) return '-';
        if (phone.indexOf('+') !== 0) return phone;
        var p = phone.replace('+', '');
        if (p.indexOf('852') === 0) return p.slice(3);
        var m = p.match(/^(\d)(\d+)$/);
        if (m) return '+' + m[1] + '-' + m[2];
        return phone;
    }

    showOfflineModal() {
        var modal = document.getElementById('offlineModal');
        if (modal) { modal.style.display = 'flex'; modal.classList.remove('hidden'); }
    }

    getWaitinglistAction(b) {
        if (b.status === 'cancelled') return '<button class="action-btn restore" onclick="window.cashierSystem.restoreWaitingInternal(\'' + b.id + '\')" style="background:#E3F2FD;color:#1565C0;padding:10px 22px;border:2px solid #90CAF9;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;margin:0 8px;">↩ 還原</button>';
        if (b.status === 'arrived') return '<button class="action-btn restore" onclick="window.cashierSystem.restoreWaitingInternal(\'' + b.id + '\')" style="background:#E3F2FD;color:#1565C0;padding:10px 22px;border:2px solid #90CAF9;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;margin:0 8px;">↩ 還原</button>';
        if (b.status === 'waiting') {
            return '<button class="action-btn arrive" onclick="window.cashierSystem.arriveWaitingInternal(\'' + b.id + '\')" style="background:#E8F5E9;color:#2E7D32;padding:10px 22px;border:2px solid #A5D6A7;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;margin:0 8px;">✅ 入座</button>' +
                   '<button class="action-btn contact" onclick="window.cashierSystem.notifyWaitingInternal(\'' + b.id + '\',\'contacted\')" style="background:#E3F2FD;color:#1565C0;padding:10px 22px;border:2px solid #90CAF9;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;margin:0 8px;">📞 致電</button>' +
                   '<button class="action-btn cancel" onclick="window.cashierSystem.cancelWaitingInternal(\'' + b.id + '\')" style="background:#FFEBEE;color:#C62828;padding:10px 22px;border:2px solid #EF9A9A;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;margin:0 8px;">✕ 取消</button>';
        }
        if (b.status === 'confirmed') {
            return '<button class="action-btn arrive" onclick="window.cashierSystem.arriveWaitingInternal(\'' + b.id + '\')" style="background:#E8F5E9;color:#2E7D32;padding:10px 22px;border:2px solid #A5D6A7;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;margin:0 8px;">✅ 入座</button>' +
                   '<button class="action-btn cancel" onclick="window.cashierSystem.cancelWaitingInternal(\'' + b.id + '\')" style="background:#FFEBEE;color:#C62828;padding:10px 22px;border:2px solid #EF9A9A;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;margin:0 8px;">✕ 取消</button>';
        }
        if (b.status === 'contacted') {
            return '<button class="action-btn arrive" onclick="window.cashierSystem.arriveWaitingInternal(\'' + b.id + '\')" style="background:#E8F5E9;color:#2E7D32;padding:10px 22px;border:2px solid #A5D6A7;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;margin:0 8px;">✅ 入座</button>' +
                   '<button class="action-btn contact call-btn" data-id="' + b.id + '" onclick="window.cashierSystem.callWaitingInternal(\'' + b.id + '\')" style="background:#E3F2FD;color:#1565C0;padding:10px 22px;border:2px solid #90CAF9;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;margin:0 8px;">📞 再致電</button>' +
                   '<button class="action-btn cancel" onclick="window.cashierSystem.cancelWaitingInternal(\'' + b.id + '\')" style="background:#FFEBEE;color:#C62828;padding:10px 22px;border:2px solid #EF9A9A;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;margin:0 8px;">✕ 取消</button>';
        }
        return '';
    }

    callWaitingInternal(id) {
        var self = this;
        if (!this._callingSet) this._callingSet = {};
        if (this._callingSet[id]) return; // 防止連點
        this._callingSet[id] = true;
        // 即時 disable button
        var btns = document.querySelectorAll('.call-btn[data-id="' + id + '"]');
        btns.forEach(function(b) { b.disabled = true; b.style.opacity = '0.5'; b.style.cursor = 'not-allowed'; b.textContent = '📞 致電中...'; });
        var apiKey = '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763';
        var xhr = new XMLHttpRequest();
        xhr.open('POST', window.location.origin + '/api/aliyun-proxy/waitinglist/' + id + '/call', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.setRequestHeader('x-api-key', apiKey);
        xhr.onload = function() {
            if (xhr.status >= 400) {
                try { var r = JSON.parse(xhr.responseText); alert('再致電失敗：' + (r.message || r.error)); } catch(e) { alert('再致電失敗'); }
                return;
            }
            try {
                var r = JSON.parse(xhr.responseText);
                if (r.success) { self.loadWaitinglistInternal(); alert('已再次致電客人'); }
                else { alert('再致電失敗：' + (r.error || '')); }
                if (self._callingSet) delete self._callingSet[id];
            } catch(e) { alert('再致電失敗'); if (self._callingSet) delete self._callingSet[id]; }
        };
        xhr.onerror = function() { alert('網絡錯誤'); if (self._callingSet) delete self._callingSet[id]; };
        xhr.send();
    }

    notifyWaitingInternal(id) {
        var self = this;
        var apiKey = '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763';
        var headers = { 'Content-Type': 'application/json', 'x-api-key': apiKey };
        fetch('/api/aliyun-proxy/waitinglist/' + id + '/notify', {
            method: 'POST',
            headers: headers
        })
        .then(function(r) { return r.json(); })
        .then(function(result) {
            if (result.success) {
                self.loadWaitinglistInternal(true);
                var msg = result.data && result.data.whatsapp ? '已發送 WhatsApp + 語音通知' : '已標記為已聯絡';
                alert(msg);
            } else {
                alert('致電失敗：' + (result.message || result.error));
            }
        })
        .catch(function() { alert('網絡錯誤'); });
    }

    cancelWaitingInternal(id) {
        var el = document.getElementById('bookingConfirmMsg');
        if (el) el.textContent = '確定取消此候位？';
        var detail = document.getElementById('bookingConfirmDetail');
        if (detail) detail.style.display = 'none';
        var modal = document.getElementById('bookingConfirmModal');
        if (modal) {
            modal.style.display = 'flex';
            modal.classList.remove('hidden');
            var yesBtn = document.getElementById('bookingConfirmYes');
            if (yesBtn) {
                yesBtn.onclick = function() {
                    modal.style.display = 'none';
                    modal.classList.add('hidden');
                    yesBtn.onclick = null;
                    var apiKey = '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763';
                    var headers = { 'Content-Type': 'application/json', 'x-api-key': apiKey };
                    fetch('/api/aliyun-proxy/waitinglist/' + id, {
                        method: 'PATCH',
                        headers: headers,
                        body: JSON.stringify({ status: 'cancelled' })
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(result) {
                        if (result.success) { window.cashierSystem.loadWaitinglistInternal(); }
                        else { alert('操作失敗：' + (result.message || result.error)); }
                    })
                    .catch(function() { alert('網絡錯誤'); });
                };
            }
            var noBtn = document.getElementById('bookingConfirmNo');
            if (noBtn) {
                noBtn.onclick = function() {
                    modal.style.display = 'none';
                    modal.classList.add('hidden');
                    noBtn.onclick = null;
                };
            }
        }
    }

    arriveWaitingInternal(id) {
        var people = 0;
        if (this._waitingData) {
            for (var i = 0; i < this._waitingData.length; i++) {
                if (this._waitingData[i].id === id) {
                    people = (this._waitingData[i].adults||0) + (this._waitingData[i].children||0);
                    break;
                }
            }
        }
        var self = this;
        self.switchTab('dashboard');
        setTimeout(async function() {
            var added = await self.addNewTable(people, 'waitinglist');
            if (added) {
                var tnEl = document.getElementById('numeric-input-table');
                var tableNum = tnEl && tnEl.value ? 'A' + tnEl.value : null;
                var apiKey = '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763';
                var headers = { 'Content-Type': 'application/json', 'x-api-key': apiKey };
                var body = { status: 'arrived' };
                if (tableNum) body.table_number = tableNum;
                fetch('/api/aliyun-proxy/waitinglist/' + id, {
                    method: 'PATCH',
                    headers: headers,
                    body: JSON.stringify(body)
                }).then(function(r) { return r.json(); }).then(function(result) {
                    if (result.success) { self.loadWaitinglistInternal(); }
                });
            }
        }, 300);
    }

    restoreWaitingInternal(id) {
        var el = document.getElementById('bookingConfirmMsg');
        if (el) el.textContent = '確定還原此候位？';
        var detail = document.getElementById('bookingConfirmDetail');
        if (detail) detail.style.display = 'none';
        var modal = document.getElementById('bookingConfirmModal');
        if (modal) {
            modal.style.display = 'flex';
            modal.classList.remove('hidden');
            var yesBtn = document.getElementById('bookingConfirmYes');
            if (yesBtn) {
                yesBtn.onclick = function() {
                    modal.style.display = 'none';
                    modal.classList.add('hidden');
                    yesBtn.onclick = null;
                    var apiKey = '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763';
                    var headers = { 'Content-Type': 'application/json', 'x-api-key': apiKey };
                    fetch('/api/aliyun-proxy/waitinglist/' + id, {
                        method: 'PATCH',
                        headers: headers,
                        body: JSON.stringify({ status: 'waiting' })
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(result) {
                        if (result.success) { window.cashierSystem.loadWaitinglistInternal(); }
                        else { alert('操作失敗：' + (result.message || result.error)); }
                    })
                    .catch(function() { alert('網絡錯誤'); });
                };
            }
            var noBtn = document.getElementById('bookingConfirmNo');
            if (noBtn) {
                noBtn.onclick = function() {
                    modal.style.display = 'none';
                    modal.classList.add('hidden');
                    noBtn.onclick = null;
                };
            }
        }
    }

    getBookingActionInternal(b) {
        if (b.status === 'cancelled') return '<button class="action-btn restore" onclick="window.cashierSystem.restoreBookingInternal(\'' + b.id + '\')" style="background:#E3F2FD;color:#1565C0;padding:10px 22px;border:2px solid #90CAF9;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;margin:0 8px;">↩ 還原</button>';
        if (b.status === 'arrived') return '<button class="action-btn restore" onclick="window.cashierSystem.restoreBookingInternal(\'' + b.id + '\')" style="background:#E3F2FD;color:#1565C0;padding:10px 22px;border:2px solid #90CAF9;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;margin:0 8px;">↩ 還原</button>';
        if (b.status === 'confirmed') {
            return '<button class="action-btn arrive" onclick="window.cashierSystem.arriveBookingInternal(\'' + b.id + '\')" style="background:#E8F5E9;color:#2E7D32;padding:10px 22px;border:2px solid #A5D6A7;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;margin:0 8px;">✅ 入座</button>' +
                   '<button class="action-btn edit" onclick="window.cashierSystem.editBookingInternal(\'' + b.id + '\')" style="background:#FFF8E1;color:#F57F17;padding:10px 22px;border:2px solid #FFE082;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;margin:0 8px;">✏️ 更改</button>' +
                   '<button class="action-btn cancel" onclick="window.cashierSystem.updateBookingStatusInternal(\'' + b.id + '\',\'cancelled\')" style="background:#FFEBEE;color:#C62828;padding:10px 22px;border:2px solid #EF9A9A;border-radius:10px;font-size:16px;font-weight:600;cursor:pointer;margin:0 8px;">✕ 取消</button>';
        }
        return '';
    }

    arriveBookingInternal(id) {
        // 從已載入的預約資料中搵返對應 booking
        var booking = null;
        if (this._bookingData) {
            for (var i = 0; i < this._bookingData.length; i++) {
                if (this._bookingData[i].id === id) { booking = this._bookingData[i]; break; }
            }
        }
        var people = booking ? ((booking.adults||0) + (booking.children||0)) : 0;
        var self = this;
        // 先切換到 dashboard
        self.switchTab('dashboard');
        // 開新增桌號視窗，成功後先 PATCH booking status
        setTimeout(async function() {
            var added = await self.addNewTable(people, 'booking');
            if (added) {
                var tnEl = document.getElementById('numeric-input-table');
                var tableNum = tnEl && tnEl.value ? 'A' + tnEl.value : null;
                var apiKey = '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763';
                var headers = { 'Content-Type': 'application/json' };
                if (apiKey) headers['x-api-key'] = apiKey;
                var body = { status: 'arrived' };
                if (tableNum) body.table_number = tableNum;
                fetch('/api/aliyun-proxy/booking/' + id + '/status', {
                    method: 'PATCH',
                    headers: headers,
                    body: JSON.stringify(body)
                }).then(function(r) { return r.json(); }).then(function(result2) {
                    if (result2.success) { self.loadBookingInternal(); }
                    else { alert('入座標記失敗：' + (result2.message || result2.error)); }
                }).catch(function() { alert('網絡錯誤'); });
            }
        }, 300);
    }

    editBookingInternal(id) {
        var booking = null;
        if (this._bookingData) {
            for (var i = 0; i < this._bookingData.length; i++) {
                if (this._bookingData[i].id === id) { booking = this._bookingData[i]; break; }
            }
        }
        if (!booking) { alert('找不到預約資料'); return; }
        this._editingBookingId = id;

        var edDate = document.getElementById('bookingEditDate');
        edDate.value = booking.booking_date || '';
        // 不允許選擇過去的日期
        var today = new Date();
        edDate.min = today.getFullYear() + '-' + String(today.getMonth()+1).padStart(2,'0') + '-' + String(today.getDate()).padStart(2,'0');
        this.populateEditTimeSlots(booking.booking_date, booking.booking_time);
        document.getElementById('bookingEditStore').value = booking.store_id || 'store_1';
        document.getElementById('bookingEditAdults').value = booking.adults || 2;
        document.getElementById('bookingEditChildren').value = booking.children || 0;
        document.getElementById('bookingEditNotes').value = booking.notes || '';

        var modal = document.getElementById('bookingEditModal');
        modal.style.display = 'flex';
        modal.classList.remove('hidden');
    }

    populateEditTimeSlots(date, selectedTime, selectId) {
        var selId = selectId || 'bookingEditTime';
        var sel = document.getElementById(selId);
        if (!sel) return;
        var d = date ? new Date(date) : new Date();
        var day = d.getDay();
        var isHoliday = (day === 0 || day === 6);
        var startHour = isHoliday ? 11 : 13;
        var startMin = isHoliday ? 30 : 30;
        var endHour = 21, endMin = 0;

        sel.innerHTML = '';
        var h = startHour, m = startMin;
        while (h < endHour || (h === endHour && m <= endMin)) {
            var timeStr = String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0');
            var opt = document.createElement('option');
            opt.value = timeStr;
            opt.textContent = timeStr;
            if (timeStr === selectedTime) opt.selected = true;
            sel.appendChild(opt);
            m += 30;
            if (m >= 60) { h += 1; m = 0; }
        }
    }

    saveBookingInternal() {
        var id = this._editingBookingId;
        if (!id) { alert('遺失預約 ID'); return; }

        var storeId = document.getElementById('bookingEditStore').value;
        var date = document.getElementById('bookingEditDate').value;
        var time = document.getElementById('bookingEditTime').value;
        var adults = parseInt(document.getElementById('bookingEditAdults').value) || 2;
        var children = parseInt(document.getElementById('bookingEditChildren').value) || 0;
        var notes = document.getElementById('bookingEditNotes').value || '';

        if (!date) { document.getElementById('bookingEditError').textContent = '請選擇日期'; document.getElementById('bookingEditError').style.display = 'block'; return; }
        if (!time) { document.getElementById('bookingEditError').textContent = '請選擇時間'; document.getElementById('bookingEditError').style.display = 'block'; return; }

        document.getElementById('bookingEditError').style.display = 'none';
        var modal = document.getElementById('bookingEditModal');
        modal.style.display = 'none';
        modal.classList.add('hidden');

        var apiKey = '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763';
        var headers = { 'Content-Type': 'application/json', 'x-api-key': apiKey };
        var self = this;

        fetch('/api/aliyun-proxy/booking/' + id, {
            method: 'PUT',
            headers: headers,
            body: JSON.stringify({ store_id: storeId, booking_date: date, booking_time: time, adults: adults, children: children, notes: notes })
        })
        .then(function(r) { return r.json(); })
        .then(function(result) {
            if (result.success) { self.loadBookingInternal(); }
            else { alert('更改失敗：' + (result.message || result.error)); }
        })
        .catch(function() { alert('網絡錯誤'); });
    }

    restoreBookingInternal(id) {
        // 查詢預約資料
        var booking = null;
        if (this._bookingData) {
            for (var i = 0; i < this._bookingData.length; i++) {
                if (this._bookingData[i].id === id) { booking = this._bookingData[i]; break; }
            }
        }
        var el = document.getElementById('bookingConfirmMsg');
        if (el) el.textContent = '確定還原此預約？';
        // 顯示預約詳情
        var detail = document.getElementById('bookingConfirmDetail');
        if (detail && booking) {
            var tp = (booking.adults||0) + (booking.children||0);
            var ph = this.formatPhone(booking.phone);
            detail.innerHTML = '<strong>' + booking.booking_time + '</strong>　' + tp + ' 人　' + ph;
            detail.style.display = 'block';
        } else if (detail) {
            detail.style.display = 'none';
        }
        var modal = document.getElementById('bookingConfirmModal');
        if (modal) {
            modal.style.display = 'flex';
            modal.classList.remove('hidden');
            var yesBtn = document.getElementById('bookingConfirmYes');
            if (yesBtn) {
                yesBtn.onclick = function() {
                    modal.style.display = 'none';
                    modal.classList.add('hidden');
                    var apiKey = '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763';
                    var headers = { 'Content-Type': 'application/json' };
                    if (apiKey) headers['x-api-key'] = apiKey;
                    var self = window.cashierSystem;
                    fetch('/api/aliyun-proxy/booking/' + id + '/status', {
                        method: 'PATCH',
                        headers: headers,
                        body: JSON.stringify({ status: 'confirmed' })
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(result) {
                        if (result.success) { self.loadBookingInternal(); }
                        else { alert('操作失敗：' + (result.message || result.error)); }
                    })
                    .catch(function() { alert('網絡錯誤'); });
                };
            }
            var noBtn = document.getElementById('bookingConfirmNo');
            if (noBtn) {
                noBtn.onclick = function() {
                    modal.style.display = 'none';
                    modal.classList.add('hidden');
                    noBtn.onclick = null;
                };
            }
        }
    }

    updateBookingStatusInternal(id, status) {
        if (status === 'cancelled') {
            var el = document.getElementById('bookingConfirmMsg');
            if (el) el.textContent = '確定取消此預約？';
            var detail = document.getElementById('bookingConfirmDetail');
            if (detail) detail.style.display = 'none';
            var modal = document.getElementById('bookingConfirmModal');
            if (modal) {
                modal.style.display = 'flex';
                modal.classList.remove('hidden');
                var yesBtn = document.getElementById('bookingConfirmYes');
                if (yesBtn) {
                    yesBtn.onclick = function() {
                        modal.style.display = 'none';
                        modal.classList.add('hidden');
                        window.cashierSystem.doUpdateStatusInternal(id, status);
                        yesBtn.onclick = null;
                    };
                }
                var noBtn = document.getElementById('bookingConfirmNo');
                if (noBtn) {
                    noBtn.onclick = function() {
                        modal.style.display = 'none';
                        modal.classList.add('hidden');
                        noBtn.onclick = null;
                    };
                }
            }
            return;
        }
        this.doUpdateStatusInternal(id, status);
    }

    doUpdateStatusInternal(id, status) {
        var apiKey = '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763';
        var headers = { 'Content-Type': 'application/json' };
        if (apiKey) headers['x-api-key'] = apiKey;
        var self = this;
        fetch('/api/aliyun-proxy/booking/' + id + '/status', {
            method: 'PATCH',
            headers: headers,
            body: JSON.stringify({ status: status })
        })
        .then(function(r) { return r.json(); })
        .then(function(result) {
            if (result.success) { self.loadBookingInternal(); }
            else { alert('操作失敗：' + (result.message || result.error)); }
        })
        .catch(function() { alert('網絡錯誤'); });
    }

    // ====== 暫停 / 恢復預約時段 ======

    showPauseModal() {
        var modal = document.getElementById('bookingPauseModal');
        if (!modal) return;
        modal.style.display = 'flex';
        modal.classList.remove('hidden');
        document.getElementById('pauseModalError').style.display = 'none';
        document.getElementById('pauseModalError').textContent = '';
        document.getElementById('pauseCustomHours').value = '1';
        this._pauseMinutes = null; // 清除之前嘅暫停設定，確保自訂流程有 confirm modal
    }

    selectPauseDuration(minutes) {
        this._pauseMinutes = minutes;
        var storeId = document.getElementById('bookingStoreFilter')?.value || '';
        if (!storeId) {
            document.getElementById('pauseModalError').textContent = '請先選擇分店';
            document.getElementById('pauseModalError').style.display = 'block';
            return;
        }
        var date = document.getElementById('bookingDateFilter')?.value || '';
        if (!date) {
            document.getElementById('pauseModalError').textContent = '請先選擇日期';
            document.getElementById('pauseModalError').style.display = 'block';
            return;
        }
        this._pauseStoreId = storeId;
        this._pauseDate = date;

        // 計算暫停到幾點
        var now = new Date();
        var currentMin = now.getHours() * 60 + now.getMinutes();
        var startSlot = Math.ceil(currentMin / 30) * 30;
        var endMin = startSlot + minutes;
        // 恢復時間 = 暫停結束後第一格 slot
        var endH = Math.floor(endMin / 60);
        var endM = endMin % 60;
        if (endH >= 22) endH = 22;
        var pauseUntil = String(endH).padStart(2,'0') + ':' + String(endM).padStart(2,'0');

        // 關閉第一個 modal，顯示確認 modal
        document.getElementById('bookingPauseModal').style.display = 'none';
        document.getElementById('bookingPauseModal').classList.add('hidden');
        var hoursLabel = (minutes >= 60 ? (minutes/60) : '') + ' 小時';
        if (minutes === 90) hoursLabel = '1.5 小時';
        else if (minutes === 150) hoursLabel = '2.5 小時';
        else if (minutes === 60) hoursLabel = '1 小時';
        else if (minutes === 120) hoursLabel = '2 小時';
        document.getElementById('pauseConfirmText').textContent = '暫停' + hoursLabel + '到 ' + pauseUntil + ' 恢復';
        document.getElementById('bookingPauseConfirmModal').style.display = 'flex';
        document.getElementById('bookingPauseConfirmModal').classList.remove('hidden');
    }

    confirmPause() {
        var minutes = this._pauseMinutes;
        var storeId = this._pauseStoreId;
        var date = this._pauseDate;

        // 如果冇㩒快速選擇制（自訂 input 情況），計時 + 儲存俾第二次 click
        if (!minutes) {
            var hours = parseFloat(document.getElementById('pauseCustomHours')?.value) || 1;
            minutes = hours * 60;
            storeId = document.getElementById('bookingStoreFilter')?.value || '';
            date = document.getElementById('bookingDateFilter')?.value || '';
            if (!storeId || !date) {
                document.getElementById('pauseModalError').textContent = '請先選擇分店和日期';
                document.getElementById('pauseModalError').style.display = 'block';
                return;
            }
            this._pauseMinutes = minutes;
            this._pauseStoreId = storeId;
            this._pauseDate = date;
            var now = new Date();
            var currentMin = now.getHours() * 60 + now.getMinutes();
            var startSlot = Math.ceil(currentMin / 30) * 30;
            var endMin = startSlot + minutes;
            var endH = Math.floor(endMin / 60);
            var endM = endMin % 60;
            if (endH >= 22) endH = 22;
            var pauseUntil = String(endH).padStart(2,'0') + ':' + String(endM).padStart(2,'0');
            document.getElementById('bookingPauseModal').style.display = 'none';
            document.getElementById('bookingPauseModal').classList.add('hidden');
            document.getElementById('pauseConfirmText').textContent = '暫停 ' + hours + ' 小時到 ' + pauseUntil + ' 恢復';
            document.getElementById('bookingPauseConfirmModal').style.display = 'flex';
            document.getElementById('bookingPauseConfirmModal').classList.remove('hidden');
            return;
        }

        // 關閉確認 modal
        document.getElementById('bookingPauseConfirmModal').style.display = 'none';
        document.getElementById('bookingPauseConfirmModal').classList.add('hidden');

        var self = this;
        var xhr = new XMLHttpRequest();
        xhr.open('POST', window.location.origin + '/api/aliyun-proxy/booking/pause', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.setRequestHeader('x-api-key', '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763');
        xhr.onload = function() {
            if (xhr.status >= 400) {
                try {
                    var r = JSON.parse(xhr.responseText);
                    alert('暫停失敗：' + (r.message || r.error));
                } catch(e) { alert('暫停失敗 (' + xhr.status + ')'); }
                return;
            }
            try {
                var r = JSON.parse(xhr.responseText);
                if (r.success) {
                    self.loadPausedStatus();
                    self.loadBookingInternal();
                    self.loadWaitinglistInternal();
                } else {
                    alert('暫停失敗：' + (r.error || ''));
                }
            } catch(e) { alert('暫停失敗'); }
        };
        xhr.onerror = function() { alert('網絡錯誤'); };
        xhr.send(JSON.stringify({ store_id: storeId, date: date, duration_minutes: minutes }));
    }

    resumeSlots() {
        var storeId = document.getElementById('bookingStoreFilter')?.value || '';
        var date = document.getElementById('bookingDateFilter')?.value || '';
        if (!storeId || !date) {
            alert('請先選擇分店和日期');
            return;
        }
        var self = this;
        var confirmModal = document.getElementById('bookingConfirmModal');
        if (confirmModal) {
            document.getElementById('bookingConfirmMsg').textContent = '確定恢復所有暫停時段？';
            var detail = document.getElementById('bookingConfirmDetail');
            if (detail) detail.style.display = 'none';
            confirmModal.style.display = 'flex';
            confirmModal.classList.remove('hidden');
            var yesBtn = document.getElementById('bookingConfirmYes');
            if (yesBtn) {
                yesBtn.onclick = function() {
                    confirmModal.style.display = 'none';
                    confirmModal.classList.add('hidden');
                    yesBtn.onclick = null;
                    self.doResumeSlots(storeId, date);
                };
            }
            var noBtn = document.getElementById('bookingConfirmNo');
            if (noBtn) {
                noBtn.onclick = function() {
                    confirmModal.style.display = 'none';
                    confirmModal.classList.add('hidden');
                    noBtn.onclick = null;
                };
            }
        }
    }

    doResumeSlots(storeId, date) {
        var self = this;
        var xhr = new XMLHttpRequest();
        xhr.open('POST', window.location.origin + '/api/aliyun-proxy/booking/resume', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.setRequestHeader('x-api-key', '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763');
        xhr.onload = function() {
            if (xhr.status >= 400) {
                try { var r = JSON.parse(xhr.responseText); alert('恢復失敗：' + (r.message || r.error)); } catch(e) { alert('恢復失敗 (' + xhr.status + ')'); }
                return;
            }
            try {
                var r = JSON.parse(xhr.responseText);
                if (r.success) { self.loadPausedStatus(); self.loadBookingInternal(); self.loadWaitinglistInternal(); self.loadFuturePausedSlots(storeId); }
                else { alert('恢復失敗：' + (r.error || '')); }
            } catch(e) { alert('恢復失敗'); }
        };
        xhr.onerror = function() { alert('網絡錯誤'); };
        xhr.send(JSON.stringify({ store_id: storeId, date: date }));
    }

    loadPausedStatus() {
        var badge = document.getElementById('pausedStatusBadge');
        if (!badge) return;
        var storeId = document.getElementById('bookingStoreFilter')?.value || '';
        var date = document.getElementById('bookingDateFilter')?.value || '';
        if (!storeId || !date) { badge.style.display = 'none'; return; }

        var self = this;
        var xhr = new XMLHttpRequest();
        xhr.open('GET', window.location.origin + '/api/aliyun-proxy/booking/paused?store_id=' + encodeURIComponent(storeId) + '&date=' + encodeURIComponent(date), true);
        xhr.setRequestHeader('x-api-key', '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763');
        xhr.onload = function() {
            try {
                var r = JSON.parse(xhr.responseText);
                if (r.success && r.data && r.data.length > 0) {
                    var times = r.data.map(function(p) { return p.booking_time; }).join(', ');
                    badge.textContent = '🛑 已暫停 ' + r.data.length + ' 個時段: ' + times;
                    badge.style.display = 'inline';
                } else {
                    badge.style.display = 'none';
                }
            } catch(e) { badge.style.display = 'none'; }
        };
        xhr.onerror = function() { badge.style.display = 'none'; };
        xhr.send();
    }

    // ====== 設定 tab ======

    loadBookingSettingsTab() {
        var storeSelect = document.getElementById('settingsStoreSelect');
        if (!storeSelect) return;
        var isAdmin = this.currentEmployee && this.currentEmployee.role === 'admin';
        if (!isAdmin && this.currentEmployee && this.currentEmployee.store_id) {
            storeSelect.disabled = true;
            storeSelect.value = this.currentEmployee.store_id;
        } else if (isAdmin) {
            storeSelect.disabled = false;
        }
        var storeId = storeSelect.value || '';
        if (!storeId && !isAdmin && this.selectedStoreId) {
            storeId = this.selectedStoreId;
            storeSelect.value = storeId;
        }
        if (!storeId) {
            var list = document.getElementById('futurePausedList');
            if (list) list.innerHTML = '<div style="text-align:center;padding:20px;color:#999;">請揀選分店</div>';
            var capGrid = document.getElementById('capSlotsGrid');
            if (capGrid) capGrid.innerHTML = '';
            return;
        }
        this.loadFuturePausedSlots(storeId);
        this.loadStoreCapacity(storeId);
        this.applyCapAdminCheck();
    }

    loadFuturePausedSlots(storeId) {
        var list = document.getElementById('futurePausedList');
        if (!list) return;
        list.innerHTML = '<div style="text-align:center;padding:20px;color:#999;">載入中...</div>';
        var today = new Date();
        var todayStr = today.getFullYear() + '-' + String(today.getMonth()+1).padStart(2,'0') + '-' + String(today.getDate()).padStart(2,'0');

        var self = this;
        var xhr = new XMLHttpRequest();
        xhr.open('GET', window.location.origin + '/api/aliyun-proxy/booking/paused?store_id=' + encodeURIComponent(storeId) + '&from_date=' + todayStr, true);
        xhr.setRequestHeader('x-api-key', '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763');
        xhr.onload = function() {
            if (xhr.status >= 400) {
                list.innerHTML = '<div style="text-align:center;padding:20px;color:#C62828;">❌ 錯誤</div>';
                return;
            }
            try {
                var r = JSON.parse(xhr.responseText);
                if (!r.success || !r.data || r.data.length === 0) {
                    list.innerHTML = '<div style="text-align:center;padding:20px;color:#999;">📭 沒有未來暫停時段</div>';
                    return;
                }
                // 按日期分組，判斷連續性或逐個顯示
                var groups = {};
                r.data.forEach(function(p) {
                    if (!groups[p.booking_date]) groups[p.booking_date] = { times: [] };
                    groups[p.booking_date].times.push(p.booking_time);
                });
                var dates = Object.keys(groups).sort();
                var html = '';
                dates.forEach(function(d) {
                    var times = groups[d].times.sort();
                    var startTime = times[0];
                    var endTime = times[times.length - 1];
                    var isFullDay = (startTime <= '11:30' && endTime >= '21:00') || times.length >= 18;

                    var rangeLabel, rangeStart, rangeEnd;
                    if (isFullDay) {
                        rangeLabel = '全日';
                        rangeStart = startTime;
                        rangeEnd = endTime;
                    } else if (times.length >= 2) {
                        // 檢查是否連續（全部相隔30分鐘）
                        var isConsecutive = true;
                        for (var ti = 1; ti < times.length; ti++) {
                            var pm = parseInt(times[ti-1].split(':')[0])*60 + parseInt(times[ti-1].split(':')[1]);
                            var cm = parseInt(times[ti].split(':')[0])*60 + parseInt(times[ti].split(':')[1]);
                            if (cm - pm !== 30) { isConsecutive = false; break; }
                        }
                        if (isConsecutive) {
                            rangeLabel = startTime + ' - ' + endTime;
                            rangeStart = startTime;
                            rangeEnd = endTime;
                        } else {
                            // 非連續，逐個顯示
                            rangeLabel = times.join(', ');
                            rangeStart = startTime;
                            rangeEnd = endTime;
                        }
                    } else {
                        rangeLabel = startTime;
                        rangeStart = startTime;
                        rangeEnd = startTime;
                    }
                    html += '<div style="margin-bottom:8px;">';
                    html += '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 14px;background:#FFF3E0;border-radius:8px;font-size:15px;">';
                    html += '<div><strong style="color:#555;font-size:14px;margin-right:10px;">' + d + '</strong><span style="font-weight:600;">🛑 ' + rangeLabel + '</span></div>';
                    html += '<button class="btn-small" onclick="window.cashierSystem.deletePausedRange(\'' + storeId + '\',\'' + d + '\',\'' + rangeStart + '\',\'' + rangeEnd + '\')" style="color:#C62828;border:1px solid #EF9A9A;background:white;padding:4px 10px;border-radius:6px;cursor:pointer;font-size:13px;">刪除</button>';
                    html += '</div></div>';
                });
                list.innerHTML = html;
            } catch(e) {
                list.innerHTML = '<div style="text-align:center;padding:20px;color:#C62828;">❌ ' + e.message + '</div>';
            }
        };
        xhr.onerror = function() {
            list.innerHTML = '<div style="text-align:center;padding:20px;color:#999;">請先登入收銀系統</div>';
        };
        xhr.send();
    }

    showAddFuturePauseModal() {
        var modal = document.getElementById('addFuturePauseModal');
        if (!modal) return;
        modal.style.display = 'flex';
        modal.classList.remove('hidden');
        document.getElementById('futurePauseModalError').style.display = 'none';

        // 設定日期 min = tomorrow
        var tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        var tomorrowStr = tomorrow.getFullYear() + '-' + String(tomorrow.getMonth()+1).padStart(2,'0') + '-' + String(tomorrow.getDate()).padStart(2,'0');
        var dateInput = document.getElementById('futurePauseDate');
        dateInput.min = tomorrowStr;
        dateInput.value = tomorrowStr;

        // Generate time slots grid
        this.generateFuturePauseGrid(tomorrowStr);
        // 綁定日期 change
        var self = this;
        if (!dateInput._fpBound) {
            dateInput._fpBound = true;
            dateInput.addEventListener('change', function() { self.generateFuturePauseGrid(this.value); });
        }
        // 綁定全剔 checkbox
        var fullDayCb = document.getElementById('futurePauseFullDay');
        if (!fullDayCb._fpBound) {
            fullDayCb._fpBound = true;
            fullDayCb.addEventListener('change', function() {
                var slots = document.querySelectorAll('#futurePauseSlotsGrid .fp-slot');
                slots.forEach(function(s) { s.classList.toggle('selected', fullDayCb.checked); });
            });
        }
    }

    generateFuturePauseGrid(dateStr) {
        var grid = document.getElementById('futurePauseSlotsGrid');
        if (!grid) return;
        // Determine start time based on daytype (using local logic)
        var d = new Date(dateStr + 'T00:00+08:00');
        var w = d.getDay();
        var isWe = (w === 0 || w === 6);
        var startH = isWe ? 11 : 13;
        var slots = [];
        for (var h = startH; h < 22; h++) {
            for (var m = 0; m < 60; m += 30) {
                if (h === 21 && m === 30) continue;
                var t = String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0');
                slots.push(t);
            }
        }
        grid.innerHTML = '';
        slots.forEach(function(t) {
            var el = document.createElement('div');
            el.className = 'fp-slot';
            el.textContent = t;
            el.addEventListener('click', function() { this.classList.toggle('selected'); });
            grid.appendChild(el);
        });
    }

    deletePausedRange(storeId, date, startTime, endTime) {
        if (!confirm('確定刪除 ' + date + ' ' + startTime + ' - ' + endTime + ' 嘅暫停？')) return;
        var self = this;
        var xhr = new XMLHttpRequest();
        xhr.open('POST', window.location.origin + '/api/aliyun-proxy/booking/pause/delete-range', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.setRequestHeader('x-api-key', '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763');
        xhr.onload = function() {
            if (xhr.status >= 400) {
                try { var r = JSON.parse(xhr.responseText); alert('刪除失敗：' + (r.message || r.error)); } catch(e) { alert('刪除失敗'); }
                return;
            }
            try {
                var r = JSON.parse(xhr.responseText);
                if (r.success) {
                    var storeId = document.getElementById('settingsStoreSelect')?.value || '';
                    self.loadFuturePausedSlots(storeId);
                    self.loadBookingInternal();
                    self.loadPausedStatus();
                }
            } catch(e) { alert('刪除失敗'); }
        };
        xhr.onerror = function() { alert('網絡錯誤'); };
        xhr.send(JSON.stringify({ store_id: storeId, date: date, start_time: startTime, end_time: endTime }));
    }

    loadStoreCapacity(storeId) {
        var self = this;
        if (!this._capReqId) this._capReqId = 0;
        var myReqId = ++this._capReqId;
        var xhr = new XMLHttpRequest();
        xhr.open('GET', window.location.origin + '/api/aliyun-proxy/booking/capacity/config/' + encodeURIComponent(storeId), true);
        xhr.setRequestHeader('x-api-key', '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763');
        xhr.onload = function() {
            try {
                var r = JSON.parse(xhr.responseText);
                if (r.success && r.data && myReqId === self._capReqId) {
                    var defaults = r.data.defaults || { weekday: 20, holiday: 20 };
                    var slots = r.data.slots || { weekday: {}, holiday: {} };
                    self._capData = { defaults: defaults, slots: slots };
                    self.renderCapGrid();
                }
            } catch(e) { console.error('loadStoreCapacity error:', e); }
        };
        xhr.send();
    }

    renderCapGrid() {
        var grid = document.getElementById('capSlotsGrid');
        if (!grid || !this._capData) return;

        var activeGroup = 'weekday';
        var activeTab = document.querySelector('.cap-daytype-tab.active');
        if (activeTab) activeGroup = activeTab.getAttribute('data-capgroup') || 'weekday';

        var defaults = this._capData.defaults || {};
        var slots = this._capData.slots || {};
        var defaultVal = defaults[activeGroup] || 20;
        var slotData = slots[activeGroup] || {};

        var allSlots = [];
        for (var h = 11; h <= 21; h++) {
            for (var m = 0; m < 60; m += 30) {
                if (h === 21 && m === 30) continue;
                var t = String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0');
                if (t >= '11:30') allSlots.push(t);
            }
        }

        grid.innerHTML = '';
        allSlots.forEach(function(t) {
            var val = slotData[t] !== undefined ? slotData[t] : defaultVal;
            var wrapper = document.createElement('div');
            wrapper.style.cssText = 'display:flex;flex-direction:column;align-items:center;gap:2px;';
            wrapper.innerHTML = '<span style="font-size:15px;font-weight:600;color:#444;">' + t + '</span>' +
                '<input type="number" class="cap-slot-input" data-time="' + t + '" value="' + val + '" min="0" max="100" style="width:100%;padding:6px;border:2px solid #ddd;border-radius:6px;font-size:16px;text-align:center;box-sizing:border-box;">';
            grid.appendChild(wrapper);
        });
        this.applyCapAdminCheck();
    }

    applyCapAdminCheck() {
        var isAdmin = this.currentEmployee && this.currentEmployee.role === 'admin';
        var capSection = document.getElementById('bookingSettingsSection');
        if (capSection) {
            var els = capSection.querySelectorAll('#saveCapacityBtn, #applyCapacityAllBtn, .cap-slot-input');
            els.forEach(function(el) {
                el.disabled = !isAdmin;
                el.style.opacity = isAdmin ? '1' : '0.6';
                if (!isAdmin) el.style.cursor = 'not-allowed';
                else el.style.cursor = '';
            });
        }
    }

    saveStoreCapacity() {
        var storeId = document.getElementById('settingsStoreSelect')?.value || '';
        if (!storeId) { alert('請先揀選分店'); return; }

        var activeGroup = 'weekday';
        var activeTab = document.querySelector('.cap-daytype-tab.active');
        if (activeTab) activeGroup = activeTab.getAttribute('data-capgroup') || 'weekday';

        var slotInputs = document.querySelectorAll('#capSlotsGrid .cap-slot-input');
        var slotValues = {};
        slotInputs.forEach(function(el) {
            var cap = parseInt(el.value);
            if (isNaN(cap)) cap = 20;
            slotValues[el.dataset.time] = cap;
        });

        var self = this;
        var done = 0, total = 2, success = true;
        var msgEl = document.getElementById('capSaveMsg');

        function finish() {
            if (msgEl) {
                msgEl.textContent = success ? '✅ 容量設定已更新' : '⚠️ 部分設定儲存失敗';
                msgEl.style.display = 'block';
                msgEl.style.color = success ? 'green' : 'red';
                setTimeout(function() { msgEl.style.display = 'none'; }, 3000);
            }
            if (success) self.loadStoreCapacity(storeId);
        }

        var xhr1 = new XMLHttpRequest();
        xhr1.open('POST', window.location.origin + '/api/aliyun-proxy/booking/capacity/save', true);
        xhr1.setRequestHeader('Content-Type', 'application/json');
        xhr1.setRequestHeader('x-api-key', '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763');
        xhr1.onload = function() { done++; if (done === total) finish(); };
        xhr1.onerror = function() { done++; success = false; if (done === total) finish(); };
        xhr1.send(JSON.stringify({ store_id: storeId, daytype_group: activeGroup, capacity: 20 }));

        var xhr2 = new XMLHttpRequest();
        xhr2.open('POST', window.location.origin + '/api/aliyun-proxy/booking/capacity/save-slots', true);
        xhr2.setRequestHeader('Content-Type', 'application/json');
        xhr2.setRequestHeader('x-api-key', '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763');
        xhr2.onload = function() { done++; if (done === total) finish(); };
        xhr2.onerror = function() { done++; success = false; if (done === total) finish(); };
        xhr2.send(JSON.stringify({ store_id: storeId, daytype_group: activeGroup, slots: slotValues }));
    }

    confirmFuturePause() {
        var storeId = document.getElementById('settingsStoreSelect')?.value || '';
        var date = document.getElementById('futurePauseDate')?.value;
        if (!date) {
            document.getElementById('futurePauseModalError').textContent = '請選擇日期';
            document.getElementById('futurePauseModalError').style.display = 'block';
            return;
        }

        var timeSlots = [];
        var fullDayCb = document.getElementById('futurePauseFullDay');
        if (fullDayCb && fullDayCb.checked) {
            // 全日暫停
            var d = new Date(date + 'T00:00+08:00');
            var w = d.getDay();
            var isWe = (w === 0 || w === 6);
            var startH = isWe ? 11 : 13;
            for (var h = startH; h < 22; h++) {
                for (var m = 0; m < 60; m += 30) {
                    if (h === 21 && m === 30) continue;
                    timeSlots.push(String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0'));
                }
            }
        } else {
            // Check individual selected slots
            var selectedSlots = document.querySelectorAll('#futurePauseSlotsGrid .fp-slot.selected');
            if (selectedSlots.length > 0) {
                selectedSlots.forEach(function(el) { timeSlots.push(el.textContent); });
            } else {
                // Use time range
                var startTime = document.getElementById('futurePauseStart')?.value;
                var endTime = document.getElementById('futurePauseEnd')?.value;
                if (startTime && endTime) {
                    var sh = parseInt(startTime.split(':')[0]), sm = parseInt(startTime.split(':')[1]);
                    var eh = parseInt(endTime.split(':')[0]), em = parseInt(endTime.split(':')[1]);
                    var startMin = sh * 60 + sm;
                    var endMin = eh * 60 + em;
                    for (var m = startMin; m < endMin; m += 30) {
                        var hh = Math.floor(m / 60);
                        var mm = m % 60;
                        timeSlots.push(String(hh).padStart(2,'0') + ':' + String(mm).padStart(2,'0'));
                    }
                }
            }
        }

        if (timeSlots.length === 0) {
            document.getElementById('futurePauseModalError').textContent = '請選擇至少一個時段';
            document.getElementById('futurePauseModalError').style.display = 'block';
            return;
        }

        document.getElementById('futurePauseModalError').style.display = 'none';
        var modal = document.getElementById('addFuturePauseModal');
        modal.style.display = 'none';
        modal.classList.add('hidden');

        var self = this;
        var xhr = new XMLHttpRequest();
        xhr.open('POST', window.location.origin + '/api/aliyun-proxy/booking/pause', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.setRequestHeader('x-api-key', '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763');
        xhr.onload = function() {
            if (xhr.status >= 400) {
                try { var r = JSON.parse(xhr.responseText); alert('暫停失敗：' + (r.message || r.error)); } catch(e) { alert('暫停失敗 (' + xhr.status + ')'); }
                return;
            }
            try {
                var r = JSON.parse(xhr.responseText);
                if (r.success) {
                    self.loadFuturePausedSlots(storeId);
                }
            } catch(e) { alert('暫停失敗'); }
        };
        xhr.onerror = function() { alert('網絡錯誤'); };
        xhr.send(JSON.stringify({ store_id: storeId, date: date, time_slots: timeSlots }));
    }

    hideProductManagementButtonsIfNotAdmin(isAdmin) {
        console.log(`hideProductManagementButtonsIfNotAdmin called, isAdmin: ${isAdmin}`);
        if (!isAdmin) {
            // 隱藏新增商品按鈕
            const addProductBtn = document.getElementById('add-product-btn');
            if (addProductBtn) {
                addProductBtn.style.display = 'none';
                console.log('Hiding add-product-btn for non-admin user');
            }
            // 隱藏批量新增商品按鈕
            const batchAddProductBtn = document.getElementById('batch-add-products-btn');
            if (batchAddProductBtn) {
                batchAddProductBtn.style.display = 'none';
                console.log('Hiding batch-add-products-btn for non-admin user');
            }
            // 隱藏匯出商品按鈕
            const exportProductsBtn = document.getElementById('export-products-btn');
            if (exportProductsBtn) {
                exportProductsBtn.style.display = 'none';
                console.log('Hiding export-products-btn for non-admin user');
            }

            // 隱藏商品篩選器容器
            const productFiltersContainer = document.querySelector('.product-filters');
            if (productFiltersContainer) {
                productFiltersContainer.style.display = 'none';
                console.log('Hiding product-filters container for non-admin user');
            }

            // 保持商品分類標籤容器可見（員工可切換商品分類）
            const productCategoryTabsContainer = document.querySelector('.product-category-tabs');
            if (productCategoryTabsContainer) {
                productCategoryTabsContainer.style.display = '';
                console.log('Keeping product-category-tabs container visible for non-admin user');
            }
        } else {
            // 管理員用戶：確保按鈕可見
            const addProductBtn = document.getElementById('add-product-btn');
            if (addProductBtn) addProductBtn.style.display = '';
            const batchAddProductBtn = document.getElementById('batch-add-products-btn');
            if (batchAddProductBtn) batchAddProductBtn.style.display = '';
            const exportProductsBtn = document.getElementById('export-products-btn');
            if (exportProductsBtn) exportProductsBtn.style.display = '';

            // 管理員用戶：確保篩選器容器可見
            const productFiltersContainer = document.querySelector('.product-filters');
            if (productFiltersContainer) productFiltersContainer.style.display = '';

            // 確保商品分類標籤容器可見
            const productCategoryTabsContainer = document.querySelector('.product-category-tabs');
            if (productCategoryTabsContainer) productCategoryTabsContainer.style.display = '';
        }
    }

    initTabs() {
        console.log(`initTabs called, isAuthenticated: ${this.isAuthenticated}`);
        // 初始化標籤頁狀態
        if (this.isAuthenticated) {
            this.showAuthenticatedUI();
        } else {
            this.showUnauthenticatedUI();
        }
        // 更新按鈕狀態
        this.updateAddOrderButtonState();
    }

    switchTab(tabName, context = {}) {
        console.log(`switchTab called: tabName=${tabName}, context=`, context);
        console.log(`this.isAuthenticated=${this.isAuthenticated}, this.currentTab=${this.currentTab}`);
        if (!this.isAuthenticated && tabName !== 'dashboard') {
            this.addMessage('請先登入以使用此功能', 'warning');
            return;
        }

        // 如果是員工管理標籤，檢查是否為管理員
        if (tabName === 'employee-management') {
            const isAdmin = this.currentEmployee && this.currentEmployee.role === 'admin';
            if (!isAdmin) {
                this.addMessage('只有管理員可以訪問員工管理功能', 'warning');
                // 切換回dashboard
                if (this.currentTab !== 'dashboard') {
                    this.switchTab('dashboard');
                }
                return;
            }
        }

        // 清理主機設定標籤的資源（如果從host-config切換到其他標籤頁）
        if (this.currentTab === 'host-config' && tabName !== 'host-config') {
            console.log('從host-config標籤頁切換，清理定時器資源');
            if (this.hostConfigStatusTimer) {
                clearInterval(this.hostConfigStatusTimer);
                this.hostConfigStatusTimer = null;
                console.log('已清理host-config定時器');
            }
        }

        // 更新活動標籤按鈕
        document.querySelectorAll('.tab-button').forEach(button => {
            if (button.dataset.tab === tabName) {
                button.classList.add('active');
            } else {
                button.classList.remove('active');
            }
        });

        // 顯示/隱藏對應的標籤內容
        document.querySelectorAll('.tab-content').forEach(tab => {
            if (tab.id === `tab-${tabName}`) {
                tab.classList.add('active');
                tab.classList.remove('hidden');
            } else {
                tab.classList.remove('active');
                tab.classList.add('hidden');
            }
        });

        this.currentTab = tabName;

        // 如果處於掛單等待狀態且切換到非dashboard標籤頁，重置狀態
        if (this.isPendingSuspend && tabName !== 'dashboard') {
            this.isPendingSuspend = false;
            this.addMessage('已取消掛單操作（切換標籤頁）', 'info');
        }

        // 如果不是 booking tab，移除 booking mode
        if (tabName !== 'booking') document.body.classList.remove('booking-mode');
        // 載入對應標籤的內容
        switch(tabName) {
            case 'dashboard':
                this.loadDashboardData();
                break;
            case 'locker-management':
                this.loadLockerManagementTab();
                break;
            case 'products':
                this.loadProductsTab();
                break;
            case 'reports':
                this.loadReportsTab();
                break;
            case 'settings':
                this.loadSettingsTab();
                break;
            case 'employee-management':
                this.loadEmployeeManagementTab();
                break;
            case 'store-management':
                this.loadStores();
                break;
            case 'receipt-management':
                this.loadReceiptManagementTab();
                break;
            case 'host-config':
                this.loadHostConfigTab();
                break;
            case 'booking':
                document.body.classList.add('booking-mode');
                // 設定預設日期為今天
                // 設定預設日期為今天
                var btd = new Date();
                var btodayStr = btd.getFullYear() + '-' + String(btd.getMonth()+1).padStart(2,'0') + '-' + String(btd.getDate()).padStart(2,'0');
                var bdateInput = document.getElementById('bookingDateFilter');
                if (bdateInput && !bdateInput.value) bdateInput.value = btodayStr;
                if (bdateInput) bdateInput.min = btodayStr;
                // 綁定日期變更自動刷新預約列表
                if (bdateInput && !bdateInput._bookingDateBound) {
                    bdateInput._bookingDateBound = true;
                    bdateInput.addEventListener('change', function() { self.loadBookingInternal(); });
                }
                // 根據權限處理分店 filter
                var isAdmin = this.currentEmployee && this.currentEmployee.role === 'admin';
                var bstoreSelect = document.getElementById('bookingStoreFilter');
                if (bstoreSelect) {
                    if (isAdmin) {
                        bstoreSelect.disabled = false;
                        bstoreSelect.style.opacity = '1';
                        bstoreSelect.style.cursor = 'pointer';
                        if (this.selectedStoreId) bstoreSelect.value = this.selectedStoreId;
                    } else {
                        var empStore = this.currentEmployee ? this.currentEmployee.store_id : (this.selectedStoreId || '');
                        if (empStore) bstoreSelect.value = empStore;
                        bstoreSelect.disabled = true;
                        bstoreSelect.style.opacity = '0.7';
                        bstoreSelect.style.cursor = 'not-allowed';
                    }
                }
                // 綁定 refresh 同 查詢 button
                var self = this;
                var refreshBtn = document.getElementById('bookingRefreshBtn');
                if (refreshBtn && !refreshBtn._bookingBound) {
                    refreshBtn._bookingBound = true;
                    refreshBtn.addEventListener('click', function() {
                        var activeMtab = document.querySelector('.booking-main-tab.active') || document.querySelector('[data-mtab="booking"]');
                        var mtab = activeMtab ? activeMtab.getAttribute('data-mtab') : 'booking';
                        if (mtab === 'waiting') { self.loadWaitinglistInternal(); }
                        else if (mtab === 'settings') { self.loadBookingSettingsTab(); }
                        else { self.loadBookingInternal(); }
                        self.loadPausedStatus();
                    });
                }
                // 綁定暫停/恢復 button
                var pauseBtn = document.getElementById('bookingPauseBtn');
                if (pauseBtn && !pauseBtn._pauseBound) {
                    pauseBtn._pauseBound = true;
                    pauseBtn.addEventListener('click', function() { self.showPauseModal(); });
                }
                var resumeBtn = document.getElementById('bookingResumeBtn');
                if (resumeBtn && !resumeBtn._resumeBound) {
                    resumeBtn._resumeBound = true;
                    resumeBtn.addEventListener('click', function() { self.resumeSlots(); });
                }
                // 綁定暫停 modal 事件
                if (!this._pauseModalBound) {
                    this._pauseModalBound = true;
                    document.querySelectorAll('.btn-pause-duration').forEach(function(btn) {
                        btn.addEventListener('click', function() {
                            self.selectPauseDuration(parseInt(this.getAttribute('data-minutes')));
                        });
                    });
                    document.getElementById('pauseConfirmBtn').addEventListener('click', function() { self.confirmPause(); });
                    document.getElementById('pauseCancelBtn').addEventListener('click', function() {
                        document.getElementById('bookingPauseModal').style.display = 'none';
                        document.getElementById('bookingPauseModal').classList.add('hidden');
                    });
                    document.getElementById('pauseFinalConfirmBtn').addEventListener('click', function() { self.confirmPause(); });
                    document.getElementById('pauseFinalCancelBtn').addEventListener('click', function() {
                        document.getElementById('bookingPauseConfirmModal').style.display = 'none';
                        document.getElementById('bookingPauseConfirmModal').classList.add('hidden');
                    });
                }
                // 綁定設定 tab 事件（未來暫停 + 座位分配）
                if (!this._settingsTabBound) {
                    this._settingsTabBound = true;
                    var stSelf = this;
                    var addFpBtn = document.getElementById('addFuturePauseBtn');
                    if (addFpBtn) addFpBtn.addEventListener('click', function() { stSelf.showAddFuturePauseModal(); });
                    var confirmFpBtn = document.getElementById('confirmFuturePauseBtn');
                    if (confirmFpBtn) confirmFpBtn.addEventListener('click', function() { stSelf.confirmFuturePause(); });
                    var cancelFpBtn = document.getElementById('cancelFuturePauseBtn');
                    if (cancelFpBtn) cancelFpBtn.addEventListener('click', function() {
                        document.getElementById('addFuturePauseModal').style.display = 'none';
                        document.getElementById('addFuturePauseModal').classList.add('hidden');
                    });
                    var saveCapBtn = document.getElementById('saveCapacityBtn');
                    if (saveCapBtn) saveCapBtn.addEventListener('click', function() { stSelf.saveStoreCapacity(); });
                    var addBkBtn = document.getElementById('addBookingBtn');
                    if (addBkBtn) addBkBtn.addEventListener('click', function() { window.cashierSystem.showAddBookingModal(); });
                    var addBkSave = document.getElementById('addBkSave');
                    if (addBkSave) addBkSave.addEventListener('click', function() { window.cashierSystem.saveAddBooking(); });
                    var addBkCancel = document.getElementById('addBkCancel');
                    if (addBkCancel) addBkCancel.addEventListener('click', function() { window.cashierSystem.closeAddBookingModal(); });
                    var addWtBtn = document.getElementById('addWaitingBtn');
                    if (addWtBtn) addWtBtn.addEventListener('click', function() { window.cashierSystem.showAddWaitingModal(); });
                    var addWtSave = document.getElementById('addWtSave');
                    if (addWtSave) addWtSave.addEventListener('click', function() { window.cashierSystem.saveAddWaiting(); });
                    var addWtCancel = document.getElementById('addWtCancel');
                    if (addWtCancel) addWtCancel.addEventListener('click', function() { window.cashierSystem.closeAddWaitingModal(); });
                    // 綁定設定 tab 分店選擇
                    var stStoreSelect = document.getElementById('settingsStoreSelect');
                    if (stStoreSelect && !stStoreSelect._settingsBound) {
                        stStoreSelect._settingsBound = true;
                        stStoreSelect.addEventListener('change', function() { stSelf.loadBookingSettingsTab(); });
                    }
                    // 綁定 daytype tab 切換
                    if (!this._capDaytypeBound) {
                        this._capDaytypeBound = true;
                        document.querySelectorAll('.cap-daytype-tab').forEach(function(btn) {
                            btn.addEventListener('click', function() {
                                document.querySelectorAll('.cap-daytype-tab').forEach(function(b) {
                                    var grp = b.getAttribute('data-capgroup');
                                    if (b === btn) {
                                        b.style.background = '#8B4513'; b.style.color = 'white'; b.style.borderColor = '#8B4513';
                                        b.classList.add('active');
                                    } else {
                                        b.style.background = 'white'; b.style.color = '#555'; b.style.borderColor = '#e0e0e0';
                                        b.classList.remove('active');
                                    }
                                });
                                stSelf.renderCapGrid();
                            });
                        });
                    }
                    var capFilter = document.getElementById('bookingStoreFilter');
                    if (capFilter) capFilter.addEventListener('change', function() { stSelf.loadStoreCapacity(this.value); });
                }
                var phoneInput = document.getElementById('bookingPhoneFilter');
                if (phoneInput && !phoneInput._phoneBound) {
                    phoneInput._phoneBound = true;
                    phoneInput.addEventListener('input', function() { self.loadBookingInternal(); });
                }
                var clearBtn = document.getElementById('bookingPhoneClear');
                if (clearBtn && !clearBtn._phoneClearBound) {
                    clearBtn._phoneClearBound = true;
                    clearBtn.addEventListener('click', function() {
                        document.getElementById('bookingPhoneFilter').value = '';
                        self.loadBookingInternal();
                    });
                }
                var queryBtn = document.getElementById('bookingQueryBtn');
                if (queryBtn && !queryBtn._bookingBound) {
                    queryBtn._bookingBound = true;
                    queryBtn.addEventListener('click', function() { self.loadBookingInternal(); });
                }
                // 綁定編輯預約 modal
                if (!this._bookingEditBound) {
                    this._bookingEditBound = true;
                    var edSelf = this;
                    var saveBtn = document.getElementById('bookingEditSave');
                    if (saveBtn) saveBtn.addEventListener('click', function() { edSelf.saveBookingInternal(); });
                    var cancelBtn = document.getElementById('bookingEditCancel');
                    if (cancelBtn) cancelBtn.addEventListener('click', function() {
                        document.getElementById('bookingEditModal').style.display = 'none';
                        document.getElementById('bookingEditModal').classList.add('hidden');
                    });
                    var dateInput = document.getElementById('bookingEditDate');
                    if (dateInput) dateInput.addEventListener('change', function() {
                        edSelf.populateEditTimeSlots(this.value, '');
                    });
                }
                // 綁定 sub-tab click（refresh 資料）
                if (!this._bookingSubTabBound) {
                    this._bookingSubTabBound = true;
                    var stSelf = this;
                    document.querySelectorAll('.booking-sub-tab').forEach(function(btn) {
                        btn.addEventListener('click', function() {
                            stSelf._bookingSubTab = this.getAttribute('data-btab');
                            stSelf.loadBookingInternal();
                        });
                    });
                }
                // 綁定 waiting sub-tab click（refresh 資料）
                if (!this._waitingSubTabBound) {
                    this._waitingSubTabBound = true;
                    var wstSelf = this;
                    document.querySelectorAll('.waiting-sub-tab').forEach(function(btn) {
                        btn.addEventListener('click', function() {
                            wstSelf._waitingSubTab = this.getAttribute('data-wtab');
                            wstSelf.loadWaitinglistInternal();
                        });
                    });
                }
                // 綁定 main tab click（預約/候位/設定）
                if (!this._bookingMainTabBound) {
                    this._bookingMainTabBound = true;
                    var mtSelf = this;
                    document.querySelectorAll('.booking-main-tab').forEach(function(btn) {
                        btn.addEventListener('click', function() {
                            var mtab = this.getAttribute('data-mtab');
                            document.querySelectorAll('.booking-main-tab').forEach(function(b) {
                                if (b.getAttribute('data-mtab') === mtab) {
                                    b.style.background = '#8B4513'; b.style.color = 'white'; b.style.borderColor = '#8B4513';
                                    b.classList.add('active');
                                } else {
                                    b.style.background = 'white'; b.style.color = '#555'; b.style.borderColor = '#e0e0e0';
                                    b.classList.remove('active');
                                }
                            });
                            document.getElementById('bookingMainSection').style.display = mtab === 'booking' ? 'block' : 'none';
                            document.getElementById('waitinglistSection').style.display = mtab === 'waiting' ? 'block' : 'none';
                            document.getElementById('bookingSettingsSection').style.display = mtab === 'settings' ? 'block' : 'none';
                            if (mtab === 'waiting') {
                                mtSelf._waitingSubTab = 'waiting';
                                mtSelf.loadWaitinglistInternal();
                            } else if (mtab === 'settings') {
                                mtSelf.loadBookingSettingsTab();
                            } else {
                                mtSelf._bookingSubTab = 'confirmed';
                                mtSelf.loadBookingInternal();
                            }
                        });
                    });
                }
                if (!this._waitingStoreBound) {
                    this._waitingStoreBound = true;
                    var wsSelf = this;
                    var wsfBind = document.getElementById('waitingStoreFilter');
                    if (wsfBind) wsfBind.addEventListener('change', function() { wsSelf.loadWaitinglistInternal(); });
                }
                // 每次 sync waiting store filter
                var wsf = document.getElementById('waitingStoreFilter');
                if (wsf) {
                    var isAdmin = this.currentEmployee && this.currentEmployee.role === 'admin';
                    if (isAdmin) {
                        wsf.disabled = false; wsf.style.opacity = '1'; wsf.style.cursor = 'pointer';
                        if (this.selectedStoreId) wsf.value = this.selectedStoreId;
                    } else {
                        var empStore = this.currentEmployee ? this.currentEmployee.store_id : (this.selectedStoreId || '');
                        if (empStore) wsf.value = empStore;
                        wsf.disabled = true; wsf.style.opacity = '0.7'; wsf.style.cursor = 'not-allowed';
                    }
                }
                // 載入預約及候位資料
                this.loadBookingInternal();
                this.loadWaitinglistInternal();
                this.loadPausedStatus();
                break;
        }

        // 處理上下文（如從儲物柜分配跳轉）
        console.log(`Checking context: context.fromLockerAssignment=${context.fromLockerAssignment}, tabName=${tabName}, this.pendingLockerAssignment=`, this.pendingLockerAssignment);
        console.log(`Context object keys:`, Object.keys(context));
        if (context.fromLockerAssignment && tabName === 'dashboard') {
            console.log(`Showing locker assignment prompt after delay...`);
            // 延遲顯示分配提示，等待數據加載完成
            setTimeout(() => {
                console.log(`Timeout callback: calling showLockerAssignmentPrompt, pendingLockerAssignment=`, this.pendingLockerAssignment);
                this.showLockerAssignmentPrompt();
            }, 500);
        }

        // 更新URL哈希（可選）
        window.location.hash = tabName;
    }

    // 標籤頁內容加載方法
    async loadDashboardData() {
        // 使用父類的方法載入現有數據
        this.loadCustomers();
        this.loadProducts();
        this.loadTodayStats();
        this.loadEntryRecords();
        this.loadDeviceStatus();

        // 初始化商品分類篩選器（如果存在於dashboard中）
        await this.loadProductCategories();
        this.populateCategoryFilters();
    }


    async loadProductsTab() {
        // 商品管理標籤內容
        if (!this.isAuthenticated) {
            this.addMessage('請先登入以管理商品', 'warning');
            return;
        }

        // 重置篩選條件（避免隱藏欄位殘留舊值導致員工看不到商品）
        const searchInput = document.getElementById('product-search');
        if (searchInput) searchInput.value = '';
        const categoryFilter = document.getElementById('product-category-filter');
        if (categoryFilter) categoryFilter.value = '';
        const stockFilter = document.getElementById('product-stock-filter');
        if (stockFilter) stockFilter.value = '';

        // 載入商品數據
        await this.loadProductsTabData();

        // 載入商品分類
        await this.loadProductCategories();

        // 初始化篩選器
        this.populateCategoryFilters();
    }

    async loadProductsTabData() {
        try {
            const response = await this.fetchWithAuth('/api/products?ignore_time_restriction=true&page_size=1000');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const result = await response.json();

            if (result.success) {
                console.log('API返回的商品數據:', {
                    total: result.data.products?.length || 0,
                    products: result.data.products?.map(p => ({
                        id: p.id,
                        name: p.name,
                        category: p.category,
                        is_available: p.is_available,
                        is_time_available: p.is_time_available,
                        has_time_restriction: p.has_time_restriction,
                        holiday_start_time: p.holiday_start_time,
                        holiday_end_time: p.holiday_end_time,
                        holiday_start_time_2: p.holiday_start_time_2,
                        holiday_end_time_2: p.holiday_end_time_2
                    })),
                    data: result.data
                });
                this.productsList = result.data.products || [];
                this.products = this.productsList; // 同時設置父類商品數組以保持兼容性
                this.productPagination.totalItems = this.productsList.length;
                this.productPagination.totalPages = Math.ceil(this.productsList.length / this.productPagination.itemsPerPage);
                this.productPagination.currentPage = 1;

                // 保留當前分類篩選值，HTML已有默認值"全部類別"（空字符串）
                // 無需設置默認值，使用HTML中的默認值

                this.applyProductFilters(); // 初始化篩選
                this.renderProductsTable();
                this.updateProductPaginationUI();
            } else {
                this.addMessage(`載入商品失敗: ${result.message}`, 'error');
            }
        } catch (error) {
            console.warn('API商品加載失敗，使用模擬商品數據:', error.message);
            // 使用模擬商品數據作為後備
            const mockProducts = this.generateMockProducts();
            this.productsList = mockProducts;
            this.products = mockProducts; // 同時設置父類商品數組以保持兼容性
            this.productPagination.totalItems = this.productsList.length;
            this.productPagination.totalPages = Math.ceil(this.productsList.length / this.productPagination.itemsPerPage);
            this.productPagination.currentPage = 1;

            // 保留當前分類篩選值，HTML已有默認值"全部類別"（空字符串）
            // 無需設置默認值，使用HTML中的默認值

            this.applyProductFilters(); // 初始化篩選
            this.renderProductsTable();
            this.updateProductPaginationUI();

            this.addMessage('使用模擬商品數據進行測試', 'info');
        }
    }

    async loadProductCategories() {
        // 如果未登入，直接使用默認分類，避免401錯誤
        if (!this.isAuthenticated) {
            console.log('未登入狀態，使用默認商品分類');
            const customCategoryOrder = [
                '收費',
                '貓零食',
                '甜品輕食',
                '沖調飲品',
                '輕便飲品',
                '紀念品',
                '寵物用品'
            ];
            this.productCategories = customCategoryOrder;
            console.log('最終分類列表（按自定義順序）:', this.productCategories);
            return;
        }

        try {
            const response = await this.fetchWithAuth('/api/products/categories');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const result = await response.json();

            if (result.success) {
                this.productCategories = result.data.categories || [];
                console.log('API返回的商品分類:', this.productCategories);

                // 過濾亂碼分類：移除包含亂碼字符或無效的分類
                this.productCategories = this.productCategories.filter(category => {
                    if (!category || typeof category !== 'string') return false;

                    const trimmed = category.trim();
                    if (trimmed === '') return false;

                    // 檢查是否包含常見的亂碼字符
                    if (trimmed.includes('�') || trimmed.includes('�') || trimmed.includes('�')) {
                        console.log('過濾亂碼分類:', category);
                        return false;
                    }

                    // 檢查是否包含過多非中文字符（允許中文、英文、數字、空格和常見標點）
                    // 簡單檢查：至少包含一個中文字符或英文字母
                    const hasValidChar = /[\u4e00-\u9fa5a-zA-Z]/.test(trimmed);
                    if (!hasValidChar) {
                        console.log('過濾無有效字符的分類:', category);
                        return false;
                    }

                    return true;
                });

                console.log('過濾後的分類:', this.productCategories);
            } else {
                console.warn('載入商品分類失敗:', result.message);
                this.productCategories = [];
            }
        } catch (error) {
            console.warn('載入商品分類失敗:', error.message);
            this.productCategories = [];
        }

        // 自定義分類順序（按照用戶指定順序）
        const customCategoryOrder = [
            '收費',
            '貓零食',
            '甜品輕食', // 包含原"甜品"分類的商品
            '沖調飲品',
            '輕便飲品',
            '紀念品',
            '寵物用品'
        ];

        if (this.productCategories.length > 0) {
            // 按照自定義順序排序
            this.productCategories.sort((a, b) => {
                const indexA = customCategoryOrder.indexOf(a);
                const indexB = customCategoryOrder.indexOf(b);

                // 如果在自定義順序中，按照自定義順序排序
                if (indexA !== -1 && indexB !== -1) return indexA - indexB;
                // 如果a在自定義順序中，b不在，a在前
                if (indexA !== -1) return -1;
                // 如果b在自定義順序中，a不在，b在前
                if (indexB !== -1) return 1;
                // 都不在自定義順序中，按字母順序排序
                return a.localeCompare(b, 'zh-Hans-CN');
            });
        } else {
            // 如果沒有API分類，使用用戶指定的分類
            this.productCategories = customCategoryOrder;
        }

        console.log('最終分類列表（按自定義順序）:', this.productCategories);
    }

    populateCategoryFilters() {
        console.log('populateCategoryFilters called');
        const categoryFilter = document.getElementById('product-category-filter');
        const modalCategory = document.getElementById('product-category');

        console.log('categoryFilter found:', !!categoryFilter, 'modalCategory found:', !!modalCategory);
        if (!categoryFilter || !modalCategory) {
            console.warn('Category filter elements not found');
            return;
        }

        // 清空現有選項（保留第一個選項）
        while (categoryFilter.options.length > 1) categoryFilter.remove(1);
        while (modalCategory.options.length > 1) modalCategory.remove(1);

        console.log('Current productCategories:', this.productCategories);

        // 添加分類選項
        this.productCategories.forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = category;
            categoryFilter.appendChild(option.cloneNode(true));
            modalCategory.appendChild(option);
        });

        // 調試：顯示最終選項
        console.log('Final category filter options:', Array.from(categoryFilter.options).map(opt => ({value: opt.value, text: opt.textContent})));

        // 動態生成分類標籤
        this.populateCategoryTabs();
    }

    populateCategoryTabs() {
        console.log('populateCategoryTabs called');
        const tabsContainer = document.querySelector('.category-tabs-container');
        if (!tabsContainer) {
            console.warn('Category tabs container not found');
            return;
        }

        // 清空現有標籤
        tabsContainer.innerHTML = '';

        // 添加API返回的分類標籤
        this.productCategories.forEach((category, index) => {
            const tab = document.createElement('button');
            // 第一個標籤設為active
            tab.className = index === 0 ? 'category-tab-button active' : 'category-tab-button';
            tab.dataset.category = category;
            tab.innerHTML = `<i class="fas fa-tag"></i> <span>${category}</span>`;
            tab.addEventListener('click', (e) => {
                e.preventDefault();
                this.switchProductCategory(category);
            });
            tabsContainer.appendChild(tab);
        });

        // 如果至少有一個分類，設置第一個分類為活躍並應用篩選
        if (this.productCategories.length > 0) {
            const firstCategory = this.productCategories[0];
            // 設置下拉選單值
            const categoryFilter = document.getElementById('product-category-filter');
            if (categoryFilter) {
                categoryFilter.value = firstCategory;
            }
            // 應用篩選
            this.applyProductFilters();
        } else {
            // 如果沒有分類，設置下拉選單為空值
            const categoryFilter = document.getElementById('product-category-filter');
            if (categoryFilter) {
                categoryFilter.value = '';
            }
        }

        console.log(`Generated ${this.productCategories.length} category tabs`);
    }

    toggleProductSelectionMode() {
        this.productSelectionMode = !this.productSelectionMode;
        this.selectedProductId = null;

        console.log('商品選擇模式:', this.productSelectionMode ? '已啟用' : '已停用');

        // 更新操作按鈕外觀
        const operationBtn = document.getElementById('product-operation-btn');
        if (operationBtn) {
            if (this.productSelectionMode) {
                operationBtn.classList.add('active');
                operationBtn.innerHTML = '<i class="fas fa-times"></i> <span data-i18n="cancelOperationBtn">取消操作</span>';
            } else {
                operationBtn.classList.remove('active');
                operationBtn.innerHTML = '<i class="fas fa-cog"></i> <span data-i18n="operationBtn">操作</span>';
            }
            this.updateTranslations(); // 更新翻譯
        }

        // 重新渲染商品表格以反映選擇模式狀態
        this.renderProductsTable();

        // 顯示提示訊息
        if (this.productSelectionMode) {
            this.addMessage('已進入商品選擇模式，請點選一個商品進行操作', 'info');
        } else {
            this.addMessage('已取消商品選擇模式', 'info');
        }
    }

    selectProductForOperation(productId) {
        console.log('選擇商品進行操作:', productId);
        console.log('productsList 長度:', this.productsList.length);
        console.log('productsList 前5個商品:', this.productsList.slice(0, 5).map(p => ({id: p.id, name: p.name})));

        // 找到對應的商品
        const product = this.productsList.find(p => p.id == productId);
        console.log('找到的商品:', product ? {id: product.id, name: product.name} : '未找到');
        if (!product) {
            this.addMessage('找不到對應的商品', 'error');
            return;
        }

        // 更新選中商品ID
        this.selectedProductId = productId;

        // 重新渲染商品表格以顯示選中狀態
        this.renderProductsTable();

        // 顯示操作菜單模態框
        this.showProductOperationModal(product);
    }

    showProductOperationModal(product) {
        console.log('showProductOperationModal 收到商品:', {id: product.id, name: product.name});
        const isAdmin = this.currentEmployee && this.currentEmployee.role === 'admin';
        console.log(`showProductOperationModal: isAdmin=${isAdmin}, currentEmployee role=${this.currentEmployee?.role}`);
        // 總是重新創建模態框以確保事件監聽器是最新的
        const existingModal = document.getElementById('product-operation-modal');
        if (existingModal) {
            existingModal.remove();
        }

        // 創建模態框HTML
        const modal = document.createElement('div');
        modal.id = 'product-operation-modal';
        modal.className = 'modal hidden';
        modal.innerHTML = `
                <div class="modal-content">
                    <div class="modal-header">
                        <h3><i class="fas fa-cog"></i> <span data-i18n="productOperationTitle">商品操作</span></h3>
                        <button class="modal-close" id="close-product-operation-modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p><strong>商品:</strong> ${this.escapeHtml(product.name)}</p>
                        <p><strong>價格:</strong> $${product.price.toFixed(2)}</p>
                        <p><strong>庫存:</strong> ${product.stock}</p>
                        <div class="operation-buttons">
                            <button class="btn-primary btn-edit-product" data-product-id="${product.id}">
                                <i class="fas fa-edit"></i> <span data-i18n="editBtn">編輯</span>
                            </button>
                            <button class="btn-danger btn-delete-product" data-product-id="${product.id}">
                                <i class="fas fa-trash"></i> <span data-i18n="deleteBtn">刪除</span>
                            </button>
                            <button class="btn-secondary btn-restock-product" data-product-id="${product.id}">
                                <i class="fas fa-boxes"></i> <span data-i18n="restockBtn">補貨</span>
                            </button>
                            <button class="btn-secondary btn-adjust-product" data-product-id="${product.id}">
                                <i class="fas fa-adjust"></i> <span data-i18n="adjustBtn">調整</span>
                            </button>
                            <button class="btn-secondary btn-cancel-operation" id="cancel-product-operation">
                                <i class="fas fa-times"></i> <span data-i18n="cancelBtn">取消</span>
                            </button>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);

            // 隱藏非管理員的編輯和刪除按鈕
            if (!isAdmin) {
                console.log('非管理員用戶，隱藏商品操作視窗中的編輯和刪除按鈕');
                const editBtn = modal.querySelector('.btn-edit-product');
                const deleteBtn = modal.querySelector('.btn-delete-product');
                if (editBtn) editBtn.style.display = 'none';
                if (deleteBtn) deleteBtn.style.display = 'none';
            }

            // 綁定事件
            modal.querySelector('#close-product-operation-modal').addEventListener('click', () => this.hideProductOperationModal());
            modal.querySelector('#cancel-product-operation').addEventListener('click', () => this.hideProductOperationModal());
            modal.querySelector('.btn-edit-product').addEventListener('click', (e) => {
                console.log('編輯按鈕被點擊，按鈕 dataset:', e.currentTarget.dataset);
                console.log('data-product-id:', e.currentTarget.dataset.productId);
                this.hideProductOperationModal();
                const productId = e.currentTarget.dataset.productId;
                console.log('從按鈕獲取的 productId:', productId);
                const productObj = this.productsList.find(p => p.id == productId);
                console.log('找到的商品對象:', productObj ? {id: productObj.id, name: productObj.name} : '未找到');
                if (productObj) {
                    this.showProductModal(productObj);
                } else {
                    this.addMessage('找不到對應的商品', 'error');
                }
            });
            modal.querySelector('.btn-delete-product').addEventListener('click', (e) => {
                this.hideProductOperationModal();
                const productId = e.currentTarget.dataset.productId;
                this.deleteProduct(productId);
            });
            modal.querySelector('.btn-restock-product').addEventListener('click', (e) => {
                this.hideProductOperationModal();
                const productId = e.currentTarget.dataset.productId;
                const productObj = this.productsList.find(p => p.id == productId);
                if (productObj) {
                    this.showRestockModal(productObj);
                } else {
                    this.addMessage('找不到對應的商品', 'error');
                }
            });
            modal.querySelector('.btn-adjust-product').addEventListener('click', (e) => {
                this.hideProductOperationModal();
                const productId = e.currentTarget.dataset.productId;
                const productObj = this.productsList.find(p => p.id == productId);
                if (productObj) {
                    this.showAdjustModal(productObj);
                } else {
                    this.addMessage('找不到對應的商品', 'error');
                }
            });

            // 點擊模態框外部關閉
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.hideProductOperationModal();
                }
            });

        // 更新商品信息（如果模態框已存在）
        modal.querySelector('p:nth-child(1)').innerHTML = `<strong>商品:</strong> ${this.escapeHtml(product.name)}`;
        modal.querySelector('p:nth-child(2)').innerHTML = `<strong>價格:</strong> $${product.price.toFixed(2)}`;
        modal.querySelector('p:nth-child(3)').innerHTML = `<strong>庫存:</strong> ${product.stock}`;

        // 更新按鈕的data-product-id
        modal.querySelectorAll('[data-product-id]').forEach(button => {
            button.dataset.productId = product.id;
        });

        // 顯示模態框
        modal.classList.remove('hidden');
    }

    hideProductOperationModal() {
        const modal = document.getElementById('product-operation-modal');
        if (modal) {
            modal.classList.add('hidden');
        }

        // 退出選擇模式
        this.productSelectionMode = false;
        this.selectedProductId = null;

        // 更新操作按鈕外觀
        const operationBtn = document.getElementById('product-operation-btn');
        if (operationBtn) {
            operationBtn.classList.remove('active');
            operationBtn.innerHTML = '<i class="fas fa-cog"></i> <span data-i18n="operationBtn">操作</span>';
            this.updateTranslations();
        }

        // 重新渲染商品表格
        this.renderProductsTable();
    }

    showProductModal(product = null) {
        console.log('showProductModal 收到商品:', product ? {id: product.id, name: product.name} : 'null');
        const modal = document.getElementById('product-modal');
        const title = document.getElementById('product-modal-title');
        const form = document.getElementById('product-form');

        if (product) {
            // 編輯模式
            title.setAttribute('data-i18n', 'editProductTitle');
            console.log('設置表單值，商品名稱:', product.name);
            document.getElementById('product-id').value = product.id;
            document.getElementById('product-uuid').value = product.id;
            document.getElementById('product-uuid').disabled = true; // 編輯時禁用UUID修改
            document.getElementById('product-name').value = product.name;
            document.getElementById('product-price').value = product.price;
            document.getElementById('product-stock').value = product.stock;
            document.getElementById('product-min-stock').value = product.min_stock || 0;
            document.getElementById('product-category').value = product.category || '';
            document.getElementById('product-order').value = product.product_order !== undefined ? product.product_order : 0;

            // 設置不計庫存選項
            const trackInventory = product.track_inventory !== undefined ? product.track_inventory : 1;
            document.getElementById('product-no-inventory').checked = trackInventory === 0;

            // 根據是否計庫存設置庫存字段狀態
            this.updateInventoryFieldState(trackInventory === 0);

            // 設置商品時效字段
            const hasTimeRestriction = product.has_time_restriction !== undefined ? product.has_time_restriction : 0;
            document.getElementById('product-time-restriction').checked = hasTimeRestriction === 1;
            document.getElementById('product-weekday-start').value = product.weekday_start_time || '';
            document.getElementById('product-weekday-end').value = product.weekday_end_time || '';
            document.getElementById('product-holiday-start').value = product.holiday_start_time || '';
            document.getElementById('product-holiday-end').value = product.holiday_end_time || '';
            document.getElementById('product-weekday-start-2').value = product.weekday_start_time_2 || '';
            document.getElementById('product-weekday-end-2').value = product.weekday_end_time_2 || '';
            document.getElementById('product-holiday-start-2').value = product.holiday_start_time_2 || '';
            document.getElementById('product-holiday-end-2').value = product.holiday_end_time_2 || '';

            // 顯示/隱藏時間字段
            this.updateTimeRestrictionFieldsState(hasTimeRestriction === 1);
        } else {
            // 新增模式
            title.setAttribute('data-i18n', 'addProductTitle');
            form.reset();
            document.getElementById('product-id').value = '';
            document.getElementById('product-uuid').value = '';
            document.getElementById('product-uuid').disabled = false; // 新增時啟用UUID輸入

            // 默認啟用庫存字段
            this.updateInventoryFieldState(false);

            // 默認禁用商品時效
            document.getElementById('product-time-restriction').checked = false;
            document.getElementById('product-weekday-start').value = '';
            document.getElementById('product-weekday-end').value = '';
            document.getElementById('product-holiday-start').value = '';
            document.getElementById('product-holiday-end').value = '';
            document.getElementById('product-weekday-start-2').value = '';
            document.getElementById('product-weekday-end-2').value = '';
            document.getElementById('product-holiday-start-2').value = '';
            document.getElementById('product-holiday-end-2').value = '';
            this.updateTimeRestrictionFieldsState(false);
        }

        // 清除UUID錯誤提示
        const uuidErrorElement = document.getElementById('product-uuid-error');
        if (uuidErrorElement) {
            uuidErrorElement.style.display = 'none';
            uuidErrorElement.textContent = '';
        }

        // 更新翻譯
        this.updateTranslations();

        // 綁定不計庫存複選框事件
        const noInventoryCheckbox = document.getElementById('product-no-inventory');
        // 移除舊的事件監聽器（避免重複綁定）
        const newNoInventoryCheckbox = noInventoryCheckbox.cloneNode(true);
        noInventoryCheckbox.parentNode.replaceChild(newNoInventoryCheckbox, noInventoryCheckbox);

        newNoInventoryCheckbox.addEventListener('change', (e) => {
            this.updateInventoryFieldState(e.target.checked);
        });

        // 綁定商品時效複選框事件
        const timeRestrictionCheckbox = document.getElementById('product-time-restriction');
        // 移除舊的事件監聽器（避免重複綁定）
        const newTimeRestrictionCheckbox = timeRestrictionCheckbox.cloneNode(true);
        timeRestrictionCheckbox.parentNode.replaceChild(newTimeRestrictionCheckbox, timeRestrictionCheckbox);

        newTimeRestrictionCheckbox.addEventListener('change', (e) => {
            this.updateTimeRestrictionFieldsState(e.target.checked);
        });

        modal.classList.remove('hidden');
    }

    updateInventoryFieldState(noInventory) {
        const stockInput = document.getElementById('product-stock');
        const minStockInput = document.getElementById('product-min-stock');
        const noInventoryCheckbox = document.getElementById('product-no-inventory');

        if (noInventory) {
            // 不計庫存時，禁用庫存字段並設置默認值
            stockInput.disabled = true;
            stockInput.value = 0;
            minStockInput.disabled = true;
            minStockInput.value = 0;
            noInventoryCheckbox.checked = true;
        } else {
            // 計庫存時，啟用庫存字段
            stockInput.disabled = false;
            minStockInput.disabled = false;
            noInventoryCheckbox.checked = false;
        }
    }

    updateTimeRestrictionFieldsState(hasTimeRestriction) {
        const timeFields = document.getElementById('time-restriction-fields');
        if (timeFields) {
            timeFields.style.display = hasTimeRestriction ? 'block' : 'none';
        }
    }

    hideProductModal() {
        document.getElementById('product-modal').classList.add('hidden');
    }

    async handleProductFormSubmit(event) {
        event.preventDefault();

        // 清除UUID錯誤提示
        const uuidErrorElement = document.getElementById('product-uuid-error');
        if (uuidErrorElement) {
            uuidErrorElement.style.display = 'none';
            uuidErrorElement.textContent = '';
        }

        const productId = document.getElementById('product-id').value;
        const customUUID = document.getElementById('product-uuid').value.trim();
        const noInventory = document.getElementById('product-no-inventory').checked;
        const productData = {
            name: document.getElementById('product-name').value.trim(),
            description: '',
            price: parseFloat(document.getElementById('product-price').value),
            stock: parseInt(document.getElementById('product-stock').value),
            min_stock: parseInt(document.getElementById('product-min-stock').value),
            category: document.getElementById('product-category').value,
            product_order: parseInt(document.getElementById('product-order').value) || 0,
            track_inventory: noInventory ? 0 : 1,
            // 商品時效字段
            has_time_restriction: document.getElementById('product-time-restriction').checked ? 1 : 0,
            weekday_start_time: document.getElementById('product-weekday-start').value || null,
            weekday_end_time: document.getElementById('product-weekday-end').value || null,
            holiday_start_time: document.getElementById('product-holiday-start').value || null,
            holiday_end_time: document.getElementById('product-holiday-end').value || null,
            weekday_start_time_2: document.getElementById('product-weekday-start-2').value || null,
            weekday_end_time_2: document.getElementById('product-weekday-end-2').value || null,
            holiday_start_time_2: document.getElementById('product-holiday-start-2').value || null,
            holiday_end_time_2: document.getElementById('product-holiday-end-2').value || null
        };

        // 如果不計庫存，設置庫存為0
        if (noInventory) {
            productData.stock = 0;
            productData.min_stock = 0;
        }

        // 驗證必填字段
        if (!productData.name || isNaN(productData.price) || productData.stock < 0) {
            this.addMessage('請填寫有效的商品信息', 'warning');
            return;
        }

        // 新增商品時處理自定義UUID
        if (!productId) {
            console.log('新增商品模式，productId:', productId, 'customUUID:', customUUID);
            if (customUUID) {
                // 檢查UUID格式（至少應該是有效的字符串）
                if (customUUID.length < 1) {
                    this.addMessage('UUID不能為空', 'warning');
                    return;
                }
                // 添加自定義ID到請求數據
                productData.id = customUUID;
                console.log('自定義UUID已添加到productData:', customUUID, '完整productData:', JSON.stringify(productData));
            } else {
                console.log('沒有自定義UUID，將由後端自動生成');
            }
            // 如果沒有自定義UUID，後端將自動生成
        }

        try {
            const url = productId ? `/api/products/${productId}` : '/api/products';
            const method = productId ? 'PUT' : 'POST';

            console.log('發送商品數據到後端:', { url, method, productData: JSON.stringify(productData) });

            const response = await this.fetchWithAuth(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(productData)
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage(productId ? '商品更新成功' : '商品添加成功', 'success');
                this.hideProductModal();
                await this.loadProductsTabData(); // 重新載入商品列表
            } else {
                // 檢查是否為UUID重複錯誤
                if ((result.error === 'ID已被使用' || result.message?.includes('商品ID')) && !productId) {
                    // 在UUID輸入字段下方顯示錯誤
                    const uuidErrorElement = document.getElementById('product-uuid-error');
                    if (uuidErrorElement) {
                        uuidErrorElement.textContent = result.message || result.error;
                        uuidErrorElement.style.display = 'block';
                    }
                    // 仍然顯示全局錯誤消息
                    this.addMessage(`操作失敗: ${result.message}`, 'error');
                } else {
                    this.addMessage(`操作失敗: ${result.message}`, 'error');
                }
            }
        } catch (error) {
            this.addMessage(`操作失敗: ${error.message}`, 'error');
        }
    }

    // 批量商品上傳相關方法
    showBatchProductModal() {
        document.getElementById('batch-product-modal').classList.remove('hidden');
        // 清空預覽和摘要
        document.getElementById('csv-preview').innerHTML = '<p class="empty-preview-message" data-i18n="noFileSelected">未選擇檔案</p>';
        document.getElementById('upload-summary').innerHTML = '<p class="empty-summary-message" data-i18n="noDataToUpload">無數據可上傳</p>';
        // 重置文件輸入
        const csvFileInput = document.getElementById('csv-file');
        if (csvFileInput) csvFileInput.value = '';
    }

    hideBatchProductModal() {
        document.getElementById('batch-product-modal').classList.add('hidden');
    }

    async handleCSVFileSelect(event) {
        const file = event.target.files[0];
        if (!file) return;

        // 驗證文件類型
        if (!file.name.toLowerCase().endsWith('.csv')) {
            this.addMessage('請選擇CSV檔案', 'warning');
            return;
        }

        try {
            const products = await this.parseCSVFile(file);
            this.displayCSVPreview(products);
            this.displayUploadSummary(products);
        } catch (error) {
            this.addMessage(`解析CSV失敗: ${error.message}`, 'error');
        }
    }

    async parseCSVFile(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const content = e.target.result;
                    const lines = content.split('\n').filter(line => line.trim().length > 0);

                    if (lines.length === 0) {
                        reject(new Error('CSV檔案為空'));
                        return;
                    }

                    const products = [];
                    for (let i = 0; i < lines.length; i++) {
                        const line = lines[i].trim();
                        // 處理CSV，使用逗號分隔
                        const columns = line.split(',').map(col => col.trim());

                        if (columns.length < 4) {
                            throw new Error(`第${i + 1}行: 需要至少4個欄位 (商品名稱, 分類, UUID, 價格)`);
                        }

                        const product = {
                            name: columns[0],
                            category: columns[1],
                            id: columns[2], // 自定義UUID
                            price: parseFloat(columns[3]),
                            product_order: columns.length >= 5 ? parseInt(columns[4]) || 0 : 0, // 第5欄為順序，預設0
                            stock: 0, // 預設不計庫存
                            min_stock: 0,
                            track_inventory: 0 // 不計庫存
                        };

                        // 驗證價格
                        if (isNaN(product.price) || typeof product.price !== 'number') {
                            throw new Error(`第${i + 1}行: 價格必須為有效的數字`);
                        }

                        // 如果UUID為空，則自動生成
                        if (!product.id || product.id.trim() === '') {
                            product.id = crypto.randomUUID ? crypto.randomUUID() : this.generateUUID();
                        }

                        products.push(product);
                    }

                    console.log('parseCSVFile resolved products:', products);
                    resolve(products);
                } catch (error) {
                    reject(error);
                }
            };
            reader.onerror = () => reject(new Error('讀取檔案失敗'));
            reader.readAsText(file, 'UTF-8');
        });
    }

    generateUUID() {
        // 簡單的UUID生成器（非標準，僅用於後備方案）
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    displayCSVPreview(products) {
        const previewContainer = document.getElementById('csv-preview');

        if (products.length === 0) {
            previewContainer.innerHTML = '<p class="empty-preview-message" data-i18n="noDataToUpload">無數據可上傳</p>';
            return;
        }

        let html = '<table>';
        html += '<thead><tr><th>商品名稱</th><th>分類</th><th>UUID</th><th>價格</th><th>順序</th></tr></thead>';
        html += '<tbody>';

        products.forEach((product, index) => {
            html += `<tr>
                <td>${this.escapeHTML(product.name)}</td>
                <td>${this.escapeHTML(product.category)}</td>
                <td><code>${this.escapeHTML(product.id)}</code></td>
                <td>$${product.price.toFixed(2)}</td>
                <td>${product.product_order !== undefined ? product.product_order : 0}</td>
            </tr>`;
        });

        html += '</tbody></table>';
        previewContainer.innerHTML = html;
    }

    displayUploadSummary(products) {
        const summaryContainer = document.getElementById('upload-summary');

        if (products.length === 0) {
            summaryContainer.innerHTML = '<p class="empty-summary-message" data-i18n="noDataToUpload">無數據可上傳</p>';
            return;
        }

        let html = '';
        html += `<div class="summary-item">
            <strong>總商品數:</strong> ${products.length} 個商品
        </div>`;

        // 分類統計
        const categories = {};
        products.forEach(product => {
            categories[product.category] = (categories[product.category] || 0) + 1;
        });

        html += `<div class="summary-item">
            <strong>分類分佈:</strong><br>`;
        for (const [category, count] of Object.entries(categories)) {
            html += `- ${this.escapeHTML(category)}: ${count} 個商品<br>`;
        }
        html += `</div>`;

        summaryContainer.innerHTML = html;
    }

    escapeHTML(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    async handleBatchProductSubmit(event) {
        event.preventDefault();

        const csvFileInput = document.getElementById('csv-file');
        const file = csvFileInput.files[0];

        if (!file) {
            this.addMessage('請選擇CSV檔案', 'warning');
            return;
        }

        try {
            const uploadBtn = document.getElementById('upload-csv-btn');
            uploadBtn.disabled = true;
            uploadBtn.textContent = '上傳中...';

            const products = await this.parseCSVFile(file);

            if (products.length === 0) {
                this.addMessage('沒有可上傳的商品數據', 'warning');
                return;
            }

            const result = await this.uploadBatchProducts(products);

            if (result.success) {
                this.addMessage(`成功新增 ${result.createdCount} 個商品`, 'success');
                this.hideBatchProductModal();
                await this.loadProductsTabData(); // 重新載入商品列表
            } else {
                this.addMessage(`批量上傳失敗: ${result.message}`, 'error');
            }
        } catch (error) {
            this.addMessage(`批量上傳失敗: ${error.message}`, 'error');
        } finally {
            const uploadBtn = document.getElementById('upload-csv-btn');
            if (uploadBtn) {
                uploadBtn.disabled = false;
                uploadBtn.textContent = (this.translate && this.translate('uploadCSVBtn')) || '上傳CSV';
            }
        }
    }

    async uploadBatchProducts(products) {
        console.log('uploadBatchProducts called with products:', products);
        const response = await this.fetchWithAuth('/api/products/batch', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ products })
        });

        console.log('uploadBatchProducts response:', response.status, response.statusText);

        if (!response.ok) {
            console.log('Response not OK, trying to parse error...');
            const errorText = await response.text();
            console.log('Error response text:', errorText);
            let errorData;
            try {
                errorData = JSON.parse(errorText);
                console.log('Parsed error data:', errorData);
            } catch (e) {
                console.log('Failed to parse error as JSON:', e);
                throw new Error(`上傳失敗: ${response.status} ${response.statusText}`);
            }
            throw new Error(errorData.message || errorData.error || '上傳失敗');
        }

        return await response.json();
    }

    switchProductCategory(category) {
        console.log('switchProductCategory called with category:', category);
        // 更新活躍標籤樣式
        document.querySelectorAll('.category-tab-button').forEach(button => {
            if (button.dataset.category === category) {
                button.classList.add('active');
            } else {
                button.classList.remove('active');
            }
        });

        // 設置分類篩選器值
        const categoryFilter = document.getElementById('product-category-filter');
        if (categoryFilter) {
            console.log('Setting category filter value to:', category);
            categoryFilter.value = category;
            // 立即檢查設置後的值
            console.log('Category filter value after setting:', categoryFilter.value);
            // 檢查是否有其他同ID元素
            const allCategoryFilters = document.querySelectorAll('#product-category-filter');
            console.log('Total category filter elements found:', allCategoryFilters.length);
            if (allCategoryFilters.length > 1) {
                console.warn('Multiple category filter elements found!');
                allCategoryFilters.forEach((filter, idx) => {
                    console.log(`Filter ${idx} value:`, filter.value);
                });
            }
        } else {
            console.warn('categoryFilter element not found!');
            // 調試：列出所有元素
            console.log('All elements with ID containing "category":');
            document.querySelectorAll('[id*="category"]').forEach(el => {
                console.log(el.id, el.tagName, el.className);
            });
        }

        // 應用篩選
        this.applyProductFilters();
    }

    applyProductFilters() {
        console.log('applyProductFilters called');
        // 獲取篩選器值 - 添加詳細調試
        const categoryFilterEl = document.getElementById('product-category-filter');
        console.log('Category filter element:', categoryFilterEl ? 'found' : 'not found');
        if (categoryFilterEl) {
            console.log('Category filter value read:', categoryFilterEl.value);
            console.log('Category filter options:', Array.from(categoryFilterEl.options).map(opt => ({value: opt.value, text: opt.text})));
        }

        this.productFilters.search = document.getElementById('product-search').value.toLowerCase();
        this.productFilters.category = document.getElementById('product-category-filter').value;
        this.productFilters.stock = document.getElementById('product-stock-filter').value;
        console.log('Filter values:', {
            category: this.productFilters.category,
            search: this.productFilters.search,
            stock: this.productFilters.stock
        });

        // 調試：輸出所有唯一的分類值
        const uniqueCategories = [...new Set(this.productsList.map(p => p.category).filter(Boolean))];
        console.log('所有商品分類值:', uniqueCategories);

        // 調試：輸出所有商品的 is_available 狀態
        console.log('所有商品 is_available 狀態:');
        this.productsList.forEach((p, i) => {
            console.log(`  [${i}] ${p.name} - 分類: "${p.category}", is_available: ${p.is_available} (type: ${typeof p.is_available})`);
        });

        // 篩選商品
        this.filteredProducts = this.productsList.filter(product => {
            // 調試：檢查藍莓芝士蛋糕
            if (product.name.includes('藍莓芝士蛋糕')) {
                console.log('Debug: 藍莓芝士蛋糕 -', {
                    name: product.name,
                    category: product.category,
                    filterCategory: this.productFilters.category,
                    passesCategoryFilter: !this.productFilters.category || product.category === this.productFilters.category,
                    id: product.id,
                    is_available: product.is_available
                });
            }

            // 調試：檢查切餅費
            if (product.name.includes('切餅費') || product.id === '4994527902067') {
                console.log('Debug: 切餅費 -', {
                    name: product.name,
                    category: product.category,
                    filterCategory: this.productFilters.category,
                    passesCategoryFilter: !this.productFilters.category || product.category === this.productFilters.category,
                    id: product.id,
                    is_available: product.is_available,
                    price: product.price,
                    stock: product.stock
                });
            }

            // 搜尋篩選
            if (this.productFilters.search && !product.name.toLowerCase().includes(this.productFilters.search)) {
                return false;
            }

            // 分類篩選 (跳過空值，即"全部類別")
            if (this.productFilters.category && product.category !== this.productFilters.category) {
                return false;
            }

            // 默認排除不可用商品 (is_available = 0)
            const isUnavailable = Number(product.is_available) === 0;
            if (isUnavailable) {
                console.log('Filtering out unavailable product:', product.name, product.id, 'is_available:', product.is_available, 'type:', typeof product.is_available);
                return false;
            }

            // 庫存狀態篩選
            switch (this.productFilters.stock) {
                case 'in-stock':
                    if (product.stock <= 0) return false;
                    break;
                case 'low-stock':
                    if (product.stock > 5 || product.stock <= 0) return false; // 假設低庫存為5以下
                    break;
                case 'out-of-stock':
                    if (product.stock > 0) return false;
                    break;
            }

            return true;
        });

        // 更新分頁
        this.productPagination.totalItems = this.filteredProducts.length;
        this.productPagination.totalPages = Math.ceil(this.filteredProducts.length / this.productPagination.itemsPerPage);
        this.productPagination.currentPage = 1;

        console.log('Filtering result:', {
            totalProducts: this.productsList.length,
            filteredProducts: this.filteredProducts.length,
            currentFilterCategory: this.productFilters.category
        });

        this.renderProductsTable();
        this.updateProductPaginationUI();

        // 同步分類標籤狀態
        this.syncCategoryTabs();
    }

    previousProductPage() {
        if (this.productPagination.currentPage > 1) {
            this.productPagination.currentPage--;
            this.renderProductsTable();
            this.updateProductPaginationUI();
        }
    }

    nextProductPage() {
        if (this.productPagination.currentPage < this.productPagination.totalPages) {
            this.productPagination.currentPage++;
            this.renderProductsTable();
            this.updateProductPaginationUI();
        }
    }

    renderProductsTable() {
        const tbody = document.getElementById('products-table-body');
        if (!tbody) return;

        // 直接使用所有過濾後的商品（不分頁）
        const displayProducts = this.filteredProducts;

        // 清空表格
        tbody.innerHTML = '';

        if (displayProducts.length === 0) {
            const emptyMsg = document.createElement('div');
            emptyMsg.className = 'empty-table-message';
            emptyMsg.setAttribute('data-i18n', 'noProductsFound');
            emptyMsg.textContent = '找不到符合條件的商品';
            emptyMsg.style.gridColumn = '1 / -1'; // 跨所有列
            tbody.appendChild(emptyMsg);
            return;
        }

        // 添加商品卡片
        displayProducts.forEach(product => {
            const card = document.createElement('div');
            card.className = 'product-card';

            // 庫存狀態類別
            let stockClass = '';
            if (product.stock <= 0) stockClass = 'out-of-stock';
            else if (product.stock <= (product.min_stock || 5)) stockClass = 'low-stock';
            if (stockClass) card.classList.add(stockClass);

            // 時間可用性類別
            const isTimeAvailable = product.is_time_available !== false; // 默認為 true
            if (!isTimeAvailable) {
                card.classList.add('time-unavailable');
            }

            // 根據時間可用性設置商品名稱的類別和標題
            const nameTitle = isTimeAvailable ? '點擊添加到購物車' : '當前時間不可用';
            const nameClass = isTimeAvailable ? 'product-card-name' : 'product-card-name time-unavailable-name';

            // 如果是選擇模式且此商品被選中，添加選中類別
            const isSelected = this.productSelectionMode && product.id === this.selectedProductId;
            if (isSelected) {
                card.classList.add('selected');
            }

            // 在選擇模式下添加特殊提示
            const selectionTitle = this.productSelectionMode ? '點擊選擇此商品進行操作' : nameTitle;

            card.innerHTML = `
                <div class="${nameClass} ${this.productSelectionMode ? 'selectable' : ''}" data-product-id="${product.id}" title="${selectionTitle}">${this.escapeHtml(product.name)}</div>
                <div class="product-card-price">$${product.price.toFixed(2)}</div>
            `;

            // 為整個卡片添加 product-id 屬性，支持點擊任何位置加入購物車
            card.dataset.productId = product.id;

            tbody.appendChild(card);
        });

        // 註解：以下代碼已不再需要，因為操作下拉菜單已被移除
        // 綁定編輯和刪除按鈕事件
        // tbody.querySelectorAll('.btn-edit').forEach(button => {
        //     button.addEventListener('click', (e) => {
        //         const productId = e.currentTarget.dataset.productId;
        //         const product = this.productsList.find(p => p.id == productId);
        //         if (product) this.showProductModal(product);
        //     });
        // });
        //
        // tbody.querySelectorAll('.btn-danger').forEach(button => {
        //     button.addEventListener('click', (e) => {
        //         e.stopPropagation(); // 防止事件冒泡到父元素
        //         console.log('Delete button clicked, button:', e.currentTarget, 'dataset:', e.currentTarget.dataset);
        //         const productId = e.currentTarget.dataset.productId;
        //         console.log('productId from dataset:', productId);
        //
        //         // 關閉下拉菜單
        //         const dropdown = e.currentTarget.closest('.action-dropdown');
        //         if (dropdown) {
        //             const menu = dropdown.querySelector('.action-dropdown-menu');
        //             if (menu) menu.classList.remove('show');
        //         }
        //
        //         this.deleteProduct(productId);
        //     });
        // });
        //
        // // 綁定補貨按鈕事件
        // tbody.querySelectorAll('.btn-restock').forEach(button => {
        //     button.addEventListener('click', (e) => {
        //         const productId = e.currentTarget.dataset.productId;
        //         const product = this.productsList.find(p => p.id == productId);
        //         if (product) this.showRestockModal(product);
        //     });
        // });
        //
        // // 綁定調整按鈕事件
        // tbody.querySelectorAll('.btn-adjust').forEach(button => {
        //     button.addEventListener('click', (e) => {
        //         const productId = e.currentTarget.dataset.productId;
        //         const product = this.productsList.find(p => p.id == productId);
        //         if (product) this.showAdjustModal(product);
        //     });
        // });
        //
        // // 綁定操作下拉菜單事件
        // tbody.querySelectorAll('.btn-action-dropdown').forEach(button => {
        //     button.addEventListener('click', (e) => {
        //         e.stopPropagation(); // 防止事件冒泡
        //         const dropdown = e.currentTarget.closest('.action-dropdown');
        //         const menu = dropdown.querySelector('.action-dropdown-menu');
        //
        //         // 切換菜單顯示
        //         const isVisible = menu.classList.contains('show');
        //
        //         // 關閉所有其他下拉菜單
        //         document.querySelectorAll('.action-dropdown-menu').forEach(m => {
        //             m.classList.remove('show');
        //         });
        //
        //         // 切換當前菜單
        //         if (isVisible) {
        //             menu.classList.remove('show');
        //         } else {
        //             menu.classList.add('show');
        //         }
        //     });
        // });
        //
        // // 點擊頁面其他地方關閉下拉菜單
        // document.addEventListener('click', () => {
        //     document.querySelectorAll('.action-dropdown-menu').forEach(menu => {
        //         menu.classList.remove('show');
        //     });
        // });
        //
        // // 防止下拉菜單內部點擊關閉菜單
        // tbody.querySelectorAll('.action-dropdown-menu').forEach(menu => {
        //     menu.addEventListener('click', (e) => {
        //         e.stopPropagation();
        //     });
        // });

        // 綁定商品卡片點擊事件（點擊整個卡片，包括商品名稱和價格）
        tbody.querySelectorAll('.product-card').forEach(card => {
            card.addEventListener('click', (e) => {
                try {
                    console.log('Product card clicked');
                    const productId = e.currentTarget.dataset.productId;
                    console.log('productId from dataset:', productId, 'type:', typeof productId);

                    if (!productId) {
                        console.error('No productId found in dataset');
                        this.addMessage('無法識別商品ID', 'error');
                        return;
                    }

                    // 檢查商品是否時間不可用
                    if (e.currentTarget.classList.contains('time-unavailable')) {
                        this.addMessage('當前時間不可用此商品', 'warning');
                        return;
                    }

                    // 如果是選擇模式，選擇商品並顯示操作菜單
                    if (this.productSelectionMode) {
                        this.selectProductForOperation(productId);
                    } else {
                        // 否則正常添加到購物車
                        this.addToCart(productId);
                    }
                } catch (error) {
                    console.error('Error in product card click handler:', error);
                    this.addMessage(`點擊商品時發生錯誤: ${error.message}`, 'error');
                }
            });
        });

        // 更新翻譯
        this.updateTranslations();
    }

    updateProductPaginationUI() {
        // 只顯示總商品數，不分頁
        const totalCountEl = document.getElementById('total-products-count');
        if (totalCountEl) totalCountEl.textContent = this.filteredProducts.length;

        // 隱藏分頁控件（上一頁/下一頁按鈕和頁碼）
        const currentPageEl = document.getElementById('current-page');
        const totalPagesEl = document.getElementById('total-pages');
        const prevBtn = document.getElementById('prev-page-btn');
        const nextBtn = document.getElementById('next-page-btn');

        if (currentPageEl) currentPageEl.textContent = '1';
        if (totalPagesEl) totalPagesEl.textContent = '1';
        if (prevBtn) prevBtn.style.display = 'none';
        if (nextBtn) nextBtn.style.display = 'none';
    }

    async deleteProduct(productId) {
        console.log('deleteProduct called with productId:', productId, 'typeof:', typeof productId);
        if (!confirm('確定要刪除這個商品嗎？此操作無法復原。')) {
            console.log('User cancelled delete');
            return;
        }

        try {
            const response = await this.fetchWithAuth(`/api/products/${productId}`, {
                method: 'DELETE'
            });

            console.log('Delete API response status:', response.status, response.statusText);
            const result = await response.json();
            console.log('Delete API result:', result);

            if (result.success) {
                // 使用伺服器返回的訊息
                const messageType = result.disabled ? 'info' : 'success';
                this.addMessage(result.message, messageType);
                await this.loadProductsTabData(); // 重新載入商品列表
            } else {
                this.addMessage(`刪除失敗: ${result.message}`, 'error');
            }
        } catch (error) {
            this.addMessage(`刪除失敗: ${error.message}`, 'error');
        }
    }

    // 輔助方法：防止XSS
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    async loadReportsTab() {
        // 統計報告標籤內容
        if (!this.isAuthenticated) {
            this.addMessage('請先登入以查看統計報告', 'warning');
            return;
        }

        // 檢查是否為總部分店
        const isHeadquarters = this.selectedStoreId ? this.isHeadquartersStore(this.selectedStoreId) : false;
        console.log(`loadReportsTab: selectedStoreId=${this.selectedStoreId}, isHeadquarters=${isHeadquarters}, accessibleStores:`, this.accessibleStores);

        // 更新歷史銷售卡片可見性
        this.updateHistoricalSalesCardVisibility(isHeadquarters);

        // 更新今日統計卡片標題（總部改為"今日各店統計"）
        this.updateTodayStatsCardTitle(isHeadquarters);

        // 更新今日結賬詳細記錄卡片可見性（總部隱藏）
        this.updateTodayCheckoutRecordsCardVisibility(isHeadquarters);

        // 更新今日統計卡片可見性（總部隱藏）
        this.updateTodayStatsCardVisibility(isHeadquarters);

        // 初始化日期篩選器（默認最近7天）
        const endDate = new Date();
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - 7);

        const formatDate = (date) => date.toISOString().split('T')[0];
        const startDateInput = document.getElementById('historical-start-date');
        const endDateInput = document.getElementById('historical-end-date');

        if (startDateInput && !startDateInput.value) {
            startDateInput.value = formatDate(startDate);
        }
        if (endDateInput && !endDateInput.value) {
            endDateInput.value = formatDate(endDate);
        }

        // 載入分店列表用於篩選器
        try {
            await this.loadStoresForHistoricalFilter();
        } catch (error) {
            console.error('載入分店列表失敗，但不影響歷史銷售功能:', error);
        }

        // 只有總部分店載入歷史銷售數據
        if (isHeadquarters) {
            // 載入歷史銷售數據（使用篩選器）
            await this.loadHistoricalSales(1, {
                start_date: startDateInput?.value || formatDate(startDate),
                end_date: endDateInput?.value || formatDate(endDate)
            });
        } else {
            console.log('非總部分店，跳過歷史銷售數據加載');
            // 清空歷史銷售列表顯示
            const historicalSalesList = document.getElementById('historical-sales-list');
            if (historicalSalesList) {
                historicalSalesList.innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-history"></i>
                        <p data-i18n="historicalSalesNotAvailable">歷史銷售數據僅總部可用</p>
                    </div>
                `;
            }
        }

        // 每次進入報表標籤重新鎖定今日統計
        this.statsUnlocked = false;
        this.resetStatsLockOverlay();

        // 載入今日統計
        await this.loadTodayStats();

        // 載入今日結賬詳細記錄（僅非總部分店）
        if (!isHeadquarters) {
            await this.loadTodayCheckoutRecords();
        }

        // 設置事件監聽器
        this.setupReportsTabEvents();
    }

    async loadTodayCheckoutRecords() {
        console.log('loadTodayCheckoutRecords called');
        try {
            if (!this.isAuthenticated) {
                console.log('loadTodayCheckoutRecords: 未登入，跳過');
                return;
            }

            console.log('loadTodayCheckoutRecords: 發送API請求');
            const response = await this.fetchWithAuth('/api/cashier/checkout-records/today');
            console.log('loadTodayCheckoutRecords: API回應狀態', response.status);

            if (!response.ok) throw new Error(`HTTP ${response.status}`);

            const result = await response.json();
            console.log('loadTodayCheckoutRecords: API結果', result);

            if (result.success) {
                console.log(`loadTodayCheckoutRecords: 成功載入 ${result.count} 筆記錄`);
                this.renderTodayCheckoutRecords(result.records);
                document.getElementById('today-checkout-records-count').textContent = `共 ${result.count} 筆記錄`;
            } else {
                console.error('載入今日結賬記錄失敗:', result.message);
                this.renderTodayCheckoutRecords([]);
            }
        } catch (error) {
            console.error('載入今日結賬記錄失敗:', error);
            this.renderTodayCheckoutRecords([]);
        }
    }

    async loadSensitiveOperations(page = 1) {
        console.log('loadSensitiveOperations called with page:', page);
        try {
            if (!this.isAuthenticated) {
                console.log('loadSensitiveOperations: 未登入，跳過');
                return;
            }

            console.log('loadSensitiveOperations: 發送API請求到 /api/audit-logs/sensitive-operations');
            console.log('loadSensitiveOperations: selectedStoreId=', this.selectedStoreId);

            // 檢查是否為總部分店（總部應顯示所有分店的敏感操作）
            const isHeadquarters = this.selectedStoreId ? this.isHeadquartersStore(this.selectedStoreId) : false;

            // 構建查詢參數
            const queryParams = new URLSearchParams({
                page: page.toString(),
                limit: '20', // 每頁20條記錄
                ...(this.selectedStoreId && !isHeadquarters ? { store_id: this.selectedStoreId } : {})
            }).toString();

            const url = `/api/audit-logs/sensitive-operations?${queryParams}`;
            const response = await this.fetchWithAuth(url, { skipStoreId: true });
            console.log('loadSensitiveOperations: API回應狀態', response.status);

            if (!response.ok) throw new Error(`HTTP ${response.status}`);

            const result = await response.json();
            console.log('loadSensitiveOperations: API結果', result);

            if (result.success) {
                const { operations, total, pagination } = result.data;
                console.log(`loadSensitiveOperations: 成功載入 ${operations.length} 筆敏感操作記錄 (總數: ${total}, 第 ${pagination.current_page}/${pagination.total_pages} 頁)`);
                this.renderSensitiveOperations(operations);
                document.getElementById('sensitive-operations-count').textContent = `共 ${total} 筆記錄`;

                // 更新分頁狀態和UI
                this.updateSensitiveOperationsPagination(pagination);
            } else {
                console.error('載入敏感操作失敗:', result.message);
                this.renderSensitiveOperations([]);
            }
        } catch (error) {
            console.error('載入敏感操作失敗:', error);
            this.renderSensitiveOperations([]);
        }
    }

    renderSensitiveOperations(operations) {
        console.log('renderSensitiveOperations called with operations:', operations, 'length:', operations?.length);
        const tableBody = document.querySelector('#sensitive-operations-table tbody');
        if (!tableBody) {
            console.warn('找不到 #sensitive-operations-table tbody 元素');
            return;
        }

        if (!operations || operations.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="4" class="empty-message">暫無敏感操作記錄</td>
                </tr>
            `;
            return;
        }

        const rows = operations.map(operation => {
            const time = this.formatDateTime(operation.created_at);
            const action = this.escapeHtml(operation.action_display);
            // 優先顯示員工帳號，如果沒有帳號則顯示員工姓名，都沒有則顯示「系統」
            let operator = '系統';
            if (operation.employee_username) {
                operator = this.escapeHtml(operation.employee_username);
            } else if (operation.employee_name) {
                operator = this.escapeHtml(operation.employee_name);
            }

            // 準備按鈕的data屬性
            const btnData = {
                operationId: operation.id,
                actionType: operation.action_type,
                actionDisplay: operation.action_display,
                createdAt: operation.created_at,
                employeeName: operation.employee_name || '',
                employeeUsername: operation.employee_username || '',
                ipAddress: operation.ip_address || '',
                details: operation.details || {}
            };
            const btnDataAttr = JSON.stringify(btnData).replace(/'/g, "&#39;");

            return `
                <tr data-operation-id="${operation.id}">
                    <td>${time}</td>
                    <td>${action}</td>
                    <td>${operator}</td>
                    <td class="action-cell">
                        <button class="btn-small btn-details" data-operation-data='${btnDataAttr}'>
                            詳細
                        </button>
                    </td>
                </tr>
            `;
        });

        tableBody.innerHTML = rows.join('');
    }

    updateSensitiveOperationsPagination(pagination) {
        console.log('updateSensitiveOperationsPagination called with:', pagination);

        // 創建或更新分頁容器
        let paginationContainer = document.getElementById('sensitive-operations-pagination');
        if (!paginationContainer) {
            paginationContainer = document.createElement('div');
            paginationContainer.id = 'sensitive-operations-pagination';
            paginationContainer.className = 'pagination-container';

            // 插入到統計信息後面
            const tableFooter = document.querySelector('.sensitive-operations-container .table-footer');
            if (tableFooter) {
                tableFooter.appendChild(paginationContainer);
            } else {
                console.warn('找不到 .sensitive-operations-container .table-footer 元素');
                return;
            }
        }

        const { current_page, total_pages, has_next, has_prev } = pagination;

        // 如果只有一頁或沒有記錄，隱藏分頁容器
        if (total_pages <= 1) {
            paginationContainer.style.display = 'none';
            return;
        } else {
            paginationContainer.style.display = 'block';
        }

        // 生成分頁HTML
        let paginationHtml = `
            <div class="pagination-info">
                第 <strong>${current_page}</strong> / <strong>${total_pages}</strong> 頁
            </div>
            <div class="pagination-controls">
        `;

        // 上一頁按鈕
        paginationHtml += `
            <button class="btn-small ${!has_prev ? 'disabled' : ''}"
                    ${!has_prev ? 'disabled' : ''}
                    data-page="${current_page - 1}">
                <i class="fas fa-chevron-left"></i> 上一頁
            </button>
        `;

        // 頁碼按鈕（只顯示有限頁碼）
        const maxVisiblePages = 5;
        let startPage = Math.max(1, current_page - Math.floor(maxVisiblePages / 2));
        let endPage = Math.min(total_pages, startPage + maxVisiblePages - 1);

        if (endPage - startPage + 1 < maxVisiblePages) {
            startPage = Math.max(1, endPage - maxVisiblePages + 1);
        }

        for (let page = startPage; page <= endPage; page++) {
            paginationHtml += `
                <button class="btn-small ${page === current_page ? 'btn-primary' : ''}"
                        data-page="${page}">
                    ${page}
                </button>
            `;
        }

        // 下一頁按鈕
        paginationHtml += `
            <button class="btn-small ${!has_next ? 'disabled' : ''}"
                    ${!has_next ? 'disabled' : ''}
                    data-page="${current_page + 1}">
                下一頁 <i class="fas fa-chevron-right"></i>
            </button>
        `;

        paginationHtml += `</div>`;
        paginationContainer.innerHTML = paginationHtml;

        // 綁定分頁按鈕事件
        paginationContainer.querySelectorAll('.btn-small:not(.disabled)').forEach(btn => {
            btn.addEventListener('click', () => {
                const page = parseInt(btn.dataset.page);
                if (!isNaN(page) && page >= 1 && page <= total_pages) {
                    this.loadSensitiveOperations(page);
                }
            });
        });
    }

    showSensitiveOperationDetail(operation) {
        console.log('showSensitiveOperationDetail called with operation:', operation);

        // 設置模態框標題
        const isPartialReverse = operation.action_type === 'sensitive_reverse_checkout' && operation.details?.partial_reverse;
        const actionDisplay = operation.action_type === 'sensitive_delete_table' ? '刪桌' :
                             operation.action_type === 'sensitive_delete_product' ? '刪品' :
                             operation.action_type === 'sensitive_reverse_checkout' ? (isPartialReverse ? '反結賬 (部份)' : '反結賬') :
                             operation.action_type === 'sensitive_price_change' ? '改價' :
                             operation.action_type;
        document.getElementById('sensitive-operation-modal-title').textContent = `${actionDisplay} - 操作詳情`;

        // 設置基本資訊
        const basicInfoHtml = `
            <div class="info-row">
                <span class="label">操作時間:</span>
                <span>${this.formatDateTime(operation.created_at)}</span>
            </div>
            <div class="info-row">
                <span class="label">操作類型:</span>
                <span>${actionDisplay}</span>
            </div>
            <div class="info-row">
                <span class="label">操作員:</span>
                <span>${operation.employee_username ? this.escapeHtml(operation.employee_username) : operation.employee_name ? this.escapeHtml(operation.employee_name) : '未知'}</span>
            </div>
            <div class="info-row">
                <span class="label">IP地址:</span>
                <span>${this.escapeHtml(operation.ip_address || '未知')}</span>
            </div>
            ${operation.action_type === 'sensitive_delete_table' ? `
            <div class="info-row">
                <span class="label">被刪桌號:</span>
                <span>${this.escapeHtml(operation.details.table_number || '未知')}</span>
            </div>
            <div class="info-row">
                <span class="label">刪除員工:</span>
                <span>${this.escapeHtml(operation.details.employee_name || '未知')}</span>
            </div>
            ` : ''}
            ${operation.action_type === 'sensitive_delete_product' || operation.action_type === 'sensitive_price_change' ? `
            <div class="info-row">
                <span class="label">桌號:</span>
                <span>${this.escapeHtml(operation.details.table_number || '未知')}</span>
            </div>
            <div class="info-row">
                <span class="label">${operation.action_type === 'sensitive_price_change' ? '改價商品' : '被刪商品'}:</span>
                <span>${this.escapeHtml(operation.details.product_name || '未知')} (${this.escapeHtml(operation.details.product_id || '未知')})</span>
            </div>
            ` : ''}
            ${operation.action_type === 'sensitive_reverse_checkout' ? `
            <div class="info-row">
                <span class="label">桌號:</span>
                <span>${this.escapeHtml(operation.details.table_number || '未知')}</span>
            </div>
            ${isPartialReverse ? `
            <div class="info-row">
                <span class="label">反結賬商品:</span>
                <span>${this.escapeHtml(operation.details.product_name || '未知')} (×${operation.details.reversed_quantity || '?'})</span>
            </div>
            <div class="info-row">
                <span class="label">反結賬金額:</span>
                <span>$${parseFloat(operation.details.reversed_amount || 0).toFixed(2)}</span>
            </div>
            <div class="info-row">
                <span class="label">更新後總金額:</span>
                <span>$${parseFloat(operation.details.new_total_amount || 0).toFixed(2)}</span>
            </div>
            ` : `
            <div class="info-row">
                <span class="label">原金額:</span>
                <span>$${parseFloat(operation.details.original_total_amount || 0).toFixed(2)}</span>
            </div>
            <div class="info-row">
                <span class="label">原人數:</span>
                <span>${operation.details.original_people_count || '0'}</span>
            </div>
            `}
            <div class="info-row">
                <span class="label">反結賬員工:</span>
                <span>${this.escapeHtml(operation.details.reverse_employee_name || '未知')}</span>
            </div>
            ` : ''}
        `;
        document.getElementById('sensitive-operation-basic-info').innerHTML = basicInfoHtml;

        // 顯示/隱藏相應的詳細資訊部分
        const deleteTableDetails = document.getElementById('delete-table-details');
        const deleteProductDetails = document.getElementById('delete-product-details');

        if (operation.action_type === 'sensitive_delete_table') {
            // 顯示刪桌詳情
            deleteTableDetails.classList.remove('hidden');
            deleteProductDetails.classList.add('hidden');

            // 填充被刪桌號詳情（模擬客人詳情）
            // 注意：這裡需要更多數據來顯示完整的客人詳情
            // 目前先顯示基本資訊
            let customerDetailHtml = `
                <div class="customer-basic-info">
                    <div class="info-item">
                        <span class="label">桌號:</span>
                        <span>${this.escapeHtml(operation.details.table_number || '未知')}</span>
                    </div>
                    <div class="info-item">
                        <span class="label">客人數:</span>
                        <span>${this.escapeHtml(operation.details.people_count || '未知')}</span>
                    </div>
                    <div class="info-item">
                        <span class="label">入場時間:</span>
                        <span>${operation.details.entry_time ? this.escapeHtml(this.formatDateTime(operation.details.entry_time)) : this.escapeHtml('未知')}</span>
                    </div>
                    <div class="info-item">
                        <span class="label">儲物柜:</span>
                        <span>${this.escapeHtml(operation.details.lockers_used || '無')}</span>
                    </div>
                    <div class="info-item">
                        <span class="label">總消費:</span>
                        <span>$${this.escapeHtml(operation.details.total_amount || '0')}</span>
                    </div>
                    <div class="info-item">
                        <span class="label">會員:</span>
                        <span>${this.escapeHtml(operation.details.is_member ? '是' : '否')}</span>
                    </div>
                </div>
            `;

            // 如果有訂單項目，顯示訂單
            if (operation.details.order_items && operation.details.order_items.length > 0) {
                let orderItemsTotal = 0;
                customerDetailHtml += `
                    <div class="customer-order-info">
                        <h5>訂單項目 (共 ${operation.details.order_items.length} 項):</h5>
                        <table class="order-items-table">
                            <thead>
                                <tr>
                                    <th>商品名稱</th>
                                    <th>單價</th>
                                    <th>數量</th>
                                    <th>小計</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${operation.details.order_items.map(item => {
                                    const unitPrice = item.price_at_time || item.price || 0;
                                    const quantity = item.quantity || 1;
                                    const subtotal = unitPrice * quantity;
                                    orderItemsTotal += subtotal;
                                    return `
                                        <tr>
                                            <td>${item.product_name || '未知商品'}</td>
                                            <td>$${unitPrice.toFixed(2)}</td>
                                            <td>${quantity}</td>
                                            <td>$${subtotal.toFixed(2)}</td>
                                        </tr>
                                    `;
                                }).join('')}
                                <tr class="order-total-row">
                                    <td colspan="3" class="text-right"><strong>訂單總計:</strong></td>
                                    <td><strong>$${orderItemsTotal.toFixed(2)}</strong></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                `;
            }

            document.getElementById('deleted-customer-detail').innerHTML = customerDetailHtml;

        } else if (operation.action_type === 'sensitive_delete_product') {
            // 顯示刪品詳情
            deleteTableDetails.classList.add('hidden');
            deleteProductDetails.classList.remove('hidden');

            // 確保 section 標題為 "被刪商品詳情"（避免之前顯示「改價詳情」殘留）
            const deleteProductHeader = deleteProductDetails.querySelector('h4');
            if (deleteProductHeader) {
                deleteProductHeader.innerHTML = '<i class="fas fa-box"></i> 被刪商品詳情';
            }

            // 填充被刪商品詳情
            let productDetailHtml = `
                <div class="product-basic-info">
                    <div class="info-item">
                        <span class="label">桌號:</span>
                        <span>${operation.details.table_number || '未知'}</span>
                    </div>
                    <div class="info-item">
                        <span class="label">被刪商品ID:</span>
                        <span>${operation.details.product_id || '未知'}</span>
                    </div>
                    <div class="info-item">
                        <span class="label">商品名稱:</span>
                        <span>${operation.details.product_name || '未知'}</span>
                    </div>
                    <div class="info-item">
                        <span class="label">前數量:</span>
                        <span>${operation.details.old_quantity ?? operation.details.quantity ?? '1'}</span>
                    </div>
                    <div class="info-item">
                        <span class="label">後數量:</span>
                        <span>${operation.details.new_quantity ?? '0'}</span>
                    </div>
                    <div class="info-item">
                        <span class="label">價格:</span>
                        <span>$${parseFloat(operation.details.price_at_time || 0).toFixed(2)}</span>
                    </div>
                    <div class="info-item">
                        <span class="label">刪除時間:</span>
                        <span>${operation.details.deleted_at ? this.formatDateTime(operation.details.deleted_at) : this.formatDateTime(operation.created_at)}</span>
                    </div>
                </div>
            `;

            document.getElementById('deleted-product-detail').innerHTML = productDetailHtml;
        } else if (operation.action_type === 'sensitive_price_change') {
            // 顯示改價詳情
            deleteTableDetails.classList.add('hidden');
            deleteProductDetails.classList.remove('hidden');

            // 將 section 標題從 "被刪商品詳情" 改為 "改價詳情"
            const productDetailsHeader = deleteProductDetails.querySelector('h4');
            if (productDetailsHeader) {
                productDetailsHeader.innerHTML = '<i class="fas fa-tag"></i> 改價詳情';
            }

            // 填充改價商品詳情
            let productDetailHtml = `
                <div class="product-basic-info">
                    <div class="info-item">
                        <span class="label">桌號:</span>
                        <span>${operation.details.table_number || '未知'}</span>
                    </div>
                    <div class="info-item">
                        <span class="label">商品ID:</span>
                        <span>${operation.details.product_id || '未知'}</span>
                    </div>
                    <div class="info-item">
                        <span class="label">商品名稱:</span>
                        <span>${operation.details.product_name || '未知'}</span>
                    </div>
                    <div class="info-item">
                        <span class="label">前價格:</span>
                        <span>$${parseFloat(operation.details.old_effective_price ?? operation.details.price_at_time ?? 0).toFixed(2)}</span>
                    </div>
                    <div class="info-item">
                        <span class="label">後價格:</span>
                        <span>$${parseFloat(operation.details.new_effective_price ?? 0).toFixed(2)}</span>
                    </div>
                    <div class="info-item">
                        <span class="label">立減:</span>
                        <span>$${parseFloat(operation.details.new_flat_discount ?? 0).toFixed(2)}</span>
                    </div>
                    <div class="info-item">
                        <span class="label">折扣:</span>
                        <span>${operation.details.new_percent_discount ?? '0'}%</span>
                    </div>
                    <div class="info-item">
                        <span class="label">價差:</span>
                        <span style="color: ${(operation.details.amount_diff || 0) > 0 ? '#e74c3c' : '#27ae60'}; font-weight: bold;">
                            -$${Math.abs(parseFloat(operation.details.amount_diff || 0)).toFixed(2)}
                        </span>
                    </div>
                    <div class="info-item">
                        <span class="label">操作時間:</span>
                        <span>${this.formatDateTime(operation.created_at)}</span>
                    </div>
                </div>
            `;

            document.getElementById('deleted-product-detail').innerHTML = productDetailHtml;
        } else {
            // 其他操作類型，隱藏兩個詳細部分
            deleteTableDetails.classList.add('hidden');
            deleteProductDetails.classList.add('hidden');

            // 恢復 section 標題為默認值
            const productDetailsHeader = deleteProductDetails.querySelector('h4');
            if (productDetailsHeader) {
                productDetailsHeader.innerHTML = '<i class="fas fa-box"></i> 被刪商品詳情';
            }
        }

        // 顯示模態框
        this.showSensitiveOperationModal();
    }

    showSensitiveOperationModal() {
        console.log('showSensitiveOperationModal called');
        const modal = document.getElementById('sensitive-operation-modal');
        if (modal) {
            modal.classList.remove('hidden');
            // 設置z-index確保顯示在最上層
            modal.style.zIndex = '1002';
        }
    }

    hideSensitiveOperationModal() {
        console.log('hideSensitiveOperationModal called');
        const modal = document.getElementById('sensitive-operation-modal');
        if (modal) {
            modal.classList.add('hidden');
        }
    }

    renderTodayCheckoutRecords(records) {
        console.log('renderTodayCheckoutRecords called with records:', records, 'length:', records?.length);
        const tableBody = document.querySelector('#today-checkout-records-table tbody');
        if (!tableBody) {
            console.warn('找不到 #today-checkout-records-table tbody 元素');
            return;
        }

        if (!records || records.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="6" class="empty-message">今日暫無結賬記錄</td>
                </tr>
            `;
            return;
        }

        const rows = records.map(record => {
            const entryTime = this.formatDateTime(record.entry_time);
            const checkoutTime = this.formatDateTime(record.checkout_time);
            const totalAmount = record.total_amount ? `$${record.total_amount.toFixed(2)}` : '$0.00';
            const isMember = record.is_member ? '是' : '否';
            const isReversed = record.is_reversed ? true : false;

            const tableNumber = this.escapeHtml(record.table_number);
            const memberStatus = isMember;
            const qrCode = this.escapeHtml(record.qr_code || record.id);
            const products = this.escapeHtml(record.products || '無');
            const lockers = this.escapeHtml(record.lockers || '無');
            const reversedProducts = this.escapeHtml(record.reversed_products || '');

            return `
                <tr data-record-id="${record.id}">
                    <td>${tableNumber}</td>
                    <td>${record.people_count}</td>
                    <td>${entryTime}</td>
                    <td>${checkoutTime}</td>
                    <td>${totalAmount}</td>
                    <td class="action-cell">
                        <button class="btn-small btn-details"
                                data-table-number="${tableNumber}"
                                data-member="${memberStatus}"
                                data-qr-code="${qrCode}"
                                data-products="${products}"
                                data-reversed-products="${reversedProducts}"
                                data-lockers="${lockers}"
                                data-record-id="${record.id}"
                                data-total-amount="${record.total_amount}"
                                data-checkout-time="${record.checkout_time}"
                                data-people-count="${record.people_count}"
                                data-entry-time="${record.entry_time}"
                                data-is-reversed="${isReversed ? '1' : '0'}"
                                data-reverse-employee="${this.escapeHtml(record.reverse_employee_name || '')}">
                            <i class="fas fa-info-circle"></i> 詳細
                        </button>
                    </td>
                </tr>
            `;
        }).join('');

        tableBody.innerHTML = rows;
    }

    showCheckoutDetail(details) {
        console.log('結賬詳細信息:', details);

        // 格式化商品列表（按逗號分割，每行一個商品）
        const isReversed = details.isReversed ? true : false;
        const reverseEmployee = details.reverseEmployee || '';

        // 解析已反結賬商品名稱集合（用於部份反結賬顯示紅線）
        const reversedProductNames = new Set();
        if (details.reversedProducts) {
            details.reversedProducts.split(',').forEach(item => {
                const trimmed = item.trim();
                if (trimmed) {
                    // 去掉 ×N 數量後綴得到純商品名
                    const name = trimmed.replace(/\s*×\d+.*$/, '').trim();
                    if (name) reversedProductNames.add(name);
                }
            });
        }

        let productsHtml = '';

        if (isReversed) {
            productsHtml = '<div class="reverse-checkout-banner">⚠️ 此單據已被反結賬</div>';
            if (reverseEmployee) {
                productsHtml += `<div class="reverse-checkout-banner-sub">反結賬員工: ${this.escapeHtml(reverseEmployee)}</div>`;
            }
        }

        if (details.products && details.products !== '無') {
            const productList = details.products.split(',').map(p => p.trim()).filter(p => p);
            productsHtml += productList.map(product => {
                // 解析商品名稱（去掉 ×N 數量後綴）
                const productName = product.replace(/\s*×\d+.*$/, '').trim();
                const escapedName = this.escapeHtml(productName);
                const escapedProduct = this.escapeHtml(product);
                // 判斷此商品是否已被（部份）反結賬
                const productReversed = isReversed || reversedProductNames.has(productName);
                return `<div class="product-item${productReversed ? ' reversed' : ''}${!productReversed ? ' clickable' : ''}"${!productReversed ? ` data-product-name="${escapedName}"` : ''}>${escapedProduct}</div>`;
            }).join('');
        } else {
            productsHtml += '<div class="product-item">無</div>';
        }

        // 格式化儲物柜列表（用逗號分隔，不用分行）
        let lockersHtml = '';
        if (details.lockers && details.lockers !== '無') {
            const lockerList = details.lockers.split(',').map(l => l.trim()).filter(l => l);
            lockersHtml = lockerList.map(locker => this.escapeHtml(locker)).join(', ');
        } else {
            lockersHtml = '無';
        }

        const dialogHtml = `
            <div class="modal" id="checkout-detail-modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3><i class="fas fa-info-circle"></i> 結賬詳細信息${isReversed ? ' (已反結賬)' : ''}</h3>
                        <button class="modal-close" id="checkout-detail-modal-close">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="checkout-detail-grid">
                            <div class="detail-row">
                                <span class="detail-label">桌號:</span>
                                <span class="detail-value">${this.escapeHtml(details.tableNumber)}</span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">會員:</span>
                                <span class="detail-value">${this.escapeHtml(details.member)}</span>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">QR Code:</span>
                                <span class="detail-value">${this.escapeHtml(details.qrCode)}</span>
                            </div>
                            <div class="detail-row detail-row-multiline">
                                <span class="detail-label">商品:</span>
                                <div class="detail-value-multiline">
                                    ${productsHtml}
                                </div>
                            </div>
                            <div class="detail-row">
                                <span class="detail-label">儲物柜:</span>
                                <span class="detail-value">${lockersHtml}</span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn-secondary" id="checkout-detail-modal-reprint-btn">
                            <i class="fas fa-print"></i> 重印小票
                        </button>
                        ${!isReversed ? '<button class="btn-danger" id="checkout-detail-modal-reverse-btn"><i class="fas fa-undo"></i> 反結賬</button>' : ''}
                        <button class="btn-primary" id="checkout-detail-modal-close-btn">關閉</button>
                    </div>
                </div>
            </div>
        `;

        // 移除現有的模態對話框（如果存在）
        const existingModal = document.getElementById('checkout-detail-modal');
        if (existingModal) {
            existingModal.remove();
        }

        // 添加對話框到文檔
        document.body.insertAdjacentHTML('beforeend', dialogHtml);

        // 綁定關閉事件
        const modal = document.getElementById('checkout-detail-modal');
        const closeBtn = document.getElementById('checkout-detail-modal-close');
        const closeBtn2 = document.getElementById('checkout-detail-modal-close-btn');

        const closeModal = () => {
            if (modal) {
                modal.remove();
            }
        };

        if (closeBtn) closeBtn.addEventListener('click', closeModal);
        if (closeBtn2) closeBtn2.addEventListener('click', closeModal);

        // 重印小票按鈕事件
        const reprintBtn = document.getElementById('checkout-detail-modal-reprint-btn');
        if (reprintBtn) {
            reprintBtn.addEventListener('click', () => {
                this.handleReprintReceipt(details);
            });
        }

        // 反結賬按鈕事件
        const reverseBtn = document.getElementById('checkout-detail-modal-reverse-btn');
        if (reverseBtn) {
            reverseBtn.addEventListener('click', () => {
                this.showReverseCheckoutModal(details.recordId, details.tableNumber, details.totalAmount, details.checkoutTime);
            });
        }

        // 商品點擊事件 — 部份反結賬（點擊商品名稱觸發單品反結賬）
        if (!isReversed && details.products && details.products !== '無') {
            const productsContainer = modal.querySelector('.detail-value-multiline');
            if (productsContainer) {
                productsContainer.addEventListener('click', (e) => {
                    const productItem = e.target.closest('.product-item.clickable');
                    if (!productItem) return;
                    const productName = productItem.dataset.productName;
                    if (!productName) return;
                    this.showPartialReverseConfirmModal(details.recordId, details.tableNumber, productName, details.totalAmount);
                });
            }
        }
    }

    async handleReprintReceipt(details) {
        console.log('重印小票請求:', details);
        try {
            if (!details.recordId) {
                this.addMessage('錯誤: 缺少記錄ID', 'error');
                return;
            }

            this.addMessage('正在重新打印小票...', 'info');

            const response = await this.fetchWithAuth('/api/receipt/reprint-checkout', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    record_id: details.recordId,
                    store_id: this.selectedStoreId || ''
                })
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || `HTTP ${response.status}`);
            }

            const result = await response.json();
            if (result.success) {
                this.addMessage('小票重印成功', 'success');
                console.log('重印結果:', result);
            } else {
                throw new Error(result.message || '重印失敗');
            }
        } catch (error) {
            console.error('重印小票錯誤:', error);
            this.addMessage('重印小票失敗: ' + error.message, 'error');
        }
    }

    // ==================== 反結賬功能 ====================

    showReverseCheckoutModal(receiptId, tableNumber, totalAmount, checkoutTime) {
        // 檢查 modal 是否已存在
        let modal = document.getElementById('reverse-checkout-modal');
        if (!modal) {
            // 創建模態框
            modal = document.createElement('div');
            modal.id = 'reverse-checkout-modal';
            modal.className = 'modal';
            modal.innerHTML = `
                <div class="modal-content" style="max-width: 450px;">
                    <div class="modal-header">
                        <h3><i class="fas fa-undo"></i> 反結賬確認</h3>
                        <button class="modal-close-btn" id="reverse-checkout-modal-close">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="reverse-checkout-info">
                            <div class="info-row">
                                <span class="label">桌號:</span>
                                <span id="reverse-checkout-table-number"></span>
                            </div>
                            <div class="info-row">
                                <span class="label">原金額:</span>
                                <span id="reverse-checkout-amount"></span>
                            </div>
                            <div class="info-row">
                                <span class="label">結賬時間:</span>
                                <span id="reverse-checkout-time"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="reverse-checkout-employee-select">選擇反結賬員工 <span class="required">*</span></label>
                            <select id="reverse-checkout-employee-select" class="form-control">
                                <option value="">-- 請選擇員工 --</option>
                            </select>
                            <div id="reverse-checkout-employee-loading" class="loading-text" style="display:none;">
                                <i class="fas fa-spinner fa-spin"></i> 載入中...
                            </div>
                            <div id="reverse-checkout-employee-empty" class="empty-text" style="display:none;">
                                暫無員工資料，請先同步員工名單
                            </div>
                        </div>
                        <div id="reverse-checkout-error" class="error-message" style="display:none;"></div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" id="reverse-checkout-cancel-btn">取消</button>
                        <button class="btn btn-danger" id="reverse-checkout-confirm-btn" disabled>
                            <i class="fas fa-undo"></i> 確認反結賬
                        </button>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);

            // 綁定事件
            modal.querySelector('#reverse-checkout-modal-close').addEventListener('click', () => this.hideReverseCheckoutModal());
            modal.querySelector('#reverse-checkout-cancel-btn').addEventListener('click', () => this.hideReverseCheckoutModal());
            modal.querySelector('#reverse-checkout-confirm-btn').addEventListener('click', () => this.confirmReverseCheckout());

            // 員工選擇啟用/停用確認按鈕
            modal.querySelector('#reverse-checkout-employee-select').addEventListener('change', (e) => {
                const confirmBtn = document.getElementById('reverse-checkout-confirm-btn');
                confirmBtn.disabled = !e.target.value;
            });

            // 點擊背景關閉
            modal.addEventListener('click', (e) => {
                if (e.target === modal) this.hideReverseCheckoutModal();
            });
        }

        // 填充資訊
        document.getElementById('reverse-checkout-table-number').textContent = tableNumber;
        document.getElementById('reverse-checkout-amount').textContent = `$${parseFloat(totalAmount || 0).toLocaleString('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
        document.getElementById('reverse-checkout-time').textContent = this.formatDateTime(checkoutTime);

        // 儲存 receiptId 供後續使用
        modal.dataset.receiptId = receiptId;

        // 載入員工名單
        this.loadReverseCheckoutEmployees();

        // 顯示模態框
        modal.classList.remove('hidden');
    }

    hideReverseCheckoutModal() {
        const modal = document.getElementById('reverse-checkout-modal');
        if (modal) {
            modal.classList.add('hidden');
            // 重置表單
            const select = document.getElementById('reverse-checkout-employee-select');
            if (select) select.value = '';
            const confirmBtn = document.getElementById('reverse-checkout-confirm-btn');
            if (confirmBtn) confirmBtn.disabled = true;
            const errorDiv = document.getElementById('reverse-checkout-error');
            if (errorDiv) errorDiv.style.display = 'none';
        }
    }

    async loadReverseCheckoutEmployees() {
        const select = document.getElementById('reverse-checkout-employee-select');
        const loading = document.getElementById('reverse-checkout-employee-loading');
        const empty = document.getElementById('reverse-checkout-employee-empty');
        if (!select) return;

        select.style.display = 'none';
        loading.style.display = 'block';
        empty.style.display = 'none';

        try {
            const response = await this.fetchWithAuth('/api/store-employees');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const result = await response.json();

            loading.style.display = 'none';
            select.style.display = '';

            if (result.success && result.data && result.data.length > 0) {
                select.innerHTML = '<option value="">-- 請選擇員工 --</option>';
                result.data.forEach(emp => {
                    const option = document.createElement('option');
                    option.value = emp.staff_name;
                    option.textContent = emp.staff_name;
                    select.appendChild(option);
                });
            } else {
                empty.style.display = 'block';
                select.style.display = 'none';
            }
        } catch (err) {
            console.error('載入員工名單錯誤:', err);
            loading.style.display = 'none';
            select.style.display = '';
            empty.style.display = 'block';
            empty.textContent = '載入員工名單失敗: ' + err.message;
        }
    }

    async confirmReverseCheckout() {
        const modal = document.getElementById('reverse-checkout-modal');
        const receiptId = modal?.dataset.receiptId;
        const select = document.getElementById('reverse-checkout-employee-select');
        const employeeName = select?.value;
        const errorDiv = document.getElementById('reverse-checkout-error');
        const confirmBtn = document.getElementById('reverse-checkout-confirm-btn');

        if (!receiptId || !employeeName) {
            if (errorDiv) {
                errorDiv.textContent = '請選擇反結賬員工';
                errorDiv.style.display = 'block';
            }
            return;
        }

        confirmBtn.disabled = true;
        confirmBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 處理中...';
        if (errorDiv) errorDiv.style.display = 'none';

        try {
            const response = await this.fetchWithAuth(`/api/reverse-checkout/${receiptId}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ reverseEmployeeName: employeeName })
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage(`反結賬成功 (桌號: ${document.getElementById('reverse-checkout-table-number').textContent})`, 'success');
                this.hideReverseCheckoutModal();
                // 關閉結賬詳細信息視窗
                const detailModal = document.getElementById('checkout-detail-modal');
                if (detailModal) detailModal.remove();
                // 刷新今日結賬詳細記錄
                this.loadTodayCheckoutRecords();
                // 刷新今日統計
                this.loadTodayStats();
            } else {
                throw new Error(result.error || result.message || '反結賬失敗');
            }
        } catch (err) {
            console.error('反結賬錯誤:', err);
            if (errorDiv) {
                errorDiv.textContent = '反結賬失敗: ' + err.message;
                errorDiv.style.display = 'block';
            }
            confirmBtn.disabled = false;
            confirmBtn.innerHTML = '<i class="fas fa-undo"></i> 確認反結賬';
        }
    }

    // ==================== 結束反結賬功能 ====================

    // ==================== 部份反結賬功能（單品反結賬） ====================

    showPartialReverseConfirmModal(receiptId, tableNumber, productName, currentTotal) {
        console.log('顯示部份反結賬確認:', { receiptId, tableNumber, productName, currentTotal });

        // 移除舊的 modal（如果存在）
        const existingModal = document.getElementById('partial-reverse-modal');
        if (existingModal) existingModal.remove();

        // 創建模態框
        const modal = document.createElement('div');
        modal.id = 'partial-reverse-modal';
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 450px;">
                <div class="modal-header">
                    <h3><i class="fas fa-undo"></i> 部份反結賬確認</h3>
                    <button class="modal-close-btn" id="partial-reverse-modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="partial-reverse-info">
                        <div class="info-row">
                            <span class="label">桌號:</span>
                            <span class="value">${this.escapeHtml(tableNumber)}</span>
                        </div>
                        <div class="info-row">
                            <span class="label">反結賬商品:</span>
                            <span class="value highlight">${this.escapeHtml(productName)}</span>
                        </div>
                        <div class="info-row">
                            <span class="label">目前總金額:</span>
                            <span class="value">$${parseFloat(currentTotal || 0).toLocaleString('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                        </div>
                        <div class="partial-reverse-notice">
                            <i class="fas fa-info-circle"></i> 只針對商品 <strong>${this.escapeHtml(productName)}</strong> 做反結賬，不影響其他商品和入座人數
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="partial-reverse-employee-select">選擇反結賬員工 <span class="required">*</span></label>
                        <select id="partial-reverse-employee-select" class="form-control">
                            <option value="">-- 請選擇員工 --</option>
                        </select>
                        <div id="partial-reverse-employee-loading" class="loading-text" style="display:none;">
                            <i class="fas fa-spinner fa-spin"></i> 載入中...
                        </div>
                        <div id="partial-reverse-employee-empty" class="empty-text" style="display:none;">
                            暫無員工資料，請先同步員工名單
                        </div>
                    </div>
                    <div id="partial-reverse-error" class="error-message" style="display:none;"></div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" id="partial-reverse-cancel-btn">取消</button>
                    <button class="btn btn-danger" id="partial-reverse-confirm-btn" disabled>
                        <i class="fas fa-undo"></i> 確認部份反結賬
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        // 儲存資料供後續使用
        modal.dataset.receiptId = receiptId;
        modal.dataset.productName = productName;

        // 綁定事件
        modal.querySelector('#partial-reverse-modal-close').addEventListener('click', () => this.hidePartialReverseModal());
        modal.querySelector('#partial-reverse-cancel-btn').addEventListener('click', () => this.hidePartialReverseModal());
        modal.querySelector('#partial-reverse-confirm-btn').addEventListener('click', () => this.confirmPartialReverse());

        // 員工選擇啟用/停用確認按鈕
        modal.querySelector('#partial-reverse-employee-select').addEventListener('change', (e) => {
            const confirmBtn = document.getElementById('partial-reverse-confirm-btn');
            confirmBtn.disabled = !e.target.value;
        });

        // 點擊背景關閉
        modal.addEventListener('click', (e) => {
            if (e.target === modal) this.hidePartialReverseModal();
        });

        // 載入員工名單
        this.loadPartialReverseEmployees();

        // 顯示模態框
        modal.classList.remove('hidden');
    }

    hidePartialReverseModal() {
        const modal = document.getElementById('partial-reverse-modal');
        if (modal) {
            modal.classList.add('hidden');
            setTimeout(() => modal.remove(), 300); // 動畫結束後移除
        }
    }

    async loadPartialReverseEmployees() {
        const select = document.getElementById('partial-reverse-employee-select');
        const loading = document.getElementById('partial-reverse-employee-loading');
        const empty = document.getElementById('partial-reverse-employee-empty');
        if (!select) return;

        select.style.display = 'none';
        loading.style.display = 'block';
        empty.style.display = 'none';

        try {
            const response = await this.fetchWithAuth('/api/store-employees');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const result = await response.json();

            loading.style.display = 'none';
            select.style.display = '';

            if (result.success && result.data && result.data.length > 0) {
                select.innerHTML = '<option value="">-- 請選擇員工 --</option>';
                result.data.forEach(emp => {
                    const option = document.createElement('option');
                    option.value = emp.staff_name;
                    option.textContent = emp.staff_name;
                    select.appendChild(option);
                });
            } else {
                empty.style.display = 'block';
                select.style.display = 'none';
            }
        } catch (err) {
            console.error('載入員工名單錯誤:', err);
            loading.style.display = 'none';
            select.style.display = '';
            empty.style.display = 'block';
            empty.textContent = '載入員工名單失敗: ' + err.message;
        }
    }

    async confirmPartialReverse() {
        const modal = document.getElementById('partial-reverse-modal');
        const receiptId = modal?.dataset.receiptId;
        const productName = modal?.dataset.productName;
        const select = document.getElementById('partial-reverse-employee-select');
        const employeeName = select?.value;
        const errorDiv = document.getElementById('partial-reverse-error');
        const confirmBtn = document.getElementById('partial-reverse-confirm-btn');

        if (!receiptId || !employeeName) {
            if (errorDiv) {
                errorDiv.textContent = '請選擇反結賬員工';
                errorDiv.style.display = 'block';
            }
            return;
        }

        if (!productName) {
            if (errorDiv) {
                errorDiv.textContent = '缺少商品資訊';
                errorDiv.style.display = 'block';
            }
            return;
        }

        confirmBtn.disabled = true;
        confirmBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 處理中...';
        if (errorDiv) errorDiv.style.display = 'none';

        try {
            const response = await this.fetchWithAuth(`/api/reverse-checkout/${receiptId}/partial`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    reverseEmployeeName: employeeName,
                    productName: productName
                })
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage(`商品「${productName}」反結賬成功 (桌號: ${document.querySelector('#partial-reverse-modal .partial-reverse-info .info-row:first-child .value')?.textContent || ''})`, 'success');
                this.hidePartialReverseModal();
                // 關閉結賬詳細信息視窗
                const detailModal = document.getElementById('checkout-detail-modal');
                if (detailModal) detailModal.remove();
                // 刷新今日結賬詳細記錄
                this.loadTodayCheckoutRecords();
                // 刷新今日統計
                this.loadTodayStats();
            } else {
                throw new Error(result.error || result.message || '部份反結賬失敗');
            }
        } catch (err) {
            console.error('部份反結賬錯誤:', err);
            if (errorDiv) {
                errorDiv.textContent = '部份反結賬失敗: ' + err.message;
                errorDiv.style.display = 'block';
            }
            confirmBtn.disabled = false;
            confirmBtn.innerHTML = '<i class="fas fa-undo"></i> 確認部份反結賬';
        }
    }

    // ==================== 結束部份反結賬功能 ====================

    formatDateTime(dateTimeString) {
        if (!dateTimeString) return '-';
        try {
            let date;
            // 檢查是否為 SQLite 日期時間格式: YYYY-MM-DD HH:MM:SS
            const sqlitePattern = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/;
            const match = sqlitePattern.exec(dateTimeString);
            if (match) {
                // 轉換為 ISO 格式: YYYY-MM-DDTHH:MM:SSZ (假設為UTC時間)
                const isoString = `${match[1]}-${match[2]}-${match[3]}T${match[4]}:${match[5]}:${match[6]}Z`;
                date = new Date(isoString);
                console.log(`formatDateTime SQLite格式轉換: ${dateTimeString} -> ${isoString} -> UTC時間: ${date.toISOString()}`);
            } else {
                // 檢查是否已有時區信息
                let timeString = dateTimeString;
                const hasTimezone = dateTimeString.endsWith('Z') ||
                                    /[+-]\d{2}:?\d{2}$/.test(dateTimeString) ||
                                    dateTimeString.includes('T') && dateTimeString.length > 19 &&
                                    (dateTimeString[19] === '+' || dateTimeString[19] === '-');

                if (!hasTimezone) {
                    // 沒有時區信息，假設為UTC時間
                    if (dateTimeString.includes('T')) {
                        // ISO格式: YYYY-MM-DDTHH:MM:SS
                        timeString = dateTimeString + 'Z';
                    } else {
                        // 其他格式，嘗試解析
                        timeString = dateTimeString;
                    }
                    console.log(`formatDateTime 添加時區: ${dateTimeString} -> ${timeString} (假設UTC)`);
                }
                date = new Date(timeString);
            }
            // 使用香港時區 (UTC+8) 顯示
            const hkTime = date.toLocaleString('zh-TW', {
                timeZone: 'Asia/Hong_Kong',
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false
            }).replace(/\//g, '-');
            console.log(`formatDateTime 轉換結果: ${dateTimeString} -> UTC: ${date.toISOString()} -> 香港時間: ${hkTime}`);
            return hkTime;
        } catch (error) {
            console.error('格式化日期時間錯誤:', error, dateTimeString);
            return dateTimeString;
        }
    }

    async loadHistoricalSales(page = 1, filters = {}) {
        try {
            // 更新內部狀態
            this.historicalSalesPage = page;
            if (Object.keys(filters).length > 0) {
                this.historicalSalesFilters = { ...filters };
            }

            // 敏感操作使用不同的API
            if (this.historicalSalesFilters.view_type === 'sensitive_operations') {
                return await this.loadHistoricalSensitiveOperations(page);
            }

            // 敏感操作總結使用不同的API
            if (this.historicalSalesFilters.view_type === 'sensitive_operations_summary') {
                return await this.loadHistoricalSensitiveOperationsSummary(page);
            }

            // 使用自定義報告API
            const requestBody = {
                report_type: 'historical_sales',
                start_date: this.historicalSalesFilters.start_date || new Date().toISOString().split('T')[0],
                end_date: this.historicalSalesFilters.end_date || new Date().toISOString().split('T')[0],
                metrics: ['revenue', 'transactions', 'customers'],
                view_type: this.historicalSalesFilters.view_type || 'summary',
                filters: {}
            };

            // 添加分店篩選器
            if (this.historicalSalesFilters.store_id) {
                requestBody.filters.store_id = this.historicalSalesFilters.store_id;
            }

            const response = await this.fetchWithAuth('/api/reports/custom', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(requestBody)
            });

            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const result = await response.json();

            if (result.success) {
                // 轉換API響應格式以適應現有渲染邏輯
                const transformedData = this.transformHistoricalSalesData(result.data);
                this.renderHistoricalSales(transformedData);
            } else {
                this.addMessage(`載入歷史銷售數據失敗: ${result.message}`, 'error');
            }
        } catch (error) {
            this.addMessage(`載入歷史銷售數據失敗: ${error.message}`, 'error');
            // 顯示佔位數據供測試
            this.renderHistoricalSales({
                sales: [],
                summary: { total_revenue: 0, total_customers: 0, avg_checkout: 0, total_checkouts: 0 },
                pagination: { current_page: 1, total_pages: 1, total: 0 }
            });
        }
    }

    async loadHistoricalSensitiveOperations(page = 1) {
        try {
            const params = new URLSearchParams({
                page: page.toString(),
                limit: '50'
            });

            if (this.historicalSalesFilters.start_date) {
                params.append('start_date', this.historicalSalesFilters.start_date);
            }
            if (this.historicalSalesFilters.end_date) {
                params.append('end_date', this.historicalSalesFilters.end_date);
            }

            // 添加分店篩選
            const storeId = this.historicalSalesFilters.store_id;
            if (storeId && !this.isHeadquartersStore(storeId)) {
                params.append('store_id', storeId);
            }

            const response = await this.fetchWithAuth(`/api/audit-logs/sensitive-operations?${params}`, { skipStoreId: true });
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const result = await response.json();

            if (result.success) {
                const { operations, total, pagination } = result.data;
                const transformedData = {
                    sales: operations.map(op => ({
                        id: op.id,
                        created_at: op.created_at,
                        action_type: op.action_type,
                        action_display: op.action_display,
                        employee_username: op.employee_username,
                        employee_name: op.employee_name,
                        ip_address: op.ip_address,
                        details: op.details || {}
                    })),
                    summary: {
                        total_records: total
                    },
                    pagination: {
                        current_page: pagination.current_page,
                        total_pages: pagination.total_pages,
                        total: pagination.total_records || total,
                        has_prev: pagination.has_prev,
                        has_next: pagination.has_next
                    },
                    view_type: 'sensitive_operations'
                };
                this.renderHistoricalSales(transformedData);
            } else {
                this.addMessage(`載入敏感操作失敗: ${result.message}`, 'error');
                this.renderHistoricalSales({
                    sales: [],
                    summary: {},
                    pagination: { current_page: 1, total_pages: 1, total: 0 },
                    view_type: 'sensitive_operations'
                });
            }
        } catch (error) {
            this.addMessage(`載入敏感操作失敗: ${error.message}`, 'error');
            this.renderHistoricalSales({
                sales: [],
                summary: {},
                pagination: { current_page: 1, total_pages: 1, total: 0 },
                view_type: 'sensitive_operations'
            });
        }
    }

    async loadHistoricalSensitiveOperationsSummary(page = 1) {
        try {
            const params = new URLSearchParams();
            if (this.historicalSalesFilters.start_date) {
                params.append('start_date', this.historicalSalesFilters.start_date);
            }
            if (this.historicalSalesFilters.end_date) {
                params.append('end_date', this.historicalSalesFilters.end_date);
            }

            // 添加分店篩選
            const storeId = this.historicalSalesFilters.store_id;
            if (storeId && !this.isHeadquartersStore(storeId)) {
                params.append('store_id', storeId);
            }

            const response = await this.fetchWithAuth(`/api/audit-logs/sensitive-operations/summary?${params}`, { skipStoreId: true });
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const result = await response.json();

            if (result.success) {
                const { summary, grand_total } = result.data;
                const transformedData = {
                    sales: summary,
                    summary: {
                        total_records: grand_total.total_count,
                        total_amount: grand_total.total_amount,
                        total_count: grand_total.total_count
                    },
                    pagination: { current_page: 1, total_pages: 1, total: summary.length, has_prev: false, has_next: false },
                    view_type: 'sensitive_operations_summary'
                };
                this.renderHistoricalSales(transformedData);
            } else {
                this.addMessage(`載入敏感操作總結失敗: ${result.message}`, 'error');
                this.renderHistoricalSales({
                    sales: [],
                    summary: {},
                    pagination: { current_page: 1, total_pages: 1, total: 0 },
                    view_type: 'sensitive_operations_summary'
                });
            }
        } catch (error) {
            this.addMessage(`載入敏感操作總結失敗: ${error.message}`, 'error');
            this.renderHistoricalSales({
                sales: [],
                summary: {},
                pagination: { current_page: 1, total_pages: 1, total: 0 },
                view_type: 'sensitive_operations_summary'
            });
        }
    }

    transformHistoricalSalesData(apiData) {
        const viewType = this.historicalSalesFilters.view_type || 'summary';
        console.log(`transformHistoricalSalesData: view_type = ${viewType}, apiData:`, apiData);

        if (viewType === 'products') {
            // 商品詳情視圖
            const summary = apiData.summary || {};
            const products = apiData.products || [];

            // 轉換摘要數據
            const transformedSummary = {
                total_revenue: summary.total_revenue || 0,
                total_quantity: summary.total_quantity || 0,
                total_products: summary.total_products || 0
            };

            // 轉換商品數據
            const transformedSales = products.map(product => ({
                id: product.id,
                name: product.name,
                category: product.category,
                price: product.price || 0,
                total_quantity: product.total_quantity || 0,
                total_revenue: product.total_revenue || 0,
                customer_count: product.customer_count || 0,
                days_sold: product.days_sold || 0
            }));

            // 計算分頁信息
            const pagination = {
                current_page: 1,
                total_pages: 1,
                total: transformedSales.length,
                has_prev: false,
                has_next: false
            };

            return {
                sales: transformedSales,
                summary: transformedSummary,
                pagination: pagination,
                view_type: 'products'
            };
        } else if (viewType === 'checkout_receipts') {
            // 結賬單據視圖
            const summary = apiData.summary || {};
            const receipts = apiData.checkout_receipts || [];

            const transformedSummary = {
                total_revenue: summary.total_revenue || 0,
                total_checkouts: summary.total_checkouts || 0,
                total_people: summary.total_people || 0
            };

            const transformedSales = receipts.map(receipt => ({
                id: receipt.id,
                store_id: receipt.store_id,
                table_number: receipt.table_number,
                people_count: receipt.people_count || 0,
                entry_time: receipt.entry_time,
                checkout_time: receipt.checkout_time,
                total_amount: receipt.total_amount || 0,
                products: receipt.products || '無',
                is_member: receipt.is_member || 0,
                qr_code: receipt.qr_code || '',
                lockers: receipt.lockers || '無',
                is_reversed: receipt.is_reversed || 0,
                reverse_employee_name: receipt.reverse_employee_name || ''
            }));

            const pagination = {
                current_page: 1,
                total_pages: 1,
                total: transformedSales.length,
                has_prev: false,
                has_next: false
            };

            return {
                sales: transformedSales,
                summary: transformedSummary,
                pagination: pagination,
                view_type: 'checkout_receipts'
            };
        } else if (viewType === 'hourly_customers') {
            // 每小時客人統計視圖
            const summary = apiData.summary || {};
            const hourlyData = apiData.hourly_data || [];
            const groupedByDate = apiData.grouped_by_date || {};

            // 轉換摘要數據
            const transformedSummary = {
                total_customers: summary.total_customers || 0,
                total_revenue: summary.total_revenue || 0,
                hour_count: summary.hour_count || 0
            };

            // 轉換每小時數據（暫時移除時區轉換以進行測試）
            console.log('原始每小時數據:', hourlyData);
            const transformedSales = hourlyData.map((record, index) => {
                const hour = parseInt(record.hour) || 0;
                // 調試日誌（僅顯示前3條）
                if (index < 3) {
                    console.log(`每小時數據記錄 ${index}:`, record);
                }

                return {
                    date: record.date,
                    hour: hour,
                    customer_count: record.customer_count || 0,
                    total_revenue: record.total_revenue || 0,
                    avg_checkout: record.avg_checkout || 0
                };
            });

            // 計算分頁信息
            const pagination = {
                current_page: 1,
                total_pages: 1,
                total: transformedSales.length,
                has_prev: false,
                has_next: false
            };

            return {
                sales: transformedSales,
                summary: transformedSummary,
                pagination: pagination,
                view_type: 'hourly_customers',
                grouped_by_date: groupedByDate
            };
        } else {
            // 銷售總覽視圖（默認）
            const summary = apiData.summary || {};
            const dailyData = apiData.daily_data || [];

            console.log('銷售總覽summary數據:', summary);
            console.log('銷售總覽每日數據:', dailyData);

            // 轉換摘要數據
            const transformedSummary = {
                total_revenue: summary.total_revenue || 0,
                total_customers: summary.unique_customers || summary.customer_count || summary.transaction_count || 0,
                avg_checkout: summary.avg_order_value || 0,
                total_checkouts: summary.transaction_count || 0
            };

            // 轉換每日銷售數據
            const transformedSales = dailyData.map(day => ({
                date: day.date,
                revenue: day.daily_revenue || 0,
                customers: day.total_customers || day.unique_customers || day.customer_count || day.daily_customers || day.transaction_count || 0,
                avg_checkout: day.avg_order_value || 0,
                checkouts: day.transaction_count || 0
            }));

            // 計算分頁信息（自定義報告不分頁，全部顯示）
            const pagination = {
                current_page: 1,
                total_pages: 1,
                total: transformedSales.length,
                has_prev: false,
                has_next: false
            };

            return {
                sales: transformedSales,
                summary: transformedSummary,
                pagination: pagination,
                view_type: 'summary'
            };
        }
    }

    async loadAuditLogs(page = 1, filters = {}) {
        try {
            // 更新內部狀態
            this.auditLogsPage = page;
            if (Object.keys(filters).length > 0) {
                this.auditLogsFilters = { ...filters };
            }

            // 構建查詢參數
            const params = new URLSearchParams({ page, limit: 20 });
            if (this.auditLogsFilters.action_type) params.append('action_type', this.auditLogsFilters.action_type);
            if (this.auditLogsFilters.start_date) params.append('start_date', this.auditLogsFilters.start_date);
            if (this.auditLogsFilters.end_date) params.append('end_date', this.auditLogsFilters.end_date);

            const response = await this.fetchWithAuth(`/api/audit-logs?${params}`);
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const result = await response.json();

            if (result.success) {
                this.renderAuditLogs(result.data);
            } else {
                this.addMessage(`載入操作日誌失敗: ${result.message}`, 'error');
            }
        } catch (error) {
            this.addMessage(`載入操作日誌失敗: ${error.message}`, 'error');
        }
    }

    async loadInventorySummary() {
        try {
            const response = await this.fetchWithAuth('/api/inventory/summary');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const result = await response.json();

            if (result.success) {
                this.renderInventorySummary(result.data);
            } else {
                console.warn('載入庫存摘要失敗:', result.message);
            }
        } catch (error) {
            console.warn('載入庫存摘要失敗:', error.message);
        }
    }

    setupReportsTabEvents() {
        // 防止重複綁定（每次切換報表Tab都會呼叫此方法）
        if (this._reportsEventsSetup) {
            console.log('setupReportsTabEvents: 已設置過，跳過');
            return;
        }
        this._reportsEventsSetup = true;

        // 歷史銷售篩選器
        const historicalApplyFiltersBtn = document.getElementById('historical-apply-filters');
        const historicalRefreshBtn = document.getElementById('historical-refresh-btn');
        const historicalPrevPageBtn = document.getElementById('historical-prev-page');
        const historicalNextPageBtn = document.getElementById('historical-next-page');

        if (historicalApplyFiltersBtn) {
            historicalApplyFiltersBtn.addEventListener('click', () => this.applyHistoricalFilters());
        }
        if (historicalRefreshBtn) {
            historicalRefreshBtn.addEventListener('click', () => this.loadHistoricalSales());
        }
        if (historicalPrevPageBtn) {
            historicalPrevPageBtn.addEventListener('click', () => this.changeHistoricalPage(-1));
        }
        if (historicalNextPageBtn) {
            historicalNextPageBtn.addEventListener('click', () => this.changeHistoricalPage(1));
        }

        // CSV下載按鈕 - 使用事件委託並防止重複綁定
        const historicalControlsContainer = document.querySelector('.historical-sales-controls');
        if (historicalControlsContainer) {
            // 移除舊的事件監聽器（如果存在）
            if (this._historicalControlsClickHandler) {
                historicalControlsContainer.removeEventListener('click', this._historicalControlsClickHandler);
            }

            // 創建新的事件處理函數
            this._historicalControlsClickHandler = (event) => {
                if (event.target && event.target.id === 'historical-download-csv-btn') {
                    console.log('CSV下載按鈕被點擊（事件委託）');
                    event.preventDefault();
                    event.stopPropagation();
                    this.downloadHistoricalSalesCSV();
                }
            };

            console.log('設置歷史銷售控制容器事件委託');
            historicalControlsContainer.addEventListener('click', this._historicalControlsClickHandler);
        } else {
            console.warn('找不到歷史銷售控制容器');
        }

        // 操作日誌篩選器（保留但元素已不存在）
        const applyFiltersBtn = document.getElementById('audit-apply-filters');
        const refreshBtn = document.getElementById('audit-refresh-btn');
        const prevPageBtn = document.getElementById('audit-prev-page');
        const nextPageBtn = document.getElementById('audit-next-page');

        if (applyFiltersBtn) {
            applyFiltersBtn.addEventListener('click', () => this.applyAuditFilters());
        }
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.loadAuditLogs());
        }
        if (prevPageBtn) {
            prevPageBtn.addEventListener('click', () => this.changeAuditPage(-1));
        }
        if (nextPageBtn) {
            nextPageBtn.addEventListener('click', () => this.changeAuditPage(1));
        }

        // 庫存操作按鈕（保留但元素已不存在）
        const lowStockBtn = document.getElementById('view-low-stock-btn');
        const inventoryLogsBtn = document.getElementById('view-inventory-logs-btn');
        if (lowStockBtn) {
            lowStockBtn.addEventListener('click', () => this.viewLowStock());
        }
        if (inventoryLogsBtn) {
            inventoryLogsBtn.addEventListener('click', () => this.viewInventoryLogs());
        }

        // 快速報告按鈕（保留但元素已不存在）
        const dailyReportBtn = document.getElementById('daily-report-btn');
        const weeklyReportBtn = document.getElementById('weekly-report-btn');
        const monthlyReportBtn = document.getElementById('monthly-report-btn');
        if (dailyReportBtn) {
            dailyReportBtn.addEventListener('click', () => this.generateDailyReport());
        }
        if (weeklyReportBtn) {
            weeklyReportBtn.addEventListener('click', () => this.generateWeeklyReport());
        }
        if (monthlyReportBtn) {
            monthlyReportBtn.addEventListener('click', () => this.generateMonthlyReport());
        }

        // 今日結賬記錄刷新按鈕
        const refreshCheckoutRecordsBtn = document.getElementById('refresh-checkout-records-btn');
        if (refreshCheckoutRecordsBtn) {
            refreshCheckoutRecordsBtn.addEventListener('click', () => this.loadTodayCheckoutRecords());
        }

        // 結賬記錄詳細按鈕事件委託
        const checkoutTable = document.getElementById('today-checkout-records-table');
        if (checkoutTable) {
            checkoutTable.addEventListener('click', (e) => {
                const detailsBtn = e.target.closest('.btn-details');
                if (!detailsBtn) return;

                const tableNumber = detailsBtn.dataset.tableNumber;
                const member = detailsBtn.dataset.member;
                const qrCode = detailsBtn.dataset.qrCode;
                const products = detailsBtn.dataset.products;
                const lockers = detailsBtn.dataset.lockers;
                const recordId = detailsBtn.dataset.recordId;
                const totalAmount = detailsBtn.dataset.totalAmount;
                const checkoutTime = detailsBtn.dataset.checkoutTime;
                const peopleCount = detailsBtn.dataset.peopleCount;
                const entryTime = detailsBtn.dataset.entryTime;
                const isReversed = detailsBtn.dataset.isReversed === '1';
                const reverseEmployee = detailsBtn.dataset.reverseEmployee || '';
                const reversedProducts = detailsBtn.dataset.reversedProducts || '';

                this.showCheckoutDetail({
                    tableNumber,
                    member,
                    qrCode,
                    products,
                    reversedProducts,
                    lockers,
                    recordId,
                    totalAmount,
                    checkoutTime,
                    peopleCount,
                    entryTime,
                    isReversed,
                    reverseEmployee
                });
            });
        }

        // 歷史銷售結賬單據詳細按鈕事件委託
        const historicalSalesContainer = document.querySelector('.historical-sales-table-container');
        if (historicalSalesContainer) {
            historicalSalesContainer.addEventListener('click', (e) => {
                const detailsBtn = e.target.closest('.historical-checkout-detail-btn');
                if (!detailsBtn) {
                    // 檢查是否為敏感操作詳細按鈕
                    const sensitiveBtn = e.target.closest('.historical-sensitive-detail-btn');
                    if (sensitiveBtn) {
                        const dataAttr = sensitiveBtn.dataset.sensitiveData;
                        if (dataAttr) {
                            try {
                                const data = JSON.parse(dataAttr);
                                // 映射 camelCase 到 snake_case
                                this.showSensitiveOperationDetail({
                                    id: data.operationId,
                                    action_type: data.actionType,
                                    action_display: data.actionDisplay,
                                    created_at: data.createdAt,
                                    employee_username: data.employeeUsername,
                                    employee_name: data.employeeName,
                                    ip_address: data.ipAddress,
                                    details: data.details || {}
                                });
                            } catch (err) {
                                console.error('解析敏感操作數據失敗:', err);
                            }
                        }
                        return;
                    }
                    return;
                }

                const tableNumber = detailsBtn.dataset.tableNumber;
                const member = detailsBtn.dataset.member;
                const qrCode = detailsBtn.dataset.qrCode;
                const products = detailsBtn.dataset.products;
                const lockers = detailsBtn.dataset.lockers;
                const recordId = detailsBtn.dataset.recordId;
                const totalAmount = detailsBtn.dataset.totalAmount;
                const checkoutTime = detailsBtn.dataset.checkoutTime;
                const peopleCount = detailsBtn.dataset.peopleCount;
                const entryTime = detailsBtn.dataset.entryTime;
                const isReversed = detailsBtn.dataset.isReversed === '1';
                const reverseEmployee = detailsBtn.dataset.reverseEmployee || '';
                const reversedProducts = detailsBtn.dataset.reversedProducts || '';

                this.showCheckoutDetail({
                    tableNumber,
                    member,
                    qrCode,
                    products,
                    reversedProducts,
                    lockers,
                    recordId,
                    totalAmount,
                    checkoutTime,
                    peopleCount,
                    entryTime,
                    isReversed,
                    reverseEmployee
                });
            });
        }

        // 歷史銷售反結賬按鈕事件委託
        if (historicalSalesContainer) {
            historicalSalesContainer.addEventListener('click', (e) => {
                const reverseBtn = e.target.closest('.reverse-checkout-btn');
                if (!reverseBtn) return;

                const receiptId = reverseBtn.dataset.receiptId;
                const tableNumber = reverseBtn.dataset.tableNumber;
                const totalAmount = reverseBtn.dataset.totalAmount;
                const checkoutTime = reverseBtn.dataset.checkoutTime;

                this.showReverseCheckoutModal(receiptId, tableNumber, totalAmount, checkoutTime);
            });
        }

        // 敏感操作刷新按鈕
        const refreshSensitiveOperationsBtn = document.getElementById('refresh-sensitive-operations-btn');
        if (refreshSensitiveOperationsBtn) {
            refreshSensitiveOperationsBtn.addEventListener('click', () => this.loadSensitiveOperations(1));
        }

        // 敏感操作詳細按鈕事件委託
        const sensitiveOperationsTable = document.getElementById('sensitive-operations-table');
        if (sensitiveOperationsTable) {
            sensitiveOperationsTable.addEventListener('click', (e) => {
                const detailsBtn = e.target.closest('.btn-details');
                if (!detailsBtn) return;

                const operationData = detailsBtn.dataset.operationData;

                try {
                    if (operationData) {
                        const data = JSON.parse(operationData);
                        this.showSensitiveOperationDetail({
                            id: data.operationId,
                            action_type: data.actionType,
                            action_display: data.actionDisplay,
                            created_at: data.createdAt,
                            employee_name: data.employeeName,
                            employee_username: data.employeeUsername,
                            ip_address: data.ipAddress,
                            details: data.details
                        });
                    } else {
                        // 兼容舊格式
                        const operationId = detailsBtn.dataset.operationId;
                        const actionType = detailsBtn.dataset.actionType;
                        const operationDetails = detailsBtn.dataset.operationDetails;
                        const details = operationDetails ? JSON.parse(operationDetails) : {};
                        this.showSensitiveOperationDetail({
                            id: operationId,
                            action_type: actionType,
                            details: details,
                            created_at: detailsBtn.closest('tr').querySelector('td:first-child')?.textContent || '',
                            employee_name: detailsBtn.closest('tr').querySelector('td:nth-child(3)')?.textContent || ''
                        });
                    }
                } catch (error) {
                    console.error('解析操作詳情失敗:', error);
                    this.addMessage('無法解析操作詳情', 'error');
                }
            });
        }

        // 敏感操作模態框關閉按鈕
        const closeSensitiveOperationModalBtn = document.getElementById('close-sensitive-operation-modal');
        const sensitiveOperationModalCloseBtn = document.getElementById('sensitive-operation-modal-close');
        if (closeSensitiveOperationModalBtn) {
            closeSensitiveOperationModalBtn.addEventListener('click', () => this.hideSensitiveOperationModal());
        }
        if (sensitiveOperationModalCloseBtn) {
            sensitiveOperationModalCloseBtn.addEventListener('click', () => this.hideSensitiveOperationModal());
        }
    }

    renderAuditLogs(data) {
        console.log('Audit logs data:', data);
        const container = document.getElementById('audit-logs-list');
        if (!container) return;

        const logs = data.logs || [];
        const pagination = data.pagination || { current_page: 1, total_pages: 1, total: 0 };
        const summary = data.summary || {};

        if (logs.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-clipboard-list"></i>
                    <p data-i18n="noAuditLogsFound">找不到操作日誌記錄</p>
                </div>
            `;
            return;
        }

        // 構建日誌表格
        let html = '';
        logs.forEach(log => {
            // 格式化時間
            const logTime = new Date(log.created_at).toLocaleString('zh-TW');

            // 格式化操作類型
            const actionTypeMap = {
                'login': '登入',
                'logout': '登出',
                'product_add': '新增商品',
                'product_edit': '編輯商品',
                'stock_update': '庫存更新',
                'order_create': '創建訂單',
                'checkout': '結賬',
                'inventory_restock': '庫存補貨',
                'inventory_adjust': '庫存調整',
                'audit_cleanup': '日誌清理'
            };
            const actionTypeText = actionTypeMap[log.action_type] || log.action_type;

            // 格式化詳細信息（截斷過長文本）
            let details = log.action_details || '';
            if (details.length > 50) {
                details = details.substring(0, 50) + '...';
            }

            html += `
                <div class="audit-log-item">
                    <div class="audit-log-time">${this.escapeHtml(logTime)}</div>
                    <div class="audit-log-employee">${this.escapeHtml(log.employee_name || log.employee_username || '系統')}</div>
                    <div class="audit-log-type">
                        <span class="action-badge action-${log.action_type}">${this.escapeHtml(actionTypeText)}</span>
                    </div>
                    <div class="audit-log-details" title="${this.escapeHtml(log.action_details || '')}">
                        ${this.escapeHtml(details)}
                    </div>
                    <div class="audit-log-ip">${this.escapeHtml(log.ip_address || '')}</div>
                </div>
            `;
        });

        container.innerHTML = html;

        // 更新分頁信息
        const pageInfoElement = document.getElementById('audit-page-info');
        const totalStatsElement = document.getElementById('audit-total-stats');
        const prevPageBtn = document.getElementById('audit-prev-page');
        const nextPageBtn = document.getElementById('audit-next-page');

        if (pageInfoElement) {
            pageInfoElement.textContent = `第 ${pagination.current_page} 頁，共 ${pagination.total_pages} 頁`;
        }
        if (totalStatsElement) {
            totalStatsElement.textContent = `總計: ${pagination.total} 條記錄`;
        }
        if (prevPageBtn) {
            prevPageBtn.disabled = !pagination.has_prev;
        }
        if (nextPageBtn) {
            nextPageBtn.disabled = !pagination.has_next;
        }

        // 更新分頁事件監聽器（使用當前頁面）
        if (prevPageBtn) {
            prevPageBtn.onclick = () => this.changeAuditPage(-1);
        }
        if (nextPageBtn) {
            nextPageBtn.onclick = () => this.changeAuditPage(1);
        }
    }

    renderInventorySummary(data) {
        console.log('Inventory summary data:', data);
        const container = document.getElementById('inventory-summary');
        if (!container) return;

        const summary = data.summary || {};
        const recentChanges = data.recent_changes || [];
        const topChangedProducts = data.top_changed_products || [];

        // 格式化數字
        const formatNumber = (num) => {
            if (num === null || num === undefined) return '0';
            return new Intl.NumberFormat('zh-TW').format(num);
        };
        const formatCurrency = (num) => {
            if (num === null || num === undefined) return '$0';
            return '$' + new Intl.NumberFormat('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(num);
        };

        // 構建摘要卡片
        let html = `
            <div class="inventory-stats-grid">
                <div class="stat-card">
                    <div class="stat-label">總商品數</div>
                    <div class="stat-value">${formatNumber(summary.total_products)}</div>
                </div>
                <div class="stat-card out-of-stock">
                    <div class="stat-label">缺貨商品</div>
                    <div class="stat-value">${formatNumber(summary.out_of_stock)}</div>
                </div>
                <div class="stat-card low-stock">
                    <div class="stat-label">低庫存商品</div>
                    <div class="stat-value">${formatNumber(summary.low_stock)}</div>
                </div>
                <div class="stat-card normal-stock">
                    <div class="stat-label">正常庫存</div>
                    <div class="stat-value">${formatNumber(summary.normal_stock)}</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">總庫存量</div>
                    <div class="stat-value">${formatNumber(summary.total_stock_value)}</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">估計總價值</div>
                    <div class="stat-value">${formatCurrency(summary.estimated_value)}</div>
                </div>
            </div>
        `;

        // 添加最近7天變更趨勢
        if (recentChanges.length > 0) {
            html += `
                <div class="inventory-section">
                    <h3><i class="fas fa-chart-line"></i> 最近7天庫存變更趨勢</h3>
                    <div class="changes-table">
                        <div class="table-header">
                            <span>日期</span>
                            <span>變更類型</span>
                            <span>總變更量</span>
                        </div>
            `;

            recentChanges.forEach(change => {
                const changeTypeMap = {
                    'restock': '補貨',
                    'adjust_add': '增加',
                    'adjust_remove': '減少',
                    'sale': '銷售'
                };
                const changeTypeText = changeTypeMap[change.change_type] || change.change_type;
                const changeClass = change.change_type === 'restock' || change.change_type === 'adjust_add' ? 'positive' : 'negative';

                html += `
                    <div class="change-row">
                        <div class="change-date">${change.date}</div>
                        <div class="change-type">${changeTypeText}</div>
                        <div class="change-quantity ${changeClass}">${change.total_change > 0 ? '+' : ''}${formatNumber(change.total_change)}</div>
                    </div>
                `;
            });

            html += `</div></div>`;
        }

        // 添加最常變更的商品
        if (topChangedProducts.length > 0) {
            html += `
                <div class="inventory-section">
                    <h3><i class="fas fa-star"></i> 最常變更的商品（最近7天）</h3>
                    <div class="top-products-list">
            `;

            topChangedProducts.forEach((product, index) => {
                html += `
                    <div class="top-product-item">
                        <div class="product-rank">${index + 1}</div>
                        <div class="product-name">${this.escapeHtml(product.name)}</div>
                        <div class="product-stats">
                            <span class="stat-badge">變更次數: ${product.change_count}</span>
                            <span class="stat-badge">總變更量: ${formatNumber(product.total_quantity_changed)}</span>
                        </div>
                    </div>
                `;
            });

            html += `</div></div>`;
        }

        container.innerHTML = html;
    }

    applyAuditFilters() {
        const actionType = document.getElementById('audit-action-filter').value;
        const startDate = document.getElementById('audit-start-date').value;
        const endDate = document.getElementById('audit-end-date').value;

        const filters = {
            action_type: actionType || '',
            start_date: startDate || '',
            end_date: endDate || ''
        };

        // 重置為第一頁並應用篩選器
        this.loadAuditLogs(1, filters);
    }

    changeAuditPage(delta) {
        const newPage = this.auditLogsPage + delta;
        if (newPage < 1) return;
        // 注意：我們不知道總頁數，但 loadAuditLogs 會處理超出範圍的情況
        this.auditLogsPage = newPage;
        this.loadAuditLogs(this.auditLogsPage, this.auditLogsFilters);
    }

    changeHistoricalPage(delta) {
        const newPage = this.historicalSalesPage + delta;
        if (newPage < 1) return;
        this.historicalSalesPage = newPage;
        this.loadHistoricalSales(this.historicalSalesPage, this.historicalSalesFilters);
    }

    applyHistoricalFilters() {
        const startDate = document.getElementById('historical-start-date').value;
        const endDate = document.getElementById('historical-end-date').value;
        const viewType = document.getElementById('historical-view-type').value;
        const storeFilter = document.getElementById('historical-store-filter').value;

        const filters = {};
        if (startDate) filters.start_date = startDate;
        if (endDate) filters.end_date = endDate;
        filters.view_type = viewType || 'summary';
        if (storeFilter) filters.store_id = storeFilter;

        // 重置為第一頁並應用篩選器
        this.loadHistoricalSales(1, filters);
    }

    async downloadHistoricalSalesCSV() {
        console.log('downloadHistoricalSalesCSV被調用，currentHistoricalSalesData:', this.currentHistoricalSalesData);
        // 顯示處理中訊息
        this.addMessage('正在生成CSV文件...', 'info');

        try {
            if (!this.currentHistoricalSalesData) {
                console.warn('沒有可下載的數據');
                this.addMessage('沒有可下載的數據', 'error');
                return;
            }

        const data = this.currentHistoricalSalesData;
        const viewType = data.view_type || 'summary';
        const sales = data.sales || [];
        const summary = data.summary || {};

        let csvContent = '';
        let filename = '';

        // 根據視圖類型生成CSV
        if (viewType === 'products') {
            // 商品詳情視圖
            filename = `商品銷售_${new Date().toISOString().slice(0,10)}.csv`;
            csvContent = '商品名稱,類別,單價,總銷量,總銷售額,購買客數,銷售天數\n';
            sales.forEach(product => {
                const row = [
                    `"${(product.name || '').replace(/"/g, '""')}"`,
                    `"${(product.category || '').replace(/"/g, '""')}"`,
                    `$${parseFloat(product.price || 0).toFixed(2)}`,
                    product.total_quantity || 0,
                    `$${parseFloat(product.total_revenue || 0).toFixed(2)}`,
                    product.customer_count || 0,
                    product.days_sold || 0
                ];
                csvContent += row.join(',') + '\n';
            });
        } else if (viewType === 'hourly_customers') {
            // 每小時客人統計視圖
            filename = `每小時客人統計_${new Date().toISOString().slice(0,10)}.csv`;
            csvContent = '日期,時段,客數,營業額,平均結賬\n';
            sales.forEach(record => {
                const totalRevenue = parseFloat(record.total_revenue || 0).toFixed(2);
                const avgCheckout = record.customer_count > 0 ? (parseFloat(record.total_revenue || 0) / record.customer_count).toFixed(2) : '0.00';
                const row = [
                    record.date || '--',
                    `${record.hour || '--'}:00`,
                    record.customer_count || 0,
                    `$${totalRevenue}`,
                    `$${avgCheckout}`
                ];
                csvContent += row.join(',') + '\n';
            });
        } else if (viewType === 'checkout_receipts') {
            // 結賬單據視圖
            filename = `結賬單據_${new Date().toISOString().slice(0,10)}.csv`;
            csvContent = '桌號,人數,入場時間,結賬時間,金額,狀態\n';
            sales.forEach(receipt => {
                const amount = receipt.is_reversed ? '0.00' : parseFloat(receipt.total_amount || 0).toFixed(2);
                const status = receipt.is_reversed ? '已反結賬' : '正常';
                const row = [
                    `"${(receipt.table_number || '--').replace(/"/g, '""')}"`,
                    receipt.is_reversed ? 0 : (receipt.people_count || 0),
                    `"${(receipt.entry_time || '--').replace(/"/g, '""')}"`,
                    `"${(receipt.checkout_time || '--').replace(/"/g, '""')}"`,
                    `$${amount}`,
                    status
                ];
                csvContent += row.join(',') + '\n';
            });
        } else {
            // 銷售總覽視圖（默認）
            filename = `銷售總覽_${new Date().toISOString().slice(0,10)}.csv`;
            csvContent = '日期,營業額,客數,平均結賬,離場數\n';
            sales.forEach(sale => {
                const revenue = parseFloat(sale.revenue || 0).toFixed(2);
                const avgCheckout = sale.customers > 0 ? (parseFloat(sale.revenue || 0) / sale.customers).toFixed(2) : '0.00';
                const row = [
                    sale.date || '--',
                    `$${revenue}`,
                    sale.customers || 0,
                    `$${avgCheckout}`,
                    sale.checkouts || 0
                ];
                csvContent += row.join(',') + '\n';
            });
        }

        // 觸發下載
        const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = filename;
        link.style.display = 'none';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(link.href);

            this.addMessage(`CSV文件已生成: ${filename}`, 'success');
        } catch (error) {
            console.error('CSV下載過程中發生錯誤:', error);
            this.addMessage(`CSV下載失敗: ${error.message}`, 'error');
        }
    }

    async viewLowStock() {
        // 切換到商品管理標籤頁
        this.switchTab('products');

        // 設置低庫存篩選器
        document.getElementById('product-stock-filter').value = 'low-stock';

        // 等待一下讓標籤頁切換完成，然後應用篩選器
        setTimeout(() => {
            this.applyProductFilters();
            this.addMessage('已篩選低庫存商品', 'info');
        }, 100);
    }

    async viewInventoryLogs() {
        try {
            const preview = document.getElementById('report-preview');
            if (preview) {
                preview.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> 正在載入庫存變更記錄...</div>';
            }

            const response = await this.fetchWithAuth('/api/inventory/logs?limit=10');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const result = await response.json();

            if (result.success) {
                this.displayInventoryLogs(result.data);
            } else {
                this.addMessage(`載入庫存記錄失敗: ${result.message}`, 'error');
                if (preview) preview.innerHTML = '<p class="error">載入庫存記錄時發生錯誤</p>';
            }
        } catch (error) {
            this.addMessage(`載入庫存記錄失敗: ${error.message}`, 'error');
            const preview = document.getElementById('report-preview');
            if (preview) preview.innerHTML = '<p class="error">無法載入庫存記錄</p>';
        }
    }

    async generateDailyReport() {
        try {
            const preview = document.getElementById('report-preview');
            if (preview) {
                preview.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> 正在生成日報表...</div>';
            }

            const response = await this.fetchWithAuth('/api/reports/daily');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const result = await response.json();

            if (result.success) {
                this.displayReport('日報表', result.data);
            } else {
                this.addMessage(`生成日報表失敗: ${result.message}`, 'error');
                if (preview) preview.innerHTML = '<p class="error">生成報告時發生錯誤</p>';
            }
        } catch (error) {
            this.addMessage(`生成日報表失敗: ${error.message}`, 'error');
            const preview = document.getElementById('report-preview');
            if (preview) preview.innerHTML = '<p class="error">無法載入報告數據</p>';
        }
    }

    async generateWeeklyReport() {
        try {
            const preview = document.getElementById('report-preview');
            if (preview) {
                preview.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> 正在生成週報表...</div>';
            }

            const response = await this.fetchWithAuth('/api/reports/weekly');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const result = await response.json();

            if (result.success) {
                this.displayReport('週報表', result.data);
            } else {
                this.addMessage(`生成週報表失敗: ${result.message}`, 'error');
                if (preview) preview.innerHTML = '<p class="error">生成報告時發生錯誤</p>';
            }
        } catch (error) {
            this.addMessage(`生成週報表失敗: ${error.message}`, 'error');
            const preview = document.getElementById('report-preview');
            if (preview) preview.innerHTML = '<p class="error">無法載入報告數據</p>';
        }
    }

    async generateMonthlyReport() {
        try {
            const preview = document.getElementById('report-preview');
            if (preview) {
                preview.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> 正在生成月報表...</div>';
            }

            const response = await this.fetchWithAuth('/api/reports/monthly');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const result = await response.json();

            if (result.success) {
                this.displayReport('月報表', result.data);
            } else {
                this.addMessage(`生成月報表失敗: ${result.message}`, 'error');
                if (preview) preview.innerHTML = '<p class="error">生成報告時發生錯誤</p>';
            }
        } catch (error) {
            this.addMessage(`生成月報表失敗: ${error.message}`, 'error');
            const preview = document.getElementById('report-preview');
            if (preview) preview.innerHTML = '<p class="error">無法載入報告數據</p>';
        }
    }

    renderHistoricalSales(data) {
        console.log('Historical sales data:', data);
        // 存儲當前數據供CSV下載使用
        this.currentHistoricalSalesData = data;

        const viewType = data.view_type || 'summary';
        const summary = data.summary || {};
        const sales = data.sales || [];
        const pagination = data.pagination || { current_page: 1, total_pages: 1, total: 0 };

        // 更新表格表頭
        this.updateHistoricalSalesTableHeader(viewType);

        // 更新統計摘要
        this.updateHistoricalSalesStats(viewType, summary);

        // 渲染銷售列表
        const container = document.getElementById('historical-sales-list');
        if (!container) return;

        if (sales.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-history"></i>
                    <p data-i18n="noHistoricalSalesFound">找不到歷史銷售記錄</p>
                </div>
            `;
            return;
        }

        // 根據視圖類型構建不同的表格內容
        let html = '';
        if (viewType === 'products') {
            // 商品詳情視圖
            sales.forEach(product => {
                const price = `$${parseFloat(product.price || 0).toLocaleString('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
                const totalRevenue = `$${parseFloat(product.total_revenue || 0).toLocaleString('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

                html += `
                    <div class="historical-sales-item">
                        <div class="historical-sales-product-name">${product.name || '--'}</div>
                        <div class="historical-sales-product-category">${product.category || '--'}</div>
                        <div class="historical-sales-product-price">${price}</div>
                        <div class="historical-sales-product-quantity">${product.total_quantity || 0}</div>
                        <div class="historical-sales-product-revenue">${totalRevenue}</div>
                        <div class="historical-sales-product-customers">${product.customer_count || 0}</div>
                        <div class="historical-sales-product-days">${product.days_sold || 0}</div>
                    </div>
                `;
            });
        } else if (viewType === 'checkout_receipts') {
            // 結賬單據視圖 - 格式與今日結賬詳細記錄一致
            sales.forEach(receipt => {
                const isReversed = receipt.is_reversed ? true : false;
                const displayAmount = isReversed ? '$0.00' : `$${parseFloat(receipt.total_amount || 0).toLocaleString('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
                const displayPeople = isReversed ? '0' : (receipt.people_count || 0);
                const entryTime = this.formatDateTime(receipt.entry_time);
                const checkoutTime = this.formatDateTime(receipt.checkout_time);
                const tableNumber = this.escapeHtml(receipt.table_number || '--');
                const products = this.escapeHtml(receipt.products || '');
                const lockers = this.escapeHtml(receipt.lockers || '');
                const reversedProducts = this.escapeHtml(receipt.reversed_products || '');
                const qrCode = this.escapeHtml(receipt.qr_code || receipt.id || '');
                const isMember = receipt.is_member ? '是' : '否';
                const reversedClass = isReversed ? ' historical-sales-reversed' : '';
                const reverseBtnHtml = isReversed
                    ? `<span class="reverse-checkout-badge" title="已由 ${this.escapeHtml(receipt.reverse_employee_name || '未知')} 反結賬">已反結賬</span>`
                    : `<button class="btn-small btn-danger reverse-checkout-btn"
                            data-receipt-id="${receipt.id}"
                            data-table-number="${tableNumber}"
                            data-total-amount="${receipt.total_amount}"
                            data-checkout-time="${receipt.checkout_time}">
                        <i class="fas fa-undo"></i> 反結賬
                    </button>`;

                html += `
                    <div class="historical-sales-item${reversedClass}">
                        <div class="historical-sales-today-table-number">${tableNumber}</div>
                        <div class="historical-sales-today-people-count">${displayPeople}</div>
                        <div class="historical-sales-today-entry-time">${entryTime}</div>
                        <div class="historical-sales-today-checkout-time">${checkoutTime}</div>
                        <div class="historical-sales-today-amount">${displayAmount}</div>
                        <div class="historical-sales-today-action">
                            <div class="historical-sales-action-group">
                                <button class="btn-small btn-details historical-checkout-detail-btn"
                                        data-table-number="${tableNumber}"
                                        data-member="${isMember}"
                                        data-qr-code="${qrCode}"
                                        data-products="${products}"
                                        data-reversed-products="${reversedProducts}"
                                        data-lockers="${lockers}"
                                        data-record-id="${receipt.id}"
                                        data-total-amount="${receipt.total_amount}"
                                        data-checkout-time="${receipt.checkout_time}"
                                        data-people-count="${receipt.people_count}"
                                        data-entry-time="${receipt.entry_time}"
                                        data-is-reversed="${isReversed ? '1' : '0'}"
                                        data-reverse-employee="${this.escapeHtml(receipt.reverse_employee_name || '')}">
                                    <i class="fas fa-info-circle"></i> 詳細
                                </button>
                                ${reverseBtnHtml}
                            </div>
                        </div>
                    </div>
                `;
            });
        } else if (viewType === 'hourly_customers') {
            // 每小時客人統計視圖
            sales.forEach(record => {
                const totalRevenue = `$${parseFloat(record.total_revenue || 0).toLocaleString('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
                const avgCheckout = `$${parseFloat(record.avg_checkout || 0).toLocaleString('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

                html += `
                    <div class="historical-sales-item">
                        <div class="historical-sales-date">${record.date || '--'}</div>
                        <div class="historical-sales-hour">${record.hour || '--'}:00</div>
                        <div class="historical-sales-customer-count">${record.customer_count || 0}</div>
                        <div class="historical-sales-hourly-revenue">${totalRevenue}</div>
                        <div class="historical-sales-hourly-avg-checkout">${avgCheckout}</div>
                    </div>
                `;
            });
        } else if (viewType === 'sensitive_operations') {
            // 敏感操作視圖 - 與敏感操作卡片顯示方式一致
            sales.forEach(op => {
                const time = this.formatDateTime(op.created_at);
                const action = this.escapeHtml(op.action_display);
                let operator = '系統';
                if (op.employee_username) {
                    operator = this.escapeHtml(op.employee_username);
                } else if (op.employee_name) {
                    operator = this.escapeHtml(op.employee_name);
                }

                const btnData = {
                    operationId: op.id,
                    actionType: op.action_type,
                    actionDisplay: op.action_display,
                    createdAt: op.created_at,
                    employeeName: op.employee_name || '',
                    employeeUsername: op.employee_username || '',
                    ipAddress: op.ip_address || '',
                    details: op.details || {}
                };
                const btnDataAttr = JSON.stringify(btnData).replace(/'/g, "&#39;");

                html += `
                    <div class="historical-sales-item">
                        <div class="historical-sales-sensitive-time">${time}</div>
                        <div class="historical-sales-sensitive-action">${action}</div>
                        <div class="historical-sales-sensitive-operator">${operator}</div>
                        <div class="historical-sales-sensitive-action-cell">
                            <button class="btn-small btn-details historical-sensitive-detail-btn" data-sensitive-data='${btnDataAttr}'>
                                <i class="fas fa-info-circle"></i> 詳細
                            </button>
                        </div>
                    </div>
                `;
            });
        } else if (viewType === 'sensitive_operations_summary') {
            // 敏感操作總結視圖 - 按分店匯總
            sales.forEach(store => {
                const totalAmount = `$${parseFloat(store.total_amount || 0).toLocaleString('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
                const storeName = this.escapeHtml(store.store_name || '未知分店');

                html += `
                    <div class="historical-sales-item">
                        <div class="historical-sales-summary-store">${storeName}</div>
                        <div class="historical-sales-summary-amount">${totalAmount}</div>
                        <div class="historical-sales-summary-count">${store.total_count || 0}</div>
                    </div>
                `;
            });
        } else {
            // 銷售總覽視圖（默認）
            sales.forEach(sale => {
                // 格式化日期
                const saleDate = new Date(sale.date).toLocaleDateString('zh-TW');

                // 格式化金額
                const revenue = `$${parseFloat(sale.revenue || 0).toLocaleString('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
                const avgCheckout = `$${parseFloat(sale.avg_checkout || 0).toLocaleString('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

                html += `
                    <div class="historical-sales-item">
                        <div class="historical-sales-date">${saleDate}</div>
                        <div class="historical-sales-revenue">${revenue}</div>
                        <div class="historical-sales-customers">${sale.customers || 0}</div>
                        <div class="historical-sales-avg-checkout">${avgCheckout}</div>
                        <div class="historical-sales-checkouts">${sale.checkouts || 0}</div>
                    </div>
                `;
            });
        }

        container.innerHTML = html;

        // 更新歷史銷售項目的網格列樣式
        this.updateHistoricalSalesGridColumns(viewType);

        // 更新分頁信息
        const pageInfoElement = document.getElementById('historical-page-info');
        const totalStatsElement = document.getElementById('historical-total-stats');
        const prevPageBtn = document.getElementById('historical-prev-page');
        const nextPageBtn = document.getElementById('historical-next-page');
        const paginationContainer = document.getElementById('historical-pagination');

        // 隱藏分頁控制項如果只有一頁
        if (paginationContainer) {
            paginationContainer.style.display = pagination.total_pages <= 1 ? 'none' : 'flex';
        }

        if (pageInfoElement) {
            pageInfoElement.textContent = `第 ${pagination.current_page} 頁，共 ${pagination.total_pages} 頁`;
        }
        if (totalStatsElement) {
            totalStatsElement.textContent = `總計: ${pagination.total} 筆記錄`;
        }
        if (prevPageBtn) {
            prevPageBtn.disabled = !pagination.has_prev;
            prevPageBtn.onclick = () => this.changeHistoricalPage(-1);
        }
        if (nextPageBtn) {
            nextPageBtn.disabled = !pagination.has_next;
            nextPageBtn.onclick = () => this.changeHistoricalPage(1);
        }
    }

    // 更新歷史銷售表格表頭
    updateHistoricalSalesTableHeader(viewType) {
        const tableHeader = document.querySelector('.historical-sales-table-container .table-header');
        const container = document.querySelector('.historical-sales-table-container');
        if (!tableHeader || !container) return;

        let headerHTML = '';
        let gridTemplateColumns = '';

        if (viewType === 'products') {
            headerHTML = `
                <span>商品名稱</span>
                <span>類別</span>
                <span>單價</span>
                <span>總銷量</span>
                <span>總銷售額</span>
                <span>購買客數</span>
                <span>銷售天數</span>
            `;
            gridTemplateColumns = '2fr 1fr 1fr 1fr 1fr 1fr 1fr';
        } else if (viewType === 'hourly_customers') {
            headerHTML = `
                <span>日期</span>
                <span>小時</span>
                <span>結賬客人數</span>
                <span>營業額</span>
                <span>平均結賬</span>
            `;
            gridTemplateColumns = '1.5fr 0.8fr 1fr 1fr 1fr';
        } else if (viewType === 'checkout_receipts') {
            headerHTML = `
                <span>桌號</span>
                <span>人數</span>
                <span>入場時間</span>
                <span>結賬時間</span>
                <span>總金額</span>
                <span>詳細</span>
            `;
            gridTemplateColumns = '0.8fr 0.8fr 1.5fr 1.5fr 1fr 0.8fr';
        } else if (viewType === 'sensitive_operations') {
            headerHTML = `
                <span>時間</span>
                <span>動作</span>
                <span>操作員</span>
                <span>詳細</span>
            `;
            gridTemplateColumns = '1.5fr 0.8fr 1fr 0.8fr';
        } else if (viewType === 'sensitive_operations_summary') {
            headerHTML = `
                <span>所屬分店</span>
                <span>總金額</span>
                <span>次數</span>
            `;
            gridTemplateColumns = '2fr 1fr 0.8fr';
        } else {
            // 銷售總覽視圖（默認）
            headerHTML = `
                <span>日期</span>
                <span>營業額</span>
                <span>客數</span>
                <span>平均結賬</span>
                <span>離場數</span>
            `;
            gridTemplateColumns = '1.5fr 1fr 1fr 1fr 1fr';
        }

        tableHeader.innerHTML = headerHTML;
        tableHeader.style.gridTemplateColumns = gridTemplateColumns;

        // 設置容器的data-view-type屬性，以便CSS選擇器生效
        container.setAttribute('data-view-type', viewType);

        // 同時更新歷史銷售項目的網格列
        const historicalSalesItems = document.querySelectorAll('.historical-sales-item');
        historicalSalesItems.forEach(item => {
            item.style.gridTemplateColumns = gridTemplateColumns;
        });
    }

    // 更新歷史銷售項目的網格列樣式
    updateHistoricalSalesGridColumns(viewType) {
        // 現在CSS通過data-view-type屬性自動處理網格列樣式
        const container = document.querySelector('.historical-sales-table-container');
        if (container) {
            container.setAttribute('data-view-type', viewType);
        }

        // 為了向後兼容，也直接設置樣式
        let gridTemplateColumns = '';
        if (viewType === 'products') {
            gridTemplateColumns = '2fr 1fr 1fr 1fr 1fr 1fr 1fr';
        } else if (viewType === 'hourly_customers') {
            gridTemplateColumns = '1.5fr 0.8fr 1fr 1fr 1fr';
        } else if (viewType === 'checkout_receipts') {
            gridTemplateColumns = '0.8fr 0.8fr 1.5fr 1.5fr 1fr 0.8fr';
        } else if (viewType === 'sensitive_operations') {
            gridTemplateColumns = '1.5fr 0.8fr 1fr 0.8fr';
        } else if (viewType === 'sensitive_operations_summary') {
            gridTemplateColumns = '2fr 1fr 0.8fr';
        } else {
            gridTemplateColumns = '1.5fr 1fr 1fr 1fr 1fr';
        }

        const historicalSalesItems = document.querySelectorAll('.historical-sales-item');
        historicalSalesItems.forEach(item => {
            item.style.gridTemplateColumns = gridTemplateColumns;
        });
    }

    // 加載分店列表用於歷史銷售篩選器
    async loadStoresForHistoricalFilter() {
        try {
            const response = await this.fetchWithAuth('/api/stores');
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            if (!result.success) {
                throw new Error(result.message || '獲取分店列表失敗');
            }

            const stores = result.data || [];
            console.log(`載入 ${stores.length} 個分店用於歷史銷售篩選`);

            // 更新歷史銷售分店篩選器
            const storeSelect = document.getElementById('historical-store-filter');
            if (!storeSelect) return;

            // 保存當前選擇的值
            const currentValue = storeSelect.value;

            // 清空選項（保留"全部分店"選項）
            storeSelect.innerHTML = '<option value="">全部分店</option>';

            // 添加分店選項
            stores.forEach(store => {
                const option = document.createElement('option');
                option.value = store.id;
                option.textContent = `${store.store_name} (${store.store_code})`;
                storeSelect.appendChild(option);
            });

            // 恢復之前選擇的值（如果存在）
            if (currentValue) {
                storeSelect.value = currentValue;
            }

            return stores;
        } catch (error) {
            console.error('載入分店列表錯誤:', error);
            // 不阻止歷史銷售功能繼續運行
            return [];
        }
    }

    // 更新歷史銷售統計摘要
    updateHistoricalSalesStats(viewType, summary) {
        // 顯示/隱藏統計區域（僅銷售總覽顯示）
        const statsContainer = document.querySelector('.historical-sales-stats');
        if (statsContainer) {
            if (viewType === 'summary' || viewType === 'checkout_receipts' || viewType === 'sensitive_operations_summary') {
                statsContainer.style.display = '';
                statsContainer.classList.remove('hidden');
            } else {
                statsContainer.style.display = 'none';
                statsContainer.classList.add('hidden');
            }
        }

        // 獲取統計元素
        const revenueElement = document.getElementById('historical-revenue');
        const customersElement = document.getElementById('historical-customers');
        const avgCheckoutElement = document.getElementById('historical-avg-checkout');
        const checkoutsElement = document.getElementById('historical-checkouts');

        // 獲取統計標籤元素
        const revenueLabel = revenueElement?.closest('.stat-item')?.querySelector('.stat-label');
        const customersLabel = customersElement?.closest('.stat-item')?.querySelector('.stat-label');
        const avgCheckoutLabel = avgCheckoutElement?.closest('.stat-item')?.querySelector('.stat-label');
        const checkoutsLabel = checkoutsElement?.closest('.stat-item')?.querySelector('.stat-label');

        if (viewType === 'products') {
            // 商品詳情視圖統計
            if (revenueElement) revenueElement.textContent = `$${parseFloat(summary.total_revenue || 0).toLocaleString('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
            if (revenueLabel) revenueLabel.textContent = '總銷售額';

            if (customersElement) customersElement.textContent = (summary.total_quantity || 0).toLocaleString('zh-TW');
            if (customersLabel) customersLabel.textContent = '總銷量';

            if (avgCheckoutElement) avgCheckoutElement.textContent = (summary.total_products || 0).toLocaleString('zh-TW');
            if (avgCheckoutLabel) avgCheckoutLabel.textContent = '商品數';

            // 隱藏離場數統計（不適用）
            if (checkoutsElement) checkoutsElement.textContent = '--';
            if (checkoutsLabel) checkoutsLabel.textContent = '--';
        } else if (viewType === 'hourly_customers') {
            // 每小時客人統計視圖
            if (revenueElement) revenueElement.textContent = `$${parseFloat(summary.total_revenue || 0).toLocaleString('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
            if (revenueLabel) revenueLabel.textContent = '總營業額';

            if (customersElement) customersElement.textContent = (summary.total_customers || 0).toLocaleString('zh-TW');
            if (customersLabel) customersLabel.textContent = '總客數';

            // 計算平均每小時客人數
            const avgCustomersPerHour = summary.hour_count > 0 ? (summary.total_customers || 0) / summary.hour_count : 0;
            if (avgCheckoutElement) avgCheckoutElement.textContent = avgCustomersPerHour.toLocaleString('zh-TW', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
            if (avgCheckoutLabel) avgCheckoutLabel.textContent = '平均每小時客數';

            if (checkoutsElement) checkoutsElement.textContent = (summary.hour_count || 0).toLocaleString('zh-TW');
            if (checkoutsLabel) checkoutsLabel.textContent = '總時段數';
        } else if (viewType === 'checkout_receipts') {
            // 結賬單據視圖
            if (revenueElement) revenueElement.textContent = `$${parseFloat(summary.total_revenue || 0).toLocaleString('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
            if (revenueLabel) revenueLabel.textContent = '總營業額';

            if (customersElement) customersElement.textContent = (summary.total_checkouts || 0).toLocaleString('zh-TW');
            if (customersLabel) customersLabel.textContent = '總單據數';

            if (avgCheckoutElement) avgCheckoutElement.textContent = (summary.total_people || 0).toLocaleString('zh-TW');
            if (avgCheckoutLabel) avgCheckoutLabel.textContent = '總人數';

            if (checkoutsElement) checkoutsElement.textContent = summary.total_checkouts > 0
                ? `$${parseFloat((summary.total_revenue || 0) / summary.total_checkouts).toLocaleString('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                : '$0';
            if (checkoutsLabel) checkoutsLabel.textContent = '均消';
        } else if (viewType === 'sensitive_operations_summary') {
            // 敏感操作總結視圖
            if (revenueElement) revenueElement.textContent = `$${parseFloat(summary.total_amount || 0).toLocaleString('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
            if (revenueLabel) revenueLabel.textContent = '總金額';

            if (customersElement) customersElement.textContent = (summary.total_count || 0).toLocaleString('zh-TW');
            if (customersLabel) customersLabel.textContent = '總次數';

            if (avgCheckoutElement) avgCheckoutElement.textContent = '--';
            if (avgCheckoutLabel) avgCheckoutLabel.textContent = '--';

            if (checkoutsElement) checkoutsElement.textContent = '--';
            if (checkoutsLabel) checkoutsLabel.textContent = '--';
        } else {
            // 銷售總覽視圖（默認）
            if (revenueElement) revenueElement.textContent = `$${parseFloat(summary.total_revenue || 0).toLocaleString('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
            if (revenueLabel) revenueLabel.textContent = '總營業額';

            if (customersElement) customersElement.textContent = (summary.total_customers || 0).toLocaleString('zh-TW');
            if (customersLabel) customersLabel.textContent = '總客數';

            if (avgCheckoutElement) avgCheckoutElement.textContent = `$${parseFloat(summary.avg_checkout || 0).toLocaleString('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
            if (avgCheckoutLabel) avgCheckoutLabel.textContent = '平均結賬';

            if (checkoutsElement) checkoutsElement.textContent = (summary.total_checkouts || 0).toLocaleString('zh-TW');
            if (checkoutsLabel) checkoutsLabel.textContent = '總離場數';
        }
    }

    displayReport(title, data) {
        const preview = document.getElementById('report-preview');
        if (!preview) return;

        const report = data.report || data;
        const period = data.period || {};
        const summary = report.summary || {};
        const details = report.details || [];

        // 格式化數字
        const formatNumber = (num) => {
            if (num === null || num === undefined) return '0';
            return new Intl.NumberFormat('zh-TW').format(num);
        };
        const formatCurrency = (num) => {
            if (num === null || num === undefined) return '$0';
            return '$' + new Intl.NumberFormat('zh-TW', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(num);
        };

        let html = `
            <div class="report-header">
                <h3><i class="fas fa-chart-bar"></i> ${title}</h3>
                <div class="report-period">
                    ${period.start_date ? `開始日期: ${period.start_date}` : ''}
                    ${period.end_date ? ` - 結束日期: ${period.end_date}` : ''}
                    ${!period.start_date && !period.end_date ? '最近期間' : ''}
                </div>
            </div>
        `;

        // 摘要統計
        if (summary.total_customers || summary.total_revenue || summary.total_orders) {
            html += `
                <div class="report-summary">
                    <h4><i class="fas fa-chart-pie"></i> 摘要統計</h4>
                    <div class="summary-stats">
                        <div class="summary-card">
                            <div class="summary-label">總客人數</div>
                            <div class="summary-value">${formatNumber(summary.total_customers)}</div>
                        </div>
                        <div class="summary-card">
                            <div class="summary-label">總營業額</div>
                            <div class="summary-value">${formatCurrency(summary.total_revenue)}</div>
                        </div>
                        <div class="summary-card">
                            <div class="summary-label">總訂單數</div>
                            <div class="summary-value">${formatNumber(summary.total_orders)}</div>
                        </div>
                        <div class="summary-card">
                            <div class="summary-label">平均消費</div>
                            <div class="summary-value">${formatCurrency(summary.average_spending)}</div>
                        </div>
                    </div>
                </div>
            `;
        }

        // 詳細資料表格
        if (details.length > 0) {
            html += `
                <div class="report-details">
                    <h4><i class="fas fa-table"></i> 詳細資料</h4>
                    <div class="details-table">
                        <div class="table-header">
                            <span>項目</span>
                            <span>數值</span>
                            <span>百分比</span>
                        </div>
            `;

            details.forEach(item => {
                html += `
                    <div class="detail-row">
                        <div class="detail-item">${this.escapeHtml(item.label)}</div>
                        <div class="detail-value">${item.value ? formatNumber(item.value) : ''}</div>
                        <div class="detail-percentage">${item.percentage ? item.percentage.toFixed(1) + '%' : ''}</div>
                    </div>
                `;
            });

            html += `</div></div>`;
        }

        // 時間戳記
        html += `
            <div class="report-footer">
                <small>報告生成時間: ${new Date().toLocaleString('zh-TW')}</small>
            </div>
        `;

        preview.innerHTML = html;
    }

    displayInventoryLogs(data) {
        const preview = document.getElementById('report-preview');
        if (!preview) return;

        const logs = data.logs || [];
        const pagination = data.pagination || { total: 0 };

        let html = `
            <div class="report-header">
                <h3><i class="fas fa-history"></i> 庫存變更記錄</h3>
                <div class="report-period">
                    總計 ${pagination.total} 條記錄
                </div>
            </div>
        `;

        if (logs.length === 0) {
            html += `<div class="empty-state"><p>沒有找到庫存變更記錄</p></div>`;
            preview.innerHTML = html;
            return;
        }

        html += `
            <div class="inventory-logs-table">
                <div class="table-header">
                    <span>時間</span>
                    <span>商品</span>
                    <span>操作類型</span>
                    <span>變更數量</span>
                    <span>員工</span>
                    <span>原因</span>
                </div>
        `;

        logs.forEach(log => {
            const logTime = new Date(log.created_at).toLocaleString('zh-TW');
            const changeTypeMap = {
                'restock': '補貨',
                'adjust_add': '增加',
                'adjust_remove': '減少',
                'sale': '銷售'
            };
            const changeTypeText = changeTypeMap[log.change_type] || log.change_type;
            const changeClass = log.change_type === 'restock' || log.change_type === 'adjust_add' ? 'positive' : 'negative';

            html += `
                <div class="log-row">
                    <div class="log-time">${logTime}</div>
                    <div class="log-product">${this.escapeHtml(log.product_name || '未知商品')}</div>
                    <div class="log-type">
                        <span class="change-badge ${changeClass}">${changeTypeText}</span>
                    </div>
                    <div class="log-quantity ${changeClass}">${log.quantity_change > 0 ? '+' : ''}${log.quantity_change}</div>
                    <div class="log-employee">${this.escapeHtml(log.employee_name || log.employee_username || '系統')}</div>
                    <div class="log-reason" title="${this.escapeHtml(log.reason || '')}">${this.escapeHtml(log.reason || '無')}</div>
                </div>
            `;
        });

        html += `</div>`;

        preview.innerHTML = html;
    }

    async loadSettingsTab() {
        // 帳戶設置標籤內容
        if (!this.isAuthenticated) {
            this.addMessage('請先登入以查看帳戶設置', 'warning');
            return;
        }

        // 清除任何現有的消息
        this.clearMessages();

        // 從本地存儲加載當前設置
        const savedShowMockData = localStorage.getItem('cashier_showMockData');
        const savedAlwaysShowMockData = localStorage.getItem('cashier_alwaysShowMockData');
        this.showMockData = savedShowMockData !== null ? savedShowMockData === 'true' : false;
        this.alwaysShowMockData = savedAlwaysShowMockData !== null ? savedAlwaysShowMockData === 'true' : false;

        // 創建設置界面
        const settingsHtml = `
            <div class="settings-container">
                <div class="settings-holiday-layout">
                    <div class="left-panel">
                        <div class="card">
                            <h2><i class="fas fa-user-cog"></i> 帳戶設置</h2>

                            <div class="settings-section">
                                <h3><i class="fas fa-user"></i> 個人資料</h3>
                                <p>當前登入員工: <strong>${this.currentEmployee ? this.currentEmployee.full_name : '未登入'}</strong></p>
                                <p>角色: <strong>${this.currentEmployee ? this.currentEmployee.role : '未登入'}</strong></p>
                                <button class="btn-secondary" id="change-password-btn">
                                    <i class="fas fa-key"></i> 修改密碼
                                </button>
                                <button class="btn-secondary" id="logout-settings-btn">
                                    <i class="fas fa-sign-out-alt"></i> 登出
                                </button>
                            </div>

                            <div class="settings-section">
                                <h3><i class="fas fa-database"></i> 模擬數據設置</h3>
                                <div class="setting-item">
                                    <div class="setting-info">
                                        <label for="show-mock-data-toggle">顯示模擬桌號數據</label>
                                        <p class="setting-description">在桌號管理中顯示模擬桌號數據（用於測試和演示）</p>
                                    </div>
                                    <div class="toggle-switch">
                                        <input type="checkbox" id="show-mock-data-toggle" class="toggle-checkbox" ${this.showMockData ? 'checked' : ''}>
                                        <label for="show-mock-data-toggle" class="toggle-label"></label>
                                    </div>
                                </div>

                                <div class="setting-item">
                                    <div class="setting-info">
                                        <label for="always-show-mock-data-toggle">總是顯示模擬數據</label>
                                        <p class="setting-description">即使有真實數據，也總是顯示模擬桌號數據（優先顯示模擬數據）</p>
                                    </div>
                                    <div class="toggle-switch">
                                        <input type="checkbox" id="always-show-mock-data-toggle" class="toggle-checkbox" ${this.alwaysShowMockData ? 'checked' : ''}>
                                        <label for="always-show-mock-data-toggle" class="toggle-label"></label>
                                    </div>
                                </div>

                                <div class="setting-actions">
                                    <button class="btn-primary" id="save-settings-btn">
                                        <i class="fas fa-save"></i> 保存設置
                                    </button>
                                    <button class="btn-secondary" id="refresh-data-btn">
                                        <i class="fas fa-sync"></i> 刷新數據
                                    </button>
                                </div>
                            </div>

                            <div class="settings-section">
                                <h3><i class="fas fa-info-circle"></i> 系統信息</h3>
                                <div class="system-info">
                                    <p>收銀系統版本: <strong>1.0.0</strong></p>
                                    <p>最後更新: <strong>2026-03-26</strong></p>
                                    <p>服務器狀態: <span id="server-status-indicator" class="status-indicator online"><i class="fas fa-circle"></i> 在線</span></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="right-panel">
                        <div class="card">
                            <h2><i class="fas fa-calendar-alt"></i> 節假日管理</h2>
                            <div class="holiday-management">
                                <div class="holiday-filters">
                                    <div class="filter-group">
                                        <label for="holiday-year-filter">年份:</label>
                                        <select id="holiday-year-filter" class="filter-select">
                                            <option value="">全部年份</option>
                                        </select>
                                    </div>
                                    <div class="filter-group">
                                        <label for="holiday-month-filter">月份:</label>
                                        <select id="holiday-month-filter" class="filter-select">
                                            <option value="">全部月份</option>
                                            <option value="01">一月</option>
                                            <option value="02">二月</option>
                                            <option value="03">三月</option>
                                            <option value="04">四月</option>
                                            <option value="05">五月</option>
                                            <option value="06">六月</option>
                                            <option value="07">七月</option>
                                            <option value="08">八月</option>
                                            <option value="09">九月</option>
                                            <option value="10">十月</option>
                                            <option value="11">十一月</option>
                                            <option value="12">十二月</option>
                                        </select>
                                    </div>
                                    <button class="btn-secondary" id="refresh-holidays-btn">
                                        <i class="fas fa-sync"></i> 刷新
                                    </button>
                                    <button class="btn-primary" id="add-holiday-btn">
                                        <i class="fas fa-plus"></i> 新增節假日
                                    </button>
                                </div>

                                <div class="holiday-table-container">
                                    <table class="holiday-table">
                                        <thead>
                                            <tr>
                                                <th>日期</th>
                                                <th>描述</th>
                                                <th>創建者</th>
                                                <th>創建時間</th>
                                                <th>操作</th>
                                            </tr>
                                        </thead>
                                        <tbody id="holiday-table-body">
                                            <tr>
                                                <td colspan="5" class="empty-table-message">載入中...</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // 插入到設置標籤容器
        const settingsTab = document.getElementById('tab-settings');
        if (settingsTab) {
            settingsTab.innerHTML = settingsHtml;

            // 綁定事件
            this.bindSettingsEvents();
            // 載入節假日數據
            this.loadHolidays();
        } else {
            console.error('設置標籤容器未找到');
            this.addMessage('設置標籤加載失敗', 'error');
        }
    }

    async loadHolidays() {
        try {
            if (!this.isAuthenticated) {
                console.warn('未登入，無法載入節假日');
                return;
            }

            const params = new URLSearchParams();
            if (this.holidaysYearFilter) {
                params.append('year', this.holidaysYearFilter);
            }
            if (this.holidaysMonthFilter) {
                params.append('month', this.holidaysMonthFilter);
            }

            const response = await fetch(`/api/holidays?${params.toString()}`, {
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            this.holidaysList = result.data?.holidays || [];
            this.renderHolidaysTable();

            // 更新年份過濾器選項
            this.updateYearFilterOptions();

        } catch (error) {
            console.error('載入節假日失敗:', error);
            this.addMessage(`載入節假日失敗: ${error.message}`, 'error');
            this.showHolidayTableError();
        }
    }

    renderHolidaysTable() {
        const tableBody = document.getElementById('holiday-table-body');
        if (!tableBody) return;

        if (this.holidaysList.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="5" class="empty-table-message">暫無節假日資料</td>
                </tr>
            `;
            return;
        }

        let html = '';
        this.holidaysList.forEach(holiday => {
            const createdAt = holiday.created_at ? new Date(holiday.created_at).toLocaleString('zh-TW') : '';
            html += `
                <tr data-holiday-id="${holiday.id}">
                    <td>${holiday.date}</td>
                    <td>${holiday.description || ''}</td>
                    <td>${holiday.created_by_name || ''}</td>
                    <td>${createdAt}</td>
                    <td class="holiday-actions">
                        <button class="btn-small btn-edit" data-action="edit-holiday" data-holiday-id="${holiday.id}">
                            <i class="fas fa-edit"></i> 編輯
                        </button>
                        <button class="btn-small btn-danger" data-action="delete-holiday" data-holiday-id="${holiday.id}">
                            <i class="fas fa-trash"></i> 刪除
                        </button>
                    </td>
                </tr>
            `;
        });

        tableBody.innerHTML = html;
    }

    showHolidayTableError() {
        const tableBody = document.getElementById('holiday-table-body');
        if (tableBody) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="5" class="error-table-message">
                        <i class="fas fa-exclamation-triangle"></i>
                        載入節假日失敗，請稍後再試
                    </td>
                </tr>
            `;
        }
    }

    updateYearFilterOptions() {
        const yearSelect = document.getElementById('holiday-year-filter');
        if (!yearSelect) return;

        // 保存當前選中值
        const currentValue = yearSelect.value;

        // 獲取所有節假日的年份
        const years = new Set();
        this.holidaysList.forEach(holiday => {
            if (holiday.date) {
                const year = holiday.date.substring(0, 4);
                years.add(year);
            }
        });

        // 添加當前年份和未來幾年
        const currentYear = new Date().getFullYear();
        for (let i = currentYear - 5; i <= currentYear + 5; i++) {
            years.add(i.toString());
        }

        // 排序年份（降序）
        const sortedYears = Array.from(years).sort((a, b) => parseInt(b) - parseInt(a));

        // 更新選項
        yearSelect.innerHTML = '<option value="">全部年份</option>';
        sortedYears.forEach(year => {
            const option = document.createElement('option');
            option.value = year;
            option.textContent = year;
            yearSelect.appendChild(option);
        });

        // 恢復選中值
        yearSelect.value = currentValue;
    }

    bindHolidayEvents() {
        // 年份過濾器
        const yearFilter = document.getElementById('holiday-year-filter');
        if (yearFilter) {
            yearFilter.addEventListener('change', (e) => {
                this.holidaysYearFilter = e.target.value;
                this.loadHolidays();
            });
        }

        // 月份過濾器
        const monthFilter = document.getElementById('holiday-month-filter');
        if (monthFilter) {
            monthFilter.addEventListener('change', (e) => {
                this.holidaysMonthFilter = e.target.value;
                this.loadHolidays();
            });
        }

        // 刷新按鈕
        const refreshBtn = document.getElementById('refresh-holidays-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                this.loadHolidays();
            });
        }

        // 新增節假日按鈕
        const addBtn = document.getElementById('add-holiday-btn');
        if (addBtn) {
            addBtn.addEventListener('click', () => {
                this.openHolidayForm();
            });
        }

        // 表格操作事件委託
        const tableBody = document.getElementById('holiday-table-body');
        console.log('綁定節假日表格事件，tableBody:', tableBody);
        if (tableBody) {
            tableBody.addEventListener('click', (e) => {
                console.log('節假日表格點擊事件:', e.target);
                const button = e.target.closest('button');
                if (!button) {
                    console.log('點擊的不是按鈕');
                    return;
                }

                console.log('找到按鈕:', button);
                const action = button.dataset.action;
                const holidayId = button.dataset.holidayId;
                console.log('按鈕數據 - action:', action, 'holidayId:', holidayId);

                if (action === 'edit-holiday') {
                    console.log('觸發編輯操作');
                    this.editHoliday(holidayId);
                } else if (action === 'delete-holiday') {
                    console.log('觸發刪除操作');
                    this.deleteHoliday(holidayId);
                }
            });
            console.log('節假日表格事件監聽器已綁定');
        } else {
            console.error('未找到holiday-table-body元素');
        }
    }

    openHolidayForm(holiday = null) {
        // 創建簡單的對話框來輸入日期範圍
        const isEdit = !!holiday;

        // 對於編輯，顯示當前值；對於新增，使用空值
        const startDate = holiday ? holiday.date : '';
        const endDate = holiday ? holiday.date : '';
        const description = holiday ? holiday.description : '';

        // 構建對話框HTML
        const dialogHtml = `
            <div class="modal" id="holiday-modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3><i class="fas fa-calendar-alt"></i> ${isEdit ? '編輯節假日' : '新增節假日'}</h3>
                        <button class="modal-close" id="holiday-modal-close">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="holiday-start-date">開始日期:</label>
                            <input type="date" id="holiday-start-date" value="${startDate}" required>
                        </div>
                        <div class="form-group">
                            <label for="holiday-end-date">結束日期:</label>
                            <input type="date" id="holiday-end-date" value="${endDate}" required>
                            <small class="form-hint">如果只有一天，請輸入與開始日期相同的日期</small>
                        </div>
                        <div class="form-group">
                            <label for="holiday-description">描述 (可選):</label>
                            <input type="text" id="holiday-description" value="${description}" placeholder="節假日描述">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn-secondary" id="holiday-modal-cancel">取消</button>
                        <button class="btn-primary" id="holiday-modal-save">保存</button>
                    </div>
                </div>
            </div>
        `;

        // 移除現有的模態對話框（如果存在）
        const existingModal = document.getElementById('holiday-modal');
        if (existingModal) {
            existingModal.remove();
        }

        // 添加對話框到文檔
        document.body.insertAdjacentHTML('beforeend', dialogHtml);

        // 綁定事件
        const modal = document.getElementById('holiday-modal');
        const closeBtn = document.getElementById('holiday-modal-close');
        const cancelBtn = document.getElementById('holiday-modal-cancel');
        const saveBtn = document.getElementById('holiday-modal-save');
        const startDateInput = document.getElementById('holiday-start-date');
        const endDateInput = document.getElementById('holiday-end-date');
        const descInput = document.getElementById('holiday-description');

        const closeModal = () => {
            if (modal) {
                modal.remove();
            }
        };

        if (closeBtn) closeBtn.addEventListener('click', closeModal);
        if (cancelBtn) cancelBtn.addEventListener('click', closeModal);

        if (saveBtn) {
            saveBtn.addEventListener('click', () => {
                const startDateVal = startDateInput.value;
                const endDateVal = endDateInput.value;
                const descriptionVal = descInput.value || null;

                // 驗證日期
                if (!startDateVal || !endDateVal) {
                    alert('請輸入開始日期和結束日期');
                    return;
                }

                // 驗證日期格式
                const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
                if (!dateRegex.test(startDateVal) || !dateRegex.test(endDateVal)) {
                    alert('日期格式必須為YYYY-MM-DD');
                    return;
                }

                // 驗證開始日期 <= 結束日期
                if (startDateVal > endDateVal) {
                    alert('開始日期不能晚於結束日期');
                    return;
                }

                // 計算日期範圍內的所有日期
                const dateRange = this.getDateRange(startDateVal, endDateVal);

                // 關閉對話框
                closeModal();

                // 保存節假日（每個日期單獨保存）
                if (isEdit && holiday) {
                    // 對於編輯，我們需要刪除舊的並創建新的（簡化處理）
                    this.saveHolidayRange({
                        id: holiday.id, // 保留原ID用於刪除
                        startDate: startDateVal,
                        endDate: endDateVal,
                        description: descriptionVal,
                        dateRange: dateRange
                    });
                } else {
                    this.saveHolidayRange({
                        startDate: startDateVal,
                        endDate: endDateVal,
                        description: descriptionVal,
                        dateRange: dateRange
                    });
                }
            });
        }

        // 點擊模態背景關閉
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeModal();
            }
        });

        // 聚焦到第一個輸入框
        setTimeout(() => {
            if (startDateInput) startDateInput.focus();
        }, 100);
    }

    getDateRange(startDate, endDate) {
        const dates = [];
        const start = new Date(startDate);
        const end = new Date(endDate);

        // 清除時間部分
        start.setHours(0, 0, 0, 0);
        end.setHours(0, 0, 0, 0);

        let current = new Date(start);
        while (current <= end) {
            const year = current.getFullYear();
            const month = String(current.getMonth() + 1).padStart(2, '0');
            const day = String(current.getDate()).padStart(2, '0');
            dates.push(`${year}-${month}-${day}`);
            current.setDate(current.getDate() + 1);
        }

        return dates;
    }

    async saveHoliday(holidayData) {
        try {
            if (!this.isAuthenticated) {
                this.addMessage('請先登入以管理節假日', 'warning');
                return;
            }

            const url = holidayData.id ? `/api/holidays/${holidayData.id}` : '/api/holidays';
            const method = holidayData.id ? 'PUT' : 'POST';

            const response = await fetch(url, {
                method,
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    date: holidayData.date,
                    description: holidayData.description
                })
            });

            if (!response.ok) {
                const errorResult = await response.json();
                throw new Error(errorResult.message || `API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            this.addMessage(result.message || '節假日保存成功', 'success');
            this.loadHolidays(); // 重新載入列表

        } catch (error) {
            console.error('保存節假日失敗:', error);
            this.addMessage(`保存節假日失敗: ${error.message}`, 'error');
        }
    }

    async saveHolidayRange(holidayRangeData) {
        try {
            if (!this.isAuthenticated) {
                this.addMessage('請先登入以管理節假日', 'warning');
                return;
            }

            console.log('保存節假日範圍:', holidayRangeData);

            // 如果有ID（編輯模式），先刪除舊的節假日
            if (holidayRangeData.id) {
                try {
                    await this.deleteHolidaySilently(holidayRangeData.id);
                } catch (deleteError) {
                    console.warn('刪除舊節假日失敗，繼續創建新記錄:', deleteError);
                }
            }

            // 為日期範圍內的每一天創建節假日
            const promises = holidayRangeData.dateRange.map(date => {
                return fetch('/api/holidays', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${this.currentToken}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        date: date,
                        description: holidayRangeData.description
                    })
                });
            });

            // 等待所有請求完成
            const responses = await Promise.all(promises);
            const errors = [];

            for (let i = 0; i < responses.length; i++) {
                if (!responses[i].ok) {
                    const errorResult = await responses[i].json();
                    errors.push(`日期 ${holidayRangeData.dateRange[i]}: ${errorResult.message || '保存失敗'}`);
                }
            }

            if (errors.length > 0) {
                throw new Error(`部分節假日保存失敗:\n${errors.join('\n')}`);
            }

            this.addMessage(`成功創建 ${holidayRangeData.dateRange.length} 個節假日`, 'success');
            this.loadHolidays(); // 重新載入列表

        } catch (error) {
            console.error('保存節假日範圍失敗:', error);
            this.addMessage(`保存節假日範圍失敗: ${error.message}`, 'error');
        }
    }

    async deleteHolidaySilently(holidayId) {
        // 靜默刪除，不顯示確認對話框
        try {
            const response = await fetch(`/api/holidays/${holidayId}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                const errorResult = await response.json();
                throw new Error(errorResult.message || `API請求失敗: ${response.status}`);
            }

            console.log('靜默刪除節假日成功:', holidayId);
        } catch (error) {
            console.error('靜默刪除節假日失敗:', error);
            throw error;
        }
    }

    async deleteHoliday(holidayId) {
        if (!confirm('確定要刪除這個節假日嗎？')) {
            return;
        }

        try {
            if (!this.isAuthenticated) {
                this.addMessage('請先登入以刪除節假日', 'warning');
                return;
            }

            const response = await fetch(`/api/holidays/${holidayId}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                const errorResult = await response.json();
                throw new Error(errorResult.message || `API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            this.addMessage(result.message || '節假日刪除成功', 'success');
            this.loadHolidays(); // 重新載入列表

        } catch (error) {
            console.error('刪除節假日失敗:', error);
            this.addMessage(`刪除節假日失敗: ${error.message}`, 'error');
        }
    }

    editHoliday(holidayId) {
        console.log('編輯節假日按鈕點擊，holidayId:', holidayId);
        console.log('holidaysList:', this.holidaysList);

        const holiday = this.holidaysList.find(h => h.id === holidayId);
        if (!holiday) {
            console.error('找不到節假日，holidayId:', holidayId);
            this.addMessage('找不到指定的節假日', 'error');
            return;
        }

        console.log('找到節假日:', holiday);
        this.openHolidayForm(holiday);
    }

    async loadEmployeeManagementTab() {
        console.log('loadEmployeeManagementTab called');
        if (!this.isAuthenticated) {
            this.addMessage('請先登入以管理員工', 'warning');
            return;
        }

        const isAdmin = this.currentEmployee && this.currentEmployee.role === 'admin';
        if (!isAdmin) {
            this.addMessage('只有管理員可以訪問員工管理功能', 'warning');
            return;
        }

        // 清除任何現有的消息
        this.clearMessages();

        try {
            // 從API獲取員工列表
            const response = await fetch('/api/employees', {
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            const employees = result.data || [];

            // 生成員工表格HTML
            let employeesHtml = '';
            if (employees.length > 0) {
                employees.forEach(employee => {
                    const lastLogin = employee.last_login ? new Date(employee.last_login).toLocaleString('zh-TW') : '從未登入';
                    const statusClass = employee.is_active ? 'status-active' : 'status-inactive';
                    const statusText = employee.is_active ? '啟用' : '停用';
                    const roleText = employee.role === 'admin' ? '管理員' : '員工';
                    const storeText = employee.store_name ? employee.store_name : (employee.role === 'admin' ? '總部' : '未分配');

                    employeesHtml += `
                        <tr data-employee-id="${employee.id}">
                            <td>${employee.id}</td>
                            <td>${employee.full_name}</td>
                            <td>${employee.username}</td>
                            <td><span class="role-badge ${employee.role}">${roleText}</span></td>
                            <td>${storeText}</td>
                            <td><span class="status-badge ${statusClass}">${statusText}</span></td>
                            <td>${lastLogin}</td>
                            <td class="employee-actions">
                                <button class="btn-small btn-edit" data-action="edit" data-employee-id="${employee.id}">
                                    <i class="fas fa-edit"></i> 編輯
                                </button>
                                <button class="btn-small btn-change-password" data-action="change-password" data-employee-id="${employee.id}">
                                    <i class="fas fa-key"></i> 更改密碼
                                </button>
                                <button class="btn-small btn-danger" data-action="delete" data-employee-id="${employee.id}">
                                    <i class="fas fa-trash"></i> 刪除
                                </button>
                            </td>
                        </tr>
                    `;
                });
            } else {
                employeesHtml = `
                    <tr>
                        <td colspan="8" class="empty-table-message">暫無員工資料</td>
                    </tr>
                `;
            }

            // 更新表格內容
            const tableBody = document.getElementById('employee-table-body');
            if (tableBody) {
                tableBody.innerHTML = employeesHtml;
            }

            // 綁定員工表格事件
            this.bindEmployeeTableEvents();

            // 加載分店列表並填充下拉菜單
            await this.loadStoresForEmployeeForm();

        } catch (error) {
            console.error('載入員工列表失敗:', error);
            this.addMessage(`載入員工列表失敗: ${error.message}`, 'error');

            // 顯示錯誤狀態
            const tableBody = document.getElementById('employee-table-body');
            if (tableBody) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="8" class="error-table-message">
                            <i class="fas fa-exclamation-triangle"></i>
                            載入員工列表失敗，請稍後再試
                        </td>
                    </tr>
                `;
            }
        }

        // 綁定表單事件
        this.bindEmployeeFormEvents();
    }

    async loadLockerManagementTab() {
        console.log('loadLockerManagementTab called');
        if (!this.isAuthenticated) {
            this.addMessage('請先登入以管理儲物柜', 'warning');
            return;
        }

        // 清除任何現有的消息
        this.clearMessages();

        try {
            // 從API獲取儲物柜列表
            // 添加分店ID到查詢參數（用於分店隔離）
            const url = `/api/locker/status${this.selectedStoreId ? '?store_id=' + this.selectedStoreId : ''}`;
            console.log(`載入儲物柜列表，分店ID: ${this.selectedStoreId || '未指定（使用默認）'}`);

            const response = await fetch(url, {
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            this.lockersList = (result.lockers || []).map(locker => ({ ...locker, id: locker.locker_number }));
            this.updateLockerStats();
            this.renderLockersGrid();
            this.bindLockerEvents();

        } catch (error) {
            console.error('載入儲物柜列表失敗:', error);
            this.addMessage(`載入儲物柜列表失敗: ${error.message}`, 'error');
            this.showLockerError();
        }
    }

    updateLockerStats() {
        const total = this.lockersList.length;
        const occupied = this.lockersList.filter(locker => locker.is_occupied).length;
        const available = total - occupied;
        const usage = total > 0 ? Math.round((occupied / total) * 100) : 0;

        this.lockerStats = { total, occupied, available, usage };

        // 更新UI統計
        document.getElementById('total-lockers').textContent = total;
        document.getElementById('occupied-lockers').textContent = occupied;
        document.getElementById('available-lockers').textContent = available;
        document.getElementById('locker-usage').textContent = `${usage}%`;
    }

    renderLockersGrid() {
        const lockerGrid = document.getElementById('locker-grid');
        if (!lockerGrid) return;

        // 應用過濾器
        let filteredLockers = this.lockersList;
        if (this.lockerFilters.status) {
            filteredLockers = filteredLockers.filter(locker => {
                if (this.lockerFilters.status === 'occupied') {
                    return locker.is_occupied;
                } else if (this.lockerFilters.status === 'available') {
                    return !locker.is_occupied;
                }
                return true;
            });
        }

        if (this.lockerFilters.search) {
            const searchNum = parseInt(this.lockerFilters.search);
            filteredLockers = filteredLockers.filter(locker =>
                locker.locker_number.toString().includes(this.lockerFilters.search)
            );
        }

        if (filteredLockers.length === 0) {
            lockerGrid.innerHTML = `
                <div class="empty-locker-message">
                    <i class="fas fa-door-closed"></i>
                    <p>沒有找到匹配的儲物柜</p>
                </div>
            `;
            return;
        }

        // 按編號排序
        filteredLockers.sort((a, b) => a.locker_number - b.locker_number);

        let lockersHtml = '';
        filteredLockers.forEach(locker => {
            const statusClass = locker.is_occupied ? 'occupied' : 'available';
            const statusText = locker.is_occupied ? '已佔用' : '空閒';
            // 嘗試從多個字段中提取桌號信息
            let customerName = '';
            if (locker.table_number) {
                // 優先使用table_number字段
                customerName = `桌號 ${locker.table_number}`;
            } else if (locker.customer_name) {
                customerName = locker.customer_name;
            } else if (locker.customer_id) {
                // 嘗試判斷customer_id是否是UUID格式或包含桌號
                if (locker.customer_id.includes('A') || locker.customer_id.includes('B') || locker.customer_id.includes('C') || locker.customer_id.includes('D')) {
                    // 假設customer_id包含桌號信息，如"A3"或"table_A3"
                    customerName = `桌號 ${locker.customer_id.replace('table_', '').replace('Table_', '').replace('TABLE_', '')}`;
                } else if (locker.customer_id.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)) {
                    // UUID格式，顯示簡短版本
                    customerName = `客戶 ${locker.customer_id.substring(0, 8)}...`;
                } else {
                    customerName = `客戶 ${locker.customer_id}`;
                }
            }
            const occupiedSince = locker.opened_at ? new Date(locker.opened_at).toLocaleString('zh-TW') : '';

            lockersHtml += `
                <div class="locker-card ${statusClass}" data-locker-id="${locker.id}">
                    <div class="locker-header">
                        <h4><i class="fas fa-door-closed"></i> 儲物柜 #${locker.locker_number}</h4>
                        <span class="locker-status ${statusClass}">${statusText}</span>
                    </div>
                    <div class="locker-body">
                        ${locker.is_occupied ? `
                            <div class="locker-info">
                                <p><i class="fas fa-user"></i> ${customerName}</p>
                                <p><i class="fas fa-clock"></i> ${occupiedSince}</p>
                            </div>
                        ` : `
                            <div class="locker-info">
                                <p><i class="fas fa-check-circle"></i> 可立即使用</p>
                            </div>
                        `}
                    </div>
                    <div class="locker-actions">
                        ${locker.is_occupied ? `
                            <button class="btn-small btn-release" data-action="release" data-locker-id="${locker.id}">
                                <i class="fas fa-door-open"></i> 釋放
                            </button>
                        ` : ''}
                        <button class="btn-small btn-open" data-action="open" data-locker-id="${locker.id}">
                            <i class="fas fa-key"></i> 開啟
                        </button>
                        <button class="btn-small btn-assign" data-action="assign" data-locker-id="${locker.id}">
                            <i class="fas fa-user-plus"></i> 分配
                        </button>
                        <button class="btn-small btn-danger" data-action="delete" data-locker-id="${locker.id}">
                            <i class="fas fa-trash"></i> 刪除
                        </button>
                    </div>
                </div>
            `;
        });

        lockerGrid.innerHTML = lockersHtml;
    }

    showLockerError() {
        const lockerGrid = document.getElementById('locker-grid');
        if (lockerGrid) {
            lockerGrid.innerHTML = `
                <div class="error-locker-message">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>載入儲物柜失敗，請稍後再試</p>
                </div>
            `;
        }
    }

    bindLockerEvents() {
        // 綁定過濾器事件
        const statusFilter = document.getElementById('locker-status-filter');
        const searchInput = document.getElementById('locker-search');
        const refreshBtn = document.getElementById('refresh-lockers-btn');
        const addBtn = document.getElementById('add-locker-btn');
        const releaseAllBtn = document.getElementById('release-all-lockers-btn');
        const rearrangeBtn = document.getElementById('rearrange-lockers-btn');
        const cancelBtn = document.getElementById('cancel-locker-btn');
        const lockerForm = document.getElementById('locker-form');

        if (statusFilter) {
            statusFilter.addEventListener('change', (e) => {
                this.lockerFilters.status = e.target.value;
                this.renderLockersGrid();
            });
        }

        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.lockerFilters.search = e.target.value;
                this.renderLockersGrid();
            });
        }

        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                this.loadLockerManagementTab();
            });
        }

        if (addBtn) {
            addBtn.addEventListener('click', () => {
                this.resetLockerForm();
                // 顯示客戶選擇（如果需要）
                this.loadCustomersForLockerForm();
            });
        }

        if (releaseAllBtn) {
            releaseAllBtn.addEventListener('click', () => {
                this.releaseAllLockers();
            });
        }

        if (rearrangeBtn) {
            rearrangeBtn.addEventListener('click', () => {
                this.rearrangeLockers();
            });
        }

        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                this.resetLockerForm();
            });
        }

        if (lockerForm) {
            lockerForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveLocker();
            });
        }

        // 綁定儲物柜卡片事件（事件委託）
        const lockerGrid = document.getElementById('locker-grid');
        if (lockerGrid) {
            // 移除舊的事件監聽器（如果存在）
            if (this.lockerGridEventHandler) {
                lockerGrid.removeEventListener('click', this.lockerGridEventHandler);
                console.log('移除舊的儲物柜事件監聽器');
            }

            // 創建新的事件處理函數
            this.lockerGridEventHandler = (e) => {
                const button = e.target.closest('button');
                if (!button) return;

                const action = button.dataset.action;
                const lockerId = button.dataset.lockerId;

                if (!action || !lockerId) return;

                console.log(`儲物柜事件: action=${action}, lockerId=${lockerId}`);

                if (action === 'release') {
                    this.releaseLocker(lockerId);
                } else if (action === 'open') {
                    this.openLocker(lockerId);
                } else if (action === 'assign') {
                    this.assignLocker(lockerId);
                } else if (action === 'edit') {
                    this.editLocker(lockerId);
                } else if (action === 'delete') {
                    this.deleteLocker(lockerId);
                }
            };

            // 添加新的事件監聽器
            lockerGrid.addEventListener('click', this.lockerGridEventHandler);
            console.log('添加新的儲物柜事件監聽器');
        }

        // 綁定狀態變更事件（顯示/隱藏客戶選擇）
        const statusSelect = document.getElementById('locker-status');
        if (statusSelect) {
            statusSelect.addEventListener('change', (e) => {
                this.toggleCustomerField(e.target.value === 'occupied');
            });
        }
    }

    toggleCustomerField(show) {
        const customerGroup = document.getElementById('customer-info-group');
        if (customerGroup) {
            customerGroup.style.display = show ? 'block' : 'none';
        }
    }

    async loadCustomersForLockerForm() {
        try {
            const response = await fetch('/api/customers/active', {
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) return;

            const result = await response.json();
            const customers = result.data || [];
            const customerSelect = document.getElementById('locker-customer');

            if (customerSelect) {
                customerSelect.innerHTML = '<option value="">選擇客戶</option>';
                customers.forEach(customer => {
                    const option = document.createElement('option');
                    option.value = customer.id;
                    option.textContent = `${customer.table_number} - ${customer.people_count}人`;
                    customerSelect.appendChild(option);
                });
            }
        } catch (error) {
            console.error('載入客戶列表失敗:', error);
        }
    }

    resetLockerForm() {
        const form = document.getElementById('locker-form');
        if (form) {
            form.reset();
            document.getElementById('locker-id').value = '';
            document.getElementById('locker-status').value = 'available';
            this.toggleCustomerField(false);
        }
    }

    async editLocker(lockerId) {
        console.log(`editLocker called for ID: ${lockerId}`);
        const locker = this.lockersList.find(l => l.id === lockerId);
        if (!locker) return;

        this.addMessage(`正在載入儲物柜 #${locker.locker_number} 的資料...`, 'info');

        // 填充表單
        document.getElementById('locker-id').value = locker.id;
        document.getElementById('locker-number').value = locker.locker_number;
        document.getElementById('locker-status').value = locker.is_occupied ? 'occupied' : 'available';

        if (locker.is_occupied) {
            this.toggleCustomerField(true);
            // 載入客戶列表並選擇當前客戶
            await this.loadCustomersForLockerForm();
            const customerSelect = document.getElementById('locker-customer');
            if (customerSelect && locker.customer_id) {
                customerSelect.value = locker.customer_id;
            }
        } else {
            this.toggleCustomerField(false);
        }

        this.addMessage(`已載入儲物柜 #${locker.locker_number} 的資料`, 'success');
    }

    async saveLocker() {
        console.log('saveLocker called');
        const form = document.getElementById('locker-form');
        if (!form) return;

        const lockerId = document.getElementById('locker-id').value;
        const isEdit = !!lockerId;

        // 收集表單數據
        const formData = {
            locker_number: parseInt(document.getElementById('locker-number').value),
            is_occupied: document.getElementById('locker-status').value === 'occupied'
        };

        if (formData.is_occupied) {
            const customerId = document.getElementById('locker-customer').value;
            if (!customerId) {
                this.addMessage('請選擇客戶', 'error');
                return;
            }
            formData.customer_id = customerId;
        }

        // 驗證必填字段
        if (!formData.locker_number || formData.locker_number < 1) {
            this.addMessage('請輸入有效的儲物柜編號', 'error');
            return;
        }

        try {
            const url = isEdit ? `/api/locker/${lockerId}` : '/api/locker';
            const method = isEdit ? 'PUT' : 'POST';

            const response = await fetch(url, {
                method: method,
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            this.addMessage(result.message || (isEdit ? '儲物柜更新成功' : '儲物柜創建成功'), 'success');

            // 重置表單
            this.resetLockerForm();

            // 刷新儲物柜列表
            this.loadLockerManagementTab();

        } catch (error) {
            console.error('保存儲物柜失敗:', error);
            this.addMessage(`保存儲物柜失敗: ${error.message}`, 'error');
        }
    }

    async releaseLocker(lockerId) {
        // 確保lockerId是數字（dataset屬性可能是字符串）
        lockerId = parseInt(lockerId, 10);
        console.log(`releaseLocker called for ID: ${lockerId} (parsed)`);
        console.log(`this.lockersList length: ${this.lockersList?.length || 0}`);
        console.log(`this.lockersList:`, this.lockersList?.map(l => ({id: l.id, locker_number: l.locker_number, is_occupied: l.is_occupied})));
        const locker = this.lockersList.find(l => l.id === lockerId);
        console.log(`Found locker:`, locker);
        if (!locker) {
            console.log(`Locker not found for ID: ${lockerId}`);
            return;
        }
        if (!locker.is_occupied) {
            console.log(`Locker ${lockerId} is not occupied, cannot release`);
            return;
        }

        // 保存客戶ID以便後續更新客人詳情
        const customerId = locker.customer_id;
        const lockerNumber = locker.locker_number;

        console.log(`儲物柜詳情:`, {
            lockerId,
            lockerNumber,
            customerId,
            locker: JSON.stringify(locker, null, 2)
        });

        if (!confirm(`確定要釋放儲物柜 #${lockerNumber} 嗎？`)) {
            return;
        }

        this.addMessage(`正在釋放儲物柜 #${lockerNumber}...`, 'info');

        try {
            const response = await fetch(`/api/locker/${lockerNumber}/release`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ force_release: true })
            });

            if (!response.ok) {
                let errorData = {};
                try {
                    errorData = await response.json();
                    console.log('API錯誤響應詳情:', errorData);
                } catch (jsonError) {
                    console.log('無法解析JSON錯誤響應:', jsonError);
                }
                throw new Error(errorData.message || `API請求失敗: ${response.status} - ${errorData.error || 'Unknown error'}`);
            }

            const result = await response.json();
            this.addMessage(result.message || '儲物柜釋放成功', 'success');
            console.log('儲物柜釋放API響應:', result);

            // 立即更新本地儲物柜狀態
            const updatedLocker = this.lockersList.find(l => l.id === lockerId);
            if (updatedLocker) {
                updatedLocker.is_occupied = false;
                updatedLocker.customer_id = null;
                updatedLocker.customer_name = '';
                updatedLocker.opened_at = null;
                this.updateLockerStats();
                this.renderLockersGrid();
                this.bindLockerEvents();
                console.log('本地儲物柜狀態已更新');
            }

            // 後台刷新儲物柜列表（確保與服務器同步）
            setTimeout(() => {
                this.loadLockerManagementTab();
            }, 500);

            // 如果儲物柜有對應的客戶ID，更新客人詳情
            if (customerId) {
                this.updateCustomerDetailAfterLockerRelease(customerId, lockerNumber);
            }

        } catch (error) {
            console.error('釋放儲物柜失敗:', error);
            this.addMessage(`釋放儲物柜失敗: ${error.message}`, 'error');
        }
    }

    async updateCustomerDetailAfterLockerRelease(customerId, lockerNumber) {
        console.log(`更新客人詳情，客戶ID: ${customerId}, 儲物柜編號: ${lockerNumber}`);

        // 首先刷新客人列表以獲取最新數據
        await this.loadCustomers();

        // 調試：顯示所有客戶
        console.log(`載入的客戶列表 (${this.customers?.length || 0} 個):`, this.customers?.map(c => ({id: c.id, table_number: c.table_number, is_checked_out: c.is_checked_out})));

        // 查找對應的客人
        let customer = null;

        // 嘗試多種匹配方式
        // 1. 直接匹配客人ID
        customer = this.customers.find(c => c.id === customerId);

        // 2. 如果沒有找到，嘗試匹配桌號（customerId可能是桌號）
        if (!customer) {
            customer = this.customers.find(c => c.table_number === customerId);
        }

        // 3. 如果還是沒有找到，嘗試從customerId中提取桌號（例如"table_A3"）
        if (!customer && customerId.includes('table_')) {
            const tableNumber = customerId.replace('table_', '');
            customer = this.customers.find(c => c.table_number === tableNumber);
        }

        if (customer) {
            console.log(`找到對應客人: ${customer.table_number}, 重新加載詳情`);
            // 重新加載客人詳情
            await this.loadCustomerDetail(customer.id);

            // 如果這是當前選中的客人，確保詳情顯示更新
            if (this.selectedCustomer && this.selectedCustomer.id === customer.id) {
                this.displayCustomerDetail(customer);
            }

            this.addMessage(`已更新桌號 ${customer.table_number} 的客人詳情`, 'info');
        } else {
            console.log(`未找到對應客人，客戶ID: ${customerId}`);
        }
    }

    async openLocker(lockerId) {
        console.log(`openLocker called for ID: ${lockerId}`);
        const locker = this.lockersList.find(l => l.id === lockerId);
        if (!locker) return;

        if (!confirm(`確定要開啟儲物柜 #${locker.locker_number} 嗎？儲物柜會暫時開啟10秒。`)) {
            return;
        }

        this.addMessage(`正在開啟儲物柜 #${locker.locker_number}...`, 'info');

        try {
            const response = await fetch(`/api/locker/test-open`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ locker_number: locker.locker_number, duration: 10000 })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.error || `API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            this.addMessage(result.message || '儲物柜開啟成功', 'success');

            // 刷新儲物柜列表以更新狀態
            this.loadLockerManagementTab();

        } catch (error) {
            console.error('開啟儲物柜失敗:', error);
            this.addMessage(`開啟儲物柜失敗: ${error.message}`, 'error');
        }
    }

    async assignLocker(lockerId) {
        // 確保lockerId是數字（dataset屬性可能是字符串）
        lockerId = parseInt(lockerId, 10);
        console.log(`assignLocker called for ID: ${lockerId} (parsed)`);
        console.log(`this.lockersList length: ${this.lockersList?.length || 0}`);
        const locker = this.lockersList.find(l => l.id === lockerId);
        console.log(`Found locker:`, locker);
        if (!locker) {
            console.log(`Locker not found for ID: ${lockerId}`);
            return;
        }

        this.addMessage(`正在準備分配儲物柜 #${locker.locker_number}...`, 'info');

        // 儲存要分配的儲物柜信息到實例變量中
        this.pendingLockerAssignment = {
            lockerId: locker.id,
            lockerNumber: locker.locker_number
        };
        console.log(`Set pendingLockerAssignment:`, this.pendingLockerAssignment);
        console.log(`Current pendingLockerAssignment after setting:`, this.pendingLockerAssignment);

        // 切換到"桌號管理"分頁 (data-tab="dashboard")
        console.log(`Calling switchTab('dashboard', { fromLockerAssignment: true, lockerId: ${locker.id} })`);
        this.switchTab('dashboard', { fromLockerAssignment: true, lockerId: locker.id });
        console.log(`switchTab called, pendingLockerAssignment should still be set:`, this.pendingLockerAssignment);
    }

    showLockerAssignmentPrompt() {
        console.log(`showLockerAssignmentPrompt called, pendingLockerAssignment:`, this.pendingLockerAssignment);
        console.log(`Current tab: ${this.currentTab}, isAuthenticated: ${this.isAuthenticated}`);
        // 在"在場客人"區域顯示分配提示
        const customersList = document.getElementById('customers-list');
        console.log(`customersList element found: ${!!customersList}`);
        if (customersList) {
            // 創建提示元素
            const promptElement = document.createElement('div');
            promptElement.className = 'locker-assignment-prompt';
            promptElement.innerHTML = `
                <div class="prompt-header">
                    <i class="fas fa-door-closed"></i>
                    <h4>儲物柜分配</h4>
                </div>
                <div class="prompt-body">
                    <p>請選擇一個桌號來分配儲物柜 <strong>#${this.pendingLockerAssignment?.lockerNumber || ''}</strong></p>
                    <p class="prompt-hint">點擊下方桌號卡片進行分配</p>
                </div>
                <div class="prompt-actions">
                    <button class="btn-small btn-cancel-assign" id="cancel-locker-assign">
                        <i class="fas fa-times"></i> 取消分配
                    </button>
                </div>
            `;

            // 插入到客人列表上方
            if (customersList.firstChild) {
                customersList.insertBefore(promptElement, customersList.firstChild);
            } else {
                customersList.appendChild(promptElement);
            }

            // 綁定取消按鈕事件
            const cancelBtn = document.getElementById('cancel-locker-assign');
            if (cancelBtn) {
                cancelBtn.addEventListener('click', () => {
                    this.cancelLockerAssignment();
                });
            }

            // 為所有客人卡片添加分配模式樣式（視覺提示）
            const customerCards = document.querySelectorAll('.customer-item');
            console.log(`Found ${customerCards.length} customer cards to add assign mode`);
            customerCards.forEach((card, index) => {
                console.log(`Adding assign mode to customer card ${index}:`, {
                    id: card.dataset.customerId,
                    tableNumber: card.querySelector('.table-number')?.textContent || 'unknown'
                });
                card.classList.add('assign-mode');
            });
            console.log('Assign mode added to all customer cards (visual only, logic handled by selectCustomer)');
        }
    }

    handleCustomerSelectionForLocker(event) {
        console.log('========== handleCustomerSelectionForLocker 被調用 ==========');
        console.log('Event target:', event.target);
        console.log('Event currentTarget:', event.currentTarget);
        console.log('pendingLockerAssignment:', this.pendingLockerAssignment);

        // 防止點擊內部按鈕觸發分配
        if (event.target.closest('button')) {
            console.log('Clicked on button, ignoring');
            return;
        }

        // 阻止事件冒泡和默認行為，防止觸發原有的selectCustomer事件
        event.stopPropagation();
        event.preventDefault();
        console.log('Event propagation stopped');

        const customerCard = event.currentTarget;
        const customerId = customerCard.dataset.customerId;

        if (!customerId || !this.pendingLockerAssignment) return;

        // 獲取客戶信息
        const customer = this.customers.find(c => c.id === customerId);
        if (!customer) return;

        // 確認分配
        if (confirm(`確定將儲物柜 #${this.pendingLockerAssignment.lockerNumber} 分配給桌號 ${customer.table_number} 嗎？`)) {
            this.completeLockerAssignment(customer);
        }
    }

    async completeLockerAssignment(customer) {
        console.log(`completeLockerAssignment called with customer:`, customer);
        console.log(`pendingLockerAssignment:`, this.pendingLockerAssignment);
        if (!this.pendingLockerAssignment) {
            console.error('No pendingLockerAssignment in completeLockerAssignment!');
            return;
        }

        this.addMessage(`正在將儲物柜 #${this.pendingLockerAssignment.lockerNumber} 分配給桌號 ${customer.table_number}...`, 'info');

        try {
            // 調用API分配儲物柜
            const apiUrl = `/api/locker/${this.pendingLockerAssignment.lockerNumber}/assign`;
            console.log(`Making API request to: ${apiUrl}`);
            const requestBody = {
                customer_id: customer.id,
                table_number: customer.table_number,
                force_assign: true
            };
            console.log('Request body:', JSON.stringify(requestBody));

            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(requestBody)
            });

            console.log(`API response status: ${response.status} ${response.statusText}`);
            console.log(`API response headers:`, Object.fromEntries(response.headers.entries()));

            if (!response.ok) {
                let errorData = {};
                try {
                    errorData = await response.json();
                    console.log('API分配錯誤響應詳情:', errorData);
                } catch (jsonError) {
                    console.log('無法解析JSON錯誤響應:', jsonError);
                    const text = await response.text();
                    console.log('Response text:', text);
                }
                throw new Error(errorData.message || `API請求失敗: ${response.status} - ${errorData.error || 'Unknown error'}`);
            }

            const result = await response.json();
            console.log('API分配成功響應:', result);
            this.addMessage(result.message || `儲物柜 #${this.pendingLockerAssignment.lockerNumber} 已成功分配給桌號 ${customer.table_number}`, 'success');

            // 清理分配狀態
            this.cleanupLockerAssignment();

            // 刷新儲物柜列表
            this.loadLockerManagementTab();

            // 刷新客戶列表以更新儲物柜資訊
            console.log('Refreshing customers list...');
            await this.loadCustomers();
            console.log('Customers list refreshed');

            // 刷新被分配客戶的詳情
            console.log(`Refreshing detail for customer ${customer.id} (table ${customer.table_number})...`);
            await this.loadCustomerDetail(customer.id);
            console.log('Customer detail refreshed');

            // 如果當前選中的客戶是被分配的客戶，確保詳情顯示更新
            if (this.selectedCustomer && this.selectedCustomer.id === customer.id) {
                console.log('Selected customer matches assigned customer, updating display...');
                this.displayCustomerDetail(customer);
            }

        } catch (error) {
            console.error('分配儲物柜失敗:', error);
            this.addMessage(`分配儲物柜失敗: ${error.message}`, 'error');
        }
    }

    cancelLockerAssignment() {
        this.addMessage('已取消儲物柜分配', 'info');
        this.cleanupLockerAssignment();
    }

    cleanupLockerAssignment() {
        // 移除分配提示
        const promptElement = document.querySelector('.locker-assignment-prompt');
        if (promptElement) {
            promptElement.remove();
        }

        // 移除客人卡片的分配模式樣式
        const customerCards = document.querySelectorAll('.customer-item.assign-mode');
        customerCards.forEach(card => {
            card.classList.remove('assign-mode');
            card.removeEventListener('click', this.handleCustomerSelectionForLocker);
        });

        // 清除待分配儲物柜信息
        this.pendingLockerAssignment = null;
    }

    async releaseAllLockers() {
        console.log('releaseAllLockers called');
        if (!confirm('確定要釋放所有已佔用的儲物柜嗎？此操作無法還原。')) {
            return;
        }

        this.addMessage('正在釋放所有儲物柜...', 'info');

        try {
            const response = await fetch('/api/locker/emergency-release-all', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    reason: '手動釋放所有儲物柜（管理員操作）',
                    operator_id: this.currentEmployee?.id || null
                })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            this.addMessage(result.message || '所有儲物柜已釋放', 'success');

            // 刷新儲物柜列表
            this.loadLockerManagementTab();

            // 刷新客人列表以更新儲物柜資訊
            await this.loadCustomers();

            // 如果當前有選中的客人，重新加載其詳情
            if (this.selectedCustomer) {
                await this.loadCustomerDetail(this.selectedCustomer.id);
            }

        } catch (error) {
            console.error('釋放所有儲物柜失敗:', error);
            this.addMessage(`釋放所有儲物柜失敗: ${error.message}`, 'error');
        }
    }

    async rearrangeLockers() {
        console.log('rearrangeLockers called');
        this.addMessage('正在重新編排儲物柜...', 'info');

        try {
            const response = await fetch('/api/locker/rearrange', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    operator_id: this.currentEmployee?.id || null
                })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            this.addMessage(result.message || '儲物柜重新編排完成', 'success');

            // 刷新儲物柜列表
            this.loadLockerManagementTab();

        } catch (error) {
            console.error('重新編排儲物柜失敗:', error);
            this.addMessage(`重新編排儲物柜失敗: ${error.message}`, 'error');
        }
    }

    async deleteLocker(lockerId) {
        console.log(`deleteLocker called for ID: ${lockerId}`);
        const locker = this.lockersList.find(l => l.id === lockerId);
        if (!locker) return;

        if (!confirm(`確定要刪除儲物柜 #${locker.locker_number} 嗎？此操作無法還原。`)) {
            return;
        }

        this.addMessage(`正在刪除儲物柜 #${locker.locker_number}...`, 'info');

        try {
            const response = await fetch(`/api/locker/${locker.locker_number}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            this.addMessage(result.message || '儲物柜刪除成功', 'success');

            // 刷新儲物柜列表
            this.loadLockerManagementTab();

        } catch (error) {
            console.error('刪除儲物柜失敗:', error);
            this.addMessage(`刪除儲物柜失敗: ${error.message}`, 'error');
        }
    }

    bindEmployeeTableEvents() {
        console.log('bindEmployeeTableEvents called');

        // 如果事件已經綁定，直接返回
        if (this._employeeTableEventsBound) {
            console.log('員工表格事件已綁定，跳過重複綁定');
            return;
        }

        const tableBody = document.getElementById('employee-table-body');
        if (!tableBody) return;

        // 移除舊的事件監聽器（如果存在）
        if (this._employeeTableEventHandler) {
            tableBody.removeEventListener('click', this._employeeTableEventHandler);
            this._employeeTableEventHandler = null;
        }

        // 創建新的事件處理器
        this._employeeTableEventHandler = (event) => {
            const button = event.target.closest('button');
            if (!button) return;

            const action = button.dataset.action;
            const employeeId = button.dataset.employeeId;

            if (!action || !employeeId) return;

            if (action === 'edit') {
                this.editEmployee(employeeId);
            } else if (action === 'change-password') {
                this.showChangePasswordModal(employeeId);
            } else if (action === 'delete') {
                this.deleteEmployee(employeeId);
            }
        };

        // 添加新的事件監聽器
        tableBody.addEventListener('click', this._employeeTableEventHandler);

        // 標記事件已綁定
        this._employeeTableEventsBound = true;
        console.log('員工表格事件綁定完成');
    }

    bindEmployeeFormEvents() {
        console.log('bindEmployeeFormEvents called');
        const employeeForm = document.getElementById('employee-form');
        const cancelBtn = document.getElementById('cancel-employee-btn');
        const addEmployeeBtn = document.getElementById('add-employee-btn');
        const refreshBtn = document.getElementById('refresh-employees-btn');

        if (employeeForm) {
            employeeForm.addEventListener('submit', (event) => {
                event.preventDefault();
                this.saveEmployee();
            });
        }

        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                this.resetEmployeeForm();
            });
        }

        if (addEmployeeBtn) {
            addEmployeeBtn.addEventListener('click', () => {
                this.resetEmployeeForm();
                // 滾動到表單部分
                const formSection = document.querySelector('.employee-form-section');
                if (formSection) {
                    formSection.scrollIntoView({ behavior: 'smooth' });
                }
            });
        }

        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                this.loadEmployeeManagementTab();
            });
        }
    }

    async loadStoresForEmployeeForm() {
        try {
            const response = await fetch('/api/stores', {
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            const stores = result.data || [];

            const storeSelect = document.getElementById('employee-store');
            if (!storeSelect) return;

            // 保存當前選中的值
            const currentValue = storeSelect.value;

            // 清空現有選項（保留第一個提示選項）
            while (storeSelect.options.length > 1) {
                storeSelect.remove(1);
            }

            // 添加分店選項
            stores.forEach(store => {
                const option = document.createElement('option');
                option.value = store.id;
                option.textContent = `${store.store_code} - ${store.store_name}`;
                storeSelect.appendChild(option);
            });

            // 還原選中的值（如果仍然存在）
            if (currentValue) {
                storeSelect.value = currentValue;
            }
        } catch (error) {
            console.error('加載分店列表失敗:', error);
            // 不顯示錯誤消息，避免干擾用戶
        }
    }

    async editEmployee(employeeId) {
        console.log(`editEmployee called for ID: ${employeeId}`);
        this.addMessage(`正在載入員工 ${employeeId} 的資料...`, 'info');

        try {
            const response = await fetch(`/api/employees/${employeeId}`, {
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            const employee = result.data;

            // 填充表單
            this.fillEmployeeForm(employee);

            // 滾動到表單部分
            const formSection = document.querySelector('.employee-form-section');
            if (formSection) {
                formSection.scrollIntoView({ behavior: 'smooth' });
            }

            this.addMessage(`已載入員工 ${employee.full_name} 的資料`, 'success');
        } catch (error) {
            console.error('載入員工資料失敗:', error);
            this.addMessage(`載入員工資料失敗: ${error.message}`, 'error');
        }
    }

    fillEmployeeForm(employee) {
        document.getElementById('employee-id').value = employee.id || '';
        document.getElementById('employee-full-name').value = employee.full_name || '';
        document.getElementById('employee-username').value = employee.username || '';
        document.getElementById('employee-role').value = employee.role || 'staff';
        document.getElementById('employee-status').value = employee.is_active ? 'active' : 'inactive';
        document.getElementById('employee-email').value = employee.email || '';
        document.getElementById('employee-phone').value = employee.phone || '';
        document.getElementById('employee-store').value = employee.store_id || '';

        // 清空密碼字段
        document.getElementById('employee-password').value = '';
        document.getElementById('employee-confirm-password').value = '';

        // 更新表單標題
        const saveBtn = document.getElementById('save-employee-btn');
        if (saveBtn) {
            saveBtn.textContent = employee.id ? '更新員工資料' : '創建員工';
        }
    }

    resetEmployeeForm() {
        document.getElementById('employee-form').reset();
        document.getElementById('employee-id').value = '';
        document.getElementById('employee-role').value = 'staff';
        document.getElementById('employee-status').value = 'active';
        document.getElementById('employee-store').value = '';

        // 更新表單標題
        const saveBtn = document.getElementById('save-employee-btn');
        if (saveBtn) {
            saveBtn.textContent = '創建員工';
        }
    }

    async saveEmployee() {
        console.log('saveEmployee called');
        const form = document.getElementById('employee-form');
        if (!form) return;

        const employeeId = document.getElementById('employee-id').value;
        const isEdit = !!employeeId;

        // 收集表單數據
        const formData = {
            full_name: document.getElementById('employee-full-name').value.trim(),
            username: document.getElementById('employee-username').value.trim(),
            role: document.getElementById('employee-role').value,
            is_active: document.getElementById('employee-status').value === 'active',
            email: document.getElementById('employee-email').value.trim(),
            phone: document.getElementById('employee-phone').value.trim(),
            store_id: document.getElementById('employee-store').value || null
        };

        // 檢查密碼（如果有）
        const password = document.getElementById('employee-password').value;
        const confirmPassword = document.getElementById('employee-confirm-password').value;
        let newPassword = null;

        if (password) {
            if (password !== confirmPassword) {
                this.addMessage('密碼與確認密碼不匹配', 'error');
                return;
            }
            newPassword = password;

            // 如果是創建新員工，將密碼包含在表單數據中
            if (!isEdit) {
                formData.password = password;
            }
            // 如果是編輯員工，密碼將在基本信息更新後單獨處理
        }

        // 驗證必填字段
        if (!formData.full_name || !formData.username) {
            this.addMessage('請填寫必填字段（全名和用戶名）', 'error');
            return;
        }

        try {
            const url = isEdit ? `/api/employees/${employeeId}` : '/api/employees';
            const method = isEdit ? 'PUT' : 'POST';

            console.log('發送員工數據:', { url, method, formData });

            const response = await fetch(url, {
                method: method,
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            let successMessage = result.message || (isEdit ? '員工資料更新成功' : '員工創建成功');

            // 如果是編輯操作且有新密碼，更新密碼
            if (isEdit && newPassword) {
                try {
                    await this.updateEmployeePassword(employeeId, newPassword);
                    successMessage += '，密碼已更新';
                } catch (passwordError) {
                    console.error('更新密碼失敗:', passwordError);
                    // 不阻止整個操作，但顯示警告
                    this.addMessage(`員工資料已更新，但密碼更新失敗: ${passwordError.message}`, 'warning');
                }
            }

            this.addMessage(successMessage, 'success');

            // 重置表單
            this.resetEmployeeForm();

            // 刷新員工列表
            this.loadEmployeeManagementTab();

        } catch (error) {
            console.error('保存員工失敗:', error);
            this.addMessage(`保存員工失敗: ${error.message}`, 'error');
        }
    }

    // 更新員工密碼
    async updateEmployeePassword(employeeId, newPassword) {
        console.log(`updateEmployeePassword called for employeeId: ${employeeId}`);

        try {
            const response = await fetch(`/api/employees/${employeeId}/password`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    new_password: newPassword
                    // 注意：管理員更改密碼不需要current_password字段
                })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            return result;
        } catch (error) {
            console.error('更新員工密碼失敗:', error);
            throw error;
        }
    }

    async deleteEmployee(employeeId) {
        console.log(`deleteEmployee called for ID: ${employeeId}`);

        // 防止重複刪除操作
        if (this._deletingEmployee) {
            console.log('已有刪除操作正在進行中，跳過重複執行');
            return;
        }

        if (!confirm('確定要刪除此員工嗎？此操作無法還原。')) {
            return;
        }

        // 標記刪除操作開始
        this._deletingEmployee = true;
        this.addMessage(`正在刪除員工 ${employeeId}...`, 'info');

        try {
            const response = await fetch(`/api/employees/${employeeId}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            this.addMessage(result.message || '員工刪除成功', 'success');

            // 刷新員工列表
            this.loadEmployeeManagementTab();

        } catch (error) {
            console.error('刪除員工失敗:', error);
            this.addMessage(`刪除員工失敗: ${error.message}`, 'error');
        } finally {
            // 無論成功或失敗，都重置刪除標誌
            this._deletingEmployee = false;
        }
    }

    // 綁定設置事件
    bindSettingsEvents() {
        // 保存設置按鈕
        const saveSettingsBtn = document.getElementById('save-settings-btn');
        if (saveSettingsBtn) {
            saveSettingsBtn.addEventListener('click', () => this.saveSettings());
        }

        // 刷新數據按鈕
        const refreshDataBtn = document.getElementById('refresh-data-btn');
        if (refreshDataBtn) {
            refreshDataBtn.addEventListener('click', () => this.refreshAllData());
        }

        // 修改密碼按鈕
        const changePasswordBtn = document.getElementById('change-password-btn');
        if (changePasswordBtn) {
            changePasswordBtn.addEventListener('click', () => this.showChangePasswordModal());
        }

        // 登出按鈕（設置頁面）
        const logoutSettingsBtn = document.getElementById('logout-settings-btn');
        if (logoutSettingsBtn) {
            logoutSettingsBtn.addEventListener('click', () => this.logout());
        }

        // 切換開關即時保存（可選）
        const showMockDataToggle = document.getElementById('show-mock-data-toggle');
        if (showMockDataToggle) {
            showMockDataToggle.addEventListener('change', (e) => {
                this.showMockData = e.target.checked;
                localStorage.setItem('cashier_showMockData', this.showMockData);
                this.addMessage('模擬數據顯示設置已更新', 'info');
            });
        }

        const alwaysShowMockDataToggle = document.getElementById('always-show-mock-data-toggle');
        if (alwaysShowMockDataToggle) {
            alwaysShowMockDataToggle.addEventListener('change', (e) => {
                this.alwaysShowMockData = e.target.checked;
                localStorage.setItem('cashier_alwaysShowMockData', this.alwaysShowMockData);
                this.addMessage('總是顯示模擬數據設置已更新', 'info');
            });
        }

        // 節假日管理事件
        this.bindHolidayEvents();

        // 檢查是否有可用更新（版本資訊）
        this.checkUpdateAvailability();
    }

    // 檢查版本更新資訊（Server + APK）
    async checkUpdateAvailability() {
        try {
            var r = await fetch('/api/update/check-available');
            var o = await r.json();
            if (o.success) {
                // Server 更新
                var ver = o.data.local_ver > 0 ? 'v' + o.data.local_ver : 'N/A';
                var latestVer = o.data.remote_ver > 0 ? 'v' + o.data.remote_ver : 'N/A';
                var status = o.data.has_update ? latestVer + ' (可更新)' : latestVer + ' (已最新)';
                var updStatus = o.data.is_updating ? '更新中' : (o.data.hot_fix_enabled === true ? 'Hot Fix Enabled' : (o.data.in_manual_window ? '可手動更新' : '手動更新時段: ' + o.data.manual_window_label));
                var el1 = document.getElementById('hostSvVer');
                var el2 = document.getElementById('hostSvLatestVer');
                var el3 = document.getElementById('hostSvUpdateStatus');
                if (el1) el1.textContent = ver;
                if (el2) el2.textContent = status;
                if (el3) el3.textContent = updStatus;
                var btnContainer = document.getElementById('hostUpdateBtnContainer');
                if (btnContainer) {
                    var isHotFix = o.data.hot_fix_enabled === true;
                    var inWindow = o.data.in_manual_window || isHotFix;
                    btnContainer.style.display = o.data.has_update && inWindow && !o.data.is_updating ? 'block' : 'none';
                }
                // APK 版本
                var apkLocal = document.getElementById('hostApkVer');
                var apkRemote = document.getElementById('hostApkLatestVer');
                var apkMsg = document.getElementById('hostApkUpdateMsg');
                if (apkLocal) apkLocal.textContent = o.data.apk_local_ver || 'N/A';
                if (apkRemote) apkRemote.textContent = o.data.apk_remote_ver || 'N/A';
                if (apkMsg) {
                    apkMsg.style.display = o.data.apk_has_update ? 'block' : 'none';
                }
            }
        } catch (e) {
            ['hostSvVer','hostSvLatestVer','hostApkVer','hostApkLatestVer'].forEach(function(id) {
                var el = document.getElementById(id);
                if (el) el.textContent = '無法檢查';
            });
        }
    }

    // 保存設置
    saveSettings() {
        // 獲取切換開關狀態
        const showMockDataToggle = document.getElementById('show-mock-data-toggle');
        const alwaysShowMockDataToggle = document.getElementById('always-show-mock-data-toggle');

        if (showMockDataToggle) {
            this.showMockData = showMockDataToggle.checked;
            localStorage.setItem('cashier_showMockData', this.showMockData);
        }

        if (alwaysShowMockDataToggle) {
            this.alwaysShowMockData = alwaysShowMockDataToggle.checked;
            localStorage.setItem('cashier_alwaysShowMockData', this.alwaysShowMockData);
        }

        this.addMessage('設置已保存成功', 'success');

        // 刷新數據以應用新設置
        this.refreshAllData();
    }

    // 刷新所有數據
    refreshAllData() {
        this.addMessage('正在刷新數據...', 'info');

        // 重新加載顧客數據
        this.loadCustomers();

        // 重新加載商品數據
        this.loadProducts();

        // 重新加載統計數據
        this.loadTodayStats();

        // 重新加載入場記錄
        this.loadEntryRecords();

        // 重新加載預約及候位（透過阿里雲 proxy）
        this.loadBookingInternal();
        this.loadWaitinglistInternal();

        setTimeout(() => {
            this.addMessage('數據刷新完成', 'success');
        }, 500);
    }

    // 顯示修改密碼模態框
    async showChangePasswordModal(employeeId) {
        console.log(`showChangePasswordModal called for employeeId: ${employeeId}`);

        if (!employeeId) {
            this.addMessage('無效的員工ID', 'error');
            return;
        }

        // 獲取員工信息
        try {
            const response = await fetch(`/api/employees/${employeeId}`, {
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            const employee = result.data;

            // 創建密碼更改模態框
            this.createPasswordChangeModal(employee);
        } catch (error) {
            console.error('獲取員工信息失敗:', error);
            this.addMessage(`獲取員工信息失敗: ${error.message}`, 'error');
        }
    }

    // 創建密碼更改模態框
    createPasswordChangeModal(employee) {
        console.log('創建密碼更改模態框:', employee);

        // 檢查是否已有密碼更改模態框，如果有則移除
        const existingModal = document.getElementById('password-change-modal');
        if (existingModal) {
            existingModal.remove();
        }

        // 創建模態框HTML
        const modalHTML = `
            <div id="password-change-modal" class="modal-overlay">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3><i class="fas fa-key"></i> 更改密碼</h3>
                        <button class="modal-close" id="close-password-modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p>為員工 <strong>${employee.full_name} (${employee.username})</strong> 更改密碼</p>
                        <form id="password-change-form">
                            <div class="form-group">
                                <label for="new-password">新密碼:</label>
                                <input type="password" id="new-password" required minlength="6" placeholder="至少6個字符">
                                <small>密碼必須至少6個字符</small>
                            </div>
                            <div class="form-group">
                                <label for="confirm-new-password">確認新密碼:</label>
                                <input type="password" id="confirm-new-password" required minlength="6" placeholder="再次輸入新密碼">
                            </div>
                            <div class="form-actions">
                                <button type="button" class="btn-secondary" id="cancel-password-change">取消</button>
                                <button type="submit" class="btn-primary" id="submit-password-change">更改密碼</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        `;

        // 添加到body
        document.body.insertAdjacentHTML('beforeend', modalHTML);

        // 綁定事件
        this.bindPasswordChangeModalEvents(employee.id);
    }

    // 綁定密碼更改模態框事件
    bindPasswordChangeModalEvents(employeeId) {
        const modal = document.getElementById('password-change-modal');
        const closeBtn = document.getElementById('close-password-modal');
        const cancelBtn = document.getElementById('cancel-password-change');
        const form = document.getElementById('password-change-form');

        if (!modal) return;

        // 關閉按鈕
        const closeModal = () => {
            modal.remove();
        };

        if (closeBtn) {
            closeBtn.addEventListener('click', closeModal);
        }

        if (cancelBtn) {
            cancelBtn.addEventListener('click', closeModal);
        }

        // 點擊模態框外部關閉
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeModal();
            }
        });

        // 表單提交
        if (form) {
            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                await this.submitPasswordChange(employeeId);
            });
        }
    }

    // 提交密碼更改
    async submitPasswordChange(employeeId) {
        const newPassword = document.getElementById('new-password').value;
        const confirmPassword = document.getElementById('confirm-new-password').value;

        if (!newPassword || newPassword.length < 6) {
            this.addMessage('新密碼必須至少6個字符', 'error');
            return;
        }

        if (newPassword !== confirmPassword) {
            this.addMessage('新密碼與確認密碼不匹配', 'error');
            return;
        }

        try {
            // 調用API更改密碼
            const response = await fetch(`/api/employees/${employeeId}/password`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${this.currentToken}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    new_password: newPassword
                    // 注意：管理員更改密碼不需要current_password字段
                })
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            this.addMessage(result.message || '密碼更改成功', 'success');

            // 關閉模態框
            const modal = document.getElementById('password-change-modal');
            if (modal) {
                modal.remove();
            }

        } catch (error) {
            console.error('更改密碼失敗:', error);
            this.addMessage(`更改密碼失敗: ${error.message}`, 'error');
        }
    }

    // 庫存管理方法
    showRestockModal(product) {
        const quantity = prompt(`為商品 "${product.name}" 輸入補貨數量:`, '10');
        if (quantity === null) return; // 用戶取消

        const parsedQuantity = parseInt(quantity);
        if (isNaN(parsedQuantity) || parsedQuantity <= 0) {
            this.addMessage('請輸入有效的正整數數量', 'warning');
            return;
        }

        this.restockProduct(product.id, parsedQuantity);
    }

    showAdjustModal(product) {
        const adjustment = prompt(`為商品 "${product.name}" 輸入庫存調整量（正數增加，負數減少）:`, '0');
        if (adjustment === null) return; // 用戶取消

        const parsedAdjustment = parseInt(adjustment);
        if (isNaN(parsedAdjustment)) {
            this.addMessage('請輸入有效的整數', 'warning');
            return;
        }

        this.adjustInventory(product.id, parsedAdjustment);
    }

    async restockProduct(productId, quantity) {
        try {
            const response = await this.fetchWithAuth('/api/inventory/restock', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    items: [{ product_id: productId, quantity }],
                    reason: '手動補貨'
                })
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage(`成功補貨 ${quantity} 個單位`, 'success');
                await this.loadProductsTabData(); // 刷新商品列表
            } else {
                this.addMessage(`補貨失敗: ${result.message}`, 'error');
            }
        } catch (error) {
            this.addMessage(`補貨失敗: ${error.message}`, 'error');
        }
    }

    async adjustInventory(productId, adjustment) {
        try {
            const response = await this.fetchWithAuth('/api/inventory/adjust', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    product_id: productId,
                    adjustment,
                    reason: '手動調整'
                })
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage(`成功調整庫存: ${adjustment}`, 'success');
                await this.loadProductsTabData(); // 刷新商品列表
            } else {
                this.addMessage(`調整失敗: ${result.message}`, 'error');
            }
        } catch (error) {
            this.addMessage(`調整失敗: ${error.message}`, 'error');
        }
    }

    // 重寫父類方法以使用身份驗證令牌
    async fetchWithAuth(url, options = {}) {
        const { skipStoreId, ...fetchOptions } = options;
        const headers = {
            ...options.headers,
            'Authorization': `Bearer ${this.currentToken}`
        };

        // 如果存在selectedStoreId，添加到URL查詢參數（除非調用方明確跳過）
        let finalUrl = url;
        if (!skipStoreId && this.selectedStoreId && this.selectedStoreId.trim() !== '')  {
            try {
                // 使用URL API正確處理查詢參數
                const urlObj = new URL(url, window.location.origin);
                // 只有在URL中沒有store_id參數時才添加
                if (!urlObj.searchParams.has('store_id')) {
                    urlObj.searchParams.set('store_id', this.selectedStoreId);
                    finalUrl = urlObj.toString().replace(window.location.origin, '');
                    console.log('fetchWithAuth: Added store_id parameter:', this.selectedStoreId);
                } else {
                    console.log('fetchWithAuth: URL already has store_id parameter, not overriding');
                }
            } catch (e) {
                // 如果URL構造失敗（可能是相對URL），使用簡單的字符串拼接
                // 檢查URL是否已包含store_id參數
                const hasStoreIdParam = url.includes('store_id=');
                if (!hasStoreIdParam) {
                    const separator = url.includes('?') ? '&' : '?';
                    finalUrl = `${url}${separator}store_id=${encodeURIComponent(this.selectedStoreId)}`;
                    console.log('fetchWithAuth: Added store_id parameter:', this.selectedStoreId);
                } else {
                    console.log('fetchWithAuth: URL already has store_id parameter, not overriding');
                }
            }
        }

        console.log('fetchWithAuth called:', finalUrl, 'headers:', headers, 'options:', options);

        // 在分機模式下，將API調用重定向到主服務器（如果需要）
        const redirectedUrl = this.buildApiUrl(finalUrl);
        if (redirectedUrl !== finalUrl) {
            console.log('fetchWithAuth: 重定向API調用到主服務器:', redirectedUrl);
        }

        // 檢查是否是需要重試的同步路徑
        const syncPaths = [
            '/api/cashier/',
            '/api/customers/',
            '/api/checkout/',
            '/api/bills/',
            '/api/orders/'
        ];

        const isSyncPath = syncPaths.some(prefix => redirectedUrl.includes(prefix));
        const maxRetries = isSyncPath ? 2 : 0; // 同步路徑重試2次，其他路徑不重試
        const retryDelay = 1000; // 1秒重試延遲

        let lastError;

        for (let attempt = 0; attempt <= maxRetries; attempt++) {
            try {
                if (attempt > 0) {
                    console.log(`fetchWithAuth: 重試第 ${attempt} 次 (共 ${maxRetries} 次重試)`);
                    await new Promise(resolve => setTimeout(resolve, retryDelay));
                }

                const response = await fetch(redirectedUrl, {
                    ...fetchOptions,
                    headers
                });

                // 如果是網絡錯誤（如TypeError），會被捕獲
                // 如果是HTTP錯誤（4xx, 5xx），不會被捕獲，需要檢查
                if (!response.ok && isSyncPath && attempt < maxRetries) {
                    // 對於同步路徑的HTTP錯誤，也進行重試
                    console.log(`fetchWithAuth: HTTP錯誤 ${response.status}，將重試`);
                    lastError = new Error(`HTTP ${response.status}: ${response.statusText}`);
                    continue;
                }

                return response;

            } catch (error) {
                console.error(`fetchWithAuth: 第 ${attempt + 1} 次嘗試失敗:`, error);
                lastError = error;

                if (attempt >= maxRetries) {
                    break;
                }
            }
        }

        // 所有重試都失敗了
        console.error(`fetchWithAuth: 所有 ${maxRetries + 1} 次嘗試都失敗`);

        // 對於同步路徑的持久失敗，可以將其加入隊列供以後重試
        // 這裡只是拋出錯誤，實際應用中可以實現隊列系統
        throw lastError || new Error('請求失敗且重試用盡');
    }

    // 重寫需要身份驗證的方法
    async addProductToOrder(productId, quantity = 1) {
        if (!this.isAuthenticated) {
            this.addMessage('請先登入以添加商品', 'warning');
            return;
        }

        if (!this.selectedCustomer) {
            this.addMessage('請先選擇客人', 'warning');
            return;
        }

        const product = this.products.find(p => p.id === productId);
        if (!product) {
            this.addMessage('商品不存在', 'error');
            return;
        }

        if (product.stock < quantity) {
            this.addMessage(`商品庫存不足，僅剩 ${product.stock} 件`, 'warning');
            return;
        }

        try {
            const response = await this.fetchWithAuth('/api/cashier/add-order-item', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    customer_id: this.selectedCustomer.id,
                    product_id: productId,
                    quantity: quantity
                })
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage(`已添加 ${product.name} x${quantity}`, 'success');
                this.loadCustomerDetail(this.selectedCustomer.id);
                this.loadOrderItems(this.selectedCustomer.id);
                this.loadProducts(); // 刷新庫存
            } else {
                this.addMessage('添加商品失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('添加商品失敗: ' + error.message, 'error');
        }
    }

    async confirmCheckout() {
        if (!this.isAuthenticated) {
            this.addMessage('請先登入以進行結賬', 'warning');
            return;
        }

        if (!this.selectedCustomer) {
            return;
        }

        const paymentMethod = "cash";

        try {
            const response = await this.fetchWithAuth('/api/cashier/checkout', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    customer_id: this.selectedCustomer.id,
                    payment_method: paymentMethod
                })
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage(`結賬成功: 桌號 ${result.table_number}, 金額: $${result.total_amount}`, 'success');
                this.hideCheckoutModal();
                this.clearSelectedCustomer();
                this.loadCustomers();
                this.loadTodayStats();
                this.loadTodayCheckoutRecords();
            } else {
                this.addMessage('結賬失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('結賬失敗: ' + error.message, 'error');
        }
    }

    async loadOrderItems(customerId) {
        console.log(`[EnhancedCashier] loadOrderItems called for customer: ${customerId}`);
        try {
            await super.loadOrderItems(customerId);
            console.log(`[EnhancedCashier] loadOrderItems completed, currentOrderItems count: ${this.currentOrderItems ? this.currentOrderItems.length : 0}`);

            // 複製訂單項目到模態框
            this.syncOrderItemsToModal();
            this.addOrderItemClickHandlers();
        } catch (error) {
            console.error(`[EnhancedCashier] loadOrderItems error:`, error);
            throw error;
        }
    }

    // 同步訂單項目到模態框
    syncOrderItemsToModal() {
        const originalOrderItems = document.getElementById('order-items');
        const modalOrderItems = document.getElementById('modal-order-items');

        if (originalOrderItems && modalOrderItems) {
            // 複製HTML內容
            modalOrderItems.innerHTML = originalOrderItems.innerHTML;

            // 為模態框中的刪除按鈕綁定事件
            const modalRemoveButtons = modalOrderItems.querySelectorAll('.order-item-remove');
            modalRemoveButtons.forEach(button => {
                // 獲取訂單項目ID
                const orderItemId = button.getAttribute('data-order-item-id');
                if (orderItemId) {
                    // 克隆按鈕以移除任何現有的事件監聽器
                    const newButton = button.cloneNode(true);
                    button.parentNode.replaceChild(newButton, button);

                    // 為新按鈕綁定點擊事件
                    newButton.addEventListener('click', (e) => {
                        e.stopPropagation();
                        this.removeOrderItem(orderItemId);
                    });
                } else {
                    console.warn('模態框刪除按鈕缺少 data-order-item-id 屬性', button);
                }
            });

            // 更新模態框訂單總計
            const originalItemCount = document.getElementById('item-count');
            const originalOrderTotal = document.getElementById('order-total');
            const modalItemCount = document.getElementById('modal-item-count');
            const modalOrderTotal = document.getElementById('modal-order-total');

            if (originalItemCount && modalItemCount) {
                modalItemCount.textContent = originalItemCount.textContent;
            }
            if (originalOrderTotal && modalOrderTotal) {
                modalOrderTotal.textContent = originalOrderTotal.textContent;
            }
        }
    }

    // 為訂單項目添加點擊更改數量的事件
    addOrderItemClickHandlers() {
        this._attachOrderItemClickHandler('order-items');
        this._attachOrderItemClickHandler('modal-order-items');
    }

    _attachOrderItemClickHandler(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;

        container.querySelectorAll('.order-item').forEach(el => {
            if (el.dataset.qtyHandler === 'true') return;
            el.dataset.qtyHandler = 'true';

            el.addEventListener('click', (e) => {
                // 刪除按鈕已有 stopPropagation，不會觸發此事件
                const removeBtn = el.querySelector('.order-item-remove');
                if (!removeBtn) return;
                const orderItemId = removeBtn.dataset.orderItemId;
                if (orderItemId) {
                    this.showOrderItemQtyModal(orderItemId);
                }
            });
        });
    }

    // 顯示修改商品購買模態框（數量 + 立減 + 折扣優惠）
    showOrderItemQtyModal(orderItemId) {
        const item = this.currentOrderItems.find(i => String(i.id) === String(orderItemId));
        if (!item) {
            this.addMessage('找不到訂單項目', 'error');
            return;
        }

        const modal = document.getElementById('order-item-qty-modal');
        if (!modal) return;

        // 設置商品資訊
        const nameEl = document.getElementById('order-item-qty-product-name');
        const currentPriceEl = document.getElementById('order-item-current-price');
        const currentQtyEl = document.getElementById('order-item-current-qty');
        const inputEl = document.getElementById('order-item-qty-input');
        const errorEl = document.getElementById('order-item-qty-error');
        const confirmBtn = document.getElementById('order-item-qty-confirm');
        const cancelBtn = document.getElementById('order-item-qty-cancel');
        const closeBtn = document.getElementById('order-item-qty-modal-close');
        const deleteBtn = document.getElementById('order-item-qty-delete');
        const flatDiscountEl = document.getElementById('order-item-flat-discount');
        const percentDiscountEl = document.getElementById('order-item-percent-discount');
        const originalPriceDisplay = document.getElementById('order-item-original-price-display');
        const effectivePriceEl = document.getElementById('order-item-effective-price');
        const qtyUpBtn = document.getElementById('order-item-qty-up');
        const qtyDownBtn = document.getElementById('order-item-qty-down');

        if (!nameEl || !inputEl || !errorEl || !confirmBtn || !cancelBtn) return;

        // 重置狀態
        let resolved = false;
        const unitPrice = item.price_at_time || 0;
        const currentFlatDiscount = item.flat_discount || 0;
        const currentPercentDiscount = item.percent_discount || 0;

        nameEl.textContent = item.product_name || '商品';
        if (currentPriceEl) currentPriceEl.textContent = unitPrice.toFixed(1);
        if (currentQtyEl) currentQtyEl.textContent = item.quantity;
        inputEl.value = item.quantity;
        if (flatDiscountEl) flatDiscountEl.value = currentFlatDiscount > 0 ? String(currentFlatDiscount) : '';
        if (percentDiscountEl) percentDiscountEl.value = currentPercentDiscount > 0 ? String(currentPercentDiscount) : '';
        errorEl.style.display = 'none';
        modal.dataset.orderItemId = orderItemId;

        // 計算有效單價
        const calcEffectivePrice = () => {
            const flatVal = parseFloat(flatDiscountEl?.value) || 0;
            const pctVal = parseFloat(percentDiscountEl?.value) || 0;
            if (flatVal < 0 || pctVal < 0) return unitPrice;
            let effective = unitPrice - flatVal;
            if (pctVal > 0) {
                effective = effective * (100 - pctVal) / 100;
            }
            return Math.max(0, effective);
        };

        // 更新價格預覽
        const updatePricePreview = () => {
            if (originalPriceDisplay) originalPriceDisplay.textContent = unitPrice.toFixed(1);
            if (effectivePriceEl) effectivePriceEl.textContent = calcEffectivePrice().toFixed(1);
        };

        updatePricePreview();

        // 上下箭頭調整數量
        const onQtyUp = () => {
            let val = parseInt(inputEl.value) || 0;
            inputEl.value = val + 1;
        };
        const onQtyDown = () => {
            let val = parseInt(inputEl.value) || 0;
            if (val > 1) inputEl.value = val - 1;
        };

        // 顯示模態框
        modal.style.display = 'flex';
        modal.classList.remove('hidden');

        const cleanup = () => {
            if (resolved) return;
            resolved = true;
            modal.style.display = 'none';
            modal.classList.add('hidden');
            confirmBtn.removeEventListener('click', onConfirm);
            cancelBtn.removeEventListener('click', onCancel);
            if (closeBtn) closeBtn.removeEventListener('click', onCancel);
            if (deleteBtn) deleteBtn.removeEventListener('click', onDelete);
            inputEl.removeEventListener('keydown', onKeydown);
            if (flatDiscountEl) flatDiscountEl.removeEventListener('input', updatePricePreview);
            if (percentDiscountEl) percentDiscountEl.removeEventListener('input', updatePricePreview);
            const giftBtnClean = document.getElementById('order-item-gift-btn');
            if (giftBtnClean) giftBtnClean.removeEventListener('click', onGift);
            if (qtyUpBtn) qtyUpBtn.removeEventListener('click', onQtyUp);
            if (qtyDownBtn) qtyDownBtn.removeEventListener('click', onQtyDown);
            modal.removeEventListener('click', onBackdropClick);
        };

        const onKeydown = (e) => {
            if (e.key === 'Enter') onConfirm();
        };

        const onConfirm = () => {
            const val = inputEl.value.trim();
            const qty = parseInt(val);
            if (!val || isNaN(qty) || qty < 1) {
                errorEl.textContent = '請輸入有效的數量（至少為 1）';
                errorEl.style.display = 'block';
                return;
            }

            const flatVal = flatDiscountEl ? (parseFloat(flatDiscountEl.value) || 0) : 0;
            const pctVal = percentDiscountEl ? (parseFloat(percentDiscountEl.value) || 0) : 0;

            if (flatVal < 0 || pctVal < 0) {
                errorEl.textContent = '折扣不能為負數';
                errorEl.style.display = 'block';
                return;
            }
            if (flatVal > 0 && flatVal >= unitPrice) {
                errorEl.textContent = '立減金額不能大於或等於單價';
                errorEl.style.display = 'block';
                return;
            }
            if (pctVal > 100) {
                errorEl.textContent = '折扣百分比不能超過 100%';
                errorEl.style.display = 'block';
                return;
            }

            cleanup();
            this.updateOrderItemQuantity(orderItemId, qty, flatVal, pctVal);
        };

        const onCancel = () => {
            cleanup();
        };

        const onDelete = () => {
            cleanup();
            this.removeOrderItem(orderItemId);
        };

        confirmBtn.addEventListener('click', onConfirm);
        cancelBtn.addEventListener('click', onCancel);
        if (closeBtn) closeBtn.addEventListener('click', onCancel);
        if (deleteBtn) deleteBtn.addEventListener('click', onDelete);

        // Enter 鍵確認
        inputEl.addEventListener('keydown', onKeydown);

        // 折扣輸入變更即時更新預覽
        if (flatDiscountEl) flatDiscountEl.addEventListener('input', updatePricePreview);
        if (percentDiscountEl) percentDiscountEl.addEventListener('input', updatePricePreview);

        // 贈送按鈕：設定 100% 折扣
        const giftBtn = document.getElementById('order-item-gift-btn');
        const onGift = () => {
            if (percentDiscountEl) {
                percentDiscountEl.value = '100';
                updatePricePreview();
            }
        };
        if (giftBtn) giftBtn.addEventListener('click', onGift);
        if (qtyUpBtn) qtyUpBtn.addEventListener('click', onQtyUp);
        if (qtyDownBtn) qtyDownBtn.addEventListener('click', onQtyDown);

        // 點擊 modal 背景關閉（僅在點擊 backdrop 時觸發）
        const onBackdropClick = (e) => {
            if (e.target === modal) onCancel();
        };
        modal.addEventListener('click', onBackdropClick);

        // 聚焦輸入框
        setTimeout(() => inputEl.focus(), 200);
    }

    // 更新訂單商品購買（數量 + 立減 + 折扣優惠，含敏感操作記錄）
    async updateOrderItemQuantity(orderItemId, newQuantity, flatDiscount, percentDiscount) {
        if (!this.isAuthenticated) {
            this.addMessage('請先登入以修改商品購買', 'warning');
            return;
        }

        try {
            const body = { quantity: newQuantity };
            if (flatDiscount !== undefined || percentDiscount !== undefined) {
                body.flat_discount = flatDiscount || 0;
                body.percent_discount = percentDiscount || 0;
            }

            const response = await this.fetchWithAuth(`/api/cashier/order-item/${orderItemId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage('商品購買已更新', 'success');
                if (this.selectedCustomer) {
                    await this.loadCustomerDetail(this.selectedCustomer.id);
                    await this.loadOrderItems(this.selectedCustomer.id);
                    await this.loadProducts();
                    await this.loadCustomers();
                }
            } else {
                this.addMessage('更新失敗: ' + (result.error || result.message || '未知錯誤'), 'error');
            }
        } catch (error) {
            console.error('更新錯誤:', error);
            this.addMessage('更新失敗: ' + error.message, 'error');
        }
    }

    async removeOrderItem(orderItemId) {
        console.log(`[EnhancedCashier] removeOrderItem called: ${orderItemId}, selectedCustomer: ${this.selectedCustomer ? this.selectedCustomer.id : 'none'}`);

        if (!this.isAuthenticated) {
            this.addMessage('請先登入以移除訂單項目', 'warning');
            return;
        }

        if (!confirm('確定要移除這個項目嗎？')) {
            return;
        }

        try {
            console.log(`[EnhancedCashier] Sending DELETE request for order item: ${orderItemId}`);
            const response = await this.fetchWithAuth(`/api/cashier/order-item/${orderItemId}`, {
                method: 'DELETE'
            });

            const result = await response.json();
            console.log(`[EnhancedCashier] DELETE response:`, { success: result.success, message: result.message, error: result.error });

            if (result.success) {
                this.addMessage('已移除訂單項目', 'success');
                if (this.selectedCustomer) {
                    console.log(`[EnhancedCashier] Refreshing data for customer: ${this.selectedCustomer.id}`);
                    await this.loadCustomerDetail(this.selectedCustomer.id);
                    await this.loadOrderItems(this.selectedCustomer.id);
                    await this.loadProducts(); // 刷新庫存
                    await this.loadCustomers(); // 刷新在場客人列表
                    console.log(`[EnhancedCashier] Data refresh completed`);
                } else {
                    console.warn(`[EnhancedCashier] No selected customer after successful delete`);
                }
            } else {
                this.addMessage('移除項目失敗: ' + result.error, 'error');
            }
        } catch (error) {
            console.error(`[EnhancedCashier] removeOrderItem error:`, error);
            this.addMessage('移除項目失敗: ' + error.message, 'error');
        }
    }

    async clearOrder() {
        if (!this.isAuthenticated) {
            this.addMessage('請先登入以清空訂單', 'warning');
            return;
        }

        if (!this.selectedCustomer || this.currentOrderItems.length === 0) {
            return;
        }

        if (!confirm('確定要清空當前訂單嗎？這將移除所有已添加的商品。')) {
            return;
        }

        // 逐一刪除所有訂單項目
        const deletePromises = this.currentOrderItems.map(item =>
            this.fetchWithAuth(`/api/cashier/order-item/${item.id}`, { method: 'DELETE' })
        );

        Promise.all(deletePromises)
            .then(() => {
                this.addMessage('訂單已清空', 'success');
                this.loadCustomerDetail(this.selectedCustomer.id);
                this.loadOrderItems(this.selectedCustomer.id);
                this.loadProducts();
                this.loadCustomers();
            })
            .catch(error => {
                this.addMessage('清空訂單失敗: ' + error.message, 'error');
            });
    }

    async reprintQRCode() {
        if (!this.isAuthenticated) {
            this.addMessage('請先登入以重新打印QR Code', 'warning');
            return;
        }

        if (!this.selectedCustomer) {
            this.addMessage('請先選擇客人', 'warning');
            return;
        }

        try {
            const response = await this.fetchWithAuth(`/api/cashier/customer/${this.selectedCustomer.id}/reprint-qr`, {
                method: 'POST'
            });
            const result = await response.json();

            if (result.success) {
                this.addMessage('QR Code小票已重新打印', 'success');
            } else {
                this.addMessage('重新打印失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('重新打印失敗: ' + error.message, 'error');
        }
    }

    // 設備控制方法
    async deviceRequest(url, method = 'POST') {
        if (!this.isAuthenticated) {
            this.addMessage('請先登入以使用設備控制', 'warning');
            throw new Error('未授權');
        }

        const response = await this.fetchWithAuth(url, { method });
        return response.json();
    }

    async testPrinter() {
        try {
            const result = await this.deviceRequest('/api/cashier/test-printer');
            if (result.success) {
                this.addMessage('打印機測試成功', 'success');
            } else {
                this.addMessage('打印機測試失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('打印機測試失敗: ' + error.message, 'error');
        }
    }

    async resetPrinter() {
        try {
            const result = await this.deviceRequest('/api/cashier/reset-printer');
            if (result.success) {
                this.addMessage('打印機已重設', 'success');
            } else {
                this.addMessage('打印機重設失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('打印機重設失敗: ' + error.message, 'error');
        }
    }

    async testLocker() {
        try {
            const result = await this.deviceRequest('/api/cashier/test-locker');
            if (result.success) {
                this.addMessage('儲物柜測試成功', 'success');
            } else {
                this.addMessage('儲物柜測試失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('儲物柜測試失敗: ' + error.message, 'error');
        }
    }

    async resetLocker() {
        try {
            const result = await this.deviceRequest('/api/cashier/reset-locker');
            if (result.success) {
                this.addMessage('儲物柜已重設', 'success');
            } else {
                this.addMessage('儲物柜重設失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('儲物柜重設失敗: ' + error.message, 'error');
        }
    }

    async openDoorLock() {
        try {
            const result = await this.deviceRequest('/api/cashier/open-doorlock');
            if (result.success) {
                this.addMessage('門鎖已開啟', 'success');
            } else {
                this.addMessage('門鎖開啟失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('門鎖開啟失敗: ' + error.message, 'error');
        }
    }

    async closeDoorLock() {
        try {
            const result = await this.deviceRequest('/api/cashier/close-doorlock');
            if (result.success) {
                this.addMessage('門鎖已關閉', 'success');
            } else {
                this.addMessage('門鎖關閉失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('門鎖關閉失敗: ' + error.message, 'error');
        }
    }

    async testAudio() {
        try {
            const result = await this.deviceRequest('/api/cashier/test-audio');
            if (result.success) {
                this.addMessage('音響測試成功', 'success');
            } else {
                this.addMessage('音響測試失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('音響測試失敗: ' + error.message, 'error');
        }
    }

    async stopAudio() {
        try {
            const result = await this.deviceRequest('/api/cashier/stop-audio');
            if (result.success) {
                this.addMessage('音響已停止', 'success');
            } else {
                this.addMessage('音響停止失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('音響停止失敗: ' + error.message, 'error');
        }
    }

    async testNFC() {
        try {
            const result = await this.deviceRequest('/api/cashier/test-nfc');
            if (result.success) {
                this.addMessage('NFC讀卡器測試成功', 'success');
            } else {
                this.addMessage('NFC讀卡器測試失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('NFC讀卡器測試失敗: ' + error.message, 'error');
        }
    }

    async resetNFC() {
        try {
            const result = await this.deviceRequest('/api/cashier/reset-nfc');
            if (result.success) {
                this.addMessage('NFC讀卡器已重設', 'success');
            } else {
                this.addMessage('NFC讀卡器重設失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('NFC讀卡器重設失敗: ' + error.message, 'error');
        }
    }

    syncCategoryTabs() {
        const categoryFilter = document.getElementById('product-category-filter');
        if (!categoryFilter) return;

        const selectedCategory = categoryFilter.value;
        const categoryTabButtons = document.querySelectorAll('.category-tab-button');

        // 更新標籤的active狀態
        categoryTabButtons.forEach(button => {
            if (button.dataset.category === selectedCategory) {
                button.classList.add('active');
            } else {
                button.classList.remove('active');
            }
        });
    }

    // 覆蓋刪除桌號顯示方法 — 加入員工選擇
    showDeleteTableModal() {
        if (!this.selectedCustomer) {
            return;
        }

        // 填入桌號、人數、入場時間
        document.getElementById('delete-table-number').textContent = this.selectedCustomer.table_number;
        document.getElementById('delete-table-people').textContent = `${this.selectedCustomer.people_count}位`;

        const entryTime = this.parseEntryTime(this.selectedCustomer.entry_time).toLocaleString('zh-TW', {
            hour: '2-digit',
            minute: '2-digit'
        });
        document.getElementById('delete-table-entry-time').textContent = entryTime;

        // 重置並禁用確認按鈕
        const confirmBtn = document.getElementById('confirm-delete-table-btn');
        if (confirmBtn) confirmBtn.disabled = true;

        // 綁定員工選擇事件（用 onchange 避免監聽器重複）
        const select = document.getElementById('delete-employee-select');
        if (select) {
            select.onchange = (e) => {
                const btn = document.getElementById('confirm-delete-table-btn');
                if (btn) btn.disabled = !e.target.value;
            };
        }

        // 重置錯誤訊息
        const errorDiv = document.getElementById('delete-table-error');
        if (errorDiv) errorDiv.style.display = 'none';

        // 載入員工名單
        this.loadDeleteEmployees();

        // 顯示模態框
        document.getElementById('delete-table-modal').classList.remove('hidden');
    }

    hideDeleteTableModal() {
        const modal = document.getElementById('delete-table-modal');
        if (modal) {
            modal.classList.add('hidden');
            // 重置表單
            const select = document.getElementById('delete-employee-select');
            if (select) {
                select.value = '';
                select.onchange = null;
            }
            const confirmBtn = document.getElementById('confirm-delete-table-btn');
            if (confirmBtn) confirmBtn.disabled = true;
            const errorDiv = document.getElementById('delete-table-error');
            if (errorDiv) errorDiv.style.display = 'none';
        }
    }

    async loadDeleteEmployees() {
        const select = document.getElementById('delete-employee-select');
        const loading = document.getElementById('delete-employee-loading');
        const empty = document.getElementById('delete-employee-empty');
        if (!select) return;

        select.style.display = 'none';
        loading.style.display = 'block';
        empty.style.display = 'none';

        try {
            const response = await this.fetchWithAuth('/api/store-employees');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const result = await response.json();

            loading.style.display = 'none';
            select.style.display = '';

            if (result.success && result.data && result.data.length > 0) {
                select.innerHTML = '<option value="">-- 請選擇員工 --</option>';
                result.data.forEach(emp => {
                    const option = document.createElement('option');
                    option.value = emp.staff_name;
                    option.textContent = emp.staff_name;
                    select.appendChild(option);
                });
            } else {
                empty.style.display = 'block';
                select.style.display = 'none';
            }
        } catch (err) {
            console.error('載入員工名單錯誤:', err);
            loading.style.display = 'none';
            select.style.display = '';
            empty.style.display = 'block';
            empty.textContent = '載入員工名單失敗: ' + err.message;
        }
    }

    // 覆蓋刪除桌號確認方法以處理模擬顧客 + 員工選擇
    async confirmDeleteTable() {
        if (!this.selectedCustomer) {
            return;
        }

        // 防止重複執行
        if (this._deletingCustomer) {
            console.log('刪除操作正在進行中，跳過重複調用');
            return;
        }

        // 檢查是否已選擇員工
        const employeeSelect = document.getElementById('delete-employee-select');
        const employeeName = employeeSelect?.value;
        const errorDiv = document.getElementById('delete-table-error');

        if (!employeeName) {
            if (errorDiv) {
                errorDiv.textContent = '請選擇刪除員工';
                errorDiv.style.display = 'block';
            }
            return;
        }

        // 確認按鈕進入 loading 狀態
        const confirmBtn = document.getElementById('confirm-delete-table-btn');
        if (confirmBtn) {
            confirmBtn.disabled = true;
            confirmBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 處理中...';
        }
        if (errorDiv) errorDiv.style.display = 'none';

        try {
            this._deletingCustomer = true;

            // 檢查是否為模擬顧客
            if (this.selectedCustomer.id.startsWith('mock-customer-')) {
                // 處理模擬顧客刪除
                const tableNumber = this.selectedCustomer.table_number;

                // 從模擬顧客列表中移除
                this.mockCustomers = this.mockCustomers.filter(customer => customer.id !== this.selectedCustomer.id);

                // 更新客人列表
                await this.loadCustomers();

                // 隱藏模態框
                this.hideDeleteTableModal();

                // 清除選中的顧客
                this.clearSelectedCustomer();

                // 顯示成功訊息
                this.addMessage(`已刪除模擬桌號 ${tableNumber}`, 'success');

                // 更新今日統計
                this.loadTodayStats();
            } else {
                // 自己實現真實顧客刪除邏輯，確保只有一個請求
                try {
                    // 保存顧客信息，防止在異步操作期間被清除
                    const customerId = this.selectedCustomer.id;
                    const tableNumber = this.selectedCustomer.table_number;

                    // 構建查詢參數
                    const params = new URLSearchParams();
                    if (this.selectedStoreId) {
                        params.append('store_id', this.selectedStoreId);
                    }

                    const url = `/api/cashier/customer/${customerId}${params.toString() ? '?' + params.toString() : ''}`;

                    // 構建headers，包含身份驗證令牌
                    const headers = {
                        'Content-Type': 'application/json'
                    };

                    // 如果存在currentToken，添加Authorization header
                    if (this.currentToken) {
                        headers['Authorization'] = `Bearer ${this.currentToken}`;
                    }

                    console.log(`發送刪除請求: ${url}`, `員工: ${employeeName}`);
                    const response = await fetch(url, {
                        method: 'DELETE',
                        headers: headers,
                        body: JSON.stringify({ employeeName: employeeName })
                    });

                    const result = await response.json();

                    if (result.success) {
                        this.addMessage(`已刪除桌號 ${tableNumber}`, 'success');
                        // 觸發Socket事件通知客戶端更新
                        const io = window.io; // 假設Socket.IO全局可用
                        if (io && typeof io.emit === 'function') {
                            try {
                                io.emit('customer-deleted', {
                                    customer_id: customerId,
                                    table_number: tableNumber
                                });
                            } catch (ioError) {
                                console.log('Socket.IO事件觸發失敗，但不影響刪除操作:', ioError);
                            }
                        } else {
                            console.log('Socket.IO未啟用或io.emit不可用，跳過事件觸發');
                        }
                        // 刪除成功，清除選中狀態並關閉客人詳情模態框
                        this.clearSelectedCustomer();
                    } else {
                        throw new Error(result.error || result.message || '刪除桌號失敗');
                    }
                } catch (error) {
                    console.error('刪除真實顧客失敗:', error);
                    if (errorDiv) {
                        errorDiv.textContent = '刪除桌號失敗: ' + error.message;
                        errorDiv.style.display = 'block';
                    }
                    // 恢復按鈕狀態
                    if (confirmBtn) {
                        confirmBtn.disabled = false;
                        confirmBtn.innerHTML = '<span data-i18n="confirmDeleteTableBtn">確認刪除</span>';
                    }
                } finally {
                    // 無論成功與否，都隱藏刪除確認模態框並更新數據
                    this.hideDeleteTableModal();
                    // 更新客人列表和統計
                    this.loadCustomers();
                    this.loadTodayStats();
                }
            }
        } finally {
            this._deletingCustomer = false;
        }
    }

    // 重寫員工登入方法以使用新的實現
    staffLogin() {
        this.showLoginModal();
    }

    // ============ 購物車功能 ============

    // 添加商品到購物車
    async addToCart(productId) {
        try {
            console.log('addToCart called with productId:', productId, 'type:', typeof productId);
            console.log('productsList IDs (first 5):', this.productsList.slice(0, 5).map(p => ({id: p.id, type: typeof p.id, name: p.name})));
            console.log('products IDs (first 5):', this.products.slice(0, 5).map(p => ({id: p.id, type: typeof p.id, name: p.name})));

            // 獲取商品詳情 - 使用寬鬆比較處理數字/字符串ID
            const product = this.productsList.find(p => p.id == productId) ||
                           this.products.find(p => p.id == productId);

            console.log('Found product:', product ? {
                id: product.id,
                name: product.name,
                stock: product.stock,
                track_inventory: product.track_inventory
            } : 'null', 'productsList length:', this.productsList.length, 'products length:', this.products.length);

            if (!product) {
                console.log('Product not found in productsList or products');
                this.addMessage('商品不存在', 'error');
                return;
            }

            // 檢查庫存（僅當 track_inventory = 1 時）
            const trackInventory = product.track_inventory !== undefined ? product.track_inventory : 1;
            if (trackInventory === 1 && product.stock <= 0) {
                this.addMessage('商品庫存不足', 'warning');
                return;
            }

            // 檢查購物車中是否已有該商品（使用寬鬆比較處理數字/字符串ID）
            const existingItemIndex = this.shoppingCart.findIndex(item => item.productId == productId);

            if (existingItemIndex >= 0) {
                // 如果商品已存在，增加數量
                this.shoppingCart[existingItemIndex].quantity += 1;
                const effPrice = this.shoppingCart[existingItemIndex].effectivePrice || this.shoppingCart[existingItemIndex].price;
                this.shoppingCart[existingItemIndex].subtotal =
                    this.shoppingCart[existingItemIndex].quantity * effPrice;
            } else {
                // 添加新商品到購物車
                this.shoppingCart.push({
                    productId: product.id,
                    name: product.name,
                    price: product.price,
                    quantity: 1,
                    flatDiscount: 0,
                    percentDiscount: 0,
                    effectivePrice: product.price,
                    subtotal: product.price
                });
            }

            // 更新購物車總計
            this.calculateCartTotals();

            // 更新購物車顯示
            this.updateCartDisplay();

            // 顯示成功訊息
            this.addMessage(`已將 ${product.name} 添加到購物車`, 'success');

        } catch (error) {
            this.addMessage(`添加到購物車失敗: ${error.message}`, 'error');
        }
    }

    // 從購物車移除商品
    removeFromCart(productId, quantity = 1) {
        const existingItemIndex = this.shoppingCart.findIndex(item => item.productId === productId);

        if (existingItemIndex < 0) {
            this.addMessage('購物車中沒有此商品', 'warning');
            return;
        }

        if (quantity >= this.shoppingCart[existingItemIndex].quantity) {
            // 移除整個商品
            this.shoppingCart.splice(existingItemIndex, 1);
        } else {
            // 減少數量
            this.shoppingCart[existingItemIndex].quantity -= quantity;
            this.shoppingCart[existingItemIndex].subtotal =
                this.shoppingCart[existingItemIndex].quantity * this.shoppingCart[existingItemIndex].price;
        }

        // 更新購物車總計
        this.calculateCartTotals();

        // 更新購物車顯示
        this.updateCartDisplay();

        this.addMessage('已更新購物車', 'info');
    }

    // 計算購物車總計
    calculateCartTotals() {
        this.cartTotalItems = this.shoppingCart.reduce((total, item) => total + item.quantity, 0);
        this.cartTotalAmount = this.shoppingCart.reduce((total, item) => total + item.subtotal, 0);
    }

    // 更新購物車顯示
    updateCartDisplay() {
        const cartItemsContainer = document.getElementById('cart-items');
        const cartTotalItemsElement = document.getElementById('cart-total-items');
        const cartTotalAmountElement = document.getElementById('cart-total-amount');
        const cartCheckoutBtn = document.getElementById('cart-checkout-btn');
        const cartClearBtn = document.getElementById('cart-clear-btn');

        if (!cartItemsContainer) return;

        // 更新總計顯示
        if (cartTotalItemsElement) {
            cartTotalItemsElement.textContent = this.cartTotalItems;
        }
        if (cartTotalAmountElement) {
            cartTotalAmountElement.textContent = `$${this.cartTotalAmount.toFixed(2)}`;
        }

        // 更新結賬按鈕狀態
        if (cartCheckoutBtn) {
            cartCheckoutBtn.disabled = this.cartTotalItems === 0;
        }

        // 清空按鈕事件綁定
        if (cartClearBtn) {
            // 移除舊的事件監聽器
            const newCartClearBtn = cartClearBtn.cloneNode(true);
            cartClearBtn.parentNode.replaceChild(newCartClearBtn, cartClearBtn);
            newCartClearBtn.addEventListener('click', () => this.clearCart());
        }

        // 如果購物車為空，顯示空狀態
        if (this.shoppingCart.length === 0) {
            cartItemsContainer.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-shopping-cart"></i>
                    <p data-i18n="emptyStateCart">購物車是空的</p>
                </div>
            `;
            return;
        }

        // 生成購物車項目列表
        let cartHTML = '';
        this.shoppingCart.forEach((item, index) => {
            const effPrice = item.effectivePrice || item.price;
            const showDiscount = (item.flatDiscount > 0 || item.percentDiscount > 0);
            const priceHtml = showDiscount
                ? `<span class="cart-item-effective-price" style="font-weight:700;color:#e74c3c;">$${effPrice.toFixed(2)}</span> <span class="cart-item-original-price" style="text-decoration:line-through;color:#999;font-size:0.85em;">$${item.price.toFixed(2)}</span>`
                : `<span class="cart-item-price">$${item.price.toFixed(2)}</span>`;
            cartHTML += `
                <div class="cart-item" data-product-id="${item.productId}">
                    <div class="cart-item-info">
                        <div class="cart-item-name">${item.name}</div>
                    </div>
                    <div class="cart-item-controls">
                        <div class="cart-item-price-quantity">
                            ${priceHtml}
                            <div class="cart-item-quantity-display">${item.quantity}</div>
                        </div>
                        <button class="cart-item-action-btn" data-index="${index}">
                            <i class="fas ${item.quantity > 1 ? 'fa-minus' : 'fa-trash'}"></i>
                        </button>
                    </div>
                </div>
            `;
        });

        cartItemsContainer.innerHTML = cartHTML;

        // 綁定操作按鈕事件
        cartItemsContainer.querySelectorAll('.cart-item-action-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = parseInt(e.currentTarget.dataset.index);
                if (this.shoppingCart[index].quantity > 1) {
                    // 減少數量
                    this.shoppingCart[index].quantity -= 1;
                    const effPrice = this.shoppingCart[index].effectivePrice || this.shoppingCart[index].price;
                    this.shoppingCart[index].subtotal = this.shoppingCart[index].quantity * effPrice;
                    this.calculateCartTotals();
                    this.updateCartDisplay();
                } else {
                    // 移除商品
                    this.removeFromCart(this.shoppingCart[index].productId);
                }
            });
        });
    }

    // 清空購物車
    clearCart(showConfirm = true) {
        if (this.shoppingCart.length === 0) {
            this.addMessage('購物車已經是空的', 'info');
            return;
        }

        let shouldClear = true;
        if (showConfirm) {
            shouldClear = confirm('確定要清空購物車嗎？');
        }

        if (shouldClear) {
            this.shoppingCart = [];
            this.calculateCartTotals();
            this.updateCartDisplay();

            // 如果處於掛單等待狀態，重置狀態
            if (this.isPendingSuspend) {
                this.isPendingSuspend = false;
                this.addMessage('掛單操作已取消（購物車已清空）', 'info');
            } else {
                this.addMessage('購物車已清空', 'success');
            }
        }
    }

    // 購物車結賬 - 顯示確認模態框
    async checkoutCart() {
        console.log('checkoutCart called');
        console.log('shoppingCart length:', this.shoppingCart.length);
        console.log('selectedCustomer:', this.selectedCustomer);

        // 檢查購物車是否為空
        if (this.shoppingCart.length === 0) {
            this.addMessage('購物車是空的，無法結賬', 'warning');
            return;
        }

        // 顯示結賬確認模態框
        this.showCheckoutModal();
    }

    // 有桌號結賬（原有流程）
    async checkoutWithTable() {
        console.log('checkoutWithTable called');
        const targetCustomer = this.selectedCustomer;

        if (!targetCustomer) {
            this.addMessage('請先選擇桌號', 'error');
            return;
        }

        // 將購物車商品添加到當前訂單（批量處理，每個商品調用一次）
        for (const cartItem of this.shoppingCart) {
            // 調用addProductToOrder並傳遞數量
            await this.addProductToOrder(cartItem.productId, cartItem.quantity);
        }

        // 執行結賬
        console.log('執行有桌號結賬，客戶ID:', targetCustomer.id);
        try {
            const response = await this.fetchWithAuth('/api/cashier/checkout', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ customer_id: targetCustomer.id })
            });

            const result = await response.json();
            if (result.success) {
                // 清空購物車（結賬時不需要確認）
                this.clearCart(false);
                this.addMessage('結賬成功！', 'success');
                console.log('有桌號結賬成功:', result);
            } else {
                throw new Error(result.error || '結賬失敗');
            }
        } catch (error) {
            console.error('有桌號結賬API調用失敗:', error);
            this.addMessage(`結賬失敗: ${error.message}`, 'error');
            // 不清空購物車，讓用戶可以重試
            throw error; // 重新拋出以便外部處理
        }
    }

    // 無桌號獨立結賬（使用新API）
    async checkoutNoTable() {
        console.log('checkoutNoTable called');
        this.addMessage('正在處理無桌號結賬...', 'info');

        // 準備商品數據
        const items = this.shoppingCart.map(item => ({
            product_id: item.productId,
            quantity: item.quantity
        }));

        // 計算人數：統計購物車中「首小時」「全日通」商品的數量總和
        const peopleCount = this.shoppingCart.reduce((count, item) => {
            if (item.name && (item.name.startsWith('首小時') || item.name.startsWith('全日通'))) {
                return count + item.quantity;
            }
            return count;
        }, 0);

        const requestData = {
            items: items,
            peopleCount: peopleCount,
            memberCardId: null
        };

        console.log('發送無桌號結賬請求:', requestData);

        try {
            const response = await this.fetchWithAuth('/api/cashier/no-table-checkout', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(requestData)
            });

            const result = await response.json();
            console.log('無桌號結賬API響應:', result);

            if (result.success) {
                console.log('無桌號結賬成功:', result);

                // 如果有折扣的購物車商品，更新已創建訂單項目的折扣
                const discountedItems = this.shoppingCart.filter(ci => ci.flatDiscount > 0 || ci.percentDiscount > 0);
                if (discountedItems.length > 0 && result.order_items && Array.isArray(result.order_items)) {
                    console.log('無桌號結賬檢測到折扣商品，更新對應 order_item 折扣');
                    for (const cartItem of discountedItems) {
                        const orderItem = result.order_items.find(oi => String(oi.product_id) === String(cartItem.productId));
                        if (orderItem && orderItem.id) {
                            const updateBody = {
                                quantity: orderItem.quantity || cartItem.quantity
                            };
                            if (cartItem.flatDiscount > 0) updateBody.flat_discount = cartItem.flatDiscount;
                            if (cartItem.percentDiscount > 0) updateBody.percent_discount = cartItem.percentDiscount;
                            try {
                                const updateRes = await this.fetchWithAuth(`/api/cashier/order-item/${orderItem.id}`, {
                                    method: 'PUT',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify(updateBody)
                                });
                                const updateResult = await updateRes.json();
                                if (updateResult.success) {
                                    console.log(`order_item ${orderItem.id} 折扣已更新:`, updateBody);
                                } else {
                                    console.warn(`更新 order_item ${orderItem.id} 折扣失敗:`, updateResult.error);
                                }
                            } catch (discountErr) {
                                console.warn('更新折扣出錯（不影響結賬）:', discountErr.message);
                            }
                        }
                    }
                }

                // 清空購物車（結賬時不需要確認）
                this.clearCart(false);

                // 觸發刷新今日結賬記錄（如果已打開）
                if (this.currentTab === 'records') {
                    this.loadCheckoutRecords();
                }

                // 觸發刷新今日統計
                this.loadTodayStats();

                // 可選：顯示收據詳情
                if (result.receipt_data) {
                    console.log('收據數據:', result.receipt_data);
                }
            } else {
                throw new Error(result.error || result.message || '無桌號結賬失敗');
            }
        } catch (error) {
            console.error('無桌號結賬API調用失敗:', error);
            this.addMessage(`無桌號結賬失敗: ${error.message}`, 'error');
            // 不清空購物車，讓用戶可以重試
            throw error; // 重新拋出以便外部處理
        }
    }

    // 重寫商品顯示方法以支持購物車
    displayProducts() {
        // 調用父類方法
        super.displayProducts();

        // 修改商品點擊事件：如果當前在商品管理標籤頁，則添加到購物車
        const productItems = document.querySelectorAll('.product-item');
        productItems.forEach(item => {
            if (!item.dataset.productId) return;

            // 移除舊的點擊事件監聽器
            const newItem = item.cloneNode(true);
            item.parentNode.replaceChild(newItem, item);

            // 添加新的點擊事件監聽器
            newItem.addEventListener('click', () => {
                const productId = parseInt(newItem.dataset.productId);

                // 檢查當前標籤頁
                if (this.currentTab === 'products') {
                    // 商品管理標籤頁：添加到購物車
                    this.addToCart(productId);
                } else {
                    // 其他標籤頁：使用原有行為（添加到訂單）
                    this.addProductToOrder(productId);
                }
            });
        });
    }

    // ============ 加單功能 ============

    // 處理加單按鈕點擊
    handleAddOrder() {
        console.log('handleAddOrder called, selectedCustomer:', this.selectedCustomer);
        if (!this.selectedCustomer) {
            this.addMessage('請先選擇桌號', 'warning');
            return;
        }

        // 存儲選中的顧客用於後續掛單
        this.addOrderTargetCustomer = this.selectedCustomer;
        // 更新購物車按鈕狀態（禁用結賬按鈕）
        this.updateCartButtons();

        // 隱藏客人詳情模態框，避免擋住商品選擇
        this.hideCustomerDetailModal();

        // 切換到商品管理標籤頁
        this.switchTab('products');

        this.addMessage(`已切換到商品管理，請選擇商品添加到購物車，然後點擊"掛單"添加到桌號 ${this.selectedCustomer.table_number}`, 'info');
    }

    // ============ 掛單功能 ============

    // 掛單功能（將購物車商品添加到桌號）
    async suspendCart() {
        console.log('suspendCart called, cart items:', this.shoppingCart.length);
        console.log('Current tab:', this.currentTab);
        console.log('isAuthenticated:', this.isAuthenticated);
        console.log('currentToken:', this.currentToken ? '有token' : '無token');

        // 檢查是否已登入
        if (!this.isAuthenticated) {
            console.log('用戶未登入，顯示警告訊息和登入模態框');
            this.addMessage('請先登入員工帳戶以使用掛單功能', 'warning');
            console.log('調用showLoginModal()');
            this.showLoginModal();
            console.log('showLoginModal調用完成，函數返回');
            return;
        }

        // 檢查是否使用模擬商品數據
        console.log('檢查購物車商品，shoppingCart內容:', JSON.stringify(this.shoppingCart));
        const hasMockProducts = this.shoppingCart.some(item => {
            const productIdStr = String(item.productId);
            const isNumericId = /^\d+$/.test(productIdStr); // 檢查是否為純數字字符串
            const id = parseInt(item.productId);
            const isMock = isNumericId && id >= 1 && id <= 13;
            console.log(`商品檢查: ID=${item.productId}, 是否為純數字=${isNumericId}, 轉換為數字=${id}, 是否為模擬商品=${isMock}`);
            return isMock;
        });

        console.log('hasMockProducts結果:', hasMockProducts);

        // 暫時註解掉模擬商品檢測以進行測試
        // if (hasMockProducts) {
        //     console.log('檢測到模擬商品，顯示警告訊息並返回');
        //     this.addMessage('目前使用的是模擬測試商品數據，請先登入系統以使用真實商品進行掛單', 'warning');
        //     return;
        // }

        if (this.shoppingCart.length === 0) {
            this.addMessage('購物車是空的，無法掛單', 'warning');
            return;
        }

        // 檢查是否有加單目標顧客（從加單流程來的）
        console.log('檢查加單目標顧客: addOrderTargetCustomer =', this.addOrderTargetCustomer);
        if (this.addOrderTargetCustomer) {
            console.log('有加單目標顧客:', this.addOrderTargetCustomer.table_number);
            // 加單流程：直接添加到目標桌號，不需要確認
            const cartItemsToAdd = [...this.shoppingCart];
            // 添加到目標桌號
            await this.addCartItemsToCustomer(this.addOrderTargetCustomer.id, cartItemsToAdd);
            // 清空加單目標，避免重複使用
            this.addOrderTargetCustomer = null;
            // 更新購物車按鈕狀態（啟用結賬按鈕）
            this.updateCartButtons();
            // 加單完成後跳轉回「在場客人」頁面（只有當購物車被清空時，表示成功）
            if (this.shoppingCart.length === 0) {
                this.switchTab('dashboard');
            }
            return;
        }

        // 如果有選中桌號，直接確認並掛單
        console.log('檢查選中桌號狀態: selectedCustomer =', this.selectedCustomer);
        if (this.selectedCustomer) {
            console.log('有選中桌號:', this.selectedCustomer.table_number);
            const confirmMessage = `確定要將 ${this.shoppingCart.length} 個商品掛單到桌號 ${this.selectedCustomer.table_number} 嗎？`;
            if (!confirm(confirmMessage)) {
                this.addMessage('已取消掛單操作', 'info');
                return;
            }

            // 保存購物車項目到臨時變量
            const cartItemsToAdd = [...this.shoppingCart];
            // 添加到選中桌號
            await this.addCartItemsToCustomer(this.selectedCustomer.id, cartItemsToAdd);
            return;
        }

        console.log('沒有選中桌號，切換到桌號管理頁面');
        // 如果沒有選中桌號，設置掛單等待狀態並切換到桌號管理頁面
        console.log('設置 isPendingSuspend = true');
        this.isPendingSuspend = true;
        console.log('調用 switchTab("dashboard")');
        this.switchTab('dashboard');
        console.log('switchTab調用完成');
        console.log('顯示提示訊息');
        this.addMessage('請在「在場客人」列表中選擇桌號進行掛單', 'info');
        console.log('suspendCart函數執行完成');
    }

    // 將購物車商品添加到指定顧客
    async addCartItemsToCustomer(customerId, cartItems) {
        console.log('addCartItemsToCustomer called with customerId:', customerId, 'cartItems:', cartItems.length);

        // 查找顧客
        let customer;
        if (customerId.startsWith('mock-customer-')) {
            customer = this.customers.find(c => c.id === customerId);
        } else {
            // 嘗試從API獲取真實顧客詳情
            try {
                // 構建查詢參數
                const params = new URLSearchParams();
                if (this.selectedStoreId) {
                    params.append('store_id', this.selectedStoreId);
                }
                const url = `/api/cashier/customer/${customerId}${params.toString() ? '?' + params.toString() : ''}`;
                console.log(`fetching customer URL:`, url);

                const response = await fetch(url);
                const result = await response.json();
                if (result.success && result.customer) {
                    customer = result.customer;
                }
            } catch (error) {
                console.error('Failed to fetch customer details:', error);
            }
        }

        if (!customer) {
            this.addMessage('找不到指定的桌號', 'error');
            return;
        }

        // 添加商品到訂單
        try {
            let successCount = 0;
            let errorCount = 0;

            // 為每個商品添加到訂單
            for (const cartItem of cartItems) {
                // 根據顧客類型使用不同的方法
                if (customerId.startsWith('mock-customer-')) {
                    // 模擬顧客：添加到模擬訂單
                    try {
                        await this.addMockOrderItem(customerId, cartItem);
                        successCount++;
                    } catch (error) {
                        console.error('Failed to add mock order item:', error);
                        errorCount++;
                    }
                } else {
                    // 真實顧客：使用API添加到訂單
                    try {
                        await this.addRealOrderItem(customerId, cartItem);
                        successCount++;
                    } catch (error) {
                        console.error('Failed to add real order item:', error);
                        errorCount++;
                    }
                }
            }

            // 顯示結果訊息
            if (successCount > 0) {
                this.addMessage(`成功將 ${successCount} 個商品掛單到桌號 ${customer.table_number}`, 'success');
            }
            if (errorCount > 0) {
                this.addMessage(`有 ${errorCount} 個商品添加失敗`, 'warning');
            }

            // 刷新顧客詳情顯示（由selectCustomer方法處理）
            // 確保訂單項目刷新
            if (customer && !customerId.startsWith('mock-customer-')) {
                console.log('掛單完成，刷新訂單顯示');
                await this.loadOrderItems(customerId);
            }

            // 如果成功添加了至少一個商品，清空購物車
            if (successCount > 0) {
                // 從購物車中移除已成功添加的商品
                // 這裡我們假設所有購物車商品都是要添加的商品，所以清空整個購物車
                this.shoppingCart = [];
                this.calculateCartTotals();
                this.updateCartDisplay();
                // 刷新在場客人列表
                this.loadCustomers();
            }

        } catch (error) {
            this.addMessage(`掛單失敗: ${error.message}`, 'error');
        }
    }

    // 顯示桌號選擇對話框
    showTableSelectionDialog() {
        console.log('showTableSelectionDialog called');
        console.log('Number of customers:', this.customers ? this.customers.length : 0);

        // 檢查是否有顧客（桌號）
        if (!this.customers || this.customers.length === 0) {
            console.log('沒有顧客，無法顯示對話框');
            this.addMessage('目前沒有在場桌號，無法進行掛單', 'warning');
            return;
        }

        // 創建模態對話框
        const modalHtml = `
            <div class="modal" id="table-selection-modal" style="display: block;">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>選擇桌號進行掛單</h3>
                        <button class="modal-close" onclick="document.getElementById('table-selection-modal').style.display='none'">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p>請選擇要將購物車商品掛單到的桌號：</p>
                        <div class="table-selection-list" style="max-height: 300px; overflow-y: auto; margin: 10px 0;">
                            ${this.customers.map(customer => `
                                <div class="table-selection-item" data-customer-id="${customer.id}" style="padding: 10px; border-bottom: 1px solid #eee; cursor: pointer; display: flex; justify-content: space-between; align-items: center;">
                                    <div>
                                        <strong>桌號: ${customer.table_number}</strong>
                                        <div style="font-size: 12px; color: #666;">
                                            ${customer.is_member ? '會員' : '非會員'} |
                                            人數: ${customer.people_count || 1} |
                                            入場時間: ${new Date(customer.entry_time).toLocaleTimeString('zh-TW')}
                                        </div>
                                    </div>
                                    <i class="fas fa-chevron-right"></i>
                                </div>
                            `).join('')}
                        </div>
                        <div class="modal-actions" style="text-align: right; margin-top: 20px;">
                            <button class="btn-secondary" onclick="document.getElementById('table-selection-modal').style.display='none'">取消</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // 添加模態對話框到頁面
        const modalContainer = document.createElement('div');
        modalContainer.innerHTML = modalHtml;
        document.body.appendChild(modalContainer.firstElementChild);

        // 添加點擊事件到桌號項目
        setTimeout(() => {
            const tableItems = document.querySelectorAll('.table-selection-item');
            tableItems.forEach(item => {
                item.addEventListener('click', (e) => {
                    const customerId = item.getAttribute('data-customer-id');
                    this.selectTableForSuspension(customerId);
                });
            });
        }, 100);
    }

    // 選擇桌號進行掛單
    async selectTableForSuspension(customerId) {
        console.log('selectTableForSuspension called with customerId:', customerId);

        // 移除模態對話框
        const modal = document.getElementById('table-selection-modal');
        if (modal) {
            modal.style.display = 'none';
            setTimeout(() => modal.remove(), 300);
        }

        // 查找顧客
        let customer;
        if (customerId.startsWith('mock-customer-')) {
            customer = this.customers.find(c => c.id === customerId);
        } else {
            // 嘗試從API獲取真實顧客詳情
            try {
                // 構建查詢參數
                const params = new URLSearchParams();
                if (this.selectedStoreId) {
                    params.append('store_id', this.selectedStoreId);
                }
                const url = `/api/cashier/customer/${customerId}${params.toString() ? '?' + params.toString() : ''}`;
                console.log(`fetching customer URL:`, url);

                const response = await fetch(url);
                const result = await response.json();
                if (result.success && result.customer) {
                    customer = result.customer;
                }
            } catch (error) {
                console.error('Failed to fetch customer details:', error);
            }
        }

        if (!customer) {
            this.addMessage('找不到指定的桌號', 'error');
            return;
        }

        // 確認對話框
        const confirmMessage = `確定要將 ${this.shoppingCart.length} 個商品掛單到桌號 ${customer.table_number} 嗎？`;
        if (!confirm(confirmMessage)) {
            this.addMessage('已取消掛單操作', 'info');
            return;
        }

        // 保存購物車項目到臨時變量
        const cartItemsToAdd = [...this.shoppingCart];

        // 添加到選中桌號
        await this.addCartItemsToCustomer(customerId, cartItemsToAdd);
    }

    // 重寫父類的selectCustomer方法
    async selectCustomer(customerId) {

        // 清除加單目標（選擇新桌號時重置）
        this.addOrderTargetCustomer = null;
        // 更新購物車按鈕狀態
        this.updateCartButtons();

        // 檢查是否處於儲物柜分配模式
        if (this.pendingLockerAssignment) {
            const customer = this.customers.find(c => c.id === customerId);
            console.log('Found customer:', customer ? `ID: ${customer.id}, table: ${customer.table_number}` : 'Not found');
            if (customer) {
                // 確認分配
                const confirmMessage = `確定將儲物柜 #${this.pendingLockerAssignment.lockerNumber} 分配給桌號 ${customer.table_number} 嗎？`;
                console.log('Showing confirm dialog with message:', confirmMessage);
                const userConfirmed = confirm(confirmMessage);
                console.log('User confirmed:', userConfirmed);
                if (userConfirmed) {
                    console.log('Calling completeLockerAssignment...');
                    await this.completeLockerAssignment(customer);
                    console.log('completeLockerAssignment finished');
                } else {
                    console.log('User cancelled assignment');
                    this.addMessage('已取消儲物柜分配', 'info');
                }
            } else {
                console.log('找不到對應客戶，客戶ID:', customerId);
            }
            return; // 分配模式下不執行正常的selectCustomer邏輯
        }

        // 檢查掛單等待狀態但購物車為空的情況
        if (this.isPendingSuspend && this.shoppingCart.length === 0) {
            console.log('警告：掛單等待狀態但購物車為空，重置狀態');
            this.isPendingSuspend = false;
            this.addMessage('掛單操作已取消（購物車為空）', 'warning');
        }

        // 如果處於掛單等待狀態，先處理掛單邏輯
        if (this.isPendingSuspend && this.shoppingCart.length > 0) {
            console.log('處理掛單等待狀態...');

            // 查找顧客資訊
            let customer;
            if (customerId.startsWith('mock-customer-')) {
                customer = this.customers.find(c => c.id === customerId);
                console.log('找到模擬顧客:', customer ? customer.table_number : '未找到');
            } else {
                // 嘗試從API獲取真實顧客詳情
                try {
                    console.log('嘗試獲取真實顧客詳情...');
                    // 構建查詢參數
                    const params = new URLSearchParams();
                    if (this.selectedStoreId) {
                        params.append('store_id', this.selectedStoreId);
                    }
                    const url = `/api/cashier/customer/${customerId}${params.toString() ? '?' + params.toString() : ''}`;
                    console.log('Fetching customer detail URL:', url);
                    const response = await fetch(url);
                    const result = await response.json();
                    console.log('API回應:', result);
                    if (result.success && result.customer) {
                        customer = result.customer;
                        console.log('找到真實顧客:', customer.table_number);
                    }
                } catch (error) {
                    console.error('Failed to fetch customer details:', error);
                }
            }

            if (customer) {
                // 設置選中顧客
                this.selectedCustomer = customer;
                const confirmMessage = `確定要將 ${this.shoppingCart.length} 個商品掛單到桌號 ${customer.table_number} 嗎？`;
                console.log('顯示確認對話框:', confirmMessage);
                if (confirm(confirmMessage)) {
                    console.log('用戶確認掛單');
                    // 保存購物車項目到臨時變量
                    const cartItemsToAdd = [...this.shoppingCart];
                    // 添加到選中桌號
                    await this.addCartItemsToCustomer(customerId, cartItemsToAdd);

                    // 重置掛單等待狀態
                    this.isPendingSuspend = false;

                    // 顯示成功訊息
                    this.addMessage(`成功將商品掛單到桌號 ${customer.table_number}`, 'success');

                    // 繼續正常顯示桌號詳情
                    console.log('掛單完成，繼續顯示桌號詳情');
                } else {
                    // 用戶取消掛單，重置狀態
                    console.log('用戶取消掛單');
                    this.isPendingSuspend = false;
                    this.addMessage('已取消掛單操作', 'info');
                    // 繼續正常顯示桌號詳情
                }
            } else {
                // 找不到顧客，重置狀態
                console.log('找不到顧客，重置掛單狀態');
                this.isPendingSuspend = false;
                this.addMessage('找不到指定的桌號', 'error');
                return;
            }
        }

        // 正常顯示桌號詳情邏輯
        // 檢查是否為模擬顧客
        if (customerId.startsWith('mock-customer-')) {
            // 查找模擬顧客
            this.selectedCustomer = this.customers.find(c => c.id === customerId);
            this.displayCustomers();

            // 顯示模擬顧客詳情
            this.displayMockCustomerDetail(this.selectedCustomer);

            // 生成模擬QR Code
            this.displayMockQRCode(this.selectedCustomer);

            // 顯示模擬訂單項目
            this.displayMockOrderItems(customerId);

            this.updateOrderButtons();
            this.updateCartButtons(); // 更新購物車按鈕狀態
            this.updateAddOrderButtonState(); // 更新加單按鈕狀態

            // 顯示客人詳情模態框
            console.log('顯示模擬顧客詳情模態框 (分支1)');
            this.showCustomerDetailModal();
        } else {
            // 調用父類方法處理真實顧客
            await super.selectCustomer(customerId);
            this.updateCartButtons(); // 更新購物車按鈕狀態
            this.updateAddOrderButtonState(); // 更新加單按鈕狀態

            // 顯示客人詳情模態框
            console.log('顯示真實顧客詳情模態框 (分支2)');
            this.showCustomerDetailModal();
        }
    }

    // 重寫displayCustomers方法以確保事件綁定正確

    // 添加商品到模擬訂單
    async addMockOrderItem(customerId, cartItem) {
        console.log('Adding mock order item for customer:', customerId, 'product:', cartItem);

        // 查找顧客
        const customer = this.customers.find(c => c.id === customerId);
        if (!customer) {
            throw new Error('顧客不存在');
        }

        // 這裡可以實現將商品添加到模擬訂單的邏輯
        // 由於模擬數據結構，我們暫時只顯示訊息
        this.addMessage(`已將 ${cartItem.name} x${cartItem.quantity} 添加到桌號 ${customer.table_number} 的模擬訂單`, 'info');
    }

    // 添加商品到真實訂單
    async addRealOrderItem(customerId, cartItem) {
        console.log('addRealOrderItem called:', { customerId, cartItem });
        console.log('購物車項目詳細信息:', JSON.stringify(cartItem));

        // 檢查是否為模擬商品ID（1-13是模擬商品）
        // 只當productId是純數字字符串時才判定為模擬商品
        const productIdNum = parseInt(cartItem.productId);
        const productIdStr = String(cartItem.productId);
        const isNumericId = /^\d+$/.test(productIdStr); // 檢查是否為純數字字符串

        if (isNumericId && productIdNum >= 1 && productIdNum <= 13) {
            console.log('檢測到模擬商品ID，無法添加到真實訂單');
            throw new Error('請先登入系統以使用真實商品數據。當前使用的是模擬測試數據。');
        }

        // 調試：檢查商品是否存在於productsList中
        const productInList = this.productsList.find(p => p.id == cartItem.productId);
        console.log('在productsList中找到商品:', productInList);

        if (!this.isAuthenticated) {
            console.log('用戶未登入，無法添加商品到訂單');
            throw new Error('請先登入以添加商品到訂單');
        }

        console.log('當前token:', this.currentToken ? '有' : '無');

        // 使用身份驗證API添加商品到訂單
        // 嘗試不同類型的ID：字符串和數字

        console.log('產品ID轉換:', {
            原始: cartItem.productId,
            類型: typeof cartItem.productId,
            字符串: productIdStr,
            數字: productIdNum,
            isNaN: isNaN(productIdNum)
        });

        // 決定使用哪個商品ID
        let finalProductId;
        if (productInList) {
            finalProductId = productInList.id; // 使用從數據庫獲取的正確類型ID
            console.log('使用數據庫中的商品ID:', finalProductId, '類型:', typeof finalProductId);
        } else {
            finalProductId = isNumericId ? productIdNum : cartItem.productId;
            console.log('使用計算的商品ID:', finalProductId, '類型:', typeof finalProductId);
        }

        const requestBody = {
            customer_id: customerId,
            product_id: finalProductId,
            quantity: cartItem.quantity
        };

        console.log('發送API請求到 /api/cashier/add-order-item, body:', requestBody);

        const response = await this.fetchWithAuth('/api/cashier/add-order-item', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        });

        console.log('API響應狀態:', response.status, response.statusText);
        const result = await response.json();
        console.log('addRealOrderItem API response:', result);
        if (!result.success) {
            throw new Error(result.error || '添加商品失敗');
        }
        console.log('成功添加商品到訂單:', cartItem.name, '數量:', cartItem.quantity);

        // 如果有折扣，立即更新訂單項目的折扣
        const hasDiscount = (cartItem.flatDiscount > 0 || cartItem.percentDiscount > 0);
        if (hasDiscount && result.order_id) {
            console.log('購物車商品有折扣，立即更新 order_item:', result.order_id);
            const updateBody = {};
            if (cartItem.flatDiscount > 0) updateBody.flat_discount = cartItem.flatDiscount;
            if (cartItem.percentDiscount > 0) updateBody.percent_discount = cartItem.percentDiscount;
            try {
                const updateRes = await this.fetchWithAuth(`/api/cashier/order-item/${result.order_id}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(updateBody)
                });
                const updateResult = await updateRes.json();
                if (updateResult.success) {
                    console.log('購物車商品折扣已更新:', updateBody);
                } else {
                    console.warn('更新折扣失敗（不影響結賬）:', updateResult.error);
                }
            } catch (discountErr) {
                console.warn('更新折扣出錯（不影響結賬）:', discountErr.message);
            }
        }
    }

    // 取消選中桌號
    deselectCustomer() {
        console.log('deselectCustomer called, current selectedCustomer:', this.selectedCustomer);

        // 隱藏客人詳情模態框
        this.hideCustomerDetailModal();

        if (!this.selectedCustomer) return;

        this.selectedCustomer = null;
        // 清除加單目標
        this.addOrderTargetCustomer = null;
        // 更新購物車按鈕狀態
        this.updateCartButtons();

        // 隱藏客人詳情，顯示空白狀態
        const customerInfo = document.getElementById('customer-info');
        const emptyState = document.getElementById('customer-empty-state');
        if (customerInfo && emptyState) {
            customerInfo.classList.add('hidden');
            emptyState.classList.remove('hidden');
        }
        // 隱藏QR Code部分
        const qrSection = document.getElementById('customer-qr-section');
        if (qrSection) {
            qrSection.classList.add('hidden');
        }

        // 隱藏模態框客人詳情，顯示空白狀態
        const modalCustomerInfo = document.getElementById('customer-modal-info');
        const modalEmptyState = document.getElementById('customer-modal-empty-state');
        if (modalCustomerInfo && modalEmptyState) {
            modalCustomerInfo.classList.add('hidden');
            modalEmptyState.classList.remove('hidden');
        }
        // 隱藏模態框QR Code部分
        const modalQrSection = document.getElementById('customer-modal-qr-section');
        if (modalQrSection) {
            modalQrSection.classList.add('hidden');
        }

        // 清空當前訂單項目
        if (this.currentOrderItems) {
            this.currentOrderItems = [];
        }
        // 重置訂單顯示為「請先選擇客人」空白狀態
        const orderItems = document.getElementById('order-items');
        if (orderItems) {
            orderItems.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-receipt"></i>
                    <p data-i18n="emptyStateSelectCustomerFirst">請先選擇客人</p>
                </div>
            `;
        }
        // 重置模態框訂單顯示為空白狀態
        const modalOrderItems = document.getElementById('modal-order-items');
        if (modalOrderItems) {
            modalOrderItems.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-receipt"></i>
                    <p data-i18n="emptyStateSelectCustomerFirst">請先選擇客人</p>
                </div>
            `;
        }
        // 重置訂單摘要
        const itemCountEl = document.getElementById('item-count');
        const orderTotalEl = document.getElementById('order-total');
        if (itemCountEl) itemCountEl.textContent = '0';
        if (orderTotalEl) orderTotalEl.textContent = '$0';
        // 重置模態框訂單摘要
        const modalItemCountEl = document.getElementById('modal-item-count');
        const modalOrderTotalEl = document.getElementById('modal-order-total');
        if (modalItemCountEl) modalItemCountEl.textContent = '0';
        if (modalOrderTotalEl) modalOrderTotalEl.textContent = '$0';

        // 更新客人列表的active狀態
        this.displayCustomers();

        // 更新按鈕狀態
        this.updateCartButtons();
        this.updateOrderButtons();
        this.updateAddOrderButtonState();

        console.log('桌號已取消選中');
    }

    /**
     * 啟動敏感操作定時上傳（每10分鐘觸發一次）
     */
    startSensitiveUploadTimer() {
        console.log('啟動敏感操作定時上傳（每10分鐘）');
        // 清除舊的定時器（防止重複調用）
        if (this._sensitiveUploadTimer) {
            clearInterval(this._sensitiveUploadTimer);
        }
        // 每10分鐘觸發一次上傳
        this._sensitiveUploadTimer = setInterval(() => {
            this.triggerSensitiveOperationsUpload();
        }, 10 * 60 * 1000);
    }

    /**
     * 觸發上傳未上傳的敏感操作到主機
     */
    async triggerSensitiveOperationsUpload() {
        try {
            console.log('觸發立即上傳敏感操作到主機...');

            // 獲取當前的API令牌
            const token = this.currentToken;
            if (!token) {
                console.warn('無法獲取認證令牌，跳過敏感操作上傳');
                return;
            }

            // 發送請求到立即上傳端點
            const response = await fetch('/api/sync/trigger-sensitive-upload', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            if (result.success) {
                console.log('立即上傳敏感操作成功:', result.message);
                if (result.data && result.data.operations_uploaded > 0) {
                    console.log(`已上傳 ${result.data.operations_uploaded} 個敏感操作到主機`);
                }
            } else {
                console.warn('立即上傳敏感操作返回失敗:', result.message || '未知錯誤');
            }
        } catch (error) {
            console.error('觸發立即上傳敏感操作失敗:', error);
            // 不影響主流程，僅記錄錯誤
        }
    }

    // 顯示客人詳情模態框
    showCustomerDetailModal() {
        const modal = document.getElementById('customer-detail-modal');
        if (!modal) {
            console.error('customer-detail-modal not found');
            return;
        }

        // 隱藏dashboard中的原始右側面板（客人詳情）
        const dashboardRightPanel = document.querySelector('#tab-dashboard .right-panel');
        if (dashboardRightPanel) {
            dashboardRightPanel.style.display = 'none';
        }

        // 顯示模態框
        modal.classList.remove('hidden');
    }

    // 隱藏客人詳情模態框
    hideCustomerDetailModal() {
        const modal = document.getElementById('customer-detail-modal');
        if (!modal) {
            console.log('customer-detail-modal not found');
            return;
        }

        // 注意：不再顯示原始右側面板，因為客人詳情現在只通過模態框顯示

        // 隱藏模態框
        modal.classList.add('hidden');
        console.log('隱藏客人詳情模態框');
    }

    // 更新加單按鈕狀態
    updateAddOrderButtonState() {
        const addOrderBtn = document.getElementById('add-order-btn');
        const modalAddOrderBtn = document.getElementById('modal-add-order-btn');

        // 更新原始加單按鈕
        if (addOrderBtn) {
            const shouldEnable = !!this.selectedCustomer;
            console.log('updateAddOrderButtonState: selectedCustomer =', this.selectedCustomer, 'shouldEnable =', shouldEnable);
            addOrderBtn.disabled = !shouldEnable;
        } else {
            console.log('updateAddOrderButtonState: add-order-btn not found');
        }

        // 更新模態框加單按鈕
        if (modalAddOrderBtn) {
            const shouldEnable = !!this.selectedCustomer;
            console.log('updateAddOrderButtonState: modal add-order-btn, shouldEnable =', shouldEnable);
            modalAddOrderBtn.disabled = !shouldEnable;
        }
    }

    // 更新訂單按鈕狀態（結賬、刪除桌號）
    updateOrderButtons() {
        // 調用父類方法（如果存在）
        if (super.updateOrderButtons) {
            super.updateOrderButtons();
        }

        const checkoutBtn = document.getElementById('checkout-btn');
        const deleteTableBtn = document.getElementById('delete-table-btn');
        const modalCheckoutBtn = document.getElementById('modal-checkout-btn');
        const modalDeleteTableBtn = document.getElementById('modal-delete-table-btn');

        // 更新原始按鈕狀態（如果父類沒有處理）
        if (checkoutBtn) {
            // 這裡可以添加自定義邏輯，目前保持父類的狀態
            console.log('updateOrderButtons: checkout-btn disabled =', checkoutBtn.disabled);
        }
        if (deleteTableBtn) {
            console.log('updateOrderButtons: delete-table-btn disabled =', deleteTableBtn.disabled);
        }

        // 同步模態框按鈕狀態
        if (modalCheckoutBtn && checkoutBtn) {
            modalCheckoutBtn.disabled = checkoutBtn.disabled;
            console.log('updateOrderButtons: modal-checkout-btn disabled =', checkoutBtn.disabled);
        }
        if (modalDeleteTableBtn && deleteTableBtn) {
            modalDeleteTableBtn.disabled = deleteTableBtn.disabled;
            console.log('updateOrderButtons: modal-delete-table-btn disabled =', deleteTableBtn.disabled);
        }

        // 同步模態框備註按鈕狀態
        const modalNoteBtn = document.getElementById('modal-note-btn');
        const noteBtn = document.getElementById('note-btn');
        if (modalNoteBtn && noteBtn) {
            modalNoteBtn.disabled = noteBtn.disabled;
        }

        // 同步模態框部份結賬按鈕狀態（與結賬按鈕相同條件）
        const modalPartialCheckoutBtn = document.getElementById('modal-partial-checkout-btn');
        if (modalPartialCheckoutBtn && checkoutBtn) {
            modalPartialCheckoutBtn.disabled = checkoutBtn.disabled;
        }

        // 同步模態框後加客人按鈕狀態（與刪除桌號相同條件）
        const modalAddSubtableBtn = document.getElementById('modal-add-subtable-btn');
        if (modalAddSubtableBtn && deleteTableBtn) {
            modalAddSubtableBtn.disabled = deleteTableBtn.disabled;
        }
    }

    // 更新購物車按鈕狀態
    updateCartButtons() {
        const cartSuspendBtn = document.getElementById('cart-suspend-btn');
        const cartCheckoutBtn = document.getElementById('cart-checkout-btn');

        console.log('updateCartButtons: cartSuspendBtn found?', !!cartSuspendBtn);
        console.log('updateCartButtons: shoppingCart length:', this.shoppingCart.length, 'selectedCustomer:', this.selectedCustomer);
        console.log('updateCartButtons: addOrderTargetCustomer:', this.addOrderTargetCustomer);

        // 掛單按鈕：只有購物車有商品時啟用（桌號選擇在掛單功能中處理）
        if (cartSuspendBtn) {
            const shouldDisable = this.shoppingCart.length === 0;
            console.log('updateCartButtons: suspend button disabled?', shouldDisable);
            cartSuspendBtn.disabled = shouldDisable;
        }

        // 結賬按鈕：只有在以下條件下啟用：
        // 1. 購物車有商品
        // 2. 沒有正在進行加單流程（addOrderTargetCustomer為null）
        if (cartCheckoutBtn) {
            const shouldDisable = this.shoppingCart.length === 0 || this.addOrderTargetCustomer !== null;
            console.log('updateCartButtons: checkout button disabled?', shouldDisable, '(shoppingCart empty:', this.shoppingCart.length === 0, ', addOrderTargetCustomer exists:', this.addOrderTargetCustomer !== null, ')');
            cartCheckoutBtn.disabled = shouldDisable;
        }
    }

    // 重寫updateCartDisplay方法以更新按鈕狀態
    updateCartDisplay() {
        console.log('updateCartDisplay called, cartTotalItems:', this.cartTotalItems, 'shoppingCart length:', this.shoppingCart.length, 'selectedCustomer:', this.selectedCustomer);
        // 調用原有的updateCartDisplay邏輯
        const cartItemsContainer = document.getElementById('cart-items');
        const cartTotalItemsElement = document.getElementById('cart-total-items');
        const cartTotalAmountElement = document.getElementById('cart-total-amount');
        const cartCheckoutBtn = document.getElementById('cart-checkout-btn');
        const cartClearBtn = document.getElementById('cart-clear-btn');

        if (!cartItemsContainer) return;

        // 更新總計顯示
        if (cartTotalItemsElement) {
            cartTotalItemsElement.textContent = this.cartTotalItems;
        }
        if (cartTotalAmountElement) {
            cartTotalAmountElement.textContent = `$${this.cartTotalAmount.toFixed(2)}`;
        }

        // 更新購物車按鈕狀態（使用統一的邏輯）
        this.updateCartButtons();

        // 清空按鈕事件綁定
        if (cartClearBtn) {
            // 移除舊的事件監聽器
            const newCartClearBtn = cartClearBtn.cloneNode(true);
            cartClearBtn.parentNode.replaceChild(newCartClearBtn, cartClearBtn);
            newCartClearBtn.addEventListener('click', () => this.clearCart());
        }

        // 如果購物車為空，顯示空狀態
        if (this.shoppingCart.length === 0) {
            cartItemsContainer.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-shopping-cart"></i>
                    <p data-i18n="emptyStateCart">購物車是空的</p>
                </div>
            `;
            return;
        }

        // 生成購物車項目列表
        let cartHTML = '';
        this.shoppingCart.forEach((item, index) => {
            const effPrice = item.effectivePrice || item.price;
            const showDiscount = (item.flatDiscount > 0 || item.percentDiscount > 0);
            const priceHtml = showDiscount
                ? `<span class="cart-item-effective-price" style="font-weight:700;color:#e74c3c;">$${effPrice.toFixed(2)}</span> <span class="cart-item-original-price" style="text-decoration:line-through;color:#999;font-size:0.85em;">$${item.price.toFixed(2)}</span>`
                : `<span class="cart-item-price">$${item.price.toFixed(2)}</span>`;
            cartHTML += `
                <div class="cart-item" data-product-id="${item.productId}">
                    <div class="cart-item-info">
                        <div class="cart-item-name">${item.name}</div>
                    </div>
                    <div class="cart-item-controls">
                        <div class="cart-item-price-quantity">
                            ${priceHtml}
                            <div class="cart-item-quantity-display">${item.quantity}</div>
                        </div>
                        <button class="cart-item-action-btn" data-index="${index}">
                            <i class="fas ${item.quantity > 1 ? 'fa-minus' : 'fa-trash'}"></i>
                        </button>
                    </div>
                </div>
            `;
        });

        cartItemsContainer.innerHTML = cartHTML;

        // 綁定操作按鈕事件
        cartItemsContainer.querySelectorAll('.cart-item-action-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = parseInt(e.currentTarget.dataset.index);
                if (this.shoppingCart[index].quantity > 1) {
                    // 減少數量
                    this.shoppingCart[index].quantity -= 1;
                    const effPrice = this.shoppingCart[index].effectivePrice || this.shoppingCart[index].price;
                    this.shoppingCart[index].subtotal = this.shoppingCart[index].quantity * effPrice;
                    this.calculateCartTotals();
                    this.updateCartDisplay();
                } else {
                    // 移除商品
                    this.removeFromCart(this.shoppingCart[index].productId);
                }
            });
        });

        // 綁定購物車商品點擊事件：點擊商品名稱區域彈出數量編輯視窗
        cartItemsContainer.querySelectorAll('.cart-item-info').forEach(el => {
            el.addEventListener('click', (e) => {
                const cartItem = e.currentTarget.closest('.cart-item');
                if (!cartItem) return;
                const productId = cartItem.dataset.productId;
                const cartIndex = this.shoppingCart.findIndex(item => item.productId == productId);
                if (cartIndex >= 0) {
                    this.showCartItemQuantityModal(cartIndex);
                }
            });
        });
    }

    // 顯示購物車商品數量編輯模態框
    showCartItemQuantityModal(index) {
        const item = this.shoppingCart[index];
        if (!item) return;

        return new Promise((resolve) => {
            const modal = document.getElementById('cart-qty-modal');
            if (!modal) return;

            const nameEl = document.getElementById('cart-qty-product-name');
            const currentPriceEl = document.getElementById('cart-qty-current-price');
            const currentQtyEl = document.getElementById('cart-qty-current-qty');
            const inputEl = document.getElementById('cart-qty-input');
            const errorEl = document.getElementById('cart-qty-error');
            const confirmBtn = document.getElementById('cart-qty-confirm');
            const cancelBtn = document.getElementById('cart-qty-cancel');
            const deleteBtn = document.getElementById('cart-qty-delete');
            const closeBtn = document.getElementById('cart-qty-modal-close');
            const flatDiscountEl = document.getElementById('cart-qty-flat-discount');
            const percentDiscountEl = document.getElementById('cart-qty-percent-discount');
            const originalPriceDisplay = document.getElementById('cart-qty-original-price-display');
            const effectivePriceEl = document.getElementById('cart-qty-effective-price');
            const giftBtn = document.getElementById('cart-qty-gift-btn');
            const qtyUpBtn = document.getElementById('cart-qty-up');
            const qtyDownBtn = document.getElementById('cart-qty-down');

            if (!nameEl || !inputEl || !errorEl || !confirmBtn || !cancelBtn || !deleteBtn) return;

            // 重置
            let resolved = false;
            const unitPrice = item.price || 0;
            const currentFlatDiscount = item.flatDiscount || 0;
            const currentPercentDiscount = item.percentDiscount || 0;

            nameEl.textContent = item.name;
            if (currentPriceEl) currentPriceEl.textContent = unitPrice.toFixed(1);
            if (currentQtyEl) currentQtyEl.textContent = item.quantity;
            inputEl.value = item.quantity;
            if (flatDiscountEl) flatDiscountEl.value = currentFlatDiscount > 0 ? String(currentFlatDiscount) : '';
            if (percentDiscountEl) percentDiscountEl.value = currentPercentDiscount > 0 ? String(currentPercentDiscount) : '';
            errorEl.style.display = 'none';

            // 計算有效單價（購物車版本）
            const calcEffectivePrice = () => {
                const flatVal = parseFloat(flatDiscountEl?.value) || 0;
                const pctVal = parseFloat(percentDiscountEl?.value) || 0;
                if (flatVal < 0 || pctVal < 0) return unitPrice;
                let effective = unitPrice - flatVal;
                if (pctVal > 0) {
                    effective = effective * (100 - pctVal) / 100;
                }
                return Math.max(0, effective);
            };

            // 更新價格預覽
            const updatePricePreview = () => {
                if (originalPriceDisplay) originalPriceDisplay.textContent = unitPrice.toFixed(1);
                if (effectivePriceEl) effectivePriceEl.textContent = calcEffectivePrice().toFixed(1);
            };

            updatePricePreview();

            // 上下箭頭調整數量
            const onQtyUp = () => {
                let val = parseInt(inputEl.value) || 0;
                inputEl.value = val + 1;
            };
            const onQtyDown = () => {
                let val = parseInt(inputEl.value) || 0;
                if (val > 1) inputEl.value = val - 1;
            };

            const cleanup = () => {
                if (resolved) return;
                resolved = true;
                modal.style.display = 'none';
                modal.classList.add('hidden');
                confirmBtn.removeEventListener('click', onConfirm);
                cancelBtn.removeEventListener('click', onCancel);
                deleteBtn.removeEventListener('click', onDelete);
                document.removeEventListener('keydown', onKeydown);
                if (closeBtn) closeBtn.removeEventListener('click', onCancel);
                if (giftBtn) giftBtn.removeEventListener('click', onGift);
                if (flatDiscountEl) flatDiscountEl.removeEventListener('input', updatePricePreview);
                if (percentDiscountEl) percentDiscountEl.removeEventListener('input', updatePricePreview);
                if (qtyUpBtn) qtyUpBtn.removeEventListener('click', onQtyUp);
                if (qtyDownBtn) qtyDownBtn.removeEventListener('click', onQtyDown);
            };

            const onDelete = () => {
                cleanup();
                // 從購物車中移除該商品
                this.shoppingCart.splice(index, 1);
                this.calculateCartTotals();
                this.updateCartDisplay();
                resolve('delete');
            };

            const onConfirm = () => {
                const val = inputEl.value.trim();
                const qty = parseInt(val);
                if (!val || isNaN(qty) || qty < 1) {
                    errorEl.textContent = '請輸入有效的數量 (至少1)';
                    errorEl.style.display = 'block';
                    return;
                }

                const flatVal = flatDiscountEl ? (parseFloat(flatDiscountEl.value) || 0) : 0;
                const pctVal = percentDiscountEl ? (parseFloat(percentDiscountEl.value) || 0) : 0;

                if (flatVal < 0 || pctVal < 0) {
                    errorEl.textContent = '折扣不能為負數';
                    errorEl.style.display = 'block';
                    return;
                }
                if (flatVal > 0 && flatVal >= unitPrice) {
                    errorEl.textContent = '立減金額不能大於或等於單價';
                    errorEl.style.display = 'block';
                    return;
                }
                if (pctVal > 100) {
                    errorEl.textContent = '折扣百分比不能超過 100%';
                    errorEl.style.display = 'block';
                    return;
                }

                // 更新購物車商品
                item.quantity = qty;
                item.flatDiscount = flatVal;
                item.percentDiscount = pctVal;
                const effPrice = calcEffectivePrice();
                item.effectivePrice = effPrice;
                item.subtotal = qty * effPrice;
                this.calculateCartTotals();
                this.updateCartDisplay();
                cleanup();
                resolve(qty);
            };

            const onCancel = () => {
                cleanup();
                resolve(null);
            };

            const onGift = () => {
                if (percentDiscountEl) {
                    percentDiscountEl.value = '100';
                    updatePricePreview();
                }
            };

            confirmBtn.addEventListener('click', onConfirm);
            cancelBtn.addEventListener('click', onCancel);
            deleteBtn.addEventListener('click', onDelete);
            if (closeBtn) closeBtn.addEventListener('click', onCancel);
            if (qtyUpBtn) qtyUpBtn.addEventListener('click', onQtyUp);
            if (qtyDownBtn) qtyDownBtn.addEventListener('click', onQtyDown);
            if (giftBtn) giftBtn.addEventListener('click', onGift);
            if (flatDiscountEl) flatDiscountEl.addEventListener('input', updatePricePreview);
            if (percentDiscountEl) percentDiscountEl.addEventListener('input', updatePricePreview);

            // Enter 鍵確認，Escape 取消
            const onKeydown = (e) => {
                if (e.key === 'Enter') onConfirm();
                if (e.key === 'Escape') onCancel();
            };
            document.addEventListener('keydown', onKeydown);

            // 顯示 modal
            modal.classList.remove('hidden');
            modal.style.display = 'flex';
            modal.style.position = 'fixed';
            modal.style.top = '0';
            modal.style.left = '0';
            modal.style.width = '100%';
            modal.style.height = '100%';
            modal.style.zIndex = '10000';
            modal.style.backgroundColor = 'rgba(0,0,0,0.5)';
            modal.style.justifyContent = 'center';
            modal.style.alignItems = 'center';

            // 聚焦輸入框
            setTimeout(() => inputEl.focus(), 100);

            // 點擊 modal 背景關閉
            modal.addEventListener('click', (e) => {
                if (e.target === modal) onCancel();
            });
        });
    }

    // 清空所有場內桌號
    async clearAllCustomers() {
        console.log('clearAllCustomers called');

        // 確認操作
        if (!confirm('確定要清空所有場內桌號嗎？此操作將刪除所有在場客人，無法復原。')) {
            console.log('User cancelled clear operation');
            return;
        }

        try {
            // 獲取當前所有顧客（真實+模擬）
            const allCustomers = this.customers || [];
            console.log('Total customers to clear:', allCustomers.length);
            let deletedCount = 0;
            let errorCount = 0;

            // 遍歷所有顧客
            for (const customer of allCustomers) {
                console.log('Processing customer:', customer.id, customer.table_number);

                // 檢查是否為模擬顧客
                if (customer.id.startsWith('mock-customer-')) {
                    // 模擬顧客：從mockCustomers數組中移除
                    const beforeLength = this.mockCustomers.length;
                    this.mockCustomers = this.mockCustomers.filter(mc => mc.id !== customer.id);
                    const afterLength = this.mockCustomers.length;
                    console.log(`Mock customer ${customer.id}: before ${beforeLength}, after ${afterLength}`);

                    if (afterLength < beforeLength) {
                        deletedCount++;
                    }
                } else {
                    // 真實顧客：調用API刪除
                    try {
                        // 檢查是否已登入，如果未登入則跳過真實顧客
                        if (!this.isAuthenticated) {
                            console.log(`Skipping real customer ${customer.table_number} - not authenticated`);
                            errorCount++;
                            continue;
                        }

                        const response = await this.fetchWithAuth(`/api/cashier/customer/${customer.id}`, {
                            method: 'DELETE'
                        });
                        const result = await response.json();
                        if (result.success) {
                            deletedCount++;
                            console.log(`Real customer ${customer.table_number} deleted successfully`);
                        } else {
                            errorCount++;
                            console.error(`刪除顧客 ${customer.table_number} 失敗:`, result.error);
                        }
                    } catch (error) {
                        errorCount++;
                        console.error(`刪除顧客 ${customer.table_number} 失敗:`, error);
                    }
                }
            }

            // 清空模擬顧客數組（以防萬一）
            this.mockCustomers = [];
            console.log('Mock customers array cleared');

            // 禁用模擬數據顯示，防止重新生成
            this.showMockData = false;
            this.alwaysShowMockData = false;
            console.log('Mock data display disabled');

            // 保存設置到本地存儲，以便頁面刷新後仍然有效
            localStorage.setItem('cashier_showMockData', 'false');
            localStorage.setItem('cashier_alwaysShowMockData', 'false');

            // 清空當前顧客列表
            this.customers = [];

            // 更新顯示（不調用loadCustomers，避免重新生成模擬數據）
            this.displayCustomers();
            this.updateCustomerCount();

            // 更新今日統計
            this.loadTodayStats();

            // 清除選中的顧客
            this.clearSelectedCustomer();

            // 顯示結果訊息
            let message = `已清空 ${deletedCount} 個桌號`;
            if (errorCount > 0) {
                message += `，有 ${errorCount} 個桌號刪除失敗（可能需要登入以刪除真實桌號）`;
                this.addMessage(message, errorCount === allCustomers.length ? 'error' : 'warning');
            } else {
                this.addMessage(message, 'success');
                // 添加提示：模擬數據顯示已禁用
                this.addMessage('模擬數據顯示已禁用，要重新啟用模擬數據，請在瀏覽器控制台執行：window.enableMockData()', 'info');
            }

        } catch (error) {
            console.error('Error in clearAllCustomers:', error);
            this.addMessage(`清空桌號失敗: ${error.message}`, 'error');
        }
    }

    // 重寫loadCustomerDetail方法以添加調試日誌
    async loadCustomerDetail(customerId) {
        console.log(`loadCustomerDetail called for customerId: ${customerId}`);
        console.log(`Current selectedCustomer:`, this.selectedCustomer ? `ID: ${this.selectedCustomer.id}, table: ${this.selectedCustomer.table_number}` : 'null');
        console.log(`Current selectedStoreId: ${this.selectedStoreId}`);

        try {
            const url = `/api/cashier/customer/${customerId}`;
            console.log(`loadCustomerDetail fetching URL: ${url}`);

            const response = await this.fetchWithAuth(url);
            console.log(`API response status: ${response.status}`);
            const result = await response.json();
            console.log(`API response result:`, result);

            if (result.success) {
                console.log(`Customer detail loaded successfully, lockers:`, result.customer?.lockers || '未定義');
                console.log(`Customer object keys:`, Object.keys(result.customer || {}));
                // 調用父類的displayCustomerDetail
                this.displayCustomerDetail(result.customer);
            } else {
                console.log(`API returned error:`, result.error);
                this.addMessage('載入客人詳情失敗: ' + result.error, 'error');
            }
        } catch (error) {
            console.error('loadCustomerDetail error:', error);
            this.addMessage('載入客人詳情失敗: ' + error.message, 'error');
        }
    }

    // 重寫displayCustomers方法以在子桌號卡片上添加"子"徽章
    displayCustomers() {
        // 調用父類方法渲染所有卡片
        super.displayCustomers();
        // 為子桌號添加 "子" 徽章
        this._addSubTableBadges();
    }

    /**
     * 為子桌號的卡片添加 "子" 徽章
     */
    _addSubTableBadges() {
        if (!this.customers || !this.customers.length) return;
        this.customers.forEach(customer => {
            if (customer.table_number && this.isSubTable(customer.table_number)) {
                const el = document.querySelector(`.customer-item[data-customer-id="${customer.id}"]`);
                if (!el) return;
                // 卡片往下移，與母桌號做出層級區分
                el.classList.add('sub-table');
                // 添加 "子" 徽章
                if (!el.querySelector('.sub-table-badge')) {
                    const badge = document.createElement('div');
                    badge.className = 'sub-table-badge';
                    badge.textContent = '子';
                    el.insertBefore(badge, el.firstChild);
                }
            }
        });
    }

    /**
     * 檢查桌號是否為子桌號 (格式: A7.1, A10.5)
     */
    isSubTable(tableNumber) {
        return /^A\d+\.\d+$/i.test(String(tableNumber));
    }

    /**
     * 獲取父桌號  (例如: A7.1 → A7, A7 → A7)
     */
    getParentTableNumber(tableNumber) {
        if (!this.isSubTable(tableNumber)) return tableNumber;
        return tableNumber.split('.')[0];
    }

    /**
     * 獲取下一個可用的子桌號數字
     * 例如: A7.1, A7.2 存在 → 返回 3
     */
    async getNextSubTableNumber(parentTableNumber) {
        // 從在場客人中找出已存在的子桌號
        const existing = new Set();
        if (this.customers) {
            this.customers.forEach(c => {
                if (c.table_number && c.table_number.startsWith(parentTableNumber + '.')) {
                    existing.add(c.table_number);
                }
            });
        }
        // 加上本次 session 曾使用過的子桌號（含已結賬的），避免同一 session 重用
        if (this._sessionSubTables) {
            this._sessionSubTables.forEach(tn => {
                if (tn && tn.startsWith(parentTableNumber + '.')) {
                    existing.add(tn);
                }
            });
        }
        let n = 1;
        while (existing.has(`${parentTableNumber}.${n}`)) {
            n++;
        }
        return n;
    }

    /**
     * 顯示「後加客人」子桌號輸入視窗
     */
    async showAddSubTableModal() {
        if (this._addingTable) {
            console.log('showAddSubTableModal: 正在執行中，跳過本次調用');
            return;
        }
        this._addingTable = true;
        try {
            const parentCustomer = this.selectedCustomer;
            if (!parentCustomer || !parentCustomer.table_number) {
                this.addMessage('請先選擇一個桌號', 'error');
                return;
            }
            // 如果當前桌號已是子桌號，取其父桌號（A7.1 → A7），產生兄弟子桌號而非孫子
            const parentTableNumber = this.isSubTable(parentCustomer.table_number)
                ? this.getParentTableNumber(parentCustomer.table_number)
                : parentCustomer.table_number;
            // 計算下一個可用的子桌號數字
            const nextSubNumber = await this.getNextSubTableNumber(parentTableNumber);
            const proposedTableNumber = `${parentTableNumber}.${nextSubNumber}`;
            // 顯示用桌號：去掉前綴 A，只顯示數字部分 (A7.1 → 7.1)
            const displayTableNumber = proposedTableNumber.replace(/^A/i, '');
            // 檢查桌號是否已被佔用（理論上不應發生）
            const isOccupied = await this.checkTableOccupied(proposedTableNumber);
            if (isOccupied) {
                this.addMessage(`子桌號 ${proposedTableNumber} 已被佔用，請重試`, 'error');
                return;
            }
            // 顯示輸入視窗（唯讀桌號 + 人數輸入）
            const result = await this.showNumericInputModal({
                title: `新增子桌號 (${parentTableNumber})`,
                tableNumber: true,
                peopleCount: true,
                readOnlyTableNumber: displayTableNumber, // 顯示 7.1 而不是 A7.1
                peopleError: '請輸入有效的人數 (1-70)'
            });
            if (!result) {
                return; // 用戶取消
            }
            const peopleCount = result.peopleCount;
            // 調用入場 API
            const requestBody = {
                peopleCount: peopleCount,
                isMember: false,
                memberCardId: null,
                table_number: proposedTableNumber
            };
            let url = '/api/entry/entry';
            if (this.selectedStoreId) {
                url += `?store_id=${this.selectedStoreId}`;
                requestBody.store_id = this.selectedStoreId;
            }
            const response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(requestBody)
            });
            const apiResult = await response.json();
            if (apiResult.success) {
                this.addMessage(`已成功新增子桌號: ${proposedTableNumber} (${peopleCount}人)`, 'success');
                // 記錄本次 session 已使用的子桌號，避免同一 session 重用號碼
                this._sessionSubTables.add(proposedTableNumber);
                this.deselectCustomer();
                this.loadCustomers();
                this.loadEntryRecords();
            } else {
                this.addMessage(`新增子桌號失敗: ${apiResult.message}`, 'error');
            }
        } catch (error) {
            console.error('新增子桌號錯誤:', error);
            this.addMessage(`新增子桌號時發生錯誤: ${error.message}`, 'error');
        } finally {
            this._addingTable = false;
        }
    }

    // 重寫displayCustomerDetail方法以添加調試日誌並更新模態框
    displayCustomerDetail(customer) {
        console.log(`displayCustomerDetail called with customer:`, customer);
        console.log(`Customer table: ${customer.table_number}, lockers:`, customer.lockers);

        // 先調用父類方法更新原始面板
        super.displayCustomerDetail(customer);

        // 更新模態框客人詳情
        const modalCustomerInfo = document.getElementById('customer-modal-info');
        const modalEmptyState = document.getElementById('customer-modal-empty-state');

        if (modalCustomerInfo && modalEmptyState) {
            const entryTime = this.parseEntryTime(customer.entry_time).toLocaleString('zh-TW', {
                hour: '2-digit',
                minute: '2-digit'
            });

            // 計算可售零食
            const snackInfo = this.calculateAvailableSnacks(customer);
            const snackClass = snackInfo.available > 0 ? 'snacks-available' : 'snacks-empty';
            const nextRefresh = snackInfo.nextRefresh
                ? snackInfo.nextRefresh.toLocaleTimeString('zh-TW', { hour: '2-digit', minute: '2-digit' })
                : '--:--';

            modalCustomerInfo.innerHTML = `
                <div class="detail-info">
                    ${this.customerNotes && this.customerNotes[customer.id] ? `
                    <div class="detail-row note-row">
                        <span class="detail-label">備註:</span>
                        <span class="detail-value note-text">${this._escapeHtml(this.customerNotes[customer.id])}</span>
                    </div>` : ''}
                    <div class="detail-row">
                        <span class="detail-label">桌號:</span>
                        <span class="detail-value">${customer.table_number}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">客人數:</span>
                        <span class="detail-value">${customer.people_count}位</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">入場時間:</span>
                        <span class="detail-value">${entryTime}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">儲物柜:</span>
                        <span class="detail-value">${customer.lockers?.length > 0 ? customer.lockers.join(', ') : (customer.lockers_used ? customer.lockers_used : '無')}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">可售零食:</span>
                        <span class="detail-value ${snackClass} available-snacks-count">
                            ${snackInfo.available}份
                            <span class="snack-refresh-hint">下次刷新 ${nextRefresh}</span>
                        </span>
                    </div>
                    <div class="detail-row total">
                        <span class="detail-label">當前消費:</span>
                        <span class="detail-value">$${customer.total_amount || 0}</span>
                    </div>
                </div>
            `;

            // 顯示模態框客人詳情，隱藏空白狀態
            modalEmptyState.classList.add('hidden');
            modalCustomerInfo.classList.remove('hidden');
        }
    }

    // 重寫loadCustomerQRCode方法以同時更新模態框QR Code
    async loadCustomerQRCode(customerId) {
        console.log(`loadCustomerQRCode called for customerId: ${customerId}`);

        try {
            // 構建查詢參數
            const params = new URLSearchParams();
            if (this.selectedStoreId) {
                params.append('store_id', this.selectedStoreId);
            }

            const url = `/api/cashier/customer/${customerId}/qr-code${params.toString() ? '?' + params.toString() : ''}`;
            console.log(`Fetching QR code from: ${url}`);

            const response = await fetch(url);
            const result = await response.json();

            if (result.success) {
                console.log('QR Code loaded successfully, updating both main panel and modal');
                // 調用父類方法更新主面板
                super.displayCustomerQRCode(result.qr_data);

                // 更新主面板QR信息
                document.getElementById('customer-qr-table').textContent = result.table_number || '--';
                document.getElementById('customer-qr-entry-time').textContent = result.entry_time || '--';
                document.getElementById('customer-qr-lockers').textContent = result.lockers || '--';
                document.getElementById('customer-qr-text').textContent = result.qr_code || '--';

                // 顯示主面板QR Code區
                document.getElementById('customer-qr-section').classList.remove('hidden');
                document.getElementById('reprint-qr-btn').disabled = false;

                // 更新模態框QR Code
                this.displayCustomerQRCodeInModal(result.qr_data, result);
            }
        } catch (error) {
            console.error('載入QR Code失敗:', error);
            this.addMessage('載入QR Code失敗: ' + error.message, 'error');
        }
    }

    // 在模態框中顯示QR Code
    displayCustomerQRCodeInModal(qrData, qrInfo) {
        console.log('displayCustomerQRCodeInModal called', { qrData: qrData ? '有數據' : '無數據', qrInfo: !!qrInfo });

        const canvas = document.getElementById('customer-modal-qr-canvas');
        const placeholder = document.getElementById('customer-modal-qr-placeholder');
        const qrSection = document.getElementById('customer-modal-qr-section');

        if (!canvas || !placeholder || !qrSection) {
            console.warn('Modal QR Code elements not found');
            return;
        }

        // 如果qrData為空，隱藏QR Code區域
        if (!qrData) {
            console.log('QR數據為空，隱藏模態框QR Code區域');
            qrSection.classList.add('hidden');
            document.getElementById('reprint-modal-qr-btn').disabled = true;
            return;
        }

        if (qrData.startsWith('data:image')) {
            // 如果是base64圖片
            const img = new Image();
            img.onload = () => {
                console.log('Modal QR Code圖片加載成功');
                const ctx = canvas.getContext('2d');
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

                // 隱藏placeholder，顯示canvas
                placeholder.classList.add('hidden');
                placeholder.style.display = 'none';
                canvas.classList.remove('hidden');
                canvas.style.display = '';
            };
            img.onerror = () => {
                console.error('Modal QR Code圖片加載失敗');
                this.drawQRCodeTextInModal(canvas, qrData);

                // 隱藏placeholder，顯示canvas
                placeholder.classList.add('hidden');
                placeholder.style.display = 'none';
                canvas.classList.remove('hidden');
                canvas.style.display = '';
            };
            img.src = qrData;
        } else {
            // 如果是文本，直接繪製文本
            this.drawQRCodeTextInModal(canvas, qrData);

            // 隱藏placeholder，顯示canvas
            placeholder.classList.add('hidden');
            placeholder.style.display = 'none';
            canvas.classList.remove('hidden');
            canvas.style.display = '';
        }

        // 更新模態框QR信息
        if (qrInfo) {
            document.getElementById('customer-modal-qr-table').textContent = qrInfo.table_number || '--';
            document.getElementById('customer-modal-qr-entry-time').textContent = qrInfo.entry_time || '--';
            document.getElementById('customer-modal-qr-lockers').textContent = qrInfo.lockers || '--';
            document.getElementById('customer-modal-qr-text').textContent = qrInfo.qr_code || '--';
        }

        // 顯示模態框QR Code區
        qrSection.classList.remove('hidden');
        document.getElementById('reprint-modal-qr-btn').disabled = false;
    }

    // 在模態框中繪製QR Code文本
    drawQRCodeTextInModal(canvas, qrData) {
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#000';
        ctx.font = '14px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(qrData.substring(0, 20) || '無QR Code資料', canvas.width / 2, canvas.height / 2);
        ctx.fillText(qrData.substring(20, 40) || '', canvas.width / 2, canvas.height / 2 + 20);
    }

    // 重寫reprintQRCode方法 - 通過打印隊列實際打印QR Code小票
    async reprintQRCode() {
        if (!this.selectedCustomer) {
            this.addMessage('請先選擇客人', 'warning');
            return;
        }

        try {
            this.addMessage('正在重新打印QR Code小票...', 'info');

            const response = await fetch('/api/receipt/reprint-qr', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    customer_id: this.selectedCustomer.id,
                    store_id: this.selectedStoreId || ''
                })
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.user_message || errorData.message || `HTTP ${response.status}`);
            }

            const result = await response.json();
            if (result.success) {
                this.addMessage('QR Code小票重印成功', 'success');
                console.log('QR重印結果:', result);
            } else {
                throw new Error(result.message || '重印失敗');
            }
        } catch (error) {
            console.error('重新打印QR Code錯誤:', error);
            this.addMessage('重新打印失敗: ' + error.message, 'error');
        }
    }

    // 重寫clearSelectedCustomer方法以同時清除模態框
    clearSelectedCustomer() {
        console.log('[EnhancedCashier] clearSelectedCustomer called');
        // 調用deselectCustomer來處理所有清理工作，包括隱藏客人詳情模態框
        this.deselectCustomer();
    }

    // 匯出商品到CSV文件
    async exportProductsToCSV() {
        if (!this.isAuthenticated) {
            this.addMessage('請先登入以匯出商品', 'warning');
            this.showLoginModal();
            return;
        }

        try {
            this.addMessage('正在匯出商品數據...', 'info');

            // 從API獲取所有商品（不分頁）
            const response = await this.fetchWithAuth('/api/products?page_size=1000');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.message || '匯出商品失敗');
            }

            const products = result.data.products || [];

            if (products.length === 0) {
                this.addMessage('沒有商品可匯出', 'warning');
                return;
            }

            // 準備CSV內容 - 不包含標題行，第一行直接是商品數據
            const csvRows = [];

            // 數據行（直接添加商品數據，不添加標題行）
            products.forEach((product, index) => {
                const row = [
                    product.name || '',
                    product.category || '',
                    product.id || '', // UUID是產品的id字段
                    product.price || 0,
                    product.product_order || 0
                ];
                csvRows.push(row);
            });

            console.log('總CSV行數（不含標題）:', csvRows.length);

            // 將CSV行轉換為字符串
            const csvContent = csvRows.map(row =>
                row.map(field => {
                    // 將字段轉換為字符串，處理特殊字符
                    const fieldStr = String(field);
                    // 如果字段包含逗號、引號或換行符，用引號包圍並轉義引號
                    if (fieldStr.includes(',') || fieldStr.includes('"') || fieldStr.includes('\n') || fieldStr.includes('\r')) {
                        return `"${fieldStr.replace(/"/g, '""')}"`;
                    }
                    return fieldStr;
                }).join(',')
            ).join('\n');

            // 創建Blob和下載鏈接
            const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `products_export_${new Date().toISOString().split('T')[0]}.csv`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);

            this.addMessage(`成功匯出 ${products.length} 個商品`, 'success');

        } catch (error) {
            console.error('匯出商品失敗:', error);
            this.addMessage(`匯出商品失敗: ${error.message}`, 'error');
        }
    }

    /**
     * 檢查選擇的分店是否為總部
     * @param {string} storeId - 分店ID
     * @returns {boolean} 是否為總部
     */
    isHeadquartersStore(storeId) {
        if (!storeId) return false;

        // 從可訪問分店列表中查找分店
        const store = this.accessibleStores.find(s => s.id === storeId);
        if (!store) return false;

        // 判斷邏輯：
        // 1. 分店名稱包含"總部"
        // 2. 分店代碼為"HEADQUARTERS"或"HQ"
        // 3. 或者有其他標誌（可擴展）
        const storeName = store.store_name || store.name || '';
        const storeCode = store.store_code || store.code || '';

        const isHeadquarters =
            storeName.includes('總部') ||
            storeName.includes('总部') ||
            storeCode === 'HEADQUARTERS' ||
            storeCode === 'HQ' ||
            storeCode === 'headquarters' ||
            storeName.includes('Headquarters');

        console.log(`isHeadquartersStore檢查: storeId=${storeId}, name=${storeName}, code=${storeCode}, isHeadquarters=${isHeadquarters}`);
        return isHeadquarters;
    }

    /**
     * 根據分店選擇更新分頁顯示
     * @param {string} storeId - 選擇的分店ID
     */
    updateTabsBasedOnStore(storeId) {
        console.log(`updateTabsBasedOnStore: 更新分頁顯示, storeId=${storeId}`);
        console.log(`updateTabsBasedOnStore: accessibleStores=${this.accessibleStores?.length}`, this.accessibleStores?.map(s => ({id: s.id, name: s.store_name})));

        if (!this.isAuthenticated) {
            console.log('updateTabsBasedOnStore: 用戶未登入，跳過分頁更新');
            return;
        }

        // 如果沒有可訪問分店，延遲處理
        if (!this.accessibleStores || this.accessibleStores.length === 0) {
            console.log('updateTabsBasedOnStore: 可訪問分店尚未加載，等待100ms後重試');
            setTimeout(() => {
                console.log('updateTabsBasedOnStore: 延遲後重新嘗試');
                this.updateTabsBasedOnStore(storeId);
            }, 100);
            return;
        }

        const isHeadquarters = this.isHeadquartersStore(storeId);
        const isAdmin = this.currentEmployee && this.currentEmployee.role === 'admin';
        console.log(`updateTabsBasedOnStore: isHeadquarters=${isHeadquarters}, isAdmin=${isAdmin}`);

        // 獲取當前分店的設置（特別是use_lockers）
        let useLockers = 1; // 默認使用儲物柜 (1=使用, 0=不使用)
        const currentStore = this.accessibleStores.find(store => store.id === storeId);
        if (currentStore) {
            // store.use_lockers: 1=使用儲物柜, 0=不使用儲物柜（默認1）
            useLockers = currentStore.use_lockers !== undefined ? currentStore.use_lockers : 1;
            console.log(`updateTabsBasedOnStore: 分店 ${storeId} 的 use_lockers=${useLockers} (1=使用儲物柜, 0=不使用)`);
        } else {
            console.warn(`updateTabsBasedOnStore: 找不到分店 ${storeId} 的詳細信息，使用默認設置 use_lockers=1`);
        }

        // 定義分頁組
        const headquartersTabs = ['settings', 'device-control', 'employee-management', 'store-management', 'receipt-management', 'reports', 'host-config', 'booking'];
        // 根據分店的儲物柜設置決定是否包含儲物柜管理分頁
        const branchTabsBase = ['products', 'dashboard', 'reports', 'host-config', 'booking'];
        const branchTabs = useLockers === 1 ? [...branchTabsBase, 'locker-management'] : branchTabsBase;
        console.log(`updateTabsBasedOnStore: 分店分頁組: ${branchTabs.join(', ')} (use_lockers=${useLockers})`);

        // 所有分頁列表
        const allTabs = [...headquartersTabs, ...branchTabs];

        // 隱藏所有分頁按鈕並禁用
        document.querySelectorAll('.tab-button').forEach(button => {
            button.style.display = 'none';
            button.disabled = true;
            button.style.opacity = '0.5';
            button.style.cursor = 'default';
        });

        // 顯示相應的分頁組
        const tabsToShow = isHeadquarters ? headquartersTabs : branchTabs;
        console.log(`updateTabsBasedOnStore: 顯示的分頁: ${tabsToShow.join(', ')}`);

        tabsToShow.forEach(tabName => {
            const button = document.querySelector(`.tab-button[data-tab="${tabName}"]`);
            if (button) {
                // 檢查權限：如果是員工管理分頁且不是管理員，則隱藏
                if (tabName === 'employee-management' && !isAdmin) {
                    console.log('updateTabsBasedOnStore: 隱藏員工管理分頁（非管理員用戶）');
                    button.style.display = 'none';
                    return;
                }

                button.style.display = '';
                // 啟用標籤按鈕
                button.disabled = false;
                button.style.opacity = '1';
                button.removeAttribute('disabled');
                button.style.cursor = 'pointer';

                // 如果當前活動分頁被隱藏，切換到第一個可見分頁
                if (this.currentTab === tabName) {
                    button.classList.add('active');
                } else {
                    button.classList.remove('active');
                }
            } else {
                console.warn(`找不到分頁按鈕: ${tabName}`);
            }
        });

        // 根據是否為總部修改統計報告標籤文本
        const reportsButton = document.querySelector(`.tab-button[data-tab="reports"]`);
        if (reportsButton && reportsButton.style.display !== 'none') {
            const spanElement = reportsButton.querySelector('span[data-i18n="tabReports"]') || reportsButton.querySelector('span');
            if (spanElement) {
                if (isHeadquarters) {
                    spanElement.textContent = '銷售歷史(AliyunOnly)';
                    console.log('將統計報告標籤文本改為: 銷售歷史 (總部模式)');
                } else {
                    spanElement.textContent = '統計報告';
                    console.log('將統計報告標籤文本改為: 統計報告 (分店模式)');
                }
            }
        }

        // 如果當前活動分頁被隱藏，切換到第一個可見分頁
        const currentTabButton = document.querySelector(`.tab-button[data-tab="${this.currentTab}"]`);
        if (!currentTabButton || currentTabButton.style.display === 'none') {
            const firstVisibleTab = tabsToShow.find(tabName => {
                if (tabName === 'employee-management' && !isAdmin) return false;
                return true;
            });
            if (firstVisibleTab) {
                console.log(`updateTabsBasedOnStore: 當前分頁 ${this.currentTab} 被隱藏，切換到 ${firstVisibleTab}`);
                this.switchTab(firstVisibleTab);
            }
        }
        // 根據是否為總部控制歷史銷售卡片的顯示
        this.updateHistoricalSalesCardVisibility(isHeadquarters);

        // 更新今日統計卡片標題
        this.updateTodayStatsCardTitle(isHeadquarters);

        // 更新今日結賬詳細記錄卡片可見性
        this.updateTodayCheckoutRecordsCardVisibility(isHeadquarters);

        // 更新今日統計卡片可見性
        this.updateTodayStatsCardVisibility(isHeadquarters);

        // 根據是否為總部控制購物車側邊欄顯示
        this.updateShoppingCartSidebarVisibility(isHeadquarters);

        // 隱藏非管理員的商品管理按鈕
        this.hideProductManagementButtonsIfNotAdmin(isAdmin);
    }

    /**
     * 根據是否為總部更新購物車側邊欄的可見性
     * @param {boolean} isHeadquarters - 是否為總部分店
     */
    updateShoppingCartSidebarVisibility(isHeadquarters) {
        console.log(`updateShoppingCartSidebarVisibility called: isHeadquarters=${isHeadquarters}`);
        const shoppingCartSidebar = document.querySelector('.shopping-cart-sidebar');
        const mainContentArea = document.querySelector('.main-content-area');
        const mainContent = document.querySelector('.main-content');

        if (shoppingCartSidebar && mainContentArea && mainContent) {
            if (isHeadquarters) {
                shoppingCartSidebar.style.display = 'none';
                mainContentArea.style.width = '100%';
                // 添加總部模式類，用於調整padding
                mainContent.classList.add('headquarters-mode');
                console.log('購物車側邊欄已隱藏，主內容區域寬度設置為100%（總部分店）');

            } else {
                shoppingCartSidebar.style.display = '';
                mainContentArea.style.width = '';
                // 移除總部模式類
                mainContent.classList.remove('headquarters-mode');
                console.log('購物車側邊欄已顯示，主內容區域寬度恢復（分店）');

            }
        } else {
            console.warn('找不到購物車側邊欄或主內容區域元素');
        }
    }

    /**
     * 根據是否為總部更新歷史銷售卡片的可見性
     * @param {boolean} isHeadquarters - 是否為總部分店
     */
    updateHistoricalSalesCardVisibility(isHeadquarters) {
        console.log(`updateHistoricalSalesCardVisibility called: isHeadquarters=${isHeadquarters}`);

        // 通過內容查找卡片，不依賴位置
        let historicalSalesCard = null;
        let todayStatsCard = null;

        // 查找所有卡片
        const allCards = document.querySelectorAll('#tab-reports .card');

        for (const card of allCards) {
            const h2 = card.querySelector('h2');
            if (!h2) continue;

            const text = h2.textContent || '';
            const spanElement = h2.querySelector('span');
            const spanText = spanElement ? spanElement.textContent || '' : '';

            // 檢查是否為歷史銷售卡片
            if (text.includes('歷史銷售') || text.includes('銷售歷史') || h2.querySelector('.fa-history')) {
                historicalSalesCard = card;
            }

            // 檢查是否為今日統計卡片
            if (text.includes('今日統計') || text.includes('今日各店統計') || text.includes('本日銷售') ||
                spanText.includes('今日統計') || spanText.includes('今日各店統計') || spanText.includes('本日銷售')) {
                todayStatsCard = card;
            }

            // 如果兩個卡片都找到了，提前結束
            if (historicalSalesCard && todayStatsCard) break;
        }

        if (!historicalSalesCard || !todayStatsCard) {
            console.warn('卡片未找到，historicalSalesCard:', !!historicalSalesCard, 'todayStatsCard:', !!todayStatsCard);
            return;
        }

        console.log(`卡片找到: 歷史銷售卡片和今日統計卡片`);

        // 獲取目標容器
        const leftPanel = document.querySelector('#tab-reports .left-panel');
        const rightPanelLeftColumn = document.querySelector('#tab-reports .right-panel .left-column');

        if (!leftPanel || !rightPanelLeftColumn) {
            console.warn('找不到面板容器');
            return;
        }

        if (isHeadquarters) {
            // 總部模式：保持原始位置（歷史銷售在左面板，本日銷售在右面板左側列）
            if (historicalSalesCard.parentNode !== leftPanel) {
                leftPanel.appendChild(historicalSalesCard);
            }

            if (todayStatsCard.parentNode !== rightPanelLeftColumn) {
                // 確保本日銷售卡片是右面板左側列的第一個卡片
                const firstCard = rightPanelLeftColumn.querySelector('.card:first-child');
                if (firstCard && firstCard !== todayStatsCard) {
                    rightPanelLeftColumn.insertBefore(todayStatsCard, firstCard);
                } else {
                    rightPanelLeftColumn.appendChild(todayStatsCard);
                }
            }

            // 兩個卡片都顯示
            historicalSalesCard.style.display = '';
            historicalSalesCard.classList.remove('hidden');
            todayStatsCard.style.display = '';
            todayStatsCard.classList.remove('hidden');
        } else {
            // 非總部分店模式：交換卡片位置
            // 今日統計卡片移動到左面板
            if (todayStatsCard.parentNode !== leftPanel) {
                leftPanel.appendChild(todayStatsCard);
            }

            // 歷史銷售卡片移動到右面板左側列（作為第一個卡片）
            if (historicalSalesCard.parentNode !== rightPanelLeftColumn) {
                const firstCard = rightPanelLeftColumn.querySelector('.card:first-child');
                if (firstCard && firstCard !== historicalSalesCard) {
                    rightPanelLeftColumn.insertBefore(historicalSalesCard, firstCard);
                } else {
                    rightPanelLeftColumn.appendChild(historicalSalesCard);
                }
            }

            // 隱藏歷史銷售卡片
            historicalSalesCard.style.display = 'none';
            historicalSalesCard.classList.add('hidden');
        }
    }

    /**
     * 更新今日統計卡片標題
     * 總部分店顯示"今日各店統計"，非總部分店顯示"今日統計"
     */
    updateTodayStatsCardTitle(isHeadquarters) {
        console.log(`updateTodayStatsCardTitle called: isHeadquarters=${isHeadquarters}`);

        // 查找今日統計卡片 - 可能在 #tab-reports 中
        let tabContainer = document.getElementById('tab-reports');
        if (!tabContainer) {
            console.warn('找不到 #tab-reports 容器，嘗試 #tab-dashboard');
            tabContainer = document.getElementById('tab-dashboard');
        }

        if (!tabContainer) {
            console.warn('找不到任何標籤容器');
            return;
        }

        // 遍歷所有卡片，查找包含"今日統計"標題的卡片
        let todayStatsCard = null;
        const cards = tabContainer.querySelectorAll('.card');

        for (const card of cards) {
            const h2 = card.querySelector('h2');
            if (h2) {
                const span = h2.querySelector('span');
                const text = h2.textContent;
                const spanText = span ? span.textContent : '';

                // 查找包含"今日統計"或"本日銷售"的卡片
                if (text.includes('今日統計') || text.includes('本日銷售') ||
                    spanText.includes('今日統計') || spanText.includes('本日銷售')) {
                    todayStatsCard = card;
                    break;
                }
            }
        }

        if (!todayStatsCard) {
            console.warn('找不到今日統計卡片，卡片數量:', cards.length);
            // 輸出所有卡片的標題以便調試
            cards.forEach((card, index) => {
                const h2 = card.querySelector('h2');
                console.log(`卡片 ${index}:`, h2 ? h2.textContent : '無標題');
            });
            return;
        }

        // 查找卡片標題
        const cardTitle = todayStatsCard.querySelector('h2');
        if (!cardTitle) {
            console.warn('找不到今日統計卡片標題');
            return;
        }

        // 檢查是否為今日統計卡片（通過標題判斷）
        const cardText = cardTitle.textContent || '';
        const spanElement = cardTitle.querySelector('span');
        const spanText = spanElement ? spanElement.textContent || '' : '';

        const isTodayStatsCard = cardText.includes('今日統計') ||
                                 cardText.includes('今日营业') ||
                                 cardText.includes('本日銷售') ||
                                 spanText.includes('今日統計') ||
                                 spanText.includes('今日营业') ||
                                 spanText.includes('本日銷售');

        if (!isTodayStatsCard) {
            console.warn('找到的卡片不是今日統計卡片，標題:', cardText, 'span文本:', spanText);
            return;
        }

        // 更新標題
        if (isHeadquarters) {
            // 總部分店：顯示"本日銷售"
            const spanElement = cardTitle.querySelector('span');
            if (spanElement) {
                spanElement.textContent = '本日銷售';
            } else {
                // 如果沒有span元素，直接修改整個h2的內容
                const icon = cardTitle.querySelector('i');
                if (icon) {
                    cardTitle.innerHTML = `<i class="${icon.className}"></i> <span>本日銷售</span>`;
                } else {
                    cardTitle.textContent = '本日銷售';
                }
            }
            console.log('今日統計卡片標題已更新為: 本日銷售');
        } else {
            // 非總部分店：顯示"今日統計"
            const spanElement = cardTitle.querySelector('span');
            if (spanElement) {
                spanElement.textContent = '今日統計';
            } else {
                // 如果沒有span元素，直接修改整個h2的內容
                const icon = cardTitle.querySelector('i');
                if (icon) {
                    cardTitle.innerHTML = `<i class="${icon.className}"></i> <span>今日統計</span>`;
                } else {
                    cardTitle.textContent = '今日統計';
                }
            }
            console.log('今日統計卡片標題已更新為: 今日統計');
        }
    }

    /**
     * 更新今日結賬詳細記錄卡片可見性
     * 總部分店隱藏，非總部分店顯示
     */
    updateTodayCheckoutRecordsCardVisibility(isHeadquarters) {
        console.log(`updateTodayCheckoutRecordsCardVisibility called: isHeadquarters=${isHeadquarters}, selectedStoreId=${this.selectedStoreId}`);

        // 查找今日結賬詳細記錄卡片
        const tabReports = document.getElementById('tab-reports');
        if (!tabReports) {
            console.warn('找不到 #tab-reports 容器');
            return;
        }

        // 遍歷所有卡片，查找包含"今日結賬詳細記錄"標題的卡片
        let checkoutRecordsCard = null;
        const cards = tabReports.querySelectorAll('.card');

        for (const card of cards) {
            const h2 = card.querySelector('h2');
            if (h2 && (h2.textContent.includes('今日結賬詳細記錄') ||
                      (h2.querySelector('span') && h2.querySelector('span').textContent.includes('今日結賬詳細記錄')))) {
                checkoutRecordsCard = card;
                break;
            }
        }

        if (!checkoutRecordsCard) {
            console.warn('找不到今日結賬詳細記錄卡片，卡片數量:', cards.length);
            // 輸出所有卡片的標題以便調試
            cards.forEach((card, index) => {
                const h2 = card.querySelector('h2');
                console.log(`卡片 ${index}:`, h2 ? h2.textContent : '無標題');
            });
            return;
        }

        console.log(`今日結賬詳細記錄卡片找到: ${isHeadquarters ? '隱藏' : '顯示'}`);

        if (isHeadquarters) {
            // 總部分店：隱藏今日結賬詳細記錄卡片
            checkoutRecordsCard.style.display = 'none';
            checkoutRecordsCard.classList.add('hidden');
            console.log('已隱藏今日結賬詳細記錄卡片');

            // 清空表格數據
            const tableBody = document.querySelector('#today-checkout-records-table tbody');
            if (tableBody) {
                tableBody.innerHTML = '';
            }
            // 清空記錄計數
            const countElement = document.getElementById('today-checkout-records-count');
            if (countElement) {
                countElement.textContent = '共 0 筆記錄';
            }
        } else {
            // 非總部分店：顯示今日結賬詳細記錄卡片
            checkoutRecordsCard.style.display = '';
            checkoutRecordsCard.classList.remove('hidden');
            console.log('已顯示今日結賬詳細記錄卡片');
        }
    }

    /**
     * 更新今日統計卡片可見性
     * 總部分店：隱藏今日統計卡片（改為顯示本日銷售卡片）
     * 其他分店：顯示今日統計卡片
     * @param {boolean} isHeadquarters - 是否為總部分店
     */
    updateTodayStatsCardVisibility(isHeadquarters) {
        console.log(`updateTodayStatsCardVisibility called: isHeadquarters=${isHeadquarters}`);

        // 查找今日統計卡片 - 可能在 #tab-reports 中
        let tabContainer = document.getElementById('tab-reports');
        if (!tabContainer) {
            console.warn('找不到 #tab-reports 容器，嘗試 #tab-dashboard');
            tabContainer = document.getElementById('tab-dashboard');
        }

        if (!tabContainer) {
            console.warn('找不到任何標籤容器');
            return;
        }

        // 遍歷所有卡片，查找包含"今日統計"或"今日各店統計"標題的卡片
        let todayStatsCard = null;
        const cards = tabContainer.querySelectorAll('.card');

        for (const card of cards) {
            const h2 = card.querySelector('h2');
            if (h2) {
                const span = h2.querySelector('span');
                const text = h2.textContent;
                const spanText = span ? span.textContent : '';

                // 查找包含"今日統計"、"今日各店統計"或"本日銷售"的卡片
                if (text.includes('今日統計') || text.includes('今日各店統計') || text.includes('本日銷售') ||
                    spanText.includes('今日統計') || spanText.includes('今日各店統計') || spanText.includes('本日銷售')) {
                    todayStatsCard = card;
                    break;
                }
            }
        }

        if (!todayStatsCard) {
            console.warn('找不到今日統計卡片，卡片數量:', cards.length);
            return;
        }

        console.log(`今日統計卡片找到: 總是顯示（內容根據總部/分店模式變化）`);

        // 不再隱藏卡片，卡片內容由 updateHeadquartersTodayStatsTable 和 showStatsGrid 控制
        todayStatsCard.style.display = '';
        todayStatsCard.classList.remove('hidden');

        // 不再需要處理本日銷售卡片可見性（本日銷售卡片已不存在）
        // this.updateDailySalesCardVisibility(isHeadquarters);
    }

    /**
     * 更新本日銷售卡片可見性
     * @param {boolean} isHeadquarters - 是否為總部分店
     */
    updateDailySalesCardVisibility(isHeadquarters) {
        // 本日銷售卡片已不存在（已與今日統計卡片合併）
        // 此方法保留為空方法以保持兼容性
        console.log(`updateDailySalesCardVisibility called (已棄用): isHeadquarters=${isHeadquarters}`);
    }

    /**
     * 加載可訪問的分店列表（覆蓋父類方法）
     * 根據員工角色返回可訪問的分店：
     * - staff員工：只能訪問自己的分店
     * - admin員工：可以訪問所有分店
     */
    async loadAccessibleStores() {
        console.log('EnhancedCashierSystem.loadAccessibleStores called');
        console.log(`loadAccessibleStores: isAuthenticated=${this.isAuthenticated}, currentEmployee=${!!this.currentEmployee}`);

        // 如果是父類初始化期間，調用父類方法
        if (this.isSuperInitializing) {
            console.log('父類初始化期間，調用父類loadAccessibleStores');
            return super.loadAccessibleStores();
        }

        if (this.currentEmployee) {
            console.log(`loadAccessibleStores: employee role=${this.currentEmployee.role}, store_id=${this.currentEmployee.store_id}`);
        }

        // 如果未登入，不執行
        if (!this.isAuthenticated || !this.currentEmployee) {
            console.log('未登入，不執行 loadAccessibleStores');
            console.log(`詳細狀態: isAuthenticated=${this.isAuthenticated}, currentEmployee存在=${!!this.currentEmployee}`);
            return;
        }

        try {
            const response = await fetch('/api/stores');
            const result = await response.json();

            if (result.success) {
                let stores = result.data || [];
                console.log(`獲得分店列表: ${stores.length} 個分店`, stores.map(s => ({id: s.id, name: s.store_name, code: s.store_code})));

                // 強制設置員工的分店ID（如果是staff角色）
                if (this.currentEmployee.role === 'staff' && this.currentEmployee.store_id) {
                    console.log(`員工(staff)角色，強制設置分店ID為所屬分店: ${this.currentEmployee.store_id}`);
                    this.selectedStoreId = this.currentEmployee.store_id;

                    // 檢查員工的分店是否存在於分店列表中
                    const employeeStoreExists = stores.some(store => store.id === this.currentEmployee.store_id);
                    if (!employeeStoreExists) {
                        console.error(`錯誤：員工的分店 ${this.currentEmployee.store_id} 不存在於分店列表中！`);
                    }
                }

                // 如果是員工(staff)角色，只保留所屬分店
                if (this.currentEmployee.role === 'staff' && this.currentEmployee.store_id) {
                    console.log(`員工(staff)角色，只保留所屬分店 ID: ${this.currentEmployee.store_id}`);
                    stores = stores.filter(store => store.id === this.currentEmployee.store_id);
                }

                this.accessibleStores = stores;
                console.log(`可訪問分店: ${this.accessibleStores.length} 個`, this.accessibleStores.map(s => ({id: s.id, name: s.store_name})));

                // 設置默認選擇的分店
                if (this.accessibleStores.length > 0) {
                    // 對於員工(staff)角色，總是強制設置為所屬分店
                    if (this.currentEmployee.role === 'staff' && this.currentEmployee.store_id) {
                        this.selectedStoreId = this.currentEmployee.store_id;
                        console.log(`員工(staff)角色，強制設置分店ID為所屬分店: ${this.selectedStoreId}`);
                    } else {
                        // 管理員或其他情況，檢查當前選擇是否有效
                        const hasValidSelection = this.selectedStoreId &&
                            this.accessibleStores.some(store => store.id === this.selectedStoreId);
                        console.log(`selectedStoreId: ${this.selectedStoreId}, hasValidSelection: ${hasValidSelection}`);

                        if (!hasValidSelection) {
                            // 選擇第一個分店
                            this.selectedStoreId = this.accessibleStores[0].id;
                            console.log(`管理員/其他情況，設置分店ID為第一個分店: ${this.selectedStoreId}`);
                        }
                    }
                }

                this.updateStoreSelector();

                // 顯示分店選擇器（如果有可訪問的分店）
                const storeSelectorContainer = document.getElementById('store-selector-container');
                if (storeSelectorContainer && this.accessibleStores.length > 0) {
                    storeSelectorContainer.classList.remove('hidden');
                }

                // 如果是員工(staff)角色，禁用分店選擇器
                if (this.currentEmployee.role === 'staff') {
                    const storeSelector = document.getElementById('store-selector');
                    if (storeSelector) {
                        storeSelector.disabled = true;
                        storeSelector.style.opacity = '0.5';
                        console.log('已禁用分店選擇器（員工角色限制）');
                    }
                }

                // 確保更新標籤頁顯示
                console.log(`loadAccessibleStores: 確保更新標籤頁顯示，selectedStoreId=${this.selectedStoreId}`);
                if (this.selectedStoreId) {
                    this.updateTabsBasedOnStore(this.selectedStoreId);
                }
            } else {
                console.error('API返回失敗，無法加載分店列表:', result);
                this.accessibleStores = [];
                if (!this.hasShownStoreLoadWarning) {
                    this.addMessage('分店資訊加載失敗：服務器返回錯誤', 'warning');
                    this.hasShownStoreLoadWarning = true;
                }
            }
        } catch (error) {
            console.error('加載分店列表失敗:', error);
            // 設置空數組以避免無限重試
            this.accessibleStores = [];
            console.warn('分店列表加載失敗，設置為空數組。錯誤詳情:', error.message);
            // 顯示用戶友好的提示
            if (!this.hasShownStoreLoadWarning) {
                this.addMessage('分店資訊加載失敗，部分功能可能受限。請檢查網絡連接或聯繫管理員。', 'warning');
                this.hasShownStoreLoadWarning = true; // 防止重複提示
            }
        }
    }

    /**
     * 更新分店選擇器UI（覆蓋父類方法）
     * 添加員工角色檢查：如果是員工(staff)角色，則禁用分店選擇器
     * 強制確保選擇正確的分店ID
     */
    updateStoreSelector() {
        console.log('EnhancedCashierSystem.updateStoreSelector called');
        console.log(`目標分店ID: ${this.selectedStoreId}`);

        // 保存當前的selectedStoreId（可能在父類方法中被覆蓋）
        const targetStoreId = this.selectedStoreId;

        // 首先調用父類方法來設置基本UI
        super.updateStoreSelector();

        // 如果存在目標分店ID，且選擇器當前值與之不同，強制設置
        if (targetStoreId) {
            const storeSelector = document.getElementById('store-selector');
            if (storeSelector && storeSelector.value !== targetStoreId.toString()) {
                console.log(`updateStoreSelector: 強制設置分店選擇器為 ${targetStoreId} (原值: ${storeSelector.value})`);
                storeSelector.value = targetStoreId;

                // 確保selectedStoreId保持為目標值（防止父類方法中的異步更新覆蓋）
                this.selectedStoreId = targetStoreId;
            }
        }

        // 如果是員工(staff)角色，禁用分店選擇器
        if (this.currentEmployee && this.currentEmployee.role === 'staff') {
            const storeSelector = document.getElementById('store-selector');
            if (storeSelector) {
                storeSelector.disabled = true;
                storeSelector.style.opacity = '0.5';
                console.log('updateStoreSelector: 已禁用分店選擇器（員工角色限制）');
            }

            // 確保更新標籤頁顯示
            console.log(`updateStoreSelector: 確保更新標籤頁顯示，selectedStoreId=${this.selectedStoreId}`);
            if (this.selectedStoreId) {
                this.updateTabsBasedOnStore(this.selectedStoreId);
            }
        }
    }

    /**
     * 處理分店選擇變化（覆蓋父類方法）
     * @param {string} storeId - 選擇的分店ID
     */
    handleStoreChange(storeId) {
        console.log(`EnhancedCashierSystem.handleStoreChange: storeId=${storeId}`);

        // 檢查員工角色：如果是員工(staff)角色，則阻止分店變更
        if (this.currentEmployee && this.currentEmployee.role === 'staff') {
            console.log(`員工(staff)角色，不允許變更分店。當前分店: ${this.selectedStoreId}, 嘗試變更為: ${storeId}`);

            // 強制恢復為員工所屬分店
            if (this.currentEmployee.store_id && storeId !== this.currentEmployee.store_id) {
                console.log(`員工嘗試變更分店，強制恢復為所屬分店: ${this.currentEmployee.store_id}`);

                // 更新UI顯示
                const storeSelector = document.getElementById('store-selector');
                if (storeSelector && storeSelector.value !== this.currentEmployee.store_id.toString()) {
                    storeSelector.value = this.currentEmployee.store_id;
                }

                // 顯示警告訊息
                this.addMessage('員工角色不允許變更分店', 'warning');
                return;
            }
        }

        // 調用父類方法（加載客人、統計等）
        super.handleStoreChange(storeId);

        // 更新分頁顯示
        this.updateTabsBasedOnStore(storeId);

        // 如果當前在統計報告分頁且不是總部分店，自動刷新今日結賬詳細記錄
        if (this.currentTab === 'reports' && !this.isHeadquartersStore(storeId)) {
            console.log(`handleStoreChange: 自動刷新今日結賬詳細記錄 (storeId=${storeId}, currentTab=${this.currentTab})`);
            this.loadTodayCheckoutRecords();
        }
    }

    /**
     * 重寫今日統計加載方法
     * 總部分店：顯示所有分店的今日統計
     * 其他分店：顯示單一分店的今日統計
     */
    async loadTodayStats() {
        console.log('EnhancedCashierSystem.loadTodayStats called');

        // 如果未選擇分店或未登入，使用父類方法
        if (!this.selectedStoreId || !this.isAuthenticated) {
            console.log('未選擇分店或未登入，使用父類方法');
            return super.loadTodayStats();
        }

        // 檢查是否為總部分店
        const isHeadquarters = this.isHeadquartersStore(this.selectedStoreId);
        console.log(`loadTodayStats: isHeadquarters=${isHeadquarters}, selectedStoreId=${this.selectedStoreId}`);

        if (!isHeadquarters) {
            // 非總部分店，使用父類方法
            console.log('非總部分店，使用父類方法');

            // 確保顯示統計網格，隱藏表格（如果存在）
            this.showStatsGrid();

            // 非管理員顯示過去三天明細
            const isNonAdmin = this.currentEmployee && this.currentEmployee.role !== 'admin';
            return super.loadTodayStats(isNonAdmin ? 4 : 1);
        }

        // 總部分店：獲取所有分店（排除總部）的今日統計
        try {
            // 獲取所有分店列表
            const storesResponse = await this.fetchWithAuth('/api/stores');
            const storesResult = await storesResponse.json();

            if (!storesResult.success) {
                throw new Error(storesResult.error || '獲取分店列表失敗');
            }

            let stores = storesResult.data || [];
            console.log(`獲得分店列表: ${stores.length} 個分店`, stores.map(s => ({id: s.id, name: s.store_name})));

            // 過濾掉總部分店
            const nonHeadquartersStores = stores.filter(store => !this.isHeadquartersStore(store.id));
            console.log(`非總部分店: ${nonHeadquartersStores.length} 個`, nonHeadquartersStores.map(s => ({id: s.id, name: s.store_name})));

            if (nonHeadquartersStores.length === 0) {
                // 沒有其他分店，顯示提示
                this.updateHeadquartersTodayStatsTable([]);
                return;
            }

            // 為每個分店獲取今日統計
            const storeStatsPromises = nonHeadquartersStores.map(async (store) => {
                try {
                    const statsUrl = `/api/cashier/stats/today?store_id=${store.id}`;
                    const response = await this.fetchWithAuth(statsUrl);
                    const result = await response.json();

                    if (result.success) {
                        return {
                            store_id: store.id,
                            store_name: store.store_name || store.name || `分店 ${store.id}`,
                            stats: result.stats || {}
                        };
                    } else {
                        return {
                            store_id: store.id,
                            store_name: store.store_name || store.name || `分店 ${store.id}`,
                            stats: {},
                            error: result.error
                        };
                    }
                } catch (error) {
                    return {
                        store_id: store.id,
                        store_name: store.store_name || store.name || `分店 ${store.id}`,
                        stats: {},
                        error: error.message
                    };
                }
            });

            const allStoreStats = await Promise.all(storeStatsPromises);
            console.log('所有分店統計數據:', allStoreStats);

            // 更新總部本日銷售卡片（取代今日各店統計）
            this.updateHeadquartersTodayStatsTable(allStoreStats);

        } catch (error) {
            console.error('加載總部今日統計失敗:', error);
            this.addMessage('加載今日統計失敗: ' + error.message, 'error');
        }
    }

    /**
     * 更新總部分店的本日銷售卡片（取代今日各店統計）
     * 顯示所有非總部分店的總營業額和總客數
     * @param {Array} storeStats - 所有分店的統計數據數組
     */
    updateHeadquartersTodayStatsTable(storeStats) {
        console.log('updateHeadquartersTodayStatsTable called (本日銷售卡片)', storeStats);

        // 獲取今日統計卡片 - 在 #tab-reports 的右側面板中
        const tabReports = document.getElementById('tab-reports');
        if (!tabReports) {
            console.warn('找不到 #tab-reports 容器');
            return;
        }
        console.log('找到 #tab-reports 容器');

        // 查找右側面板中的今日統計卡片
        const rightPanel = tabReports.querySelector('.right-panel');
        if (!rightPanel) {
            console.warn('找不到右側面板');
            console.log('tabReports 子元素:', Array.from(tabReports.children).map(c => c.className));
            return;
        }
        console.log('找到 .right-panel，子元素數量:', rightPanel.children.length);

        // 查找第一個卡片（今日統計卡片）
        let todayStatsCard = rightPanel.querySelector('.card:first-child');
        if (!todayStatsCard) {
            console.warn('找不到今日統計卡片');
            console.log('rightPanel 內的卡片:', Array.from(rightPanel.querySelectorAll('.card')).map(c => {
                const h2 = c.querySelector('h2');
                return h2 ? h2.textContent : '無標題';
            }));
            return;
        }
        console.log('找到今日統計卡片，標題:', todayStatsCard.querySelector('h2')?.textContent);

        // 修改卡片標題為"本日銷售"
        const cardTitle = todayStatsCard.querySelector('h2');
        if (cardTitle) {
            const spanElement = cardTitle.querySelector('span');
            if (spanElement) {
                spanElement.textContent = '本日銷售';
            } else {
                // 如果沒有span元素，直接修改整個h2的內容
                const icon = cardTitle.querySelector('i');
                if (icon) {
                    cardTitle.innerHTML = `<i class="${icon.className}"></i> <span>本日銷售</span>`;
                } else {
                    cardTitle.innerHTML = '<i class="fas fa-sun"></i> <span>本日銷售</span>';
                }
            }
        }

        // 隱藏原有的統計網格
        const statsGrid = todayStatsCard.querySelector('.stats-grid');
        if (statsGrid) {
            console.log('找到 .stats-grid，隱藏它');
            statsGrid.style.display = 'none';
        } else {
            console.log('找不到 .stats-grid');
        }

        // 總部模式不需要鎖定覆蓋層，隱藏它
        const lockOverlay = todayStatsCard.querySelector('.stats-lock-overlay');
        if (lockOverlay) {
            lockOverlay.style.display = 'none';
        }

        // 查找或創建本日銷售容器
        let dailySalesContainer = todayStatsCard.querySelector('.daily-sales-container');
        if (!dailySalesContainer) {
            console.log('找不到 .daily-sales-container，創建新的');
            dailySalesContainer = document.createElement('div');
            dailySalesContainer.className = 'daily-sales-container';
            todayStatsCard.appendChild(dailySalesContainer);
        } else {
            console.log('找到現有的 .daily-sales-container');
            // 確保容器可見（可能被 showStatsGrid 隱藏了）
            dailySalesContainer.style.display = '';
        }

        // 計算總營業額和總客數
        let totalRevenue = 0;
        let totalCustomers = 0;
        let storeCount = 0;

        storeStats.forEach(storeStat => {
            const stats = storeStat.stats;
            const revenue = stats.total_revenue || 0;
            const customers = stats.total_people || 0;

            totalRevenue += revenue;
            totalCustomers += customers;
            storeCount++;
        });

        // 創建本日銷售內容 - 逐一顯示各分店數據
        let html = '';

        if (storeCount === 0) {
            html = `
                <div class="empty-state">
                    <i class="fas fa-store"></i>
                    <p>暫無其他分店銷售數據</p>
                </div>
            `;
        } else {
            // 創建表格標頭
            html = `
                <div class="store-stats-table">
                    <div class="table-header">
                        <span>分店名稱</span>
                        <span>今日營業額</span>
                        <span>今日客數</span>
                    </div>
                    <div class="store-stats-list">
            `;

            // 逐一顯示每個分店的數據
            storeStats.forEach(storeStat => {
                const stats = storeStat.stats;
                const revenue = stats.total_revenue || 0;
                const customers = stats.total_people || 0;
                const storeName = storeStat.store_name || `分店 ${storeStat.store_id}`;

                html += `
                    <div class="store-stat-row">
                        <div class="store-name">${storeName}</div>
                        <div class="store-revenue">$${revenue.toLocaleString()}</div>
                        <div class="store-customers">${customers.toLocaleString()}</div>
                    </div>
                `;
            });

            // 添加總計行
            html += `
                    </div>
                    <div class="store-stats-total">
                        <div class="total-row">
                            <div class="total-label">總計 (${storeCount} 間分店):</div>
                            <div class="total-revenue">$${totalRevenue.toLocaleString()}</div>
                            <div class="total-customers">${totalCustomers.toLocaleString()}</div>
                        </div>
                    </div>
                </div>
            `;
        }

        console.log('設置 .daily-sales-container.innerHTML, 長度:', html.length);
        dailySalesContainer.innerHTML = html;
        console.log(`本日銷售卡片更新: 總營業額=$${totalRevenue}, 總客數=${totalCustomers}, 分店數=${storeCount}`);
        console.log('卡片內容設置完成，檢查 DOM 結構...');
    }

    /**
     * 更新總部分店的本日銷售卡片
     * 顯示所有非總部分店的總營業額和總客數
     * @param {Array} storeStats - 所有分店的統計數據數組
     */
    updateHeadquartersDailySalesCard(storeStats) {
        console.log('updateHeadquartersDailySalesCard called', storeStats);

        // 查找或創建本日銷售卡片容器
        const tabReports = document.getElementById('tab-reports');
        if (!tabReports) {
            console.warn('找不到 #tab-reports 容器');
            return;
        }

        // 查找左側面板
        const leftPanel = tabReports.querySelector('.left-panel');
        if (!leftPanel) {
            console.warn('找不到左側面板');
            return;
        }

        // 查找是否已有本日銷售卡片
        let dailySalesCard = leftPanel.querySelector('#daily-sales-card');
        if (!dailySalesCard) {
            // 創建新卡片（放在歷史銷售卡片之後）
            const historicalSalesCard = leftPanel.querySelector('.card:first-child');
            if (!historicalSalesCard) {
                console.warn('找不到歷史銷售卡片');
                return;
            }

            dailySalesCard = document.createElement('div');
            dailySalesCard.id = 'daily-sales-card';
            dailySalesCard.className = 'card';
            dailySalesCard.innerHTML = `
                <h2><i class="fas fa-sun"></i> <span>本日銷售</span></h2>
                <div class="stats-grid">
                    <div class="stat-item">
                        <div class="stat-value" id="daily-total-revenue">$0</div>
                        <div class="stat-label">今日總營業額</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value" id="daily-total-customers">0</div>
                        <div class="stat-label">今日總客數</div>
                    </div>
                </div>
            `;

            // 在歷史銷售卡片之後插入
            historicalSalesCard.parentNode.insertBefore(dailySalesCard, historicalSalesCard.nextSibling);
            console.log('已創建本日銷售卡片');
        }

        // 計算總營業額和總客數
        let totalRevenue = 0;
        let totalCustomers = 0;
        let storeCount = 0;

        storeStats.forEach(storeStat => {
            const stats = storeStat.stats;
            const revenue = stats.total_revenue || 0;
            const customers = stats.total_people || 0;

            totalRevenue += revenue;
            totalCustomers += customers;
            storeCount++;
        });

        // 更新卡片內容
        const revenueElement = dailySalesCard.querySelector('#daily-total-revenue');
        const customersElement = dailySalesCard.querySelector('#daily-total-customers');

        if (revenueElement) {
            revenueElement.textContent = `$${totalRevenue.toLocaleString()}`;
        }
        if (customersElement) {
            customersElement.textContent = totalCustomers.toLocaleString();
        }

        console.log(`本日銷售卡片更新: 總營業額=$${totalRevenue}, 總客數=${totalCustomers}, 分店數=${storeCount}`);

        // 如果沒有分店數據，顯示提示
        if (storeCount === 0) {
            const statsGrid = dailySalesCard.querySelector('.stats-grid');
            if (statsGrid) {
                statsGrid.innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-store"></i>
                        <p>暫無其他分店銷售數據</p>
                    </div>
                `;
            }
        }
    }

    /**
     * 顯示統計網格，隱藏表格（用於非總部分店）
     */
    showStatsGrid() {
        console.log('showStatsGrid called');

        // 通過內容查找今日統計卡片，不依賴位置
        let todayStatsCard = null;
        const allCards = document.querySelectorAll('#tab-reports .card');

        for (const card of allCards) {
            const h2 = card.querySelector('h2');
            if (!h2) continue;

            const text = h2.textContent || '';
            const spanElement = h2.querySelector('span');
            const spanText = spanElement ? spanElement.textContent || '' : '';

            // 檢查是否為今日統計卡片
            if (text.includes('今日統計') || text.includes('今日各店統計') || text.includes('本日銷售') ||
                spanText.includes('今日統計') || spanText.includes('今日各店統計') || spanText.includes('本日銷售')) {
                todayStatsCard = card;
                break;
            }
        }

        if (!todayStatsCard) {
            console.warn('找不到今日統計卡片');
            return;
        }

        // 確保卡片標題為"今日統計"
        const cardTitle = todayStatsCard.querySelector('h2');
        if (cardTitle) {
            const spanElement = cardTitle.querySelector('span');
            if (spanElement) {
                spanElement.textContent = '今日統計';
            } else {
                // 如果沒有span元素，直接修改整個h2的內容
                const icon = cardTitle.querySelector('i');
                if (icon) {
                    cardTitle.innerHTML = `<i class="${icon.className}"></i> <span>今日統計</span>`;
                } else {
                    cardTitle.innerHTML = '<i class="fas fa-chart-line"></i> <span>今日統計</span>';
                }
            }
        }

        // 顯示統計網格
        const statsGrid = todayStatsCard.querySelector('.stats-grid');
        if (statsGrid) {
            statsGrid.style.display = '';
        }

        // 隱藏本日銷售容器（如果存在）
        const dailySalesContainer = todayStatsCard.querySelector('.daily-sales-container');
        if (dailySalesContainer) {
            dailySalesContainer.style.display = 'none';
        }

        console.log('已恢復今日統計卡片顯示（分店模式）');
    }

    // 重新啟用模擬數據顯示
    enableMockData() {
        this.showMockData = true;
        this.alwaysShowMockData = true;

        // 保存設置到本地存儲
        localStorage.setItem('cashier_showMockData', 'true');
        localStorage.setItem('cashier_alwaysShowMockData', 'true');

        // 重新生成模擬數據
        this.mockCustomers = this.generateMockCustomers();

        // 重新載入客人數據
        this.loadCustomers();

        this.addMessage('模擬數據顯示已重新啟用', 'success');
    }

    // 覆蓋分店保存方法，添加「新增進場時輸入桌號」設置
    async saveStore(event) {
        event.preventDefault();

        const form = document.getElementById('store-form');
        if (!form) return;

        const storeId = document.getElementById('store-id').value;
        const isEdit = !!storeId;

        // 收集表單數據（映射到API字段名）
        const storeData = {
            store_name: document.getElementById('store-name').value,
            store_code: document.getElementById('store-code').value,
            address: document.getElementById('store-address').value,
            phone: document.getElementById('store-phone').value,
            email: document.getElementById('store-email').value,
            opening_hours: document.getElementById('store-opening-hours').value,
            status: document.getElementById('store-status').value,
            description: document.getElementById('store-description').value,
            use_lockers: document.getElementById('store-dont-use-lockers') ?
                (document.getElementById('store-dont-use-lockers').checked ? 0 : 1) : 1
        };

        // 處理JSON設定
        try {
            const settingsText = document.getElementById('store-settings').value;
            let settings = {};
            if (settingsText.trim()) {
                settings = JSON.parse(settingsText);
            }
            // 添加「新增進場時輸入桌號」設置
            const requireTableNumberCheckbox = document.getElementById('store-require-table-number');
            if (requireTableNumberCheckbox) {
                settings.require_table_number = requireTableNumberCheckbox.checked;
                console.log(`saveStore: 設置require_table_number為 ${requireTableNumberCheckbox.checked}`);
            }
            storeData.settings = JSON.stringify(settings);
            console.log('saveStore: 最終storeData:', storeData);
        } catch (error) {
            this.addMessage('JSON設定格式錯誤，請檢查格式', 'error');
            return;
        }

        // 驗證必填字段
        if (!storeData.store_name || !storeData.store_code) {
            this.addMessage('請填寫分店名稱和分店代碼', 'error');
            return;
        }

        // 檢查是否已登入
        if (!this.isAuthenticated || !this.currentToken) {
            this.addMessage('請先登入以保存分店設置', 'error');
            this.showLoginModal();
            return;
        }

        try {
            const url = isEdit ? `/api/stores/${storeId}` : '/api/stores';
            const method = isEdit ? 'PUT' : 'POST';

            // 構建headers，包含可選的身份驗證令牌
            const headers = {
                'Content-Type': 'application/json'
            };

            // 如果存在currentToken，添加Authorization header
            if (this.currentToken) {
                headers['Authorization'] = `Bearer ${this.currentToken}`;
                console.log(`saveStore: 使用令牌進行身份驗證，令牌長度: ${this.currentToken.length}`);
            } else {
                console.warn('saveStore: currentToken為空，將嘗試無身份驗證請求');
            }

            const response = await fetch(url, {
                method,
                headers,
                body: JSON.stringify(storeData)
            });

            console.log(`saveStore: 響應狀態: ${response.status} ${response.statusText}`);
            console.log(`saveStore: 響應headers:`, Object.fromEntries(response.headers.entries()));

            const result = await response.json();
            console.log(`saveStore: 響應結果:`, result);

            if (result.success) {
                this.addMessage(isEdit ? '分店更新成功' : '分店創建成功', 'success');
                this.clearStoreForm();
                await this.loadStores(); // 重新加載列表
            } else {
                console.error(`saveStore: API返回錯誤，狀態碼: ${response.status}, 錯誤信息: ${result.error}, 詳情: ${result.message}`);
                console.error(`saveStore: 當前員工信息:`, this.currentEmployee);
                console.error(`saveStore: 令牌長度: ${this.currentToken ? this.currentToken.length : 'null'}`);
                this.addMessage((isEdit ? '分店更新失敗' : '分店創建失敗') + ': ' + result.error, 'error');
            }
        } catch (error) {
            console.error('保存分店時發生錯誤:', error);
            this.addMessage('保存分店時發生錯誤: ' + error.message, 'error');
        }
    }

    // 覆蓋加載分店資料用於編輯
    async loadStoreForEdit(storeId) {
        try {
            console.log('loadStoreForEdit: 加載分店資料，storeId:', storeId);
            // 構建headers，包含可選的身份驗證令牌
            const headers = {};

            // 如果存在currentToken，添加Authorization header
            if (this.currentToken) {
                headers['Authorization'] = `Bearer ${this.currentToken}`;
            }

            const response = await fetch(`/api/stores/${storeId}`, { headers });
            if (!response.ok) {
                throw new Error(`API請求失敗: ${response.status}`);
            }

            const result = await response.json();
            if (!result.success) {
                throw new Error(result.error || '加載分店資料失敗');
            }

            const store = result.data;
            console.log('loadStoreForEdit: 從API獲取的分店數據:', store);
            console.log('loadStoreForEdit: 分店settings:', store.settings);

            // 填充表單字段
            document.getElementById('store-id').value = store.id;
            document.getElementById('store-name').value = store.store_name || store.name || '';
            document.getElementById('store-code').value = store.store_code || store.code || '';
            document.getElementById('store-address').value = store.address || '';
            document.getElementById('store-phone').value = store.phone || '';
            document.getElementById('store-email').value = store.email || '';
            document.getElementById('store-opening-hours').value = store.opening_hours || '';
            document.getElementById('store-status').value = store.status || 'active';
            document.getElementById('store-description').value = store.description || '';

            // 處理JSON設定
            const settingsTextarea = document.getElementById('store-settings');
            if (settingsTextarea) {
                try {
                    let settings = {};
                    // 處理settings字段，可能是字符串或對象
                    if (store.settings) {
                        if (typeof store.settings === 'string') {
                            // 如果是字符串，檢查是否為"[object Object]"
                            if (store.settings === '[object Object]') {
                                console.warn('loadStoreForEdit: settings是"[object Object]"字符串，視為空對象');
                                settings = {};
                            } else {
                                // 嘗試解析為JSON
                                try {
                                    settings = JSON.parse(store.settings);
                                } catch (parseErr) {
                                    console.warn('loadStoreForEdit: 解析settings JSON失敗:', parseErr, '原始值:', store.settings);
                                    settings = {};
                                }
                            }
                        } else if (typeof store.settings === 'object') {
                            // 已經是對象
                            settings = store.settings;
                        }
                    }
                    console.log('loadStoreForEdit: 處理後的settings:', settings);

                    // 設置「新增進場時輸入桌號」勾選框
                    const requireTableNumberCheckbox = document.getElementById('store-require-table-number');
                    if (requireTableNumberCheckbox) {
                        // 處理布林值，支援 true/false 字符串或布林類型
                        const requireTableNumberValue = settings.require_table_number;
                        requireTableNumberCheckbox.checked =
                            requireTableNumberValue === true ||
                            requireTableNumberValue === 'true' ||
                            requireTableNumberValue === 1;
                        console.log('loadStoreForEdit: 設置require_table_number為', requireTableNumberValue, '勾選框狀態:', requireTableNumberCheckbox.checked);
                    }
                    // 設置「不使用儲物柜」勾選框
                    const dontUseLockersCheckbox = document.getElementById('store-dont-use-lockers');
                    if (dontUseLockersCheckbox) {
                        // store.use_lockers: 1=使用儲物柜, 0=不使用儲物柜（默認1）
                        // checkbox: 勾選=不使用儲物柜, 未勾選=使用儲物柜
                        const useLockers = store.use_lockers !== undefined ? store.use_lockers : 1;
                        dontUseLockersCheckbox.checked = useLockers === 0;
                        console.log('loadStoreForEdit: 設置use_lockers為', store.use_lockers, 'checkbox狀態 (勾選=不使用):', dontUseLockersCheckbox.checked);
                    }
                    // 從settings中移除require_table_number，避免重複
                    const { require_table_number, ...otherSettings } = settings;
                    settingsTextarea.value = Object.keys(otherSettings).length > 0 ? JSON.stringify(otherSettings, null, 2) : '';
                } catch (error) {
                    console.warn('解析分店設定失敗:', error);
                    settingsTextarea.value = '';
                }
            }

            // 滾動到表單區域
            const formSection = document.querySelector('.store-form-section');
            if (formSection) {
                formSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }

            this.addMessage('已載入分店資料', 'success');
        } catch (error) {
            console.error('加載分店資料失敗:', error);
            this.addMessage('加載分店資料失敗: ' + error.message, 'error');
        }
    }

    // 覆蓋清空分店表單方法
    clearStoreForm() {
        document.getElementById('store-form').reset();
        document.getElementById('store-id').value = '';
        document.getElementById('store-settings').value = '{"timezone": "Asia/Hong_Kong", "currency": "HKD"}';

        // 重置「新增進場時輸入桌號」勾選框
        const requireTableNumberCheckbox = document.getElementById('store-require-table-number');
        if (requireTableNumberCheckbox) {
            requireTableNumberCheckbox.checked = false;
        }

        this.addMessage('表單已重置', 'info');
    }

    // 覆蓋設置分店管理事件
    setupStoreManagementEvents() {
        console.log('EnhancedCashierSystem.setupStoreManagementEvents called');

        // 分店表單提交事件 - 綁定到覆蓋的saveStore方法
        const storeForm = document.getElementById('store-form');
        if (storeForm) {
            // 移除可能存在的舊事件監聽器
            storeForm.removeEventListener('submit', this.storeFormSubmitHandler);
            // 添加新事件監聽器
            storeForm.addEventListener('submit', this.storeFormSubmitHandler);
        }

        // 取消按鈕
        const cancelBtn = document.getElementById('cancel-store-btn');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => this.clearStoreForm());
        }

        // 新增分店按鈕
        const addStoreBtn = document.getElementById('add-store-btn');
        if (addStoreBtn) {
            addStoreBtn.addEventListener('click', () => {
                this.clearStoreForm();
                const formSection = document.querySelector('.store-form-section');
                if (formSection) {
                    formSection.scrollIntoView({ behavior: 'smooth' });
                }
            });
        }

        // 刷新分店列表按鈕
        const refreshBtn = document.getElementById('refresh-stores-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.loadStores());
        }
    }

    // 覆蓋初始化分店管理
    async initStoreManagement() {
        console.log('EnhancedCashierSystem.initStoreManagement called');
        this.setupStoreManagementEvents();
        await this.loadStores();
    }

    /**
     * 加載小票管理分頁
     */
    async loadReceiptManagementTab() {
        console.log('loadReceiptManagementTab called');

        if (!this.isAuthenticated) {
            this.addMessage('請先登入以使用小票管理功能', 'warning');
            return;
        }

        // 檢查是否為管理員（只有管理員可以訪問小票管理）
        const isAdmin = this.currentEmployee && this.currentEmployee.role === 'admin';
        if (!isAdmin) {
            this.addMessage('只有管理員可以訪問小票管理功能', 'warning');
            // 切換回dashboard
            if (this.currentTab !== 'dashboard') {
                this.switchTab('dashboard');
            }
            return;
        }

        // 更新購物車側邊欄可見性（總部隱藏購物車）
        const isHeadquarters = this.selectedStoreId ? this.isHeadquartersStore(this.selectedStoreId) : false;
        this.updateShoppingCartSidebarVisibility(isHeadquarters);


        try {
            // 載入小票模板列表
            await this.loadReceiptTemplates();

            // 載入分店列表（用於模板分配）
            await this.loadStoresForReceiptTemplates();

            // 綁定小票管理事件
            this.bindReceiptManagementEvents();

            // 更新預覽
            this.updateReceiptPreview();
        } catch (error) {
            console.error('加載小票管理分頁錯誤:', error);
            this.addMessage(`加載小票管理分頁時發生錯誤: ${error.message}`, 'error');
        }
    }

    /**
     * 加載主機設定分頁
     */
    async loadHostConfigTab() {
        console.log('loadHostConfigTab called');

        // 清除現有的狀態更新定時器
        if (this.hostConfigStatusTimer) {
            clearInterval(this.hostConfigStatusTimer);
            this.hostConfigStatusTimer = null;
        }

        // 初始化角色選擇
        this.initHostRoleSelection();

        // 載入保存的設定
        await this.loadHostConfigSettings();

        // 綁定事件
        this.bindHostConfigEvents();

        // 更新UI狀態
        this.updateHostConfigUI();

        // 檢查版本更新資訊
        this.checkUpdateAvailability();

        // 員工登入時，主機設定版面不允許任何更改（只讀模式）
        if (this.isAuthenticated && this.currentEmployee && this.currentEmployee.role !== 'admin') {
            console.log('員工登入模式：禁用主機設定所有互動元素');
            const hostConfigTab = document.getElementById('tab-host-config');
            if (hostConfigTab) {
                // 禁用所有 input, select, textarea, button（保留系統更新按鈕）
                const inputs = hostConfigTab.querySelectorAll('input, select, textarea, button');
                inputs.forEach(el => {
                    // 允許系統更新相關 button 保持可用
                    if (el.id === 'updateConfirmBtn' || el.closest('#hostUpdateBtnContainer') || el.closest('#updateBtnArea')) {
                        return;
                    }
                    el.disabled = true;
                    el.style.opacity = '0.6';
                    el.style.cursor = 'not-allowed';
                });
                // 禁用所有 label（用於 radio），防止點擊 label 觸發 radio
                const labels = hostConfigTab.querySelectorAll('label.radio-option');
                labels.forEach(label => {
                    label.style.opacity = '0.6';
                    label.style.cursor = 'not-allowed';
                    label.style.pointerEvents = 'none';
                });
                // 顯示提示訊息
                const hostConfigContent = hostConfigTab.querySelector('.host-config-content');
                if (hostConfigContent && !hostConfigTab.querySelector('.employee-readonly-notice')) {
                    const notice = document.createElement('div');
                    notice.className = 'employee-readonly-notice';
                    notice.style.cssText = 'background: #fff3cd; border: 1px solid #ffeeba; color: #856404; padding: 10px 15px; border-radius: 5px; margin-bottom: 15px; font-size: 14px;';
                    notice.innerHTML = '<i class="fas fa-info-circle"></i> 您以員工身份登入，主機設定為唯讀模式。如需更改設定，請以管理員身份登入。';
                    hostConfigContent.parentNode.insertBefore(notice, hostConfigContent);
                }
            }
        }

        // 啟動定期狀態更新（每5秒更新一次）
        this.hostConfigStatusTimer = setInterval(() => {
            this.updateConnectionStatusDisplay();
        }, 5000);
    }

    // 主機設定輔助方法
    initHostRoleSelection() {
        console.log('initHostRoleSelection called');
        const roleRadios = document.querySelectorAll('input[name="host-role"]');
        roleRadios.forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.onHostRoleChange(e.target.value);
            });
        });
    }

    async loadHostConfigSettings() {
        console.log('loadHostConfigSettings called');
        // 從localStorage加載保存的設定
        const savedRole = localStorage.getItem('hostRole') || 'master';
        const savedMasterIp = localStorage.getItem('masterServerIp') || '';

        // 更新單選按鈕
        const roleRadio = document.querySelector(`input[name="host-role"][value="${savedRole}"]`);
        if (roleRadio) {
            roleRadio.checked = true;
        }

        // 更新IP輸入框
        const ipInput = document.getElementById('master-server-ip');
        if (ipInput) {
            ipInput.value = savedMasterIp;
        }

        // 更新當前URL顯示
        const currentUrlInput = document.getElementById('current-url');
        if (currentUrlInput) {
            currentUrlInput.value = window.location.href;
        }

        // 更新連接狀態顯示
        this.updateConnectionStatusDisplay();
    }

    bindHostConfigEvents() {
        console.log('bindHostConfigEvents called');
        // 連接按鈕
        const connectBtn = document.getElementById('connect-to-master-btn');
        if (connectBtn) {
            connectBtn.addEventListener('click', () => this.connectToMaster());
        }

        // 斷開連接按鈕
        const disconnectBtn = document.getElementById('disconnect-from-master-btn');
        if (disconnectBtn) {
            disconnectBtn.addEventListener('click', () => this.disconnectFromMaster());
        }

        // 自動檢測按鈕
        const detectBtn = document.getElementById('detect-master-ip-btn');
        if (detectBtn) {
            detectBtn.addEventListener('click', () => this.detectMasterIp());
        }

        // 保存設定按鈕
        const saveBtn = document.getElementById('save-master-ip-btn');
        if (saveBtn) {
            saveBtn.addEventListener('click', () => this.saveMasterIpSettings());
        }

        // 立即應用按鈕
        const applyBtn = document.getElementById('apply-master-ip-btn');
        if (applyBtn) {
            applyBtn.addEventListener('click', () => this.applyMasterIpSettings());
        }

        // === 機器主服務器設定事件綁定 (只有管理員可見) ===
        // 機器主服務器連接按鈕
        const machineConnectBtn = document.getElementById('connect-machine-master-btn');
        if (machineConnectBtn) {
            machineConnectBtn.addEventListener('click', () => this.connectToMachineMaster());
        }

        // 機器主服務器斷開連接按鈕
        const machineDisconnectBtn = document.getElementById('disconnect-machine-master-btn');
        if (machineDisconnectBtn) {
            machineDisconnectBtn.addEventListener('click', () => this.disconnectFromMachineMaster());
        }

        // 機器主服務器測試連接按鈕
        const machineTestBtn = document.getElementById('test-machine-master-btn');
        if (machineTestBtn) {
            machineTestBtn.addEventListener('click', () => this.testMachineMasterConnection());
        }

        // 機器主服務器保存設定按鈕
        const machineSaveBtn = document.getElementById('save-machine-master-ip-btn');
        if (machineSaveBtn) {
            machineSaveBtn.addEventListener('click', () => this.saveMachineMasterIpSettings());
        }
    }

    updateHostConfigUI() {
        console.log('updateHostConfigUI called');
        const selectedRole = document.querySelector('input[name="host-role"]:checked')?.value || 'master';

        // 更新角色顯示
        const roleDisplay = document.getElementById('current-role-display');
        if (roleDisplay) {
            roleDisplay.textContent = selectedRole === 'master' ? '主機' : '分機';
        }

        // 顯示/隱藏客戶端設定區域
        const clientSettingsSection = document.getElementById('client-settings-section');
        if (clientSettingsSection) {
            clientSettingsSection.style.display = selectedRole === 'client' ? 'block' : 'none';
        }

        // 更新連接狀態
        this.updateConnectionStatusDisplay();
    }

    onHostRoleChange(role) {
        console.log('onHostRoleChange:', role);
        // 保存到localStorage
        localStorage.setItem('hostRole', role);
        // 更新連接狀態
        this.masterConnectionStatus = 'unknown';

        // 如果切換到主機模式，清除自動重連間隔
        if (role === 'master') {
            if (this._masterReconnectInterval) {
                clearInterval(this._masterReconnectInterval);
                this._masterReconnectInterval = null;
                console.log('切換到主機模式，已清除自動重連間隔');
            }
        }

        // 更新UI
        this.updateHostConfigUI();
        // 更新連接警告顯示
        this.updateCustomerListConnectionWarning();
    }

    // 連接功能
    async connectToMaster() {
        console.log('connectToMaster called');
        const ipInput = document.getElementById('master-server-ip');
        if (!ipInput) {
            this.showHostConfigMessage('找不到IP輸入框', 'error');
            return;
        }

        const masterIp = ipInput.value.trim();
        if (!masterIp) {
            this.showHostConfigMessage('請輸入主服務器IP地址', 'warning');
            return;
        }

        // 規範化IP地址
        const normalizedIp = this.normalizeMasterIp(masterIp);
        ipInput.value = normalizedIp;

        this.showHostConfigMessage(`正在連接到主服務器: ${normalizedIp}`, 'info');

        // 設置連接中狀態
        this.updateConnectionStatusDisplay('connecting', normalizedIp);

        try {
            // 測試連接
            const isConnected = await this.testMasterConnection(normalizedIp);
            if (isConnected) {
                // 保存設定
                localStorage.setItem('masterServerIp', normalizedIp);
                this.showHostConfigMessage('測試連接成功，正在建立 Socket.IO 連接...', 'success');
                // 保持連接中狀態，等待Socket.IO連接成功
                // this.updateConnectionStatusDisplay('connecting', normalizedIp); // 已經是connecting狀態

                // 重新建立Socket.IO連接
                this.reconnectSocketToMaster();

            } else {
                this.showHostConfigMessage('無法連接到主服務器，請檢查IP地址和網絡連接', 'error');
                this.updateConnectionStatusDisplay('disconnected', normalizedIp);
            }
        } catch (error) {
            console.error('連接主服務器錯誤:', error);
            this.showHostConfigMessage(`連接錯誤: ${error.message}`, 'error');
            this.updateConnectionStatusDisplay('error', normalizedIp);
        }
    }

    /**
     * 重新建立Socket.IO連接到主服務器
     */
    reconnectSocketToMaster() {
        console.log('reconnectSocketToMaster called');

        // 防止重複調用
        if (this._isReconnectingToMaster) {
            console.log('已經在重新連接到主服務器，跳過重複調用');
            return;
        }

        // 設置重新連接標誌
        this._isReconnectingToMaster = true;
        console.log('設置重新連接標誌，開始Socket.IO重新連接過程');

        // 如果已經有socket連接，先斷開
        if (this.socket && this.socket.connected) {
            console.log('斷開現有的Socket.IO連接');
            this.socket.disconnect();
        }

        // 重新建立socket連接
        if (typeof this.connectSocket === 'function') {
            console.log('重新建立Socket.IO連接');
            this.connectSocket();
        } else {
            console.error('connectSocket方法不存在');
            this._isReconnectingToMaster = false; // 重置標誌
        }

        // 設置定時器重置標誌（防止標誌永遠卡住）
        setTimeout(() => {
            if (this._isReconnectingToMaster) {
                console.log('重置重新連接標誌（超時保護）');
                this._isReconnectingToMaster = false;
            }
        }, 10000); // 10秒後重置
    }

    disconnectFromMaster() {
        console.log('disconnectFromMaster called');
        // 清除保存的IP
        localStorage.removeItem('masterServerIp');
        this.showHostConfigMessage('已斷開連接，清除保存的IP設定', 'info');
        this.updateConnectionStatusDisplay('disconnected', '未設定');

        // 重置IP輸入框
        const ipInput = document.getElementById('master-server-ip');
        if (ipInput) {
            ipInput.value = '';
        }

        // 斷開Socket.IO連接（如果存在）
        if (this.socket && this.socket.connected) {
            console.log('斷開Socket.IO連接');
            this.socket.disconnect();
            // 重新連接到本地服務器
            if (typeof this.connectSocket === 'function') {
                setTimeout(() => {
                    this.connectSocket();
                }, 100);
            }
        }
    }

    async detectMasterIp() {
        console.log('detectMasterIp called');
        this.showHostConfigMessage('正在自動檢測局域網內的主服務器...', 'info');

        // 簡單的檢測：嘗試常見的IP段
        const commonIpRanges = [
            '192.168.1.100:3000',
            '192.168.1.101:3000',
            '192.168.0.100:3000',
            '192.168.0.101:3000',
            '192.168.3.155:3000', // 默認主平板IP
            'localhost:3000'
        ];

        let detectedIp = null;

        for (const ip of commonIpRanges) {
            try {
                this.showHostConfigMessage(`嘗試連接: ${ip}`, 'info');
                const isConnected = await this.testMasterConnection(ip);
                if (isConnected) {
                    detectedIp = ip;
                    break;
                }
            } catch (error) {
                // 忽略錯誤，繼續嘗試下一個
            }
        }

        if (detectedIp) {
            const ipInput = document.getElementById('master-server-ip');
            if (ipInput) {
                ipInput.value = detectedIp;
            }
            this.showHostConfigMessage(`檢測到主服務器: ${detectedIp}`, 'success');
        } else {
            this.showHostConfigMessage('未檢測到可用的主服務器，請手動輸入IP地址', 'warning');
        }
    }

    saveMasterIpSettings() {
        console.log('saveMasterIpSettings called');
        const ipInput = document.getElementById('master-server-ip');
        if (!ipInput) return;

        const masterIp = ipInput.value.trim();
        if (!masterIp) {
            this.showHostConfigMessage('請輸入主服務器IP地址', 'warning');
            return;
        }

        const normalizedIp = this.normalizeMasterIp(masterIp);
        localStorage.setItem('masterServerIp', normalizedIp);
        ipInput.value = normalizedIp;
        this.showHostConfigMessage('設定已保存', 'success');
    }

    applyMasterIpSettings() {
        console.log('applyMasterIpSettings called');
        const ipInput = document.getElementById('master-server-ip');
        if (!ipInput) return;

        const masterIp = ipInput.value.trim();
        if (!masterIp) {
            this.showHostConfigMessage('請輸入主服務器IP地址', 'warning');
            return;
        }

        const normalizedIp = this.normalizeMasterIp(masterIp);
        localStorage.setItem('masterServerIp', normalizedIp);
        ipInput.value = normalizedIp;

        this.showHostConfigMessage('設定已應用，請手動點擊"連接主服務器"測試連接', 'info');
    }

    async testMasterConnection(masterIp) {
        console.log('testMasterConnection called:', masterIp);
        // 嘗試多個端點：首先是根目錄，然後是/health，最後是API端點
        const testUrls = [
            `http://${masterIp}/`,           // 根目錄（兩個服務器都有）
            `http://${masterIp}/health`,     // 健康檢查端點（僅server/index.js有）
            `http://${masterIp}/api/stores`  // API端點（兩個服務器都有）
        ];

        console.log('測試URL列表:', testUrls);

        // 首先嘗試所有URL的正常GET請求
        for (const testUrl of testUrls) {
            try {
                console.log(`嘗試正常GET請求: ${testUrl}`);
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 3000); // 3秒超時

                const response = await fetch(testUrl, {
                    method: 'GET',
                    signal: controller.signal,
                    cache: 'no-cache',
                    mode: 'cors', // 嘗試cors模式
                    credentials: 'omit'
                });
                clearTimeout(timeoutId);

                if (response.ok) {
                    console.log(`服務器在線（GET ${testUrl}成功）`);
                    return true;
                }
                console.log(`GET ${testUrl}失敗，HTTP狀態碼: ${response.status}`);
            } catch (error) {
                console.log(`GET ${testUrl}失敗（可能是CORS問題）:`, error.message);
                // 繼續嘗試下一個URL
            }
        }

        // 如果所有GET請求都失敗，嘗試HEAD請求（繞過CORS）
        for (const testUrl of testUrls) {
            try {
                console.log(`嘗試HEAD請求（no-cors）: ${testUrl}`);
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 3000);

                // 使用HEAD方法，no-cors模式
                await fetch(testUrl, {
                    method: 'HEAD',
                    mode: 'no-cors',
                    signal: controller.signal,
                    cache: 'no-cache'
                });
                clearTimeout(timeoutId);

                // 如果沒有拋出錯誤，認為服務器可能在线
                console.log(`HEAD請求成功（no-cors模式），服務器可能在線: ${testUrl}`);
                return true;
            } catch (error) {
                console.log(`HEAD ${testUrl}失敗:`, error.message);
                // 繼續嘗試下一個URL
            }
        }

        // 所有嘗試都失敗
        console.log('所有連接嘗試都失敗，服務器可能離線或不可達');
        return false;
    }

    updateConnectionStatusDisplay(status = null, masterIp = null) {
        console.log('updateConnectionStatusDisplay called:', status, masterIp);

        // 更新內部連接狀態
        if (status) {
            this.masterConnectionStatus = status;
        } else {
            // 如果沒有提供狀態，保持當前狀態不變
            // 不定時更新只更新Socket.IO和API狀態，不重置主連接狀態
            if (this.masterConnectionStatus === undefined) {
                this.masterConnectionStatus = 'disconnected';
            }
        }

        const statusDisplay = document.getElementById('connection-status-display');
        const ipDisplay = document.getElementById('master-ip-display');
        const socketStatusDisplay = document.getElementById('socket-connection-status');
        const apiStatusDisplay = document.getElementById('api-connection-status');
        const lastSyncTimeDisplay = document.getElementById('last-sync-time');
        const syncSuccessCountDisplay = document.getElementById('sync-success-count');
        const syncFailureCountDisplay = document.getElementById('sync-failure-count');
        const lastErrorMessageDisplay = document.getElementById('last-error-message');

        // 更新主連接狀態
        if (statusDisplay) {
            let statusText = '未知';
            let statusClass = 'unknown';

            // 決定要顯示的狀態：優先使用傳入的status，否則使用內部狀態
            const displayStatus = status || this.masterConnectionStatus;

            switch(displayStatus) {
                case 'connecting':
                    statusText = '連接中...';
                    statusClass = 'connecting';
                    break;
                case 'connected':
                    statusText = '已連接';
                    statusClass = 'connected';
                    break;
                case 'disconnected':
                    statusText = '未連接';
                    statusClass = 'disconnected';
                    break;
                case 'error':
                    statusText = '連接錯誤';
                    statusClass = 'error';
                    break;
                case 'unknown':
                    statusText = '未知';
                    statusClass = 'unknown';
                    break;
                default:
                    statusText = '未設定';
                    statusClass = 'unknown';
            }

            statusDisplay.textContent = statusText;
            statusDisplay.className = `status-value ${statusClass}`;
        }

        // 更新主服務器IP顯示
        if (ipDisplay) {
            const savedMasterIp = localStorage.getItem('masterServerIp');
            ipDisplay.textContent = masterIp || savedMasterIp || '未設定';
        }

        // 更新Socket.IO連接狀態
        if (socketStatusDisplay) {
            const isSocketConnected = this.socket && this.socket.connected;
            socketStatusDisplay.textContent = isSocketConnected ? '已連接' : '未連接';
            socketStatusDisplay.className = `status-value ${isSocketConnected ? 'connected' : 'disconnected'}`;
        }

        // 更新API連接狀態
        if (apiStatusDisplay) {
            // 默認為未測試，實際狀態需要通過測試API獲取
            const role = localStorage.getItem('hostRole') || 'master';
            if (role === 'client') {
                apiStatusDisplay.textContent = '待測試';
                apiStatusDisplay.className = 'status-value unknown';
            } else {
                apiStatusDisplay.textContent = '主機模式';
                apiStatusDisplay.className = 'status-value connected';
            }
        }

        // 更新最後同步時間
        if (lastSyncTimeDisplay) {
            const lastSyncTime = localStorage.getItem('lastSyncTime') || '從未同步';
            lastSyncTimeDisplay.textContent = lastSyncTime;
        }

        // 更新同步統計
        if (syncSuccessCountDisplay) {
            const syncSuccessCount = localStorage.getItem('syncSuccessCount') || '0';
            syncSuccessCountDisplay.textContent = syncSuccessCount;
        }

        if (syncFailureCountDisplay) {
            const syncFailureCount = localStorage.getItem('syncFailureCount') || '0';
            syncFailureCountDisplay.textContent = syncFailureCount;
        }

        if (lastErrorMessageDisplay) {
            const lastErrorMessage = localStorage.getItem('lastSyncError') || '無';
            lastErrorMessageDisplay.textContent = lastErrorMessage;
        }

        // 更新在場客人列表的連接警告
        this.updateCustomerListConnectionWarning();
    }

    updateCustomerListConnectionWarning() {
        console.log('updateCustomerListConnectionWarning called');
        const customerListContainer = document.getElementById('customer-list');
        if (!customerListContainer) {
            console.log('找不到customer-list容器');
            return;
        }

        // 檢查是否為分機模式
        const role = localStorage.getItem('hostRole') || 'master';
        const masterIp = localStorage.getItem('masterServerIp') || '';

        // 查找或創建警告元素
        let warningElement = customerListContainer.querySelector('.connection-warning');

        const connectionStatus = this.masterConnectionStatus || 'unknown';
        if (role === 'client' && connectionStatus !== 'connected') {
            // 需要顯示警告（分機模式且未連接主機，無論是否設置IP）
            if (!warningElement) {
                warningElement = document.createElement('div');
                warningElement.className = 'connection-warning';
                warningElement.innerHTML = `
                    <div class="connection-warning-content">
                        <i class="fas fa-exclamation-triangle"></i>
                        <span>未成功連接主機</span>
                    </div>
                `;
                // 插入到客人列表的頂部
                if (customerListContainer.firstChild) {
                    customerListContainer.insertBefore(warningElement, customerListContainer.firstChild);
                } else {
                    customerListContainer.appendChild(warningElement);
                }
            }
            // 確保警告可見
            warningElement.classList.remove('hidden');
        } else {
            // 不需要警告，隱藏或移除警告元素
            if (warningElement) {
                warningElement.classList.add('hidden');
            }
        }
    }

    async autoReconnectToMaster() {
        console.log('autoReconnectToMaster called');

        // 檢查是否正在進行手動重新連接，如果是則跳過
        if (this._isReconnectingToMaster) {
            console.log('檢測到手動重新連接正在進行，跳過自動重連');
            return;
        }

        // 檢查當前主連接狀態，如果已經是已連接狀態，跳過自動重連
        if (this.masterConnectionStatus === 'connected') {
            console.log('主服務器連接狀態已經是已連接，跳過自動重連');
            return;
        }

        // 清除現有的重連間隔
        if (this._masterReconnectInterval) {
            clearInterval(this._masterReconnectInterval);
            this._masterReconnectInterval = null;
        }

        // 檢查是否為分機模式且有保存的主服務器IP
        const savedRole = localStorage.getItem('hostRole') || 'master';
        const savedMasterIp = localStorage.getItem('masterServerIp') || '';

        if (savedRole !== 'client' || !savedMasterIp) {
            console.log('不是分機模式或未保存主服務器IP，跳過自動重連');
            return;
        }

        console.log(`開始自動重連主服務器: ${savedMasterIp}`);
        this.showHostConfigMessage(`正在自動重連主服務器: ${savedMasterIp}`, 'info');

        let attempts = 0;
        const maxAttempts = 3;
        let isConnected = false;

        // 立即嘗試三次連接
        while (attempts < maxAttempts && !isConnected) {
            attempts++;
            console.log(`自動重連嘗試 ${attempts}/${maxAttempts}`);
            this.showHostConfigMessage(`自動重連嘗試 ${attempts}/${maxAttempts}`, 'info');

            try {
                isConnected = await this.testMasterConnection(savedMasterIp);
                if (isConnected) {
                    console.log('自動重連成功！');
                    this.showHostConfigMessage('自動重連成功！', 'success');
                    this.updateConnectionStatusDisplay('connected', savedMasterIp);

                    // 重新建立Socket.IO連接
                    this.reconnectSocketToMaster();
                    break;
                } else {
                    console.log(`自動重連嘗試 ${attempts} 失敗`);
                    if (attempts < maxAttempts) {
                        // 等待2秒後重試
                        await new Promise(resolve => setTimeout(resolve, 2000));
                    }
                }
            } catch (error) {
                console.error(`自動重連嘗試 ${attempts} 發生錯誤:`, error);
                if (attempts < maxAttempts) {
                    await new Promise(resolve => setTimeout(resolve, 2000));
                }
            }
        }

        if (!isConnected) {
            console.log(`自動重連失敗，將在2分鐘後再次嘗試`);
            this.showHostConfigMessage('自動重連失敗，2分鐘後將再次嘗試', 'warning');
            this.updateConnectionStatusDisplay('disconnected', savedMasterIp);

            // 設置每2分鐘重試的間隔
            this._masterReconnectInterval = setInterval(() => {
                console.log('定時重連觸發，嘗試重新連接主服務器');
                this.autoReconnectToMaster();
            }, 2 * 60 * 1000); // 2分鐘
        }
    }

    showHostConfigMessage(message, type = 'info') {
        console.log(`Host config message [${type}]:`, message);
        // 使用現有的addMessage方法
        if (typeof this.addMessage === 'function') {
            this.addMessage(`[主機設定] ${message}`, type);
        } else {
            // 備用：直接alert
            alert(`[主機設定] ${message}`);
        }
    }

    normalizeMasterIp(ip) {
        if (!ip || typeof ip !== 'string') return ip;

        let normalized = ip.trim();

        // 移除協議前綴
        normalized = normalized.replace(/^https?:\/\//, '');

        // 移除路徑部分（如果有）
        const slashIndex = normalized.indexOf('/');
        if (slashIndex !== -1) {
            normalized = normalized.substring(0, slashIndex);
        }

        // 確保有端口
        if (!normalized.includes(':')) {
            normalized += ':3000'; // 默認端口
        }

        return normalized;
    }

    /**
     * 載入小票模板列表
     */
    async loadReceiptTemplates() {
        try {
            console.log('loadReceiptTemplates called');

            const response = await this.fetchWithAuth('/api/receipt/templates');
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            if (!result.success) {
                throw new Error(result.message || '獲取模板列表失敗');
            }

            this.receiptTemplates = result.data || [];
            console.log(`載入 ${this.receiptTemplates.length} 個小票模板`);

            // 渲染模板列表
            this.renderReceiptTemplates();

            return this.receiptTemplates;
        } catch (error) {
            console.error('載入小票模板錯誤:', error);
            this.addMessage(`載入小票模板失敗: ${error.message}`, 'error');
            throw error;
        }
    }

    /**
     * 渲染小票模板列表
     */
    renderReceiptTemplates() {
        const tbody = document.getElementById('receipt-templates-list');
        if (!tbody) {
            console.warn('receipt-templates-list元素未找到');
            return;
        }

        tbody.innerHTML = '';

        if (!this.receiptTemplates || this.receiptTemplates.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="empty-state">
                        <i class="fas fa-receipt"></i>
                        <p data-i18n="noReceiptTemplatesFound">暫無小票模板</p>
                    </td>
                </tr>
            `;
            return;
        }

        this.receiptTemplates.forEach(template => {
            const row = document.createElement('tr');
            row.dataset.templateId = template.id;

            // 解析配置（如果是字符串）
            let config = {};
            try {
                config = typeof template.config === 'string'
                    ? JSON.parse(template.config)
                    : template.config || {};
            } catch (e) {
                console.warn('解析模板配置失敗:', e);
            }

            row.innerHTML = `
                <td>${template.template_name || '未命名模板'}</td>
                <td>${template.store_name ? `${template.store_name} (${template.store_code})` : '所有分店'}</td>
                <td>
                    ${template.is_default ? '<span class="badge badge-success" data-i18n="defaultTemplateBadge">默認</span>' : ''}
                </td>
                <td>${template.created_at ? new Date(template.created_at).toLocaleString('zh-TW') : '-'}</td>
                <td>
                    <button class="btn-small btn-primary edit-receipt-template-btn" data-template-id="${template.id}">
                        <i class="fas fa-edit"></i> <span data-i18n="editBtn">編輯</span>
                    </button>
                    <button class="btn-small btn-danger delete-receipt-template-btn" data-template-id="${template.id}" ${template.is_default ? 'disabled' : ''}>
                        <i class="fas fa-trash"></i> <span data-i18n="deleteBtn">刪除</span>
                    </button>
                </td>
            `;

            tbody.appendChild(row);
        });

        // 綁定模板操作事件
        this.bindReceiptTemplateActions();
    }

    /**
     * 載入分店列表（用於小票模板分配）
     */
    async loadStoresForReceiptTemplates() {
        try {
            console.log('loadStoresForReceiptTemplates called');

            const response = await this.fetchWithAuth('/api/stores');
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            if (!result.success) {
                throw new Error(result.message || '獲取分店列表失敗');
            }

            this.storesForReceiptTemplates = result.data || [];
            console.log(`載入 ${this.storesForReceiptTemplates.length} 個分店用於模板分配`);

            // 更新分店選擇器
            this.updateReceiptTemplateStoreSelector();

            return this.storesForReceiptTemplates;
        } catch (error) {
            console.error('載入分店列表錯誤:', error);
            // 不阻止小票管理功能繼續運行
            return [];
        }
    }

    /**
     * 更新小票模板分店選擇器
     */
    updateReceiptTemplateStoreSelector() {
        const storeSelect = document.getElementById('receipt-template-store');
        if (!storeSelect) return;

        // 保存當前選擇的值
        const currentValue = storeSelect.value;

        // 清空選項（保留"所有分店"選項）
        storeSelect.innerHTML = '<option value="">所有分店</option>';

        // 添加分店選項
        if (this.storesForReceiptTemplates && this.storesForReceiptTemplates.length > 0) {
            this.storesForReceiptTemplates.forEach(store => {
                const option = document.createElement('option');
                option.value = store.id;
                option.textContent = `${store.store_name} (${store.store_code})`;
                // 如果分店不活躍，標記為禁用
                if (!store.is_active || store.status !== 'active') {
                    option.disabled = true;
                    option.textContent += ' (已停用)';
                }
                storeSelect.appendChild(option);
            });
        }

        // 恢復之前的選擇
        if (currentValue) {
            storeSelect.value = currentValue;
        }
    }

    /**
     * 綁定小票管理事件
     */
    bindReceiptManagementEvents() {
        console.log('bindReceiptManagementEvents called');

        // 新增模板按鈕
        const addBtn = document.getElementById('add-receipt-template-btn');
        if (addBtn) {
            addBtn.removeEventListener('click', this.handleAddReceiptTemplate);
            this.handleAddReceiptTemplate = () => this.showReceiptTemplateForm();
            addBtn.addEventListener('click', this.handleAddReceiptTemplate);
        }

        // 刷新模板列表按鈕
        const refreshBtn = document.getElementById('refresh-receipt-templates-btn');
        if (refreshBtn) {
            refreshBtn.removeEventListener('click', this.handleRefreshReceiptTemplates);
            this.handleRefreshReceiptTemplates = () => this.loadReceiptTemplates();
            refreshBtn.addEventListener('click', this.handleRefreshReceiptTemplates);
        }

        // 模板表單提交
        const form = document.getElementById('receipt-template-form');
        if (form) {
            form.removeEventListener('submit', this.handleReceiptTemplateSubmit);
            this.handleReceiptTemplateSubmit = (e) => this.saveReceiptTemplate(e);
            form.addEventListener('submit', this.handleReceiptTemplateSubmit);
        }

        // 取消按鈕
        const cancelBtn = document.getElementById('cancel-receipt-template-btn');
        if (cancelBtn) {
            cancelBtn.removeEventListener('click', this.handleCancelReceiptTemplate);
            this.handleCancelReceiptTemplate = () => this.clearReceiptTemplateForm();
            cancelBtn.addEventListener('click', this.handleCancelReceiptTemplate);
        }

        // 刷新預覽按鈕
        const refreshPreviewBtn = document.getElementById('refresh-preview-btn');
        if (refreshPreviewBtn) {
            refreshPreviewBtn.removeEventListener('click', this.handleRefreshPreview);
            this.handleRefreshPreview = () => this.updateReceiptPreview();
            refreshPreviewBtn.addEventListener('click', this.handleRefreshPreview);
        }

        // 測試打印按鈕
        const testPrintBtn = document.getElementById('test-print-btn');
        if (testPrintBtn) {
            testPrintBtn.removeEventListener('click', this.handleTestPrint);
            this.handleTestPrint = () => this.testReceiptPrint();
            testPrintBtn.addEventListener('click', this.handleTestPrint);
        }

        // 表單字段變更事件（實時更新預覽）
        const formFields = [
            'receipt-template-name',
            'receipt-template-store',
            'receipt-template-is-default',
            'receipt-company-name',
            'receipt-store-name',
            'receipt-header-text',
            'receipt-show-qr-code',
            'receipt-show-locker-info',
            'receipt-font-size',
            'receipt-footer-text',
            'receipt-contact-info',
            'receipt-show-logo',
            'receipt-logo-position',
            'receipt-logo-width'
        ];

        formFields.forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field) {
                field.removeEventListener('input', this.handleFormFieldChange);
                field.removeEventListener('change', this.handleFormFieldChange);
                this.handleFormFieldChange = () => this.updateReceiptPreview();
                field.addEventListener('input', this.handleFormFieldChange);
                field.addEventListener('change', this.handleFormFieldChange);
            }
        });

        // Logo上傳事件
        const logoUploadInput = document.getElementById('receipt-logo-upload');
        if (logoUploadInput) {
            logoUploadInput.removeEventListener('change', this.handleLogoUploadChange);
            this.handleLogoUploadChange = (e) => this.handleLogoUpload(e);
            logoUploadInput.addEventListener('change', this.handleLogoUploadChange);
        }

        // 移除logo按鈕事件
        const removeLogoBtn = document.getElementById('remove-logo-btn');
        if (removeLogoBtn) {
            removeLogoBtn.removeEventListener('click', this.handleRemoveLogo);
            this.handleRemoveLogo = () => this.removeLogo();
            removeLogoBtn.addEventListener('click', this.handleRemoveLogo);
        }
    }

    /**
     * 綁定小票模板操作事件（編輯、刪除）
     */
    bindReceiptTemplateActions() {
        // 編輯按鈕
        document.querySelectorAll('.edit-receipt-template-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const templateId = e.currentTarget.dataset.templateId;
                this.editReceiptTemplate(templateId);
            });
        });

        // 刪除按鈕
        document.querySelectorAll('.delete-receipt-template-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const templateId = e.currentTarget.dataset.templateId;
                this.deleteReceiptTemplate(templateId);
            });
        });
    }

    /**
     * 顯示小票模板表單（新增模式）
     */
    showReceiptTemplateForm() {
        console.log('showReceiptTemplateForm called');
        this.clearReceiptTemplateForm();

        // 顯示表單區域
        const editorSection = document.querySelector('.receipt-editor-section');
        if (editorSection) {
            editorSection.scrollIntoView({ behavior: 'smooth' });
        }
    }

    /**
     * 編輯小票模板
     */
    async editReceiptTemplate(templateId) {
        try {
            console.log(`editReceiptTemplate called: ${templateId}`);

            const response = await this.fetchWithAuth(`/api/receipt/templates/${templateId}`);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            if (!result.success) {
                throw new Error(result.message || '獲取模板失敗');
            }

            const template = result.data;
            this.currentReceiptTemplateId = template.id;

            // 填充表單
            document.getElementById('receipt-template-name').value = template.template_name || '';
            document.getElementById('receipt-template-store').value = template.store_id || '';
            document.getElementById('receipt-template-is-default').checked = template.is_default === 1;

            // 解析配置
            let config = {};
            try {
                config = typeof template.config === 'string'
                    ? JSON.parse(template.config)
                    : template.config || {};
            } catch (e) {
                console.warn('解析模板配置失敗:', e);
            }

            // 填充配置字段
            document.getElementById('receipt-company-name').value = config.company_name || '';
            document.getElementById('receipt-store-name').value = config.store_name || '';
            document.getElementById('receipt-header-text').value = config.header_text || '';
            document.getElementById('receipt-show-qr-code').value = config.show_qr_code !== false ? 'true' : 'false';
            document.getElementById('receipt-show-locker-info').value = config.show_locker_info !== false ? 'true' : 'false';
            document.getElementById('receipt-font-size').value = config.font_size || 'medium';
            document.getElementById('receipt-footer-text').value = config.footer_text || '';
            document.getElementById('receipt-contact-info').value = config.contact_info || '';

            // 填充logo相關字段
            document.getElementById('receipt-logo-base64').value = config.logo_base64 || '';
            document.getElementById('receipt-show-logo').checked = config.show_logo !== false;
            document.getElementById('receipt-logo-position').value = config.logo_position || 'top-center';
            document.getElementById('receipt-logo-width').value = config.logo_width || 100;

            // 更新logo預覽
            this.updateLogoPreview(config.logo_base64);

            // 更新預覽
            this.updateReceiptPreview();

            // 滾動到編輯器
            const editorSection = document.querySelector('.receipt-editor-section');
            if (editorSection) {
                editorSection.scrollIntoView({ behavior: 'smooth' });
            }

            this.addMessage(`正在編輯模板: ${template.template_name}`, 'info');
        } catch (error) {
            console.error('編輯小票模板錯誤:', error);
            this.addMessage(`編輯模板失敗: ${error.message}`, 'error');
        }
    }

    /**
     * 保存小票模板
     */
    async saveReceiptTemplate(e) {
        e.preventDefault();
        console.log('saveReceiptTemplate called');

        try {
            // 收集表單數據
            const templateData = {
                template_name: document.getElementById('receipt-template-name').value,
                store_id: document.getElementById('receipt-template-store').value || null,
                is_default: document.getElementById('receipt-template-is-default').checked,
                config: {
                    company_name: document.getElementById('receipt-company-name').value,
                    store_name: document.getElementById('receipt-store-name').value,
                    header_text: document.getElementById('receipt-header-text').value,
                    show_qr_code: document.getElementById('receipt-show-qr-code').value === 'true',
                    show_locker_info: document.getElementById('receipt-show-locker-info').value === 'true',
                    font_size: document.getElementById('receipt-font-size').value,
                    footer_text: document.getElementById('receipt-footer-text').value,
                    contact_info: document.getElementById('receipt-contact-info').value,
                    logo_base64: document.getElementById('receipt-logo-base64').value || null,
                    show_logo: document.getElementById('receipt-show-logo').checked,
                    logo_position: document.getElementById('receipt-logo-position').value,
                    logo_width: parseInt(document.getElementById('receipt-logo-width').value) || 100
                }
            };

            // 調試：記錄logo_base64長度和請求體大小
            const logoBase64 = templateData.config.logo_base64;
            if (logoBase64) {
                console.log(`logo_base64 長度: ${logoBase64.length} 字符`);
                console.log(`logo_base64 前綴: ${logoBase64.substring(0, 100)}...`);
            }
            const requestBody = JSON.stringify(templateData);
            console.log(`請求體總大小: ${requestBody.length} 字符 (約 ${Math.round(requestBody.length / 1024)} KB)`);

            // 驗證
            if (!templateData.template_name.trim()) {
                this.addMessage('請輸入模板名稱', 'warning');
                return;
            }

            let response;
            if (this.currentReceiptTemplateId) {
                // 更新現有模板
                response = await this.fetchWithAuth(`/api/receipt/templates/${this.currentReceiptTemplateId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(templateData)
                });
            } else {
                // 創建新模板
                response = await this.fetchWithAuth('/api/receipt/templates', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(templateData)
                });
            }

            if (!response.ok) {
                const errorResult = await response.json();
                throw new Error(errorResult.message || `HTTP ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            if (!result.success) {
                throw new Error(result.message || '保存失敗');
            }

            this.addMessage(`小票模板${this.currentReceiptTemplateId ? '更新' : '創建'}成功`, 'success');

            // 清空表單
            this.clearReceiptTemplateForm();

            // 刷新模板列表
            await this.loadReceiptTemplates();

        } catch (error) {
            console.error('保存小票模板錯誤:', error);
            this.addMessage(`保存小票模板失敗: ${error.message}`, 'error');
        }
    }

    /**
     * 刪除小票模板
     */
    async deleteReceiptTemplate(templateId) {
        if (!confirm('確定要刪除此小票模板嗎？此操作無法還原。')) {
            return;
        }

        try {
            const response = await this.fetchWithAuth(`/api/receipt/templates/${templateId}`, {
                method: 'DELETE'
            });

            if (!response.ok) {
                const errorResult = await response.json();
                throw new Error(errorResult.message || `HTTP ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            if (!result.success) {
                throw new Error(result.message || '刪除失敗');
            }

            this.addMessage('小票模板刪除成功', 'success');

            // 刷新模板列表
            await this.loadReceiptTemplates();

        } catch (error) {
            console.error('刪除小票模板錯誤:', error);
            this.addMessage(`刪除小票模板失敗: ${error.message}`, 'error');
        }
    }

    /**
     * 清空小票模板表單
     */
    clearReceiptTemplateForm() {
        console.log('clearReceiptTemplateForm called');

        this.currentReceiptTemplateId = null;

        // 重置表單
        const form = document.getElementById('receipt-template-form');
        if (form) form.reset();

        // 設置默認值
        document.getElementById('receipt-template-store').value = '';
        document.getElementById('receipt-template-is-default').checked = false;
        document.getElementById('receipt-show-qr-code').value = 'true';
        document.getElementById('receipt-show-locker-info').value = 'true';
        document.getElementById('receipt-font-size').value = 'medium';

        // 清空配置字段
        document.getElementById('receipt-company-name').value = '';
        document.getElementById('receipt-store-name').value = '';
        document.getElementById('receipt-header-text').value = '';
        document.getElementById('receipt-footer-text').value = '';
        document.getElementById('receipt-contact-info').value = '';

        // 更新預覽
        this.updateReceiptPreview();
    }

    /**
     * 規範化換行符，將 \n 轉義序列轉換為實際換行符
     * @param {string} text - 輸入文本
     * @returns {string} 處理後的文本
     */
    normalizeNewlines(text) {
        if (!text) return '';
        // 將 \n 轉義序列替換為實際換行符
        return text.replace(/\\n/g, '\n');
    }

    /**
     * 更新小票預覽
     */
    updateReceiptPreview() {
        console.log('updateReceiptPreview called');

        // 收集表單數據
        const previewData = {
            company_name: document.getElementById('receipt-company-name').value || '自動咖啡館',
            store_name: document.getElementById('receipt-store-name').value || '分店名稱',
            header_text: document.getElementById('receipt-header-text').value || '歡迎光臨，祝您用餐愉快！',
            show_qr_code: document.getElementById('receipt-show-qr-code').value === 'true',
            show_locker_info: document.getElementById('receipt-show-locker-info').value === 'true',
            font_size: document.getElementById('receipt-font-size').value || 'medium',
            footer_text: document.getElementById('receipt-footer-text').value || '感謝您的光臨，歡迎再次蒞臨！',
            contact_info: document.getElementById('receipt-contact-info').value || '電話: 1234-5678 | 地址: 香港某處',
            logo_base64: document.getElementById('receipt-logo-base64').value || null,
            show_logo: document.getElementById('receipt-show-logo').checked,
            logo_position: document.getElementById('receipt-logo-position').value || 'top-center',
            logo_width: parseInt(document.getElementById('receipt-logo-width').value) || 100
        };

        // 更新預覽元素
        const previewCompanyName = document.getElementById('preview-company-name');
        const previewStoreName = document.getElementById('preview-store-name');
        const previewHeaderText = document.getElementById('preview-header-text');
        const previewLockerInfo = document.getElementById('preview-locker-info');
        const previewQrCode = document.getElementById('preview-qr-code');
        const previewFooterText = document.getElementById('preview-footer-text');
        const previewContactInfo = document.getElementById('preview-contact-info');

        // 設置預覽文本，處理 \n 換行符
        if (previewCompanyName) {
            previewCompanyName.textContent = this.normalizeNewlines(previewData.company_name);
            previewCompanyName.style.whiteSpace = 'pre-wrap';
        }
        if (previewStoreName) {
            previewStoreName.textContent = this.normalizeNewlines(previewData.store_name);
            previewStoreName.style.whiteSpace = 'pre-wrap';
        }
        if (previewHeaderText) {
            previewHeaderText.textContent = this.normalizeNewlines(previewData.header_text);
            previewHeaderText.style.whiteSpace = 'pre-wrap';
        }
        if (previewFooterText) {
            previewFooterText.textContent = this.normalizeNewlines(previewData.footer_text);
            previewFooterText.style.whiteSpace = 'pre-wrap';
        }
        if (previewContactInfo) {
            previewContactInfo.textContent = this.normalizeNewlines(previewData.contact_info);
            previewContactInfo.style.whiteSpace = 'pre-wrap';
        }

        // 顯示/隱藏儲物柜信息
        if (previewLockerInfo) {
            previewLockerInfo.style.display = previewData.show_locker_info ? 'flex' : 'none';
        }

        // 顯示/隱藏QR碼
        if (previewQrCode) {
            previewQrCode.style.display = previewData.show_qr_code ? 'block' : 'none';
        }

        // 應用字體大小
        const previewContent = document.querySelector('.receipt-preview-content');
        if (previewContent) {
            previewContent.className = 'receipt-preview-content';
            previewContent.classList.add(`font-size-${previewData.font_size}`);
        }

        // 更新logo顯示
        this.updateLogoInPreview(previewData);

        // 更新示例商品列表和總金額
        this.updateExampleItemsInPreview();
    }

    /**
     * 更新小票預覽中的logo顯示
     * @param {Object} previewData - 預覽數據
     */
    updateLogoInPreview(previewData) {
        const logoContainer = document.getElementById('preview-logo-container');
        if (!logoContainer) return;

        // 檢查是否有logo且需要顯示
        const hasLogo = previewData.logo_base64 && previewData.show_logo;

        if (hasLogo) {
            // 創建或更新logo圖片
            let logoImg = logoContainer.querySelector('img');
            if (!logoImg) {
                logoImg = document.createElement('img');
                logoImg.alt = 'Logo';
                logoContainer.appendChild(logoImg);
            }

            // 設置logo圖片
            logoImg.src = previewData.logo_base64;
            logoImg.style.width = `${previewData.logo_width || 100}px`;
            logoImg.style.margin = '0 auto';
            logoImg.style.display = 'block';

            // 根據位置設置對齊
            logoContainer.style.textAlign = 'center'; // 默認置中
            if (previewData.logo_position === 'top-left') {
                logoContainer.style.textAlign = 'left';
            } else if (previewData.logo_position === 'top-right') {
                logoContainer.style.textAlign = 'right';
            }

            logoContainer.style.display = 'block';
        } else {
            logoContainer.style.display = 'none';
            // 清除現有圖片
            logoContainer.innerHTML = '';
        }
    }

    /**
     * 更新logo預覽
     * @param {string} logoBase64 - base64編碼的logo圖片
     */
    updateLogoPreview(logoBase64) {
        const logoPreview = document.getElementById('logo-preview');
        if (!logoPreview) return;

        if (logoBase64) {
            // 顯示logo圖片
            logoPreview.innerHTML = `<img src="${logoBase64}" alt="Logo Preview">`;
        } else {
            // 顯示無logo提示
            logoPreview.innerHTML = '<span data-i18n="noLogoPreview">未選擇Logo</span>';
        }
    }

    /**
     * 處理logo上傳
     * @param {Event} event - 文件上傳事件
     */
    handleLogoUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        // 檢查文件類型
        if (!file.type.match('image.*')) {
            this.addMessage('請選擇圖片文件', 'warning');
            return;
        }

        // 檢查文件大小（限制為2MB）
        if (file.size > 2 * 1024 * 1024) {
            this.addMessage('圖片大小不能超過2MB', 'warning');
            return;
        }

        // 顯示上傳中消息
        this.addMessage('正在處理圖片...', 'info');

        // 壓縮圖片（更小尺寸以減少請求體大小）
        this.compressImage(file, 150, 150, 0.6).then(base64 => {
            // 保存到隱藏字段
            document.getElementById('receipt-logo-base64').value = base64;
            // 更新預覽
            this.updateLogoPreview(base64);
            // 自動勾選顯示logo
            document.getElementById('receipt-show-logo').checked = true;
            // 更新小票預覽
            this.updateReceiptPreview();
            this.addMessage('圖片上傳並壓縮完成', 'success');
        }).catch(error => {
            console.error('圖片壓縮錯誤:', error);
            // 如果壓縮失敗，使用原始文件
            const reader = new FileReader();
            reader.onload = (e) => {
                const base64 = e.target.result;
                document.getElementById('receipt-logo-base64').value = base64;
                this.updateLogoPreview(base64);
                document.getElementById('receipt-show-logo').checked = true;
                this.updateReceiptPreview();
                this.addMessage('圖片上傳完成（使用原始圖片）', 'success');
            };
            reader.readAsDataURL(file);
        });
    }

    /**
     * 壓縮圖片
     * @param {File} file - 圖片文件
     * @param {number} maxWidth - 最大寬度 (默認200像素)
     * @param {number} maxHeight - 最大高度 (默認200像素)
     * @param {number} quality - 圖片質量 0-1 (默認0.7)
     * @returns {Promise<string>} base64編碼的壓縮圖片
     */
    compressImage(file, maxWidth = 200, maxHeight = 200, quality = 0.7) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                const img = new Image();
                img.onload = () => {
                    // 計算縮放比例
                    let width = img.width;
                    let height = img.height;

                    if (width > maxWidth || height > maxHeight) {
                        const ratio = Math.min(maxWidth / width, maxHeight / height);
                        width = Math.floor(width * ratio);
                        height = Math.floor(height * ratio);
                    }

                    // 創建canvas進行壓縮
                    const canvas = document.createElement('canvas');
                    canvas.width = width;
                    canvas.height = height;

                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, width, height);

                    // 轉換為base64
                    const base64 = canvas.toDataURL('image/jpeg', quality);
                    console.log(`壓縮圖片完成: 原始文件 ${file.size} bytes, 壓縮後 base64 長度 ${base64.length} 字符 (約 ${Math.round(base64.length / 1024)} KB), 尺寸 ${width}x${height}, 質量 ${quality}`);
                    resolve(base64);
                };
                img.onerror = reject;
                img.src = e.target.result;
            };
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }

    /**
     * 移除logo
     */
    removeLogo() {
        // 清除隱藏字段
        document.getElementById('receipt-logo-base64').value = '';
        // 清除文件輸入
        document.getElementById('receipt-logo-upload').value = '';
        // 更新預覽
        this.updateLogoPreview('');
        // 更新小票預覽
        this.updateReceiptPreview();
    }

    /**
     * 更新預覽中的示例商品列表和總金額
     */
    updateExampleItemsInPreview() {
        const itemsHeader = document.getElementById('preview-items-header');
        const itemsList = document.getElementById('preview-items-list');
        const totalAmount = document.getElementById('preview-total-amount');

        if (!itemsHeader || !itemsList || !totalAmount) return;

        // 示例商品數據
        const exampleItems = [
            { name: '美式咖啡', quantity: 2, price: 80 },
            { name: '巧克力蛋糕', quantity: 1, price: 150 },
            { name: '奶茶', quantity: 1, price: 90 }
        ];

        // 計算總金額
        let total = 0;
        exampleItems.forEach(item => {
            total += item.quantity * item.price;
        });

        // 顯示商品列表和總金額
        itemsHeader.style.display = 'flex';
        totalAmount.style.display = 'flex';

        // 更新總金額
        const totalSpan = totalAmount.querySelector('span:last-child');
        if (totalSpan) {
            totalSpan.textContent = `$${total}`;
        }

        // 清空並重建商品列表
        itemsList.innerHTML = '';
        exampleItems.forEach((item, index) => {
            const itemElement = document.createElement('div');
            itemElement.className = 'receipt-line';
            const itemTotal = item.quantity * item.price;
            itemElement.innerHTML = `
                <span>${item.name} x${item.quantity}</span>
                <span>$${item.price} = $${itemTotal}</span>
            `;
            itemsList.appendChild(itemElement);
        });
    }

    /**
     * 獲取小票模板表單配置數據
     * @returns {Object} 模板配置數據
     */
    getReceiptTemplateFormData() {
        try {
            // 收集表單數據
            const templateData = {
                template_name: document.getElementById('receipt-template-name').value,
                store_id: document.getElementById('receipt-template-store').value || null,
                is_default: document.getElementById('receipt-template-is-default').checked,
                config: {
                    company_name: document.getElementById('receipt-company-name').value,
                    store_name: document.getElementById('receipt-store-name').value,
                    header_text: document.getElementById('receipt-header-text').value,
                    show_qr_code: document.getElementById('receipt-show-qr-code').value === 'true',
                    show_locker_info: document.getElementById('receipt-show-locker-info').value === 'true',
                    font_size: document.getElementById('receipt-font-size').value,
                    footer_text: document.getElementById('receipt-footer-text').value,
                    contact_info: document.getElementById('receipt-contact-info').value,
                    show_logo: document.getElementById('receipt-show-logo').checked,
                    logo_position: document.getElementById('receipt-logo-position').value,
                    logo_width: parseInt(document.getElementById('receipt-logo-width').value) || 100,
                    logo_base64: document.getElementById('receipt-logo-base64').value || ''
                }
            };

            return templateData;
        } catch (error) {
            console.error('獲取小票模板表單數據錯誤:', error);
            return null;
        }
    }

    /**
     * 測試小票打印
     */
    async testReceiptPrint() {
        try {
            this.addMessage('正在發送測試打印...', 'info');
            console.log('testReceiptPrint called');

            // 檢查是否有連接的打印機
            const receiptPrinterIp = document.getElementById('receipt-printer-ip')?.value;
            const receiptPrinterPort = document.getElementById('receipt-printer-port')?.value || 9100;

            console.log('IP field value:', receiptPrinterIp);
            console.log('Port field value:', receiptPrinterPort);

            // 如果IP為空，嘗試從默認打印機配置中獲取
            let ipToUse = receiptPrinterIp;
            if (!ipToUse && this.printerConfigs && this.printerConfigs.length > 0) {
                const defaultConfig = this.printerConfigs.find(config => config.is_default === 1);
                if (defaultConfig && defaultConfig.ip_address) {
                    console.log('Using IP from default printer config:', defaultConfig.ip_address);
                    ipToUse = defaultConfig.ip_address;
                    // 同時更新IP字段以便後續使用
                    const ipField = document.getElementById('receipt-printer-ip');
                    if (ipField) ipField.value = defaultConfig.ip_address;
                }
            }

            if (!ipToUse) {
                this.addMessage('請先設置打印機IP地址', 'error');
                return;
            }

            // 獲取小票模板配置（從當前表單）
            const templateData = this.getReceiptTemplateFormData();
            const templateConfig = templateData?.config || null;

            // 使用收銀系統的測試端點
            const response = await fetch('/api/cashier/test-receipt-printer', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    connectionType: 'wifi',
                    ipAddress: ipToUse,
                    port: receiptPrinterPort,
                    printerType: document.getElementById('receipt-printer-type')?.value || 'epson',
                    storeId: this.selectedStoreId,
                    templateConfig: templateConfig,
                    test_type: 'template_preview'
                })
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage('測試打印指令已發送: ' + result.message, 'success');
            } else {
                this.addMessage('測試打印失敗: ' + (result.error || result.message), 'error');
            }
        } catch (error) {
            console.error('測試打印錯誤:', error);
            this.addMessage(`測試打印失敗: ${error.message}`, 'error');
        }
    }

    /**
     * 重寫關閉結賬模態框，退出合單模式（若有）
     */
    hideCheckoutModal() {
        // 如果在合單模式關閉結賬視窗，需退出合單模式，避免卡片留在選中狀態
        if (this.isMergeMode) {
            this.exitMergeMode(false); // 不顯示訊息，避免干擾成功結賬摘要
        }
        super.hideCheckoutModal();
    }

    /**
     * 重寫結賬確認模態框顯示，支持無桌號購物車結賬
     */
    async showCheckoutModal() {
        console.log('EnhancedCashierSystem.showCheckoutModal called');
        console.log('selectedCustomer:', this.selectedCustomer);
        console.log('shoppingCart length:', this.shoppingCart ? this.shoppingCart.length : 0);

        // 檢查是否有選擇客人（有桌號結賬）
        if (this.selectedCustomer) {
            // 檢查母桌號是否有未結賬的子桌號
            const hasSubs = this._hasSubTables(this.selectedCustomer.table_number);
            if (hasSubs) {
                console.log('檢測到子桌號，顯示合單結賬確認視窗');
                const choice = await this._showSubTableMergeConfirm();
                if (choice === null) {
                    // 用戶按取消/關閉 → 不做任何事
                    return;
                } else if (choice === true) {
                    // 是 - 合單結賬：填充彙總數據到結賬視窗並顯示
                    this._fillMergeCheckoutModal(this.selectedCustomer);
                    return;
                }
                // false → 否 - 只結賬母單，繼續正常結賬流程
                console.log('用戶選擇只結賬母單，繼續正常結賬');
            }

            console.log('有桌號結賬，調用父類方法');
            // 確保人數輸入隱藏，顯示靜態文字
            const peopleInput = document.getElementById('checkout-people-input');
            if (peopleInput) peopleInput.style.display = 'none';
            document.getElementById('checkout-people').style.display = '';
            super.showCheckoutModal();
            return;
        }

        // 無桌號結賬：檢查購物車是否為空
        if (!this.shoppingCart || this.shoppingCart.length === 0) {
            this.addMessage('購物車是空的，無法結賬', 'warning');
            return;
        }

        // 計算購物車總金額（使用折扣後的有效價格）
        const totalAmount = this.shoppingCart.reduce((sum, item) => {
            const effPrice = item.effectivePrice || item.price;
            return sum + (effPrice * item.quantity);
        }, 0);

        console.log('無桌號結賬，購物車總金額:', totalAmount);

        // 更新模態框內容
        document.getElementById('checkout-table').textContent = '無桌號';

        // 從購物車計算人數：統計「首小時」「全日通」商品的數量總和
        const cartPeopleCount = this.shoppingCart.reduce((count, item) => {
            if (item.name && (item.name.startsWith('首小時') || item.name.startsWith('全日通'))) {
                return count + item.quantity;
            }
            return count;
        }, 0);
        document.getElementById('checkout-people').style.display = '';
        document.getElementById('checkout-people').textContent = `${cartPeopleCount}位`;
        // 隱藏可編輯輸入框（無桌號改為自動計算）
        const peopleInput = document.getElementById('checkout-people-input');
        if (peopleInput) {
            peopleInput.style.display = 'none';
        }

        const now = new Date();
        const entryTime = now.toLocaleTimeString('zh-TW', {
            hour: '2-digit',
            minute: '2-digit'
        });
        document.getElementById('checkout-entry-time').textContent = entryTime;
        document.getElementById('checkout-amount').textContent = `$${totalAmount.toFixed(2)}`;
        this.checkoutTotalAmount = totalAmount;

        // 重置收款金額和找續
        const paymentInput = document.getElementById('checkout-payment');
        if (paymentInput) {
            paymentInput.value = '';
            paymentInput.classList.remove('invalid');
        }
        document.getElementById('checkout-change').textContent = '$0.00';
        document.getElementById('checkout-change').className = 'change-amount';

        // 顯示模態框
        document.getElementById('checkout-modal').classList.remove('hidden');
    }

    /**
     * 重寫結賬確認，支持無桌號購物車結賬
     */
    async confirmCheckout() {
        console.log('EnhancedCashierSystem.confirmCheckout called');

        // 合單結賬模式：使用合單結賬流程
        if (this.isMergeMode && this.mergeCustomerIds && this.mergeCustomerIds.size > 0) {
            console.log('合單結賬模式，調用 confirmMergeCheckout');
            await this.confirmMergeCheckout();
            return;
        }

        console.log('selectedCustomer:', this.selectedCustomer);
        console.log('shoppingCart length:', this.shoppingCart ? this.shoppingCart.length : 0);

        // 檢查是否有選擇客人（有桌號結賬）
        if (this.selectedCustomer) {
            console.log('有桌號結賬，調用父類方法');
            // 調用父類的 confirmCheckout 方法
            try {
                await super.confirmCheckout();
                // 父類 confirmCheckout 已調用 loadCustomers 和 loadTodayStats，
                // 但沒有 loadTodayCheckoutRecords，這裡補上
                this.loadTodayCheckoutRecords();
            } catch (error) {
                console.error('有桌號結賬失敗:', error);
                this.addMessage(`結賬失敗: ${error.message}`, 'error');
            }
            return;
        }

        // 無桌號結賬：檢查購物車是否為空
        if (!this.shoppingCart || this.shoppingCart.length === 0) {
            this.addMessage('購物車是空的，無法結賬', 'warning');
            return;
        }

        // 防止重複提交
        if (this.isCheckingOut) {
            console.log('結賬正在進行中，請稍候');
            return;
        }

        this.isCheckingOut = true;
        try {
            // 隱藏模態框
            this.hideCheckoutModal();

            // 調用無桌號結賬API
            await this.checkoutNoTable();

        } catch (error) {
            console.error('無桌號結賬失敗:', error);
            this.addMessage(`結賬失敗: ${error.message}`, 'error');
        } finally {
            this.isCheckingOut = false;
        }
    }

    // ==================== 子桌號合單結賬確認 ====================

    /**
     * 檢查母桌號是否有未結賬的子桌號
     * @param {string} tableNumber - 桌號（如 A7）
     * @returns {boolean}
     */
    _hasSubTables(tableNumber) {
        if (!this.customers || !Array.isArray(this.customers) || !tableNumber) return false;
        // 子桌號格式為 A7.1, A7.2 等
        return this.customers.some(c =>
            c.table_number &&
            c.table_number.startsWith(tableNumber + '.') &&
            c.id !== (this.selectedCustomer ? this.selectedCustomer.id : null)
        );
    }

    /**
     * 顯示子桌號合單結賬確認對話框
     * @returns {Promise<boolean|null>} true=合單結賬, false=只結賬母單, null=取消
     */
    _showSubTableMergeConfirm() {
        return new Promise((resolve) => {
            const modal = document.getElementById('subtable-merge-confirm-modal');
            const closeBtn = document.getElementById('subtable-merge-confirm-close');
            const yesBtn = document.getElementById('subtable-merge-yes-btn');
            const noBtn = document.getElementById('subtable-merge-no-btn');
            const infoDiv = document.getElementById('subtable-merge-info');

            // 顯示子桌號列表
            if (infoDiv && this.selectedCustomer) {
                const subTables = this.customers
                    .filter(c => c.table_number && c.table_number.startsWith(this.selectedCustomer.table_number + '.'))
                    .map(c => c.table_number.replace(/^A/i, ''));
                if (subTables.length > 0) {
                    infoDiv.innerHTML = `<span style="color:#e67e22;">子桌號：${subTables.join('、')}</span>`;
                }
            }

            const cleanup = () => {
                modal.classList.add('hidden');
                closeBtn.removeEventListener('click', onClose);
                yesBtn.removeEventListener('click', onYes);
                noBtn.removeEventListener('click', onNo);
            };

            const onClose = () => { cleanup(); resolve(null); };
            const onYes = () => { cleanup(); resolve(true); };
            const onNo = () => { cleanup(); resolve(false); };

            closeBtn.addEventListener('click', onClose);
            yesBtn.addEventListener('click', onYes);
            noBtn.addEventListener('click', onNo);

            // 點擊模態框外部關閉
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    cleanup();
                    resolve(null);
                }
            }, { once: true });

            modal.classList.remove('hidden');
        });
    }

    /**
     * 填充合單結賬彙總數據到結賬模態框並顯示
     * 不執行結賬，用戶需在模態框中按「確認結賬」完成
     */
    _fillMergeCheckoutModal(mainCustomer) {
        console.log('填充合單結賬彙總數據，母桌號:', mainCustomer.table_number);

        // 找出所有未結賬的子桌號
        const subCustomers = this.customers.filter(c =>
            c.table_number &&
            c.table_number.startsWith(mainCustomer.table_number + '.') &&
            c.id !== mainCustomer.id
        );

        // 合併所有客人：母桌號 + 子桌號
        const allCustomers = [mainCustomer, ...subCustomers];
        console.log('合單結賬桌號:', allCustomers.map(c => c.table_number));

        // 計算彙總數據
        const tableNumbers = allCustomers.map(c => c.table_number.replace(/^A/i, '')).join(', ');
        const totalPeople = allCustomers.reduce((sum, c) => sum + (Number(c.people_count) || 0), 0);
        const entryTimes = allCustomers.map(c => {
            const time = this.parseEntryTime(c.entry_time);
            return time.toLocaleTimeString('zh-TW', {
                hour: '2-digit',
                minute: '2-digit'
            });
        }).join(', ');
        const totalAmount = allCustomers.reduce((sum, c) => sum + (Number(c.total_amount) || 0), 0);

        // 更新結賬模態框顯示彙總數據
        document.getElementById('checkout-table').textContent = tableNumbers;
        document.getElementById('checkout-people').textContent = `${totalPeople}位`;
        document.getElementById('checkout-entry-time').textContent = entryTimes;
        document.getElementById('checkout-amount').textContent = `$${totalAmount.toFixed(2)}`;
        this.checkoutTotalAmount = totalAmount;

        // 重置收款金額和找續
        const paymentInput = document.getElementById('checkout-payment');
        if (paymentInput) {
            paymentInput.value = '';
            paymentInput.classList.remove('invalid');
        }
        document.getElementById('checkout-change').textContent = '$0.00';
        document.getElementById('checkout-change').className = 'change-amount';

        // 保存合單數據供 confirmMergeCheckout 使用
        this._mergeCheckoutData = {
            customers: allCustomers,
            totalAmount: totalAmount
        };

        // 設置合單模式狀態讓 confirmCheckout 能正確識別
        this.isMergeMode = true;
        this.mergeCustomerIds = new Set(allCustomers.map(c => c.id));

        // 顯示結賬模態框，用戶按「確認結賬」後執行 confirmMergeCheckout
        document.getElementById('checkout-modal').classList.remove('hidden');
    }

    // ==================== 合單結賬方法 ====================

    /**
     * 進入合單結賬模式
     */
    enterMergeMode() {
        if (this.isMergeMode) return;
        this.isMergeMode = true;
        this.mergeCustomerIds = new Set();

        // 取消當前選中的客人
        if (this.selectedCustomer) {
            this.deselectCustomer();
        }

        // 切換按鈕顯示狀態
        const mergeBtn = document.getElementById('merge-checkout-btn');
        const mergeBtnGroup = document.getElementById('merge-btn-group');

        if (mergeBtn) mergeBtn.disabled = true;
        if (mergeBtnGroup) mergeBtnGroup.style.display = 'inline-flex';

        // 清除所有卡片的選中狀態
        document.querySelectorAll('.customer-item.merge-selected').forEach(el => {
            el.classList.remove('merge-selected');
        });

        this.addMessage('請點擊選擇要合單結賬的桌號，至少選擇 2 張桌子', 'info');

        // 點擊非桌號區域自動取消合單模式
        if (!this._mergeCancelHandler) {
            this._mergeCancelHandler = (e) => {
                if (!this.isMergeMode) return;
                // 點到桌號卡片或合單按鈕組 → 不取消
                if (e.target.closest('.customer-item')) return;
                if (e.target.closest('#merge-btn-group')) return;
                if (e.target.closest('#merge-checkout-btn')) return;
                // 點到模態框 → 不取消
                if (e.target.closest('.modal')) return;
                this.exitMergeMode();
            };
        }
        // 延遲一幀綁定，避免本次 click 事件立即觸發取消
        setTimeout(() => {
            document.addEventListener('click', this._mergeCancelHandler);
        }, 0);
    }

    /**
     * 退出合單結賬模式
     */
    exitMergeMode(showMessage = true) {
        this.isMergeMode = false;
        this.mergeCustomerIds = new Set();
        this._mergeCheckoutData = null;

        // 恢復按鈕顯示狀態
        const mergeBtn = document.getElementById('merge-checkout-btn');
        const mergeBtnGroup = document.getElementById('merge-btn-group');

        if (mergeBtn) mergeBtn.disabled = false;
        if (mergeBtnGroup) mergeBtnGroup.style.display = 'none';

        // 移除所有卡片的合單選中樣式
        document.querySelectorAll('.customer-item.merge-selected').forEach(el => {
            el.classList.remove('merge-selected');
        });

        if (showMessage) {
            this.addMessage('已取消合單結賬', 'info');
        }

        // 移除全域點擊監聽
        if (this._mergeCancelHandler) {
            document.removeEventListener('click', this._mergeCancelHandler);
        }
    }

    /**
     * 切換指定客人的合單選中狀態
     * @param {string} customerId - 客戶ID
     * @param {HTMLElement} cardElement - 卡片DOM元素
     */
    toggleMergeSelection(customerId, cardElement) {
        if (!this.isMergeMode) return;

        const card = cardElement || document.querySelector(`.customer-item[data-customer-id="${customerId}"]`);
        if (!card) return;

        if (this.mergeCustomerIds.has(customerId)) {
            this.mergeCustomerIds.delete(customerId);
            card.classList.remove('merge-selected');
        } else {
            this.mergeCustomerIds.add(customerId);
            card.classList.add('merge-selected');
        }

        console.log(`合單選擇: ${this.mergeCustomerIds.size} 張桌子已選`);
    }

    /**
     * 確認合單選擇，顯示結賬模態框
     */
    confirmMergeSelection() {
        const realCustomerIds = [...this.mergeCustomerIds].filter(id => !id.startsWith('mock-customer-'));
        if (realCustomerIds.length < 2) {
            this.addMessage('請選擇至少兩個真實桌號進行合單結賬', 'warning');
            return;
        }

        // 獲取選中客人的完整數據
        const selectedCustomers = this.customers.filter(c => realCustomerIds.includes(c.id));

        // 計算彙總數據
        const tableNumbers = selectedCustomers.map(c => c.table_number).join(', ');
        const totalPeople = selectedCustomers.reduce((sum, c) => sum + (Number(c.people_count) || 0), 0);
        const entryTimes = selectedCustomers.map(c => {
            const time = this.parseEntryTime(c.entry_time);
            return time.toLocaleTimeString('zh-TW', {
                hour: '2-digit',
                minute: '2-digit'
            });
        }).join(', ');
        const totalAmount = selectedCustomers.reduce((sum, c) => sum + (Number(c.total_amount) || 0), 0);

        // 保存合單數據供 confirmMergeCheckout 使用
        this._mergeCheckoutData = {
            customers: selectedCustomers,
            totalAmount: totalAmount
        };

        // 填充結賬模態框
        document.getElementById('checkout-table').textContent = tableNumbers;
        document.getElementById('checkout-people').textContent = `${totalPeople}位`;
        document.getElementById('checkout-entry-time').textContent = entryTimes;
        document.getElementById('checkout-amount').textContent = `$${totalAmount.toFixed(2)}`;
        this.checkoutTotalAmount = totalAmount;

        // 重置收款金額和找續
        const paymentInput = document.getElementById('checkout-payment');
        if (paymentInput) {
            paymentInput.value = '';
            paymentInput.classList.remove('invalid');
        }
        document.getElementById('checkout-change').textContent = '$0.00';
        document.getElementById('checkout-change').className = 'change-amount';

        // 顯示模態框
        document.getElementById('checkout-modal').classList.remove('hidden');
    }

    /**
     * 執行合單結賬 - 依次為每個客人調用結賬API
     */
    async confirmMergeCheckout() {
        if (!this._mergeCheckoutData || !this._mergeCheckoutData.customers || this._mergeCheckoutData.customers.length === 0) {
            this.addMessage('合單結賬數據異常，請重新操作', 'error');
            return;
        }

        // 驗證收款金額
        const paymentInput = document.getElementById('checkout-payment');
        const paymentStr = paymentInput?.value?.trim();
        let payment = NaN;

        if (paymentStr !== '' && paymentStr !== undefined) {
            payment = parseFloat(paymentStr);
            const total = this.checkoutTotalAmount || 0;

            if (!isNaN(payment) && payment <= 0) {
                this.addMessage('收款金額必須大於 0', 'error');
                if (paymentInput) paymentInput.focus();
                return;
            }

            if (!isNaN(payment) && payment < total) {
                this.addMessage('收款金額不可少於結賬金額', 'error');
                if (paymentInput) paymentInput.focus();
                return;
            }
        }

        // 防止重複提交
        if (this.isCheckingOut) {
            console.log('結賬正在進行中，請稍候');
            return;
        }

        this.isCheckingOut = true;
        const customers = this._mergeCheckoutData.customers;
        let successCount = 0;
        let failureCount = 0;
        const failedTables = [];

        // 隱藏結賬模態框
        this.hideCheckoutModal();

        this.addMessage(`正在進行合單結賬，共 ${customers.length} 個桌號...`, 'info');

        try {
            for (const customer of customers) {
                try {
                    console.log(`合單結賬: 正在處理桌號 ${customer.table_number} (ID: ${customer.id})`);

                    const response = await this.fetchWithAuth('/api/cashier/checkout', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            customer_id: customer.id,
                            payment_method: "cash",
                            payment_amount: isNaN(payment) ? undefined : payment
                        })
                    });

                    const result = await response.json();

                    if (result.success) {
                        successCount++;
                        console.log(`合單結賬成功: 桌號 ${customer.table_number}`);
                    } else {
                        failureCount++;
                        failedTables.push(customer.table_number);
                        console.error(`合單結賬失敗 (桌號 ${customer.table_number}):`, result.error);
                    }
                } catch (error) {
                    failureCount++;
                    failedTables.push(customer.table_number);
                    console.error(`合單結賬失敗 (桌號 ${customer.table_number}):`, error.message);
                }
            }
        } finally {
            this.isCheckingOut = false;

            // 顯示結果摘要
            if (successCount > 0 && failureCount === 0) {
                this.addMessage(`合單結賬成功: ${successCount} 個桌號已完成結賬`, 'success');
            } else if (successCount > 0 && failureCount > 0) {
                this.addMessage(`合單結賬: ${successCount} 個成功，${failureCount} 個失敗 (桌號: ${failedTables.join(', ')})`, 'warning');
            } else {
                this.addMessage(`合單結賬失敗: 所有 ${failureCount} 個桌號均失敗`, 'error');
            }

            // 清理狀態
            this._mergeCheckoutData = null;
            this.exitMergeMode(false); // 不顯示"已取消合單結賬"訊息
            await this.loadCustomers();
            await this.loadTodayStats();
        }
    }

    /**
     * 在 displayCustomers 重新渲染後恢復合單選中狀態
     */
    updateMergeSelectionUI() {
        if (!this.isMergeMode || !this.mergeCustomerIds || this.mergeCustomerIds.size === 0) return;

        const staleIds = [];
        this.mergeCustomerIds.forEach(customerId => {
            const card = document.querySelector(`.customer-item[data-customer-id="${customerId}"]`);
            if (card) {
                card.classList.add('merge-selected');
            } else {
                staleIds.push(customerId);
            }
        });

        staleIds.forEach(id => this.mergeCustomerIds.delete(id));
        if (staleIds.length > 0) {
            console.log(`合單模式: 已清理 ${staleIds.length} 個失效的客戶ID`);
        }
    }

    // ==================== 機器主服務器設定方法 ====================

    /**
     * 連接到機器主服務器
     */
    async connectToMachineMaster() {
        console.log('connectToMachineMaster called');
        const ipInput = document.getElementById('machine-master-server-ip');
        if (!ipInput) {
            this.addMessage('[機器主服務器] 找不到IP輸入框', 'error');
            return;
        }

        const machineMasterIp = ipInput.value.trim();
        if (!machineMasterIp) {
            this.addMessage('[機器主服務器] 請輸入機器主服務器IP地址', 'warning');
            return;
        }

        // 規範化IP地址
        const normalizedIp = this.normalizeMasterIp(machineMasterIp);
        ipInput.value = normalizedIp;

        this.addMessage(`[機器主服務器] 正在連接到機器主服務器: ${normalizedIp}`, 'info');

        try {
            // 測試連接
            const isConnected = await this.testMachineMasterConnection(normalizedIp);
            if (isConnected) {
                // 保存設定
                localStorage.setItem('machineMasterServerIp', normalizedIp);
                this.addMessage('[機器主服務器] 連接成功！', 'success');
                this.updateMachineMasterConnectionStatus('connected', normalizedIp);

                // 通知其他機器界面更新
                this.notifyMachineInterfaces(normalizedIp);
            } else {
                this.addMessage('[機器主服務器] 連接失敗，請檢查IP地址和服務器狀態', 'error');
                this.updateMachineMasterConnectionStatus('error', normalizedIp);
            }
        } catch (error) {
            console.error('[機器主服務器] 連接過程發生錯誤:', error);
            this.addMessage(`[機器主服務器] 連接錯誤: ${error.message}`, 'error');
            this.updateMachineMasterConnectionStatus('error', normalizedIp);
        }
    }

    /**
     * 斷開機器主服務器連接
     */
    disconnectFromMachineMaster() {
        console.log('disconnectFromMachineMaster called');

        // 清除保存的IP
        localStorage.removeItem('machineMasterServerIp');

        // 更新連接狀態
        this.updateMachineMasterConnectionStatus('disconnected', '未設定');

        this.addMessage('[機器主服務器] 已斷開連接', 'info');

        // 通知其他機器界面清除設定
        this.notifyMachineInterfaces(null);
    }

    /**
     * 測試機器主服務器連接
     */
    async testMachineMasterConnection(machineMasterIp) {
        console.log('testMachineMasterConnection called:', machineMasterIp);

        // 重用現有的健康檢查方法
        return await this.testMasterConnection(machineMasterIp);
    }

    /**
     * 保存機器主服務器IP設定
     */
    saveMachineMasterIpSettings() {
        console.log('saveMachineMasterIpSettings called');
        const ipInput = document.getElementById('machine-master-server-ip');
        if (!ipInput) {
            this.addMessage('[機器主服務器] 找不到IP輸入框', 'error');
            return;
        }

        const machineMasterIp = ipInput.value.trim();
        if (!machineMasterIp) {
            this.addMessage('[機器主服務器] 請輸入機器主服務器IP地址', 'warning');
            return;
        }

        // 規範化IP地址
        const normalizedIp = this.normalizeMasterIp(machineMasterIp);
        ipInput.value = normalizedIp;

        // 保存到localStorage
        localStorage.setItem('machineMasterServerIp', normalizedIp);

        this.addMessage(`[機器主服務器] IP設定已保存: ${normalizedIp}`, 'success');

        // 更新顯示
        this.updateMachineMasterConnectionStatus('unknown', normalizedIp);
    }

    /**
     * 更新機器主服務器連接狀態顯示
     */
    updateMachineMasterConnectionStatus(status = null, machineMasterIp = null) {
        console.log('updateMachineMasterConnectionStatus called:', status, machineMasterIp);

        // 更新內部連接狀態
        if (status) {
            this.machineMasterConnectionStatus = status;
        }

        // 更新顯示元素
        const statusDisplay = document.getElementById('machine-master-status-display');
        if (statusDisplay) {
            let statusText = '未知';
            let statusClass = 'unknown';

            switch(status) {
                case 'connected':
                    statusText = '已連接';
                    statusClass = 'connected';
                    break;
                case 'disconnected':
                    statusText = '未連接';
                    statusClass = 'disconnected';
                    break;
                case 'error':
                    statusText = '連接錯誤';
                    statusClass = 'error';
                    break;
                default:
                    statusText = '未設定';
                    statusClass = 'unknown';
            }

            statusDisplay.textContent = statusText;
            statusDisplay.className = `status-value ${statusClass}`;
        }

        // 更新IP顯示
        const ipInput = document.getElementById('machine-master-server-ip');
        if (ipInput && machineMasterIp) {
            ipInput.value = machineMasterIp;
        }
    }

    // ====== 部份結賬功能 ======

    /**
     * 計算商品有效單價（考量立減/折扣）
     */
    _calcEffectivePrice(item) {
        const unitPrice = item.price_at_time || 0;
        const flatDisc = item.flat_discount || 0;
        const pctDisc = item.percent_discount || 0;
        let effective = unitPrice - flatDisc;
        if (pctDisc > 0) {
            effective = effective * (100 - pctDisc) / 100;
        }
        return unitPrice >= 0 ? Math.max(0, effective) : effective;
    }

    /**
     * 開啟部份結賬模態框
     */
    async openPartialCheckoutModal() {
        console.log('openPartialCheckoutModal called');
        if (!this.selectedCustomer) return;

        const modal = document.getElementById('partial-checkout-modal');
        if (!modal) return;

        // 從 API 獲取完整客人資料（含 order_items）
        try {
            const response = await this.fetchWithAuth(`/api/cashier/customer/${this.selectedCustomer.id}`);
            const result = await response.json();
            if (!result.success || !result.customer) {
                this.addMessage('無法載入客人商品資料', 'error');
                return;
            }

            const customer = result.customer;
            const orderItems = customer.order_items || [];

            // 按 product_id+折扣 合併商品（不同折扣的同一商品視為不同項目）
            const productMap = new Map();
            for (const item of orderItems) {
                if (item.quantity <= 0) continue;
                const flatD = item.flat_discount || 0;
                const pctD = item.percent_discount || 0;
                const mergeKey = `${item.product_id}|${flatD}|${pctD}`;
                if (productMap.has(mergeKey)) {
                    productMap.get(mergeKey).quantity += item.quantity;
                } else {
                    productMap.set(mergeKey, {
                        product_id: item.product_id,
                        product_name: item.product_name || '商品',
                        price_at_time: item.price_at_time || 0,
                        flat_discount: flatD,
                        percent_discount: pctD,
                        quantity: item.quantity,
                        rowKey: mergeKey
                    });
                }
            }

            // 存為實例變數供後續操作
            this._partialCheckoutData = {
                customerId: customer.id,
                tableNumber: customer.table_number || '',
                storeId: this.selectedStoreId || 'default_store',
                tableItems: Array.from(productMap.values()),    // 桌號商品原始數據
                checkoutItems: []                               // 結賬清單（移入的商品）
            };

            this._renderPartialCheckoutLists();

            modal.classList.remove('hidden');
        } catch (error) {
            console.error('openPartialCheckoutModal error:', error);
            this.addMessage('無法載入客人商品資料: ' + error.message, 'error');
        }
    }

    /**
     * 渲染部份結賬左右兩欄
     */
    _renderPartialCheckoutLists() {
        const data = this._partialCheckoutData;
        if (!data) return;

        const leftList = document.getElementById('partial-checkout-list');
        const rightList = document.getElementById('partial-checkout-table-items');
        if (!leftList || !rightList) return;

        // 渲染右側：桌號商品（原始數量 - 已移入結賬清單的數量）
        const checkoutMap = new Map();
        for (const ci of data.checkoutItems) {
            checkoutMap.set(ci.rowKey, (checkoutMap.get(ci.rowKey) || 0) + ci.quantity);
        }

        let rightHtml = '';
        let rightTotal = 0;
        for (const item of data.tableItems) {
            const checkedOut = checkoutMap.get(item.rowKey) || 0;
            const remaining = item.quantity - checkedOut;
            if (remaining <= 0) continue;
            const effPrice = this._calcEffectivePrice(item);
            rightTotal += remaining * effPrice;
            const priceDisplay = (effPrice !== item.price_at_time)
                ? `<span class="partial-checkout-item-price">$${effPrice.toFixed(2)}</span> <span class="partial-checkout-item-original-price" style="text-decoration:line-through;color:#999;font-size:0.8em;">$${item.price_at_time.toFixed(2)}</span>`
                : `<span class="partial-checkout-item-price">$${item.price_at_time.toFixed(2)}</span>`;
            rightHtml += `
                <div class="partial-checkout-item" data-row-key="${item.rowKey}" data-side="right">
                    <span class="partial-checkout-item-name">${this._escapeHtml(item.product_name)}</span>
                    ${priceDisplay}
                    <span class="partial-checkout-item-qty">剩 ${remaining}</span>
                </div>`;
        }
        rightList.innerHTML = rightHtml || '<div class="partial-checkout-empty">暫無商品</div>';
        document.getElementById('partial-checkout-right-total').textContent = '$' + rightTotal.toFixed(2);

        // 渲染左側：結賬清單（已移入的商品）
        let leftHtml = '';
        let leftTotal = 0;
        for (const item of data.checkoutItems) {
            if (item.quantity <= 0) continue;
            const effPrice = this._calcEffectivePrice(item);
            leftTotal += item.quantity * effPrice;
            const priceDisplay = (effPrice !== item.price_at_time)
                ? `<span class="partial-checkout-item-price">$${effPrice.toFixed(2)}</span> <span class="partial-checkout-item-original-price" style="text-decoration:line-through;color:#999;font-size:0.8em;">$${item.price_at_time.toFixed(2)}</span>`
                : `<span class="partial-checkout-item-price">$${item.price_at_time.toFixed(2)}</span>`;
            leftHtml += `
                <div class="partial-checkout-item" data-row-key="${item.rowKey}" data-side="left">
                    <span class="partial-checkout-item-name">${this._escapeHtml(item.product_name)}</span>
                    ${priceDisplay}
                    <span class="partial-checkout-item-qty">${item.quantity}</span>
                </div>`;
        }
        leftList.innerHTML = leftHtml || '<div class="partial-checkout-empty">暫無商品</div>';
        document.getElementById('partial-checkout-left-total').textContent = '$' + leftTotal.toFixed(2);

        // 綁定點擊事件
        this._bindPartialCheckoutClickEvents();
    }

    /**
     * 綁定部份結賬商品項目的點擊事件
     */
    _bindPartialCheckoutClickEvents() {
        const data = this._partialCheckoutData;
        if (!data) return;

        // 右欄點擊：移到左側（結賬清單）
        document.querySelectorAll('#partial-checkout-table-items .partial-checkout-item').forEach(el => {
            el.addEventListener('click', (e) => {
                const rowKey = e.currentTarget.dataset.rowKey;
                if (!rowKey) return;

                // 檢查是否還有剩餘數量
                const checkoutQty = data.checkoutItems
                    .filter(i => i.rowKey === rowKey)
                    .reduce((sum, i) => sum + i.quantity, 0);
                const tableItem = data.tableItems.find(i => i.rowKey === rowKey);
                if (!tableItem) return;
                const remaining = tableItem.quantity - checkoutQty;
                if (remaining <= 0) return; // 沒得移了

                // 從桌號商品移到結賬清單（1個數量）
                const existing = data.checkoutItems.find(i => i.rowKey === rowKey);
                if (existing) {
                    existing.quantity += 1;
                } else {
                    data.checkoutItems.push({
                        product_id: tableItem.product_id,
                        product_name: tableItem.product_name,
                        price_at_time: tableItem.price_at_time,
                        flat_discount: tableItem.flat_discount || 0,
                        percent_discount: tableItem.percent_discount || 0,
                        quantity: 1,
                        rowKey: tableItem.rowKey
                    });
                }

                this._renderPartialCheckoutLists();
            });
        });

        // 左欄點擊：移到右側（回到桌號商品）
        document.querySelectorAll('#partial-checkout-list .partial-checkout-item').forEach(el => {
            el.addEventListener('click', (e) => {
                const rowKey = e.currentTarget.dataset.rowKey;
                if (!rowKey) return;

                const existing = data.checkoutItems.find(i => i.rowKey === rowKey);
                if (!existing || existing.quantity <= 0) return;

                existing.quantity -= 1;
                if (existing.quantity <= 0) {
                    data.checkoutItems = data.checkoutItems.filter(i => i.rowKey !== rowKey);
                }

                this._renderPartialCheckoutLists();
            });
        });
    }

    /**
     * 關閉部份結賬模態框
     */
    closePartialCheckoutModal() {
        const modal = document.getElementById('partial-checkout-modal');
        if (modal) modal.classList.add('hidden');
        this._partialCheckoutData = null;
    }

    /**
     * 確認部份結賬
     */
    async confirmPartialCheckout() {
        const data = this._partialCheckoutData;
        if (!data || data.checkoutItems.length === 0) {
            this.addMessage('請先選擇要結賬的商品', 'warning');
            return;
        }

        // 收集要結賬的商品（使用折扣後的有效價格）
        const items = data.checkoutItems
            .filter(i => i.quantity > 0)
            .map(i => ({
                product_id: i.product_id,
                product_name: i.product_name,
                quantity: i.quantity,
                price_at_time: this._calcEffectivePrice(i)  // 傳送有效價格（含折扣）
            }));

        if (items.length === 0) {
            this.addMessage('請先選擇要結賬的商品', 'warning');
            return;
        }

        try {
            this.addMessage('正在處理部份結賬...', 'info');
            const response = await this.fetchWithAuth('/api/cashier/partial-checkout', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    customer_id: data.customerId,
                    items: items,
                    store_id: data.storeId
                })
            });
            const result = await response.json();

            if (result.success) {
                this.addMessage(`部份結賬成功: 桌號 ${result.partial_table_number}, 金額: $${result.total_amount}`, 'success');
                this.closePartialCheckoutModal();
                // 刷新客人資料
                if (this.selectedCustomer) {
                    this.loadCustomerDetail(this.selectedCustomer.id);
                }
                this.loadCustomers();
                this.loadTodayStats();
            } else {
                this.addMessage('部份結賬失敗: ' + (result.error || '未知錯誤'), 'error');
            }
        } catch (error) {
            console.error('confirmPartialCheckout error:', error);
            this.addMessage('部份結賬失敗: ' + error.message, 'error');
        }
    }

    /**
     * 通知其他機器界面更新主服務器設定
     */
    notifyMachineInterfaces(machineMasterIp) {
        console.log('notifyMachineInterfaces called:', machineMasterIp);

        // 這裡可以實現通知其他機器界面（entry-machine, exit-machine, vending-machine）的邏輯
        // 例如：通過localStorage事件或廣播API

        // 方案1: 通過localStorage事件通知
        const eventData = {
            type: 'MACHINE_MASTER_IP_UPDATE',
            machineMasterIp: machineMasterIp,
            timestamp: Date.now()
        };

        localStorage.setItem('machineMasterEvent', JSON.stringify(eventData));

        // 方案2: 在localStorage中設置標記，其他界面可以定期檢查
        localStorage.setItem('machineMasterServerIp', machineMasterIp || '');

        this.addMessage(`[機器主服務器] 設定已更新，entry-machine、exit-machine、vending-machine將使用此設定`, 'info');
    }

    /**
     * 初始化機器主服務器設定
     */
    initMachineMasterSettings() {
        console.log('initMachineMasterSettings called');

        // 從localStorage加載保存的機器主服務器IP
        const savedMachineMasterIp = localStorage.getItem('machineMasterServerIp') || '';

        // 更新輸入框
        const ipInput = document.getElementById('machine-master-server-ip');
        if (ipInput && savedMachineMasterIp) {
            ipInput.value = savedMachineMasterIp;
        }

        // 更新連接狀態
        this.updateMachineMasterConnectionStatus('unknown', savedMachineMasterIp);
    }
}

// 重寫connectSocket方法以支持主服務器IP配置
EnhancedCashierSystem.prototype.connectSocket = function() {
    console.log('EnhancedCashierSystem.connectSocket called');

    // 獲取主服務器IP
    const masterIp = localStorage.getItem('masterServerIp');
    const currentRole = localStorage.getItem('hostRole') || 'master';

    let socketUrl = window.location.origin;
    let isConnectingToMaster = false;

    // 如果是分機模式且有配置主服務器IP，使用配置的IP
    if (currentRole === 'client' && masterIp) {
        socketUrl = `http://${masterIp}`;
        isConnectingToMaster = true;
        console.log('使用主服務器IP連接Socket.IO:', socketUrl);
    } else {
        console.log('使用本地服務器連接Socket.IO:', socketUrl);
    }

    // 如果已經有socket連接，先斷開
    if (this.socket && this.socket.connected) {
        console.log('斷開現有的Socket.IO連接');
        this.socket.disconnect();
    }

    // 記錄當前嘗試連接的URL，用於錯誤處理時識別
    this._lastSocketConnectionAttempt = socketUrl;
    this._isConnectingToMaster = isConnectingToMaster;

    // 創建Socket.IO連接，添加額外配置以支持跨域
    this.socket = io(socketUrl, {
        transports: ['websocket', 'polling'],
        reconnection: true,
        reconnectionAttempts: 5,
        reconnectionDelay: 1000
    });

    // 複製父類的socket事件處理器（從CashierSystem.prototype.connectSocket）
    // 注意：這裡只複製基本的事件處理器，實際應用中可能需要更完整的實現
    this.socket.on('connect', () => {
        console.log(`Socket.IO連接成功: ${socketUrl}`);
        this.updateStatus('online');
        this.addMessage(`已連線到伺服器: ${socketUrl}`, 'success');

        // 根據連接目標更新主連接狀態
        if (isConnectingToMaster) {
            console.log('成功連接到主服務器，更新主連接狀態為已連接');
            this.updateConnectionStatusDisplay('connected', masterIp);
        } else {
            // 連接到本地服務器，更新主連接狀態為斷開（未連接到主服務器）
            console.log('連接到本地服務器，更新主連接狀態為斷開');
            this.updateConnectionStatusDisplay('disconnected', null);
        }

        // 重置重新連接標誌（如果設置了）
        if (this._isReconnectingToMaster) {
            console.log('Socket.IO連接成功，重置重新連接標誌');
            this._isReconnectingToMaster = false;
        }
    });

    this.socket.on('disconnect', (reason) => {
        console.log(`Socket.IO斷開連接: ${reason}`);
        this.updateStatus('offline');
        this.addMessage('與伺服器斷開連線', 'error');

        // 如果是連接到主服務器時斷開，更新狀態為斷開
        if (isConnectingToMaster) {
            console.log('與主服務器斷開連接，更新狀態為斷開');
            this.updateConnectionStatusDisplay('disconnected', masterIp);
        }
    });

    // 添加連接錯誤處理
    this.socket.on('connect_error', (error) => {
        console.error(`Socket.IO連接錯誤:`, error);
        console.error(`連接URL: ${socketUrl}, 錯誤詳情:`, error.message);

        // 如果正在嘗試連接到主服務器失敗，更新狀態為錯誤
        if (isConnectingToMaster) {
            console.log('連接到主服務器失敗，等待重連機制或最終失敗處理');
            this.addMessage('連接到主服務器失敗，正在嘗試重連...', 'warning');

            // 更新連接狀態為錯誤（但不立即清除IP，等待重連機制）
            this.updateConnectionStatusDisplay('error', masterIp);

            // 重置重新連接標誌
            if (this._isReconnectingToMaster) {
                console.log('連接到主服務器失敗，重置重新連接標誌');
                this._isReconnectingToMaster = false;
            }

            // 不立即回退到本地服務器，讓Socket.IO的重連機制嘗試
            // 如果最終失敗，reconnect_failed事件會處理回退
        } else {
            // 本地服務器連接錯誤
            this.addMessage('本地服務器連接錯誤', 'error');
        }
    });

    // 添加重新連接事件處理
    this.socket.on('reconnecting', (attemptNumber) => {
        console.log(`Socket.IO正在重新連接，嘗試次數: ${attemptNumber}`);
        this.addMessage(`正在重新連接到伺服器 (嘗試 ${attemptNumber})`, 'info');
    });

    this.socket.on('reconnect_failed', () => {
        console.error('Socket.IO重新連接失敗');
        this.addMessage('重新連接伺服器失敗', 'error');

        // 如果連接到主服務器失敗，保留 masterServerIp 讓 autoReconnectToMaster 自動重連
        if (isConnectingToMaster) {
            console.log('連接到主服務器最終失敗，保留主機IP，啟動自動重連機制');
            this.updateConnectionStatusDisplay('disconnected', masterIp);

            // 重置重新連接標誌
            if (this._isReconnectingToMaster) {
                console.log('Socket.IO重新連接最終失敗，重置重新連接標誌');
                this._isReconnectingToMaster = false;
            }

            // 先連回本地服務器保持 UI 可用
            setTimeout(() => {
                this.connectSocket();
            }, 3000);

            // 啟動自動重連（保留 masterServerIp，網絡恢復後會自動重連主機）
            setTimeout(() => {
                this.autoReconnectToMaster();
            }, 5000);
        }
    });

    this.socket.on('customer-added', (data) => {
        this.addMessage(`新客人入場: 桌號 ${data.table_number}, ${data.people_count}位`, 'info');
        this.loadCustomers();
        this.loadTodayStats();
    });

    this.socket.on('order-updated', (data) => {
        if (this.selectedCustomer && this.selectedCustomer.id === data.customer_id) {
            this.addMessage(`已添加商品: ${data.product_name} x${data.quantity}`, 'success');
            this.loadCustomerDetail(this.selectedCustomer.id);
        }
        // 刷新在場客人列表（因為訂單金額變更）
        this.loadCustomers();
    });

    this.socket.on('checkout-complete', (data) => {
        this.addMessage(`桌號 ${data.table_number} 已結賬, 金額: $${data.total_amount}`, 'success');
        this.loadCustomers();
        this.loadTodayStats();
        this.clearSelectedCustomer();
    });

    this.socket.on('partial-checkout-complete', (data) => {
        this.addMessage(`桌號 ${data.partial_table_number} 部份結賬, 金額: $${data.total_amount}`, 'success');
        this.loadCustomers();
        this.loadTodayStats();
        if (this.selectedCustomer && this.selectedCustomer.id === data.customer_id) {
            this.loadCustomerDetail(this.selectedCustomer.id);
        }
    });

    this.socket.on('customer-deleted', (data) => {
        this.addMessage(`桌號 ${data.table_number} 已刪除`, 'info');
        if (this.selectedCustomer && this.selectedCustomer.id === data.customer_id) {
            this.clearSelectedCustomer();
        }
        this.loadCustomers();
    });

    // 監聽 new-customer 事件（從 HTTP POST /api/entry/entry 發出）
    // 讓分機新增桌號後，主機也能自動刷新列表
    this.socket.on('new-customer', (data) => {
        console.log(`收到新客人通知: 桌號 ${data.table_number}, ${data.people_count}位`);
        this.loadCustomers();
        this.loadTodayStats();
        this.loadEntryRecords();
    });

    console.log('Socket.IO連接嘗試已建立，URL:', socketUrl);
};

// 全局函數：重新啟用模擬數據
window.enableMockData = function() {
    if (window.cashierSystem && typeof window.cashierSystem.enableMockData === 'function') {
        window.cashierSystem.enableMockData();
    } else {
        // 如果收銀系統尚未初始化，只設置本地存儲
        localStorage.setItem('cashier_showMockData', 'true');
        localStorage.setItem('cashier_alwaysShowMockData', 'true');
        console.log('模擬數據設置已更新。請刷新頁面以重新啟用模擬數據。');
        alert('模擬數據設置已更新。請刷新頁面以重新啟用模擬數據。');
    }
};

// 初始化增強收銀系統
document.addEventListener('DOMContentLoaded', async () => {
    console.log('DOMContentLoaded: 開始初始化 EnhancedCashierSystem');
    console.log('window.cashierSystem exists?', !!window.cashierSystem);
    console.log('window.cashierSystem constructor name:', window.cashierSystem?.constructor?.name);

    // 防止重複初始化
    if (window.cashierSystem && window.cashierSystem.constructor.name === 'EnhancedCashierSystem') {
        console.log('EnhancedCashierSystem 已存在，跳過初始化');
        return;
    }
    try {
        console.log('Creating new EnhancedCashierSystem instance...');
        window.cashierSystem = new EnhancedCashierSystem();
        console.log('DOMContentLoaded: EnhancedCashierSystem 實例創建成功');

        // 初始化系統
        console.log('Calling cashierSystem.init()...');
        await window.cashierSystem.init();
        console.log('DOMContentLoaded: EnhancedCashierSystem.init() 完成');
    } catch (error) {
        console.error('DOMContentLoaded: 初始化 EnhancedCashierSystem 時發生錯誤:', error);
        alert('系統初始化失敗，請查看控制台日誌: ' + error.message);
    }
});

// ===== 系統更新 UI 全域函數 =====
var _updateCheckTimer = null;

function showUpdateModal() {
    var cs = window.cashierSystem;
    if (!cs) return;
    // 分機不允許按「立即更新」
    var role = localStorage.getItem('hostRole') || 'master';
    if (role !== 'master') {
        if (cs.addMessage) cs.addMessage('⚠️ 只有主機模式可以執行系統更新', 'error');
        return;
    }
    var modal = document.getElementById('updateModal');
    if (!modal) return;
    // 更新版本資訊
    var vi = document.getElementById('updateVersionInfo');
    if (vi) vi.textContent = 'Server: ' + (document.getElementById('hostSvVer')?.textContent || '?') + ' → ' + (document.getElementById('hostSvLatestVer')?.textContent || '?');
    // 顯示確認 modal
    document.getElementById('updateBtnArea').style.display = 'flex';
    document.getElementById('updateProgressArea').style.display = 'none';
    document.getElementById('updateConfirmBtn').disabled = false;
    modal.style.display = 'flex';
    modal.classList.remove('hidden');
}

function closeUpdateModal() {
    var modal = document.getElementById('updateModal');
    if (modal) { modal.style.display = 'none'; modal.classList.add('hidden'); }
    if (_updateCheckTimer) { clearInterval(_updateCheckTimer); _updateCheckTimer = null; }
}

function startSystemUpdate() {
    var btn = document.getElementById('updateConfirmBtn');
    btn.disabled = true;
    btn.textContent = '更新中...';
    document.getElementById('updateBtnArea').style.display = 'none';
    document.getElementById('updateProgressArea').style.display = 'block';
    document.getElementById('updateProgressText').textContent = '正在觸發更新...';

    // 顯示鎖遮罩
    var lockOverlay = document.getElementById('updateLockOverlay');
    if (lockOverlay) lockOverlay.style.display = 'flex';

    // 檢查 ENABLE HOT FIX checkbox（用伺服器端狀態）
    var fetchOpts = { method: 'POST' };
    // 讀取伺服器 hot_fix 狀態
    fetch('/api/update/hot-fix').then(function(r) { return r.json(); }).then(function(hf) {
        if (hf.success && hf.hot_fix_enabled) {
            fetchOpts.headers = { 'Content-Type': 'application/json' };
            fetchOpts.body = JSON.stringify({ hot_fix: true });
        }
        doTrigger();
    }).catch(function() { doTrigger(); });

    function doTrigger() {
    // call API
    fetch('/api/update/trigger', fetchOpts)
        .then(function(r) { return r.json(); })
        .then(function(o) {
            if (o.success) {
                document.getElementById('updateProgressText').textContent = '更新已啟動，請耐心等待...';
                // 輪詢更新狀態
                _updateCheckTimer = setInterval(function() {
                    fetch('/api/update-status')
                        .then(function(r) { return r.json(); })
                        .then(function(s) {
                            if (!s.is_updating) {
                                document.getElementById('updateProgressText').textContent = '✅ 更新完成！';
                                clearInterval(_updateCheckTimer);
                                _updateCheckTimer = null;
                                setTimeout(function() { location.reload(); }, 2000);
                            }
                        })
                        .catch(function() {});
                }, 5000);
            } else {
                document.getElementById('updateProgressText').textContent = '❌ ' + (o.error || '觸發失敗');
                btn.disabled = false;
                btn.textContent = '確認更新';
                if (lockOverlay) lockOverlay.style.display = 'none';
            }
        })
        .catch(function(err) {
            document.getElementById('updateProgressText').textContent = '❌ 網絡錯誤: ' + err.message;
            btn.disabled = false;
            btn.textContent = '確認更新';
            if (lockOverlay) lockOverlay.style.display = 'none';
        });
    }
}

// 全局錯誤處理
window.addEventListener('error', (event) => {
    console.error('全局錯誤:', event.error);
    console.error('錯誤發生在:', event.filename, '行號:', event.lineno, '列號:', event.colno);
});

window.addEventListener('unhandledrejection', (event) => {
    console.error('未處理的 Promise 拒絕:', event.reason);
});