const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');
const { sendWhatsApp, makePhoneCall } = require('../services/twilioService');

// 阿里雲 forward helper：當本地搵唔到 record 時 proxy 去阿里雲
const ALIYUN_SERVER = (process.env.ALIYUN_SERVER || 'http://47.239.121.13:3000').replace(/\/$/, '');
const API_KEY = process.env.ALIYUN_API_KEY || process.env.MAIN_API_KEY || '';
const FETCH_TIMEOUT_MS = parseInt(process.env.ALIYUN_PROXY_TIMEOUT || '8000', 10);

function forwardToAliyun(method, endpoint, body) {
    const url = `${ALIYUN_SERVER}${endpoint}`;
    const opts = {
        method,
        headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY }
    };
    if (body) opts.body = JSON.stringify(body);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    opts.signal = controller.signal;
    return fetch(url, opts).then(r => {
        clearTimeout(timer);
        return r.json();
    }).catch(e => {
        clearTimeout(timer);
        throw e;
    });
}

/**
 * @route POST /api/waitinglist
 * @desc 新增候位（公開）
 * @access Public
 */
router.post('/', (req, res) => {
    try {
        const { store_id, adults, children, phone, notes, lang } = req.body;
        if (!store_id || !phone) {
            return res.status(400).json({ success: false, error: '缺少必要欄位', message: '請填寫分店和聯絡電話' });
        }
        const id = require('uuid').v4();
        db.run(`INSERT INTO waitinglist (id, store_id, adults, children, phone, notes, lang, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'waiting', datetime('now', '+8 hours'))`,
            [id, store_id, adults || 0, children || 0, phone, notes || '', lang || 'zh-TW'],
            function(err) {
                if (err) {
                    return res.status(500).json({ success: false, error: '儲存失敗', message: err.message });
                }
                forwardToAliyun('POST', '/api/waitinglist', { store_id, adults, children, phone, notes, lang })
                    .catch(e => console.error('forward waitinglist to Aliyun failed:', e.message));
                res.status(201).json({ success: true, data: { id, store_id, adults, children, phone, notes, lang } });
            });
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

router.get('/', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { store_id, status } = req.query;
        let query = `SELECT * FROM waitinglist WHERE 1=1`;
        const params = [];

        if (store_id) { query += ` AND store_id = ?`; params.push(store_id); }
        if (status) { query += ` AND status = ?`; params.push(status); }

        query += ` ORDER BY created_at DESC`;

        db.all(query, params, (err, rows) => {
            if (err) {
                return res.status(500).json({ success: false, error: '查詢錯誤', message: err.message });
            }
            res.json({ success: true, data: rows || [] });
        });
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route PATCH /api/waitinglist/:id
 * @desc 更新候位狀態（員工權限）
 * @access Private/Staff
 */
router.patch('/:id', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { id } = req.params;
        const { status, table_number } = req.body;
        const validStatuses = ['waiting', 'contacted', 'confirmed', 'arrived', 'cancelled'];

        if (!validStatuses.includes(status)) {
            return res.status(400).json({ success: false, error: '狀態值無效' });
        }

        db.get(`SELECT * FROM waitinglist WHERE id = ?`, [id], (err, item) => {
            if (err) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });

            const body = { status };
            if (table_number) body.table_number = table_number;

            if (!item) {
                // 本地冇 record→ 只 forward 去阿里雲
                forwardToAliyun('PATCH', `/api/waitinglist/${id}`, body)
                    .then(result => res.json(result))
                    .catch(e => res.status(502).json({ success: false, error: '無法連線阿里雲', message: e.message }));
                return;
            }

            // 本地有 record→ update本地 + forward阿里雲
            let sql = `UPDATE waitinglist SET status = ?, updated_at = datetime('now', '+8 hours')`;
            let params = [status];
            if (table_number !== undefined) {
                sql += `, table_number = ?`;
                params.push(table_number);
            }
            sql += ` WHERE id = ?`;
            params.push(id);

            db.run(sql, params, function(updateErr) {
                if (updateErr) {
                    return res.status(500).json({ success: false, error: '更新失敗', message: updateErr.message });
                }
                forwardToAliyun('PATCH', `/api/waitinglist/${id}`, body)
                    .catch(e => console.error('forward waitinglist status to Aliyun failed:', e.message));
                res.json({ success: true, data: { id, status } });
            });
        });
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route POST /api/waitinglist/:id/notify
 * @desc 致電客人：WhatsApp + 語音通話
 * @access Private/Staff
 */
router.post('/:id/notify', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { id } = req.params;

        db.get(`SELECT * FROM waitinglist WHERE id = ?`, [id], async (err, item) => {
            if (err) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });

            // 本地冇記錄 → forward 去阿里雲
            if (!item) {
                try {
                    const result = await forwardToAliyun('POST', `/api/waitinglist/${id}/notify`, null);
                    if (result && result.success) {
                        db.run(`UPDATE aliyun_waitinglist_cache SET status = 'contacted', updated_at = ? WHERE id = ?`, [new Date(Date.now() + 8*60*60*1000).toISOString().replace('Z', ''), id]);
                        db.run(`INSERT OR REPLACE INTO waitinglist (id, store_id, adults, children, phone, notes, lang, status, ref_number, created_at, updated_at) SELECT id, store_id, adults, children, phone, notes, lang, 'contacted', ref_number, created_at, ? FROM aliyun_waitinglist_cache WHERE id = ?`, [new Date(Date.now() + 8*60*60*1000).toISOString().replace('Z', ''), id]);
                        return res.json(result);
                    }
                } catch (e) {
                    return res.status(502).json({ success: false, error: '無法連線阿里雲', message: e.message });
                }
            }

            const storeNames = { 'store_1': '荃灣店', 'store_2': '尖沙咀店', 'store_3': '旺角店', 'store_4': '銅鑼灣店' };
            const storeName = storeNames[item.store_id] || item.store_id;
            const lang = item.lang || 'zh-TW';

            // 標記為已聯絡
            db.run(`UPDATE waitinglist SET status = 'contacted', updated_at = ? WHERE id = ?`,
                [new Date(Date.now() + 8*60*60*1000).toISOString().replace('Z', ''), id]);

            // 並行發送 WhatsApp + 打電話
            const results = await Promise.allSettled([
                sendWhatsApp(item.phone, item.store_id, storeName, lang, item.id),
                makePhoneCall(item.phone, item.store_id, storeName, lang)
            ]);

            console.log(`通知結果 - WhatsApp: ${results[0].status}, 語音: ${results[1].status}`);

            res.json({
                success: true,
                message: '已致電客人',
                data: {
                    whatsapp: results[0].status === 'fulfilled',
                    phoneCall: results[1].status === 'fulfilled'
                }
            });
        });
    } catch (error) {
        console.error('致電錯誤:', error);
        res.status(500).json({ success: false, error: '致電失敗', message: error.message });
    }
});

/**
 * @route POST /api/waitinglist/:id/call
 * @desc 再致電（只打電話，唔 send WhatsApp）
 * @access Private/Staff
 */
router.post('/:id/call', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { id } = req.params;
        db.get(`SELECT * FROM waitinglist WHERE id = ?`, [id], async (err, item) => {
            if (err) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });

            // 本地冇記錄 → forward 去阿里雲
            if (!item) {
                try {
                    const result = await forwardToAliyun('POST', `/api/waitinglist/${id}/call`, null);
                    if (result && result.success) {
                        db.run(`UPDATE aliyun_waitinglist_cache SET status = 'contacted', updated_at = ? WHERE id = ?`, [new Date(Date.now() + 8*60*60*1000).toISOString().replace('Z', ''), id]);
                        db.run(`INSERT OR REPLACE INTO waitinglist (id, store_id, adults, children, phone, notes, lang, status, ref_number, created_at, updated_at) SELECT id, store_id, adults, children, phone, notes, lang, 'contacted', ref_number, created_at, ? FROM aliyun_waitinglist_cache WHERE id = ?`, [new Date(Date.now() + 8*60*60*1000).toISOString().replace('Z', ''), id]);
                        return res.json(result);
                    }
                } catch (e) {
                    return res.status(502).json({ success: false, error: '無法連線阿里雲', message: e.message });
                }
            }

            const storeNames = { 'store_1': '荃灣店', 'store_2': '尖沙咀店', 'store_3': '旺角店', 'store_4': '銅鑼灣店' };
            const storeName = storeNames[item.store_id] || item.store_id;
            const lang = item.lang || 'zh-TW';

            // 更新 updated_at 等 timer 重新計
            db.run(`UPDATE waitinglist SET updated_at = ? WHERE id = ?`,
                [new Date(Date.now() + 8*60*60*1000).toISOString().replace('Z', ''), id]);

            // 只打電話
            const result = await makePhoneCall(item.phone, item.store_id, storeName, lang).catch(e => e);

            res.json({
                success: true,
                message: '已再次致電客人',
                data: { phoneCall: true }
            });
        });
    } catch (error) {
        console.error('再致電錯誤:', error);
        res.status(500).json({ success: false, error: '再致電失敗', message: error.message });
    }
});

module.exports = router;
