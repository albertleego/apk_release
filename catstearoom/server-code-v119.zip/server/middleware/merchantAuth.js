/**
 * merchantAuth.js — Merchant 登入「第一道大門」（BACKEND 最外層額外閘）
 *
 * 概念：每個 merchant server（BACKEND，阿里雲）喺員工登入之外，多一層屬於商家
 * 自己嘅大門。過閘先載入頁面；頁面內部員工(officer/admin)登入完全照舊（純額外一層）。
 *
 * 機制：httpOnly cookie `merchant_token`（記住 ~30 日）對應 sessions 表一條
 * role='merchant' 嘅 session。merchantGate 只攔「已知 HTML 文件」GET，無有效
 * cookie 就 redirect 去 /merchant-login。EDGE（平板）唔 mount 呢個 gate（runtime flag off）。
 *
 * 唔郁 server/middleware/auth.js：員工 auth（Bearer token / requireAdmin / sliding TTL）
 * 完全唔受影響；merchant session 唔 sliding（固定 30 日，避免每次 page load 縮短）。
 */
const { db } = require('../../database/db');

const MERCHANT_COOKIE = 'merchant_token';
// Merchant session 有效期（小時）：預設 720 = 30 日（「記住 1 個月」）
const MERCHANT_SESSION_HOURS = parseInt(process.env.MERCHANT_SESSION_HOURS || '720', 10);

// ── 極細 cookie header parser（repo 冇 cookie-parser，唔為咗一個 cookie 加 npm dep）──
function parseCookies(header) {
    const out = {};
    if (!header) return out;
    header.split(';').forEach((part) => {
        const idx = part.indexOf('=');
        if (idx === -1) return;
        const key = part.slice(0, idx).trim();
        let val = part.slice(idx + 1).trim();
        if (!key) return;
        try { val = decodeURIComponent(val); } catch (e) { /* 保留原值 */ }
        out[key] = val;
    });
    return out;
}

function getMerchantToken(req) {
    return parseCookies(req.headers.cookie)[MERCHANT_COOKIE] || null;
}

// DB 驗證：sessions JOIN employees，只認 role='merchant' + 未過期 + active
// cb(err, row) — row = { session_id, employee_id, username, full_name, role }
function validateMerchantToken(token, cb) {
    if (!token) return cb(null, null);
    db.get(
        `SELECT s.id AS session_id, e.id AS employee_id, e.username, e.full_name, e.role, e.is_active
           FROM sessions s JOIN employees e ON e.id = s.employee_id
          WHERE s.token = ? AND s.expires_at > ? AND e.role = 'merchant'`,
        [token, new Date().toISOString()],
        (err, row) => {
            if (err) return cb(err);
            if (!row || row.is_active !== 1) return cb(null, null);
            cb(null, row);
        }
    );
}

// ── Path classify（正表保護）：淨係「已知 HTML 文件」先閘，其餘全部放行 ──
const GATED_FOLDER_ROOTS = [
    '/entry-machine',
    '/cashier',
    '/vending-machine',
    '/exit-machine',
    '/group-booking',
    '/mc-report',
    '/merchant-account'
];
const HTML_RE = /\.html$/i;

function classifyPath(p) {
    // 單頁 entry
    if (p === '/' || p === '/admin-config') return 'gate';
    // 員工「顧客預約管理」都係後台 → 閘
    if (p === '/booking/manage.html') return 'gate';
    // 其餘 /booking/* = 客用（booking / waitinglist / mybooking / index）→ 唔閘
    if (p === '/booking' || p === '/booking/' || p.startsWith('/booking/')) return 'pass';
    // merchant-login 頁本身永遠唔 redirect（防 redirect 迴圈）
    if (p === '/merchant-login' || p.startsWith('/merchant-login/')) return 'pass';
    // 後台 folder roots：root 或 root/ 或 入面 .html → 閘；assets（.js/.css/...）放行
    for (let i = 0; i < GATED_FOLDER_ROOTS.length; i++) {
        const r = GATED_FOLDER_ROOTS[i];
        if (p === r || p === r + '/') return 'gate';
        if (p.startsWith(r + '/')) return HTML_RE.test(p) ? 'gate' : 'pass';
    }
    return 'pass';
}

// redirect 目標 sanitize：只准同一 origin 相對路徑
function sanitizeNextUrl(raw) {
    if (!raw) return null;
    const u = String(raw).trim();
    if (u.length > 500) return null;
    // 必須單個 '/' 開頭（排除 '//host'、'https://...' 等 open redirect）
    if (!/^\/(?!\/)/.test(u)) return null;
    // 唔准 backslash / CRLF
    if (/[\\\r\n]/.test(u)) return null;
    return u;
}

function redirectToMerchantLogin(req, res) {
    const next = sanitizeNextUrl(req.originalUrl || req.url) || '/';
    return res.redirect('/merchant-login?next=' + encodeURIComponent(next));
}

function clearMerchantCookie(res) {
    res.clearCookie(MERCHANT_COOKIE, { path: '/', httpOnly: true, sameSite: 'lax' });
}

function setMerchantCookie(res, token) {
    // secure 用 env 控制（預設 false 先測到 http://localhost:3002；production https 開 true）
    res.cookie(MERCHANT_COOKIE, token, {
        httpOnly: true,
        secure: process.env.MERCHANT_COOKIE_SECURE === 'true',
        sameSite: 'lax',
        maxAge: MERCHANT_SESSION_HOURS * 3600 * 1000 // ~30 日
    });
}

// ── Page gate middleware（只攔 HTML document GET）──
function merchantGate(req, res, next) {
    if (req.method !== 'GET') return next();
    if (classifyPath(req.path) !== 'gate') return next();

    const token = getMerchantToken(req);
    if (!token) return redirectToMerchantLogin(req, res);

    validateMerchantToken(token, (err, row) => {
        if (err || !row) {
            clearMerchantCookie(res);
            return redirectToMerchantLogin(req, res);
        }
        req.merchant = row; // { session_id, employee_id, username, full_name, role }
        next();
    });
}

// ── API middleware（讀 cookie，JSON 401）──
function requireMerchant(req, res, next) {
    const token = getMerchantToken(req);
    if (!token) {
        return res.status(401).json({ success: false, error: '未登入 merchant' });
    }
    validateMerchantToken(token, (err, row) => {
        if (err) {
            return res.status(500).json({ success: false, error: '驗證 merchant session 失敗' });
        }
        if (!row) {
            clearMerchantCookie(res);
            return res.status(401).json({ success: false, error: 'merchant session 無效或已過期' });
        }
        req.merchant = row;
        next();
    });
}

module.exports = {
    MERCHANT_COOKIE,
    MERCHANT_SESSION_HOURS,
    merchantSessionMs: () => MERCHANT_SESSION_HOURS * 3600 * 1000,
    parseCookies,
    getMerchantToken,
    validateMerchantToken,
    classifyPath,
    sanitizeNextUrl,
    merchantGate,
    requireMerchant,
    setMerchantCookie,
    clearMerchantCookie
};
