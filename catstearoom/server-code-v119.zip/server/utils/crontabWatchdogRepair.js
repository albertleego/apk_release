// ─── crontab / boot-script watchdog 自我修復（EDGE 平板專用，冪等 no-op）───
// 2026-09-07 crash-loop 實證（尖沙咀主機 c84faa97）：舊部署指南（TERMUX_DEPLOY_GUIDE.md）同
// fix-ssh-tunnel.sh 用 pgrep -f "node server/index.js" / "[n]ode server/index.js" 偵測 server 是否在跑。
// 但真 server 嘅 cmdline 係絕對路徑 `node /data/data/com.termux/files/home/server/index.js`
// （node 同路徑之間冇空格）→ pattern 對唔到 → watchdog 每分鐘 spawn 多餘 server →
// EADDRINUSE crash-loop（燒電 + 洗 log + 可能引致 HTTP hang 而漏寫客）。
// 正確 pattern：`[s]erver/index.js` —— 絕對/相對路徑都 match；[s] bracket 令 pgrep 唔會自匹配
// 自己個 shell（cmdline 顯示係 "[s]erver/index.js"，regex `[s]erver/index.js` 對唔上）。
// boot 時偵測舊 pattern，有先改寫（live crontab + ~/crontab.txt mirror + ~/.termux/boot/*.sh），
// 已正確就完全唔郁（冪等）。淨係真 Termux（/data/data/com.termux 存在）先會郁 —— dev PC /
// aliyun EDGE staging 一定 no-op。失敗唔阻啟動（caller 已 try/catch，呢度再兜一層）。
// generic 修復（master 同 catstearoom 平板都用同一套 Termux 部署）→ 理應 sync 返 master。
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const runtime = require('../config/runtime');

const TERMUX_ROOT = '/data/data/com.termux';
const TERMUX_BIN = TERMUX_ROOT + '/files/usr/bin';
const CRONTAB_BIN = TERMUX_BIN + '/crontab';
// 正確 watchdog 用 pattern；絕對/相對路徑都 match，且 pgrep 唔會自匹配
const GOOD_PATTERN = '[s]erver/index.js';
// 舊部署文件/腳本種落嘅錯誤 pattern（兩種寫法）
const BAD_PATTERNS = ['[n]ode server/index.js', 'node server/index.js'];
// 只會掂「watchdog 行」：有 pgrep -f + bash start_server.sh 先處理
const WATCHDOG_RE = /pgrep\s+-f/;
const START_RE = /bash\s+start_server\.sh/;

// 純函數：將 watchdog 行入面嘅舊 pattern 換成正確 pattern。冇舊 pattern → 原封不動（冪等）。
// 回傳 { content, changed, fixed }：changed = 有冇改到；fixed = 被改嘅 watchdog 行數量。
function normalizeWatchdogContent(content) {
    const lines = String(content == null ? '' : content).split(/\r?\n/);
    let fixed = 0;
    const out = lines.map((line) => {
        if (!WATCHDOG_RE.test(line) || !START_RE.test(line)) return line;
        let l = line;
        for (const bad of BAD_PATTERNS) {
            if (l.includes(bad)) {
                l = l.split(bad).join(GOOD_PATTERN);
                fixed += 1;
            }
        }
        return l;
    });
    return { content: out.join('\n'), changed: fixed > 0, fixed };
}

// 有冇任何 watchdog 行（用嚟決定使唔使 log）
function hasWatchdogLine(content) {
    return String(content || '').split(/\r?\n/).some((line) => START_RE.test(line) && WATCHDOG_RE.test(line));
}

function runCrontab(args) {
    const env = Object.assign({}, process.env, {
        PATH: TERMUX_BIN + ':' + (process.env.PATH || '')
    });
    const out = execFileSync(CRONTAB_BIN, args, {
        encoding: 'utf8',
        env,
        stdio: ['ignore', 'pipe', 'pipe'],
        timeout: 20000
    });
    return out || '';
}

function hupCrond() {
    try {
        execFileSync(TERMUX_BIN + '/sh', ['-c', 'pkill -HUP -x crond 2>/dev/null; true'], {
            stdio: 'ignore',
            timeout: 10000
        });
    } catch (e) {
        // 冇 crond 唔緊要；下次 crond 起動會讀返已修正嘅 crontab
    }
}

// 原子寫入（tmp + rename），避免 crash-loop 期間兩個 server process 同時寫而整爛檔
function atomicWrite(file, content) {
    const tmp = file + '.repair.tmp';
    fs.writeFileSync(tmp, content);
    fs.renameSync(tmp, file);
}

// 修正 live crontab + ~/crontab.txt mirror。回傳 'fixed' | 'clean' | 'none'
function repairCrontab() {
    const home = path.resolve(__dirname, '../..');
    let cur = '';
    try {
        cur = runCrontab(['-l']);
    } catch (e) {
        // crontab -l exit != 0（例如「no crontab for user」）→ 當冇 crontab
        cur = '';
    }
    const watch = hasWatchdogLine(cur);
    const res = normalizeWatchdogContent(cur);
    if (!res.changed) {
        return watch ? 'clean' : 'none';
    }
    // 經 temp file 裝入 spool（crontab 指令本身原子），再同步 mirror
    const tmpInstall = path.join(home, '.watchdog-repair.cron');
    fs.writeFileSync(tmpInstall, res.content);
    try {
        runCrontab([tmpInstall]);
    } finally {
        try { fs.unlinkSync(tmpInstall); } catch (e) { /* 唔緊要 */ }
    }
    try { atomicWrite(path.join(home, 'crontab.txt'), res.content); } catch (e) { /* mirror 寫唔到唔阻 crontab */ }
    hupCrond();
    return 'fixed';
}

// 修正 ~/.termux/boot/*.sh 入面嘅 watchdog 行（fix-ssh-tunnel.sh 種落嘅 boot-script 變體）。
// 回傳 { file, fixed }[]（只回有 watchdog 或改咗嘅檔）
function repairBootScripts() {
    const home = path.resolve(__dirname, '../..');
    const bootDir = path.join(home, '.termux', 'boot');
    if (!fs.existsSync(bootDir)) return [];
    const results = [];
    let names = [];
    try { names = fs.readdirSync(bootDir); } catch (e) { return []; }
    for (const name of names) {
        if (!name.endsWith('.sh')) continue;
        const f = path.join(bootDir, name);
        let src = '';
        try { src = fs.readFileSync(f, 'utf8'); } catch (e) { continue; }
        const res = normalizeWatchdogContent(src);
        if (!res.changed) continue; // 冇舊 pattern → 唔郁
        try { atomicWrite(f, res.content); } catch (e) { continue; }
        results.push({ file: f, fixed: res.fixed });
    }
    return results;
}

// 主入口：EDGE 平板 boot 時呼叫（server/index.js module-load 期）。冪等、失敗唔阻啟動。
function repairCrontabWatchdog() {
    if (!runtime.isEdge) return; // BACKEND（阿里雲）唔郁
    if (!fs.existsSync(TERMUX_ROOT)) return; // 唔係真 Termux（dev PC / aliyun EDGE staging）→ 一定 no-op

    let result = 'none';
    if (fs.existsSync(CRONTAB_BIN)) {
        try { result = repairCrontab(); } catch (e) {
            console.warn('[watchdog-repair] crontab 檢查失敗（唔阻啟動）:', e.message);
        }
    }
    let bootFixed = [];
    try { bootFixed = repairBootScripts(); } catch (e) {
        console.warn('[watchdog-repair] boot script 檢查失敗（唔阻啟動）:', e.message);
    }

    if (result === 'fixed') {
        console.log(`[watchdog-repair] ✅ crontab watchdog pattern 已由舊版修正為 "${GOOD_PATTERN}"（含 ~/crontab.txt mirror，crond 已 HUP）`);
    } else if (result === 'clean') {
        console.log(`[watchdog-repair] ℹ️ crontab watchdog 已係正確 pattern（no-op）`);
    }
    for (const r of bootFixed) {
        console.log(`[watchdog-repair] ✅ boot script ${r.file} watchdog pattern 已修正（${r.fixed} 行）`);
    }
}

module.exports = { repairCrontabWatchdog, normalizeWatchdogContent, hasWatchdogLine, GOOD_PATTERN, BAD_PATTERNS };
