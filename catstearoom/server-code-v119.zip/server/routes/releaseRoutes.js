const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const authMiddleware = require('../middleware/auth');
const runtime = require('../config/runtime');

// ─────────────────────────────────────────────────────────────
// Release hosting（BACKEND 專用）
// 取代公開 GitHub apk_release：以 API key（x-api-key）保護 APK / server zip / 更新清單。
// 掛載於 /api/release（置於 /api/ 之下，沿用 nginx 既有「/api/ 豁免 Basic Auth」規則）。
// 檔案目錄鏡像 apk_release repo 結構：root + <merchant>/
// ─────────────────────────────────────────────────────────────

// 全部路由都需要認證（x-api-key，涵蓋 ALIYUN_API_KEY_OLD 以利金鑰輪換過渡）
router.use(authMiddleware.authenticate);

const MERCHANT_RE = /^[a-z0-9_-]{0,32}$/;
const FILE_RE = /^[A-Za-z0-9._-]{1,128}\.(apk|zip)$/;

function releaseBase() {
    return path.resolve(runtime.releaseBaseDir());
}

// 解析路徑並確保不會逃出 release 目錄
function resolveFile(merchant, name) {
    const base = releaseBase();
    const rel = merchant ? path.join(merchant, name) : name;
    const full = path.resolve(base, rel);
    if (full !== base && !full.startsWith(base + path.sep)) return null;
    return full;
}

function sendManifest(res, merchant, fileName) {
    if (!MERCHANT_RE.test(merchant)) {
        return res.status(400).json({ success: false, error: '不合法的 merchant 參數' });
    }
    const full = resolveFile(merchant, fileName);
    if (!full || !fs.existsSync(full)) {
        return res.status(404).json({ success: false, error: '找不到更新清單' });
    }
    try {
        const json = JSON.parse(fs.readFileSync(full, 'utf8'));
        res.setHeader('Cache-Control', 'public, max-age=300');
        return res.json(json);
    } catch (e) {
        return res.status(500).json({ success: false, error: '更新清單格式錯誤', message: e.message });
    }
}

// GET /api/release/manifest?merchant=<slug>  → latest-version.json
router.get('/manifest', (req, res) => {
    const merchant = String(req.query.merchant || '').trim();
    return sendManifest(res, merchant, 'latest-version.json');
});

// GET /api/release/manifest-entry?merchant=<slug>  → latest-version-entry.json
router.get('/manifest-entry', (req, res) => {
    const merchant = String(req.query.merchant || '').trim();
    return sendManifest(res, merchant, 'latest-version-entry.json');
});

// GET /api/release/file?merchant=<slug>&name=<file>  → 串流 APK / server zip
router.get('/file', (req, res) => {
    const merchant = String(req.query.merchant || '').trim();
    const name = String(req.query.name || '').trim();
    if (!MERCHANT_RE.test(merchant) || !FILE_RE.test(name)) {
        return res.status(400).json({ success: false, error: '不合法的參數' });
    }
    const full = resolveFile(merchant, name);
    if (!full || !fs.existsSync(full)) {
        return res.status(404).json({ success: false, error: '找不到檔案' });
    }
    const ext = path.extname(full).toLowerCase();
    res.setHeader('Content-Type', ext === '.apk' ? 'application/vnd.android.package-archive' : 'application/zip');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Length', fs.statSync(full).size);
    const stream = fs.createReadStream(full);
    stream.on('error', () => { if (!res.headersSent) res.status(500).end(); else res.end(); });
    stream.pipe(res);
});

module.exports = router;
