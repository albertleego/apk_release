const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');
const storeAwareMiddleware = require('../middleware/store-aware');

/**
 * @route GET /api/employees
 * @desc 獲取所有員工（僅管理員）
 * @access Private/Admin
 */
router.get('/', authMiddleware.authenticate, authMiddleware.requireAdmin, (req, res) => {
    try {
        const { search, role, is_active } = req.query;
        const { employee } = req;

        // 構建基礎查詢
        let query = `SELECT e.id, e.username, e.password_hash, e.full_name, e.role, e.email, e.phone, e.store_id,
                     e.is_active, e.last_login, e.created_at, s.store_name
                     FROM employees e
                     LEFT JOIN stores s ON e.store_id = s.id
                     WHERE 1=1`;
        const params = [];

        // 添加分店過濾：總部管理員（admin角色，store_id為NULL）可以查看所有員工
        // 分店管理員（admin角色，有store_id）只能查看自己分店的員工
        if (employee.role === 'admin' && employee.store_id) {
            query += ` AND e.store_id = ?`;
            params.push(employee.store_id);
        }
        // 總部管理員（employee.store_id為NULL）不需要添加store_id過濾，可以查看所有員工

        // 添加篩選條件
        if (search) {
            query += ` AND (username LIKE ? OR full_name LIKE ? OR email LIKE ?)`;
            const searchTerm = `%${search}%`;
            params.push(searchTerm, searchTerm, searchTerm);
        }

        if (role) {
            query += ` AND role = ?`;
            params.push(role);
        }

        if (is_active !== undefined) {
            query += ` AND is_active = ?`;
            params.push(is_active === 'true' ? 1 : 0);
        }

        query += ` ORDER BY e.created_at DESC`;

        db.all(query, params, (err, employees) => {
            if (err) {
                console.error('查詢員工列表錯誤:', err);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: err.message
                });
            }

            res.json({
                success: true,
                data: employees,
                count: employees.length
            });
        });
    } catch (error) {
        console.error('獲取員工列表錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取員工列表失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/employees/:id
 * @desc 獲取特定員工信息（僅管理員或自己）
 * @access Private
 */
router.get('/:id', authMiddleware.authenticate, (req, res) => {
    try {
        const { id } = req.params;
        const { employee } = req;

        // 檢查權限：管理員可以查看任何員工，普通員工只能查看自己
        if (employee.role !== 'admin' && employee.id !== id) {
            return res.status(403).json({
                success: false,
                error: '權限不足',
                message: '您只能查看自己的信息'
            });
        }

        db.get(
            `SELECT e.id, e.username, e.full_name, e.role, e.email, e.phone, e.store_id,
             e.is_active, e.last_login, e.created_at, s.store_name
             FROM employees e
             LEFT JOIN stores s ON e.store_id = s.id
             WHERE e.id = ?`,
            [id],
            (err, employeeData) => {
                if (err) {
                    console.error('查詢員工錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                if (!employeeData) {
                    return res.status(404).json({
                        success: false,
                        error: '員工不存在',
                        message: '找不到指定的員工'
                    });
                }

                // 分店權限檢查：分店管理員只能查看自己分店的員工
                if (employee.role === 'admin' && employee.store_id && employeeData.store_id !== employee.store_id) {
                    return res.status(403).json({
                        success: false,
                        error: '分店權限不足',
                        message: '您只能查看自己分店的員工信息'
                    });
                }

                res.json({
                    success: true,
                    data: employeeData
                });
            }
        );
    } catch (error) {
        console.error('獲取員工信息錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取員工信息失敗',
            message: error.message
        });
    }
});

/**
 * @route POST /api/employees
 * @desc 創建新員工（僅管理員）
 * @access Private/Admin
 */
router.post('/', authMiddleware.authenticate, authMiddleware.requireAdmin, async (req, res) => {
    try {
        const { username, password, full_name, role, email, phone, store_id } = req.body;
        const ipAddress = req.ip || req.connection.remoteAddress;

        console.log('創建新員工:', { username, full_name, role });

        // 驗證必填字段
        if (!username || !password || !full_name || !role) {
            return res.status(400).json({
                success: false,
                error: '缺少必要字段',
                message: '請提供用戶名、密碼、姓名和角色'
            });
        }

        // 驗證角色
        if (!['admin', 'staff', 'merchant'].includes(role)) {
            return res.status(400).json({
                success: false,
                error: '無效的角色',
                message: '角色必須是 "admin"、"staff" 或 "merchant"'
            });
        }

        // merchant 帳戶（「第一道大門」帳）：只准總部管理員（store_id 為 NULL）建立，
        // 強制 store_id=NULL（總部層級，唔綁分店）。第一個 merchant 帳由總部 admin 用 API/SQL 起。
        if (role === 'merchant') {
            if (req.employee.store_id) {
                return res.status(403).json({
                    success: false,
                    error: '權限不足',
                    message: '只有總部管理員可以建立 merchant 帳戶'
                });
            }
            if (store_id) {
                return res.status(400).json({
                    success: false,
                    error: '無效的分店',
                    message: 'merchant 帳戶唔可以指定分店（總部層級）'
                });
            }
            return checkUsername();
        }

        // 驗證store_id：staff角色必須指定分店，admin角色可為NULL
        if (role === 'staff' && !store_id) {
            return res.status(400).json({
                success: false,
                error: '缺少分店',
                message: '員工角色必須指定所屬分店'
            });
        }

        // 如果提供了store_id，驗證分店存在
        if (store_id) {
            db.get(
                `SELECT id FROM stores WHERE id = ?`,
                [store_id],
                (err, store) => {
                    if (err) {
                        console.error('檢查分店錯誤:', err);
                        return res.status(500).json({
                            success: false,
                            error: '服務器錯誤',
                            message: err.message
                        });
                    }

                    if (!store) {
                        return res.status(400).json({
                            success: false,
                            error: '無效的分店',
                            message: '指定的分店不存在'
                        });
                    }

                    // 分店驗證通過，繼續檢查用戶名
                    checkUsername();
                }
            );
        } else {
            // store_id為NULL，直接檢查用戶名
            checkUsername();
        }

        function checkUsername() {
        // 檢查用戶名是否已存在
        db.get(
            `SELECT id FROM employees WHERE LOWER(username) = LOWER(?)`,
            [username],
            async (err, existingEmployee) => {
                if (err) {
                    console.error('檢查用戶名錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                if (existingEmployee) {
                    return res.status(400).json({
                        success: false,
                        error: '用戶名已存在',
                        message: '該用戶名已被使用，請選擇其他用戶名'
                    });
                }

                // 哈希密碼
                const saltRounds = 10;
                const passwordHash = await bcrypt.hash(password, saltRounds);

                // 創建員工記錄
                const employeeId = uuidv4();
                const now = new Date().toISOString();

                db.run(
                    `INSERT INTO employees (id, username, password_hash, full_name, role, email, phone, store_id, created_at, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [
                        employeeId,
                        username,
                        passwordHash,
                        full_name,
                        role,
                        email || null,
                        phone || null,
                        store_id || null,
                        now,
                        now
                    ],
                    function (insertErr) {
                        if (insertErr) {
                            console.error('創建員工錯誤:', insertErr);
                            return res.status(500).json({
                                success: false,
                                error: '服務器錯誤',
                                message: insertErr.message
                            });
                        }

                        // 創建審計日誌
                        authMiddleware.createAuditLog(req.employee.id, 'employee_create', `創建員工: ${username} (${full_name})`, ipAddress);

                        // 獲取創建的員工信息（排除密碼哈希）
                        db.get(
                            `SELECT id, username, full_name, role, email, phone, store_id, is_active, created_at
                             FROM employees WHERE id = ?`,
                            [employeeId],
                            (selectErr, newEmployee) => {
                                if (selectErr) {
                                    console.error('獲取新員工錯誤:', selectErr);
                                }

                                res.status(201).json({
                                    success: true,
                                    message: '員工創建成功',
                                    data: newEmployee || { id: employeeId, username, full_name, role }
                                });
                            }
                        );
                    }
                );
            }
        );
    }
} catch (error) {
        console.error('創建員工錯誤:', error);
        res.status(500).json({
            success: false,
            error: '創建員工失敗',
            message: error.message
        });
    }
});

/**
 * @route PUT /api/employees/:id
 * @desc 更新員工信息（僅管理員）
 * @access Private/Admin
 */
router.put('/:id', authMiddleware.authenticate, authMiddleware.requireAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const { username, full_name, role, email, phone, is_active, store_id } = req.body;
        const ipAddress = req.ip || req.connection.remoteAddress;

        console.log('更新員工:', { id, username, full_name, role, store_id });

        // 檢查員工是否存在
        db.get(
            `SELECT id, username, store_id FROM employees WHERE id = ?`,
            [id],
            async (err, existingEmployee) => {
                if (err) {
                    console.error('檢查員工錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                if (!existingEmployee) {
                    return res.status(404).json({
                        success: false,
                        error: '員工不存在',
                        message: '找不到指定的員工'
                    });
                }

                // 分店權限檢查：分店管理員只能修改自己分店的員工
                if (req.employee.role === 'admin' && req.employee.store_id && existingEmployee.store_id !== req.employee.store_id) {
                    return res.status(403).json({
                        success: false,
                        error: '分店權限不足',
                        message: '您只能修改自己分店的員工信息'
                    });
                }

                // 如果提供了新用戶名，檢查是否已被其他員工使用
                if (username && username !== existingEmployee.username) {
                    db.get(
                        `SELECT id FROM employees WHERE LOWER(username) = LOWER(?) AND id != ?`,
                        [username, id],
                        (usernameErr, otherEmployee) => {
                            if (usernameErr) {
                                console.error('檢查用戶名錯誤:', usernameErr);
                                return res.status(500).json({
                                    success: false,
                                    error: '服務器錯誤',
                                    message: usernameErr.message
                                });
                            }

                            if (otherEmployee) {
                                return res.status(400).json({
                                    success: false,
                                    error: '用戶名已存在',
                                    message: '該用戶名已被其他員工使用'
                                });
                            }

                            // 繼續更新
                            updateEmployee();
                        }
                    );
                } else {
                    updateEmployee();
                }

                async function updateEmployee() {
                    // 首先獲取當前員工的完整信息以進行驗證
                    db.get(
                        `SELECT role, store_id FROM employees WHERE id = ?`,
                        [id],
                        async (err, currentEmployee) => {
                            if (err) {
                                console.error('查詢當前員工錯誤:', err);
                                return res.status(500).json({
                                    success: false,
                                    error: '服務器錯誤',
                                    message: err.message
                                });
                            }

                            if (!currentEmployee) {
                                return res.status(404).json({
                                    success: false,
                                    error: '員工不存在',
                                    message: '找不到指定的員工'
                                });
                            }

                            // 驗證store_id：如果角色是staff或將要更改為staff，則需要store_id
                            console.log('角色/分店驗證:', { role, currentRole: currentEmployee.role, store_id, currentStoreId: currentEmployee.store_id });
                            const targetRole = role !== undefined ? role : currentEmployee.role;
                            const targetStoreId = store_id !== undefined ? store_id : currentEmployee.store_id;

                            if (targetRole === 'staff' && !targetStoreId) {
                                return res.status(400).json({
                                    success: false,
                                    error: '缺少分店',
                                    message: '員工角色必須指定所屬分店'
                                });
                            }

                            // merchant 帳戶唔可以綁分店（維持 store_id = NULL 不變式）
                            // 注意：分店管理員改 merchant 已喺上面 367 行分店檢查擋走；呢度擋總部 admin 誤綁店
                            if (targetRole === 'merchant' && store_id) {
                                return res.status(400).json({
                                    success: false,
                                    error: '無效的分店',
                                    message: 'merchant 帳戶唔可以指定分店（總部層級）'
                                });
                            }

                            // 如果提供了store_id，驗證分店存在
                            console.log('store_id驗證:', { store_id, defined: store_id !== undefined, truthy: !!store_id });
                            if (store_id !== undefined && store_id) {
                                db.get(
                                    `SELECT id FROM stores WHERE id = ?`,
                                    [store_id],
                                    (storeErr, store) => {
                                        if (storeErr) {
                                            console.error('檢查分店錯誤:', storeErr);
                                            return res.status(500).json({
                                                success: false,
                                                error: '服務器錯誤',
                                                message: storeErr.message
                                            });
                                        }

                                        if (!store) {
                                            return res.status(400).json({
                                                success: false,
                                                error: '無效的分店',
                                                message: '指定的分店不存在'
                                            });
                                        }

                                        // 分店驗證通過，繼續構建更新語句
                                        buildUpdate();
                                    }
                                );
                            } else {
                                // 沒有提供store_id或store_id為null，直接構建更新語句
                                console.log('跳過分店驗證，直接調用buildUpdate');
                                buildUpdate();
                            }

                            function buildUpdate() {
                                // 構建更新語句
                                console.log('buildUpdate被調用，store_id:', store_id);
                                const updates = [];
                                const params = [];

                    if (username !== undefined) {
                        updates.push('username = ?');
                        params.push(username);
                    }

                    if (full_name !== undefined) {
                        updates.push('full_name = ?');
                        params.push(full_name);
                    }

                    if (role !== undefined) {
                        if (!['admin', 'staff', 'merchant'].includes(role)) {
                            return res.status(400).json({
                                success: false,
                                error: '無效的角色',
                                message: '角色必須是 "admin"、"staff" 或 "merchant"'
                            });
                        }
                        // merchant 帳戶只准總部管理員處理（分店管理員已喺上面 367 行分店檢查擋走）
                        if (role === 'merchant' && req.employee.store_id) {
                            return res.status(403).json({
                                success: false,
                                error: '權限不足',
                                message: '只有總部管理員可以處理 merchant 帳戶'
                            });
                        }
                        updates.push('role = ?');
                        params.push(role);
                        // merchant 帳戶強制 store_id = NULL（總部層級；staff→merchant 升級時順手解除綁店）
                        if (role === 'merchant') {
                            updates.push('store_id = NULL');
                        }
                    }

                    if (email !== undefined) {
                        updates.push('email = ?');
                        params.push(email || null);
                    }

                    if (phone !== undefined) {
                        updates.push('phone = ?');
                        params.push(phone || null);
                    }

                    if (store_id !== undefined) {
                        console.log('添加store_id到更新語句:', { store_id, paramValue: store_id || null });
                        updates.push('store_id = ?');
                        params.push(store_id || null);
                    }

                    if (is_active !== undefined) {
                        updates.push('is_active = ?');
                        params.push(is_active ? 1 : 0);
                    }

                    // 添加更新時間
                    updates.push('updated_at = ?');
                    params.push(new Date().toISOString());

                    // 添加WHERE條件
                    params.push(id);

                    console.log('更新字段:', updates);
                    if (updates.length === 1) { // 只有updated_at
                        return res.status(400).json({
                            success: false,
                            error: '無效的更新',
                            message: '沒有提供可更新的字段'
                        });
                    }

                    const updateQuery = `UPDATE employees SET ${updates.join(', ')} WHERE id = ?`;
                    console.log('執行更新查詢:', { updateQuery, params });

                    db.run(updateQuery, params, function (updateErr) {
                        if (updateErr) {
                            console.error('更新員工錯誤:', updateErr);
                            return res.status(500).json({
                                success: false,
                                error: '服務器錯誤',
                                message: updateErr.message
                            });
                        }

                        console.log('更新結果:', { changes: this.changes, lastID: this.lastID });
                        if (this.changes === 0) {
                            return res.status(404).json({
                                success: false,
                                error: '員工不存在',
                                message: '找不到指定的員工'
                            });
                        }

                        // 創建審計日誌
                        authMiddleware.createAuditLog(req.employee.id, 'employee_update', `更新員工: ${existingEmployee.username}`, ipAddress);

                        // 獲取更新後的員工信息
                        db.get(
                            `SELECT e.id, e.username, e.full_name, e.role, e.email, e.phone, e.store_id,
                             e.is_active, e.last_login, e.created_at, s.store_name
                             FROM employees e
                             LEFT JOIN stores s ON e.store_id = s.id
                             WHERE e.id = ?`,
                            [id],
                            (selectErr, updatedEmployee) => {
                                if (selectErr) {
                                    console.error('獲取更新後員工錯誤:', selectErr);
                                }

                                res.json({
                                    success: true,
                                    message: '員工更新成功',
                                    data: updatedEmployee || { id }
                                });
                            }
                        );
                    });
                }
            }
        );
        }
    });
} catch (error) {
        console.error('更新員工錯誤:', error);
        res.status(500).json({
            success: false,
            error: '更新員工失敗',
            message: error.message
        });
    }
});

/**
 * @route DELETE /api/employees/:id
 * @desc 刪除員工（僅管理員）
 * @access Private/Admin
 */
router.delete('/:id', authMiddleware.authenticate, authMiddleware.requireAdmin, (req, res) => {
    try {
        const { id } = req.params;
        const ipAddress = req.ip || req.connection.remoteAddress;

        console.log('刪除員工:', { id });

        // 檢查員工是否存在
        db.get(
            `SELECT username, store_id FROM employees WHERE id = ?`,
            [id],
            (err, employee) => {
                if (err) {
                    console.error('檢查員工錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                if (!employee) {
                    return res.status(404).json({
                        success: false,
                        error: '員工不存在',
                        message: '找不到指定的員工'
                    });
                }

                // 分店權限檢查：分店管理員只能刪除自己分店的員工
                if (req.employee.role === 'admin' && req.employee.store_id && employee.store_id !== req.employee.store_id) {
                    return res.status(403).json({
                        success: false,
                        error: '分店權限不足',
                        message: '您只能刪除自己分店的員工信息'
                    });
                }

                // 檢查是否嘗試刪除自己
                if (req.employee.id === id) {
                    return res.status(400).json({
                        success: false,
                        error: '無法刪除自己',
                        message: '您不能刪除自己的帳戶'
                    });
                }

                // 刪除員工（實際應用中可能改為標記為停用）
                db.run(
                    `DELETE FROM employees WHERE id = ?`,
                    [id],
                    function (deleteErr) {
                        if (deleteErr) {
                            console.error('刪除員工錯誤:', deleteErr);
                            return res.status(500).json({
                                success: false,
                                error: '服務器錯誤',
                                message: deleteErr.message
                            });
                        }

                        if (this.changes === 0) {
                            return res.status(404).json({
                                success: false,
                                error: '員工不存在',
                                message: '找不到指定的員工'
                            });
                        }

                        // 刪除相關會話
                        db.run(
                            `DELETE FROM sessions WHERE employee_id = ?`,
                            [id],
                            (sessionErr) => {
                                if (sessionErr) console.error('刪除會話錯誤:', sessionErr);
                            }
                        );

                        // 創建審計日誌
                        authMiddleware.createAuditLog(req.employee.id, 'employee_delete', `刪除員工: ${employee.username}`, ipAddress);

                        res.json({
                            success: true,
                            message: '員工刪除成功'
                        });
                    }
                );
            }
        );
    } catch (error) {
        console.error('刪除員工錯誤:', error);
        res.status(500).json({
            success: false,
            error: '刪除員工失敗',
            message: error.message
        });
    }
});

/**
 * @route PUT /api/employees/:id/password
 * @desc 修改密碼（管理員可修改他人密碼，員工只能修改自己的密碼）
 * @access Private
 */
router.put('/:id/password', authMiddleware.authenticate, async (req, res) => {
    try {
        const { id } = req.params;
        const { current_password, new_password } = req.body;
        const { employee } = req;
        const ipAddress = req.ip || req.connection.remoteAddress;

        console.log('修改密碼:', { id });

        // 驗證新密碼
        if (!new_password || new_password.length < 6) {
            return res.status(400).json({
                success: false,
                error: '無效的密碼',
                message: '新密碼必須至少6個字符'
            });
        }

        // 檢查權限：管理員可以直接修改，普通員工需要提供當前密碼
        if (employee.role !== 'admin' && employee.id !== id) {
            return res.status(403).json({
                success: false,
                error: '權限不足',
                message: '您只能修改自己的密碼'
            });
        }

        // 獲取員工當前信息
        db.get(
            `SELECT id, password_hash FROM employees WHERE id = ?`,
            [id],
            async (err, targetEmployee) => {
                if (err) {
                    console.error('查詢員工錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                if (!targetEmployee) {
                    return res.status(404).json({
                        success: false,
                        error: '員工不存在',
                        message: '找不到指定的員工'
                    });
                }

                // 如果是普通員工修改自己的密碼，需要驗證當前密碼
                if (employee.role !== 'admin' && employee.id === id) {
                    if (!current_password) {
                        return res.status(400).json({
                            success: false,
                            error: '缺少當前密碼',
                            message: '請提供當前密碼以驗證身份'
                        });
                    }

                    const isPasswordValid = await bcrypt.compare(current_password, targetEmployee.password_hash);
                    if (!isPasswordValid) {
                        // 創建審計日誌（密碼驗證失敗）
                        authMiddleware.createAuditLog(employee.id, 'password_change_failed', '當前密碼不正確', ipAddress);

                        return res.status(401).json({
                            success: false,
                            error: '密碼不正確',
                            message: '當前密碼不正確'
                        });
                    }
                }

                // 哈希新密碼
                const saltRounds = 10;
                const newPasswordHash = await bcrypt.hash(new_password, saltRounds);

                // 更新密碼
                db.run(
                    `UPDATE employees SET password_hash = ?, updated_at = ? WHERE id = ?`,
                    [newPasswordHash, new Date().toISOString(), id],
                    function (updateErr) {
                        if (updateErr) {
                            console.error('更新密碼錯誤:', updateErr);
                            return res.status(500).json({
                                success: false,
                                error: '服務器錯誤',
                                message: updateErr.message
                            });
                        }

                        if (this.changes === 0) {
                            return res.status(404).json({
                                success: false,
                                error: '員工不存在',
                                message: '找不到指定的員工'
                            });
                        }

                        // 刪除該員工的所有會話（強制重新登入）
                        db.run(
                            `DELETE FROM sessions WHERE employee_id = ?`,
                            [id],
                            (sessionErr) => {
                                if (sessionErr) console.error('刪除會話錯誤:', sessionErr);
                            }
                        );

                        // 創建審計日誌（密碼修改成功）
                        authMiddleware.createAuditLog(employee.id, 'password_change', '密碼修改成功', ipAddress);

                        res.json({
                            success: true,
                            message: '密碼修改成功，請重新登入'
                        });
                    }
                );
            }
        );
    } catch (error) {
        console.error('修改密碼錯誤:', error);
        res.status(500).json({
            success: false,
            error: '修改密碼失敗',
            message: error.message
        });
    }
});

module.exports = router;