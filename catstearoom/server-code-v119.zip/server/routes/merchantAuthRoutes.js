/**
 * merchantAuthRoutes.js — Merchant 登入「第一道大門」API（BACKEND 專用）
 *
 * 呢啲 route 淨係喺 runtime.merchantGate() on 時先 mount（見 server/index.js）。
 * merchant = employees 表入面 role='merchant' 嘅帳（store_id NULL = 總部層級），
 * 帳密同員工一樣 bcrypt 存 DB。merchant 登入成功 → httpOnly cookie `merchant_token`
 * （記住 ~30 日）對應 sessions 表一條 session；員工登入機制完全唔受影響。
 *
 * 安全：呢個入口唔畀 admin/staff 用（避免員工帳號借道入閘）；員工 /api/auth/login
 * 亦已 reject role='merchant'（雙向隔離）。
 */
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');
const merchantAuth = require('../middleware/merchantAuth');

// 輕量 promisify（sqlite3 callback → Promise），方便 async/await
const dbGet = (sql, params = []) => new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => (err ? reject(err) : resolve(row)));
});
const dbRun = (sql, params = []) => new Promise((resolve, reject) => {
    db.run(sql, params, (err) => (err ? reject(err) : resolve()));
});

/**
 * @route POST /api/auth/merchant-login
 * @desc Merchant 登入（記住 ~30 日）— 只接受 role='merchant'
 * @access Public
 */
router.post('/merchant-login', async (req, res) => {
    try {
        const { username, password, next } = req.body || {};
        const ipAddress = req.ip || req.connection.remoteAddress;

        if (!username || !password) {
            return res.status(400).json({ success: false, error: '請輸入帳號和密碼' });
        }

        const employee = await dbGet(
            `SELECT * FROM employees WHERE LOWER(username) = LOWER(?)`,
            [username]
        );

        if (!employee) {
            authMiddleware.createAuditLog(null, 'merchant_login_failed', `merchant 登入：用戶不存在 (${username})`, ipAddress);
            // 統一 message，唔洩露有冇呢個帳
            return res.status(401).json({ success: false, error: '帳號或密碼不正確' });
        }

        if (employee.is_active !== 1) {
            authMiddleware.createAuditLog(employee.id, 'merchant_login_failed', 'merchant 帳戶已停用', ipAddress);
            return res.status(403).json({ success: false, error: '帳戶已停用，請聯繫系統管理員' });
        }

        const isPasswordValid = await bcrypt.compare(password, employee.password_hash);
        if (!isPasswordValid) {
            authMiddleware.createAuditLog(employee.id, 'merchant_login_failed', 'merchant 密碼不正確', ipAddress);
            return res.status(401).json({ success: false, error: '帳號或密碼不正確' });
        }

        // 只允許 merchant 角色經呢度入閘
        if (employee.role !== 'merchant') {
            authMiddleware.createAuditLog(employee.id, 'merchant_login_failed', '非 merchant 帳戶嘗試用 merchant 登入', ipAddress);
            return res.status(403).json({ success: false, error: '此帳戶請使用員工登入' });
        }

        // 建立 merchant session（30 日）
        const sessionId = uuidv4();
        const token = uuidv4();
        const expiresAt = new Date(Date.now() + merchantAuth.merchantSessionMs());

        await dbRun(
            `INSERT INTO sessions (id, employee_id, token, ip_address, user_agent, expires_at)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [sessionId, employee.id, token, ipAddress, req.headers['user-agent'] || '', expiresAt.toISOString()]
        );

        // 更新最後登入時間
        try {
            await dbRun(`UPDATE employees SET last_login = ? WHERE id = ?`, [new Date().toISOString(), employee.id]);
        } catch (e) { /* 非關鍵 */ }

        authMiddleware.createAuditLog(employee.id, 'merchant_login', 'merchant 登入成功', ipAddress);

        merchantAuth.setMerchantCookie(res, token);

        const cleanNext = merchantAuth.sanitizeNextUrl(next);
        return res.json({ success: true, next: cleanNext || '/', expires_at: expiresAt.toISOString() });
    } catch (error) {
        console.error('merchant 登入錯誤:', error);
        return res.status(500).json({ success: false, error: '登入失敗，請稍後再試' });
    }
});

/**
 * @route POST /api/auth/merchant-logout
 * @desc Merchant 登出 — 刪 session + 清 cookie（cookie 冇都淨係清）
 * @access merchant cookie
 */
router.post('/merchant-logout', async (req, res) => {
    try {
        const token = merchantAuth.getMerchantToken(req);
        if (token) {
            await dbRun(`DELETE FROM sessions WHERE token = ?`, [token]).catch(() => {});
        }
        merchantAuth.clearMerchantCookie(res);
        return res.json({ success: true });
    } catch (error) {
        console.error('merchant 登出錯誤:', error);
        merchantAuth.clearMerchantCookie(res);
        return res.json({ success: true });
    }
});

/**
 * @route GET /api/auth/merchant-me
 * @desc 攞返而家 merchant 帳資料（帳戶頁顯示用）
 * @access merchant cookie
 */
router.get('/merchant-me', merchantAuth.requireMerchant, (req, res) => {
    return res.json({
        success: true,
        data: {
            id: req.merchant.employee_id,
            username: req.merchant.username,
            full_name: req.merchant.full_name,
            role: req.merchant.role
        }
    });
});

/**
 * @route PUT /api/auth/merchant-account
 * @desc Merchant 改自己帳號/密碼（current_password 驗證；改密碼 → 踢走其他裝置 session）
 * @access merchant cookie
 */
router.put('/merchant-account', merchantAuth.requireMerchant, async (req, res) => {
    try {
        let { current_password, new_username, new_password } = req.body || {};
        const merchant = req.merchant;
        const ipAddress = req.ip || req.connection.remoteAddress;

        if (!current_password) {
            return res.status(400).json({ success: false, error: '請輸入當前密碼以驗證身份' });
        }
        if (!new_username && !new_password) {
            return res.status(400).json({ success: false, error: '請輸入新帳號或新密碼' });
        }
        if (new_password !== undefined && new_password.length < 6) {
            return res.status(400).json({ success: false, error: '新密碼必須至少 6 個字符' });
        }
        if (new_username !== undefined && typeof new_username === 'string') {
            new_username = new_username.trim();
            if (!new_username) {
                return res.status(400).json({ success: false, error: '新帳號唔可以空白' });
            }
        }

        const employee = await dbGet(
            `SELECT id, username, password_hash FROM employees WHERE id = ?`,
            [merchant.employee_id]
        );
        if (!employee) {
            return res.status(404).json({ success: false, error: 'merchant 帳戶唔存在' });
        }

        const isPasswordValid = await bcrypt.compare(current_password, employee.password_hash);
        if (!isPasswordValid) {
            authMiddleware.createAuditLog(merchant.employee_id, 'merchant_password_failed', '修改 merchant 帳戶：當前密碼不正確', ipAddress);
            return res.status(401).json({ success: false, error: '當前密碼不正確' });
        }

        // 若改 username，檢查唯一性
        if (new_username && new_username !== employee.username) {
            const existing = await dbGet(
                `SELECT id FROM employees WHERE LOWER(username) = LOWER(?) AND id != ?`,
                [new_username, merchant.employee_id]
            );
            if (existing) {
                return res.status(400).json({ success: false, error: '新帳號已被使用' });
            }
        }

        const updates = [];
        const params = [];

        if (new_username && new_username !== employee.username) {
            updates.push('username = ?');
            params.push(new_username);
        }

        let passwordChanged = false;
        if (new_password) {
            const saltRounds = 10;
            const newHash = await bcrypt.hash(new_password, saltRounds);
            updates.push('password_hash = ?');
            params.push(newHash);
            passwordChanged = true;
        }

        if (updates.length === 0) {
            return res.json({ success: true, must_relogin: false, message: '冇任何變更' });
        }

        updates.push('updated_at = ?');
        params.push(new Date().toISOString());
        params.push(merchant.employee_id);

        await dbRun(`UPDATE employees SET ${updates.join(', ')} WHERE id = ?`, params);

        // 改密碼 → 刪晒該 merchant 所有 session（強制其他裝置重新登入）
        if (passwordChanged) {
            await dbRun(`DELETE FROM sessions WHERE employee_id = ?`, [merchant.employee_id]).catch(() => {});
            authMiddleware.createAuditLog(merchant.employee_id, 'merchant_password_change', 'merchant 修改密碼（已踢走其他 session）', ipAddress);
        } else {
            authMiddleware.createAuditLog(merchant.employee_id, 'merchant_account_update', 'merchant 修改帳號', ipAddress);
        }

        return res.json({ success: true, must_relogin: !!passwordChanged, message: '帳戶已更新' });
    } catch (error) {
        console.error('merchant 修改帳戶錯誤:', error);
        return res.status(500).json({ success: false, error: '更新失敗，請稍後再試' });
    }
});

module.exports = router;
