const express = require('express');
const router = express.Router();
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');

// ─────────────────────────────────────────────────────────────
// APK 更新代理（EDGE 專用）
// APK 外殼唔持有 API key；由本機 Node server（持有 ALIYUN_API_KEY）代為向
// 阿里雲受保護端點（/api/release/*）取得更新清單與檔案。
// 取得清單後改寫 apk_url 指向本機 /api/apk-update/file，APK 端無需改下載邏輯。
// ─────────────────────────────────────────────────────────────

const MERCHANT_RE = /^[a-z0-9_-]{0,32}$/;
const FILE_RE = /^[A-Za-z0-9._-]{1,128}\.(apk|zip)$/;

function releaseBaseUrl() {
    return (process.env.RELEASE_BASE_URL || '').replace(/\/$/, '');
}

function apiKeyHeader() {
    const key = process.env.ALIYUN_API_KEY;
    return key ? ['-H', `x-api-key: ${key}`] : [];
}

// 用 curl 抓 JSON（Termux 的 curl 使用系統憑證，較 Node https 穩定）
function fetchJson(url) {
    return new Promise((resolve, reject) => {
        const args = ['-sL', '--connect-timeout', '10', ...apiKeyHeader(), url];
        execFile('curl', args, { timeout: 30000, maxBuffer: 10 * 1024 * 1024 }, (err, stdout) => {
            if (err) return reject(err);
            try { resolve(JSON.parse(stdout)); } catch (e) { reject(e); }
        });
    });
}

// 下載檔案到暫存（回傳暫存路徑）
function downloadToTemp(url) {
    const dest = path.join(os.tmpdir(), `apk_update_${Date.now()}_${crypto.randomBytes(4).toString('hex')}.apk`);
    return new Promise((resolve, reject) => {
        const args = ['-sL', '--connect-timeout', '10', '-o', dest, ...apiKeyHeader(), url];
        execFile('curl', args, { timeout: 180000 }, (err) => {
            if (err) return reject(err);
            if (!fs.existsSync(dest) || fs.statSync(dest).size === 0) return reject(new Error('下載失敗或檔案為空'));
            resolve(dest);
        });
    });
}

// 取得清單並改寫 apk_url 指向本機
async function serveManifest(req, res, endpoint, fileName) {
    const merchant = String(req.query.merchant || '').trim();
    if (!MERCHANT_RE.test(merchant)) {
        return res.status(400).json({ success: false, error: '不合法的 merchant 參數' });
    }
    const base = releaseBaseUrl();
    if (!base) {
        return res.status(503).json({ success: false, error: '未設定 RELEASE_BASE_URL' });
    }
    const url = `${base}/api/release/${endpoint}${merchant ? `?merchant=${encodeURIComponent(merchant)}` : ''}`;
    try {
        const json = await fetchJson(url);
        const host = req.headers.host || 'localhost:3000';
        if (json && typeof json.apk_url === 'string') {
            // 取檔名：支援兩種 apk_url 形式
            //   (a) 直接檔案 URL：.../autocafe-v9.9.apk
            //   (b) 端點 URL：.../api/release/file?name=autocafe-v9.9.apk
            let baseName = '';
            try {
                const u = new URL(json.apk_url);
                baseName = u.searchParams.get('name') || path.basename(u.pathname);
            } catch (_) {
                baseName = path.basename(json.apk_url.split('?')[0]);
            }
            if (FILE_RE.test(baseName)) {
                const q = merchant ? `&merchant=${encodeURIComponent(merchant)}` : '';
                json.apk_url = `http://${host}/api/apk-update/file?name=${encodeURIComponent(baseName)}${q}`;
            }
        }
        res.setHeader('Cache-Control', 'no-store');
        return res.json(json);
    } catch (e) {
        return res.status(502).json({ success: false, error: '無法取得更新清單', message: e.message });
    }
}

// GET /api/apk-update/manifest?merchant=<slug>
router.get('/manifest', (req, res) => serveManifest(req, res, 'manifest', 'latest-version.json'));

// GET /api/apk-update/manifest-entry?merchant=<slug>
router.get('/manifest-entry', (req, res) => serveManifest(req, res, 'manifest-entry', 'latest-version-entry.json'));

// GET /api/apk-update/file?merchant=<slug>&name=<file>
router.get('/file', async (req, res) => {
    const merchant = String(req.query.merchant || '').trim();
    const name = String(req.query.name || '').trim();
    if (!MERCHANT_RE.test(merchant) || !FILE_RE.test(name)) {
        return res.status(400).json({ success: false, error: '不合法的參數' });
    }
    const base = releaseBaseUrl();
    if (!base) {
        return res.status(503).json({ success: false, error: '未設定 RELEASE_BASE_URL' });
    }
    const url = `${base}/api/release/file?name=${encodeURIComponent(name)}${merchant ? `&merchant=${encodeURIComponent(merchant)}` : ''}`;
    try {
        const tmp = await downloadToTemp(url);
        const cleanup = () => { try { fs.unlinkSync(tmp); } catch (_) {} };
        res.setHeader('Content-Type', 'application/vnd.android.package-archive');
        res.setHeader('X-Content-Type-Options', 'nosniff');
        res.sendFile(tmp, (err) => { cleanup(); if (err && !res.headersSent) res.status(500).end(); });
    } catch (e) {
        return res.status(502).json({ success: false, error: '無法下載更新檔案', message: e.message });
    }
});

module.exports = router;
