# Aliyun Cron Scripts（`/home/autocafe/scripts/`）

呢個資料夾係阿里雲伺服器（47.239.121.13）定時任務 scripts 嘅 **version-controlled source of truth**。

## 背景

阿里雲 `/home/autocafe/scripts/` 有 14 個定時任務 scripts（Google Sheets 同步、更表、cBOS 下載、DB backup、錯誤 email 監視器等），由 `/etc/cron.d/autocafe` 排程。呢啲 scripts 以前**唔喺任何 git**，得伺服器一份 + 本地 `aliyun-current/` 偶然副本 —— 有遺失風險。2026-09-02 開始將佢哋納入 catstearoom repo 版本控制。

> ⚠️ **呢啲係 catstearoom 商家定制 scripts**（硬寫 catstearoom 4 間店 + 佢哋嘅 Google Sheets ID），所以 commit 去 `catstearoom` branch，**唔好入 master**（master = 通用版要保持乾淨）。見 `MD Files/STRUCTURE.md` branch model。

## 內容

| 檔案 | 用途 | Cron 排程 |
|---|---|---|
| `cron.d.autocafe` | `/etc/cron.d/autocafe` 設定副本（reference） | — |
| `crontab.extra` | user crontab guard 檔（acme.sh restore 用） | 3:55 檢查 |
| `check_cron_logs.py` | 錯誤偵測 + email 通知監視器 | 7,15,23 點 |
| `check_fix_hours.py` | 更表總工時檢查 | 4:10 |
| `cbos_download.py` | cBOS 報表下載（原本喺 `/tmp/`） | 每月 2 號 3:00 |
| `fill_sheet.py` | 填 Sale Statistic Report 月份 tab | 每月 2 號 3:00 |
| `sync_sales_to_sheet.py` | 每日各店人數/營業額同步 | 23:00 |
| `sync_holidays_from_sheet.py` | 假日同步 | 3:30 |
| `save_arrived_to_sheet.py` | 已入座記錄儲存 | 21:00 |
| `db-backup.sh` | DB 備份 | 3:00 |
| `vet_reminder.py` | 獸醫預約提醒 | 18:05 |
| `notify_email.py` | Gmail SMTP 發信（供 check_cron_logs / vet_reminder） | — |
| `cron_wrapper.sh` | cron wrapper（靜默失敗 → ❌ 標記） | — |
| `search_feedback.py` / `search_mc_roster.py` | 非 cron 嘅伺服器工具 | —（人手行） |
| `crontab.backup` | 舊 user crontab 備份（reference） | — |

## 部署：點改呢啲 scripts

**改 code 後伺服器唔會自動 pull** —— 呢個 folder 只係 version control。實際更新流程（跟 `ALIYUN_DEPLOY_GUIDE.md` 精神）：

1. **先由伺服器下載**現有版本到本地（伺服器先係 live truth）
2. 用 `Edit` / `Write` 修改本地 copy
3. 上傳：`scp` 去 `/home/autocafe/scripts/<檔名>`（root@47.239.121.13，SSH_ASKPASS 方法）
4. Cron scripts 唔使 `pm2 restart`（唔係 daemon）；下一個排程自然用新版本
   - 想即刻跑：`/usr/bin/python3 /home/autocafe/scripts/<名>.py <args>`
5. 驗證 + **commit 去 catstearoom branch** 同步 repo

## 🔒 唔入 git 嘅檔案（secrets / runtime）

以下檔案**唔好 commit**，`.gitignore` 已加：

- `google-sheets-key.json` + `.old_*` — Google 服務帳號金鑰
- `email_config.json` — Gmail App Password（chmod 600）
- `drive_client_oauth.json` / `drive_token.json` — Google Drive OAuth
- `.cron_log_state.json` — 監視器讀取 offset（runtime state）
- `logs/`、`cron_email_check.log` — runtime logs

## fill_sheet.py 特別註記（2026-09-02）

Workbook 已到 Google Sheets 10M 格上限，`duplicate_sheet` 建新月份 tab 會失敗。已改為：新月份 tab 唔存在時 → **回收最舊月份 tab**（`find_oldest_month_sheet`，將年份+月份最舊嗰個改名做新月份）→ 填新月份資料。每月會犧牲最舊月份報告。
