#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
神秘顧客 feedback 搜尋（4 間分店 spreadsheet）

用法: python3 search_feedback.py <電話>
  - 用 service account 讀取 4 間分店 spreadsheet 嘅「最左側」sheet（表單回應）
  - 喺「登記電話」欄搜尋（自動補 852 前綴 / 去 852 前綴比對）
  - 輸出 JSON 到 stdout，按時間戳記由新至舊排序

範例:
  python3 search_feedback.py 12345678        → 會搜 12345678 及 85212345678
  python3 search_feedback.py 85212345678     → 同上

呼叫來源: 由 cafe-server 嘅 POST /api/feedback/search 呼叫
"""
import sys
import re
import json
from datetime import datetime

import gspread
from google.oauth2.service_account import Credentials

# google-sheets-key.json 跟 merchant folder 走（scripts 部署喺 <merchant>/scripts/），唔硬寫絕對路徑
import os
_HERE = os.path.dirname(os.path.abspath(__file__))
KEY_PATH = os.environ.get('SHEETS_KEY_PATH', os.path.join(_HERE, 'google-sheets-key.json'))
SCOPE = [
    'https://spreadsheets.google.com/feeds',
    'https://www.googleapis.com/auth/drive',
]

# 分店 → spreadsheet key（只查每個 spreadsheet 最左側嗰個 sheet）
SHEETS = [
    {'store': '荃灣',   'key': '1XUyo_QIXLUyPVfFBRKB1qjhjr8cO8bqw0nMLtStY0MQ'},
    {'store': '尖沙咀', 'key': '18iASXt0KHm-ercUHM3sFW_Lz4uvw3eZ-eJncUy3tNlQ'},
    {'store': '旺角',   'key': '1ehQY3QTu86jVZEKtO2XGjh2C0usOHH2hvAN9kiAGCMg'},
    {'store': '銅鑼灣', 'key': '1htrtTvd2ZWgYWWZvAso88GcMzNhEx_PrZ7RuovLzNAA'},
]

TS_COL = 0    # 時間戳記
PHONE_COL = 1 # 登記電話


def normalize(phone):
    """抽出所有數字；同時返回『8 位本地號碼』+『852 全號』"""
    digits = re.sub(r'\D', '', str(phone))
    if len(digits) >= 11 and digits.startswith('852'):
        return digits[-8:], digits
    if len(digits) >= 8:
        return digits[-8:], '852' + digits[-8:]
    return digits, digits


def parse_ts(s):
    """把 Google Form 時間戳記轉成 datetime（支援 2026/8/13 下午2:30:00 / 2026-08-13 14:30:00 等格式）"""
    s = (s or '').strip()
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y/%m/%d %H:%M:%S', '%Y-%m-%d %H:%M', '%Y/%m/%d %H:%M'):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            pass
    m = re.match(r'^(\d{4})/(\d{1,2})/(\d{1,2})\s*(上午|下午)?\s*(\d{1,2}):(\d{2})(?::(\d{2}))?', s)
    if m:
        y, mo, d, ampm, h, mi, se = m.groups()
        h = int(h)
        if ampm == '下午' and h < 12:
            h += 12
        if ampm == '上午' and h == 12:
            h = 0
        return datetime(int(y), int(mo), int(d), h, int(mi), int(se or 0))
    return datetime.min


def main():
    raw = sys.argv[1] if len(sys.argv) > 1 else ''
    core, full = normalize(raw)
    if not core:
        print(json.dumps({'error': 'empty_phone'}, ensure_ascii=False))
        return

    creds = Credentials.from_service_account_file(KEY_PATH, scopes=SCOPE)
    client = gspread.authorize(creds)

    results = []
    errors = []
    for s in SHEETS:
        try:
            sh = client.open_by_key(s['key'])
            tab = sh.worksheets()[0]  # 最左側嗰個 sheet（表單回應）
            rows = tab.get_all_values()
        except Exception as e:
            errors.append({'store': s['store'], 'error': str(e)[:200]})
            continue
        for r in rows[1:]:  # 跳過 header row
            if len(r) <= PHONE_COL:
                continue
            c_core, c_full = normalize(r[PHONE_COL])
            if c_core and (c_core == core or c_full == core or c_core == full or c_full == full):
                results.append({'store': s['store'], 'record': r})

    results.sort(key=lambda x: parse_ts(x['record'][TS_COL] if len(x['record']) > TS_COL else ''),
                 reverse=True)

    out = {'count': len(results), 'results': results}
    if errors:
        out['errors'] = errors
    print(json.dumps(out, ensure_ascii=False))


if __name__ == '__main__':
    main()
