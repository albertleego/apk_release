#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
神秘顧客 更表搜尋 — 喺「更表」spreadsheet 揾電話係咪當月/上月嘅神秘顧客

用法: python3 search_mc_roster.py <電話>
  - 讀 spreadsheet key 1CCO8J9s7LbZRC8-yny6QrVQnx2P9lw54I0IOXj77qC4
  - 目標 sheet: 更表_<mmm><yy>（當月，例如 更表_aug26）＋ 更表_<上一個月><yy>（例如 更表_jul26）
  - 每個 sheet:
      * BY48 = mcCount（神秘顧客人數）
      * 主要搜尋範圍: BX50..BX(50+mcCount)
      * 保險: 若 BY48 嘅 count 未 update（例如 0 但實際有記錄），會沿 BX 向下掃到空格為止
      * 搵到 → 回報該 row 嘅 BX(電話)/BY/CA/CC/CE 以及 row49 分店 label
  - 當月搵唔到先搜上月；兩月都冇 → found=false
  - stdout 輸出 JSON
"""
import sys
import json
import re
from datetime import datetime, timedelta

import gspread
from google.oauth2.service_account import Credentials

# google-sheets-key.json 跟 merchant folder 走（scripts 部署喺 <merchant>/scripts/），唔硬寫絕對路徑
import os
_HERE = os.path.dirname(os.path.abspath(__file__))
KEY_PATH = os.environ.get('SHEETS_KEY_PATH', os.path.join(_HERE, 'google-sheets-key.json'))
SHEET_KEY = '1CCO8J9s7LbZRC8-yny6QrVQnx2P9lw54I0IOXj77qC4'
SCOPE = [
    'https://spreadsheets.google.com/feeds',
    'https://www.googleapis.com/auth/drive',
    'https://www.googleapis.com/auth/spreadsheets',
]

MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']
MC_ROW = 48        # BY48 = mcCount
HEADER_ROW = 49    # row49 = 分店 label + 分店 count
DATA_START = 50    # 神秘顧客由 row 50 開始
BLOCK_END = 200    # 保險上限（沿 BX 掃到空格，封頂 200）

# get_values('BX49:CE…') 每一行嘅 column index（BX=76, BY=77, CA=79, CC=81, CE=83）
BX = 0
BY = 1
CA = 3
CC = 5
CE = 7


def sheet_title(y, m):
    """更表_<mmm><yy>，e.g. 更表_aug26"""
    return '更表_%s%02d' % (MONTHS[m - 1], y % 100)


def normalize(phone):
    """抽出所有數字；同時返回『8 位本地號碼』+『852 全號』（與 search_feedback.py 一致）"""
    digits = re.sub(r'\D', '', str(phone))
    if len(digits) >= 11 and digits.startswith('852'):
        return digits[-8:], digits
    if len(digits) >= 8:
        return digits[-8:], '852' + digits[-8:]
    return digits, digits


def cell(row_vals, idx):
    """get_values 嘅 row 可能被截短，取唔到當做空字串"""
    return (row_vals[idx] if idx < len(row_vals) else '').strip()


def scan_sheet(ws, core, full):
    """喺單一個更表 sheet 搜電話。搵到 → 回報 dict；冇 → None"""
    mc_raw = ''
    try:
        v = ws.get_values('BY%d' % MC_ROW)
        if v and v[0]:
            mc_raw = str(v[0][0] or '').strip()
    except Exception:
        mc_raw = ''
    mc_count = int(mc_raw) if mc_raw.isdigit() else 0

    # 一次過讀 BX49:CE{BLOCK_END}（row49 = header，row50+ = 神秘顧客資料）
    rows = ws.get_values('BX%d:CE%d' % (HEADER_ROW, BLOCK_END))
    header = rows[0] if rows else []
    labels = {
        'BY': cell(header, BY),   # TW
        'CA': cell(header, CA),   # TST
        'CC': cell(header, CC),   # MK
        'CE': cell(header, CE),   # CW
    }

    # 主要範圍尾行 = 50 + mcCount；保險：再沿 BX 掃到最後一個非空格
    real_last = DATA_START
    for i, rv in enumerate(rows[1:], start=DATA_START):
        if cell(rv, BX):
            real_last = i
    last_row = max(DATA_START + mc_count, real_last)

    for i, rv in enumerate(rows[1:], start=DATA_START):
        if i > last_row:
            break
        ph = cell(rv, BX)
        if not ph:
            continue
        c_core, c_full = normalize(ph)
        if c_core and (c_core == core or c_full == core or c_core == full or c_full == full):
            return {
                'row': i,
                'phone': ph,
                'mc_count': mc_count,
                'labels': labels,
                'values': {
                    'BY': cell(rv, BY),   # 荃灣
                    'CA': cell(rv, CA),   # 尖沙咀
                    'CC': cell(rv, CC),   # 旺角
                    'CE': cell(rv, CE),   # 銅鑼灣
                },
            }
    return None


def main():
    raw = sys.argv[1] if len(sys.argv) > 1 else ''
    core, full = normalize(raw)
    if not core:
        print(json.dumps({'success': False, 'error': 'empty_phone'}, ensure_ascii=False))
        return

    now = datetime.now()
    cur = sheet_title(now.year, now.month)
    # 上一個月
    first = now.replace(day=1) - timedelta(days=1)
    prev = sheet_title(first.year, first.month)

    try:
        creds = Credentials.from_service_account_file(KEY_PATH, scopes=SCOPE)
        client = gspread.authorize(creds)
        sh = client.open_by_key(SHEET_KEY)
    except Exception as e:
        print(json.dumps({'success': False, 'error': 'Google Sheets 連線失敗: ' + str(e)[:200]}, ensure_ascii=False))
        return

    checked = []
    for title in (cur, prev):
        try:
            ws = sh.worksheet(title)
        except Exception:
            checked.append({'sheet': title, 'status': 'missing'})
            continue
        hit = scan_sheet(ws, core, full)
        if hit:
            print(json.dumps({
                'success': True,
                'found': True,
                'sheet': title,
                'checked': checked,
                'row': hit['row'],
                'phone': hit['phone'],
                'mc_count': hit['mc_count'],
                'labels': hit['labels'],
                'values': hit['values'],
            }, ensure_ascii=False))
            return
        checked.append({'sheet': title, 'status': 'not_found'})

    print(json.dumps({
        'success': True,
        'found': False,
        'checked': checked,
    }, ensure_ascii=False))


if __name__ == '__main__':
    main()
