#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
獸醫預約提醒 — 每日 6:05pm 檢查各店 Daily_XX「獸醫預約」sheet
如果當天（香港時間）有獸醫預約 → email 提醒 albertleetmail@gmail.com
並提醒各分店 send 診金單出 group 及 upload 貓病紀錄。

由 cron.d/autocafe 呼叫（cron_wrapper.sh 包住）：
    5 18 * * * root <merchant>/scripts/cron_wrapper.sh "vet_reminder" /usr/bin/python3 <merchant>/scripts/vet_reminder.py >> <merchant>/scripts/logs/vet_reminder_cron.log 2>&1

用法: python3 vet_reminder.py [--dry-run] [--date YYYY-MM-DD]
    --dry-run: 只輸出會寄嘅內容，唔真係寄（測試用）
    --date:   指定檢查日期（預設香港時間今天，測試用）

「獸醫預約」sheet 欄位（row 3 header，row 4 起資料）：
    D=日  E=月(Jan..Dec)  F=年  G=開始時間(1500)  H=貓貓名  I=診所名  J=備註
"""
import sys
import json
import datetime

import gspread
from google.oauth2.service_account import Credentials

# google-sheets-key.json 跟 merchant folder 走（scripts 部署喺 <merchant>/scripts/），唔硬寫絕對路徑
import os
_HERE = os.path.dirname(os.path.abspath(__file__))
KEY_PATH = os.environ.get('SHEETS_KEY_PATH', os.path.join(_HERE, 'google-sheets-key.json'))

# store_id → { name, daily sheet key }（Daily_TW/TS/MK/CW）
DAILY_SHEETS = {
    'store_1': {'name': '荃灣',  'key': '10-krvXDLWI2hlwzgCpFxfevPZeMA9jcWjWsBIrUEYJ0'},
    'store_2': {'name': '尖沙咀', 'key': '1sAsLbYDX1WJSlth61GYdV5o_Hzkkyxv0JqvuEdA_Wd0'},
    'store_3': {'name': '旺角',  'key': '1wPHxfOtc4vU1TBS2RRCIyN4-xOKNj5F0M-DzjSazOjM'},
    'store_4': {'name': '銅鑼灣', 'key': '126jGeBHnT71fGNRkS9kaY5hcEwHMRmFZDOX-9uO-qVY'},
}
WORKSHEET_NAME = '獸醫預約'

# 欄位 col index（1-based）。「獸醫預約」sheet 同「包場紀錄」唔同：
# A=更表update B=last update C=日 D=月 E=年 F=開始時間 G=貓貓名 H=診所名 I=備註 J=舊record請刪除
COL_DAY = 3
COL_MONTH = 4
COL_YEAR = 5
COL_TIME = 6
COL_CAT = 7
COL_CLINIC = 8
COL_NOTE = 9
DATA_START_ROW = 4

HKT = datetime.timezone(datetime.timedelta(hours=8))


def fmt_time(t):
    """1500 → 15:00；900 → 09:00；9:00 → 09:00"""
    t = str(t or '').strip().replace(':', '')
    if t.isdigit():
        if len(t) == 3:
            t = '0' + t
        if len(t) == 4:
            return t[:2] + ':' + t[2:]
    return str(t or '')


def parse_row(r):
    """由 row values（list）抽出欄位；日期三欄任一空白 → 空白行，回傳 None"""
    def g(i):
        return str(r[i - 1]).strip() if len(r) >= i else ''
    day, month, year = g(COL_DAY), g(COL_MONTH), g(COL_YEAR)
    # 日欄唔係數字（header/garbage/空白）→ 唔算資料行
    if not day.isdigit():
        return None
    return {
        'day': day,
        'month': month,
        'year': year,
        'time': fmt_time(g(COL_TIME)),
        'cat': g(COL_CAT),
        'clinic': g(COL_CLINIC),
        'note': g(COL_NOTE),
    }


def is_today(rec, today):
    """判斷 record 日期是否 = today（香港時間）"""
    return (rec['day'].lstrip('0') == str(today.day)
            and rec['month'].strip().title() == today.strftime('%b')
            and rec['year'] == str(today.year))


def main():
    dry_run = '--dry-run' in sys.argv
    now = datetime.datetime.now(HKT)
    today = now.date()
    # --date 覆寫檢查日期（測試用）
    if '--date' in sys.argv:
        i = sys.argv.index('--date')
        if i + 1 < len(sys.argv):
            try:
                today = datetime.datetime.strptime(sys.argv[i + 1], '%Y-%m-%d').date()
            except ValueError:
                print('[vet_reminder] ERROR --date 格式錯誤（應為 YYYY-MM-DD）')
                return 1
    print('[vet_reminder] %s 開始檢查（%s，日期=%s）' % (
        now.strftime('%Y-%m-%d %H:%M:%S'), 'dry-run' if dry_run else '正式', today.isoformat()))

    scope = [
        'https://spreadsheets.google.com/feeds',
        'https://www.googleapis.com/auth/drive',
        'https://www.googleapis.com/auth/spreadsheets',
    ]
    try:
        creds = Credentials.from_service_account_file(KEY_PATH, scopes=scope)
        client = gspread.authorize(creds)
    except Exception as e:
        print('[vet_reminder] ERROR Google Sheets 連線失敗: ' + str(e)[:200])
        return 1

    found = []   # [(store_name, rec)]
    errors = []
    for sid, cfg in DAILY_SHEETS.items():
        try:
            sh = client.open_by_key(cfg['key'])
            ws = sh.worksheet(WORKSHEET_NAME)
            vals = ws.get_all_values()
        except Exception as e:
            errors.append('%s: %s' % (cfg['name'], str(e)[:150]))
            print('[vet_reminder] ERROR %s 讀取失敗: %s' % (cfg['name'], str(e)[:150]))
            continue

        cnt = 0
        for r in vals[DATA_START_ROW - 1:]:
            rec = parse_row(r)
            if rec and is_today(rec, today):
                found.append((cfg['name'], rec))
                cnt += 1
        print('[vet_reminder] %s: 今日預約 %d 筆' % (cfg['name'], cnt))

    if not found:
        print('[vet_reminder] 今日（%s）無獸醫預約' % today.isoformat())
        return 1 if errors else 0

    # 組 email
    lines = ['今日（%s）有獸醫預約，請各分店留意：' % today.isoformat(), '']
    for store_name, rec in found:
        lines.append('【%s】' % store_name)
        parts = []
        if rec['time']:
            parts.append('時間: %s' % rec['time'])
        if rec['cat']:
            parts.append('貓貓名: %s' % rec['cat'])
        if rec['clinic']:
            parts.append('診所名: %s' % rec['clinic'])
        if rec['note']:
            parts.append('備註: %s' % rec['note'])
        lines.append(' | '.join(parts))
        lines.append('')
    lines.append('⚠️ 提醒：記得 send 診金單出 group，及 upload 貓病紀錄！')
    body = '\n'.join(lines)
    subject = '🐾 獸醫預約提醒 %s（%s店）' % (
        today.isoformat(), '、'.join(s for s, _ in found))

    print('[vet_reminder] 今日共 %d 筆預約，寄信 subject: %s' % (len(found), subject))
    print('--- 電郵內容 ---')
    print(body)
    print('-----------------')

    if dry_run:
        print('[vet_reminder] dry-run：冇 send email')
        return 0

    try:
        import notify_email
        notify_email.send(subject, body)
        print('[vet_reminder] EMAIL SENT OK')
    except Exception as e:
        print('[vet_reminder] ERROR 寄信失敗: %r' % e)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
