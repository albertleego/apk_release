#!/usr/bin/env python3
"""每日同步：從 Google Sheet 下載節假日 daytype，更新 holidays 及 daytype_all 表。

holidays 表：只存 B/S/U/H（供 entryRoutes/productRoutes 判斷是否節假日）
daytype_all 表：存全年 365/366 天 daytype（供 booking-standalone 包場查詢）

Google Sheet: https://docs.google.com/spreadsheets/d/1i6ZUED3Q-fPs64VfB0ZvVw7nno3AZUrDQ2CXPh0D6nw/
排程：每天 3:30am（香港時間）由 crontab 執行

版本更新（2026-09）：識揀年份。
- 每年一個 tab（tab 名 = 年份），YEAR_GID 對應 gid；唔再硬寫 2026 讀第一 tab。
- 每次 sync「今年 + 下年」兩個 tab。
- DELETE 只限該年，唔會剷走其他年份嘅資料。
- 更新前用 S/U 位置驗證 grid 同目標年份相配，唔啱就 skip，防止錯誤年份覆蓋。
"""
import csv, io, sqlite3, hashlib, os, sys, datetime, calendar
from urllib.request import urlopen, Request
from urllib.error import URLError

# ─── 設定 ───
SHEET_ID = '1i6ZUED3Q-fPs64VfB0ZvVw7nno3AZUrDQ2CXPh0D6nw'
# 每年一個 tab（tab 名 = 年份）→ gid。新增年份 tab 後，喺度加一行。
YEAR_GID = {
    2027: '1111753247',
    2026: '304497758',
    2025: '2062082643',
    2024: '0',
    2023: '982773168',
}

# 路徑跟 merchant folder 走（scripts 部署喺 <merchant>/scripts/），唔硬寫絕對路徑
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)  # <merchant>
DB_PATH = os.environ.get('HOLIDAY_SYNC_DB_PATH', os.path.join(_ROOT, 'database', 'cafe.db'))
LOG_DIR = os.environ.get('HOLIDAY_SYNC_LOG_DIR', os.path.join(_HERE, 'logs'))


def log(msg):
    """寫入 log 檔案"""
    os.makedirs(LOG_DIR, exist_ok=True)
    timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f'[{timestamp}] {msg}'
    print(line)
    with open(os.path.join(LOG_DIR, 'holiday_sync.log'), 'a', encoding='utf-8') as f:
        f.write(line + '\n')


def dim_of(year, month):
    """該年該月有幾多日（支援閏年）"""
    return calendar.monthrange(year, month)[1]


def download_csv(year):
    """下載該年 tab 嘅 CSV（按 gid 精確揀 tab）"""
    gid = YEAR_GID.get(year)
    if not gid:
        log(f'⚠️ {year} 冇對應 tab gid（YEAR_GID 未加），跳過')
        return None
    url = f'https://docs.google.com/spreadsheets/d/{SHEET_ID}/export?format=csv&gid={gid}'
    log(f'下載 {year} tab (gid={gid})...')
    try:
        req = Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        raw = urlopen(req, timeout=30).read().decode('utf-8')
        if raw.lstrip().startswith('<'):
            log(f'⚠️ {year} tab 下載唔到（回傳非 CSV），跳過')
            return None
        log(f'下載完成 ({len(raw)} bytes)')
        return raw
    except URLError as e:
        log(f'下載失敗: {e}')
        return None


def parse_csv(raw):
    """解析 CSV 為 {(month, day): daytype} 字典"""
    reader = csv.reader(io.StringIO(raw))
    next(reader)  # headers
    daytype_map = {}
    for row in reader:
        month_str = row[0]
        if not month_str or not month_str.isdigit():
            continue
        month = int(month_str)
        for i, val in enumerate(row[1:]):
            day = i + 1
            daytype_map[(month, day)] = val.strip()
    return daytype_map


def validate_year(daytype_map, year):
    """驗證 grid 同目標年份相配：S 一定要係真星期六、U 一定要係真星期日。
    若 gid 揀錯 tab，S/U 位置會大量錯晒 → 拒絕更新，防止錯誤年份覆蓋 DB。"""
    bad_s = bad_u = 0
    for (month, day), dt in daytype_map.items():
        if not dt or dt == 'X':
            continue
        try:
            wd = datetime.date(year, month, day).weekday()  # 0=Mon ... 6=Sun
        except ValueError:
            continue
        if dt == 'S' and wd != 5:
            bad_s += 1
        elif dt == 'U' and wd != 6:
            bad_u += 1
    if bad_s == 0 and bad_u == 0:
        return True
    log(f'❌ {year} tab 內容同該年份唔相配（S 錯 {bad_s} 格 / U 錯 {bad_u} 格），拒絕更新')
    return False


# ─── holidays 表（只存 B/S/U/H） ───

def build_holiday_rows(daytype_map, year):
    """只保留真正的節假日（H/S/U/B），跳過 X 及閒日"""
    rows = []
    holiday_types = {'H', 'S', 'U', 'B'}
    for month in range(1, 13):
        for day in range(1, dim_of(year, month) + 1):
            dt = daytype_map.get((month, day), '')
            if dt == 'X' or dt not in holiday_types:
                continue
            date_str = f'{year}-{month:02d}-{day:02d}'
            id_str = hashlib.md5(date_str.encode()).hexdigest()
            desc = f'daytype={dt}'
            rows.append((id_str, date_str, desc, dt, 1))
    return rows


def _year_clause(year):
    """該年日期範圍（ISO 日期字串可直接字串比較）"""
    return (f'{year}-01-01', f'{year}-12-31')


def update_holidays(conn, rows, year):
    """更新 holidays 表（只 DELETE 該年 default_store 嘅舊資料，保留其他年份）"""
    c = conn.cursor()
    lo, hi = _year_clause(year)

    existing = c.execute(
        'SELECT date, daytype, is_holiday FROM holidays '
        'WHERE store_id = ? AND date BETWEEN ? AND ? ORDER BY date',
        ('default_store', lo, hi)
    ).fetchall()

    new_data = {}
    for row in rows:
        new_data[row[1]] = (row[3], row[4])

    changed = False
    if len(existing) != len(rows):
        log(f'holidays {year} 筆數不同: 現有 {len(existing)} 筆, 新 {len(rows)} 筆')
        changed = True
    else:
        for date, daytype, is_holiday in existing:
            new_dt, new_ih = new_data.get(date, ('', 0))
            if (daytype or '') != new_dt or (is_holiday or 0) != new_ih:
                log(f'holidays 變更: {date} → daytype={new_dt}')
                changed = True

    if not changed:
        log(f'holidays {year} 無變更，跳過更新')
        return False

    log(f'更新 holidays {year} 表 ({len(rows)} 天)...')
    c.execute(
        'DELETE FROM holidays WHERE store_id = ? AND date BETWEEN ? AND ?',
        ('default_store', lo, hi)
    )
    c.executemany(
        'INSERT INTO holidays (id, date, description, created_by, created_at, store_id, daytype, is_holiday) '
        'VALUES (?, ?, ?, \'system_sync\', datetime(\'now\'), \'default_store\', ?, ?)',
        [(r[0], r[1], r[2], r[3], r[4]) for r in rows]
    )
    return True


# ─── daytype_all 表（全年所有日子） ───

def build_daytype_all_rows(daytype_map, year):
    """建立全年所有日子 daytype，缺失的日子用星期幾推算"""
    rows = []
    for month in range(1, 13):
        for day in range(1, dim_of(year, month) + 1):
            dt = daytype_map.get((month, day), '')
            if dt == 'X':
                continue  # X = 剔除
            date_str = f'{year}-{month:02d}-{day:02d}'
            # 如果 sheet 沒給 daytype，用星期幾推算
            if not dt:
                d = datetime.date(year, month, day)
                dow = d.weekday()  # 0=Mon ... 6=Sun
                if dow == 4:       # Friday
                    dt = 'F'
                elif dow == 5:     # Saturday
                    dt = 'S'
                elif dow == 6:     # Sunday
                    dt = 'U'
                # Mon-Thu → dt stays '' (wd)
            is_hol = 1 if dt in ('H', 'S', 'U', 'B') else 0
            rows.append((date_str, dt, is_hol))
    return rows


def update_daytype_all(conn, rows, year):
    """更新 daytype_all 表（只 DELETE 該年，保留其他年份）"""
    c = conn.cursor()
    lo, hi = _year_clause(year)

    existing = c.execute(
        'SELECT date, daytype, is_holiday FROM daytype_all WHERE date BETWEEN ? AND ? ORDER BY date',
        (lo, hi)
    ).fetchall()

    new_data = {}
    for row in rows:
        new_data[row[0]] = (row[1], row[2])

    changed = False
    if len(existing) != len(rows):
        log(f'daytype_all {year} 筆數不同: 現有 {len(existing)} 筆, 新 {len(rows)} 筆')
        changed = True
    else:
        for date, daytype, is_holiday in existing:
            new_dt, new_ih = new_data.get(date, ('', 0))
            if (daytype or '') != new_dt or (is_holiday or 0) != new_ih:
                log(f'daytype_all 變更: {date} → daytype={new_dt}')
                changed = True

    if not changed:
        log(f'daytype_all {year} 無變更，跳過更新')
        return False

    log(f'更新 daytype_all {year} 表 ({len(rows)} 天)...')
    c.execute('DELETE FROM daytype_all WHERE date BETWEEN ? AND ?', (lo, hi))
    c.executemany(
        'INSERT INTO daytype_all (date, daytype, is_holiday) VALUES (?, ?, ?)',
        rows
    )
    return True


# ─── 主流程 ───

def sync_year(conn, year):
    """同步單一年份（下載 → 驗證 → holidays + daytype_all）"""
    raw = download_csv(year)
    if not raw:
        return False

    daytype_map = parse_csv(raw)
    log(f'{year} 解析完成: {len(daytype_map)} 個日期項目')

    if not validate_year(daytype_map, year):
        return False

    ok = True

    # 1. 更新 holidays 表（只存 B/S/U/H）
    holiday_rows = build_holiday_rows(daytype_map, year)
    log(f'holidays {year} 待檢查: {len(holiday_rows)} 天')
    try:
        if update_holidays(conn, holiday_rows, year):
            conn.commit()
            log(f'✅ holidays {year} 表已更新')
        else:
            log(f'✅ holidays {year} 表無變更')
    except Exception as e:
        conn.rollback()
        log(f'❌ holidays {year} 更新失敗: {e}')
        ok = False

    # 2. 更新 daytype_all 表（全年所有日子）
    all_rows = build_daytype_all_rows(daytype_map, year)
    log(f'daytype_all {year} 待檢查: {len(all_rows)} 天')
    try:
        if update_daytype_all(conn, all_rows, year):
            conn.commit()
            log(f'✅ daytype_all {year} 表已更新')
        else:
            log(f'✅ daytype_all {year} 表無變更')
    except Exception as e:
        conn.rollback()
        log(f'❌ daytype_all {year} 更新失敗: {e}')
        ok = False

    return ok


def main():
    log('=== 開始同步節假日 ===')

    now = datetime.date.today()
    # 每次同步「今年 + 下年」（若 tab 已存在）
    target_years = sorted({now.year, now.year + 1} & set(YEAR_GID))
    if not target_years:
        log('❌ 今年/下年都冇對應 tab gid（YEAR_GID 未加），跳過')
        return 1
    log(f'目標年份: {target_years}')

    conn = sqlite3.connect(DB_PATH)
    all_ok = True
    for year in target_years:
        if not sync_year(conn, year):
            all_ok = False
    conn.close()

    log('✅ 同步完成' if all_ok else '⚠️ 同步完成（有年份失敗，見上）')
    return 0 if all_ok else 1


if __name__ == '__main__':
    exit(main())
