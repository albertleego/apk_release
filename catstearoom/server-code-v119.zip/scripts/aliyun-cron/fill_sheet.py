#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""依 SALE_GET_STAT.MD 邏輯，自動填 Sale Statistic Report 對應月份 sheet。

由 crontab 喺 cbos_download.py 下載完 CSV 之後執行：
  1. 確保月份 tab 存在（冇就複製上個月 tab）
  2. 清空 B2 以下所有數據（保留 Row1 + A 欄）
  3. 填食物 N/B/H（B12:I38）= erun_food + system 依百分比分配
  4. 填飲品（B39:I50）= erun_drink + system
  5. 填 全月套票（Row6）、濕雞(全)（Row10）from system.csv

用法：
  python3 fill_sheet.py                # 用上個月（報告月份）
  python3 fill_sheet.py --date 2026-07 # 指定報告月份（測試用）
"""

import csv, io, os, sys, datetime, sqlite3, traceback
from collections import defaultdict

import gspread
from google.oauth2.service_account import Credentials

# ─── 設定 ───
SHEET_ID = '1yzBXC25jqonL-PNno2kM9mEBx1FAMJ3iEA1gtK61sk4'
# 路徑跟 merchant folder 走（scripts 部署喺 <merchant>/scripts/），唔硬寫絕對路徑
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)  # <merchant>
KEY_PATH = os.environ.get('SHEETS_KEY_PATH', os.path.join(_HERE, 'google-sheets-key.json'))
DB_PATH = os.environ.get('CAFE_DB_PATH', os.path.join(_ROOT, 'database', 'cafe.db'))
REPORT_DIR = '/tmp/cbos_report'
LOG_PATH = os.environ.get('FILL_SHEET_LOG', os.path.join(_HERE, 'logs', 'fill_sheet.log'))
MONTH_NAMES = ['', 'jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']

SCOPE = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']

SHOPS = ['荃灣', '尖沙咀', '旺角', '銅鑼灣']
SHOP_COL = {'荃灣': 0, '尖沙咀': 2, '旺角': 4, '銅鑼灣': 6}  # 喺 8 欄 grid 內嘅 qty index（amount = +1）

# 9 種食物嘅 sheet 標籤順序
LABELS = ['藍莓', '朱古力', '巴斯克', '芝腿', '腿蛋', '芝蛋', '牛油', '朱曲', '抺茶']
G2ROWOFF = {'N': 0, 'B': 9, 'H': 18}

ERUN_FOOD_MAP = {
    '藍莓芝士蛋糕': '藍莓', '朱古力松露蛋糕': '朱古力', '巴斯克芝士蛋糕': '巴斯克',
    '芝士火腿三文治': '芝腿', '雞蛋火腿三文治': '腿蛋',
    '牛油曲奇': '牛油', '朱古力曲奇': '朱曲', '抹茶曲奇': '抺茶',
}
SYS_FOOD_MAP = {
    '藍莓芝士蛋糕': '藍莓', '朱古力松露蛋糕': '朱古力', '巴斯克芝士蛋糕': '巴斯克',
    '芝士火腿三文治': '芝腿', '雞蛋火腿三文治': '腿蛋', '芝士蛋三文治': '芝蛋',
    '牛油曲奇 (3塊)': '牛油', '朱古力曲奇 (3塊)': '朱曲', '抹茶合桃曲奇 (3塊)': '抺茶',
}
# system food -> 用邊隻 erun item 嘅百分比（芝士蛋三文治用 fallback）
SYS_FOOD_ERUN = {
    '藍莓芝士蛋糕': '藍莓芝士蛋糕', '朱古力松露蛋糕': '朱古力松露蛋糕', '巴斯克芝士蛋糕': '巴斯克芝士蛋糕',
    '芝士火腿三文治': '芝士火腿三文治', '雞蛋火腿三文治': '雞蛋火腿三文治',
    '牛油曲奇 (3塊)': '牛油曲奇', '朱古力曲奇 (3塊)': '朱古力曲奇', '抹茶合桃曲奇 (3塊)': '抹茶曲奇',
}

ERUN_DRINK_MAP = {
    '芒果乳酪特飲': '芒果乳酪特飲', '朱古力奶': '香濃朱古力', '朱古力咖啡': 'Mocha 咖啡',
    '拿鐵咖啡': 'Latte', '韓國蜂蜜柚子茶': '韓國蜂蜜柚子茶',
    '冷泡茉莉綠茶': '冷泡茉莉綠茶', '冷泡香桃紅茶': '冷泡香桃紅茶',
    '冷泡熱情果紅茶': '冷泡熱情果紅茶', '芒果紅茶': '芒果紅茶', '蜜桃紅茶': '蜜桃紅茶',
}
SYS_DRINK_MAP = {
    '芒果乳酪特飲': '芒果乳酪特飲', '香濃朱古力': '香濃朱古力', 'Mocha 咖啡': 'Mocha 咖啡',
    'Latte': 'Latte', '韓國蜂蜜柚子茶': '韓國蜂蜜柚子茶', '冷泡錫蘭伯爵茶': '冷泡錫蘭伯爵茶',
    '冷泡茉莉綠茶': '冷泡茉莉綠茶', '冷泡香桃紅茶': '冷泡香桃紅茶',
    '冷泡熱情果紅茶': '冷泡熱情果紅茶', '芒果紅茶': '芒果紅茶',
}
# 飲品格 Sheet Row 39-50 順序
DRINK_ROWS = ['芒果乳酪特飲', '蜜桃乳酪特飲', '香濃朱古力', 'Mocha 咖啡', 'Latte',
              '韓國蜂蜜柚子茶', '冷泡錫蘭伯爵茶', '冷泡茉莉綠茶', '冷泡香桃紅茶',
              '冷泡熱情果紅茶', '芒果紅茶', '蜜桃紅茶']


def log(msg):
    line = '[%s] %s' % (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), msg)
    print(line)
    try:
        os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
        with open(LOG_PATH, 'a', encoding='utf-8') as f:
            f.write(line + '\n')
    except Exception:
        pass


def read_csv(path):
    with open(path, encoding='utf-8-sig') as f:
        return list(csv.DictReader(io.StringIO(f.read())))


def month_from_title(title):
    """'jun26' → (2026, 6)；唔係月份 tab（如 jul26 / DayType人流 / 2025）就回傳 None。"""
    if len(title) != 5 or title[:3] not in MONTH_NAMES[1:] or not title[3:].isdigit():
        return None
    return (2000 + int(title[3:]), MONTH_NAMES.index(title[:3]))


def find_oldest_month_sheet(sh):
    """喺月份 tab（如 jun26 / jul26）入面搵最舊嗰個，供回收改名用。

    Workbook 已到 Google Sheets 10M 格上限，duplicate 新月份 tab 會失敗，
    所以新月份要用「回收最舊月份 tab」方式：改名做新月份，再填新月份資料。
    """
    best = None
    for w in sh.worksheets():
        ym = month_from_title(w.title)
        if ym is None:
            continue
        if best is None or ym < best[1]:
            best = (w, ym)
    return best[0] if best else None


def load_daytype(start, end):
    """讀 daytype_all：date -> daytype。冇記錄就 fallback 用星期幾。"""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT date, COALESCE(daytype,'') FROM daytype_all WHERE date BETWEEN ? AND ?",
                (start.strftime('%Y-%m-%d'), end.strftime('%Y-%m-%d')))
    m = {r[0]: r[1] for r in cur.fetchall()}
    conn.close()
    missing = 0
    d = start
    while d <= end:
        ds = d.strftime('%Y-%m-%d')
        if ds not in m:
            w = d.weekday()
            m[ds] = 'H' if w >= 5 else 'N'   # 六日 → H，平日 → N
            missing += 1
        d += datetime.timedelta(days=1)
    if missing:
        log('⚠️ daytype_all 缺 %d 天，已 fallback 用星期幾' % missing)
    return m


def group_of(dt):
    if dt in ('S', 'U', 'H'):
        return 'H'
    if dt == 'B':
        return 'B'
    return 'N'   # 空白 / F


def split_qty(q, p):
    raw = {g: q * p[g] for g in ('N', 'B', 'H')}
    base = {g: int(raw[g]) for g in raw}
    rem = {g: raw[g] - base[g] for g in raw}
    left = q - sum(base.values())
    for g in sorted(rem, key=lambda k: -rem[k])[:left]:
        base[g] += 1
    return base


def split_amt(a, q, qs):
    amt = {'N': 0, 'B': 0, 'H': 0}
    leftover = int(a)
    for i, g in enumerate(('N', 'B', 'H')):
        if i == 2:
            amt[g] = leftover
        else:
            v = round(a * qs[g] / q) if q else 0
            amt[g] = v
            leftover -= v
    return amt


def build_food_grid(erun_food_rows, dt_map, sys_food_rows):
    """回傳 27x8 grid（食物 N/B/H），erun 實數 + system 依百分比分配。"""
    # 1) erun 百分比
    erun_agg = defaultdict(lambda: defaultdict(int))
    for r in erun_food_rows:
        item = r['item'].strip()
        if item not in ERUN_FOOD_MAP:
            continue
        g = group_of(dt_map.get(r['date'][:10], ''))
        erun_agg[(r['shop'].strip(), item)][g] += int(r['qty'])

    def pct(store, item):
        v = erun_agg[(store, item)]
        tot = sum(v.values())
        if tot == 0:
            return None
        return {g: v[g] / tot for g in ('N', 'B', 'H')}

    def fallback_pct(store, kind):
        items = (['雞蛋火腿三文治', '芝士火腿三文治'] if kind == 'sandwich'
                 else ['牛油曲奇', '朱古力曲奇', '抹茶曲奇'])
        s = {'N': 0, 'B': 0, 'H': 0}
        w = 0
        for it in items:
            p = pct(store, it)
            if p:
                for g in s:
                    s[g] += p[g]
                w += 1
        return {g: s[g] / w for g in s} if w else {'N': 1 / 3, 'B': 1 / 3, 'H': 1 / 3}

    def get_pct(store, sys_item):
        if sys_item == '芝士蛋三文治':
            return fallback_pct(store, 'sandwich')
        erun_item = SYS_FOOD_ERUN.get(sys_item)
        if erun_item:
            p = pct(store, erun_item)
            if p:
                return p
        return fallback_pct(store, 'cookie' if '曲奇' in sys_item else 'sandwich')

    grid = [[0] * 8 for _ in range(27)]

    # 2) erun 實數
    for r in erun_food_rows:
        item = r['item'].strip()
        if item not in ERUN_FOOD_MAP:
            continue
        store = r['shop'].strip()
        g = group_of(dt_map.get(r['date'][:10], ''))
        li = LABELS.index(ERUN_FOOD_MAP[item])
        col = SHOP_COL.get(store)
        if col is None:
            continue
        row = G2ROWOFF[g] + li
        grid[row][col] += int(r['qty'])
        grid[row][col + 1] += int(float(r.get('net_sales') or 0))

    # 3) system 依百分比分配
    for r in sys_food_rows:
        store = r['分店'].strip()
        item = r['商品名稱'].strip()
        if item not in SYS_FOOD_MAP:
            continue
        col = SHOP_COL.get(store)
        if col is None:
            continue
        q = int(float(r['總銷量']))
        a = float(r['總銷售額'])
        p = get_pct(store, item)
        qs = split_qty(q, p)
        asplit = split_amt(a, q, qs)
        li = LABELS.index(SYS_FOOD_MAP[item])
        for g in ('N', 'B', 'H'):
            row = G2ROWOFF[g] + li
            grid[row][col] += qs[g]
            grid[row][col + 1] += asplit[g]
    return grid


def build_top_grid(sys_rows):
    """回傳 10 行 × 8 欄（Sheet Row 2-11 頂部項目），全由 system.csv 填。

    Row2 首小時 / Row3 次小時 / Row4 全日通 / Row5 一週套票 / Row6 全月套票 /
    Row7 乾雞(半) / Row8 乾雞(全) / Row9 濕雞(半) / Row10 濕雞(全) / Row11 貓唧唧
    """
    TOP_ITEMS = ['首小時', '次小時', '全日通', '一週套票', '全月套票',
                 '乾雞(半)', '乾雞(全)', '濕雞(半)', '濕雞(全)', '貓唧唧']
    KEY_PREFIX = {
        '首小時': '首小時', '次小時': '次小時', '全日通': '全日通',
        '一週套票': '一週套票', '全月套票': '全月套票',
    }
    KEY_EXACT = {
        '乾雞零食 (半份)': '乾雞(半)', '乾雞零食 (全份)': '乾雞(全)',
        '濕雞零食 (半份)': '濕雞(半)', '濕雞零食 (全份)': '濕雞(全)',
        '貓唧唧肉泥': '貓唧唧',
    }
    agg = defaultdict(lambda: [0, 0.0])   # (store, key) -> [qty, amt]
    for r in sys_rows:
        cat = r['類別'].strip()
        if cat not in ('收費', '貓零食'):
            continue
        n = r['商品名稱'].strip()
        s = r['分店'].strip()
        q = int(float(r['總銷量']))
        a = float(r['總銷售額'])
        key = None
        if n in KEY_EXACT:
            key = KEY_EXACT[n]
        else:
            for prefix, k in KEY_PREFIX.items():
                if n.startswith(prefix):
                    key = k
                    break
        if key:
            agg[(s, key)][0] += q
            agg[(s, key)][1] += a

    grid = [[0] * 8 for _ in range(10)]
    for i, item in enumerate(TOP_ITEMS):
        for shop in SHOPS:
            col = SHOP_COL.get(shop)
            if col is None:
                continue
            q, a = agg[(shop, item)]
            grid[i][col] = q
            grid[i][col + 1] = int(a)
    return grid


def build_bottom_grid(erun_food_rows, erun_drink_rows, sys_rows):
    """回傳 4 行 × 8 欄（Sheet Row 68-71 底部彙總）。

    順序: [寵物用品, 飲品, 甜品, 紀念品]
    規則:
      寵物用品 = system 寵物用品分類（冇就 0）
      飲品     = erun_drink 全部分店 + system 沖調飲品
      甜品     = erun_food 全部分店 + system 甜品輕食
      紀念品   = system 紀念品分類
    """
    def agg_erun(rows):
        d = defaultdict(lambda: [0, 0.0])
        for r in rows:
            s = r['shop'].strip()
            if s not in SHOPS:
                continue
            d[s][0] += int(r['qty'])
            d[s][1] += float(r.get('net_sales') or 0)
        return d

    def agg_sys_cat(cat):
        d = defaultdict(lambda: [0, 0.0])
        for r in sys_rows:
            if r['類別'].strip() != cat:
                continue
            s = r['分店'].strip()
            if s not in SHOPS:
                continue
            d[s][0] += int(float(r['總銷量']))
            d[s][1] += float(r['總銷售額'])
        return d

    food_e = agg_erun(erun_food_rows)
    drink_e = agg_erun(erun_drink_rows)
    drink_s = agg_sys_cat('沖調飲品')
    dessert_s = agg_sys_cat('甜品輕食')
    souvenir_s = agg_sys_cat('紀念品')
    pet_s = agg_sys_cat('寵物用品')

    # 每行: 寵物用品 / 飲品 / 甜品 / 紀念品
    rows = []
    for key in ('pet', 'drink', 'dessert', 'souvenir'):
        row = [0] * 8
        for shop in SHOPS:
            col = SHOP_COL.get(shop)
            if col is None:
                continue
            if key == 'pet':
                q, a = pet_s[shop]
            elif key == 'drink':
                q = drink_e[shop][0] + drink_s[shop][0]
                a = drink_e[shop][1] + drink_s[shop][1]
            elif key == 'dessert':
                q = food_e[shop][0] + dessert_s[shop][0]
                a = food_e[shop][1] + dessert_s[shop][1]
            else:  # souvenir
                q, a = souvenir_s[shop]
            row[col] = q
            row[col + 1] = int(a)
        rows.append(row)
    return rows


def build_drink_grid(erun_drink_rows, sys_drink_rows):
    """回傳 12x8 grid（飲品整月彙總），erun + system 直接加。"""
    grid = [[0] * 8 for _ in range(12)]

    def add(store, label, qty, amt):
        col = SHOP_COL.get(store)
        if col is None:
            return
        try:
            ri = DRINK_ROWS.index(label)
        except ValueError:
            return
        grid[ri][col] += qty
        grid[ri][col + 1] += amt

    for r in erun_drink_rows:
        item = r['item'].strip()
        if item in ERUN_DRINK_MAP:
            add(r['shop'].strip(), ERUN_DRINK_MAP[item],
                int(r['qty']), int(float(r.get('net_sales') or 0)))
    for r in sys_drink_rows:
        item = r['商品名稱'].strip()
        if item in SYS_DRINK_MAP:
            add(r['分店'].strip(), SYS_DRINK_MAP[item],
                int(float(r['總銷量'])), int(float(r['總銷售額'])))
    return grid


def main():
    # ─── 計算報告月份 ───
    if '--date' in sys.argv:
        d = datetime.datetime.strptime(sys.argv[sys.argv.index('--date') + 1], '%Y-%m').date()
        rs, re_ = d.replace(day=1), d
        import calendar
        re_ = d.replace(day=calendar.monthrange(d.year, d.month)[1])
    else:
        today = datetime.date.today()
        re_ = today.replace(day=1) - datetime.timedelta(days=1)
        rs = re_.replace(day=1)

    label = MONTH_NAMES[rs.month] + str(rs.year)[-2:]
    log('=== 填寫 %s ===' % label)

    # ─── 讀 CSVs ───
    food_path = '%s/%s/erun_food.csv' % (REPORT_DIR, label)
    drink_path = '%s/%s/erun_drink.csv' % (REPORT_DIR, label)
    sys_path = '%s/%s/system.csv' % (REPORT_DIR, label)
    if not os.path.exists(food_path):
        log('❌ %s 唔存在，跳過（可能下載失敗）' % food_path)
        return 1
    erun_food_rows = read_csv(food_path)
    erun_drink_rows = read_csv(drink_path) if os.path.exists(drink_path) else []
    sys_rows = read_csv(sys_path) if os.path.exists(sys_path) else []
    sys_food_rows = [r for r in sys_rows if '甜品輕食' in r['類別'].strip()]
    sys_drink_rows = [r for r in sys_rows if '沖調飲品' in r['類別'].strip() or '輕便飲品' in r['類別'].strip()]
    log('CSV 讀取: erun_food=%d rows, erun_drink=%d rows, system=%d rows' %
        (len(erun_food_rows), len(erun_drink_rows), len(sys_rows)))

    # ─── daytype ───
    dt_map = load_daytype(rs, re_)

    # ─── 統計 ───
    top_grid = build_top_grid(sys_rows)              # Row2-11 首小時/套票/貓零食
    food_grid = build_food_grid(erun_food_rows, dt_map, sys_food_rows)
    drink_grid = build_drink_grid(erun_drink_rows, sys_drink_rows)
    bottom_grid = build_bottom_grid(erun_food_rows, erun_drink_rows, sys_rows)  # Row68-71 寵物/飲品/甜品/紀念品

    # ─── Sheet ───
    creds = Credentials.from_service_account_file(KEY_PATH, scopes=SCOPE)
    c = gspread.authorize(creds)
    sh = c.open_by_key(SHEET_ID)

    try:
        ws = sh.worksheet(label)
        log('%s tab 已存在' % label)
    except gspread.exceptions.WorksheetNotFound:
        # 唔再 duplicate：workbook 已到 Google Sheets 10M 格上限，duplicate 會失敗。
        # 改為回收最舊嘅月份 tab（改名做新月份），再填新月份資料。
        src = find_oldest_month_sheet(sh)
        if src is None:
            log('❌ 搵唔到月份 tab 可回收，未能建立 %s' % label)
            return 1
        old_title = src.title
        src.update_title(label)
        ws = sh.worksheet(label)
        # 將新 tab 移到最左側（第一個位置）
        ws.update_index(0)
        log('✅ 已回收最舊月份 tab %s → 改名為 %s，並移到最前（最左側）' % (old_title, label))

    # 清空 B2 以下（保留 Row1 + A 欄）
    ws.update(values=[[''] * 8] * 999, range_name='B2:I1000', value_input_option='USER_ENTERED')
    log('✅ 已清空 B2:I1000')

    # 填寫
    ws.update(values=top_grid, range_name='B2:I11', value_input_option='USER_ENTERED')
    log('✅ 頂部項目已填（B2:I11：首小時/次小時/全日通/套票/貓零食）')
    ws.update(values=food_grid, range_name='B12:I38', value_input_option='USER_ENTERED')
    log('✅ 食物 N/B/H 已填（B12:I38）')
    ws.update(values=drink_grid, range_name='B39:I50', value_input_option='USER_ENTERED')
    log('✅ 飲品已填（B39:I50）')
    ws.update(values=bottom_grid, range_name='B68:I71', value_input_option='USER_ENTERED')
    log('✅ 底部彙總已填（B68:I71：寵物用品/飲品/甜品/紀念品）')

    # ─── 填 DayType人流 tab C1/D1（上月年份 / 月份）───
    # 例：8月2號 → rs = 7月 → C1=2026, D1=7
    try:
        dtws = sh.worksheet('DayType人流')
        dtws.update(values=[[rs.year, rs.month]], range_name='C1:D1', value_input_option='USER_ENTERED')
        log('✅ DayType人流 C1=%d（年份）D1=%d（月份）' % (rs.year, rs.month))
    except Exception as e:
        log('⚠️ DayType人流 C1/D1 更新失敗: %s' % e)

    # ─── 驗證 ───
    tsum = 0
    for row in top_grid:
        tsum += sum(row[0::2])
    log('頂部項目總數: %d' % tsum)
    ftot = 0
    for row in food_grid:
        ftot += sum(row[0::2])
    log('食物總數: %d' % ftot)
    dsum = 0
    for i in range(12):
        dsum += sum(drink_grid[i][0::2])
    log('飲品總數: %d' % dsum)
    log('✅ 完成 %s' % label)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception:
        log('❌ 錯誤:\n' + traceback.format_exc())
        sys.exit(1)
