#!/bin/bash
# cron_wrapper.sh — 包住一個定時任務，確保 log 有錯誤標記（由 check_cron_logs.py 統一偵測 + email）
#
# 做法：
#   1. 執行 job，捕捉 stdout/stderr + exit code
#   2. 輸出照原樣流出（cron.d 嗰行嘅 >> log 會照舊 append）
#   3. 如果 exit code != 0 但 output 冇任何錯誤標記，自動補一行「❌」落 log
#      → check_cron_logs.py 一定掃到
#
# 自己唔 send email（統一由 check_cron_logs.py 每 15 分鐘掃 log 出 alert）
#
# 用法: cron_wrapper.sh "<job_name>" <command...>
# 例:   cron_wrapper.sh "sync_sales_to_sheet" /usr/bin/python3 <merchant>/scripts/sync_sales_to_sheet.py

JOB_NAME="$1"; shift

OUT=$(mktemp /tmp/cron_wrapper.XXXXXX)

"$@" > "$OUT" 2>&1
RC=$?

# 輸出照原樣流出
cat "$OUT"

# 冇錯誤標記但 exit code 非 0 → 補一個 ❌ 標記（check_cron_logs.py 偵測用）
if [ $RC -ne 0 ] && ! grep -qiE '❌|traceback|error|failed|exception|失敗' "$OUT"; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ❌ 任務 $JOB_NAME 退出碼非零 (rc=$RC)（無錯誤訊息輸出）"
fi

rm -f "$OUT"
exit $RC
