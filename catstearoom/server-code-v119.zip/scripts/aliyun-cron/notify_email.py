#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Send alert email via Gmail SMTP (App Password, STARTTLS 587).

用法: python3 notify_email.py "<subject>" "<body>"
讀 config: <merchant>/scripts/email_config.json
"""
import json
import smtplib
import sys
import os
from email.message import EmailMessage

# email_config.json 跟 merchant folder 走（scripts 部署喺 <merchant>/scripts/），唔硬寫絕對路徑
_HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.environ.get('EMAIL_CONFIG_PATH', os.path.join(_HERE, 'email_config.json'))


def load_config():
    with open(CONFIG_PATH, encoding='utf-8') as f:
        return json.load(f)


def send(subject, body):
    cfg = load_config()
    msg = EmailMessage()
    msg['From'] = cfg['sender']
    msg['To'] = cfg['to']
    msg['Subject'] = subject
    msg.set_content(body)
    with smtplib.SMTP('smtp.gmail.com', 587, timeout=30) as s:
        s.ehlo()
        s.starttls()
        s.ehlo()
        s.login(cfg['sender'], cfg['password'])
        s.send_message(msg)


def main():
    if len(sys.argv) < 3:
        print('usage: notify_email.py "<subject>" "<body>"')
        return 2
    try:
        send(sys.argv[1], sys.argv[2])
        print('EMAIL SENT OK')
        return 0
    except Exception as e:
        print('EMAIL FAILED: %r' % e)
        return 1


if __name__ == '__main__':
    sys.exit(main())
