#!/usr/bin/env python3
"""cBOS + Auto Cafe System - download sales reports for previous month (food + drinks + system) + upload to Google Drive"""
import urllib.request, urllib.parse, http.cookiejar, re, json, os, datetime, csv, sys

CBOS_BASE = 'http://catstearoom.softether.net:8888'
OUTPUT_DIR = '/tmp/cbos_report'
DRIVE_FOLDER_ID = '13EvaF5FCXC_75Bidd3PjWmM-ZQxD9Nxt'
# 路徑跟 merchant folder 走（scripts 部署喺 <merchant>/scripts/），唔硬寫絕對路徑
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)  # <merchant>
DRIVE_TOKEN_PATH = os.environ.get('DRIVE_TOKEN_PATH', os.path.join(_HERE, 'drive_token.json'))
MONTH_NAMES = ['', 'jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']

def get_fields(html):
    def ext(n):
        m = re.search(r'id="' + n + r'" value="([^"]*)"', html)
        if not m:
            m = re.search(r'name="' + n + r'"[^>]*value="([^"]*)"', html)
        return m.group(1) if m else ''
    return ext('__VIEWSTATE'), ext('__VIEWSTATEGENERATOR'), ext('__EVENTVALIDATION')

def gen_cbos_report(opener, bsd_s, bsd_e, c1_values, filename, label):
    """Generate report from cBOS for given category and save as XLSX + CSV"""
    print('\n=== %s ===' % label)
    params = {
        'mode': 'genrpt',
        'bsd_s': bsd_s, 'bsd_e': bsd_e,
        'sn': '1,2,3,4', 'c1': c1_values,
        'c2': '', 'c3': '', 'c1_c1s1': '', 'bc': '', 'ubc': '', 'us': '',
    }
    handler_url = CBOS_BASE + '/cbos/SalesPayRptHandler.ashx?' + urllib.parse.urlencode(params)
    resp4 = opener.open(handler_url, timeout=60)
    jresult = json.loads(resp4.read().decode('utf-8', errors='replace'))
    if jresult.get('result') != '1':
        print('  Failed: ' + str(jresult))
        return False
    print('  Generated: ' + str(jresult.get('totrec', {})))

    fields = 'RowNum,SNxL,BSD,BN,RL,SCxL,USxL,BC,PNxL,UP,QU,UNxL,DP,DISC,VDA,NETSALES,AAC,FIFOCOST,COGSAAC,MARGIN,MDPxL,PMxL,PA,CCYA,PD,PATOT'
    names = ' ,shop,date,order_no,trans_no,customer,staff,barcode,item,price,qty,unit,disc_pct,discount,amount,net_sales,avg_cost,fifo_cost,cogs,margin,bill_status,payment_method,payment,payment_fcy,payment_date,total_payment'
    export_url = CBOS_BASE + '/cbos/Common/GenExcelAPI.aspx?mode=salespay&field=' + urllib.parse.quote(fields) + '&name=' + urllib.parse.quote(names)
    resp5 = opener.open(export_url, timeout=60)
    raw_data = resp5.read()

    xlsx_path = OUTPUT_DIR + '/' + filename + '.xlsx'
    with open(xlsx_path, 'wb') as f:
        f.write(raw_data)
    print('  XLSX: %s (%d bytes)' % (xlsx_path, len(raw_data)))

    try:
        import openpyxl
    except ImportError:
        os.system('pip3 install openpyxl --break-system-packages -q')
        import openpyxl

    wb = openpyxl.load_workbook(xlsx_path)
    ws = wb.active
    csv_path = OUTPUT_DIR + '/' + filename + '.csv'
    with open(csv_path, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        for row in ws.iter_rows(values_only=True):
            w.writerow(row)
    print('  CSV: ' + csv_path)
    return True

def gen_system_report(bsd_s, bsd_e):
    """Generate system.csv by querying SQLite directly with store info"""
    import sqlite3
    print('\n=== Report: System (全商品銷售) ===')

    db_path = os.environ.get('CAFE_DB_PATH', os.path.join(_ROOT, 'database', 'cafe.db'))
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute('''
        SELECT
            COALESCE(s.store_name, '未知') AS store_name,
            p.name AS product_name,
            p.category,
            p.price,
            SUM(oi.quantity) AS total_qty,
            SUM(oi.quantity * oi.price_at_time) AS total_rev
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        JOIN customers c ON oi.customer_id = c.id
        LEFT JOIN stores s ON oi.store_id = s.id
        WHERE c.is_checked_out = 1
          AND COALESCE(c.is_reversed, 0) = 0
          AND strftime('%Y-%m-%d', c.checkout_time, '+8 hours') BETWEEN ? AND ?
        GROUP BY s.store_name, p.id
        ORDER BY s.store_name, total_qty DESC
    ''', (bsd_s, bsd_e))
    rows = c.fetchall()
    conn.close()
    print('  Generated: %d rows' % len(rows))

    csv_path = OUTPUT_DIR + '/system.csv'
    with open(csv_path, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(['分店', '商品名稱', '類別', '單價', '總銷量', '總銷售額'])
        for r in rows:
            w.writerow([r['store_name'], r['product_name'], r['category'],
                        r['price'], r['total_qty'], r['total_rev']])
    print('  CSV: ' + csv_path + ' (' + str(os.path.getsize(csv_path)) + ' bytes)')
    return True

def upload_to_drive(month_label):
    """Upload all report files to Google Drive month folder, creating it if needed"""
    print('\n=== Upload to Google Drive ===')

    try:
        from google.auth.transport.requests import Request
        from google.oauth2.credentials import Credentials
        from googleapiclient.discovery import build
        from googleapiclient.http import MediaFileUpload
    except ImportError:
        print('  Installing Google API libraries...')
        os.system('pip3 install google-api-python-client google-auth --break-system-packages -q')
        from google.auth.transport.requests import Request
        from google.oauth2.credentials import Credentials
        from googleapiclient.discovery import build
        from googleapiclient.http import MediaFileUpload

    if not os.path.exists(DRIVE_TOKEN_PATH):
        print('  ERROR: Token not found at ' + DRIVE_TOKEN_PATH)
        print('  Run one-time auth first.')
        return False

    with open(DRIVE_TOKEN_PATH) as f:
        token_data = json.load(f)

    creds = Credentials(
        token=token_data['token'],
        refresh_token=token_data['refresh_token'],
        token_uri=token_data['token_uri'],
        client_id=token_data['client_id'],
        client_secret=token_data['client_secret'],
        scopes=token_data.get('scopes', ['https://www.googleapis.com/auth/drive.file'])
    )

    # Refresh if expired
    if creds.expired and creds.refresh_token:
        print('  Token expired, refreshing...')
        creds.refresh(Request())
        # Save refreshed token
        token_data['token'] = creds.token
        with open(DRIVE_TOKEN_PATH, 'w') as f:
            json.dump(token_data, f, indent=2)
        print('  Token refreshed and saved.')

    service = build('drive', 'v3', credentials=creds)

    # Find or create month folder
    month_folder_name = month_label
    query = "name='%s' and '%s' in parents and trashed=false and mimeType='application/vnd.google-apps.folder'" % (month_folder_name, DRIVE_FOLDER_ID)
    results = service.files().list(q=query, fields='files(id, name)').execute()
    folders = results.get('files', [])

    if folders:
        folder_id = folders[0]['id']
        print('  Found folder: %s (%s)' % (month_folder_name, folder_id))
    else:
        file_meta = {
            'name': month_folder_name,
            'mimeType': 'application/vnd.google-apps.folder',
            'parents': [DRIVE_FOLDER_ID]
        }
        folder = service.files().create(body=file_meta, fields='id').execute()
        folder_id = folder['id']
        print('  Created folder: %s (%s)' % (month_folder_name, folder_id))

    # Files to upload
    files_to_upload = [
        'erun_food.xlsx', 'erun_food.csv',
        'erun_drink.xlsx', 'erun_drink.csv',
        'system.csv'
    ]

    for filename in files_to_upload:
        file_path = os.path.join(OUTPUT_DIR, filename)
        if not os.path.exists(file_path):
            print('  SKIP (not found): ' + filename)
            continue

        # Check if file already exists in folder
        query = "name='%s' and '%s' in parents and trashed=false" % (filename, folder_id)
        existing = service.files().list(q=query, fields='files(id, name)').execute()
        existing_files = existing.get('files', [])

        file_size = os.path.getsize(file_path)
        mime_type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' if filename.endswith('.xlsx') else 'text/csv'

        if existing_files:
            # Update existing file
            file_id = existing_files[0]['id']
            media = MediaFileUpload(file_path, mimetype=mime_type)
            service.files().update(fileId=file_id, media_body=media).execute()
            print('  UPDATED: %s (%s, %d bytes)' % (filename, file_id, file_size))
        else:
            # Upload new file
            file_meta = {'name': filename, 'parents': [folder_id]}
            media = MediaFileUpload(file_path, mimetype=mime_type)
            service.files().create(body=file_meta, media_body=media, fields='id').execute()
            print('  UPLOADED: %s (%d bytes)' % (filename, file_size))

    print('  Google Drive upload complete!')
    print('  https://drive.google.com/drive/folders/' + DRIVE_FOLDER_ID)
    return True

def main():
    # Auto-calculate previous month
    today = datetime.date.today()
    prev_month_end = today.replace(day=1) - datetime.timedelta(days=1)
    prev_month_start = prev_month_end.replace(day=1)

    # Folder name: e.g. jun26
    month_label = MONTH_NAMES[prev_month_start.month] + str(prev_month_start.year)[-2:]
    print('Folder: ' + month_label)

    global OUTPUT_DIR
    OUTPUT_DIR = '/tmp/cbos_report/' + month_label
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    bsd_slash = prev_month_start.strftime('%Y/%m/%d')
    bsd_e_slash = prev_month_end.strftime('%Y/%m/%d')
    bsd_dash = prev_month_start.strftime('%Y-%m-%d')
    bsd_e_dash = prev_month_end.strftime('%Y-%m-%d')
    print('Date: %s ~ %s' % (bsd_slash, bsd_e_slash))

    # ─── cBOS Reports ───
    print('\n=== cBOS Login ===')
    cj = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    opener.addheaders = [('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')]
    resp = opener.open(CBOS_BASE + '/cbos/', timeout=30)
    vs, vsg, ev = get_fields(resp.read().decode('utf-8', errors='replace'))
    data = urllib.parse.urlencode({'__VIEWSTATE': vs, '__VIEWSTATEGENERATOR': vsg, '__EVENTVALIDATION': ev, 'txtUsername': '501', 'txtPassword': 'abcd1111'}).encode()
    opener.open(CBOS_BASE + '/cbos/', data=data, timeout=30)
    opener.open(CBOS_BASE + '/cbos/SalesPayRpt.aspx', timeout=30)
    print('cBOS Login OK')

    gen_cbos_report(opener, bsd_slash, bsd_e_slash, '2,4,5', 'erun_food', 'CBOS: Food (蛋糕+三文治+曲奇)')
    gen_cbos_report(opener, bsd_slash, bsd_e_slash, '1', 'erun_drink', 'CBOS: Drinks (飲品)')

    # ─── Auto Cafe System Report ───
    gen_system_report(bsd_dash, bsd_e_dash)

    # ─── Upload to Google Drive ───
    upload_to_drive(month_label)

    print('\nAll done!')
    return 0

if __name__ == '__main__':
    exit(main())
