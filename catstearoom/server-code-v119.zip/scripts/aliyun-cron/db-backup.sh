#!/bin/bash
# 自動咖啡館系統 - Database 每日備份腳本
# 每天香港時間 03:00 執行，保留最近 30 天備份

# 路徑跟 merchant folder 走（scripts 部署喺 <merchant>/scripts/），唔硬寫絕對路徑
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MERCHANT_ROOT="$(dirname "$SCRIPT_DIR")"
BACKUP_DIR="$MERCHANT_ROOT/database/backup"
DB_FILE="$MERCHANT_ROOT/database/cafe.db"
RETENTION_DAYS=30

# 確保備份目錄存在
mkdir -p "$BACKUP_DIR"

# 產生檔名：cafe.db.YYYYMMDD.sqlite.gz
DATE_TAG=$(TZ=Asia/Hong_Kong date +%Y%m%d)
BACKUP_FILE="$BACKUP_DIR/cafe.db.$DATE_TAG.sqlite.gz"

# 用 sqlite3 做 online backup（唔使停 server）
sqlite3 "$DB_FILE" ".backup /tmp/cafe_backup_temp.db" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "[$(TZ=Asia/Hong_Kong date '+%Y-%m-%d %H:%M:%S')] ERROR: sqlite3 backup failed" >> "$BACKUP_DIR/backup.log"
    exit 1
fi

# 壓縮
gzip -c /tmp/cafe_backup_temp.db > "$BACKUP_FILE"
rm -f /tmp/cafe_backup_temp.db

# 記錄
echo "[$(TZ=Asia/Hong_Kong date '+%Y-%m-%d %H:%M:%S')] OK: $BACKUP_FILE ($(ls -lh "$BACKUP_FILE" | awk '{print $5}'))" >> "$BACKUP_DIR/backup.log"

# 清理超過 30 日嘅舊 backup
find "$BACKUP_DIR" -name 'cafe.db.*.sqlite.gz' -mtime +"$RETENTION_DAYS" -delete
