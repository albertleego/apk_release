#!/usr/bin/env python3
"""
每日各分店人數同步至 Google Sheet
每天香港時間 23:00 執行，將當日各分店結賬總人數寫入對應 Sheet 的 B 欄

排程設定（crontab）：
  0 23 * * * /usr/bin/python3 <merchant>/scripts/sync_sales_to_sheet.py >> <merchant>/scripts/logs/sheets_cron.log 2>&1

查看排程：crontab -l
查看日誌：tail -f <merchant>/scripts/logs/sheets_cron.log
"""

import sqlite3
import sys
from datetime import datetime, timedelta, timezone

import gspread
from google.oauth2.service_account import Credentials

# ─── 設定 ─────────────────────────────────────────────────────────
# 路徑跟 merchant folder 走（scripts 部署喺 <merchant>/scripts/），唔硬寫絕對路徑
import os
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)  # <merchant>
DB_PATH = os.environ.get('CAFE_DB_PATH', os.path.join(_ROOT, 'database', 'cafe.db'))
KEY_PATH = os.environ.get('SHEETS_KEY_PATH', os.path.join(_HERE, 'google-sheets-key.json'))

# store_id → { name, sheet_key }
STORES = {
    'store_1': {
        'name': '荃灣',
        'key': '1XC3wTfSeQfgjvup_MV8k-a316TXN7OXhlkYLoBggccA',
    },
    'store_2': {
        'name': '尖沙咀',
        'key': '13gSuUY5aY-hHBAS6SwUO69iyJqPxVN6BjM5hlWdCUWE',
    },
    'store_3': {
        'name': '旺角',
        'key': '1CoeNRrPbH13uXRDBEj5-fAsDDHyiOiOIRtXuZwoO_pg',
    },
    'store_4': {
        'name': '銅鑼灣',
        'key': '12EXWyrE_UZ9VG0B-zyl_eE17QxSDRBKE4c6ot8I4XbY',
    },
}

SCOPE = [
    'https://spreadsheets.google.com/feeds',
    'https://www.googleapis.com/auth/drive',
]

LOG_PREFIX = 'sync_sales_to_sheet'
# ─────────────────────────────────────────────────────────────────


def log(msg: str):
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(f'[{timestamp}] {LOG_PREFIX} {msg}')
    sys.stdout.flush()


def get_today_hk() -> str:
    """回傳香港時間的『今日』日期 YYYY-MM-DD（香港 = UTC+8）"""
    hk = timezone(timedelta(hours=8))
    return datetime.now(hk).strftime('%Y-%m-%d')


def get_month_sheet_name(date_str: str = None) -> str:
    """回傳當月的 sheet 名稱，例如 '26年7月'（西年後兩碼）"""
    if date_str:
        dt = datetime.strptime(date_str, '%Y-%m-%d')
    else:
        hk = timezone(timedelta(hours=8))
        dt = datetime.now(hk)
    short_year = str(dt.year)[-2:]  # 取後兩位，如 2026 → 26
    return f'{short_year}年{dt.month}月'


def get_date_label(date_str: str) -> str:
    """將 YYYY-MM-DD 轉為 Sheet 中的日期格式，例如 '2026年7月8日'"""
    dt = datetime.strptime(date_str, '%Y-%m-%d')
    return f'{dt.year}年{dt.month}月{dt.day}日'


def fetch_daily_data(date_str: str) -> dict:
    """
    從 cafe.db 查詢指定日期的各分店結賬總人數及總營業額。

    回傳：
        {
            'store_1': { 'store_name': '荃灣', 'customer_count': 39, 'total_revenue': 12345.0 },
            'store_2': { ... },
            ...
        }
    """
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    # checkout_time 格式: '2026-07-07T23:30:04.129Z' (UTC)
    # 香港 = UTC+8，需要 +8 小時後再取日期
    # 客數 = SUM(people_count) 結賬客人總人數
    # 營業額 = SUM(total_amount) 結賬客人總金額
    c.execute("""
        SELECT
            c.store_id,
            s.store_name,
            COALESCE(SUM(c.people_count), 0)    AS customer_count,
            COALESCE(SUM(c.total_amount), 0)    AS total_revenue
        FROM customers c
        JOIN stores s ON c.store_id = s.id
        WHERE c.checkout_time IS NOT NULL
          AND DATE(
              DATETIME(REPLACE(SUBSTR(c.checkout_time, 1, 19), 'T', ' '), '+8 hours')
          ) = ?
          AND c.is_checked_out = 1
        GROUP BY c.store_id
    """, (date_str,))

    result = {}
    for r in c.fetchall():
        result[r['store_id']] = {
            'store_name': r['store_name'],
            'customer_count': r['customer_count'],
            'total_revenue': r['total_revenue'],
        }
    conn.close()
    return result


def update_store_sheet(
    client: gspread.Client,
    store_cfg: dict,
    date_label: str,
    month_sheet: str,
    customer_count: int,
    total_revenue: float,
) -> bool:
    """
    將一間分店的人數寫入對應的 Google Sheet B 欄。
    同時計算結算差額 = C欄(手入營業額) - DB營業額，寫入 AE 欄。
    - 找到當月 sheet
    - 掃描 A 欄比對日期
    - 更新 B 欄（人數）
    - 更新 AE 欄（結算差額 = DB營業額 - C欄手入營業額）
    """
    try:
        sh = client.open_by_key(store_cfg['key'])

        # 找對應月份的 sheet
        try:
            ws = sh.worksheet(month_sheet)
        except gspread.WorksheetNotFound:
            log(f'  ⚠️ {store_cfg["name"]}: 找不到 sheet "{month_sheet}"，跳過')
            return False

        # 讀取 A 欄所有日期
        all_a = ws.col_values(1)  # 第 1 欄 = A
        target_row = None
        for i, val in enumerate(all_a):
            if val == date_label:
                target_row = i + 1  # 1-based row
                break

        if target_row is None:
            log(f'  ⚠️ {store_cfg["name"]}: 找不到日期 "{date_label}"，跳過')
            return False

        # 1. 更新 B 欄（人數）
        ws.update(range_name=f'B{target_row}', values=[[customer_count]])

        # 2. 讀取 C 欄（手入營業額）
        c_val = ws.cell(target_row, 3).value  # 第 3 欄 = C
        c_amount = 0.0
        if c_val:
            try:
                # 移除逗號、貨幣符號等，取純數字
                cleaned = c_val.replace(',', '').replace('$', '').replace(' ', '')
                c_amount = float(cleaned)
            except ValueError:
                c_amount = 0.0

        # 3. 計算結算差額 = C欄手入營業額 - DB營業額
        diff = round(c_amount - total_revenue, 2)

        # 4. 更新 AE 欄（結算差額，第 31 欄）
        ws.update(range_name=f'AE{target_row}', values=[[diff]])

        log(f'  ✅ {store_cfg["name"]}: 第{target_row}行 B={customer_count}人 C={c_amount} DB營業額={total_revenue} 差額={diff}')
        return True

    except Exception as e:
        log(f'  ❌ {store_cfg["name"]}: 寫入失敗 - {e}')
        return False


def main():
    log('=== 開始同步 ===')

    # 1. 取得日期（可帶參數指定日期，如: python3 sync_sales_to_sheet.py 2026-08-04）
    date_str = sys.argv[1] if len(sys.argv) > 1 else get_today_hk()
    date_label = get_date_label(date_str)
    month_sheet = get_month_sheet_name(date_str)
    log(f'目標日期: {date_str} → {date_label}')
    log(f'目標 sheet: {month_sheet}')

    # 2. 查詢各分店今日結賬總人數及營業額
    customers_data = fetch_daily_data(date_str)
    log(f'查詢到 {len(customers_data)} 間分店的資料')
    for sid, data in customers_data.items():
        log(f'  {data["store_name"]} ({sid}): {data["customer_count"]} 人, 營業額 {data["total_revenue"]}')

    if not customers_data:
        log('⚠️ 無任何分店資料')

    # 3. 連線 Google Sheets
    creds = Credentials.from_service_account_file(KEY_PATH, scopes=SCOPE)
    client = gspread.authorize(creds)

    # 4. 逐間分店寫入（更新 B 欄人數 + AE 欄結算差額）
    success_count = 0
    for store_id, store_cfg in STORES.items():
        if store_id in customers_data:
            data = customers_data[store_id]
            ok = update_store_sheet(
                client, store_cfg,
                date_label, month_sheet,
                data['customer_count'],
                data['total_revenue'],
            )
            if ok:
                success_count += 1
        else:
            log(f'  ⏭️ {store_cfg["name"]}: 無資料，跳過')

    # 5. 總結
    log(f'✅ 同步完成: {success_count}/{len(STORES)} 間分店更新成功')


if __name__ == '__main__':
    main()
