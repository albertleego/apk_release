const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');
const hongKongTime = require('../server/utils/hongKongTime');

const dbPath = path.join(__dirname, 'cafe.db');
let db = new sqlite3.Database(dbPath);

// WAL 模式 + busy_timeout：防止 I/O 中斷導致的資料庫損壞
db.serialize(() => {
  db.run('PRAGMA journal_mode = WAL');
  db.run('PRAGMA synchronous = NORMAL');
  db.run('PRAGMA busy_timeout = 30000');
});

// 可重試的錯誤碼（SQLITE_BUSY=鎖等待, SQLITE_LOCKED=表鎖,
// SQLITE_READONLY=journal損壞, SQLITE_IOERR=磁碟I/O失敗）
const RETRIABLE_CODES = ['SQLITE_BUSY', 'SQLITE_LOCKED', 'SQLITE_READONLY', 'SQLITE_IOERR'];
const MAX_DB_RETRIES = 3;

function wrapDbMethods() {
  ['run', 'get', 'all'].forEach(method => {
    const original = db[method].bind(db);
    db[method] = function sqliteRetryWrapper(sql, params, callback) {
      // 正規化參數：處理 (sql, callback) 或 (sql, params, callback)
      if (typeof params === 'function') { callback = params; params = undefined; }
      else if (params !== undefined && !Array.isArray(params)) params = [params];

      let retriesLeft = MAX_DB_RETRIES;
      const tryExec = () => {
        const done = function sqliteRetryCb() {
          const err = arguments[0];
          if (err && retriesLeft > 0 &&
              RETRIABLE_CODES.some(c => err.code === c || (err.message && err.message.includes(c)))) {
            retriesLeft--;
            if (err.code === 'SQLITE_READONLY' || (err.message && err.message.includes('SQLITE_READONLY'))) {
              console.warn('⚠️ SQLITE_READONLY 偵測到，正在重新連線資料庫...');
              reconnectDb();
            } else if (err.code === 'SQLITE_BUSY' || (err.message && err.message.includes('SQLITE_BUSY'))) {
              console.warn(`⚠️ SQLITE_BUSY，第 ${MAX_DB_RETRIES - retriesLeft}/${MAX_DB_RETRIES} 次重試`);
            }
            setTimeout(tryExec, 1000);
            return;
          }
          if (callback) callback.apply(this, arguments);
        };
        if (params !== undefined) original(sql, params, done);
        else original(sql, done);
      };
      tryExec();
    };
  });
}

function reconnectDb() {
  try { db.close(); } catch (e) { /* 可能已經關閉 */ }
  db = new sqlite3.Database(dbPath);
  db.serialize(() => {
    db.run('PRAGMA journal_mode = WAL');
    db.run('PRAGMA synchronous = NORMAL');
    db.run('PRAGMA busy_timeout = 30000');
  });
  wrapDbMethods();
  console.log('✅ 資料庫已重新連線');
}

wrapDbMethods();

// 初始化數據庫表
const initDatabase = () => {
  db.serialize(() => {
    // 客人表
    db.run(`
      CREATE TABLE IF NOT EXISTS customers (
        id TEXT PRIMARY KEY,
        table_number TEXT NOT NULL,
        qr_code TEXT UNIQUE NOT NULL,
        people_count INTEGER NOT NULL,
        entry_time DATETIME DEFAULT CURRENT_TIMESTAMP,
        checkout_time DATETIME,
        total_amount REAL DEFAULT 0,
        is_checked_out INTEGER DEFAULT 0,
        is_member INTEGER DEFAULT 0,
        member_card_id TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        lockers_used TEXT DEFAULT NULL, -- 儲存使用的儲物柜列表（逗號分隔）
        checkout_pending INTEGER DEFAULT 0, -- 結賬確認鎖定: 1=確認視窗開啟中, 計費scheduler跳過
        checkout_pending_at DATETIME -- 結賬鎖定起始時間（用於5分鐘超時自動解鎖）
      )
    `);

    // 確保lockers_used字段存在（兼容現有數據庫）
    db.run(`
      ALTER TABLE customers ADD COLUMN lockers_used TEXT DEFAULT NULL
    `, (err) => {
      // 忽略錯誤（字段已存在）
      if (err && !err.message.includes('duplicate column name')) {
        console.error('添加lockers_used字段錯誤:', err);
      }
    });

    // 確保結賬鎖定字段存在（兼容現有數據庫）
    db.run(`
      ALTER TABLE customers ADD COLUMN checkout_pending INTEGER DEFAULT 0
    `, (err) => {
      // 忽略錯誤（字段已存在）
      if (err && !err.message.includes('duplicate column name')) {
        console.error('添加checkout_pending字段錯誤:', err);
      }
    });
    db.run(`
      ALTER TABLE customers ADD COLUMN checkout_pending_at DATETIME
    `, (err) => {
      // 忽略錯誤（字段已存在）
      if (err && !err.message.includes('duplicate column name')) {
        console.error('添加checkout_pending_at字段錯誤:', err);
      }
    });

    // 確保「重設入場時間」字段存在（兼容現有數據庫）
    // entry_time_original: 首次重設時記錄的原始入場時間（之後唔覆寫），用於紅線顯示舊時間
    // entry_time_modified_by: 執行重設嘅員工
    // entry_time_modified_at: 重設時間
    db.run(`
      ALTER TABLE customers ADD COLUMN entry_time_original DATETIME
    `, (err) => {
      // 忽略錯誤（字段已存在）
      if (err && !err.message.includes('duplicate column name')) {
        console.error('添加entry_time_original字段錯誤:', err);
      }
    });
    db.run(`
      ALTER TABLE customers ADD COLUMN entry_time_modified_by TEXT
    `, (err) => {
      // 忽略錯誤（字段已存在）
      if (err && !err.message.includes('duplicate column name')) {
        console.error('添加entry_time_modified_by字段錯誤:', err);
      }
    });
    db.run(`
      ALTER TABLE customers ADD COLUMN entry_time_modified_at DATETIME
    `, (err) => {
      // 忽略錯誤（字段已存在）
      if (err && !err.message.includes('duplicate column name')) {
        console.error('添加entry_time_modified_at字段錯誤:', err);
      }
    });

    // 商品表
    db.run(`
      CREATE TABLE IF NOT EXISTS products (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        price REAL NOT NULL,
        stock INTEGER DEFAULT 0,
        locker_number INTEGER, -- 對應的儲物柜編號
        is_available INTEGER DEFAULT 1,
        category TEXT DEFAULT 'general',
        min_stock INTEGER DEFAULT 10,
        supplier TEXT,
        cost_price REAL,
        last_restocked DATETIME,
        track_inventory INTEGER DEFAULT 1, -- 是否跟踪庫存: 1=跟踪, 0=不計庫存
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // 訂單項目表（客人購買的商品）
    db.run(`
      CREATE TABLE IF NOT EXISTS order_items (
        id TEXT PRIMARY KEY,
        customer_id TEXT NOT NULL,
        product_id TEXT NOT NULL,
        quantity INTEGER DEFAULT 1,
        price_at_time REAL NOT NULL,
        purchased_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        employee_id TEXT,
        FOREIGN KEY (customer_id) REFERENCES customers (id),
        FOREIGN KEY (product_id) REFERENCES products (id),
        FOREIGN KEY (employee_id) REFERENCES employees (id)
      )
    `);

    // 桌位表
    db.run(`
      CREATE TABLE IF NOT EXISTS tables (
        id TEXT PRIMARY KEY,
        table_number TEXT UNIQUE NOT NULL,
        capacity INTEGER NOT NULL,
        is_occupied INTEGER DEFAULT 0,
        current_customer_id TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (current_customer_id) REFERENCES customers (id)
      )
    `);

    // 儲物柜表
    db.run(`
      CREATE TABLE IF NOT EXISTS lockers (
        id TEXT PRIMARY KEY,
        locker_number INTEGER NOT NULL,
        store_id TEXT NOT NULL DEFAULT 'default_store',
        is_occupied INTEGER DEFAULT 0,
        customer_id TEXT,
        opened_at DATETIME,
        closed_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (customer_id) REFERENCES customers (id),
        FOREIGN KEY (store_id) REFERENCES stores (id),
        UNIQUE(store_id, locker_number)
      )
    `);

    // 設備狀態表
    db.run(`
      CREATE TABLE IF NOT EXISTS devices (
        id TEXT PRIMARY KEY,
        device_type TEXT NOT NULL, -- 'entry', 'exit', 'lock', 'locker', 'vending', 'printer'
        device_id TEXT UNIQUE NOT NULL,
        status TEXT DEFAULT 'offline', -- 'online', 'offline', 'error'
        last_seen DATETIME,
        ip_address TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // 會員表
    db.run(`
      CREATE TABLE IF NOT EXISTS members (
        id TEXT PRIMARY KEY,
        card_id TEXT UNIQUE NOT NULL,
        name TEXT,
        phone TEXT,
        balance REAL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // 交易記錄表
    db.run(`
      CREATE TABLE IF NOT EXISTS transactions (
        id TEXT PRIMARY KEY,
        customer_id TEXT NOT NULL,
        transaction_type TEXT NOT NULL, -- 'entry', 'purchase', 'checkout'
        amount REAL NOT NULL,
        description TEXT,
        employee_id TEXT,
        payment_method TEXT, -- 'cash', 'card', 'member'
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (customer_id) REFERENCES customers (id),
        FOREIGN KEY (employee_id) REFERENCES employees (id)
      )
    `);

    // ==================== 新增表（收銀系統增強） ====================

    // 員工帳戶表
    db.run(`
      CREATE TABLE IF NOT EXISTS employees (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        role TEXT NOT NULL, -- 'admin', 'staff'
        email TEXT,
        phone TEXT,
        store_id TEXT, -- 分店ID，staff員工必須指定，admin可為NULL
        is_active INTEGER DEFAULT 1,
        last_login DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (store_id) REFERENCES stores (id)
      )
    `);

    // 確保employees表包含store_id字段（兼容現有數據庫）
    db.run(`
      ALTER TABLE employees ADD COLUMN store_id TEXT
    `, (err) => {
      // 忽略字段已存在的錯誤
      if (err && !err.message.includes('duplicate column name')) {
        console.error('添加employees.store_id字段錯誤:', err);
      }
    });

    // 會話管理表
    db.run(`
      CREATE TABLE IF NOT EXISTS sessions (
        id TEXT PRIMARY KEY,
        employee_id TEXT NOT NULL,
        token TEXT UNIQUE NOT NULL,
        ip_address TEXT,
        user_agent TEXT,
        expires_at DATETIME NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (employee_id) REFERENCES employees (id)
      )
    `);

    // 操作日誌表
    db.run(`
      CREATE TABLE IF NOT EXISTS audit_logs (
        id TEXT PRIMARY KEY,
        employee_id TEXT,
        action_type TEXT NOT NULL, -- 'login', 'logout', 'product_add', 'product_edit', 'order_create', 'checkout', 'stock_update', 'report_generate'
        action_details TEXT,
        ip_address TEXT,
        store_id TEXT NOT NULL DEFAULT 'default_store',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (employee_id) REFERENCES employees (id)
      )
    `);

    // 確保audit_logs表包含store_id字段（兼容現有數據庫）
    db.run(`
      ALTER TABLE audit_logs ADD COLUMN store_id TEXT DEFAULT 'default_store'
    `, (err) => {
      // 忽略錯誤（字段已存在）
      if (err && !err.message.includes('duplicate column name')) {
        console.error('添加audit_logs表store_id字段錯誤:', err);
      }
    });

    // 通知表
    db.run(`
      CREATE TABLE IF NOT EXISTS notifications (
        id TEXT PRIMARY KEY,
        notification_type TEXT NOT NULL, -- 'system', 'order', 'stock', 'customer'
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        is_read INTEGER DEFAULT 0,
        recipient_id TEXT, -- NULL表示廣播給所有員工
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // 報告表
    db.run(`
      CREATE TABLE IF NOT EXISTS reports (
        id TEXT PRIMARY KEY,
        report_type TEXT NOT NULL, -- 'daily', 'weekly', 'monthly', 'custom'
        report_date DATE NOT NULL,
        data JSON NOT NULL, -- 報告數據（JSON格式）
        generated_by TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (generated_by) REFERENCES employees (id)
      )
    `);

    // 庫存變更記錄表
    db.run(`
      CREATE TABLE IF NOT EXISTS inventory_logs (
        id TEXT PRIMARY KEY,
        product_id TEXT NOT NULL,
        employee_id TEXT NOT NULL,
        change_type TEXT NOT NULL, -- 'add', 'remove', 'adjust', 'sale'
        quantity_change INTEGER NOT NULL,
        previous_quantity INTEGER NOT NULL,
        new_quantity INTEGER NOT NULL,
        reason TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products (id),
        FOREIGN KEY (employee_id) REFERENCES employees (id)
      )
    `);

    // ==================== 多分店支持表 ====================

    // 分店信息表
    db.run(`
      CREATE TABLE IF NOT EXISTS stores (
        id TEXT PRIMARY KEY,
        store_code TEXT UNIQUE NOT NULL,   -- 分店代碼: STORE01, STORE02
        store_name TEXT NOT NULL,          -- 分店名稱
        address TEXT,
        phone TEXT,
        email TEXT,
        opening_hours TEXT,
        description TEXT,
        timezone TEXT DEFAULT 'Asia/Hong_Kong',
        is_active INTEGER DEFAULT 1,
        status TEXT DEFAULT 'active',      -- active, maintenance, closed
        settings TEXT DEFAULT '{"timezone": "Asia/Hong_Kong", "currency": "HKD"}',
        use_lockers INTEGER DEFAULT 1,     -- 是否使用儲物柜: 1=使用, 0=不使用
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // 確保stores表包含所有必要字段（兼容現有數據庫）
    console.log('檢查stores表字段...');

    // 分開執行每個ALTER TABLE，避免一個錯誤導致全部失敗
    const addColumnIfNotExists = (columnName, columnDefinition, callback) => {
      db.run(`ALTER TABLE stores ADD COLUMN ${columnName} ${columnDefinition}`, (err) => {
        if (err) {
          if (err.message.includes('duplicate column name')) {
            console.log(`字段 ${columnName} 已存在，忽略錯誤`);
            callback(null);
          } else {
            console.error(`添加字段 ${columnName} 錯誤:`, err);
            callback(err);
          }
        } else {
          console.log(`成功添加字段 ${columnName}（如果不存在）`);
          callback(null);
        }
      });
    };

    // 逐一添加字段
    addColumnIfNotExists('email', 'TEXT', (err1) => {
      if (err1) return;
      addColumnIfNotExists('opening_hours', 'TEXT', (err2) => {
        if (err2) return;
        addColumnIfNotExists('description', 'TEXT', (err3) => {
          if (err3) return;
          addColumnIfNotExists('status', 'TEXT DEFAULT "active"', (err4) => {
            if (err4) return;
            addColumnIfNotExists('settings', 'TEXT DEFAULT \'{"timezone": "Asia/Hong_Kong", "currency": "HKD"}\'', (err5) => {
              if (err5) return;
              addColumnIfNotExists('use_lockers', 'INTEGER DEFAULT 1', (err6) => {
                if (err6) return;
                console.log('所有stores表字段檢查完成');
              });
            });
          });
        });
      });
    });

    // 分店配置表 (存儲分店特定配置)
    db.run(`
      CREATE TABLE IF NOT EXISTS store_configs (
        id TEXT PRIMARY KEY,
        store_id TEXT NOT NULL,
        config_key TEXT NOT NULL,          -- 配置鍵名
        config_value TEXT,                 -- 配置值 (JSON格式)
        config_type TEXT DEFAULT 'string', -- 類型: string, number, boolean, json
        description TEXT,
        is_system INTEGER DEFAULT 0,       -- 是否系統配置 (不可刪除)
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(store_id, config_key),
        FOREIGN KEY (store_id) REFERENCES stores (id)
      )
    `);

    // 打印機配置表 (存儲小票機配置)
    db.run(`
      CREATE TABLE IF NOT EXISTS printer_configs (
        id TEXT PRIMARY KEY,
        store_id TEXT NOT NULL,
        printer_name TEXT NOT NULL,
        connection_type TEXT NOT NULL, -- 'wifi', 'bluetooth', 'usb'
        ip_address TEXT,
        port INTEGER DEFAULT 9100,
        bluetooth_address TEXT,
        printer_type TEXT DEFAULT 'epson', -- 'epson', 'star', 'zebra', 'custom'
        is_default INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (store_id) REFERENCES stores (id)
      )
    `);

    // 確保bluetooth_address字段存在（兼容舊版本）
    db.run(`ALTER TABLE printer_configs ADD COLUMN bluetooth_address TEXT`, (err) => {
      if (err && !err.message.includes('duplicate column name')) {
        console.error('添加bluetooth_address字段錯誤:', err);
      }
    });

    // ==================== KPay 卡機收款 ====================

    // KPay 支付記錄表（離場機卡機收款，每筆支付一行）
    db.run(`
      CREATE TABLE IF NOT EXISTS kpay_payments (
        id TEXT PRIMARY KEY,
        customer_id TEXT NOT NULL,
        out_trade_no TEXT UNIQUE NOT NULL,
        amount REAL NOT NULL,
        payment_type INTEGER,
        status TEXT DEFAULT 'pending',      -- pending|success|failed|cancelled|timeout
        pay_method INTEGER,                 -- KPay payMethod: 1=Visa 2=Master 4=微信 5=支付寶 12=PayMe 14=FPS
        transaction_no TEXT,
        ref_no TEXT,
        store_id TEXT NOT NULL DEFAULT 'default_store',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        paid_at DATETIME,
        FOREIGN KEY (customer_id) REFERENCES customers (id)
      )
    `);

    // KPay 分店配置表（per-store singleton，未設時用 .env fallback）
    db.run(`
      CREATE TABLE IF NOT EXISTS kpay_configs (
        store_id TEXT PRIMARY KEY,
        mode TEXT DEFAULT 'lan',            -- mock|lan
        kpos_ip TEXT,
        kpos_port INTEGER DEFAULT 18080,
        app_id TEXT,
        app_secret TEXT,
        callback_url TEXT,
        enabled INTEGER DEFAULT 0,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (store_id) REFERENCES stores (id)
      )
    `);

    // KPay 支付記錄索引
    db.run(`CREATE INDEX IF NOT EXISTS idx_kpay_payments_customer ON kpay_payments(customer_id)`);

    // 小票模板表 (存儲收銀小票模板)
    db.run(`
      CREATE TABLE IF NOT EXISTS receipt_templates (
        id TEXT PRIMARY KEY,
        template_name TEXT NOT NULL,
        store_id TEXT,                      -- NULL表示適用所有分店
        is_default INTEGER DEFAULT 0,       -- 是否為默認模板
        config JSON NOT NULL,               -- 模板配置 (JSON格式)
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        created_by TEXT,                    -- 創建者員工ID
        FOREIGN KEY (store_id) REFERENCES stores (id),
        FOREIGN KEY (created_by) REFERENCES employees (id)
      )
    `);

    // 數據同步記錄表 (記錄本地與中央服務器同步狀態)
    db.run(`
      CREATE TABLE IF NOT EXISTS sync_logs (
        id TEXT PRIMARY KEY,
        store_id TEXT NOT NULL,
        sync_type TEXT NOT NULL,           -- 同步類型: full(全量), incremental(增量), manual(手動)
        table_name TEXT NOT NULL,          -- 表名: customers, products, etc
        record_id TEXT,                    -- 記錄ID (NULL表示批量同步)
        operation TEXT,                    -- 操作: create, update, delete (NULL表示批量)
        sync_direction TEXT NOT NULL,      -- 方向: upload(上傳), download(下載)
        status TEXT DEFAULT 'pending',     -- 狀態: pending, success, failed, conflict
        error_message TEXT,
        retry_count INTEGER DEFAULT 0,
        synced_at DATETIME,                -- 同步完成時間
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (store_id) REFERENCES stores (id)
      )
    `);

    // ==================== 創建索引 ====================
    console.log('創建索引...');

    // 員工表索引
    db.run(`CREATE INDEX IF NOT EXISTS idx_employees_username ON employees(username)`);

    // 會話表索引
    db.run(`CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_sessions_employee_id ON sessions(employee_id)`);

    // 操作日誌表索引
    db.run(`CREATE INDEX IF NOT EXISTS idx_audit_logs_employee_id ON audit_logs(employee_id)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at)`);

    // 通知表索引
    db.run(`CREATE INDEX IF NOT EXISTS idx_notifications_recipient ON notifications(recipient_id, is_read)`);

    // 報告表索引
    db.run(`CREATE INDEX IF NOT EXISTS idx_reports_report_date ON reports(report_date)`);

    // 庫存變更記錄表索引
    db.run(`CREATE INDEX IF NOT EXISTS idx_inventory_logs_product_id ON inventory_logs(product_id)`);

    // 分店表索引
    db.run(`CREATE INDEX IF NOT EXISTS idx_stores_store_code ON stores(store_code)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_stores_is_active ON stores(is_active)`);

    // 分店配置表索引
    db.run(`CREATE INDEX IF NOT EXISTS idx_store_configs_store_key ON store_configs(store_id, config_key)`);

    // 小票模板表索引
    db.run(`CREATE INDEX IF NOT EXISTS idx_receipt_templates_store_id ON receipt_templates(store_id)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_receipt_templates_is_default ON receipt_templates(is_default)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_receipt_templates_created_at ON receipt_templates(created_at)`);

    // 打印機配置表索引
    db.run(`CREATE INDEX IF NOT EXISTS idx_printer_configs_store_id ON printer_configs(store_id)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_printer_configs_default ON printer_configs(store_id, is_default)`);

    // 同步記錄表索引
    db.run(`CREATE INDEX IF NOT EXISTS idx_sync_logs_store_status ON sync_logs(store_id, status)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_sync_logs_created_at ON sync_logs(created_at)`);

    // 商品表索引
    db.run(`CREATE INDEX IF NOT EXISTS idx_products_category ON products(category)`);

    // ==================== 添加分店支持字段 ====================
    console.log('添加分店支持字段...');

    // 首先創建默認分店（如果不存在）
    db.get(`SELECT COUNT(*) as count FROM stores`, (err, row) => {
        if (err) {
            console.error('檢查分店數量錯誤:', err);
            return;
        }

        if (row.count === 0) {
            console.log('創建默認分店...');
            db.run(
                `INSERT INTO stores (id, store_code, store_name, address, timezone, is_active)
                 VALUES (?, ?, ?, ?, ?, ?)`,
                [
                    'default_store',
                    'DEFAULT',
                    '默認分店',
                    '香港',
                    'Asia/Hong_Kong',
                    1
                ],
                function(insertErr) {
                    if (insertErr) {
                        console.error('創建默認分店錯誤:', insertErr);
                    } else {
                        console.log('默認分店創建成功: DEFAULT (默認分店)');
                    }
                }
            );
        } else {
            console.log(`已有 ${row.count} 個分店存在`);
        }
    });

    // 為現有表添加 store_id 字段（如果不存在）
    const tablesToAddStoreId = [
        'customers', 'products', 'order_items', 'tables', 'lockers',
        'devices', 'members', 'transactions', 'employees', 'audit_logs', 'inventory_logs'
    ];

    tablesToAddStoreId.forEach(tableName => {
        db.all(`PRAGMA table_info(${tableName})`, (err, rows) => {
            if (err) {
                console.error(`檢查${tableName}表結構錯誤:`, err);
                return;
            }

            const hasStoreId = rows && Array.isArray(rows) && rows.some(row => row.name === 'store_id');
            if (!hasStoreId) {
                console.log(`在${tableName}表中添加store_id字段...`);

                // 設置默認值：對於employees表，store_id可為NULL（總部管理員）
                const defaultValue = tableName === 'employees' ? 'NULL' : "'default_store'";
                const nullableClause = tableName === 'employees' ? '' : ' NOT NULL';

                db.run(`ALTER TABLE ${tableName} ADD COLUMN store_id TEXT${nullableClause} DEFAULT ${defaultValue}`, (alterErr) => {
                    if (alterErr) {
                        console.error(`添加store_id字段到${tableName}表錯誤:`, alterErr);
                    } else {
                        console.log(`成功添加store_id字段到${tableName}表`);

                        // 如果是已存在數據的表，更新現有記錄的store_id
                        if (tableName !== 'employees') {
                            db.run(`UPDATE ${tableName} SET store_id = 'default_store' WHERE store_id IS NULL OR store_id = ''`, (updateErr) => {
                                if (updateErr) {
                                    console.error(`更新${tableName}表store_id錯誤:`, updateErr);
                                } else {
                                    console.log(`已更新${tableName}表現有記錄的store_id為默認值`);
                                }
                            });
                        }
                    }
                });
            } else {
                console.log(`${tableName}表已包含store_id字段`);
            }
        });
    });

    // 為store_id字段創建索引（提高查詢性能）
    const tablesToIndex = ['customers', 'products', 'order_items', 'tables', 'transactions'];
    tablesToIndex.forEach(tableName => {
        db.run(`CREATE INDEX IF NOT EXISTS idx_${tableName}_store_id ON ${tableName}(store_id)`, (indexErr) => {
            if (indexErr) {
                console.error(`創建${tableName}表store_id索引錯誤:`, indexErr);
            } else {
                console.log(`已創建/確認${tableName}表store_id索引`);
            }
        });
    });

    // 遷移 tables 表：添加組合約束 UNIQUE(store_id, table_number) 並為各分店建立桌號
    db.serialize(() => {
        db.get(`SELECT sql FROM sqlite_master WHERE type='table' AND name='tables'`, (migErr, row) => {
            if (migErr || !row) {
                if (migErr) console.error('檢查tables表結構錯誤:', migErr);
                return;
            }

            const currentSql = row.sql || '';
            if (currentSql.includes('UNIQUE(store_id, table_number)')) {
                console.log('tables表已有組合約束(store_id, table_number)，跳過遷移');
                return;
            }

            console.log('tables表缺少組合約束(store_id, table_number)，開始遷移...');

            // 1. 獲取現有桌號數據（含 default_store）
            db.all(`SELECT * FROM tables ORDER BY table_number`, (allErr, allTables) => {
                if (allErr || !allTables || allTables.length === 0) {
                    if (allErr) console.error('獲取桌號數據錯誤:', allErr);
                    return;
                }

                const defaultTables = allTables.filter(t => !t.store_id || t.store_id === 'default_store');
                if (defaultTables.length === 0) {
                    console.log('沒有找到 default_store 桌號，跳過遷移');
                    return;
                }

                // 2. 創建新表（帶組合約束）
                db.run(`CREATE TABLE IF NOT EXISTS tables_new (
                    id TEXT PRIMARY KEY,
                    table_number TEXT NOT NULL,
                    capacity INTEGER NOT NULL,
                    is_occupied INTEGER DEFAULT 0,
                    current_customer_id TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    store_id TEXT NOT NULL DEFAULT 'default_store',
                    UNIQUE(store_id, table_number),
                    FOREIGN KEY (current_customer_id) REFERENCES customers (id)
                )`, function() {
                    console.log('✅ 新tables表創建成功');

                    // 3. 複製現有數據
                    db.run(`INSERT INTO tables_new (id, table_number, capacity, is_occupied, current_customer_id, created_at, store_id)
                            SELECT id, table_number, capacity, is_occupied, current_customer_id, created_at,
                                   COALESCE(store_id, 'default_store') FROM tables`, function() {
                        console.log('✅ 桌號數據複製完成');

                        // 4. 刪除舊表
                        db.run(`DROP TABLE tables`, function() {
                            console.log('✅ 舊tables表刪除成功');

                            // 5. 重命名新表
                            db.run(`ALTER TABLE tables_new RENAME TO tables`, function() {
                                console.log('✅ tables表重命名成功');

                                // 6. 創建索引
                                db.run(`CREATE INDEX IF NOT EXISTS idx_tables_store_id ON tables(store_id)`);

                                // 7. 為各分店複製桌號
                                console.log('為各分店複製 default_store 桌號...');
                                const storeList = [
                                    { id: 'store_1' }, { id: 'store_2' },
                                    { id: 'store_3' }, { id: 'store_4' }
                                ];

                                let done = 0;
                                const total = defaultTables.length * storeList.length;

                                storeList.forEach(store => {
                                    defaultTables.forEach(orig => {
                                        db.run(`INSERT INTO tables (id, table_number, capacity, is_occupied, current_customer_id, created_at, store_id)
                                                VALUES (?, ?, ?, 0, NULL, datetime('now'), ?)`,
                                            [uuidv4(), orig.table_number, orig.capacity, store.id],
                                            function() {
                                                done++;
                                                if (done === total) {
                                                    console.log(`✅ 完成：為 ${storeList.length} 個分店各創建 ${defaultTables.length} 個桌號`);
                                                }
                                            }
                                        );
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });

    // 檢查並更新表結構（兼容現有數據庫）
    console.log('檢查表結構...');

    // 檢查products表是否有track_inventory字段
    db.all(`PRAGMA table_info(products)`, (err, rows) => {
        if (err) {
            console.error('檢查products表結構錯誤:', err);
            return;
        }

        const hasTrackInventory = rows && Array.isArray(rows) && rows.some(row => row.name === 'track_inventory');
        if (!hasTrackInventory) {
            console.log('在products表中添加track_inventory字段...');
            db.run(`ALTER TABLE products ADD COLUMN track_inventory INTEGER DEFAULT 1`, (alterErr) => {
                if (alterErr) {
                    console.error('添加track_inventory字段錯誤:', alterErr);
                } else {
                    console.log('成功添加track_inventory字段到products表');
                }
            });
        } else {
            console.log('products表已包含track_inventory字段');
        }

        // 檢查products表是否有product_order字段
        const hasProductOrder = rows && Array.isArray(rows) && rows.some(row => row.name === 'product_order');
        if (!hasProductOrder) {
            console.log('在products表中添加product_order字段...');
            db.run(`ALTER TABLE products ADD COLUMN product_order INTEGER DEFAULT 0`, (alterErr) => {
                if (alterErr) {
                    console.error('添加product_order字段錯誤:', alterErr);
                } else {
                    console.log('成功添加product_order字段到products表');
                }
            });
        } else {
            console.log('products表已包含product_order字段');
        }

        // 檢查products表是否有商品時效相關字段
        const hasTimeRestriction = rows && Array.isArray(rows) && rows.some(row => row.name === 'has_time_restriction');
        if (!hasTimeRestriction) {
            console.log('在products表中添加商品時效相關字段...');
            db.run(`ALTER TABLE products ADD COLUMN has_time_restriction INTEGER DEFAULT 0`, (alterErr) => {
                if (alterErr) {
                    console.error('添加has_time_restriction字段錯誤:', alterErr);
                } else {
                    console.log('成功添加has_time_restriction字段到products表');
                }
            });
            db.run(`ALTER TABLE products ADD COLUMN weekday_start_time TEXT`, (alterErr) => {
                if (alterErr) console.error('添加weekday_start_time字段錯誤:', alterErr);
            });
            db.run(`ALTER TABLE products ADD COLUMN weekday_end_time TEXT`, (alterErr) => {
                if (alterErr) console.error('添加weekday_end_time字段錯誤:', alterErr);
            });
            db.run(`ALTER TABLE products ADD COLUMN holiday_start_time TEXT`, (alterErr) => {
                if (alterErr) console.error('添加holiday_start_time字段錯誤:', alterErr);
            });
            db.run(`ALTER TABLE products ADD COLUMN holiday_end_time TEXT`, (alterErr) => {
                if (alterErr) console.error('添加holiday_end_time字段錯誤:', alterErr);
            });
        } else {
            console.log('products表已包含商品時效相關字段');
        }

        // 檢查是否有第二段時間範圍字段
        const hasTimeRestriction2 = rows && Array.isArray(rows) && rows.some(row => row.name === 'weekday_start_time_2');
        if (!hasTimeRestriction2) {
            console.log('在products表中添加第二段商品時效相關字段...');
            db.run(`ALTER TABLE products ADD COLUMN weekday_start_time_2 TEXT`, (alterErr) => {
                if (alterErr) console.error('添加weekday_start_time_2字段錯誤:', alterErr);
            });
            db.run(`ALTER TABLE products ADD COLUMN weekday_end_time_2 TEXT`, (alterErr) => {
                if (alterErr) console.error('添加weekday_end_time_2字段錯誤:', alterErr);
            });
            db.run(`ALTER TABLE products ADD COLUMN holiday_start_time_2 TEXT`, (alterErr) => {
                if (alterErr) console.error('添加holiday_start_time_2字段錯誤:', alterErr);
            });
            db.run(`ALTER TABLE products ADD COLUMN holiday_end_time_2 TEXT`, (alterErr) => {
                if (alterErr) console.error('添加holiday_end_time_2字段錯誤:', alterErr);
            });
        } else {
            console.log('products表已包含第二段商品時效相關字段');
        }

        // 檢查是否有is_time_available字段
        const hasIsTimeAvailable = rows && Array.isArray(rows) && rows.some(row => row.name === 'is_time_available');
        if (!hasIsTimeAvailable) {
            console.log('在products表中添加is_time_available字段...');
            db.run(`ALTER TABLE products ADD COLUMN is_time_available INTEGER DEFAULT 0`, (alterErr) => {
                if (alterErr) {
                    console.error('添加is_time_available字段錯誤:', alterErr);
                } else {
                    console.log('成功添加is_time_available字段到products表');
                }
            });
        } else {
            console.log('products表已包含is_time_available字段');
        }
    });

    // 檢查並遷移 audit_logs 表，確保 employee_id 可為 NULL
    db.serialize(() => {
        db.get(`SELECT name FROM sqlite_master WHERE type='table' AND name='audit_logs'`, (err, table) => {
            if (err) {
                console.error('檢查 audit_logs 表錯誤:', err);
                return;
            }

            if (!table) {
                console.log('audit_logs 表不存在，將由後續創建表語句創建');
                return;
            }

            // 檢查 employee_id 是否為 NOT NULL
            db.all(`PRAGMA table_info(audit_logs)`, (pragmaErr, columns) => {
                if (pragmaErr) {
                    console.error('檢查 audit_logs 表結構錯誤:', pragmaErr);
                    return;
                }

                const employeeIdColumn = columns.find(col => col.name === 'employee_id');
                const storeIdColumn = columns.find(col => col.name === 'store_id');

                if (!employeeIdColumn) {
                    console.error('audit_logs 表缺少 employee_id 字段');
                    return;
                }

                // 如果 employee_id 是 NOT NULL，需要重建表
                if (employeeIdColumn.notnull === 1) {
                    console.log('檢測到 audit_logs.employee_id 為 NOT NULL，正在重建表以允許 NULL 值...');

                    // 創建臨時表
                    db.run(`
                        CREATE TABLE audit_logs_new (
                            id TEXT PRIMARY KEY,
                            employee_id TEXT,
                            action_type TEXT NOT NULL,
                            action_details TEXT,
                            ip_address TEXT,
                            store_id TEXT NOT NULL DEFAULT 'default_store',
                            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                            FOREIGN KEY (employee_id) REFERENCES employees (id)
                        )
                    `, (createErr) => {
                        if (createErr) {
                            console.error('創建新 audit_logs 表錯誤:', createErr);
                            return;
                        }

                        console.log('新 audit_logs 表創建成功，複製現有數據...');

                        // 複製現有數據
                        db.run(`
                            INSERT INTO audit_logs_new (id, employee_id, action_type, action_details, ip_address, store_id, created_at)
                            SELECT id, employee_id, action_type, action_details, ip_address,
                                   COALESCE(store_id, 'default_store') as store_id, created_at
                            FROM audit_logs
                        `, (copyErr) => {
                            if (copyErr) {
                                console.error('複製數據到新表錯誤:', copyErr);
                                db.run('DROP TABLE audit_logs_new');
                                return;
                            }

                            console.log('數據複製成功，替換舊表...');

                            // 刪除舊表並重命名新表
                            db.run('DROP TABLE audit_logs', (dropErr) => {
                                if (dropErr) {
                                    console.error('刪除舊表錯誤:', dropErr);
                                    return;
                                }

                                db.run('ALTER TABLE audit_logs_new RENAME TO audit_logs', (renameErr) => {
                                    if (renameErr) {
                                        console.error('重命名新表錯誤:', renameErr);
                                        return;
                                    }

                                    console.log('audit_logs 表重建完成，employee_id 現在允許 NULL 值');

                                    // 重新創建索引
                                    db.run(`CREATE INDEX IF NOT EXISTS idx_audit_logs_employee_id ON audit_logs(employee_id)`);
                                    db.run(`CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at)`);
                                    console.log('audit_logs 表索引已重建');
                                });
                            });
                        });
                    });
                } else {
                    console.log('audit_logs.employee_id 已允許 NULL 值，無需修改');
                }

                // 確保 store_id 有默認值
                if (storeIdColumn && storeIdColumn.dflt_value === null) {
                    console.log('audit_logs.store_id 缺少默認值，正在添加默認值...');
                    // 更新現有 NULL 值為默認值
                    db.run(`UPDATE audit_logs SET store_id = 'default_store' WHERE store_id IS NULL`, (updateErr) => {
                        if (updateErr) {
                            console.error('更新 store_id 默認值錯誤:', updateErr);
                        } else {
                            console.log('已更新 audit_logs.store_id 默認值');
                        }
                    });
                }
            });
        });
    });

    // 創建或遷移節假日表（所有分店共用）
    db.serialize(() => {
        // 第一步：檢查holidays表是否存在
        db.get(`SELECT name FROM sqlite_master WHERE type='table' AND name='holidays'`, (err, table) => {
            if (err) {
                console.error('檢查holidays表錯誤:', err);
                return;
            }

            if (!table) {
                // 表不存在，直接創建新表
                console.log('holidays表不存在，創建新表');
                db.run(`
                    CREATE TABLE holidays (
                        id TEXT PRIMARY KEY,
                        date DATE UNIQUE NOT NULL,
                        description TEXT,
                        created_by TEXT,
                        store_id TEXT DEFAULT 'default_store',
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (created_by) REFERENCES employees (id)
                    )
                `);
                console.log('節假日表創建完成（所有分店共用）');
            } else {
                // 表已存在，檢查結構並遷移
                console.log('holidays表已存在，檢查結構並遷移...');

                // 檢查是否有store_id列
                db.get(`PRAGMA table_info(holidays)`, (pragmaErr, columns) => {
                    if (pragmaErr) {
                        console.error('檢查表結構錯誤:', pragmaErr);
                        return;
                    }

                    // 檢查列信息（實際columns是數組）
                    db.all(`PRAGMA table_info(holidays)`, (pragmaErr, columnInfo) => {
                        if (pragmaErr) {
                            console.error('獲取表結構錯誤:', pragmaErr);
                            return;
                        }

                        const hasStoreId = columnInfo.some(col => col.name === 'store_id');
                        console.log(`holidays表結構: 共有${columnInfo.length}個字段, store_id字段: ${hasStoreId ? '存在' : '不存在'}`);

                        if (!hasStoreId) {
                            // 添加store_id字段
                            db.run(`ALTER TABLE holidays ADD COLUMN store_id TEXT DEFAULT 'default_store'`, (alterErr) => {
                                if (alterErr && !alterErr.message.includes('duplicate column name')) {
                                    console.error('添加store_id字段錯誤:', alterErr);
                                } else {
                                    console.log('已添加store_id字段');
                                }
                            });
                        }

                        // 更新所有現有記錄的store_id為默認值
                        db.run(`UPDATE holidays SET store_id = 'default_store' WHERE store_id IS NULL OR store_id = ''`, (updateErr) => {
                            if (updateErr) {
                                console.error('更新節假日store_id錯誤:', updateErr);
                            } else {
                                console.log('已更新現有節假日的store_id為默認值');
                            }
                        });

                        // 確保date字段有UNIQUE約束（可能需要重新創建表，但我們先嘗試創建唯一索引）
                        db.run(`CREATE UNIQUE INDEX IF NOT EXISTS idx_holidays_date ON holidays(date)`, (indexErr) => {
                            if (indexErr) {
                                console.error('創建日期唯一索引錯誤:', indexErr);
                            } else {
                                console.log('日期唯一索引確保完成');
                            }
                        });
                    });
                });
            }
        });
    });
    console.log('節假日表初始化完成');

    // ==================== 預約表 (Booking/Reservation) ====================
    db.run(`
      CREATE TABLE IF NOT EXISTS bookings (
        id TEXT PRIMARY KEY,
        store_id TEXT NOT NULL,
        booking_date TEXT NOT NULL,
        booking_time TEXT NOT NULL,
        adults INTEGER DEFAULT 2,
        children INTEGER DEFAULT 0,
        phone TEXT NOT NULL,
        notes TEXT,
        status TEXT NOT NULL DEFAULT 'confirmed',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (store_id) REFERENCES stores (id)
      )
    `);
    // 為 bookings 表建立索引
    db.run(`CREATE INDEX IF NOT EXISTS idx_bookings_store_date ON bookings(store_id, booking_date)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_bookings_phone ON bookings(phone)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status)`);
    db.run(`ALTER TABLE bookings ADD COLUMN table_number TEXT`, function(err) {
        if (err && !err.message.includes('duplicate column')) console.error('加 bookings table_number 錯誤:', err.message);
    });
    db.run(`ALTER TABLE bookings ADD COLUMN lang TEXT DEFAULT 'zh-TW'`, function(err) {
        if (err && !err.message.includes('duplicate column')) console.error('加 bookings lang 錯誤:', err.message);
    });

    // ==================== 候位系統 ====================
    db.run(`
      CREATE TABLE IF NOT EXISTS waitinglist (
        id TEXT PRIMARY KEY,
        store_id TEXT NOT NULL,
        adults INTEGER DEFAULT 2,
        children INTEGER DEFAULT 0,
        phone TEXT NOT NULL,
        notes TEXT DEFAULT '',
        lang TEXT DEFAULT 'zh-TW',
        status TEXT NOT NULL DEFAULT 'waiting',
        ref_number TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
    db.run(`CREATE INDEX IF NOT EXISTS idx_waitinglist_store ON waitinglist(store_id)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_waitinglist_phone ON waitinglist(phone)`);
    db.run(`ALTER TABLE waitinglist ADD COLUMN table_number TEXT`, function(err) {
        if (err && !err.message.includes('duplicate column')) console.error('加 waitinglist table_number 錯誤:', err.message);
    });
    // Migration: add lang column if not exists (for existing tables)
    db.run(`ALTER TABLE waitinglist ADD COLUMN lang TEXT DEFAULT 'zh-TW'`, function(err) {
        if (err && !err.message.includes('duplicate column')) {
            console.error('加 lang 欄位錯誤:', err.message);
        }
    });

    // ==================== 暫停預約時段 ====================
    db.run(`
      CREATE TABLE IF NOT EXISTS paused_slots (
        id TEXT PRIMARY KEY,
        store_id TEXT NOT NULL,
        booking_date TEXT NOT NULL,
        booking_time TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
    db.run(`CREATE INDEX IF NOT EXISTS idx_paused_slots_store_date ON paused_slots(store_id, booking_date)`);
    // 清除已存在嘅重複
    db.run(`DELETE FROM paused_slots WHERE rowid NOT IN (SELECT MIN(rowid) FROM paused_slots GROUP BY store_id, booking_date, booking_time)`);
    // 防止重複暫停時段
    db.run(`CREATE UNIQUE INDEX IF NOT EXISTS idx_paused_slots_unique ON paused_slots(store_id, booking_date, booking_time)`);
    // paused_slots 加 cached_at 欄（供 aliyun-proxy cache refresh 用）
    db.run(`ALTER TABLE paused_slots ADD COLUMN cached_at DATETIME`, function(err) {
        if (err && !err.message.includes('duplicate column')) {
            console.error('加 paused_slots.cached_at 欄位錯誤:', err.message);
        }
    });
    // paused_slots 加 source 欄（標記 confirm.html 產生嘅暫停時段，bookingRoutesBackend.js L208/L439 用）
    db.run(`ALTER TABLE paused_slots ADD COLUMN source TEXT`, function(err) {
        if (err && !err.message.includes('duplicate column')) {
            console.error('加 paused_slots.source 欄位錯誤:', err.message);
        }
    });

    // ==================== 分店座位容量設定 ====================
    db.run(`
      CREATE TABLE IF NOT EXISTS store_capacity (
        id TEXT PRIMARY KEY,
        store_id TEXT NOT NULL,
        daytype_group TEXT NOT NULL,
        capacity INTEGER NOT NULL DEFAULT 20,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(store_id, daytype_group)
      )
    `);

    // ==================== 分店時段容量設定 ====================
    db.run(`
      CREATE TABLE IF NOT EXISTS store_slot_capacity (
        id TEXT PRIMARY KEY,
        store_id TEXT NOT NULL,
        daytype_group TEXT NOT NULL,
        booking_time TEXT NOT NULL,
        capacity INTEGER NOT NULL DEFAULT 20,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(store_id, daytype_group, booking_time)
      )
    `);

    // ==================== 反結賬功能支援表 ====================

    // 分店員工名單表 (來自 Google Sheet 同步)
    db.run(`
      CREATE TABLE IF NOT EXISTS store_checkout_staff (
        id TEXT PRIMARY KEY,
        store_id TEXT NOT NULL,
        staff_name TEXT NOT NULL,
        fetched_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (store_id) REFERENCES stores (id)
      )
    `);

    // 為 store_checkout_staff 建立索引
    db.run('CREATE INDEX IF NOT EXISTS idx_store_checkout_staff_store ON store_checkout_staff(store_id)');

    // 確保 customers 表有 is_reversed, reversed_by, reversed_at 字段
    db.run('ALTER TABLE customers ADD COLUMN is_reversed INTEGER DEFAULT 0', (err) => {
      if (err && !err.message.includes('duplicate column name')) {
        console.error('添加 customers.is_reversed 字段錯誤:', err);
      }
    });
    db.run('ALTER TABLE customers ADD COLUMN reversed_by TEXT', (err) => {
      if (err && !err.message.includes('duplicate column name')) {
        console.error('添加 customers.reversed_by 字段錯誤:', err);
      }
    });
    db.run('ALTER TABLE customers ADD COLUMN reversed_at DATETIME', (err) => {
      if (err && !err.message.includes('duplicate column name')) {
        console.error('添加 customers.reversed_at 字段錯誤:', err);
      }
    });
    db.run('ALTER TABLE customers ADD COLUMN reverse_employee_name TEXT', (err) => {
      if (err && !err.message.includes('duplicate column name')) {
        console.error('添加 customers.reverse_employee_name 字段錯誤:', err);
      }
    });
    db.run('ALTER TABLE customers ADD COLUMN seating_type TEXT DEFAULT \'walk-in\'', (err) => {
      if (err && !err.message.includes('duplicate column name')) {
        console.error('添加 customers.seating_type 字段錯誤:', err);
      }
    });

    // 確保 order_items 表有 is_reversed 字段
    db.run('ALTER TABLE order_items ADD COLUMN is_reversed INTEGER DEFAULT 0', (err) => {
      if (err && !err.message.includes('duplicate column name')) {
        console.error('添加 order_items.is_reversed 字段錯誤:', err);
      }
    });

    // 確保 order_items 表有 flat_discount 和 percent_discount 字段（立減/折扣優惠）
    db.run('ALTER TABLE order_items ADD COLUMN flat_discount REAL DEFAULT 0', (err) => {
      if (err && !err.message.includes('duplicate column name')) {
        console.error('添加 order_items.flat_discount 字段錯誤:', err);
      }
    });
    db.run('ALTER TABLE order_items ADD COLUMN percent_discount REAL DEFAULT 0', (err) => {
      if (err && !err.message.includes('duplicate column name')) {
        console.error('添加 order_items.percent_discount 字段錯誤:', err);
      }
    });

    // ==================== 阿里雲預約/候位 Cache 表 ====================
    db.run(`CREATE TABLE IF NOT EXISTS aliyun_booking_cache (
        id TEXT PRIMARY KEY,
        store_id TEXT NOT NULL,
        booking_date TEXT,
        booking_time TEXT,
        adults INTEGER DEFAULT 2,
        children INTEGER DEFAULT 0,
        phone TEXT,
        notes TEXT,
        status TEXT,
        table_number TEXT,
        lang TEXT DEFAULT 'zh-TW',
        created_at TEXT,
        updated_at TEXT,
        cached_at TEXT
      )`);
    db.run('CREATE INDEX IF NOT EXISTS idx_aliyun_booking_cache_store_date ON aliyun_booking_cache(store_id, booking_date)');

    db.run(`CREATE TABLE IF NOT EXISTS aliyun_waitinglist_cache (
        id TEXT PRIMARY KEY,
        store_id TEXT NOT NULL,
        adults INTEGER DEFAULT 2,
        children INTEGER DEFAULT 0,
        phone TEXT,
        notes TEXT,
        status TEXT,
        ref_number TEXT,
        table_number TEXT,
        lang TEXT DEFAULT 'zh-TW',
        created_at TEXT,
        updated_at TEXT,
        cached_at TEXT
      )`);
    db.run('CREATE INDEX IF NOT EXISTS idx_aliyun_waitinglist_cache_store ON aliyun_waitinglist_cache(store_id)');

    console.log('數據庫表初始化完成');

    // 初始化桌位數據 - 確保只有A1-A50共50個桌號
    db.all('SELECT id, table_number, is_occupied FROM tables', (err, rows) => {
      if (err) {
        console.error('檢查桌位數據錯誤:', err);
        return;
      }

      const existingTables = rows || [];
      console.log(`現有桌位數量: ${existingTables.length}`);

      // 1. 刪除非A系列且未被佔用的桌位
      let deletedCount = 0;
      const nonASeriesTables = existingTables.filter(t => !/^A\d{1,2}$/.test(t.table_number));

      nonASeriesTables.forEach(table => {
        if (table.is_occupied === 0) {
          // 桌位空閒，可以安全刪除
          db.run('DELETE FROM tables WHERE id = ?', [table.id], function(err) {
            if (err) {
              console.error(`刪除非A系列桌位 ${table.table_number} 錯誤:`, err);
            } else {
              deletedCount++;
              console.log(`已刪除非A系列桌位: ${table.table_number}`);
            }
          });
        } else {
          // 桌位被佔用，無法刪除，記錄警告
          console.warn(`無法刪除非A系列桌位 ${table.table_number}，因為它正在使用中 (is_occupied=1)`);
        }
      });

      // 2. 確保A1-A50都存在
      const requiredTables = Array.from({ length: 50 }, (_, i) => `A${i + 1}`);
      const existingASeriesTables = existingTables.filter(t => /^A\d{1,2}$/.test(t.table_number)).map(t => t.table_number);
      const missingTables = requiredTables.filter(tableNum => !existingASeriesTables.includes(tableNum));

      if (missingTables.length > 0) {
        console.log(`缺少 ${missingTables.length} 個A系列桌位，正在創建: ${missingTables.join(', ')}`);
        const stmt = db.prepare('INSERT INTO tables (id, table_number, capacity) VALUES (?, ?, ?)');
        missingTables.forEach(tableNumber => {
          stmt.run(uuidv4(), tableNumber, 70);
        });
        stmt.finalize();
        console.log(`已創建 ${missingTables.length} 個缺失的A系列桌位`);
      } else {
        console.log('所有A1-A50桌位已存在');
      }

      console.log(`桌位初始化完成: 刪除了 ${deletedCount} 個非A系列桌位，檢查了 ${requiredTables.length} 個A系列桌位`);
    });

    // 插入示例商品
    db.get('SELECT COUNT(*) as count FROM products', (err, row) => {
      if (err) {
        console.error('檢查商品數量錯誤:', err);
        return;
      }

      if (row.count === 0) {
        const products = [
          // 飲品
          { name: '美式咖啡', description: '經典美式咖啡', price: 80, stock: 50, locker_number: 1, category: '飲品' },
          { name: '拿鐵咖啡', description: '香醇拿鐵', price: 100, stock: 50, locker_number: 2, category: '飲品' },
          { name: '卡布奇諾', description: '綿密卡布奇諾', price: 110, stock: 50, locker_number: 3, category: '飲品' },
          { name: '抹茶拿鐵', description: '日式抹茶拿鐵', price: 120, stock: 40, locker_number: 4, category: '飲品' },
          { name: '奶茶', description: '香濃奶茶', price: 90, stock: 60, locker_number: 9, category: '飲品' },
          { name: '可樂', description: '冰涼可樂', price: 60, stock: 100, locker_number: 10, category: '飲品' },
          // 甜品
          { name: '巧克力蛋糕', description: '經典巧克力蛋糕', price: 150, stock: 30, locker_number: 5, category: '甜品' },
          { name: '起司蛋糕', description: '紐約起司蛋糕', price: 160, stock: 30, locker_number: 6, category: '甜品' },
          { name: '提拉米蘇', description: '義式提拉米蘇', price: 140, stock: 25, locker_number: 11, category: '甜品' },
          { name: '布丁', description: '香滑布丁', price: 80, stock: 40, locker_number: 12, category: '甜品' },
          // 貓零食
          { name: '貓草餅乾', description: '天然貓草餅乾', price: 120, stock: 30, locker_number: 7, category: '貓零食' },
          { name: '小魚乾', description: '香脆小魚乾', price: 100, stock: 40, locker_number: 8, category: '貓零食' },
          { name: '貓薄荷玩具', description: '貓薄荷填充玩具', price: 180, stock: 20, locker_number: 13, category: '貓零食' },
          { name: '逗貓棒', description: '彩色羽毛逗貓棒', price: 150, stock: 25, locker_number: 14, category: '貓零食' },
          { name: '貓抓板', description: '瓦楞紙貓抓板', price: 250, stock: 15, locker_number: 15, category: '貓零食' }
        ];

        const stmt = db.prepare('INSERT INTO products (id, name, description, price, stock, locker_number, category) VALUES (?, ?, ?, ?, ?, ?, ?)');
        products.forEach(product => {
          stmt.run(uuidv4(), product.name, product.description, product.price, product.stock, product.locker_number, product.category);
        });
        stmt.finalize();
        console.log('插入示例商品數據完成');
      }
    });

    // 初始化儲物柜數據 - 確保有1-70號儲物柜
    db.all('SELECT locker_number FROM lockers ORDER BY locker_number', (err, rows) => {
      if (err) {
        console.error('檢查儲物柜數據錯誤:', err);
        return;
      }

      const existingLockers = rows || [];
      console.log(`現有儲物柜數量: ${existingLockers.length}`);

      // 檢查缺失的儲物柜編號（1-70）
      const existingLockerNumbers = existingLockers.map(l => l.locker_number);
      const requiredLockerNumbers = Array.from({ length: 70 }, (_, i) => i + 1); // 1-70
      const missingLockerNumbers = requiredLockerNumbers.filter(num => !existingLockerNumbers.includes(num));

      console.log(`現有儲物柜編號: ${existingLockerNumbers.sort((a,b) => a-b).join(', ')}`);
      console.log(`缺失的儲物柜編號: ${missingLockerNumbers.join(', ')}`);

      if (missingLockerNumbers.length > 0) {
        console.log(`正在創建 ${missingLockerNumbers.length} 個缺失的儲物柜: ${missingLockerNumbers.join(', ')}`);
        const stmt = db.prepare('INSERT INTO lockers (id, locker_number) VALUES (?, ?)');
        missingLockerNumbers.forEach(lockerNumber => {
          stmt.run(uuidv4(), lockerNumber);
        });
        stmt.finalize();
        console.log(`已創建 ${missingLockerNumbers.length} 個缺失的儲物柜`);
      } else {
        console.log('所有1-50號儲物柜已存在');
      }
    });

    // 創建默認員工帳戶（如果員工表為空）
    db.get('SELECT COUNT(*) as count FROM employees', async (err, row) => {
      if (err) {
        console.error('檢查員工數量錯誤:', err);
        return;
      }

      if (row.count === 0) {
        console.log('創建默認員工帳戶...');

        const adminId = uuidv4();
        const staffId = uuidv4();
        const now = new Date().toISOString();
        const adminPassword = 'admin123';
        const staffPassword = 'staff123';

        try {
          // 哈希密碼
          const saltRounds = 10;
          const adminPasswordHash = await bcrypt.hash(adminPassword, saltRounds);
          const staffPasswordHash = await bcrypt.hash(staffPassword, saltRounds);

          // 插入默認管理員
          db.run(
            `INSERT INTO employees (id, username, password_hash, full_name, role, email, phone, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              adminId,
              'admin',
              adminPasswordHash,
              '系統管理員',
              'admin',
              'admin@cafe.example.com',
              '0900000000',
              now,
              now
            ],
            function(insertErr) {
              if (insertErr) {
                console.error('創建默認管理員錯誤:', insertErr);
              } else {
                console.log('默認管理員創建成功: admin / admin123');
                console.log('請立即更改默認密碼以確保安全！');
              }
            }
          );

          // 插入默認普通員工
          db.run(
            `INSERT INTO employees (id, username, password_hash, full_name, role, email, phone, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              staffId,
              'staff',
              staffPasswordHash,
              '收銀員',
              'staff',
              'staff@cafe.example.com',
              '0911111111',
              now,
              now
            ],
            function(staffInsertErr) {
              if (staffInsertErr) {
                console.error('創建默認員工錯誤:', staffInsertErr);
              } else {
                console.log('默認員工創建成功: staff / staff123');
                console.log('請立即更改默認密碼以確保安全！');
              }
            }
          );
        } catch (hashErr) {
          console.error('密碼哈希錯誤:', hashErr);

          // 如果bcrypt失敗，使用簡單的哈希（僅用於開發）
          const fallbackHash = '$2a$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW'; // 'secret'的哈希

          // 創建管理員（使用回退哈希）
          db.run(
            `INSERT INTO employees (id, username, password_hash, full_name, role, email, phone, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              adminId,
              'admin',
              fallbackHash,
              '系統管理員',
              'admin',
              'admin@cafe.example.com',
              '0900000000',
              now,
              now
            ],
            function(insertErr2) {
              if (insertErr2) {
                console.error('創建默認管理員錯誤（回退）:', insertErr2);
              } else {
                console.log('默認管理員創建成功（使用回退哈希）: admin / secret');
                console.log('請立即更改密碼以確保安全！');
              }
            }
          );

          // 創建員工（使用回退哈希）
          db.run(
            `INSERT INTO employees (id, username, password_hash, full_name, role, email, phone, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              staffId,
              'staff',
              fallbackHash,
              '收銀員',
              'staff',
              'staff@cafe.example.com',
              '0911111111',
              now,
              now
            ],
            function(staffInsertErr2) {
              if (staffInsertErr2) {
                console.error('創建默認員工錯誤（回退）:', staffInsertErr2);
              } else {
                console.log('默認員工創建成功（使用回退哈希）: staff / secret');
                console.log('請立即更改密碼以確保安全！');
              }
            }
          );
        }
      } else {
        console.log(`數據庫中已有 ${row.count} 個員工帳戶`);
      }
    });

    // ===== 創建測試分店和測試員工 =====
    // 確保 test 分店存在（用於測試）
    db.get(`SELECT COUNT(*) as count FROM stores WHERE id = 'test'`, (err, row) => {
      if (err) {
        console.error('檢查測試分店錯誤:', err);
        return;
      }
      if (row.count === 0) {
        const testStoreId = 'test';
        db.run(
          `INSERT INTO stores (id, store_code, store_name, address, timezone, is_active)
           VALUES (?, ?, ?, ?, ?, ?)`,
          [testStoreId, 'TEST', '測試分店', '測試地點', 'Asia/Hong_Kong', 1],
          (insertErr) => {
            if (insertErr) {
              console.error('創建測試分店錯誤:', insertErr);
            } else {
              console.log('✅ 測試分店創建成功: test (TEST)');
            }
          }
        );
      } else {
        console.log('測試分店已存在');
      }
    });

    // 確保 test 員工存在（用於測試登入）
    db.get(`SELECT COUNT(*) as count FROM employees WHERE username = 'test'`, async (err, row) => {
      if (err) {
        console.error('檢查測試員工錯誤:', err);
        return;
      }
      if (row.count === 0) {
        try {
          const saltRounds = 10;
          const testPasswordHash = await bcrypt.hash('test', saltRounds);
          const now = new Date().toISOString();
          db.run(
            `INSERT INTO employees (id, username, password_hash, full_name, role, email, phone, store_id, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [uuidv4(), 'test', testPasswordHash, '測試員工', 'staff', 'test@cafe.example.com', '0900000000', 'test', now, now],
            (insertErr) => {
              if (insertErr) {
                console.error('創建測試員工錯誤:', insertErr);
              } else {
                console.log('✅ 測試員工創建成功: test / test');
              }
            }
          );
        } catch (hashErr) {
          console.error('測試員工密碼哈希錯誤:', hashErr);
        }
      } else {
        console.log('測試員工 test 已存在');
      }
    });
  });
};

// 數據庫操作函數
const dbOperations = {
  // 獲取空閒桌位
  getAvailableTables: (peopleCount, storeId) => {
    return new Promise((resolve, reject) => {
      // 構建查詢條件
      let query = `SELECT * FROM tables
         WHERE is_occupied = 0
         AND capacity >= ?
         AND table_number LIKE 'A%'
         AND table_number GLOB 'A[0-9]*'`;
      let params = [peopleCount];

      // 添加分店過濾條件（如果提供了storeId）
      if (storeId) {
        query += ` AND store_id = ?`;
        params.push(storeId);
      } else {
        // 如果沒有提供storeId，使用默認分店（向後兼容）
        query += ` AND (store_id = 'default_store' OR store_id IS NULL)`;
      }

      query += ` ORDER BY CAST(SUBSTR(table_number, 2) AS INTEGER) ASC`;

      db.all(query, params, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  },

  // 分配桌位給客人
  assignTableToCustomer: (tableId, customerId) => {
    return new Promise((resolve, reject) => {
      db.run(
        `UPDATE tables SET is_occupied = 1, current_customer_id = ? WHERE id = ?`,
        [customerId, tableId],
        function(err) {
          if (err) reject(err);
          else resolve(this.changes);
        }
      );
    });
  },

  // 創建新客人
  createCustomer: (customerData) => {
    return new Promise((resolve, reject) => {
      const customerId = uuidv4();
      const qrCode = `CAFE-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

      // 使用 UTC ISO 字符串儲存時間，避免時區問題
      const now = new Date();
      const utcISOString = now.toISOString(); // 格式: "2026-03-24T07:31:00.000Z"

      // 獲取store_id（默認為default_store）
      const storeId = customerData.store_id || 'default_store';

      const seatingType = customerData.seating_type || 'walk-in';
      db.run(
        `INSERT INTO customers (id, table_number, qr_code, people_count, is_member, member_card_id, entry_time, store_id, seating_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          customerId,
          customerData.table_number,
          qrCode,
          customerData.people_count,
          customerData.is_member || 0,
          customerData.member_card_id || null,
          utcISOString,
          storeId,
          seatingType
        ],
        function(err) {
          if (err) reject(err);
          else resolve({ id: customerId, qr_code: qrCode, store_id: storeId, seating_type: seatingType });
        }
      );
    });
  },

  // 根據QR Code獲取客人信息
  getCustomerByQRCode: (qrCode, storeId) => {
    return new Promise((resolve, reject) => {
      // 構建查詢條件
      let query = `SELECT c.*, t.table_number as actual_table_number FROM customers c
         LEFT JOIN tables t ON c.table_number = t.table_number
         WHERE c.qr_code = ? AND c.is_checked_out = 0`;
      let params = [qrCode];

      // 添加分店過濾條件（如果提供了storeId）
      if (storeId) {
        query += ` AND c.store_id = ?`;
        params.push(storeId);
      } else {
        // 如果沒有提供storeId，使用默認分店（向後兼容）
        query += ` AND (c.store_id = 'default_store' OR c.store_id IS NULL)`;
      }

      db.get(query, params, (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  },

  // 根據ID獲取客人信息
  getCustomerById: (customerId) => {
    return new Promise((resolve, reject) => {
      db.get(`SELECT * FROM customers WHERE id = ?`, [customerId], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  },

  // 獲取分店 KPay 配置（冇記錄時返回 null，由 kpayService 用 .env 做 fallback）
  getKpayConfig: (storeId) => {
    return new Promise((resolve, reject) => {
      db.get(
        `SELECT * FROM kpay_configs WHERE store_id = ?`,
        [storeId || 'default_store'],
        (err, row) => {
          if (err) reject(err);
          else resolve(row || null);
        }
      );
    });
  },

  // 寫入/更新分店 KPay 配置
  upsertKpayConfig: (storeId, cfg) => {
    return new Promise((resolve, reject) => {
      const store = storeId || 'default_store';
      db.run(
        `INSERT INTO kpay_configs (store_id, mode, kpos_ip, kpos_port, app_id, app_secret, callback_url, enabled, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(store_id) DO UPDATE SET
           mode = excluded.mode, kpos_ip = excluded.kpos_ip, kpos_port = excluded.kpos_port,
           app_id = excluded.app_id, app_secret = excluded.app_secret, callback_url = excluded.callback_url,
           enabled = excluded.enabled, updated_at = excluded.updated_at`,
        [
          store,
          cfg.mode || 'lan',
          cfg.kpos_ip || null,
          cfg.kpos_port || 18080,
          cfg.app_id || null,
          cfg.app_secret || null,
          cfg.callback_url || null,
          cfg.enabled !== undefined ? (cfg.enabled ? 1 : 0) : 0,
          new Date().toISOString()
        ],
        function(err) {
          if (err) reject(err);
          else resolve(this.changes);
        }
      );
    });
  },

  // 建立 KPay 支付記錄（pending）
  createKpayPayment: ({ customerId, outTradeNo, amount, paymentType, storeId }) => {
    return new Promise((resolve, reject) => {
      db.run(
        `INSERT INTO kpay_payments (id, customer_id, out_trade_no, amount, payment_type, status, store_id, created_at)
         VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)`,
        [
          uuidv4(),
          customerId,
          outTradeNo,
          amount,
          paymentType,
          storeId || 'default_store',
          new Date().toISOString()
        ],
        function(err) {
          if (err) reject(err);
          else resolve({ out_trade_no: outTradeNo });
        }
      );
    });
  },

  // 更新 KPay 支付狀態（只更新傳入嘅欄位）
  updateKpayPayment: (outTradeNo, patch) => {
    return new Promise((resolve, reject) => {
      const fields = [];
      const params = [];
      if (patch.status !== undefined) { fields.push('status = ?'); params.push(patch.status); }
      if (patch.pay_method !== undefined) { fields.push('pay_method = ?'); params.push(patch.pay_method); }
      if (patch.transaction_no !== undefined) { fields.push('transaction_no = ?'); params.push(patch.transaction_no); }
      if (patch.ref_no !== undefined) { fields.push('ref_no = ?'); params.push(patch.ref_no); }
      if (patch.paid_at !== undefined) { fields.push('paid_at = ?'); params.push(patch.paid_at); }
      if (fields.length === 0) { resolve(0); return; }
      params.push(outTradeNo);
      db.run(
        `UPDATE kpay_payments SET ${fields.join(', ')} WHERE out_trade_no = ?`,
        params,
        function(err) {
          if (err) reject(err);
          else resolve(this.changes);
        }
      );
    });
  },

  // 根據 out_trade_no 獲取 KPay 支付記錄
  getKpayPaymentByOutTradeNo: (outTradeNo) => {
    return new Promise((resolve, reject) => {
      db.get(
        `SELECT * FROM kpay_payments WHERE out_trade_no = ?`,
        [outTradeNo],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });
  },

  // 獲取客人最新一筆 KPay 支付記錄
  getKpayPaymentByCustomer: (customerId) => {
    return new Promise((resolve, reject) => {
      db.get(
        `SELECT * FROM kpay_payments WHERE customer_id = ? ORDER BY created_at DESC LIMIT 1`,
        [customerId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });
  },

  // 獲取空閒儲物柜
  getAvailableLockers: (count = 1, storeId) => {
    return new Promise((resolve, reject) => {
      // 構建查詢條件
      let query = `SELECT * FROM lockers WHERE is_occupied = 0`;
      let params = [];

      // 添加分店過濾條件（如果提供了storeId）
      if (storeId) {
        query += ` AND store_id = ?`;
        params.push(storeId);
      } else {
        // 如果沒有提供storeId，使用默認分店（向後兼容）
        query += ` AND (store_id = 'default_store' OR store_id IS NULL)`;
      }

      query += ` ORDER BY locker_number ASC LIMIT ?`;
      params.push(count);

      db.all(query, params, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  },

  // 分配儲物柜給客人
  assignLockerToCustomer: (lockerId, customerId) => {
    return new Promise((resolve, reject) => {
      const openedAt = new Date().toISOString(); // UTC ISO 字符串
      db.run(
        `UPDATE lockers SET is_occupied = 1, customer_id = ?, opened_at = ? WHERE id = ?`,
        [customerId, openedAt, lockerId],
        function(err) {
          if (err) reject(err);
          else resolve(this.changes);
        }
      );
    });
  },

  // 添加商品購買記錄
  addOrderItem: (customerId, productId, quantity, price) => {
    return new Promise((resolve, reject) => {
      const orderId = uuidv4();

      // 先獲取商品當前價格和庫存跟踪設置
      db.get(`SELECT price, track_inventory FROM products WHERE id = ?`, [productId], (err, product) => {
        if (err) {
          reject(err);
          return;
        }

        const actualPrice = price || product.price;

        // 獲取客戶的store_id
        db.get(`SELECT store_id FROM customers WHERE id = ?`, [customerId], (err2, customer) => {
          if (err2) {
            reject(err2);
            return;
          }

          const storeId = customer?.store_id || 'default_store';

          db.run(
            `INSERT INTO order_items (id, customer_id, product_id, quantity, price_at_time, store_id) VALUES (?, ?, ?, ?, ?, ?)`,
            [orderId, customerId, productId, quantity, actualPrice, storeId],
            function(err) {
              if (err) reject(err);
              else {
                // 更新客人總金額
                db.run(
                  `UPDATE customers SET total_amount = total_amount + ? WHERE id = ?`,
                  [actualPrice * quantity, customerId],
                  (updateErr) => {
                    if (updateErr) console.error('更新總金額錯誤:', updateErr);
                  }
                );

                // 更新商品庫存（僅當 track_inventory = 1 時）
                if (product.track_inventory === 1) {
                  db.run(
                    `UPDATE products SET stock = stock - ? WHERE id = ?`,
                    [quantity, productId],
                    (stockErr) => {
                      if (stockErr) console.error('更新庫存錯誤:', stockErr);
                    }
                  );
                }

                resolve(orderId);
              }
            }
          );
        });
      });
    });
  },

  // 結賬
  checkoutCustomer: (customerId) => {
    return new Promise((resolve, reject) => {
      const checkoutTime = new Date().toISOString(); // UTC ISO 字符串

      // 先查詢客人使用的儲物柜列表
      db.all(
        `SELECT locker_number FROM lockers WHERE customer_id = ? AND is_occupied = 1`,
        [customerId],
        (lockersErr, lockers) => {
          if (lockersErr) {
            reject(lockersErr);
            return;
          }

          const lockerNumbers = lockers.map(l => l.locker_number).sort((a, b) => a - b);
          const lockersUsed = lockerNumbers.length > 0 ? lockerNumbers.join(', ') : '無';

          // 更新客人狀態並保存儲物柜列表（同時清除結賬鎖定標記）
          db.run(
            `UPDATE customers SET is_checked_out = 1, checkout_time = ?, lockers_used = ?, checkout_pending = 0, checkout_pending_at = NULL WHERE id = ?`,
            [checkoutTime, lockersUsed, customerId],
            function(err) {
              if (err) reject(err);
              else {
                // 釋放桌位
                db.run(
                  `UPDATE tables SET is_occupied = 0, current_customer_id = NULL WHERE current_customer_id = ?`,
                  [customerId],
                  (tableErr) => {
                    if (tableErr) console.error('釋放桌位錯誤:', tableErr);
                  }
                );

                // 釋放儲物柜（保持customer_id以便歷史查詢）
                db.run(
                  `UPDATE lockers SET is_occupied = 0, customer_id = NULL, closed_at = ? WHERE customer_id = ?`,
                  [checkoutTime, customerId],
                  (lockerErr) => {
                    if (lockerErr) console.error('釋放儲物柜錯誤:', lockerErr);
                  }
                );

                resolve(this.changes);
              }
            }
          );
        }
      );
    });
  },

  // 檢查會員卡
  checkMemberCard: (cardId) => {
    return new Promise((resolve, reject) => {
      db.get(
        `SELECT * FROM members WHERE card_id = ?`,
        [cardId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });
  },

  // ==================== 員工相關操作（收銀系統增強） ====================

  // 獲取所有員工
  getAllEmployees: () => {
    return new Promise((resolve, reject) => {
      db.all(
        `SELECT id, username, full_name, role, email, phone, is_active, last_login, created_at, updated_at
         FROM employees ORDER BY created_at DESC`,
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
  },

  // 根據ID獲取員工
  getEmployeeById: (employeeId) => {
    return new Promise((resolve, reject) => {
      db.get(
        `SELECT id, username, full_name, role, email, phone, is_active, last_login, created_at, updated_at
         FROM employees WHERE id = ?`,
        [employeeId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });
  },

  // 根據用戶名獲取員工（用於登入）
  getEmployeeByUsername: (username) => {
    return new Promise((resolve, reject) => {
      db.get(
        `SELECT * FROM employees WHERE LOWER(username) = LOWER(?)`,
        [username],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });
  },

  // 創建新員工
  createEmployee: (employeeData) => {
    return new Promise((resolve, reject) => {
      const employeeId = uuidv4();
      const now = new Date().toISOString();

      db.run(
        `INSERT INTO employees (id, username, password_hash, full_name, role, email, phone, is_active, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          employeeId,
          employeeData.username,
          employeeData.password_hash,
          employeeData.full_name,
          employeeData.role || 'staff',
          employeeData.email || null,
          employeeData.phone || null,
          employeeData.is_active !== undefined ? employeeData.is_active : 1,
          now,
          now
        ],
        function(err) {
          if (err) reject(err);
          else resolve(employeeId);
        }
      );
    });
  },

  // 更新員工信息
  updateEmployee: (employeeId, employeeData) => {
    return new Promise((resolve, reject) => {
      const now = new Date().toISOString();
      const updates = [];
      const params = [];

      // 構建動態更新語句
      if (employeeData.full_name !== undefined) {
        updates.push('full_name = ?');
        params.push(employeeData.full_name);
      }
      if (employeeData.role !== undefined) {
        updates.push('role = ?');
        params.push(employeeData.role);
      }
      if (employeeData.email !== undefined) {
        updates.push('email = ?');
        params.push(employeeData.email || null);
      }
      if (employeeData.phone !== undefined) {
        updates.push('phone = ?');
        params.push(employeeData.phone || null);
      }
      if (employeeData.is_active !== undefined) {
        updates.push('is_active = ?');
        params.push(employeeData.is_active);
      }
      updates.push('updated_at = ?');
      params.push(now);

      if (updates.length === 1) { // 只有updated_at
        return resolve(0); // 沒有實際更新
      }

      params.push(employeeId);

      db.run(
        `UPDATE employees SET ${updates.join(', ')} WHERE id = ?`,
        params,
        function(err) {
          if (err) reject(err);
          else resolve(this.changes);
        }
      );
    });
  },

  // 更新員工密碼
  updateEmployeePassword: (employeeId, passwordHash) => {
    return new Promise((resolve, reject) => {
      const now = new Date().toISOString();

      db.run(
        `UPDATE employees SET password_hash = ?, updated_at = ? WHERE id = ?`,
        [passwordHash, now, employeeId],
        function(err) {
          if (err) reject(err);
          else resolve(this.changes);
        }
      );
    });
  },

  // 刪除員工
  deleteEmployee: (employeeId) => {
    return new Promise((resolve, reject) => {
      db.run(
        `DELETE FROM employees WHERE id = ?`,
        [employeeId],
        function(err) {
          if (err) reject(err);
          else resolve(this.changes);
        }
      );
    });
  },

  // 檢查用戶名是否已存在
  checkUsernameExists: (username, excludeId = null) => {
    return new Promise((resolve, reject) => {
      let query = `SELECT COUNT(*) as count FROM employees WHERE LOWER(username) = LOWER(?)`;
      const params = [username];

      if (excludeId) {
        query += ` AND id != ?`;
        params.push(excludeId);
      }

      db.get(query, params, (err, row) => {
        if (err) reject(err);
        else resolve(row.count > 0);
      });
    });
  },

  // 創建審計日誌
  createAuditLog: (employeeId, actionType, actionDetails, ipAddress) => {
    return new Promise((resolve, reject) => {
      const logId = uuidv4();
      const now = new Date().toISOString();

      db.run(
        `INSERT INTO audit_logs (id, employee_id, action_type, action_details, ip_address, created_at)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [logId, employeeId, actionType, actionDetails || '', ipAddress || '', now],
        function(err) {
          if (err) reject(err);
          else resolve(logId);
        }
      );
    });
  },

  // 獲取審計日誌
  getAuditLogs: (filters = {}) => {
    return new Promise((resolve, reject) => {
      let query = `
        SELECT al.*, e.username, e.full_name
        FROM audit_logs al
        LEFT JOIN employees e ON al.employee_id = e.id
        WHERE 1=1
      `;
      const params = [];

      // 添加篩選條件
      if (filters.employee_id) {
        query += ` AND al.employee_id = ?`;
        params.push(filters.employee_id);
      }
      if (filters.action_type) {
        query += ` AND al.action_type = ?`;
        params.push(filters.action_type);
      }
      if (filters.start_date) {
        query += ` AND al.created_at >= ?`;
        params.push(filters.start_date);
      }
      if (filters.end_date) {
        query += ` AND al.created_at <= ?`;
        params.push(filters.end_date);
      }

      query += ` ORDER BY al.created_at DESC`;

      if (filters.limit) {
        query += ` LIMIT ?`;
        params.push(filters.limit);
      }

      db.all(query, params, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  },

  // 檢查是否為節假日（使用香港日期）
  isHoliday: (date) => {
    return new Promise((resolve, reject) => {
      // 使用香港日期（YYYY-MM-DD）
      const dateStr = hongKongTime.getHongKongDateString(date);
      db.get('SELECT 1 FROM holidays WHERE date = ?', [dateStr], (err, row) => {
        if (err) reject(err);
        else resolve(!!row);
      });
    });
  },

  // 獲取當前有效的時段商品（使用香港時間）
  getValidHourProduct: (productType, datetime, storeId = null) => {
    return new Promise((resolve, reject) => {
      // productType: '首小時' 或 '次小時'
      // 使用香港時間
      const timeStr = hongKongTime.getHongKongTimeString(datetime); // HH:MM (香港時間)
      // 香港日期 YYYY-MM-DD
      const dateStr = hongKongTime.getHongKongDateString(datetime);

      // 先檢查是否為節假日（與 checkTimeRestriction 同步：星期六日也算假日）
      const dayOfWeek = hongKongTime.getHongKongDayOfWeek(datetime);
      const isWeekend = (dayOfWeek === 0 || dayOfWeek === 6);
      db.get('SELECT 1 FROM holidays WHERE date = ?', [dateStr], (err, holidayRow) => {
        if (err) {
          reject(err);
          return;
        }

        const isHoliday = isWeekend || !!holidayRow;
        const timeFieldPrefix = isHoliday ? 'holiday' : 'weekday';

        // 查詢符合條件的商品，排除時間段為 "00:00"-"00:00" 的無效時段
        const targetStoreId = storeId || 'default_store';
        const query = `
          SELECT id, name, price
          FROM products
          WHERE category = '收費'
            AND name LIKE ?
            AND has_time_restriction = 1
            AND store_id = ?
            AND (
              (NOT (${timeFieldPrefix}_start_time = '00:00' AND ${timeFieldPrefix}_end_time = '00:00') AND
               ${timeFieldPrefix}_start_time <= ? AND ${timeFieldPrefix}_end_time >= ?)
              OR
              (NOT (${timeFieldPrefix}_start_time_2 = '00:00' AND ${timeFieldPrefix}_end_time_2 = '00:00') AND
               ${timeFieldPrefix}_start_time_2 <= ? AND ${timeFieldPrefix}_end_time_2 >= ?)
            )
          LIMIT 1`;

        const likePattern = `%${productType}%`;
        const params = [likePattern, targetStoreId, timeStr, timeStr, timeStr, timeStr];

        db.get(query, params, (err2, product) => {
          if (err2) {
            reject(err2);
            return;
          }

          if (!product) {
            // 如果沒有找到符合時間的商品，返回第一個匹配類型的商品（作為默認）
            db.get(
              `SELECT id, name, price FROM products WHERE category = '收費' AND name LIKE ? AND store_id = ? LIMIT 1`,
              [likePattern, targetStoreId],
              (err3, defaultProduct) => {
                if (err3) reject(err3);
                else resolve(defaultProduct);
              }
            );
          } else {
            resolve(product);
          }
        });
      });
    });
  },

  // 計算客人首小時和次小時商品總價
  getHourProductsTotalPrice: (customerId) => {
    return new Promise((resolve, reject) => {
      // 先獲取客人人數
      db.get(`SELECT people_count FROM customers WHERE id = ?`, [customerId], (err, customer) => {
        if (err) {
          reject(err);
          return;
        }

        if (!customer) {
          reject(new Error('客人不存在'));
          return;
        }

        const peopleCount = customer.people_count;

        // 查詢首小時和次小時商品總價
        db.get(
          `SELECT
            SUM(oi.quantity * oi.price_at_time) as total_price,
            SUM(CASE WHEN p.name LIKE '%首小時%' THEN oi.quantity * oi.price_at_time ELSE 0 END) as first_hour_price,
            SUM(CASE WHEN p.name LIKE '%次小時%' THEN oi.quantity * oi.price_at_time ELSE 0 END) as second_hour_price
           FROM order_items oi
           JOIN products p ON oi.product_id = p.id
           WHERE oi.customer_id = ?
           AND (p.name LIKE '%首小時%' OR p.name LIKE '%次小時%')`,
          [customerId],
          (err2, row) => {
            if (err2) {
              reject(err2);
              return;
            }

            const totalPrice = row?.total_price || 0;
            const firstHourPrice = row?.first_hour_price || 0;
            const secondHourPrice = row?.second_hour_price || 0;
            const perPersonPrice = peopleCount > 0 ? totalPrice / peopleCount : 0;

            resolve({
              totalPrice,
              firstHourPrice,
              secondHourPrice,
              perPersonPrice,
              peopleCount
            });
          }
        );
      });
    });
  },

  // 獲取當前有效的全日通商品（使用香港時間）
  getValidDayPassProduct: (datetime, storeId = null) => {
    return new Promise((resolve, reject) => {
      // 使用香港時間
      const timeStr = hongKongTime.getHongKongTimeString(datetime); // HH:MM (香港時間)
      // 香港日期 YYYY-MM-DD
      const dateStr = hongKongTime.getHongKongDateString(datetime);

      // 先檢查是否為節假日（與 getValidHourProduct 同步：星期六日也算假日）
      const dayOfWeek = hongKongTime.getHongKongDayOfWeek(datetime);
      const isWeekend = (dayOfWeek === 0 || dayOfWeek === 6);
      db.get('SELECT 1 FROM holidays WHERE date = ?', [dateStr], (err, holidayRow) => {
        if (err) {
          reject(err);
          return;
        }

        const isHoliday = isWeekend || !!holidayRow;
        const timeFieldPrefix = isHoliday ? 'holiday' : 'weekday';
        const targetStoreId = storeId || 'default_store';

        // 查詢符合條件的全日通商品，排除時間段為 "00:00"-"00:00" 的無效時段
        const query = `
          SELECT id, name, price
          FROM products
          WHERE category = '收費'
            AND name LIKE '%全日通%'
            AND has_time_restriction = 1
            AND store_id = ?
            AND (
              (NOT (${timeFieldPrefix}_start_time = '00:00' AND ${timeFieldPrefix}_end_time = '00:00') AND
               ${timeFieldPrefix}_start_time <= ? AND ${timeFieldPrefix}_end_time >= ?)
              OR
              (NOT (${timeFieldPrefix}_start_time_2 = '00:00' AND ${timeFieldPrefix}_end_time_2 = '00:00') AND
               ${timeFieldPrefix}_start_time_2 <= ? AND ${timeFieldPrefix}_end_time_2 >= ?)
            )
          ORDER BY price ASC
          LIMIT 1`;

        const params = [targetStoreId, timeStr, timeStr, timeStr, timeStr];

        db.get(query, params, (err2, product) => {
          if (err2) {
            reject(err2);
            return;
          }

          if (!product) {
            // 如果沒有找到符合時間的全日通商品，返回第一個全日通商品（作為默認）
            db.get(
              `SELECT id, name, price FROM products WHERE category = '收費' AND name LIKE '%全日通%' AND store_id = ? ORDER BY price ASC LIMIT 1`,
              [targetStoreId],
              (err3, defaultProduct) => {
                if (err3) reject(err3);
                else resolve(defaultProduct);
              }
            );
          } else {
            resolve(product);
          }
        });
      });
    });
  },

  // 移除客人的所有首小時和次小時商品，返回移除的總金額
  removeHourProducts: (customerId) => {
    return new Promise((resolve, reject) => {
      db.serialize(() => {
        // 開始事務
        db.run('BEGIN TRANSACTION');

        // 查詢所有需要移除的訂單項目
        db.all(
          `SELECT oi.id, oi.product_id, oi.quantity, oi.price_at_time, p.track_inventory
           FROM order_items oi
           JOIN products p ON oi.product_id = p.id
           WHERE oi.customer_id = ?
           AND (p.name LIKE '%首小時%' OR p.name LIKE '%次小時%')`,
          [customerId],
          (err, rows) => {
            if (err) {
              db.run('ROLLBACK');
              reject(err);
              return;
            }

            if (rows.length === 0) {
              db.run('COMMIT');
              resolve({ removedCount: 0, totalAmount: 0 });
              return;
            }

            let totalAmount = 0;
            let processed = 0;

            rows.forEach((row) => {
              const itemAmount = row.quantity * row.price_at_time;
              totalAmount += itemAmount;

              // 刪除訂單項目
              db.run(`DELETE FROM order_items WHERE id = ?`, [row.id], (err2) => {
                if (err2) {
                  db.run('ROLLBACK');
                  reject(err2);
                  return;
                }

                // 恢復庫存（如果商品追蹤庫存）
                if (row.track_inventory === 1) {
                  db.run(
                    `UPDATE products SET stock = stock + ? WHERE id = ?`,
                    [row.quantity, row.product_id],
                    (err3) => {
                      if (err3) {
                        db.run('ROLLBACK');
                        reject(err3);
                        return;
                      }
                      checkComplete();
                    }
                  );
                } else {
                  checkComplete();
                }
              });
            });

            function checkComplete() {
              processed++;
              if (processed === rows.length) {
                // 更新客人總金額（減去移除的金額）
                db.run(
                  `UPDATE customers SET total_amount = total_amount - ? WHERE id = ?`,
                  [totalAmount, customerId],
                  (err4) => {
                    if (err4) {
                      db.run('ROLLBACK');
                      reject(err4);
                      return;
                    }
                    db.run('COMMIT');
                    resolve({ removedCount: rows.length, totalAmount });
                  }
                );
              }
            }
          }
        );
      });
    });
  },

  // 移除客人的所有時段商品（首小時、次小時、全日通），返回移除的總金額
  // 用於「重設入場時間」時完整重算
  removeAllHourProducts: (customerId) => {
    return new Promise((resolve, reject) => {
      db.serialize(() => {
        // 開始事務
        db.run('BEGIN TRANSACTION');

        // 查詢所有需要移除的訂單項目（首小時、次小時、全日通）
        db.all(
          `SELECT oi.id, oi.product_id, oi.quantity, oi.price_at_time, p.track_inventory
           FROM order_items oi
           JOIN products p ON oi.product_id = p.id
           WHERE oi.customer_id = ?
           AND (p.name LIKE '%首小時%' OR p.name LIKE '%次小時%' OR p.name LIKE '%全日通%')`,
          [customerId],
          (err, rows) => {
            if (err) {
              db.run('ROLLBACK');
              reject(err);
              return;
            }

            if (rows.length === 0) {
              db.run('COMMIT');
              resolve({ removedCount: 0, totalAmount: 0 });
              return;
            }

            let totalAmount = 0;
            let processed = 0;

            rows.forEach((row) => {
              const itemAmount = row.quantity * row.price_at_time;
              totalAmount += itemAmount;

              // 刪除訂單項目
              db.run(`DELETE FROM order_items WHERE id = ?`, [row.id], (err2) => {
                if (err2) {
                  db.run('ROLLBACK');
                  reject(err2);
                  return;
                }

                // 恢復庫存（如果商品追蹤庫存）
                if (row.track_inventory === 1) {
                  db.run(
                    `UPDATE products SET stock = stock + ? WHERE id = ?`,
                    [row.quantity, row.product_id],
                    (err3) => {
                      if (err3) {
                        db.run('ROLLBACK');
                        reject(err3);
                        return;
                      }
                      checkComplete();
                    }
                  );
                } else {
                  checkComplete();
                }
              });
            });

            function checkComplete() {
              processed++;
              if (processed === rows.length) {
                // 更新客人總金額（減去移除的金額）
                db.run(
                  `UPDATE customers SET total_amount = total_amount - ? WHERE id = ?`,
                  [totalAmount, customerId],
                  (err4) => {
                    if (err4) {
                      db.run('ROLLBACK');
                      reject(err4);
                      return;
                    }
                    db.run('COMMIT');
                    resolve({ removedCount: rows.length, totalAmount });
                  }
                );
              }
            }
          }
        );
      });
    });
  },

  // 按指定入場時間計算應有時段商品（純計算，唔寫 DB）
  // 用於「重設入場時間」預覽同執行：按新 entry_time 當時段揀正確嘅繁忙/非繁忙價
  computeHourProducts: async (peopleCount, entryTime, storeId = null) => {
    const now = new Date();
    const elapsedMinutes = Math.floor((now.getTime() - entryTime.getTime()) / (1000 * 60));

    // 規則同 scheduler：69分鐘內不收次小時，70分鐘起每60分鐘收一次次小時
    let requiredSecondHourCount = 0;
    if (elapsedMinutes >= 70) {
      requiredSecondHourCount = Math.floor((elapsedMinutes - 70) / 60) + 1;
    }

    const targetStoreId = storeId || 'default_store';

    // 全部按「新入場時間」當時段揀商品（繁忙/非繁忙價位）
    const firstHourProduct = await dbOperations.getValidHourProduct('首小時', entryTime, targetStoreId);
    const secondHourProduct = await dbOperations.getValidHourProduct('次小時', entryTime, targetStoreId);
    const dayPassProduct = await dbOperations.getValidDayPassProduct(entryTime, targetStoreId);

    let convertedToDayPass = false;
    let addedItems = [];
    let newHourTotal = 0;

    const firstHourPrice = firstHourProduct ? firstHourProduct.price : 0;
    const secondHourPrice = secondHourProduct ? secondHourProduct.price : 0;

    // 全日通判斷（同 scheduler 一致：有次小時先考慮轉全日通）
    if (
      requiredSecondHourCount > 0 &&
      dayPassProduct &&
      ((firstHourPrice + secondHourPrice * requiredSecondHourCount) > dayPassProduct.price)
    ) {
      convertedToDayPass = true;
      addedItems = [{
        product_id: dayPassProduct.id,
        name: dayPassProduct.name,
        quantity: peopleCount,
        price: dayPassProduct.price
      }];
      newHourTotal = peopleCount * dayPassProduct.price;
    } else {
      if (firstHourProduct) {
        addedItems.push({
          product_id: firstHourProduct.id,
          name: firstHourProduct.name,
          quantity: peopleCount,
          price: firstHourProduct.price
        });
        newHourTotal += peopleCount * firstHourProduct.price;
      }
      if (requiredSecondHourCount > 0 && secondHourProduct) {
        addedItems.push({
          product_id: secondHourProduct.id,
          name: secondHourProduct.name,
          quantity: peopleCount * requiredSecondHourCount,
          price: secondHourProduct.price
        });
        newHourTotal += peopleCount * requiredSecondHourCount * secondHourProduct.price;
      }
    }

    return {
      requiredSecondHourCount,
      convertedToDayPass,
      firstHourProduct,
      secondHourProduct,
      dayPassProduct,
      addedItems,
      newHourTotal
    };
  }
};

// 初始化數據庫
initDatabase();

module.exports = {
  get db() { return db; },
  ...dbOperations
};