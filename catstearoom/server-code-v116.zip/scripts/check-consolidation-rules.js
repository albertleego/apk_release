#!/usr/bin/env node
/**
 * 代碼整合守則檢查（guard script）
 *
 * 確保 Feature Flags 集中喺 server/config/runtime.js，唔准喺其他 code 直接寫 env。
 * 違規 → 退出碼 1（git pre-commit 會擋住 commit）。
 *
 * 用法：
 *   node scripts/check-consolidation-rules.js
 * 或經 pre-commit hook 自動跑。
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const CONFIG_FILE = 'server/config/runtime.js';

// 受 runtime.js 管理嘅環境變數：RUNNING_MODE + MODE_DEFAULTS 內嘅 feature flags
// ENABLE_SYNC / SYNC_MOCK_MODE 係平板 data sync 本身嘅 config（唔係 feature flag），容許直接用
const FEATURE_FLAG_RE = /process\.env\.(RUNNING_MODE|ENABLE_[A-Z0-9_]+|ALLOW_CROSS_STORE_ADMIN)\b/g;
const SYNC_ALLOWLIST = ['ENABLE_SYNC', 'SYNC_MOCK_MODE'];

/** 遞歸收集所有 .js 檔（跳過 node_modules / .git） */
function collectFiles(dir, out = []) {
    if (dir.includes('node_modules') || dir.includes('.git')) return out;
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
    catch (e) { return out; }
    for (const entry of entries) {
        if (entry.name === 'node_modules' || entry.name === '.git') continue;
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) collectFiles(full, out);
        else if (entry.name.endsWith('.js')) out.push(full);
    }
    return out;
}

// ---------- 第一層檢查：feature flags 集中喺 runtime.js ----------
const violations = [];
for (const file of collectFiles(ROOT)) {
    const rel = path.relative(ROOT, file).replace(/\\/g, '/');
    if (rel === CONFIG_FILE) continue; // runtime.js 本身例外
    const lines = fs.readFileSync(file, 'utf8').split('\n');
    lines.forEach((line, i) => {
        const matches = line.match(FEATURE_FLAG_RE);
        if (!matches) return;
        for (const m of matches) {
            const flagName = m.replace('process.env.', '');
            if (SYNC_ALLOWLIST.includes(flagName)) continue;
            violations.push(`${rel}:${i + 1}: ${m} 唔應該喺 runtime.js 以外直接用，請改用 runtime.xxx()`);
        }
    });
}

// ---------- 第二層檢查：硬寫 credential（密碼 / API key / token）----------
// 掃 .js / .py / .sh / .json，檢查有冇硬寫敏感值入 code。
// 豁免：.env 相關、config 範例檔、placeholder / 假值 / 空值、
//       gitignored 工作目錄（唔會 commit）、console.log 訊息、test 檔。
const CRED_SUSPECT_RE = /\b(password|passwd|api[_-]?key|apikey|token|secret|client[_-]?secret|access[_-]?key|private[_-]?key)\b\s*[:=]\s*['"][^'"]{6,}['"]/i;
// 真正洩漏過、需要防止回流的 live credential（唔含 DB seed 預設值 / test 值）
const KNOWN_LIVE_KEYS = [
    '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763', // ALIYUN_API_KEY（live，已輪換計劃中）
    'a693cdc9124815afa23a90e3dd66bb80e69546cafcfe8fdb1b9ceb6173ab29ac', // staging（g8y）ALIYUN_API_KEY，2026-08-30 輪換
    'temp123456!', // 舊阿里雲 root 密碼
    'temp1234!',   // 舊阿里雲 root 密碼
];
const PLACEHOLDER_PATTERN = /^['"]?[<(\[{]?(your_|your-|xxx+|<|placeholder|changeme|example|dummy|your|[A-Z_]+_KEY|[A-Z_]+_SECRET|[A-Z_]+_PASSWORD)/i;
// gitignored 工作目錄 / backup 檔 / test 檔（唔會 commit，掃佢哋只會誤報）
const CRED_EXEMPT_PATTERNS = [
    /\.env(\.|$)/,                 // .env 同 .env.*（真正放 secret 嘅地方）
    /\.example\.[a-z]+$/,          // config 範例（.env.example 等）
    /\.gitignore$/,                // 唔係 code
    /check-consolidation-rules\.js$/, // 自己
    /(^|\/)(aliyun-current|aliyun-modify-work|temp-aliyun-fix|temp-aliyun-fix-modify|aliyun-backup-product-modal)\//, // gitignored 工作目錄
    /(^|\/)(aliyun_enhanced_cashier|aliyun-backup-product-modal)/, // gitignored 備份檔
    /\.(backup|bak)\./,
    /\.backup$|\.bak$/,
    /(^|\/)(test|test-|test_|\.test\.)[^/]*\.(js|py|ts|sh)$/, // test 檔（gitignored test*.js）
    /ALIYUN_ROOT_PASSWORD|PRODUCTION_ECS_PASSWORD|DEMO_STAGING_ECS_PASSWORD/, // 密碼變數名出現喺錯誤訊息 / 提示文案（唔係值）
];
const CRED_ALLOWED_VALUE_RE = /^(process\.env\.|config\.|runtime\.|os\.environ|process\.env\[|const\s+ALIYUN_API_KEY)/;

const knownLeakedFiles = new Set();
const credViolations = [];
const ALREADY_TRACKED_EXT = /\.(js|py|sh|json|ts|mjs|cjs)$/;

for (const file of collectFiles(ROOT)) {
    const rel = path.relative(ROOT, file).replace(/\\/g, '/');
    if (rel === CONFIG_FILE) continue; // runtime.js 本身例外（第一層）
    if (CRED_EXEMPT_PATTERNS.some(p => p.test(rel))) continue;
    if (!ALREADY_TRACKED_EXT.test(rel)) continue;

    const content = fs.readFileSync(file, 'utf8');
    const lines = content.split('\n');

    // (a) 硬寫 credential pattern
    lines.forEach((line, i) => {
        const trimmed = line.trim();
        if (CRED_ALLOWED_VALUE_RE.test(trimmed)) return;             // 讀 env / config 嘅唔算
        if (PLACEHOLDER_PATTERN.test(trimmed)) return;               // placeholder 唔算
        if (/^console\.(log|error|warn|info)/.test(trimmed)) return; // log 訊息唔算 credential
        // 值來源係 env / config（例如 apiKey='${process.env.X}'）唔算硬寫
        if (/process\.env\.|process\.env\[|config\.|runtime\.|os\.environ/.test(trimmed)) return;
        const m = trimmed.match(CRED_SUSPECT_RE);
        if (m) {
            credViolations.push(`${rel}:${i + 1}: 疑似硬寫 credential：${m[0].slice(0, 60)} — 請改用 .env / config，唔好寫入 code`);
        }
    });

    // (b) 已知 live key 殘留
    if (KNOWN_LIVE_KEYS.some(k => content.includes(k))) {
        knownLeakedFiles.add(rel);
    }
}

for (const rel of knownLeakedFiles) {
    credViolations.push(`${rel}: 含已知 live credential（已被標記洩漏），請移除或改讀 .env`);
}

const allViolations = [...violations, ...credViolations];

if (allViolations.length) {
    console.error('❌ 代碼整合守則違規：');
    allViolations.forEach(v => console.error('  ' + v));
    console.error('\n修正方法：');
    console.error('  · feature flags → 去 server/config/runtime.js 定義，用 runtime.xxx() 引用');
    console.error('  · credential → 放入 .env（gitignored），code 用 process.env.XXX 讀取');
    process.exit(1);
}
console.log('✓ 代碼整合守則檢查通過（feature flags 集中喺 runtime.js + 無硬寫 credential）');
