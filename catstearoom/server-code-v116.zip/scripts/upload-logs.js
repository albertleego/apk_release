/**
 * 自動咖啡館系統 - 每小時 Log 上傳腳本
 *
 * 功能：
 * 1. 將 logs/ 目錄下的 .log 檔案上傳到阿里雲伺服器
 * 2. 清理平板本地超過 7 天的舊 Log
 *
 * 依賴：axios（Node.js 模組）
 *
 * 定時執行 (Termux crond):
 *   7 * * * * node /path/to/scripts/upload-logs.js >> /path/to/logs/cron_upload.log 2>&1
 *
 * 或手動執行一次：
 *   node scripts/upload-logs.js
 */
const path = require('path');
const fs = require('fs');

// ============ 設定 ============

const CONFIG_PATH = path.join(__dirname, '..', 'gdrive-config.json');
const DEFAULT_DB_PATH = path.join(__dirname, '..', 'database', 'cafe.db');

/** 預設設定 */
const DEFAULT_CONFIG = {
  store_id: process.env.STORE_ID || 'store_1',
  store_name: '',
  db_path: DEFAULT_DB_PATH,
  log_dir: path.join(__dirname, '..', 'logs'),
  retention_days: 7,
  aliyun_server: process.env.ALIYUN_SERVER || 'http://47.239.121.13:3000',
  aliyun_api_key: process.env.ALIYUN_API_KEY || '',
};

// ============ 工具函式 ============

function getHongKongTime() {
  const now = new Date();
  return new Date(now.getTime() + 8 * 3600000);
}

/** 從資料庫讀取分店中文名 */
function getStoreNameFromDB(dbPath, storeId) {
  return new Promise((resolve) => {
    if (!dbPath || !fs.existsSync(dbPath)) return resolve(null);
    try {
      const sqlite3 = require('sqlite3');
      const db = new sqlite3.Database(dbPath, sqlite3.OPEN_READONLY, (err) => {
        if (err) return resolve(null);
        db.get('SELECT store_name FROM stores WHERE id = ?', [storeId], (err, row) => {
          db.close();
          resolve(row ? row.store_name : null);
        });
      });
    } catch (e) {
      resolve(null);
    }
  });
}

/** 載入設定 */
function loadConfig() {
  const config = { ...DEFAULT_CONFIG };
  if (fs.existsSync(CONFIG_PATH)) {
    try {
      const userConfig = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
      Object.assign(config, userConfig);
    } catch (e) {
      console.error(`[upload-logs] 讀取設定檔失敗 ${CONFIG_PATH}:`, e.message);
    }
  }
  return config;
}

/**
 * 透過阿里雲 API 上傳 Log 檔案
 */
async function uploadLogToAliyun(config, localPath, remoteFilename) {
  const content = fs.readFileSync(localPath, 'utf8');
  const server = config.aliyun_server.replace(/\/$/, '');
  const url = `${server}/api/sync/upload-logs`;

  let axios;
  try {
    axios = require('axios');
  } catch (e) {
    console.error('[upload-logs] axios 未安裝，嘗試使用動態載入');
    axios = (await import('axios')).default;
  }

  const response = await axios.post(url, {
    filename: remoteFilename,
    store_name: config.store_name,
    content: content
  }, {
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': config.aliyun_api_key
    },
    timeout: 60000
  });

  return response.data;
}

// ============ 主要功能 ============

/**
 * 上傳 Log 檔案到阿里雲
 */
async function uploadLogs(config) {
  const hk = getHongKongTime();
  const timeStr = hk.toISOString().substring(11, 19).replace(/:/g, '-');

  const logDir = config.log_dir;
  if (!fs.existsSync(logDir)) {
    console.warn(`[upload-logs] Log 目錄不存在: ${logDir}，跳過上傳`);
    return;
  }

  const files = fs.readdirSync(logDir).filter(f => f.endsWith('.log') && !f.startsWith('.'));

  // 沒有 log 檔案時跳過
  if (files.length === 0) {
    console.log('[upload-logs] 沒有 Log 檔案，跳過上傳');
    return;
  }

  let uploadedCount = 0;

  for (const file of files) {
    const localPath = path.join(logDir, file);

    // 跳過空檔案
    const stat = fs.statSync(localPath);
    if (stat.size === 0) {
      console.log(`[upload-logs] 跳過空檔案: ${file}`);
      continue;
    }

    // 上傳時加入時間戳記命名，避免覆蓋之前的檔案
    const remoteFileName = file.replace('.log', `_${timeStr}.log`);

    try {
      console.log(`[upload-logs] 上傳中: ${file} → ${config.store_name}/${remoteFileName}`);
      const result = await uploadLogToAliyun(config, localPath, remoteFileName);
      console.log(`[upload-logs] ✅ 上傳完成: ${remoteFileName} (${result.size_bytes} bytes)`);
      uploadedCount++;
    } catch (e) {
      console.error(`[upload-logs] ❌ 上傳失敗: ${file}`, e.message);
      if (e.response) {
        console.error(`[upload-logs]    狀態: ${e.response.status}, 訊息:`, JSON.stringify(e.response.data));
      }
    }
  }

  console.log(`[upload-logs] 本次上傳 ${uploadedCount}/${files.length} 個檔案`);
}

/**
 * 清理本地超過 retention_days 的 Log 檔案
 */
function cleanupLocalLogs(config) {
  const logDir = config.log_dir;
  if (!fs.existsSync(logDir)) return;

  const now = Date.now();
  const maxAgeMs = config.retention_days * 24 * 60 * 60 * 1000;
  let deletedCount = 0;

  const files = fs.readdirSync(logDir).filter(f => f.endsWith('.log'));
  for (const file of files) {
    const filePath = path.join(logDir, file);
    try {
      const stat = fs.statSync(filePath);
      if (now - stat.mtime.getTime() > maxAgeMs) {
        fs.unlinkSync(filePath);
        console.log(`[upload-logs] 🗑️ 已刪除本地舊 Log: ${file}`);
        deletedCount++;
      }
    } catch (e) {
      console.error(`[upload-logs] 刪除失敗: ${file}`, e.message);
    }
  }

  if (deletedCount > 0) {
    console.log(`[upload-logs] 本地共清理 ${deletedCount} 個舊檔案`);
  } else {
    console.log('[upload-logs] 本地無需清理');
  }
}

// ============ 主程式 ============

async function main() {
  console.log('='.repeat(50));
  console.log('[upload-logs] 開始 Log 上傳與清理（阿里雲）');
  console.log('[upload-logs] 時間:', getHongKongTime().toISOString());
  console.log('='.repeat(50));

  const config = loadConfig();
  console.log(`[upload-logs] 分店 ID: ${config.store_id}`);

  // 自動從資料庫讀取分店中文名
  if (!config.store_name) {
    const name = await getStoreNameFromDB(config.db_path, config.store_id);
    if (name) {
      config.store_name = name;
      console.log(`[upload-logs] 自動讀取分店名: ${config.store_name}`);
    } else {
      config.store_name = config.store_id;
    }
  }
  console.log(`[upload-logs] 上傳目標: ${config.aliyun_server}`);
  console.log(`[upload-logs] 保留天數: ${config.retention_days} 天`);

  // 1. 上傳 Log
  console.log('\n--- 上傳階段 ---');
  await uploadLogs(config);

  // 2. 清理本地 >7 天
  console.log('\n--- 清理本地 ---');
  cleanupLocalLogs(config);

  console.log('\n' + '='.repeat(50));
  console.log('[upload-logs] 完成');
  console.log('='.repeat(50));
}

main().catch(e => console.error('[upload-logs] 錯誤:', e.message));
