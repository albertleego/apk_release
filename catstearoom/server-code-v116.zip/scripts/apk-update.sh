#!/data/data/com.termux/files/usr/bin/bash
# 自動咖啡館系統 - APK 自動更新腳本
# 定時執行：crond (每天香港時間 00:07)
# 從 GitHub apk_release repo 檢查和更新 APK

# Termux 家目錄（使用固定路徑避免 run-as 與 crond 的 HOME 差異）
TERMUX_HOME="/data/data/com.termux/files/home"

VERSION_FILE="$TERMUX_HOME/.apk_version"
APK_FILE="$TERMUX_HOME/autocafe-update.apk"
VERSION_URL="https://raw.githubusercontent.com/albertleego/apk_release/main/latest-version.json"
LOG_FILE="$TERMUX_HOME/logs/apk-update.log"
NODE="/data/data/com.termux/files/usr/bin/node"
TMP_DIR="$TERMUX_HOME/.apk_update_tmp"

mkdir -p "$TERMUX_HOME/logs" "$TMP_DIR"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] === APK 更新檢查開始 ===" >> "$LOG_FILE"

# 1. 讀取目前版本
CURRENT_VERSION=""
if [ -f "$VERSION_FILE" ]; then
    CURRENT_VERSION=$(cat "$VERSION_FILE")
fi
echo "[apk-update] 目前版本: $CURRENT_VERSION" >> "$LOG_FILE"

# 2. 獲取最新版本資訊
curl -s -o "$TMP_DIR/latest-version.json" "$VERSION_URL"
if [ ! -f "$TMP_DIR/latest-version.json" ] || [ ! -s "$TMP_DIR/latest-version.json" ]; then
    echo "[apk-update] ❌ 無法獲取版本資訊" >> "$LOG_FILE"
    rm -rf "$TMP_DIR"
    exit 1
fi

# 3. 用 Node.js 解析 JSON
LATEST_JSON=$("$NODE" -e "
const d = JSON.parse(require('fs').readFileSync('$TMP_DIR/latest-version.json','utf8'));
console.log(d.version_code + '|' + d.version + '|' + d.apk_url + '|' + d.md5);
")

NEW_VERSION_CODE=$(echo "$LATEST_JSON" | cut -d'|' -f1)
NEW_VERSION_NAME=$(echo "$LATEST_JSON" | cut -d'|' -f2)
APK_URL=$(echo "$LATEST_JSON" | cut -d'|' -f3)
NEW_MD5=$(echo "$LATEST_JSON" | cut -d'|' -f4)

echo "[apk-update] 最新版本: $NEW_VERSION_CODE ($NEW_VERSION_NAME)" >> "$LOG_FILE"

# 4. 比對版本
if [ "$CURRENT_VERSION" = "$NEW_VERSION_CODE" ]; then
    echo "[apk-update] ✅ 已是最新版本" >> "$LOG_FILE"
    rm -rf "$TMP_DIR"
    exit 0
fi

# 5. 下載新 APK
echo "[apk-update] 下載新版本: $APK_URL" >> "$LOG_FILE"
curl -L -o "$APK_FILE" "$APK_URL" 2>> "$LOG_FILE"

if [ ! -f "$APK_FILE" ]; then
    echo "[apk-update] ❌ 下載失敗" >> "$LOG_FILE"
    rm -rf "$TMP_DIR"
    exit 1
fi

# 6. MD5 校驗
DL_MD5=$(md5sum "$APK_FILE" | cut -d' ' -f1)
if [ "$DL_MD5" != "$NEW_MD5" ]; then
    echo "[apk-update] ❌ MD5 不符 (預期 $NEW_MD5, 實際 $DL_MD5)" >> "$LOG_FILE"
    rm -f "$APK_FILE"
    rm -rf "$TMP_DIR"
    exit 1
fi
echo "[apk-update] ✅ MD5 驗證通過: $DL_MD5" >> "$LOG_FILE"

# 7. 安裝 APK（嘗試多種方法）
echo "[apk-update] 安裝 APK v$NEW_VERSION_NAME ..." >> "$LOG_FILE"

INSTALL_OK=0

# 方法 A：複製到 /data/local/tmp/ 再 pm install
cp "$APK_FILE" /data/local/tmp/autocafe-update.apk 2>/dev/null
if /system/bin/pm install -r /data/local/tmp/autocafe-update.apk 2>>"$LOG_FILE"; then
    INSTALL_OK=1
    echo "[apk-update] ✅ 方法 A 安裝成功" >> "$LOG_FILE"
fi

# 方法 B：直接用 pm install
if [ "$INSTALL_OK" = "0" ]; then
    if /system/bin/pm install -r "$APK_FILE" 2>>"$LOG_FILE"; then
        INSTALL_OK=1
        echo "[apk-update] ✅ 方法 B 安裝成功" >> "$LOG_FILE"
    fi
fi

# 方法 C：用 am start 開啟安裝器（需用戶按安裝）
if [ "$INSTALL_OK" = "0" ]; then
    am start -a android.intent.action.VIEW \
        -d "file://${APK_FILE}" \
        -t "application/vnd.android.package-archive" 2>/dev/null
    echo "[apk-update] ℹ️ 已開啟安裝器，請在平板上按「安裝」" >> "$LOG_FILE"
    # 即使需手動按安裝，也記錄版本避免每天重複下載
    INSTALL_OK=1
fi

# 8. 更新版本記錄
if [ "$INSTALL_OK" = "1" ]; then
    echo "$NEW_VERSION_CODE" > "$VERSION_FILE"
    echo "[apk-update] ✅ APK 更新完成: v$NEW_VERSION_NAME" >> "$LOG_FILE"
    termux-notification --title "APK 已更新" \
        --content "自動咖啡館已更新至 $NEW_VERSION_NAME" \
        --priority high 2>/dev/null || true
else
    echo "[apk-update] ℹ️ APK 已下載至: $APK_FILE" >> "$LOG_FILE"
    echo "[apk-update] ℹ️ 請手動安裝" >> "$LOG_FILE"
    termux-notification --title "APK 更新待安裝" \
        --content "新版本 $NEW_VERSION_NAME 已下載，請點擊安裝" \
        --action "am start -a android.intent.action.VIEW -d ${APK_FILE} -t application/vnd.android.package-archive" \
        --priority high 2>/dev/null || true
fi

rm -rf "$TMP_DIR"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] === APK 更新檢查結束 ===" >> "$LOG_FILE"
