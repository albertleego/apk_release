/**
 * 香港時間工具
 * 香港時間為 UTC+8，無夏令時
 */

/**
 * 獲取當前香港時間的 Date 對象
 * @returns {Date} 香港時間的 Date 對象
 */
function getHongKongTime() {
    const now = new Date();
    return convertToHongKongTime(now);
}

/**
 * 將任意 Date 對象轉換為香港時間
 * @param {Date} date - 原始 Date 對象（假設為 UTC 或本地時間）
 * @returns {Date} 香港時間的 Date 對象
 */
function convertToHongKongTime(date) {
    // 方法1：如果設置了時區環境變量，直接返回新 Date（使用本地方法）
    // 方法2：手動計算 UTC+8
    const utcTime = date.getTime() + (date.getTimezoneOffset() * 60000);
    const hongKongTime = new Date(utcTime + (8 * 60 * 60000));
    return hongKongTime;
}

/**
 * 獲取香港時間的日期字符串（YYYY-MM-DD）
 * @param {Date} [date] - 可選的 Date 對象，默認當前時間
 * @returns {string} YYYY-MM-DD 格式的日期字符串
 */
function getHongKongDateString(date = null) {
    const hkDate = date ? convertToHongKongTime(date) : getHongKongTime();
    const year = hkDate.getFullYear();
    const month = String(hkDate.getMonth() + 1).padStart(2, '0');
    const day = String(hkDate.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

/**
 * 獲取香港時間的時間字符串（HH:MM）
 * @param {Date} [date] - 可選的 Date 對象，默認當前時間
 * @returns {string} HH:MM 格式的時間字符串
 */
function getHongKongTimeString(date = null) {
    const hkDate = date ? convertToHongKongTime(date) : getHongKongTime();
    const hours = String(hkDate.getHours()).padStart(2, '0');
    const minutes = String(hkDate.getMinutes()).padStart(2, '0');
    return `${hours}:${minutes}`;
}

/**
 * 獲取香港時間的星期幾
 * 0 = 星期日, 1 = 星期一, ..., 6 = 星期六
 * @param {Date} [date] - 可選的 Date 對象，默認當前時間
 * @returns {number} 星期幾（0-6）
 */
function getHongKongDayOfWeek(date = null) {
    const hkDate = date ? convertToHongKongTime(date) : getHongKongTime();
    return hkDate.getDay();
}

/**
 * 檢查指定日期是否為香港時間的節假日（星期六、星期日）
 * @param {Date} [date] - 可選的 Date 對象，默認當前時間
 * @returns {boolean} 是否為節假日
 */
function isHongKongWeekend(date = null) {
    const dayOfWeek = getHongKongDayOfWeek(date);
    return dayOfWeek === 0 || dayOfWeek === 6; // 星期日或星期六
}

/**
 * 獲取完整的香港時間信息對象
 * @param {Date} [date] - 可選的 Date 對象，默認當前時間
 * @returns {Object} 包含香港時間各組件的對象
 */
function getHongKongTimeInfo(date = null) {
    const hkDate = date ? convertToHongKongTime(date) : getHongKongTime();
    return {
        date: hkDate,
        dateString: getHongKongDateString(hkDate),
        timeString: getHongKongTimeString(hkDate),
        dayOfWeek: getHongKongDayOfWeek(hkDate),
        isWeekend: isHongKongWeekend(hkDate),
        year: hkDate.getFullYear(),
        month: hkDate.getMonth() + 1,
        day: hkDate.getDate(),
        hours: hkDate.getHours(),
        minutes: hkDate.getMinutes(),
        seconds: hkDate.getSeconds()
    };
}

module.exports = {
    getHongKongTime,
    convertToHongKongTime,
    getHongKongDateString,
    getHongKongTimeString,
    getHongKongDayOfWeek,
    isHongKongWeekend,
    getHongKongTimeInfo
};