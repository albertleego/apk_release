const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');
const storeAwareMiddleware = require('../middleware/store-aware');

// 為所有路由添加分店上下文中間件
router.use(storeAwareMiddleware.initStoreContext);

/**
 * @route GET /api/inventory/low-stock
 * @desc 獲取低庫存商品
 * @access Private/Staff
 */
router.get('/low-stock', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const storeId = req.storeContext?.store_id || 'default_store';
        const query = `
            SELECT p.*,
                   CASE
                     WHEN p.stock = 0 THEN '缺貨'
                     WHEN p.stock <= p.min_stock THEN '低庫存'
                     ELSE '正常'
                   END as stock_status,
                   p.min_stock - p.stock as needed_quantity
            FROM products p
            WHERE (p.stock <= p.min_stock OR p.stock = 0) AND p.store_id = ?
            ORDER BY p.stock ASC, p.name ASC
        `;

        db.all(query, [storeId], (err, products) => {
            if (err) {
                console.error('查詢低庫存商品錯誤:', err);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: err.message
                });
            }

            // 分類商品狀態
            const outOfStock = products.filter(p => p.stock === 0);
            const lowStock = products.filter(p => p.stock > 0 && p.stock <= p.min_stock);

            res.json({
                success: true,
                data: {
                    products,
                    summary: {
                        total_low_stock: products.length,
                        out_of_stock: outOfStock.length,
                        low_stock: lowStock.length,
                        urgent_restock: outOfStock.length + lowStock.length
                    },
                    categories: {
                        out_of_stock: outOfStock,
                        low_stock: lowStock
                    }
                }
            });
        });
    } catch (error) {
        console.error('獲取低庫存商品錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取低庫存商品失敗',
            message: error.message
        });
    }
});

/**
 * @route POST /api/inventory/restock
 * @desc 批量補貨
 * @access Private/Staff
 */
router.post('/restock', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const { items, reason = '手動補貨', supplier } = req.body;
        const storeId = req.storeContext?.store_id || 'default_store';
        const { employee } = req;
        const ipAddress = req.ip || req.connection.remoteAddress;

        if (!items || !Array.isArray(items) || items.length === 0) {
            return res.status(400).json({
                success: false,
                error: '缺少必要字段',
                message: '請提供補貨項目列表'
            });
        }

        // 驗證每個項目
        const validItems = [];
        for (const item of items) {
            if (!item.product_id || typeof item.quantity !== 'number' || item.quantity <= 0) {
                return res.status(400).json({
                    success: false,
                    error: '無效的補貨項目',
                    message: `項目 ${item.product_id || '未知'} 的數量必須大於0`
                });
            }

            // 檢查商品是否存在
            const product = await new Promise((resolve, reject) => {
                db.get('SELECT * FROM products WHERE id = ? AND store_id = ?', [item.product_id, storeId], (err, row) => {
                    if (err) reject(err);
                    else resolve(row);
                });
            });

            if (!product) {
                return res.status(404).json({
                    success: false,
                    error: '商品不存在',
                    message: `商品 ID ${item.product_id} 不存在`
                });
            }

            validItems.push({ ...item, current_stock: product.stock });
        }

        // 開始事務處理
        const results = [];
        const errors = [];

        for (const item of validItems) {
            try {
                const newQuantity = item.current_stock + item.quantity;
                const now = new Date().toISOString();

                // 更新商品庫存
                await new Promise((resolve, reject) => {
                    db.run(
                        `UPDATE products SET stock = ?, last_restocked = ? WHERE id = ? AND store_id = ?`,
                        [newQuantity, now, item.product_id, storeId],
                        function(err) {
                            if (err) reject(err);
                            else resolve(this.changes);
                        }
                    );
                });

                // 創建庫存變更記錄
                const logId = uuidv4();
                await new Promise((resolve, reject) => {
                    db.run(
                        `INSERT INTO inventory_logs
                        (id, product_id, employee_id, change_type, quantity_change, previous_quantity, new_quantity, reason, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                        [
                            logId,
                            item.product_id,
                            employee.id,
                            'restock',
                            item.quantity,
                            item.current_stock,
                            newQuantity,
                            `${reason}${supplier ? ` - 供應商: ${supplier}` : ''}`,
                            now
                        ],
                        function(err) {
                            if (err) reject(err);
                            else resolve(logId);
                        }
                    );
                });

                // 創建審計日誌
                authMiddleware.createAuditLog(
                    employee.id,
                    'inventory_restock',
                    `補貨商品 ${item.product_id}, 數量: ${item.quantity}, 原因: ${reason}`,
                    ipAddress
                );

                results.push({
                    product_id: item.product_id,
                    quantity: item.quantity,
                    previous_stock: item.current_stock,
                    new_stock: newQuantity,
                    success: true
                });
            } catch (itemError) {
                errors.push({
                    product_id: item.product_id,
                    error: itemError.message,
                    success: false
                });
                console.error(`補貨商品 ${item.product_id} 錯誤:`, itemError);
            }
        }

        res.json({
            success: true,
            message: `成功補貨 ${results.length} 個商品，失敗 ${errors.length} 個`,
            data: {
                results,
                errors: errors.length > 0 ? errors : undefined
            }
        });
    } catch (error) {
        console.error('批量補貨錯誤:', error);
        res.status(500).json({
            success: false,
            error: '批量補貨失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/inventory/logs
 * @desc 獲取庫存變更記錄
 * @access Private/Staff
 */
router.get('/logs', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const {
            product_id,
            change_type,
            employee_id,
            start_date,
            end_date,
            page = 1,
            limit = 20
        } = req.query;
        const storeId = req.storeContext?.store_id || 'default_store';

        let query = `
            SELECT il.*,
                   p.name as product_name,
                   e.username as employee_username,
                   e.full_name as employee_name
            FROM inventory_logs il
            LEFT JOIN products p ON il.product_id = p.id
            LEFT JOIN employees e ON il.employee_id = e.id
            WHERE 1=1
            AND p.store_id = ?
        `;

        const params = [storeId];

        // 添加篩選條件
        if (product_id) {
            query += ` AND il.product_id = ?`;
            params.push(product_id);
        }

        if (change_type) {
            query += ` AND il.change_type = ?`;
            params.push(change_type);
        }

        if (employee_id) {
            query += ` AND il.employee_id = ?`;
            params.push(employee_id);
        }

        if (start_date) {
            query += ` AND il.created_at >= ?`;
            params.push(start_date);
        }

        if (end_date) {
            query += ` AND il.created_at <= ?`;
            params.push(end_date);
        }

        query += ` ORDER BY il.created_at DESC`;

        // 獲取總數
        const countQuery = query.replace(
            'SELECT il.*, p.name as product_name, e.username as employee_username, e.full_name as employee_name',
            'SELECT COUNT(*) as total'
        );

        db.get(countQuery, params, (countErr, countRow) => {
            if (countErr) {
                console.error('查詢庫存記錄總數錯誤:', countErr);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: countErr.message
                });
            }

            const total = countRow.total || 0;
            const totalPages = Math.ceil(total / limit);
            const offset = (page - 1) * limit;

            // 添加分頁
            query += ` LIMIT ? OFFSET ?`;
            params.push(limit, offset);

            db.all(query, params, (err, logs) => {
                if (err) {
                    console.error('查詢庫存記錄錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                res.json({
                    success: true,
                    data: {
                        logs,
                        pagination: {
                            total,
                            total_pages: totalPages,
                            current_page: parseInt(page),
                            page_size: parseInt(limit),
                            has_next: page < totalPages,
                            has_prev: page > 1
                        },
                        summary: {
                            total_records: total,
                            change_types: logs.reduce((acc, log) => {
                                acc[log.change_type] = (acc[log.change_type] || 0) + 1;
                                return acc;
                            }, {})
                        }
                    }
                });
            });
        });
    } catch (error) {
        console.error('獲取庫存記錄錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取庫存記錄失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/inventory/summary
 * @desc 獲取庫存摘要
 * @access Private/Staff
 */
router.get('/summary', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const storeId = req.storeContext?.store_id || 'default_store';
        const query = `
            SELECT
                COUNT(*) as total_products,
                SUM(CASE WHEN stock = 0 THEN 1 ELSE 0 END) as out_of_stock,
                SUM(CASE WHEN stock > 0 AND stock <= min_stock THEN 1 ELSE 0 END) as low_stock,
                SUM(CASE WHEN stock > min_stock THEN 1 ELSE 0 END) as normal_stock,
                SUM(stock) as total_stock_value,
                SUM(stock * price) as estimated_value,
                GROUP_CONCAT(DISTINCT category) as categories
            FROM products
            WHERE is_available = 1 AND store_id = ?
        `;

        db.get(query, [storeId], (err, summary) => {
            if (err) {
                console.error('查詢庫存摘要錯誤:', err);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: err.message
                });
            }

            // 獲取最近7天的庫存變更
            const weekAgo = new Date();
            weekAgo.setDate(weekAgo.getDate() - 7);
            const weekAgoISO = weekAgo.toISOString();

            const changeQuery = `
                SELECT
                    DATE(il.created_at) as date,
                    il.change_type,
                    SUM(il.quantity_change) as total_change
                FROM inventory_logs il
                JOIN products p ON il.product_id = p.id
                WHERE il.created_at >= ? AND p.store_id = ?
                GROUP BY DATE(il.created_at), il.change_type
                ORDER BY date DESC
            `;

            db.all(changeQuery, [weekAgoISO, storeId], (changeErr, changes) => {
                if (changeErr) {
                    console.error('查詢庫存變更統計錯誤:', changeErr);
                    // 繼續返回摘要，忽略錯誤
                }

                // 獲取最常變更的商品
                const topProductsQuery = `
                    SELECT
                        p.name,
                        COUNT(il.id) as change_count,
                        SUM(ABS(il.quantity_change)) as total_quantity_changed
                    FROM inventory_logs il
                    JOIN products p ON il.product_id = p.id
                    WHERE il.created_at >= ? AND p.store_id = ?
                    GROUP BY il.product_id
                    ORDER BY change_count DESC
                    LIMIT 5
                `;

                db.all(topProductsQuery, [weekAgoISO, storeId], (topErr, topProducts) => {
                    if (topErr) {
                        console.error('查詢熱門商品錯誤:', topErr);
                    }

                    res.json({
                        success: true,
                        data: {
                            summary,
                            recent_changes: changes || [],
                            top_changed_products: topProducts || [],
                            timestamp: new Date().toISOString()
                        }
                    });
                });
            });
        });
    } catch (error) {
        console.error('獲取庫存摘要錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取庫存摘要失敗',
            message: error.message
        });
    }
});

/**
 * @route POST /api/inventory/adjust
 * @desc 手動調整庫存
 * @access Private/Staff
 */
router.post('/adjust', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const { product_id, adjustment, reason = '手動調整' } = req.body;
        const storeId = req.storeContext?.store_id || 'default_store';
        const { employee } = req;
        const ipAddress = req.ip || req.connection.remoteAddress;

        if (!product_id || typeof adjustment !== 'number') {
            return res.status(400).json({
                success: false,
                error: '缺少必要字段',
                message: '請提供商品ID和調整數量'
            });
        }

        // 檢查商品是否存在
        const product = await new Promise((resolve, reject) => {
            db.get('SELECT * FROM products WHERE id = ? AND store_id = ?', [product_id, storeId], (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });

        if (!product) {
            return res.status(404).json({
                success: false,
                error: '商品不存在',
                message: `商品 ID ${product_id} 不存在`
            });
        }

        // 計算新庫存量
        const newQuantity = product.stock + adjustment;
        if (newQuantity < 0) {
            return res.status(400).json({
                success: false,
                error: '庫存不足',
                message: `調整後庫存不能為負數 (當前: ${product.stock}, 調整: ${adjustment})`
            });
        }

        const now = new Date().toISOString();

        // 更新商品庫存
        await new Promise((resolve, reject) => {
            db.run(
                `UPDATE products SET stock = ?, updated_at = ? WHERE id = ? AND store_id = ?`,
                [newQuantity, now, product_id, storeId],
                function(err) {
                    if (err) reject(err);
                    else resolve(this.changes);
                }
            );
        });

        // 創建庫存變更記錄
        const logId = uuidv4();
        await new Promise((resolve, reject) => {
            db.run(
                `INSERT INTO inventory_logs
                (id, product_id, employee_id, change_type, quantity_change, previous_quantity, new_quantity, reason, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [
                    logId,
                    product_id,
                    employee.id,
                    adjustment > 0 ? 'adjust_add' : 'adjust_remove',
                    adjustment,
                    product.stock,
                    newQuantity,
                    reason,
                    now
                ],
                function(err) {
                    if (err) reject(err);
                    else resolve(logId);
                }
            );
        });

        // 創建審計日誌
        authMiddleware.createAuditLog(
            employee.id,
            'inventory_adjust',
            `調整商品庫存 ${product.name}, 調整: ${adjustment}, 新庫存: ${newQuantity}, 原因: ${reason}`,
            ipAddress
        );

        res.json({
            success: true,
            message: `成功調整庫存: ${product.name}`,
            data: {
                product_id,
                product_name: product.name,
                adjustment,
                previous_stock: product.stock,
                new_stock: newQuantity,
                timestamp: now
            }
        });
    } catch (error) {
        console.error('調整庫存錯誤:', error);
        res.status(500).json({
            success: false,
            error: '調整庫存失敗',
            message: error.message
        });
    }
});

module.exports = router;