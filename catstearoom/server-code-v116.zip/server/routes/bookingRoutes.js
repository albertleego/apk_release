const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');

// 阿里雲唯一源頭：所有寫入/讀取都同步 forward 去阿里雲執行，阿里雲嘅規則（容量/暫停/重複/驗證）
// 喺阿里雲嗰度執行，阿里雲回覆原封轉發俾 client。本地 DB 只係唯讀 cache/mirror，
// 喺阿里雲確認之後先 best-effort 更新（失敗只 log，唔影響回覆）。
const ALIYUN_SERVER = (process.env.ALIYUN_SERVER || 'http://47.239.121.13:3000').replace(/\/$/, '');
const API_KEY = process.env.ALIYUN_API_KEY || process.env.MAIN_API_KEY || '';
const FETCH_TIMEOUT_MS = parseInt(process.env.ALIYUN_PROXY_TIMEOUT || '8000', 10);

/**
 * 同步 forward 去阿里雲，返回 { status, body }（要原封轉發 status code）。
 * 網絡失敗 / 逾時 → throw { code: 'ALIYUN_UNREACHABLE' }。
 */
function relayToAliyun(method, endpoint, body) {
    const url = `${ALIYUN_SERVER}${endpoint}`;
    const opts = { method, headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY } };
    if (body && typeof body === 'object') opts.body = JSON.stringify(body);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    opts.signal = controller.signal;
    return fetch(url, opts).then(async (r) => {
        clearTimeout(timer);
        let json = null;
        try { json = await r.json(); } catch (e) { json = { success: false, error: `HTTP ${r.status}` }; }
        return { status: r.status, body: json };
    }).catch((e) => {
        clearTimeout(timer);
        const err = new Error('無法連線阿里雲：' + (e.message || ''));
        err.code = 'ALIYUN_UNREACHABLE';
        throw err;
    });
}

function aliyunUnreachable(message) {
    return { success: false, error: 'ALIYUN_UNREACHABLE', message: message || '無法連線阿里雲，操作未完成。請檢查網絡後重試。' };
}

// ==================== 本地 mirror helpers（best-effort，絕唔影響回覆） ====================

function mirrorBookingUpsert(aliyunResponse, reqBody) {
    try {
        const d = (aliyunResponse && aliyunResponse.data) || {};
        const id = d.id || (reqBody && reqBody.id);
        if (!id) return;
        const store_id = d.store_id || reqBody.store_id;
        const booking_date = d.booking_date || reqBody.booking_date;
        const booking_time = d.booking_time || reqBody.booking_time;
        const adults = d.adults != null ? d.adults : (reqBody.adults != null ? reqBody.adults : 2);
        const children = d.children != null ? d.children : (reqBody.children != null ? reqBody.children : 0);
        const phone = d.phone != null ? d.phone : (reqBody.phone != null ? reqBody.phone : '');
        const notes = d.notes != null ? d.notes : (reqBody.notes || '');
        const lang = d.lang != null ? d.lang : (reqBody.lang || 'zh-TW');
        const status = d.status || 'confirmed';
        db.run(
            `INSERT OR REPLACE INTO bookings (id, store_id, booking_date, booking_time, adults, children, phone, notes, lang, status, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now', '+8 hours'), datetime('now', '+8 hours'))`,
            [id, store_id, booking_date, booking_time, adults, children, phone, notes, lang, status],
            function (err) { if (err) console.error('mirror booking upsert failed:', err.message); }
        );
    } catch (e) { console.error('mirror booking upsert error:', e.message); }
}

function mirrorBookingList(rows) {
    try {
        if (!Array.isArray(rows)) return;
        rows.forEach(function (r) {
            if (!r || !r.id) return;
            const created_at = r.created_at || `datetime('now', '+8 hours')`;
            db.run(
                `INSERT OR REPLACE INTO bookings (id, store_id, booking_date, booking_time, adults, children, phone, notes, lang, status, table_number, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now', '+8 hours'))`,
                [r.id, r.store_id, r.booking_date, r.booking_time, r.adults, r.children, r.phone, r.notes, r.lang, r.status, r.table_number, created_at],
                function (err) { if (err) console.error('mirror booking list failed:', err.message); }
            );
        });
    } catch (e) { console.error('mirror booking list error:', e.message); }
}

function mirrorBookingUpdate(id, fields) {
    try {
        const sets = [];
        const params = [];
        const valid = { store_id: 1, booking_date: 1, booking_time: 1, adults: 1, children: 1, notes: 1, status: 1, table_number: 1, lang: 1 };
        Object.keys(fields || {}).forEach(function (k) {
            if (valid[k]) { sets.push(`${k} = ?`); params.push(fields[k]); }
        });
        if (!sets.length) return;
        sets.push(`updated_at = datetime('now', '+8 hours')`);
        params.push(id);
        db.run(`UPDATE bookings SET ${sets.join(', ')} WHERE id = ?`, params, function (err) {
            if (err) console.error('mirror booking update failed:', err.message);
        });
    } catch (e) { console.error('mirror booking update error:', e.message); }
}

function mirrorPausedSlots(storeId, date, slots) {
    try {
        const arr = Array.isArray(slots) ? slots : ((slots && slots.data && slots.data.slots) || []);
        arr.forEach(function (t) {
            db.run(
                `INSERT OR IGNORE INTO paused_slots (id, store_id, booking_date, booking_time) VALUES (?, ?, ?, ?)`,
                [uuidv4(), storeId, date, t],
                function (err) { if (err) console.error('mirror paused upsert failed:', err.message); }
            );
        });
    } catch (e) { console.error('mirror paused error:', e.message); }
}

function mirrorPausedList(storeId, date, fromDate, rows) {
    try {
        if (!Array.isArray(rows)) return;
        let query, params;
        if (fromDate) {
            query = `DELETE FROM paused_slots WHERE store_id = ? AND booking_date >= ?`;
            params = [storeId, fromDate];
        } else {
            query = `DELETE FROM paused_slots WHERE store_id = ? AND booking_date = ?`;
            params = [storeId, date];
        }
        db.run(query, params, function (err) {
            if (err) return console.error('mirror paused clear failed:', err.message);
            rows.forEach(function (r) {
                if (!r || !r.booking_date || !r.booking_time) return;
                db.run(
                    `INSERT OR IGNORE INTO paused_slots (id, store_id, booking_date, booking_time) VALUES (?, ?, ?, ?)`,
                    [r.id || uuidv4(), r.store_id || storeId, r.booking_date, r.booking_time],
                    function (e2) { if (e2) console.error('mirror paused list insert failed:', e2.message); }
                );
            });
        });
    } catch (e) { console.error('mirror paused list error:', e.message); }
}

// ==================== 本地讀取 fallback（阿里雲 down 時用） ====================

function readLocalBookings(res, query) {
    const { store_id, date, status, phone } = query;
    const params = [];
    let q = `SELECT * FROM bookings WHERE 1=1`;
    if (store_id) { q += ` AND store_id = ?`; params.push(store_id); }
    let effectiveDate = date;
    if (!effectiveDate) {
        const today = new Date();
        effectiveDate = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    }
    q += ` AND booking_date = ?`;
    params.push(effectiveDate);
    if (status) { q += ` AND status = ?`; params.push(status); }
    if (phone) { q += ` AND phone LIKE ?`; params.push(`%${phone}%`); }
    q += ` ORDER BY booking_date ASC, booking_time ASC`;
    db.all(q, params, (err, rows) => {
        if (err) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });
        res.json({ success: true, data: rows || [], source: 'offline-cache', warning: '阿里雲無法連線，顯示離線資料' });
    });
}

function readLocalPaused(res, storeId, date, fromDate) {
    let query, params;
    if (fromDate) {
        query = `SELECT * FROM paused_slots WHERE store_id = ? AND booking_date >= ? ORDER BY booking_date ASC, booking_time ASC`;
        params = [storeId, fromDate];
    } else {
        query = `SELECT * FROM paused_slots WHERE store_id = ? AND booking_date = ? ORDER BY booking_time ASC`;
        params = [storeId, date];
    }
    db.all(query, params, (err, rows) => {
        if (err) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });
        res.json({ success: true, data: rows || [], source: 'offline-cache', warning: '阿里雲無法連線，顯示離線資料' });
    });
}

// Helper: 攞分店對應日期嘅 daytype group ('weekday' / 'holiday')
function getDaytypeGroup(date, callback) {
  db.get(`SELECT COALESCE(daytype, '') as daytype, COALESCE(description, '') as description FROM holidays WHERE date = ? AND store_id = 'default_store'`, [date], (err, row) => {
    var isHoliday = false;
    if (!err && row) {
      // daytype 可能喺 daytype 欄位或者 description 欄位（"daytype=B" 格式）
      var raw = row.daytype || row.description || '';
      // "daytype=B" → extract "B"
      var m = raw.match(/[NHSUB]|daytype=([NHSUB])/);
      var dt = m ? (m[1] || m[0]) : '';
      if (dt === 'H' || dt === 'S' || dt === 'U' || dt === 'B') isHoliday = true;
      else if (dt === 'N' || dt === 'F') isHoliday = false;
    } else {
      var d = new Date(date + 'T00:00+08:00');
      var w = d.getDay();
      isHoliday = (w === 0 || w === 6);
    }
    callback(isHoliday ? 'holiday' : 'weekday');
  });
}

// Helper: 攞分店對應日期所有 slot capacity map
function getSlotCapacityMap(storeId, date, callback) {
  getDaytypeGroup(date, function(group) {
    db.all(`SELECT booking_time, capacity FROM store_slot_capacity WHERE store_id = ? AND daytype_group = ?`,
      [storeId, group], function(err, slotRows) {
        var defaultCap = 20;
        db.get(`SELECT capacity FROM store_capacity WHERE store_id = ? AND daytype_group = ?`,
          [storeId, group], function(err2, row2) {
            if (!err2 && row2) defaultCap = row2.capacity;
            var map = {};
            (slotRows || []).forEach(function(r) { map[r.booking_time] = r.capacity; });
            callback(map, defaultCap, group);
          });
      });
  });
}

/**
 * @route POST /api/booking
 * @desc 新增預約（公開，客戶使用）
 * @access Public
 */
router.post('/', async (req, res) => {
    try {
        const { store_id, booking_date, booking_time, adults, children, phone, notes, lang } = req.body;
        if (!store_id || !booking_date || !booking_time) {
            return res.status(400).json({ success: false, error: '缺少必要欄位', message: '請填寫分店、日期和時間' });
        }
        if (!/^\d{4}-\d{2}-\d{2}$/.test(booking_date)) {
            return res.status(400).json({ success: false, error: '日期格式錯誤', message: '日期格式需為 YYYY-MM-DD' });
        }
        if (!/^\d{2}:\d{2}$/.test(booking_time)) {
            return res.status(400).json({ success: false, error: '時間格式錯誤', message: '時間格式需為 HH:MM' });
        }
        // 本地生成 id，當 explicitId forward 去阿里雲（冪等：重試唔會重複）
        const id = uuidv4();
        let result;
        try {
            result = await relayToAliyun('POST', '/api/booking', {
                id, store_id, booking_date, booking_time,
                adults, children, phone, notes, lang,
                _skipWhatsApp: req.body._skipWhatsApp
            });
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            return res.status(503).json(aliyunUnreachable('無法連線阿里雲，預約未建立。請檢查網絡後重試。'));
        }
        // 阿里雲確認成功先 mirror 落本地（best-effort）
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            mirrorBookingUpsert(result.body, req.body);
        }
        // 原封轉發阿里雲回覆（包括 409 已滿/已暫停、400 驗證錯誤）
        return res.status(result.status).json(result.body);
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

router.get('/list', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const { store_id, date, status, phone } = req.query;
        const qs = new URLSearchParams();
        if (store_id) qs.set('store_id', store_id);
        if (date) qs.set('date', date);
        if (status) qs.set('status', status);
        if (phone) qs.set('phone', phone);
        let result;
        try {
            result = await relayToAliyun('GET', `/api/booking/list?${qs.toString()}`);
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            // 阿里雲 down → 讀本地 mirror
            return readLocalBookings(res, req.query);
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            // 更新本地 mirror（best-effort）
            mirrorBookingList(result.body.data);
            return res.json(result.body);
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        console.error('查詢預約列表錯誤:', error);
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route PATCH /api/booking/:id/cancel
 * @desc 取消預約（公開，需 phone 驗證）
 * @access Public
 */
router.patch('/:id/cancel', async (req, res) => {
    try {
        const { phone } = req.body;
        const { id } = req.params;
        if (!phone) {
            return res.status(400).json({
                success: false,
                error: '缺少電話號碼',
                message: '請提供預約時使用的電話號碼以驗證身份'
            });
        }
        let result;
        try {
            result = await relayToAliyun('PATCH', `/api/booking/${id}/cancel`, { phone });
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            return res.status(503).json(aliyunUnreachable('無法連線阿里雲，取消未完成。請檢查網絡後重試。'));
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            mirrorBookingUpdate(id, { status: 'cancelled' });
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        console.error('取消預約錯誤:', error);
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route PATCH /api/booking/:id/edit
 * @desc 編輯預約（公開，需 phone 驗證）
 * @access Public
 */
router.patch('/:id/edit', async (req, res) => {
    try {
        const { phone, store_id, booking_date, booking_time, adults, children, notes } = req.body;
        const { id } = req.params;
        if (!phone || !store_id || !booking_date || !booking_time) {
            return res.status(400).json({ success: false, error: '缺少必要欄位' });
        }
        let result;
        try {
            result = await relayToAliyun('PATCH', `/api/booking/${id}/edit`, { phone, store_id, booking_date, booking_time, adults, children, notes });
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            return res.status(503).json(aliyunUnreachable('無法連線阿里雲，編輯未完成。請檢查網絡後重試。'));
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            mirrorBookingUpdate(id, { store_id, booking_date, booking_time, adults, children, notes });
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route PATCH /api/booking/:id/status
 * @desc 更新預約狀態（員工權限）
 * @access Private/Staff
 */
router.patch('/:id/status', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const { status, table_number } = req.body;
        const { id } = req.params;
        const validStatuses = ['confirmed', 'cancelled', 'arrived'];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({
                success: false,
                error: '狀態值無效',
                message: `狀態需為: ${validStatuses.join(', ')}`
            });
        }
        let result;
        try {
            result = await relayToAliyun('PATCH', `/api/booking/${id}/status`, { status, table_number });
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            return res.status(503).json(aliyunUnreachable('無法連線阿里雲，操作未完成。請檢查網絡後重試。'));
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            mirrorBookingUpdate(id, { status, table_number });
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        console.error('更新預約狀態錯誤:', error);
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route GET /api/booking/paused
 * @desc 拎已暫停嘅 time slot list（員工權限）— 由阿里雲讀取，本地 fallback
 * @access Private/Staff
 */
router.get('/paused', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const { store_id, date, from_date } = req.query;
        if (!store_id || (!date && !from_date)) {
            return res.status(400).json({ success: false, error: '缺少必要參數', message: '請提供 store_id 和 date/from_date' });
        }
        const qs = `store_id=${encodeURIComponent(store_id)}` + (from_date ? `&from_date=${encodeURIComponent(from_date)}` : `&date=${encodeURIComponent(date)}`);
        let result;
        try {
            result = await relayToAliyun('GET', `/api/booking/paused?${qs}`);
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            return readLocalPaused(res, store_id, date, from_date);
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            mirrorPausedList(store_id, date, from_date, result.body.data);
            return res.json(result.body);
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        console.error('查詢暫停時段錯誤:', error);
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route DELETE /api/booking/pause/:id
 * @desc 刪除單一暫停時段（員工權限）
 * @access Private/Staff
 */
router.delete('/pause/:id', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const { id } = req.params;
        let result;
        try {
            result = await relayToAliyun('DELETE', `/api/booking/pause/${id}`);
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            return res.status(503).json(aliyunUnreachable('無法連線阿里雲，刪除未完成。請檢查網絡後重試。'));
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            db.run(`DELETE FROM paused_slots WHERE id = ?`, [id], function (err) { if (err) console.error('mirror paused delete failed:', err.message); });
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route POST /api/booking/pause/delete-range
 * @desc 刪除一段時間範圍內嘅暫停時段（員工權限）
 * @access Private/Staff
 */
router.post('/pause/delete-range', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const { store_id, date, start_time, end_time } = req.body;
        if (!store_id || !date || !start_time || !end_time) {
            return res.status(400).json({ success: false, error: '缺少必要參數' });
        }
        let result;
        try {
            result = await relayToAliyun('POST', '/api/booking/pause/delete-range', { store_id, date, start_time, end_time });
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            return res.status(503).json(aliyunUnreachable('無法連線阿里雲，刪除未完成。請檢查網絡後重試。'));
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            db.run(`DELETE FROM paused_slots WHERE store_id = ? AND booking_date = ? AND booking_time >= ? AND booking_time <= ?`,
                [store_id, date, start_time, end_time],
                function (err) { if (err) console.error('mirror paused delete-range failed:', err.message); });
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

// ==================== 座位容量設定 ====================

/**
 * @route POST /api/booking/capacity/save
 * @desc 設定分店某 daytype group 嘅容量（員工權限）
 * @access Private/Staff
 */
router.post('/capacity/save', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const { store_id, daytype_group, capacity } = req.body;
        if (!store_id || !daytype_group || capacity === undefined) {
            return res.status(400).json({ success: false, error: '缺少必要參數', message: '請提供 store_id、daytype_group 和 capacity' });
        }
        if (!['weekday', 'holiday'].includes(daytype_group)) {
            return res.status(400).json({ success: false, error: 'daytype_group 無效', message: 'daytype_group 需為 weekday 或 holiday' });
        }
        var cap = parseInt(capacity);
        if (isNaN(cap) || cap < 1 || cap > 100) {
            return res.status(400).json({ success: false, error: '容量無效', message: '容量需為 1-100' });
        }
        let result;
        try {
            result = await relayToAliyun('POST', '/api/booking/capacity/save', { store_id, daytype_group, capacity: cap });
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            return res.status(503).json(aliyunUnreachable('無法連線阿里雲，容量設定未儲存。請檢查網絡後重試。'));
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            // mirror 本地（best-effort）
            db.run(
                `INSERT INTO store_capacity (id, store_id, daytype_group, capacity, updated_at)
                 VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                 ON CONFLICT(store_id, daytype_group) DO UPDATE SET capacity = ?, updated_at = CURRENT_TIMESTAMP`,
                [uuidv4(), store_id, daytype_group, cap, cap],
                function (err) { if (err) console.error('mirror capacity save failed:', err.message); }
            );
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route GET /api/booking/capacity/config/:store_id
 * @desc 拎某分店嘅容量設定（含 per-slot）（員工權限）— 由阿里雲讀取，本地 fallback
 * @access Private/Staff
 */
router.get('/capacity/config/:store_id', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        var storeId = req.params.store_id;
        let result;
        try {
            result = await relayToAliyun('GET', `/api/booking/capacity/config/${encodeURIComponent(storeId)}`);
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            // fallback 讀本地 config
            return readLocalCapacityConfig(res, storeId);
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            // mirror 落本地 capacity 表（best-effort）
            var d = result.body.data || {};
            var defaults = d.defaults || {};
            Object.keys(defaults).forEach(function (dtg) {
                db.run(
                    `INSERT INTO store_capacity (id, store_id, daytype_group, capacity, updated_at)
                     VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                     ON CONFLICT(store_id, daytype_group) DO UPDATE SET capacity = ?, updated_at = CURRENT_TIMESTAMP`,
                    [uuidv4(), storeId, dtg, defaults[dtg], defaults[dtg]],
                    function (err) { if (err) console.error('mirror capacity config default failed:', err.message); }
                );
            });
            var slots = d.slots || {};
            ['weekday', 'holiday'].forEach(function (dtg) {
                Object.keys(slots[dtg] || {}).forEach(function (time) {
                    db.run(
                        `INSERT INTO store_slot_capacity (id, store_id, daytype_group, booking_time, capacity, updated_at)
                         VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                         ON CONFLICT(store_id, daytype_group, booking_time) DO UPDATE SET capacity = ?, updated_at = CURRENT_TIMESTAMP`,
                        [uuidv4(), storeId, dtg, time, slots[dtg][time], slots[dtg][time]],
                        function (err) { if (err) console.error('mirror capacity config slot failed:', err.message); }
                    );
                });
            });
            return res.json(result.body);
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

function readLocalCapacityConfig(res, storeId) {
    db.all(`SELECT daytype_group, capacity FROM store_capacity WHERE store_id = ?`, [storeId], (err, rows) => {
        if (err) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });
        var config = { weekday: 20, holiday: 20 };
        (rows || []).forEach(function (r) { config[r.daytype_group] = r.capacity; });
        db.all(`SELECT daytype_group, booking_time, capacity FROM store_slot_capacity WHERE store_id = ? ORDER BY daytype_group, booking_time`, [storeId], (err2, slotRows) => {
            if (err2) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err2.message });
            var slotConfig = { weekday: {}, holiday: {} };
            (slotRows || []).forEach(function (r) { slotConfig[r.daytype_group][r.booking_time] = r.capacity; });
            // 「分鐘前不可預約」讀本地 mirror store_configs（default 1）
            db.get(`SELECT config_value FROM store_configs WHERE store_id = ? AND config_key = 'advance_booking_minutes'`, [storeId], (err3, cfgRow) => {
                var advanceMinutes = 1;
                if (!err3 && cfgRow && cfgRow.config_value !== null && cfgRow.config_value !== '') {
                    var v = parseInt(cfgRow.config_value);
                    if (!isNaN(v) && v >= 0) advanceMinutes = v;
                }
                res.json({ success: true, data: { defaults: config, slots: slotConfig, advance_minutes: advanceMinutes }, source: 'local-cache', warning: '阿里雲無法連線，顯示離線容量設定' });
            });
        });
    });
}

/**
 * @route POST /api/booking/capacity/save-slots
 * @desc 儲存 per-slot capacity（員工權限）
 * @access Private/Staff
 */
router.post('/capacity/save-slots', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const { store_id, daytype_group, slots } = req.body;
        if (!store_id || !daytype_group || !slots || typeof slots !== 'object') {
            return res.status(400).json({ success: false, error: '缺少必要參數' });
        }
        if (!['weekday', 'holiday'].includes(daytype_group)) {
            return res.status(400).json({ success: false, error: 'daytype_group 無效' });
        }
        let result;
        try {
            result = await relayToAliyun('POST', '/api/booking/capacity/save-slots', { store_id, daytype_group, slots });
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            return res.status(503).json(aliyunUnreachable('無法連線阿里雲，容量設定未儲存。請檢查網絡後重試。'));
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            // mirror 本地 per-slot（best-effort）
            Object.keys(slots).forEach(function (time) {
                var cap = parseInt(slots[time]);
                if (isNaN(cap) || cap < 0 || cap > 100) return;
                db.run(
                    `INSERT INTO store_slot_capacity (id, store_id, daytype_group, booking_time, capacity, updated_at)
                     VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                     ON CONFLICT(store_id, daytype_group, booking_time) DO UPDATE SET capacity = ?, updated_at = CURRENT_TIMESTAMP`,
                    [uuidv4(), store_id, daytype_group, time, cap, cap],
                    function (err) { if (err) console.error('mirror capacity save-slots failed:', err.message); }
                );
            });
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route POST /api/booking/capacity/apply-to-all
 * @desc 將某分店嘅容量設定套用至所有分店（管理員專用）
 * @access Private/Admin
 */
router.post('/capacity/apply-to-all', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const { store_id } = req.body;
        if (!store_id) {
            return res.status(400).json({ success: false, error: '缺少必要參數', message: '請提供來源分店 ID' });
        }
        if (!store_id.match(/^store_[1-4]$/)) {
            return res.status(400).json({ success: false, error: '無效嘅分店 ID' });
        }
        let result;
        try {
            result = await relayToAliyun('POST', '/api/booking/capacity/apply-to-all', { store_id });
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            return res.status(503).json(aliyunUnreachable('無法連線阿里雲，容量套用未完成。請檢查網絡後重試。'));
        }
        // 本地 mirror：唔逐間寫，下次讀 config 會由阿里雲 refresh
        return res.status(result.status).json(result.body);
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route GET /api/booking/capacity/public
 * @desc 公開端點：拎某分店某日嘅 capacity — 由阿里雲讀取，本地 fallback
 * @access Public
 */
router.get('/capacity/public', async (req, res) => {
    try {
        const { store_id, date } = req.query;
        if (!store_id || !date) {
            return res.status(400).json({ success: false, error: '缺少必要參數' });
        }
        let result;
        try {
            result = await relayToAliyun('GET', `/api/booking/capacity/public?store_id=${encodeURIComponent(store_id)}&date=${encodeURIComponent(date)}`);
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            getSlotCapacityMap(store_id, date, function (capMap, defaultCap) {
                res.json({ success: true, data: { store_id, date, default_capacity: defaultCap, slot_capacities: capMap }, source: 'local-cache', warning: '阿里雲無法連線，顯示離線容量設定' });
            });
            return;
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            return res.json(result.body);
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route GET /api/booking/:id
 * @desc 查詢單一預約詳情（公開，用於客戶查詢）— 由阿里雲讀取，本地 fallback
 * @access Public
 */
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        let result;
        try {
            result = await relayToAliyun('GET', `/api/booking/${encodeURIComponent(id)}`);
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            db.get(`SELECT * FROM bookings WHERE id = ?`, [id], (err, booking) => {
                if (err) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });
                if (!booking) return res.status(404).json({ success: false, error: '找不到該預約' });
                res.json({ success: true, data: booking, source: 'offline-cache', warning: '阿里雲無法連線，顯示離線資料' });
            });
            return;
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            return res.json(result.body);
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route PUT /api/booking/:id
 * @desc 更新預約內容（員工權限）
 * @access Private/Staff
 */
router.put('/:id', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const { id } = req.params;
        const { booking_date, booking_time, adults, children, notes } = req.body;
        let result;
        try {
            result = await relayToAliyun('PUT', `/api/booking/${id}`, { booking_date, booking_time, adults, children, notes });
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            return res.status(503).json(aliyunUnreachable('無法連線阿里雲，更新未完成。請檢查網絡後重試。'));
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            mirrorBookingUpdate(id, { booking_date, booking_time, adults, children, notes });
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route POST /api/booking/pause
 * @desc 暫停某店某日未來 N 分鐘嘅 time slot（員工權限）— 由阿里雲執行（計算 slots + 寫入）
 * @access Private/Staff
 */
router.post('/pause', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const { store_id, date, duration_minutes, time_slots, is_full_day } = req.body;
        if (!store_id || !date) {
            return res.status(400).json({ success: false, error: '缺少必要參數', message: '請提供 store_id 和 date' });
        }
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
            return res.status(400).json({ success: false, error: '日期格式錯誤', message: '日期格式需為 YYYY-MM-DD' });
        }
        if (!time_slots && !is_full_day && !duration_minutes) {
            return res.status(400).json({ success: false, error: '缺少參數', message: '請提供 time_slots、is_full_day 或 duration_minutes' });
        }
        // 原封 forward，阿里雲負責計算 affected slots + 寫入 + 回覆
        let result;
        try {
            result = await relayToAliyun('POST', '/api/booking/pause', { store_id, date, duration_minutes, time_slots, is_full_day });
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            return res.status(503).json(aliyunUnreachable('無法連線阿里雲，暫停未完成。請檢查網絡後重試。'));
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            var inserted = (result.body.data && result.body.data.slots) || [];
            mirrorPausedSlots(store_id, date, inserted);
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        console.error('暫停時段錯誤:', error);
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route POST /api/booking/resume
 * @desc 恢復某店某日所有暫停 slot（員工權限）— 由阿里雲執行
 * @access Private/Staff
 */
router.post('/resume', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const { store_id, date } = req.body;
        if (!store_id || !date) {
            return res.status(400).json({ success: false, error: '缺少必要參數', message: '請提供 store_id 和 date' });
        }
        let result;
        try {
            result = await relayToAliyun('POST', '/api/booking/resume', { store_id, date });
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            return res.status(503).json(aliyunUnreachable('無法連線阿里雲，恢復未完成。請檢查網絡後重試。'));
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            db.run(`DELETE FROM paused_slots WHERE store_id = ? AND booking_date = ?`,
                [store_id, date],
                function (err) { if (err) console.error('mirror paused resume failed:', err.message); });
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        console.error('恢復時段錯誤:', error);
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

module.exports = router;
