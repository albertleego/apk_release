const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const storeAwareMiddleware = require('../middleware/store-aware');

// 為所有路由添加分店上下文中間件
router.use(storeAwareMiddleware.initStoreContext);

// 儲物柜系統配置
const LOCKER_CONFIG = {
  DEFAULT_LOCKER_COUNT: 70,
  AUTO_CLOSE_TIMEOUT: 30000, // 30秒
  TEST_OPEN_DURATION: 10000, // 10秒
  MAX_LOCKERS_PER_BANK: 40,
  MIN_TEMPERATURE: 2, // 冷藏櫃最低溫度 (°C)
  MAX_TEMPERATURE: 8, // 冷藏櫃最高溫度 (°C)
  BATTERY_WARNING_LEVEL: 20, // 電池警告水平 (%)
  BATTERY_CRITICAL_LEVEL: 10, // 電池危險水平 (%)
  MAINTENANCE_CHECK_INTERVAL: 3600000, // 1小時
  HEARTBEAT_INTERVAL: 30000, // 30秒
};

// 儲物柜狀態
const lockerStatus = {
  device_id: 'locker-system-001',
  status: 'online',
  last_seen: new Date().toISOString(),
  ip_address: null,
  firmware_version: '1.2.0',
  hardware_model: 'Locker-Pro-2024',
  lockers: Array.from({ length: LOCKER_CONFIG.DEFAULT_LOCKER_COUNT }, (_, i) => ({
    locker_number: i + 1,
    is_occupied: false,
    is_open: false,
    customer_id: null,
    table_number: null,
    opened_at: null,
    product_id: null,
    temperature: 22.5, // 室溫 (°C)
    battery_level: 100, // 電池水平 (%)
    last_maintenance: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), // 7天前
    error_state: null, // 'motor_fault', 'sensor_error', 'communication_error', 'low_battery'
    is_refrigerated: i < 5, // 前5個是冷藏櫃
    bank_id: 'bank-001',
    location: `區域-A-${String(i + 1).padStart(2, '0')}`,
    max_weight: 5.0, // 最大承重 (kg)
    current_weight: 0.0,
    door_open_count: 0,
    total_usage_time: 0, // 總使用時間 (秒)
  }))
};

// 儲物柜事件日誌
const lockerEvents = [];

// 儲物柜錯誤狀態模擬
const ERROR_SIMULATION = {
  enabled: false,
  fault_locker_numbers: [],
  communication_errors: false,
  temperature_alarm: false,
  battery_drain_rate: 1.0, // 正常耗電速度
};

// 輔助函數
function logLockerEvent(eventType, lockerNumber, details) {
  const event = {
    id: uuidv4(),
    timestamp: new Date().toISOString(),
    event_type: eventType,
    locker_number: lockerNumber,
    device_id: lockerStatus.device_id,
    details: details,
  };
  lockerEvents.push(event);

  // 保持日誌大小（最近1000條事件）
  if (lockerEvents.length > 1000) {
    lockerEvents.shift();
  }

  // 觸發Socket事件
  const io = require('../index').io;
  if (io) {
    io.emit('locker-event', event);
  }

  return event;
}

function simulateHardwareErrors() {
  if (!ERROR_SIMULATION.enabled) return;

  lockerStatus.lockers.forEach(locker => {
    // 模擬故障儲物柜
    if (ERROR_SIMULATION.fault_locker_numbers.includes(locker.locker_number)) {
      locker.error_state = 'motor_fault';
    }

    // 模擬通訊錯誤
    if (ERROR_SIMULATION.communication_errors && Math.random() < 0.1) {
      locker.error_state = 'communication_error';
    }

    // 模擬溫度警報（冷藏櫃）
    if (ERROR_SIMULATION.temperature_alarm && locker.is_refrigerated) {
      if (locker.temperature < LOCKER_CONFIG.MIN_TEMPERATURE) {
        locker.error_state = 'temperature_low';
      } else if (locker.temperature > LOCKER_CONFIG.MAX_TEMPERATURE) {
        locker.error_state = 'temperature_high';
      }
    }

    // 模擬電池耗電
    if (locker.battery_level > 0) {
      locker.battery_level -= ERROR_SIMULATION.battery_drain_rate * Math.random();
      if (locker.battery_level < 0) locker.battery_level = 0;
    }
  });
}

function checkLockerHealth(locker) {
  const issues = [];

  if (locker.error_state) {
    issues.push({
      type: 'error',
      code: locker.error_state,
      message: getErrorMessage(locker.error_state),
      severity: 'critical'
    });
  }

  if (locker.is_refrigerated) {
    if (locker.temperature < LOCKER_CONFIG.MIN_TEMPERATURE) {
      issues.push({
        type: 'temperature',
        code: 'temp_low',
        message: `溫度過低: ${locker.temperature}°C`,
        severity: 'warning'
      });
    } else if (locker.temperature > LOCKER_CONFIG.MAX_TEMPERATURE) {
      issues.push({
        type: 'temperature',
        code: 'temp_high',
        message: `溫度過高: ${locker.temperature}°C`,
        severity: 'critical'
      });
    }
  }

  if (locker.battery_level <= LOCKER_CONFIG.BATTERY_CRITICAL_LEVEL) {
    issues.push({
      type: 'battery',
      code: 'battery_critical',
      message: `電池電量極低: ${locker.battery_level.toFixed(1)}%`,
      severity: 'critical'
    });
  } else if (locker.battery_level <= LOCKER_CONFIG.BATTERY_WARNING_LEVEL) {
    issues.push({
      type: 'battery',
      code: 'battery_warning',
      message: `電池電量低: ${locker.battery_level.toFixed(1)}%`,
      severity: 'warning'
    });
  }

  // 檢查維護需求
  const lastMaintenance = new Date(locker.last_maintenance);
  const daysSinceMaintenance = (Date.now() - lastMaintenance.getTime()) / (1000 * 60 * 60 * 24);
  if (daysSinceMaintenance > 30) {
    issues.push({
      type: 'maintenance',
      code: 'maintenance_overdue',
      message: `需要維護: ${Math.floor(daysSinceMaintenance)} 天未維護`,
      severity: 'warning'
    });
  }

  return issues;
}

function getErrorMessage(errorCode) {
  const errorMessages = {
    'motor_fault': '馬達故障',
    'sensor_error': '傳感器錯誤',
    'communication_error': '通訊錯誤',
    'temperature_low': '溫度過低',
    'temperature_high': '溫度過高',
    'low_battery': '電池電量低',
    'overweight': '超重',
    'door_blocked': '門被阻擋',
  };
  return errorMessages[errorCode] || '未知錯誤';
}

function syncLockerToDatabase(locker, storeId = 'default_store') {
  const db = require('../../database/db').db;
  console.log(`[DEBUG] syncLockerToDatabase 開始: locker_number=${locker.locker_number}, is_occupied=${locker.is_occupied}, customer_id=${locker.customer_id}, store_id=${storeId}`);

  // 先查詢是否已存在該儲物柜編號的記錄（考慮分店）
  db.get(
    `SELECT id FROM lockers WHERE locker_number = ? AND store_id = ?`,
    [locker.locker_number, storeId],
    (err, existing) => {
      if (err) {
        console.error(`查詢儲物柜 ${locker.locker_number} 錯誤:`, err);
        return;
      }

      if (existing) {
        console.log(`[DEBUG] 儲物柜 ${locker.locker_number} 已存在，執行更新`);
        // 更新現有記錄（包含store_id）
        db.run(
          `UPDATE lockers SET is_occupied = ?, customer_id = ?, opened_at = ?, closed_at = ?, store_id = ? WHERE locker_number = ? AND store_id = ?`,
          [
            locker.is_occupied ? 1 : 0,
            locker.customer_id,
            locker.is_open ? locker.opened_at : null,
            !locker.is_open ? new Date().toISOString() : null,
            storeId,
            locker.locker_number,
            storeId
          ],
          (updateErr) => {
            if (updateErr) {
              console.error(`更新儲物柜 ${locker.locker_number} 錯誤:`, updateErr);
            } else {
              console.log(`[DEBUG] 儲物柜 ${locker.locker_number} 更新成功，customer_id=${locker.customer_id}, is_occupied=${locker.is_occupied ? 1 : 0}`);
            }
          }
        );
      } else {
        console.log(`[DEBUG] 儲物柜 ${locker.locker_number} 不存在，執行插入`);
        // 插入新記錄（包含store_id）
        db.run(
          `INSERT INTO lockers (id, locker_number, is_occupied, customer_id, opened_at, closed_at, store_id)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [
            uuidv4(),
            locker.locker_number,
            locker.is_occupied ? 1 : 0,
            locker.customer_id,
            locker.is_open ? locker.opened_at : null,
            !locker.is_open ? new Date().toISOString() : null,
            storeId
          ],
          (insertErr) => {
            if (insertErr) {
              console.error(`插入儲物柜 ${locker.locker_number} 錯誤:`, insertErr);
            } else {
              console.log(`[DEBUG] 儲物柜 ${locker.locker_number} 插入成功，customer_id=${locker.customer_id}, is_occupied=${locker.is_occupied ? 1 : 0}`);
            }
          }
        );
      }
    }
  );
}

// 從數據庫同步佔用狀態到內存
function syncOccupancyFromDatabase(storeId = 'default_store') {
  const db = require('../../database/db').db;
  return new Promise((resolve, reject) => {
    db.all(
      `SELECT l.locker_number, l.is_occupied, l.customer_id, c.table_number
       FROM lockers l
       LEFT JOIN customers c ON l.customer_id = c.id
       WHERE l.store_id = ?
       ORDER BY l.locker_number`,
      [storeId],
      (err, rows) => {
        if (err) {
          console.error('從數據庫同步佔用狀態錯誤:', err);
          reject(err);
          return;
        }

        // 更新 lockerStatus 中的佔用狀態
        console.log(`[DEBUG] syncOccupancyFromDatabase 從數據庫讀取 ${rows.length} 個儲物柜記錄`);
        rows.forEach(dbLocker => {
          console.log(`[DEBUG] 儲物柜 ${dbLocker.locker_number}: is_occupied=${dbLocker.is_occupied}, customer_id=${dbLocker.customer_id}, table_number=${dbLocker.table_number}`);
          const locker = lockerStatus.lockers.find(l => l.locker_number === dbLocker.locker_number);
          if (locker) {
            locker.is_occupied = dbLocker.is_occupied === 1;
            locker.customer_id = dbLocker.customer_id || null;
            locker.table_number = dbLocker.table_number || null;
            // 注意：我們不更新 opened_at，因為數據庫中的 opened_at 可能與模擬狀態不同步
            // 如果需要，可以考慮從數據庫同步 opened_at
          } else {
            // 數據庫中有儲物柜，但內存中不存在，可以選擇添加（但這不應該發生）
            console.warn(`數據庫中有儲物柜 ${dbLocker.locker_number}，但內存中不存在`);
          }
        });

        resolve();
      }
    );
  });
}

// 儲物柜設備註冊/心跳
router.post('/heartbeat', (req, res) => {
  try {
    const { device_id, status, ip_address, locker_states, firmware_version, hardware_model } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';

    // 更新設備信息
    lockerStatus.device_id = device_id || lockerStatus.device_id;
    lockerStatus.status = status || 'online';
    lockerStatus.last_seen = new Date().toISOString();
    lockerStatus.ip_address = ip_address || lockerStatus.ip_address;
    lockerStatus.firmware_version = firmware_version || lockerStatus.firmware_version;
    lockerStatus.hardware_model = hardware_model || lockerStatus.hardware_model;

    // 模擬硬件錯誤
    simulateHardwareErrors();

    // 更新儲物柜狀態（如果設備提供了狀態）
    if (locker_states && Array.isArray(locker_states)) {
      locker_states.forEach(state => {
        const locker = lockerStatus.lockers.find(l => l.locker_number === state.locker_number);
        if (locker) {
          locker.is_occupied = state.is_occupied !== undefined ? state.is_occupied : locker.is_occupied;
          locker.is_open = state.is_open !== undefined ? state.is_open : locker.is_open;
          locker.temperature = state.temperature !== undefined ? state.temperature : locker.temperature;
          locker.battery_level = state.battery_level !== undefined ? state.battery_level : locker.battery_level;
          locker.current_weight = state.current_weight !== undefined ? state.current_weight : locker.current_weight;

          // 記錄狀態變化
          if (state.is_open !== undefined && state.is_open !== locker.is_open) {
            logLockerEvent(state.is_open ? 'locker_opened' : 'locker_closed',
                          locker.locker_number,
                          { source: 'heartbeat', customer_id: locker.customer_id });
          }
        }
      });
    }

    // 計算系統健康狀態
    const healthIssues = [];
    const lockerHealth = lockerStatus.lockers.map(locker => {
      const issues = checkLockerHealth(locker);
      if (issues.length > 0) {
        healthIssues.push(...issues.map(issue => ({
          locker_number: locker.locker_number,
          ...issue
        })));
      }
      return {
        locker_number: locker.locker_number,
        issues: issues
      };
    });

    // 同步到數據庫
    lockerStatus.lockers.forEach(locker => {
      syncLockerToDatabase(locker, storeId);
    });

    // 更新數據庫中的設備狀態
    const db = require('../../database/db').db;
    db.run(
      `INSERT OR REPLACE INTO devices (id, device_type, device_id, status, last_seen, ip_address, metadata, store_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        uuidv4(),
        'locker-system',
        lockerStatus.device_id,
        lockerStatus.status,
        lockerStatus.last_seen,
        lockerStatus.ip_address,
        JSON.stringify({
          firmware_version: lockerStatus.firmware_version,
          hardware_model: lockerStatus.hardware_model,
          locker_count: lockerStatus.lockers.length,
          refrigerated_count: lockerStatus.lockers.filter(l => l.is_refrigerated).length
        }),
        storeId
      ],
      (err) => {
        if (err) console.error('更新設備狀態錯誤:', err);
      }
    );

    // 記錄心跳事件
    logLockerEvent('heartbeat', null, {
      device_id: lockerStatus.device_id,
      status: lockerStatus.status,
      locker_states_received: locker_states ? locker_states.length : 0
    });

    res.json({
      success: true,
      message: '儲物柜心跳接收成功',
      status: {
        device_id: lockerStatus.device_id,
        status: lockerStatus.status,
        last_seen: lockerStatus.last_seen,
        firmware_version: lockerStatus.firmware_version,
        hardware_model: lockerStatus.hardware_model,
        ip_address: lockerStatus.ip_address,
        locker_count: lockerStatus.lockers.length,
        occupied_count: lockerStatus.lockers.filter(l => l.is_occupied).length,
        open_count: lockerStatus.lockers.filter(l => l.is_open).length,
        refrigerated_count: lockerStatus.lockers.filter(l => l.is_refrigerated).length,
        error_count: lockerStatus.lockers.filter(l => l.error_state).length,
        battery_status: {
          average: (lockerStatus.lockers.reduce((sum, l) => sum + l.battery_level, 0) / lockerStatus.lockers.length).toFixed(1),
          low_count: lockerStatus.lockers.filter(l => l.battery_level <= LOCKER_CONFIG.BATTERY_WARNING_LEVEL).length,
          critical_count: lockerStatus.lockers.filter(l => l.battery_level <= LOCKER_CONFIG.BATTERY_CRITICAL_LEVEL).length
        },
        temperature_range: {
          min: Math.min(...lockerStatus.lockers.map(l => l.temperature)).toFixed(1),
          max: Math.max(...lockerStatus.lockers.map(l => l.temperature)).toFixed(1)
        },
        health_issues: healthIssues.length > 0 ? healthIssues : undefined
      }
    });
  } catch (error) {
    console.error('儲物柜心跳錯誤:', error);
    res.status(500).json({
      error: '儲物柜心跳處理失敗',
      message: error.message
    });
  }
});

// 開啟儲物柜
router.post('/open', (req, res) => {
  try {
    const { locker_numbers, customer_id, product_id, force_open } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';

    if (!locker_numbers || !Array.isArray(locker_numbers) || locker_numbers.length === 0) {
      return res.status(400).json({ error: '請提供要開啟的儲物柜編號數組' });
    }

    const results = [];
    const failed = [];
    const warnings = [];

    locker_numbers.forEach(locker_number => {
      const locker = lockerStatus.lockers.find(l => l.locker_number === locker_number);

      if (!locker) {
        failed.push({
          locker_number,
          error: '儲物柜不存在',
          code: 'locker_not_found'
        });
        return;
      }

      // 檢查儲物柜狀態
      const healthIssues = checkLockerHealth(locker);
      const criticalIssues = healthIssues.filter(issue => issue.severity === 'critical');

      // 如果有嚴重錯誤且不是強制開啟
      if (criticalIssues.length > 0 && !force_open) {
        failed.push({
          locker_number,
          error: '儲物柜有嚴重故障',
          code: 'critical_fault',
          issues: criticalIssues
        });
        return;
      }

      // 檢查是否被其他客人佔用
      if (locker.is_occupied && locker.customer_id !== customer_id) {
        failed.push({
          locker_number,
          error: '儲物柜已被其他客人佔用',
          code: 'occupied_by_other',
          current_customer: locker.customer_id
        });
        return;
      }

      // 檢查重量限制（如果啟用）
      if (locker.current_weight > locker.max_weight * 0.9) { // 90% 最大承重
        warnings.push({
          locker_number,
          warning: '儲物柜接近重量限制',
          current_weight: locker.current_weight,
          max_weight: locker.max_weight
        });
      }

      // 檢查電池電量（如果低於臨界值）
      if (locker.battery_level <= LOCKER_CONFIG.BATTERY_CRITICAL_LEVEL) {
        warnings.push({
          locker_number,
          warning: '電池電量極低，開啟可能失敗',
          battery_level: locker.battery_level.toFixed(1)
        });
      }

      // 開啟儲物柜
      locker.is_open = true;
      locker.is_occupied = true;
      locker.opened_at = new Date().toISOString();
      locker.customer_id = customer_id || locker.customer_id;
      locker.product_id = product_id || locker.product_id;
      locker.door_open_count++;

      // 記錄開啟事件
      logLockerEvent('locker_opened', locker_number, {
        customer_id: customer_id,
        product_id: product_id,
        force_open: force_open || false,
        issues: healthIssues.length > 0 ? healthIssues : undefined
      });

      // 同步到數據庫
      syncLockerToDatabase(locker, storeId);

      results.push({
        locker_number,
        opened: true,
        opened_at: locker.opened_at,
        auto_close_in: LOCKER_CONFIG.AUTO_CLOSE_TIMEOUT / 1000,
        warnings: warnings.filter(w => w.locker_number === locker_number).length > 0
          ? warnings.filter(w => w.locker_number === locker_number)
          : undefined
      });

      // 設定自動關閉定時器
      setTimeout(() => {
        if (locker.is_open) {
          locker.is_open = false;
          logLockerEvent('locker_auto_closed', locker_number, {
            customer_id: locker.customer_id,
            open_duration: LOCKER_CONFIG.AUTO_CLOSE_TIMEOUT
          });
          console.log(`儲物柜 ${locker_number} 自動關閉`);
        }
      }, LOCKER_CONFIG.AUTO_CLOSE_TIMEOUT);
    });

    // 觸發Socket事件
    const io = req.app.get('io');
    io.emit('lockers-opened', {
      locker_numbers: results.map(r => r.locker_number),
      customer_id: customer_id,
      product_id: product_id,
      timestamp: new Date().toISOString(),
      results: results,
      failed: failed.length > 0 ? failed : undefined,
      warnings: warnings.length > 0 ? warnings : undefined
    });

    // 如果有警告，記錄警告事件
    if (warnings.length > 0) {
      logLockerEvent('locker_open_warnings', null, {
        warnings: warnings,
        customer_id: customer_id
      });
    }

    res.json({
      success: true,
      message: `成功開啟 ${results.length} 個儲物柜${failed.length > 0 ? `, ${failed.length} 個失敗` : ''}`,
      results: results,
      failed: failed.length > 0 ? failed : undefined,
      warnings: warnings.length > 0 ? warnings : undefined,
      summary: {
        total_requested: locker_numbers.length,
        successful: results.length,
        failed: failed.length,
        with_warnings: warnings.length
      }
    });
  } catch (error) {
    console.error('開啟儲物柜錯誤:', error);
    logLockerEvent('locker_open_error', null, {
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({
      error: '開啟儲物柜失敗',
      message: error.message,
      code: 'internal_error'
    });
  }
});

// 關閉儲物柜
router.post('/close', (req, res) => {
  try {
    const { locker_numbers, force_close } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';

    if (!locker_numbers || !Array.isArray(locker_numbers)) {
      return res.status(400).json({ error: '請提供要關閉的儲物柜編號數組' });
    }

    const results = [];
    const failed = [];
    const warnings = [];

    locker_numbers.forEach(locker_number => {
      const locker = lockerStatus.lockers.find(l => l.locker_number === locker_number);

      if (!locker) {
        failed.push({
          locker_number,
          error: '儲物柜不存在',
          code: 'locker_not_found'
        });
        return;
      }

      // 檢查儲物柜是否已經關閉
      if (!locker.is_open) {
        warnings.push({
          locker_number,
          warning: '儲物柜已經關閉',
          code: 'already_closed'
        });
        // 仍然視為成功
      }

      // 檢查是否有故障（如果有故障且不是強制關閉）
      const healthIssues = checkLockerHealth(locker);
      const criticalIssues = healthIssues.filter(issue => issue.severity === 'critical');

      if (criticalIssues.length > 0 && !force_close) {
        warnings.push({
          locker_number,
          warning: '儲物柜有嚴重故障，關閉操作可能無效',
          issues: criticalIssues,
          code: 'closing_with_fault'
        });
      }

      // 記錄關閉前的狀態
      const wasOpen = locker.is_open;
      const openDuration = wasOpen && locker.opened_at
        ? (Date.now() - new Date(locker.opened_at).getTime()) / 1000
        : 0;

      // 關閉儲物柜
      locker.is_open = false;

      if (wasOpen) {
        // 更新使用時間統計
        locker.total_usage_time += openDuration;

        // 記錄關閉事件
        logLockerEvent('locker_closed', locker_number, {
          customer_id: locker.customer_id,
          open_duration: openDuration,
          force_close: force_close || false,
          issues: healthIssues.length > 0 ? healthIssues : undefined
        });
      }

      // 同步到數據庫
      syncLockerToDatabase(locker, storeId);

      results.push({
        locker_number,
        closed: true,
        closed_at: new Date().toISOString(),
        was_open: wasOpen,
        open_duration: wasOpen ? openDuration : 0,
        warnings: warnings.filter(w => w.locker_number === locker_number).length > 0
          ? warnings.filter(w => w.locker_number === locker_number)
          : undefined
      });
    });

    // 觸發Socket事件
    const io = req.app.get('io');
    io.emit('lockers-closed', {
      locker_numbers: results.map(r => r.locker_number),
      timestamp: new Date().toISOString(),
      results: results,
      failed: failed.length > 0 ? failed : undefined,
      warnings: warnings.length > 0 ? warnings : undefined
    });

    // 如果有警告，記錄警告事件
    if (warnings.length > 0) {
      logLockerEvent('locker_close_warnings', null, {
        warnings: warnings,
        force_close: force_close || false
      });
    }

    res.json({
      success: true,
      message: `成功處理 ${results.length} 個儲物柜關閉請求`,
      results: results,
      failed: failed.length > 0 ? failed : undefined,
      warnings: warnings.length > 0 ? warnings : undefined,
      summary: {
        total_requested: locker_numbers.length,
        successfully_closed: results.filter(r => r.was_open).length,
        already_closed: results.filter(r => !r.was_open).length,
        failed: failed.length,
        with_warnings: warnings.length
      }
    });
  } catch (error) {
    console.error('關閉儲物柜錯誤:', error);
    logLockerEvent('locker_close_error', null, {
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({
      error: '關閉儲物柜失敗',
      message: error.message,
      code: 'internal_error'
    });
  }
});

// 釋放儲物柜（客人離場後）
router.post('/release', (req, res) => {
  try {
    const { customer_id, force_release } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';

    if (!customer_id) {
      return res.status(400).json({ error: '請提供客人ID' });
    }

    const releasedLockers = [];
    const warnings = [];

    lockerStatus.lockers.forEach(locker => {
      if (locker.customer_id === customer_id) {
        // 檢查儲物柜狀態
        const healthIssues = checkLockerHealth(locker);
        const criticalIssues = healthIssues.filter(issue => issue.severity === 'critical');

        if (criticalIssues.length > 0 && !force_release) {
          warnings.push({
            locker_number: locker.locker_number,
            warning: '儲物柜有嚴重故障，釋放可能不完全',
            issues: criticalIssues,
            code: 'release_with_fault'
          });
        }

        // 記錄釋放前的狀態
        const wasOpen = locker.is_open;
        const wasOccupied = locker.is_occupied;
        const openDuration = wasOpen && locker.opened_at
          ? (Date.now() - new Date(locker.opened_at).getTime()) / 1000
          : 0;

        // 釋放儲物柜
        locker.is_occupied = false;
        locker.is_open = false;
        locker.customer_id = null;
        locker.product_id = null;
        if (wasOpen) {
          locker.total_usage_time += openDuration;
        }

        releasedLockers.push({
          locker_number: locker.locker_number,
          was_open: wasOpen,
          was_occupied: wasOccupied,
          open_duration: openDuration,
          released_at: new Date().toISOString()
        });

        // 記錄釋放事件
        logLockerEvent('locker_released', locker.locker_number, {
          customer_id: customer_id,
          was_open: wasOpen,
          was_occupied: wasOccupied,
          open_duration: openDuration,
          force_release: force_release || false,
          issues: healthIssues.length > 0 ? healthIssues : undefined
        });

        // 同步到數據庫
        syncLockerToDatabase(locker, storeId);
      }
    });

    if (releasedLockers.length === 0) {
      return res.json({
        success: true,
        message: '該客人沒有佔用任何儲物柜',
        released_lockers: [],
        customer_id: customer_id,
        warnings: warnings.length > 0 ? warnings : undefined
      });
    }

    // 觸發Socket事件
    const io = req.app.get('io');
    io.emit('lockers-released', {
      customer_id: customer_id,
      released_lockers: releasedLockers.map(r => r.locker_number),
      timestamp: new Date().toISOString(),
      warnings: warnings.length > 0 ? warnings : undefined
    });

    // 如果有警告，記錄警告事件
    if (warnings.length > 0) {
      logLockerEvent('locker_release_warnings', null, {
        customer_id: customer_id,
        warnings: warnings,
        force_release: force_release || false
      });
    }

    res.json({
      success: true,
      message: `已釋放 ${releasedLockers.length} 個儲物柜`,
      released_lockers: releasedLockers.map(r => r.locker_number),
      details: releasedLockers,
      customer_id: customer_id,
      warnings: warnings.length > 0 ? warnings : undefined,
      summary: {
        total_released: releasedLockers.length,
        were_open: releasedLockers.filter(r => r.was_open).length,
        were_occupied: releasedLockers.filter(r => r.was_occupied).length,
        with_warnings: warnings.length
      }
    });
  } catch (error) {
    console.error('釋放儲物柜錯誤:', error);
    logLockerEvent('locker_release_error', null, {
      customer_id: req.body.customer_id,
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({
      error: '釋放儲物柜失敗',
      message: error.message,
      code: 'internal_error'
    });
  }
});

// 釋放單個儲物柜
router.post('/:locker_number/release', (req, res) => {
  try {
    const { locker_number } = req.params;
    const { force_release } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';

    const locker = lockerStatus.lockers.find(l => l.locker_number === parseInt(locker_number));

    if (!locker) {
      return res.status(404).json({ error: '儲物柜不存在' });
    }

    // 檢查儲物柜狀態
    const healthIssues = checkLockerHealth(locker);
    const criticalIssues = healthIssues.filter(issue => issue.severity === 'critical');

    if (criticalIssues.length > 0 && !force_release) {
      return res.status(400).json({
        error: '儲物柜有嚴重故障',
        code: 'critical_fault',
        issues: criticalIssues
      });
    }

    // 記錄釋放前的狀態
    const wasOpen = locker.is_open;
    const wasOccupied = locker.is_occupied;
    const openDuration = wasOpen && locker.opened_at
      ? (Date.now() - new Date(locker.opened_at).getTime()) / 1000
      : 0;

    // 釋放儲物柜
    locker.is_occupied = false;
    locker.is_open = false;
    locker.customer_id = null;
    locker.product_id = null;
    if (wasOpen) {
      locker.total_usage_time += openDuration;
    }

    // 記錄釋放事件
    logLockerEvent('locker_released', locker.locker_number, {
      customer_id: locker.customer_id,
      was_open: wasOpen,
      was_occupied: wasOccupied,
      open_duration: openDuration,
      force_release: force_release || false,
      issues: healthIssues.length > 0 ? healthIssues : undefined
    });

    // 同步到數據庫
    syncLockerToDatabase(locker, storeId);

    // 觸發Socket事件
    const io = req.app.get('io');
    io.emit('locker-released', {
      locker_number: locker.locker_number,
      was_open: wasOpen,
      was_occupied: wasOccupied,
      timestamp: new Date().toISOString()
    });

    res.json({
      success: true,
      message: `儲物柜 ${locker.locker_number} 已釋放`,
      locker: {
        locker_number: locker.locker_number,
        is_occupied: locker.is_occupied,
        is_open: locker.is_open,
        customer_id: locker.customer_id,
        released_at: new Date().toISOString()
      }
    });
  } catch (error) {
    console.error('釋放單個儲物柜錯誤:', error);
    logLockerEvent('locker_release_error', null, {
      locker_number: req.params.locker_number,
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({
      error: '釋放儲物柜失敗',
      message: error.message,
      code: 'internal_error'
    });
  }
});

// 重新編排儲物柜
router.post('/rearrange', (req, res) => {
  try {
    // 目前僅記錄事件，無實際重新編排邏輯
    logLockerEvent('lockers_rearranged', null, {
      operator_id: req.body.operator_id,
      timestamp: new Date().toISOString()
    });

    res.json({
      success: true,
      message: '儲物柜重新編排完成',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('重新編排儲物柜錯誤:', error);
    res.status(500).json({
      error: '重新編排儲物柜失敗',
      message: error.message
    });
  }
});

// 刪除儲物柜
router.delete('/:locker_number', (req, res) => {
  try {
    const { locker_number } = req.params;
    const storeId = req.storeContext?.store_id || 'default_store';
    const lockerIndex = lockerStatus.lockers.findIndex(l => l.locker_number === parseInt(locker_number));

    if (lockerIndex === -1) {
      return res.status(404).json({ error: '儲物柜不存在' });
    }

    const deletedLocker = lockerStatus.lockers[lockerIndex];
    // 檢查儲物柜是否被佔用
    if (deletedLocker.is_occupied) {
      return res.status(400).json({ error: '無法刪除已佔用的儲物柜' });
    }

    // 從陣列中移除
    lockerStatus.lockers.splice(lockerIndex, 1);

    // 記錄刪除事件
    logLockerEvent('locker_deleted', deletedLocker.locker_number, {
      locker_number: deletedLocker.locker_number,
      location: deletedLocker.location,
      is_refrigerated: deletedLocker.is_refrigerated
    });

    // 同步到數據庫（刪除記錄）
    const db = require('../../database/db').db;
    db.run(
      'DELETE FROM lockers WHERE locker_number = ? AND store_id = ?',
      [locker_number, storeId],
      (err) => {
        if (err) console.error(`刪除儲物柜 ${locker_number} 數據庫錯誤:`, err);
      }
    );

    res.json({
      success: true,
      message: `儲物柜 ${locker_number} 已刪除`,
      locker_number: parseInt(locker_number)
    });
  } catch (error) {
    console.error('刪除儲物柜錯誤:', error);
    res.status(500).json({
      error: '刪除儲物柜失敗',
      message: error.message
    });
  }
});

// 新增儲物柜（支持指定編號或自動編號）
router.post('/', (req, res) => {
  try {
    const { locker_number, location, is_refrigerated, max_weight, is_occupied, customer_id } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';

    // 決定儲物柜編號
    let newLockerNumber;
    if (locker_number !== undefined) {
      // 檢查編號是否已存在
      const existingLocker = lockerStatus.lockers.find(l => l.locker_number === parseInt(locker_number));
      if (existingLocker) {
        return res.status(400).json({ error: `儲物柜編號 ${locker_number} 已存在` });
      }
      newLockerNumber = parseInt(locker_number);
    } else {
      // 自動生成編號（當前最大編號+1）
      const maxLockerNumber = lockerStatus.lockers.length > 0
        ? Math.max(...lockerStatus.lockers.map(l => l.locker_number))
        : 0;
      newLockerNumber = maxLockerNumber + 1;
    }

    const newLocker = {
      locker_number: newLockerNumber,
      is_occupied: is_occupied || false,
      is_open: false,
      customer_id: customer_id || null,
      opened_at: null,
      product_id: null,
      temperature: is_refrigerated ? 5.0 : 22.5,
      battery_level: 100,
      last_maintenance: new Date().toISOString(),
      error_state: null,
      is_refrigerated: is_refrigerated || false,
      bank_id: 'bank-001',
      location: location || `區域-A-${String(newLockerNumber).padStart(2, '0')}`,
      max_weight: max_weight || 5.0,
      current_weight: 0.0,
      door_open_count: 0,
      total_usage_time: 0
    };

    lockerStatus.lockers.push(newLocker);

    // 同步到數據庫
    syncLockerToDatabase(newLocker, storeId);

    // 記錄新增事件
    logLockerEvent('locker_added', newLockerNumber, {
      location: newLocker.location,
      is_refrigerated: newLocker.is_refrigerated,
      max_weight: newLocker.max_weight,
      is_occupied: newLocker.is_occupied,
      customer_id: newLocker.customer_id
    });

    res.json({
      success: true,
      message: `儲物柜 ${newLockerNumber} 新增成功`,
      locker: newLocker
    });
  } catch (error) {
    console.error('新增儲物柜錯誤:', error);
    res.status(500).json({
      error: '新增儲物柜失敗',
      message: error.message
    });
  }
});

// 更新儲物柜（主要用於更新佔用狀態）
router.put('/:locker_number', (req, res) => {
  try {
    const { locker_number } = req.params;
    const { is_occupied, customer_id, force_update } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';

    const locker = lockerStatus.lockers.find(l => l.locker_number === parseInt(locker_number));

    if (!locker) {
      return res.status(404).json({ error: '儲物柜不存在' });
    }

    // 檢查儲物柜狀態
    const healthIssues = checkLockerHealth(locker);
    const criticalIssues = healthIssues.filter(issue => issue.severity === 'critical');

    if (criticalIssues.length > 0 && !force_update) {
      return res.status(400).json({
        error: '儲物柜有嚴重故障',
        code: 'critical_fault',
        issues: criticalIssues
      });
    }

    // 記錄更新前的狀態
    const wasOccupied = locker.is_occupied;
    const previousCustomerId = locker.customer_id;

    // 更新儲物柜狀態
    if (is_occupied !== undefined) {
      locker.is_occupied = is_occupied;
    }
    if (customer_id !== undefined) {
      locker.customer_id = customer_id;
    }
    // 如果設置為未佔用，清空客戶ID
    if (locker.is_occupied === false) {
      locker.customer_id = null;
    }

    // 記錄更新事件
    logLockerEvent('locker_updated', locker.locker_number, {
      previous_occupied: wasOccupied,
      previous_customer_id: previousCustomerId,
      new_occupied: locker.is_occupied,
      new_customer_id: locker.customer_id,
      force_update: force_update || false,
      issues: healthIssues.length > 0 ? healthIssues : undefined
    });

    // 同步到數據庫
    syncLockerToDatabase(locker, storeId);

    // 觸發Socket事件
    const io = req.app.get('io');
    io.emit('locker-updated', {
      locker_number: locker.locker_number,
      is_occupied: locker.is_occupied,
      customer_id: locker.customer_id,
      timestamp: new Date().toISOString()
    });

    res.json({
      success: true,
      message: `儲物柜 ${locker.locker_number} 更新成功`,
      locker: {
        locker_number: locker.locker_number,
        is_occupied: locker.is_occupied,
        customer_id: locker.customer_id
      }
    });
  } catch (error) {
    console.error('更新儲物柜錯誤:', error);
    res.status(500).json({
      error: '更新儲物柜失敗',
      message: error.message
    });
  }
});

// 分配儲物柜給客人
router.post('/:locker_number/assign', (req, res) => {
  try {
    const { locker_number } = req.params;
    const { customer_id, force_assign, table_number } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';

    if (!customer_id) {
      return res.status(400).json({ error: '請提供客人ID' });
    }

    const locker = lockerStatus.lockers.find(l => l.locker_number === parseInt(locker_number));

    if (!locker) {
      return res.status(404).json({ error: '儲物柜不存在' });
    }

    // 檢查儲物柜狀態
    const healthIssues = checkLockerHealth(locker);
    const criticalIssues = healthIssues.filter(issue => issue.severity === 'critical');

    if (criticalIssues.length > 0 && !force_assign) {
      return res.status(400).json({
        error: '儲物柜有嚴重故障',
        code: 'critical_fault',
        issues: criticalIssues
      });
    }

    // 檢查是否已被其他客人佔用
    if (locker.is_occupied && locker.customer_id !== customer_id) {
      return res.status(400).json({
        error: '儲物柜已被其他客人佔用',
        code: 'occupied_by_other',
        current_customer: locker.customer_id
      });
    }

    // 記錄分配前的狀態
    const wasOccupied = locker.is_occupied;
    const previousCustomerId = locker.customer_id;

    // 分配儲物柜給客人
    locker.is_occupied = true;
    // 使用客戶UUID作為customer_id，以便查詢關聯
    locker.customer_id = customer_id;
    // 儲存桌號作為顯示用
    locker.table_number = table_number;

    // 記錄分配事件
    logLockerEvent('locker_assigned', locker.locker_number, {
      customer_id: customer_id,
      table_number: table_number,
      previous_occupied: wasOccupied,
      previous_customer_id: previousCustomerId,
      force_assign: force_assign || false,
      issues: healthIssues.length > 0 ? healthIssues : undefined
    });

    // 同步到數據庫
    console.log(`[DEBUG] 分配儲物柜 ${locker.locker_number} 到客戶 ${customer_id} (桌號 ${table_number})`);
    console.log(`[DEBUG] locker 對象:`, {
      locker_number: locker.locker_number,
      is_occupied: locker.is_occupied,
      customer_id: locker.customer_id,
      table_number: locker.table_number
    });
    syncLockerToDatabase(locker, storeId);
    console.log(`[DEBUG] syncLockerToDatabase 調用完成`);

    // 觸發Socket事件
    const io = req.app.get('io');
    io.emit('locker-assigned', {
      locker_number: locker.locker_number,
      customer_id: customer_id,
      table_number: table_number,
      previous_occupied: wasOccupied,
      previous_customer_id: previousCustomerId,
      timestamp: new Date().toISOString()
    });

    res.json({
      success: true,
      message: `儲物柜 ${locker.locker_number} 已分配給客人`,
      locker: {
        locker_number: locker.locker_number,
        is_occupied: locker.is_occupied,
        customer_id: locker.customer_id,
        table_number: table_number,
        assigned_at: new Date().toISOString()
      },
      customer_id: customer_id,
      table_number: table_number
    });
  } catch (error) {
    console.error('分配儲物柜錯誤:', error);
    logLockerEvent('locker_assign_error', null, {
      locker_number: req.params.locker_number,
      customer_id: req.body.customer_id,
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({
      error: '分配儲物柜失敗',
      message: error.message,
      code: 'internal_error'
    });
  }
});

// 配置管理端點
router.get('/config', (req, res) => {
  try {
    res.json({
      success: true,
      config: LOCKER_CONFIG,
      error_simulation: ERROR_SIMULATION,
      system_info: {
        device_id: lockerStatus.device_id,
        firmware_version: lockerStatus.firmware_version,
        hardware_model: lockerStatus.hardware_model,
        total_lockers: lockerStatus.lockers.length,
        refrigerated_count: lockerStatus.lockers.filter(l => l.is_refrigerated).length,
        battery_powered_count: lockerStatus.lockers.filter(l => l.battery_level < 100).length
      }
    });
  } catch (error) {
    console.error('獲取配置錯誤:', error);
    res.status(500).json({
      error: '獲取配置失敗',
      message: error.message
    });
  }
});

// 更新配置
router.post('/config/update', (req, res) => {
  try {
    const { config_updates } = req.body;

    if (!config_updates || typeof config_updates !== 'object') {
      return res.status(400).json({ error: '請提供有效的配置更新' });
    }

    // 更新配置（只允許更新特定字段）
    const allowedUpdates = [
      'AUTO_CLOSE_TIMEOUT',
      'TEST_OPEN_DURATION',
      'BATTERY_WARNING_LEVEL',
      'BATTERY_CRITICAL_LEVEL',
      'MAINTENANCE_CHECK_INTERVAL'
    ];

    Object.keys(config_updates).forEach(key => {
      if (allowedUpdates.includes(key) && typeof config_updates[key] === 'number') {
        LOCKER_CONFIG[key] = config_updates[key];
      }
    });

    logLockerEvent('config_updated', null, {
      updates: config_updates,
      allowed_updates: allowedUpdates
    });

    res.json({
      success: true,
      message: '配置更新成功',
      updated_config: LOCKER_CONFIG
    });
  } catch (error) {
    console.error('更新配置錯誤:', error);
    res.status(500).json({
      error: '更新配置失敗',
      message: error.message
    });
  }
});

// 錯誤模擬控制
router.post('/error-simulation', (req, res) => {
  try {
    const { enabled, fault_locker_numbers, communication_errors, temperature_alarm, battery_drain_rate } = req.body;

    if (enabled !== undefined) ERROR_SIMULATION.enabled = enabled;
    if (fault_locker_numbers !== undefined) ERROR_SIMULATION.fault_locker_numbers = fault_locker_numbers;
    if (communication_errors !== undefined) ERROR_SIMULATION.communication_errors = communication_errors;
    if (temperature_alarm !== undefined) ERROR_SIMULATION.temperature_alarm = temperature_alarm;
    if (battery_drain_rate !== undefined) ERROR_SIMULATION.battery_drain_rate = battery_drain_rate;

    logLockerEvent('error_simulation_updated', null, {
      enabled: ERROR_SIMULATION.enabled,
      fault_locker_count: ERROR_SIMULATION.fault_locker_numbers.length,
      communication_errors: ERROR_SIMULATION.communication_errors,
      temperature_alarm: ERROR_SIMULATION.temperature_alarm,
      battery_drain_rate: ERROR_SIMULATION.battery_drain_rate
    });

    res.json({
      success: true,
      message: '錯誤模擬設置更新成功',
      error_simulation: ERROR_SIMULATION
    });
  } catch (error) {
    console.error('更新錯誤模擬設置錯誤:', error);
    res.status(500).json({
      error: '更新錯誤模擬設置失敗',
      message: error.message
    });
  }
});

// 緊急釋放所有儲物柜
router.post('/emergency-release-all', (req, res) => {
  try {
    const { reason, operator_id } = req.body;

    if (!reason) {
      return res.status(400).json({ error: '請提供緊急釋放原因' });
    }

    const releasedCount = lockerStatus.lockers.filter(l => l.is_occupied).length;
    const openCount = lockerStatus.lockers.filter(l => l.is_open).length;

    // 釋放所有儲物柜
    lockerStatus.lockers.forEach(locker => {
      if (locker.is_occupied) {
        const wasOpen = locker.is_open;
        locker.is_occupied = false;
        locker.is_open = false;
        locker.customer_id = null;
        locker.product_id = null;

        if (wasOpen) {
          logLockerEvent('locker_emergency_closed', locker.locker_number, {
            reason: reason,
            operator_id: operator_id
          });
        }
      }
    });

    // 記錄緊急事件
    logLockerEvent('emergency_release_all', null, {
      reason: reason,
      operator_id: operator_id,
      released_count: releasedCount,
      open_count: openCount
    });

    // 觸發Socket事件
    const io = req.app.get('io');
    io.emit('lockers-emergency-released', {
      reason: reason,
      operator_id: operator_id,
      released_count: releasedCount,
      open_count: openCount,
      timestamp: new Date().toISOString()
    });

    res.json({
      success: true,
      message: '緊急釋放所有儲物柜成功',
      summary: {
        released_count: releasedCount,
        open_count: openCount,
        total_lockers: lockerStatus.lockers.length
      },
      reason: reason,
      operator_id: operator_id,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('緊急釋放錯誤:', error);
    logLockerEvent('emergency_release_error', null, {
      error: error.message,
      stack: error.stack
    });
    res.status(500).json({
      error: '緊急釋放失敗',
      message: error.message
    });
  }
});

// 維護模式
router.post('/maintenance-mode', (req, res) => {
  try {
    const { enabled, locker_numbers, maintenance_type } = req.body;

    if (locker_numbers && Array.isArray(locker_numbers)) {
      // 特定儲物柜維護模式
      locker_numbers.forEach(locker_number => {
        const locker = lockerStatus.lockers.find(l => l.locker_number === locker_number);
        if (locker) {
          locker.maintenance_mode = enabled;
          locker.maintenance_type = maintenance_type;
          locker.last_maintenance = new Date().toISOString();

          logLockerEvent('locker_maintenance_mode', locker_number, {
            enabled: enabled,
            maintenance_type: maintenance_type
          });
        }
      });
    } else {
      // 所有儲物柜維護模式
      lockerStatus.lockers.forEach(locker => {
        locker.maintenance_mode = enabled;
        if (enabled) {
          locker.maintenance_type = maintenance_type;
          locker.last_maintenance = new Date().toISOString();
        }
      });

      logLockerEvent('system_maintenance_mode', null, {
        enabled: enabled,
        maintenance_type: maintenance_type,
        locker_count: lockerStatus.lockers.length
      });
    }

    res.json({
      success: true,
      message: `維護模式 ${enabled ? '啟用' : '停用'} 成功`,
      maintenance_mode: enabled,
      affected_lockers: locker_numbers || 'all',
      maintenance_type: maintenance_type
    });
  } catch (error) {
    console.error('維護模式設置錯誤:', error);
    res.status(500).json({
      error: '維護模式設置失敗',
      message: error.message
    });
  }
});

// 獲取事件日誌
router.get('/events', (req, res) => {
  try {
    const { limit, event_type, start_time, end_time } = req.query;
    let filteredEvents = [...lockerEvents];

    if (event_type) {
      filteredEvents = filteredEvents.filter(event => event.event_type === event_type);
    }

    if (start_time) {
      const start = new Date(start_time);
      filteredEvents = filteredEvents.filter(event => new Date(event.timestamp) >= start);
    }

    if (end_time) {
      const end = new Date(end_time);
      filteredEvents = filteredEvents.filter(event => new Date(event.timestamp) <= end);
    }

    // 限制返回數量
    const eventLimit = limit ? parseInt(limit) : 100;
    filteredEvents = filteredEvents.slice(-eventLimit);

    res.json({
      success: true,
      events: filteredEvents,
      total_count: lockerEvents.length,
      filtered_count: filteredEvents.length,
      query: {
        limit: eventLimit,
        event_type: event_type,
        start_time: start_time,
        end_time: end_time
      }
    });
  } catch (error) {
    console.error('獲取事件日誌錯誤:', error);
    res.status(500).json({
      error: '獲取事件日誌失敗',
      message: error.message
    });
  }
});

// 系統診斷
router.get('/diagnostics', (req, res) => {
  try {
    const diagnostics = {
      system_health: {
        overall_status: lockerStatus.status,
        last_heartbeat: lockerStatus.last_seen,
        locker_count: lockerStatus.lockers.length,
        online_lockers: lockerStatus.lockers.filter(l => !l.error_state).length,
        faulty_lockers: lockerStatus.lockers.filter(l => l.error_state).length,
        open_lockers: lockerStatus.lockers.filter(l => l.is_open).length,
        occupied_lockers: lockerStatus.lockers.filter(l => l.is_occupied).length
      },
      battery_health: {
        average_level: (lockerStatus.lockers.reduce((sum, l) => sum + l.battery_level, 0) / lockerStatus.lockers.length).toFixed(1),
        low_battery_count: lockerStatus.lockers.filter(l => l.battery_level <= LOCKER_CONFIG.BATTERY_WARNING_LEVEL).length,
        critical_battery_count: lockerStatus.lockers.filter(l => l.battery_level <= LOCKER_CONFIG.BATTERY_CRITICAL_LEVEL).length,
        min_battery: Math.min(...lockerStatus.lockers.map(l => l.battery_level)).toFixed(1),
        max_battery: Math.max(...lockerStatus.lockers.map(l => l.battery_level)).toFixed(1)
      },
      temperature_health: {
        refrigerated_count: lockerStatus.lockers.filter(l => l.is_refrigerated).length,
        within_range: lockerStatus.lockers.filter(l => l.is_refrigerated &&
          l.temperature >= LOCKER_CONFIG.MIN_TEMPERATURE &&
          l.temperature <= LOCKER_CONFIG.MAX_TEMPERATURE).length,
        out_of_range: lockerStatus.lockers.filter(l => l.is_refrigerated &&
          (l.temperature < LOCKER_CONFIG.MIN_TEMPERATURE ||
           l.temperature > LOCKER_CONFIG.MAX_TEMPERATURE)).length,
        min_temperature: Math.min(...lockerStatus.lockers.map(l => l.temperature)).toFixed(1),
        max_temperature: Math.max(...lockerStatus.lockers.map(l => l.temperature)).toFixed(1)
      },
      usage_statistics: {
        total_door_open_count: lockerStatus.lockers.reduce((sum, l) => sum + l.door_open_count, 0),
        average_usage_time: (lockerStatus.lockers.reduce((sum, l) => sum + l.total_usage_time, 0) / lockerStatus.lockers.length).toFixed(1),
        most_used_locker: lockerStatus.lockers.reduce((max, l) => l.door_open_count > max.door_open_count ? l : max, lockerStatus.lockers[0]).locker_number,
        least_used_locker: lockerStatus.lockers.reduce((min, l) => l.door_open_count < min.door_open_count ? l : min, lockerStatus.lockers[0]).locker_number
      },
      error_summary: {
        total_errors: lockerStatus.lockers.filter(l => l.error_state).length,
        by_type: lockerStatus.lockers.reduce((acc, l) => {
          if (l.error_state) {
            acc[l.error_state] = (acc[l.error_state] || 0) + 1;
          }
          return acc;
        }, {})
      }
    };

    res.json({
      success: true,
      diagnostics: diagnostics,
      generated_at: new Date().toISOString()
    });
  } catch (error) {
    console.error('系統診斷錯誤:', error);
    res.status(500).json({
      error: '系統診斷失敗',
      message: error.message
    });
  }
});

// 獲取儲物柜狀態
router.get('/status', async (req, res) => {
  try {
    const storeId = req.storeContext?.store_id || 'default_store';
    const { locker_number, detailed } = req.query;

    // 直接從數據庫查詢儲物柜狀態（確保分店隔離）
    const db = require('../../database/db').db;

    if (locker_number) {
      // 獲取單個儲物柜狀態
      const query = `
        SELECT l.*, c.table_number
        FROM lockers l
        LEFT JOIN customers c ON l.customer_id = c.id
        WHERE l.locker_number = ? AND l.store_id = ?
      `;

      db.get(query, [locker_number, storeId], (err, dbLocker) => {
        if (err) {
          console.error('查詢單個儲物柜錯誤:', err);
          return res.status(500).json({
            error: '查詢儲物柜失敗',
            message: err.message
          });
        }

        if (!dbLocker) {
          return res.status(404).json({ error: '儲物柜不存在' });
        }

        // 轉換為前端期望的格式
        const locker = {
          locker_number: dbLocker.locker_number,
          is_occupied: dbLocker.is_occupied === 1,
          is_open: false, // 數據庫不存儲開關狀態，使用默認值
          customer_id: dbLocker.customer_id,
          table_number: dbLocker.table_number,
          opened_at: dbLocker.opened_at,
          product_id: null,
          temperature: 22.5,
          battery_level: 100,
          last_maintenance: dbLocker.last_maintenance || new Date().toISOString(),
          error_state: null,
          is_refrigerated: dbLocker.locker_number <= 5, // 前5個是冷藏櫃
          bank_id: 'bank-001',
          location: `區域-A-${String(dbLocker.locker_number).padStart(2, '0')}`,
          max_weight: 5.0,
          current_weight: 0.0,
          door_open_count: 0,
          total_usage_time: 0
        };

        // 計算健康狀態
        const healthIssues = checkLockerHealth(locker);
        const lockerWithHealth = {
          ...locker,
          health_issues: healthIssues.length > 0 ? healthIssues : undefined,
          health_score: calculateHealthScore(locker, healthIssues)
        };

        res.json({
          success: true,
          locker: (detailed === 'true' || detailed === '1') ? lockerWithHealth : locker
        });
      });
    } else {
      // 獲取所有儲物柜狀態
      const query = `
        SELECT l.*, c.table_number
        FROM lockers l
        LEFT JOIN customers c ON l.customer_id = c.id
        WHERE l.store_id = ?
        ORDER BY l.locker_number
      `;

      console.log(`[DEBUG] 查詢儲物柜狀態: storeId=${storeId}, query=${query}`);

      db.all(query, [storeId], (err, dbLockers) => {
        if (err) {
          console.error('查詢儲物柜列表錯誤:', err);
          return res.status(500).json({
            error: '查詢儲物柜列表失敗',
            message: err.message
          });
        }

        const detailedMode = detailed === 'true' || detailed === '1';
        const healthIssues = [];

        // 轉換為前端期望的格式
        const lockersWithHealth = dbLockers.map(dbLocker => {
          const locker = {
            locker_number: dbLocker.locker_number,
            is_occupied: dbLocker.is_occupied === 1,
            is_open: false, // 數據庫不存儲開關狀態，使用默認值
            customer_id: dbLocker.customer_id,
            table_number: dbLocker.table_number,
            opened_at: dbLocker.opened_at,
            product_id: null,
            temperature: dbLocker.locker_number <= 5 ? 5.0 : 22.5, // 冷藏櫃溫度
            battery_level: 100,
            last_maintenance: dbLocker.last_maintenance || new Date().toISOString(),
            error_state: null,
            is_refrigerated: dbLocker.locker_number <= 5, // 前5個是冷藏櫃
            bank_id: 'bank-001',
            location: `區域-A-${String(dbLocker.locker_number).padStart(2, '0')}`,
            max_weight: 5.0,
            current_weight: 0.0,
            door_open_count: 0,
            total_usage_time: 0
          };

          if (detailedMode) {
            const issues = checkLockerHealth(locker);
            if (issues.length > 0) {
              healthIssues.push(...issues.map(issue => ({
                locker_number: locker.locker_number,
                ...issue
              })));
            }

            return {
              ...locker,
              health_issues: issues.length > 0 ? issues : undefined,
              health_score: calculateHealthScore(locker, issues)
            };
          }

          return locker;
        });

        // 計算系統統計數據（基於當前分店的儲物柜）
        const occupiedCount = dbLockers.filter(l => l.is_occupied === 1).length;
        const refrigeratedCount = Math.min(5, dbLockers.length); // 前5個是冷藏櫃

        const systemStats = {
          device_id: `locker-system-${storeId}`,
          status: 'online',
          last_seen: new Date().toISOString(),
          firmware_version: '1.2.0',
          hardware_model: 'Locker-Pro-2024',
          ip_address: null,
          total_lockers: dbLockers.length,
          occupied_lockers: occupiedCount,
          open_lockers: 0, // 數據庫不存儲開關狀態
          refrigerated_count: refrigeratedCount,
          error_count: 0,
          battery_status: {
            average: 100.0,
            min: 100.0,
            max: 100.0,
            low_count: 0,
            critical_count: 0
          },
          temperature_stats: {
            min: 5.0,
            max: 22.5,
            refrigerated_in_range: refrigeratedCount,
            refrigerated_out_of_range: 0
          },
          usage_statistics: {
            total_door_open_count: 0,
            average_usage_time: 0,
            most_used_locker: dbLockers.length > 0 ? dbLockers[0].locker_number : 0,
            least_used_locker: dbLockers.length > 0 ? dbLockers[0].locker_number : 0
          },
          error_summary: {},
          health_issues_summary: {
            total_issues: healthIssues.length,
            by_severity: healthIssues.reduce((acc, issue) => {
              acc[issue.severity] = (acc[issue.severity] || 0) + 1;
              return acc;
            }, {}),
            by_type: healthIssues.reduce((acc, issue) => {
              acc[issue.type] = (acc[issue.type] || 0) + 1;
              return acc;
            }, {})
          }
        };

        res.json({
          success: true,
          system_status: systemStats,
          lockers: lockersWithHealth,
          timestamp: new Date().toISOString()
        });
      });
    }
  } catch (error) {
    console.error('獲取儲物柜狀態錯誤:', error);
    res.status(500).json({
      error: '獲取儲物柜狀態失敗',
      message: error.message
    });
  }
});

// 計算儲物柜健康分數（0-100）
function calculateHealthScore(locker, healthIssues) {
  let score = 100;

  // 扣除錯誤狀態
  if (locker.error_state) {
    score -= 30;
  }

  // 扣除健康問題
  healthIssues.forEach(issue => {
    if (issue.severity === 'critical') {
      score -= 20;
    } else if (issue.severity === 'warning') {
      score -= 10;
    }
  });

  // 電池電量影響
  if (locker.battery_level <= LOCKER_CONFIG.BATTERY_CRITICAL_LEVEL) {
    score -= 25;
  } else if (locker.battery_level <= LOCKER_CONFIG.BATTERY_WARNING_LEVEL) {
    score -= 15;
  }

  // 溫度影響（冷藏櫃）
  if (locker.is_refrigerated) {
    if (locker.temperature < LOCKER_CONFIG.MIN_TEMPERATURE ||
        locker.temperature > LOCKER_CONFIG.MAX_TEMPERATURE) {
      score -= 20;
    }
  }

  // 確保分數在0-100之間
  return Math.max(0, Math.min(100, score));
}

// 手動測試開啟儲物柜
router.post('/test-open', (req, res) => {
  try {
    const { locker_number, duration } = req.body;

    if (!locker_number) {
      return res.status(400).json({ error: '請提供儲物柜編號' });
    }

    const locker = lockerStatus.lockers.find(l => l.locker_number === locker_number);

    if (!locker) {
      return res.status(404).json({ error: '儲物柜不存在' });
    }

    // 開啟儲物柜
    locker.is_open = true;
    locker.opened_at = new Date().toISOString();

    const openDuration = duration || 10000; // 預設10秒

    // 設定自動關閉
    setTimeout(() => {
      if (locker.is_open) {
        locker.is_open = false;
        console.log(`測試儲物柜 ${locker_number} 自動關閉`);
      }
    }, openDuration);

    // 觸發Socket事件
    const io = req.app.get('io');
    io.emit('locker-test-opened', {
      locker_number: locker_number,
      duration: openDuration,
      timestamp: locker.opened_at
    });

    res.json({
      success: true,
      message: `儲物柜 ${locker_number} 已開啟（測試模式）`,
      locker: {
        locker_number: locker.locker_number,
        is_open: locker.is_open,
        opened_at: locker.opened_at,
        will_close_in: openDuration / 1000
      }
    });
  } catch (error) {
    console.error('測試開啟儲物柜錯誤:', error);
    res.status(500).json({
      error: '測試開啟儲物柜失敗',
      message: error.message
    });
  }
});

module.exports = router;
module.exports.lockerStatus = lockerStatus;
module.exports.syncOccupancyFromDatabase = syncOccupancyFromDatabase;