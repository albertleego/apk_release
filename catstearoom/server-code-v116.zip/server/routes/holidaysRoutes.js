const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');
const storeAwareMiddleware = require('../middleware/store-aware');

// 為所有路由添加分店上下文中間件
router.use(storeAwareMiddleware.initStoreContext);

/**
 * @route GET /api/holidays
 * @desc 獲取節假日列表（支持年份過濾）
 * @access Private/Staff
 */
router.get('/', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const storeId = 'default_store'; // 所有分店共用節假日
        const { year, month } = req.query;

        let query = `SELECT
            h.id, h.date, h.description,
            e.full_name as created_by_name, h.created_at
            FROM holidays h
            LEFT JOIN employees e ON h.created_by = e.id
            WHERE 1=1 AND h.store_id = ?`;
        const params = [storeId];

        // 年份過濾
        if (year) {
            query += ` AND strftime('%Y', h.date) = ?`;
            params.push(year);
        }

        // 月份過濾
        if (month) {
            query += ` AND strftime('%m', h.date) = ?`;
            params.push(month.padStart(2, '0'));
        }

        query += ` ORDER BY h.date DESC`;

        console.log('查詢節假日:', { year, month, query, params });

        db.all(query, params, (err, holidays) => {
            if (err) {
                console.error('查詢節假日錯誤:', err);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: err.message
                });
            }

            // 格式化日期為YYYY-MM-DD格式
            const formattedHolidays = holidays.map(holiday => ({
                ...holiday,
                date: holiday.date // SQLite DATE類型已經返回YYYY-MM-DD格式
            }));

            res.json({
                success: true,
                data: {
                    holidays: formattedHolidays
                }
            });
        });
    } catch (error) {
        console.error('獲取節假日錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取節假日失敗',
            message: error.message
        });
    }
});

/**
 * @route POST /api/holidays
 * @desc 創建新節假日
 * @access Private/Staff
 */
router.post('/', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const storeId = 'default_store'; // 所有分店共用節假日
        const { date, description } = req.body;
        const employeeId = req.employee.id;
        const ipAddress = req.ip || req.connection.remoteAddress;

        console.log('創建節假日:', { date, description, employeeId });

        // 驗證必填字段
        if (!date) {
            return res.status(400).json({
                success: false,
                error: '缺少必要字段',
                message: '請提供節假日日期'
            });
        }

        // 驗證日期格式（YYYY-MM-DD）
        const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
        if (!dateRegex.test(date)) {
            return res.status(400).json({
                success: false,
                error: '無效的日期格式',
                message: '日期格式必須為YYYY-MM-DD'
            });
        }

        // 檢查日期是否已存在
        db.get(
            `SELECT id FROM holidays WHERE date = ? AND store_id = ?`,
            [date, storeId],
            (checkErr, existingHoliday) => {
                if (checkErr) {
                    console.error('檢查節假日錯誤:', checkErr);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: checkErr.message
                    });
                }

                if (existingHoliday) {
                    return res.status(400).json({
                        success: false,
                        error: '日期已存在',
                        message: `日期 ${date} 已設置為節假日`
                    });
                }

                // 創建新節假日
                const holidayId = uuidv4();
                const now = new Date().toISOString();

                db.run(
                    `INSERT INTO holidays (id, date, description, created_by, created_at, store_id)
                     VALUES (?, ?, ?, ?, ?, ?)`,
                    [holidayId, date, description || null, employeeId, now, storeId],
                    function(insertErr) {
                        if (insertErr) {
                            console.error('創建節假日錯誤:', insertErr);
                            return res.status(500).json({
                                success: false,
                                error: '服務器錯誤',
                                message: insertErr.message
                            });
                        }

                        // 創建審計日誌
                        authMiddleware.createAuditLog(
                            employeeId,
                            'holiday_create',
                            `創建節假日: ${date}${description ? ` (${description})` : ''}`,
                            ipAddress
                        );

                        // 獲取新創建的節假日信息
                        db.get(
                            `SELECT
                                h.id, h.date, h.description,
                                e.full_name as created_by_name, h.created_at
                             FROM holidays h
                             LEFT JOIN employees e ON h.created_by = e.id
                             WHERE h.id = ? AND h.store_id = ?`,
                            [holidayId, storeId],
                            (selectErr, newHoliday) => {
                                if (selectErr) {
                                    console.error('獲取新節假日錯誤:', selectErr);
                                }

                                res.status(201).json({
                                    success: true,
                                    message: '節假日創建成功',
                                    data: {
                                        holiday: newHoliday || {
                                            id: holidayId,
                                            date,
                                            description: description || null,
                                            created_by_name: req.employee.full_name,
                                            created_at: now
                                        }
                                    }
                                });
                            }
                        );
                    }
                );
            }
        );
    } catch (error) {
        console.error('創建節假日錯誤:', error);
        res.status(500).json({
            success: false,
            error: '創建節假日失敗',
            message: error.message
        });
    }
});

/**
 * @route PUT /api/holidays/:id
 * @desc 更新節假日信息
 * @access Private/Staff
 */
router.put('/:id', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const storeId = 'default_store'; // 所有分店共用節假日
        const { id } = req.params;
        const { date, description } = req.body;
        const employeeId = req.employee.id;
        const ipAddress = req.ip || req.connection.remoteAddress;

        console.log('更新節假日:', { id, date, description });

        // 檢查節假日是否存在
        db.get(
            `SELECT id, date FROM holidays WHERE id = ? AND store_id = ?`,
            [id, storeId],
            (checkErr, existingHoliday) => {
                if (checkErr) {
                    console.error('檢查節假日錯誤:', checkErr);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: checkErr.message
                    });
                }

                if (!existingHoliday) {
                    return res.status(404).json({
                        success: false,
                        error: '節假日不存在',
                        message: '找不到指定的節假日'
                    });
                }

                // 如果提供了新日期，檢查是否與其他節假日衝突
                const checkDateConflict = (callback) => {
                    if (!date || date === existingHoliday.date) {
                        // 沒有新日期或與當前相同，直接回調
                        return callback(null);
                    }

                    // 驗證日期格式
                    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
                    if (!dateRegex.test(date)) {
                        return callback(new Error('日期格式必須為YYYY-MM-DD'));
                    }

                    db.get(
                        `SELECT id FROM holidays WHERE date = ? AND id != ? AND store_id = ?`,
                        [date, id, storeId],
                        (dateErr, conflictHoliday) => {
                            if (dateErr) {
                                return callback(dateErr);
                            }

                            if (conflictHoliday) {
                                return callback(new Error(`日期 ${date} 已設置為其他節假日`));
                            }

                            callback(null);
                        }
                    );
                };

                checkDateConflict((dateErr) => {
                    if (dateErr) {
                        return res.status(400).json({
                            success: false,
                            error: '日期衝突',
                            message: dateErr.message
                        });
                    }

                    // 構建更新語句
                    const updates = [];
                    const params = [];

                    if (date !== undefined) {
                        updates.push('date = ?');
                        params.push(date);
                    }

                    if (description !== undefined) {
                        updates.push('description = ?');
                        params.push(description || null);
                    }

                    if (updates.length === 0) {
                        return res.status(400).json({
                            success: false,
                            error: '無效的更新',
                            message: '沒有提供可更新的字段'
                        });
                    }

                    // 添加WHERE條件
                    params.push(id);
                    params.push(storeId);

                    const updateQuery = `UPDATE holidays SET ${updates.join(', ')} WHERE id = ? AND store_id = ?`;

                    db.run(updateQuery, params, function(updateErr) {
                        if (updateErr) {
                            console.error('更新節假日錯誤:', updateErr);
                            return res.status(500).json({
                                success: false,
                                error: '服務器錯誤',
                                message: updateErr.message
                            });
                        }

                        if (this.changes === 0) {
                            return res.status(404).json({
                                success: false,
                                error: '節假日不存在',
                                message: '找不到指定的節假日'
                            });
                        }

                        // 創建審計日誌
                        authMiddleware.createAuditLog(
                            employeeId,
                            'holiday_update',
                            `更新節假日: ${date || existingHoliday.date}${description ? ` (${description})` : ''}`,
                            ipAddress
                        );

                        // 獲取更新後的節假日信息
                        db.get(
                            `SELECT
                                h.id, h.date, h.description,
                                e.full_name as created_by_name, h.created_at
                             FROM holidays h
                             LEFT JOIN employees e ON h.created_by = e.id
                             WHERE h.id = ? AND h.store_id = ?`,
                            [id, storeId],
                            (selectErr, updatedHoliday) => {
                                if (selectErr) {
                                    console.error('獲取更新後節假日錯誤:', selectErr);
                                }

                                res.json({
                                    success: true,
                                    message: '節假日更新成功',
                                    data: {
                                        holiday: updatedHoliday || {
                                            id,
                                            date: date || existingHoliday.date,
                                            description: description !== undefined ? description : existingHoliday.description,
                                            created_by_name: req.employee.full_name,
                                            created_at: existingHoliday.created_at
                                        }
                                    }
                                });
                            }
                        );
                    });
                });
            }
        );
    } catch (error) {
        console.error('更新節假日錯誤:', error);
        res.status(500).json({
            success: false,
            error: '更新節假日失敗',
            message: error.message
        });
    }
});

/**
 * @route DELETE /api/holidays/:id
 * @desc 刪除節假日
 * @access Private/Staff
 */
router.delete('/:id', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const storeId = 'default_store'; // 所有分店共用節假日
        const { id } = req.params;
        const employeeId = req.employee.id;
        const ipAddress = req.ip || req.connection.remoteAddress;

        console.log('刪除節假日:', { id });

        // 檢查節假日是否存在
        db.get(
            `SELECT id, date, description FROM holidays WHERE id = ? AND store_id = ?`,
            [id, storeId],
            (checkErr, existingHoliday) => {
                if (checkErr) {
                    console.error('檢查節假日錯誤:', checkErr);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: checkErr.message
                    });
                }

                if (!existingHoliday) {
                    return res.status(404).json({
                        success: false,
                        error: '節假日不存在',
                        message: '找不到指定的節假日'
                    });
                }

                // 刪除節假日
                db.run(
                    `DELETE FROM holidays WHERE id = ? AND store_id = ?`,
                    [id, storeId],
                    function(deleteErr) {
                        if (deleteErr) {
                            console.error('刪除節假日錯誤:', deleteErr);
                            return res.status(500).json({
                                success: false,
                                error: '服務器錯誤',
                                message: deleteErr.message
                            });
                        }

                        // 創建審計日誌
                        authMiddleware.createAuditLog(
                            employeeId,
                            'holiday_delete',
                            `刪除節假日: ${existingHoliday.date}${existingHoliday.description ? ` (${existingHoliday.description})` : ''}`,
                            ipAddress
                        );

                        res.json({
                            success: true,
                            message: '節假日刪除成功',
                            data: {
                                deleted: true
                            }
                        });
                    }
                );
            }
        );
    } catch (error) {
        console.error('刪除節假日錯誤:', error);
        res.status(500).json({
            success: false,
            error: '刪除節假日失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/holidays/check/:date
 * @desc 檢查指定日期是否為節假日
 * @access Private/Staff
 */
router.get('/check/:date', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const storeId = 'default_store'; // 所有分店共用節假日
        const { date } = req.params;

        console.log('檢查日期是否為節假日:', date);

        // 驗證日期格式
        const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
        if (!dateRegex.test(date)) {
            return res.status(400).json({
                success: false,
                error: '無效的日期格式',
                message: '日期格式必須為YYYY-MM-DD'
            });
        }

        db.get(
            `SELECT id, date, description FROM holidays WHERE date = ? AND store_id = ?`,
            [date, storeId],
            (err, holiday) => {
                if (err) {
                    console.error('檢查節假日錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                res.json({
                    success: true,
                    data: {
                        is_holiday: !!holiday,
                        holiday: holiday || null
                    }
                });
            }
        );
    } catch (error) {
        console.error('檢查節假日錯誤:', error);
        res.status(500).json({
            success: false,
            error: '檢查節假日失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/holidays/public/daytype/:date
 * @desc 公開端點 - 檢查指定日期的 daytype（無需登入）
 * @access Public
 */
router.get('/public/daytype/:date', (req, res) => {
    try {
        const storeId = 'default_store';
        const { date } = req.params;

        // 驗證日期格式
        const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
        if (!dateRegex.test(date)) {
            return res.status(400).json({
                success: false,
                error: '無效的日期格式',
                message: '日期格式必須為YYYY-MM-DD'
            });
        }

        db.get(
            `SELECT id, date, description, daytype, is_holiday FROM holidays WHERE date = ? AND store_id = ?`,
            [date, storeId],
            (err, holiday) => {
                if (err) {
                    console.error('查詢 daytype 錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                res.json({
                    success: true,
                    data: {
                        date: date,
                        daytype: holiday ? holiday.daytype : '',
                        is_holiday: holiday ? holiday.is_holiday : 0,
                        description: holiday ? holiday.description : ''
                    }
                });
            }
        );
    } catch (error) {
        console.error('查詢 daytype 錯誤:', error);
        res.status(500).json({
            success: false,
            error: '查詢 daytype 失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/holidays/public/batch
 * @desc 公開端點 - 批量查詢某年或某月的所有 daytype（無需登入）
 * @access Public
 */
router.get('/public/batch', (req, res) => {
    try {
        const storeId = 'default_store';
        const { year, month } = req.query;

        let query = `SELECT date, daytype, is_holiday, description FROM holidays WHERE store_id = ?`;
        const params = [storeId];

        if (year) {
            query += ` AND strftime('%Y', date) = ?`;
            params.push(year);
        }
        if (month) {
            query += ` AND strftime('%m', date) = ?`;
            params.push(month.padStart(2, '0'));
        }

        query += ` ORDER BY date ASC`;

        db.all(query, params, (err, rows) => {
            if (err) {
                console.error('批量查詢 daytype 錯誤:', err);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: err.message
                });
            }

            // 轉成 { '2026-01-01': 'H', '2026-01-02': 'F', ... }
            const daytypeMap = {};
            rows.forEach(row => {
                daytypeMap[row.date] = {
                    daytype: row.daytype || '',
                    is_holiday: row.is_holiday || 0,
                    description: row.description || ''
                };
            });

            res.json({
                success: true,
                data: daytypeMap
            });
        });
    } catch (error) {
        console.error('批量查詢 daytype 錯誤:', error);
        res.status(500).json({
            success: false,
            error: '批量查詢失敗',
            message: error.message
        });
    }
});

module.exports = router;