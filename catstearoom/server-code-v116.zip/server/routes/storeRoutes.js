const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');
const storeAwareMiddleware = require('../middleware/store-aware');

// 為所有路由添加分店上下文中間件（暫時禁用）
// router.use(storeAwareMiddleware.initStoreContext);

/**
 * @route GET /api/stores
 * @desc 獲取分店列表（僅總部管理員）
 * @access Private/Admin
 */
router.get('/', (req, res) => { // authMiddleware.authenticate暫時移除
    try {
        // 暫時簡化：直接返回所有分店
        db.all(
            `SELECT * FROM stores ORDER BY id ASC`,
            (err, stores) => {
                if (err) {
                    console.error('查詢分店列表錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                res.json({
                    success: true,
                    data: stores
                });
            }
        );
    } catch (error) {
        console.error('獲取分店列表錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取分店列表失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/stores/:id
 * @desc 獲取單個分店詳情
 * @access Private/Admin
 */
router.get('/:id', authMiddleware.authenticate, (req, res) => {
    try {
        const { id } = req.params;
        const employeeRole = req.employee?.role;
        const employeeStoreId = req.employee?.store_id;

        // 檢查權限
        if (employeeRole !== 'admin') {
            return res.status(403).json({
                success: false,
                error: '權限不足',
                message: '只有管理員可以查看分店詳情'
            });
        }

        // 分店管理員只能查看自己的分店
        if (employeeStoreId && employeeStoreId !== id) {
            return res.status(403).json({
                success: false,
                error: '權限不足',
                message: '您只能查看自己分店的詳情'
            });
        }

        db.get(
            `SELECT * FROM stores WHERE id = ?`,
            [id],
            (err, store) => {
                if (err) {
                    console.error('查詢分店詳情錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                if (!store) {
                    return res.status(404).json({
                        success: false,
                        error: '分店不存在',
                        message: '指定的分店不存在'
                    });
                }

                res.json({
                    success: true,
                    data: store
                });
            }
        );
    } catch (error) {
        console.error('獲取分店詳情錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取分店詳情失敗',
            message: error.message
        });
    }
});

/**
 * @route POST /api/stores
 * @desc 創建新分店（僅總部管理員）
 * @access Private/Admin
 */
router.post('/', authMiddleware.authenticate, (req, res) => {
    try {
        const employeeRole = req.employee?.role;
        const employeeStoreId = req.employee?.store_id;

        // 只有總部管理員（store_id為NULL的admin）可以創建分店
        if (employeeRole !== 'admin' || employeeStoreId !== null) {
            return res.status(403).json({
                success: false,
                error: '權限不足',
                message: '只有總部管理員可以創建分店'
            });
        }

        const { store_code, store_name, address, phone, email, opening_hours, description, timezone = 'Asia/Hong_Kong', status = 'active', settings = '{"timezone": "Asia/Hong_Kong", "currency": "HKD"}', use_lockers = 1 } = req.body;

        // 驗證必填字段
        if (!store_code || !store_name) {
            return res.status(400).json({
                success: false,
                error: '缺少必要字段',
                message: '請提供分店代碼和名稱'
            });
        }

        // 檢查分店代碼是否已存在
        db.get(
            `SELECT id FROM stores WHERE store_code = ?`,
            [store_code],
            (checkErr, existingStore) => {
                if (checkErr) {
                    console.error('檢查分店代碼錯誤:', checkErr);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: checkErr.message
                    });
                }

                if (existingStore) {
                    return res.status(400).json({
                        success: false,
                        error: '分店代碼已存在',
                        message: `分店代碼 ${store_code} 已被使用`
                    });
                }

                // 創建新分店
                const storeId = uuidv4();
                const now = new Date().toISOString();

                // 計算is_active基於status
                const is_active = status === 'active' || status === 'maintenance' ? 1 : 0;

                db.run(
                    `INSERT INTO stores (id, store_code, store_name, address, phone, email, opening_hours, description, timezone, is_active, status, settings, use_lockers, created_at, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [storeId, store_code, store_name, address || null, phone || null, email || null, opening_hours || null, description || null, timezone, is_active, status, settings, use_lockers, now, now],
                    function(insertErr) {
                        if (insertErr) {
                            console.error('創建分店錯誤:', insertErr);
                            return res.status(500).json({
                                success: false,
                                error: '服務器錯誤',
                                message: insertErr.message
                            });
                        }

                        // 創建審計日誌
                        authMiddleware.createAuditLog(
                            req.employee.id,
                            'store_create',
                            `創建分店: ${store_name} (${store_code})`,
                            req.ip || req.connection.remoteAddress
                        );

                        // 獲取新創建的分店信息
                        db.get(
                            `SELECT * FROM stores WHERE id = ?`,
                            [storeId],
                            (selectErr, newStore) => {
                                if (selectErr) {
                                    console.error('獲取新分店錯誤:', selectErr);
                                }

                                res.status(201).json({
                                    success: true,
                                    message: '分店創建成功',
                                    data: {
                                        store: newStore || {
                                            id: storeId,
                                            store_code,
                                            store_name,
                                            address: address || null,
                                            phone: phone || null,
                                            timezone,
                                            is_active: 1,
                                            created_at: now,
                                            updated_at: now
                                        }
                                    }
                                });
                            }
                        );
                    }
                );
            }
        );
    } catch (error) {
        console.error('創建分店錯誤:', error);
        res.status(500).json({
            success: false,
            error: '創建分店失敗',
            message: error.message
        });
    }
});

/**
 * @route PUT /api/stores/:id
 * @desc 更新分店信息
 * @access Private/Admin
 */
router.put('/:id', authMiddleware.authenticate, (req, res) => {
    try {
        const { id } = req.params;
        const employeeRole = req.employee?.role;
        const employeeStoreId = req.employee?.store_id;

        // 檢查權限
        if (employeeRole !== 'admin') {
            return res.status(403).json({
                success: false,
                error: '權限不足',
                message: '只有管理員可以更新分店信息'
            });
        }

        // 分店管理員只能更新自己的分店，總部管理員可以更新任何分店
        if (employeeStoreId && employeeStoreId !== id) {
            return res.status(403).json({
                success: false,
                error: '權限不足',
                message: '您只能更新自己分店的信息'
            });
        }

        const { store_code, store_name, address, phone, email, opening_hours, description, timezone, status, settings, is_active, use_lockers } = req.body;

        // 檢查分店是否存在
        db.get(
            `SELECT id, store_code FROM stores WHERE id = ?`,
            [id],
            (checkErr, existingStore) => {
                if (checkErr) {
                    console.error('檢查分店錯誤:', checkErr);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: checkErr.message
                    });
                }

                if (!existingStore) {
                    return res.status(404).json({
                        success: false,
                        error: '分店不存在',
                        message: '指定的分店不存在'
                    });
                }

                // 如果提供了新分店代碼，檢查是否與其他分店衝突
                const checkCodeConflict = (callback) => {
                    if (!store_code || store_code === existingStore.store_code) {
                        return callback(null);
                    }

                    db.get(
                        `SELECT id FROM stores WHERE store_code = ? AND id != ?`,
                        [store_code, id],
                        (codeErr, conflictStore) => {
                            if (codeErr) {
                                return callback(codeErr);
                            }

                            if (conflictStore) {
                                return callback(new Error(`分店代碼 ${store_code} 已被其他分店使用`));
                            }

                            callback(null);
                        }
                    );
                };

                checkCodeConflict((codeErr) => {
                    if (codeErr) {
                        return res.status(400).json({
                            success: false,
                            error: '分店代碼衝突',
                            message: codeErr.message
                        });
                    }

                    // 構建更新語句
                    const updates = [];
                    const params = [];

                    if (store_code !== undefined) {
                        updates.push('store_code = ?');
                        params.push(store_code);
                    }

                    if (store_name !== undefined) {
                        updates.push('store_name = ?');
                        params.push(store_name);
                    }

                    if (address !== undefined) {
                        updates.push('address = ?');
                        params.push(address || null);
                    }

                    if (phone !== undefined) {
                        updates.push('phone = ?');
                        params.push(phone || null);
                    }

                    if (email !== undefined) {
                        updates.push('email = ?');
                        params.push(email || null);
                    }

                    if (opening_hours !== undefined) {
                        updates.push('opening_hours = ?');
                        params.push(opening_hours || null);
                    }

                    if (description !== undefined) {
                        updates.push('description = ?');
                        params.push(description || null);
                    }

                    if (settings !== undefined) {
                        updates.push('settings = ?');
                        params.push(settings);
                    }

                    if (status !== undefined) {
                        updates.push('status = ?');
                        params.push(status);
                        // 根據status更新is_active
                        const isActiveFromStatus = status === 'active' || status === 'maintenance' ? 1 : 0;
                        updates.push('is_active = ?');
                        params.push(isActiveFromStatus);
                    }

                    if (timezone !== undefined) {
                        updates.push('timezone = ?');
                        params.push(timezone);
                    }

                    // 只有總部管理員可以修改is_active狀態
                    if (is_active !== undefined && employeeStoreId === null) {
                        updates.push('is_active = ?');
                        params.push(is_active ? 1 : 0);
                    }

                    if (use_lockers !== undefined) {
                        updates.push('use_lockers = ?');
                        params.push(use_lockers ? 1 : 0);
                    }

                    if (updates.length === 0) {
                        return res.status(400).json({
                            success: false,
                            error: '無效的更新',
                            message: '沒有提供可更新的字段'
                        });
                    }

                    // 添加updated_at和WHERE條件
                    updates.push('updated_at = ?');
                    params.push(new Date().toISOString());
                    params.push(id);

                    const updateQuery = `UPDATE stores SET ${updates.join(', ')} WHERE id = ?`;

                    db.run(updateQuery, params, function(updateErr) {
                        if (updateErr) {
                            console.error('更新分店錯誤:', updateErr);
                            return res.status(500).json({
                                success: false,
                                error: '服務器錯誤',
                                message: updateErr.message
                            });
                        }

                        if (this.changes === 0) {
                            return res.status(404).json({
                                success: false,
                                error: '分店不存在',
                                message: '找不到指定的分店'
                            });
                        }

                        // 創建審計日誌
                        authMiddleware.createAuditLog(
                            req.employee.id,
                            'store_update',
                            `更新分店: ${store_name || existingStore.store_name} (${store_code || existingStore.store_code})`,
                            req.ip || req.connection.remoteAddress
                        );

                        // 獲取更新後的分店信息
                        db.get(
                            `SELECT * FROM stores WHERE id = ?`,
                            [id],
                            (selectErr, updatedStore) => {
                                if (selectErr) {
                                    console.error('獲取更新後分店錯誤:', selectErr);
                                }

                                res.json({
                                    success: true,
                                    message: '分店更新成功',
                                    data: {
                                        store: updatedStore || {
                                            id,
                                            store_code: store_code || existingStore.store_code,
                                            store_name: store_name || existingStore.store_name,
                                            address: address !== undefined ? address : existingStore.address,
                                            phone: phone !== undefined ? phone : existingStore.phone,
                                            timezone: timezone || existingStore.timezone,
                                            is_active: is_active !== undefined ? (is_active ? 1 : 0) : existingStore.is_active,
                                            created_at: existingStore.created_at,
                                            updated_at: new Date().toISOString()
                                        }
                                    }
                                });
                            }
                        );
                    });
                });
            }
        );
    } catch (error) {
        console.error('更新分店錯誤:', error);
        res.status(500).json({
            success: false,
            error: '更新分店失敗',
            message: error.message
        });
    }
});

/**
 * @route DELETE /api/stores/:id
 * @desc 刪除分店（僅總部管理員）
 * @access Private/Admin
 */
router.delete('/:id', authMiddleware.authenticate, (req, res) => {
    try {
        const { id } = req.params;
        const employeeRole = req.employee?.role;
        const employeeStoreId = req.employee?.store_id;

        // 只有總部管理員可以刪除分店
        if (employeeRole !== 'admin' || employeeStoreId !== null) {
            return res.status(403).json({
                success: false,
                error: '權限不足',
                message: '只有總部管理員可以刪除分店'
            });
        }

        // 不能刪除默認分店
        if (id === 'default_store') {
            return res.status(400).json({
                success: false,
                error: '不能刪除默認分店',
                message: '默認分店是系統必需的分店，不能刪除'
            });
        }

        // 檢查分店是否存在
        db.get(
            `SELECT id, store_code, store_name FROM stores WHERE id = ?`,
            [id],
            (checkErr, existingStore) => {
                if (checkErr) {
                    console.error('檢查分店錯誤:', checkErr);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: checkErr.message
                    });
                }

                if (!existingStore) {
                    return res.status(404).json({
                        success: false,
                        error: '分店不存在',
                        message: '指定的分店不存在'
                    });
                }

                // 檢查分店是否有關聯數據
                db.get(
                    `SELECT COUNT(*) as count FROM employees WHERE store_id = ?`,
                    [id],
                    (empErr, empCount) => {
                        if (empErr) {
                            console.error('檢查分店員工錯誤:', empErr);
                            return res.status(500).json({
                                success: false,
                                error: '服務器錯誤',
                                message: empErr.message
                            });
                        }

                        // 如果分店有關聯員工，不能直接刪除，只能停用
                        if (empCount.count > 0) {
                            return res.status(400).json({
                                success: false,
                                error: '分店有關聯數據',
                                message: '分店有關聯員工，請先轉移或刪除員工後再刪除分店'
                            });
                        }

                        // 刪除分店
                        db.run(
                            `DELETE FROM stores WHERE id = ?`,
                            [id],
                            function(deleteErr) {
                                if (deleteErr) {
                                    console.error('刪除分店錯誤:', deleteErr);
                                    return res.status(500).json({
                                        success: false,
                                        error: '服務器錯誤',
                                        message: deleteErr.message
                                    });
                                }

                                // 創建審計日誌
                                authMiddleware.createAuditLog(
                                    req.employee.id,
                                    'store_delete',
                                    `刪除分店: ${existingStore.store_name} (${existingStore.store_code})`,
                                    req.ip || req.connection.remoteAddress
                                );

                                res.json({
                                    success: true,
                                    message: '分店刪除成功',
                                    data: {
                                        deleted: true
                                    }
                                });
                            }
                        );
                    }
                );
            }
        );
    } catch (error) {
        console.error('刪除分店錯誤:', error);
        res.status(500).json({
            success: false,
            error: '刪除分店失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/stores/:id/stats
 * @desc 獲取分店統計信息
 * @access Private/Admin
 */
router.get('/:id/stats', authMiddleware.authenticate, (req, res) => {
    try {
        const { id } = req.params;
        const employeeRole = req.employee?.role;
        const employeeStoreId = req.employee?.store_id;

        // 檢查權限
        if (employeeRole !== 'admin') {
            return res.status(403).json({
                success: false,
                error: '權限不足',
                message: '只有管理員可以查看分店統計'
            });
        }

        // 分店管理員只能查看自己分店的統計
        if (employeeStoreId && employeeStoreId !== id) {
            return res.status(403).json({
                success: false,
                error: '權限不足',
                message: '您只能查看自己分店的統計'
            });
        }

        // 獲取分店基本信息
        db.get(
            `SELECT id, store_code, store_name, is_active, created_at FROM stores WHERE id = ?`,
            [id],
            (storeErr, store) => {
                if (storeErr) {
                    console.error('查詢分店錯誤:', storeErr);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: storeErr.message
                    });
                }

                if (!store) {
                    return res.status(404).json({
                        success: false,
                        error: '分店不存在',
                        message: '指定的分店不存在'
                    });
                }

                // 獲取員工統計
                db.get(
                    `SELECT
                        COUNT(*) as total_employees,
                        SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) as admin_count,
                        SUM(CASE WHEN role = 'staff' THEN 1 ELSE 0 END) as staff_count,
                        SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active_employees
                     FROM employees WHERE store_id = ?`,
                    [id],
                    (empErr, employeeStats) => {
                        if (empErr) {
                            console.error('查詢員工統計錯誤:', empErr);
                            // 繼續其他查詢
                        }

                        // 獲取商品統計
                        db.get(
                            `SELECT
                                COUNT(*) as total_products,
                                SUM(CASE WHEN is_available = 1 THEN 1 ELSE 0 END) as available_products,
                                SUM(CASE WHEN stock = 0 THEN 1 ELSE 0 END) as out_of_stock,
                                SUM(CASE WHEN stock > 0 AND stock <= min_stock THEN 1 ELSE 0 END) as low_stock,
                                SUM(stock * price) as estimated_value
                             FROM products WHERE store_id = ?`,
                            [id],
                            (prodErr, productStats) => {
                                if (prodErr) {
                                    console.error('查詢商品統計錯誤:', prodErr);
                                }

                                // 獲取今日客人統計
                                const today = new Date().toISOString().split('T')[0];
                                db.get(
                                    `SELECT
                                        COUNT(*) as today_customers,
                                        SUM(CASE WHEN is_checked_out = 1 THEN 1 ELSE 0 END) as today_checkouts,
                                        SUM(CASE WHEN is_checked_out = 1 THEN total_amount ELSE 0 END) as today_revenue
                                     FROM customers
                                     WHERE DATE(entry_time) = ? AND store_id = ?`,
                                    [today, id],
                                    (custErr, customerStats) => {
                                        if (custErr) {
                                            console.error('查詢客人統計錯誤:', custErr);
                                        }

                                        res.json({
                                            success: true,
                                            data: {
                                                store,
                                                statistics: {
                                                    employees: employeeStats || {},
                                                    products: productStats || {},
                                                    customers: customerStats || {},
                                                    timestamp: new Date().toISOString()
                                                }
                                            }
                                        });
                                    }
                                );
                            }
                        );
                    }
                );
            }
        );
    } catch (error) {
        console.error('獲取分店統計錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取分店統計失敗',
            message: error.message
        });
    }
});

module.exports = router;