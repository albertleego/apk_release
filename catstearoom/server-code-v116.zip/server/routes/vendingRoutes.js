const express = require('express');
const router = express.Router();
const storeAwareMiddleware = require('../middleware/store-aware');
const { getCustomerByQRCode, getAvailableLockers } = require('../../database/db');

// 為所有路由添加分店上下文中間件
router.use(storeAwareMiddleware.initStoreContext);

// QR Code掃描驗證
router.post('/scan', async (req, res) => {
  try {
    const { qr_code } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';

    if (!qr_code) {
      return res.status(400).json({ error: '請提供QR Code' });
    }

    // 解析QR Code數據（可能是JSON字符串或直接編碼）
    let qrData;
    try {
      qrData = JSON.parse(qr_code);
    } catch (e) {
      // 如果不是JSON，直接使用字符串作為QR Code值
      qrData = { qr_code: qr_code };
    }

    const qrCodeValue = qrData.qr_code || qr_code;

    // 查找客人（分店過濾）
    const customer = await getCustomerByQRCode(qrCodeValue, storeId);

    if (!customer) {
      return res.status(404).json({
        error: 'QR Code無效或客人已結賬',
        valid: false
      });
    }

    // 檢查客人是否已結賬
    if (customer.is_checked_out) {
      return res.status(400).json({
        error: '客人已結賬，無法購買商品',
        valid: false,
        checked_out: true
      });
    }

    // 獲取商品列表（分店過濾）
    const db = require('../../database/db').db;
    const products = await new Promise((resolve, reject) => {
      db.all(
        `SELECT * FROM products WHERE is_available = 1 AND (stock > 0 OR track_inventory = 0) AND store_id = ? ORDER BY name`,
        [storeId],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });

    res.json({
      success: true,
      valid: true,
      customer: {
        id: customer.id,
        table_number: customer.table_number,
        people_count: customer.people_count,
        total_amount: customer.total_amount,
        qr_code: customer.qr_code
      },
      products: products,
      message: 'QR Code驗證成功，可以開始購物'
    });

  } catch (error) {
    console.error('QR Code掃描錯誤:', error);
    res.status(500).json({
      error: 'QR Code掃描失敗',
      message: error.message
    });
  }
});

// 購買商品
router.post('/purchase', async (req, res) => {
  try {
    const { customer_id, product_id, quantity } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';

    if (!customer_id || !product_id || !quantity) {
      return res.status(400).json({ error: '請提供客人ID、商品ID和數量' });
    }

    if (quantity <= 0) {
      return res.status(400).json({ error: '數量必須大於0' });
    }

    // 檢查客人是否存在且未結賬（分店過濾）
    const customer = await new Promise((resolve, reject) => {
      const db = require('../../database/db').db;
      db.get(
        `SELECT * FROM customers WHERE id = ? AND is_checked_out = 0 AND store_id = ?`,
        [customer_id, storeId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!customer) {
      return res.status(404).json({ error: '客人不存在或已結賬' });
    }

    // 檢查商品庫存（分店過濾）
    const product = await new Promise((resolve, reject) => {
      const db = require('../../database/db').db;
      db.get(
        `SELECT * FROM products WHERE id = ? AND is_available = 1 AND store_id = ?`,
        [product_id, storeId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!product) {
      return res.status(404).json({ error: '商品不存在或已下架' });
    }

    // 檢查商品庫存（僅當 track_inventory = 1 時）
    if (product.track_inventory === 1 && product.stock < quantity) {
      return res.status(400).json({ error: '商品庫存不足' });
    }

    // 添加訂單項目
    const dbOps = require('../../database/db');
    const orderId = await dbOps.addOrderItem(customer_id, product_id, quantity, product.price);

    // 觸發設備開啟儲物柜
    const io = req.app.get('io');
    io.emit('device-control', {
      device: 'vending-locker',
      action: 'open',
      locker_number: product.locker_number,
      product_id: product_id,
      product_name: product.name,
      customer_id: customer_id
    });

    // 更新客戶端顯示
    io.emit('vending-purchase', {
      customer_id: customer_id,
      table_number: customer.table_number,
      product_name: product.name,
      quantity: quantity,
      price: product.price,
      locker_number: product.locker_number,
      order_id: orderId
    });

    res.json({
      success: true,
      message: '購買成功',
      order_id: orderId,
      product_name: product.name,
      quantity: quantity,
      price: product.price,
      total: product.price * quantity,
      locker_number: product.locker_number,
      customer: {
        table_number: customer.table_number,
        new_total: customer.total_amount + (product.price * quantity)
      }
    });

  } catch (error) {
    console.error('購買商品錯誤:', error);
    res.status(500).json({
      error: '購買商品失敗',
      message: error.message
    });
  }
});

// 獲取客人當前的購買記錄
router.get('/customer/:id/orders', async (req, res) => {
  try {
    const { id } = req.params;
    const storeId = req.storeContext?.store_id || 'default_store';

    const db = require('../../database/db').db;

    // 首先檢查客人是否存在且屬於當前分店
    const customer = await new Promise((resolve, reject) => {
      db.get(
        `SELECT id FROM customers WHERE id = ? AND store_id = ?`,
        [id, storeId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!customer) {
      return res.status(404).json({ error: '客人不存在或無權訪問' });
    }

    const orders = await new Promise((resolve, reject) => {
      db.all(
        `SELECT oi.*, p.name as product_name, p.description as product_description
         FROM order_items oi
         LEFT JOIN products p ON oi.product_id = p.id
         WHERE oi.customer_id = ?
         ORDER BY oi.purchased_at ASC`,
        [id],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });

    res.json({
      success: true,
      customer_id: id,
      orders: orders,
      total_items: orders.reduce((sum, item) => sum + item.quantity, 0),
      total_amount: orders.reduce((sum, item) => sum + (item.quantity * item.price_at_time), 0)
    });

  } catch (error) {
    console.error('獲取購買記錄錯誤:', error);
    res.status(500).json({
      error: '獲取購買記錄失敗',
      message: error.message
    });
  }
});

// 模擬設備狀態
router.get('/device-status', (req, res) => {
  res.json({
    success: true,
    device: 'vending-machine',
    status: 'online',
    lockers: Array.from({ length: 20 }, (_, i) => ({
      locker_number: i + 1,
      status: 'ready',
      product: i < 8 ? `商品${i + 1}` : null
    })),
    last_updated: new Date().toISOString()
  });
});

// 手動觸發儲物柜開啟（測試用）
router.post('/test-open-locker', (req, res) => {
  try {
    const { locker_number } = req.body;

    if (!locker_number) {
      return res.status(400).json({ error: '請提供儲物柜編號' });
    }

    const io = req.app.get('io');
    io.emit('device-control', {
      device: 'vending-locker',
      action: 'open',
      locker_number: locker_number,
      test_mode: true
    });

    res.json({
      success: true,
      message: `已發送開啟儲物柜 ${locker_number} 指令（測試模式）`
    });
  } catch (error) {
    console.error('測試開啟儲物柜錯誤:', error);
    res.status(500).json({
      error: '測試開啟儲物柜失敗',
      message: error.message
    });
  }
});

module.exports = router;