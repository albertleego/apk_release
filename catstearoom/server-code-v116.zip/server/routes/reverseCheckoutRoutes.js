/**
 * 反結賬路由
 *
 * POST /api/reverse-checkout/:customerId - 執行反結賬
 * GET  /api/store-employees             - 取得當前分店的員工名單
 */

const express = require('express');
const router = express.Router();
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');
const storeAwareMiddleware = require('../middleware/store-aware');
const { v4: uuidv4 } = require('uuid');

router.use(storeAwareMiddleware.initStoreContext);

/**
 * @route GET /api/store-employees
 * @desc 取得當前分店的員工名單 (來自 Google Sheet 同步)
 * @access Private
 */
router.get('/store-employees', authMiddleware.authenticate, (req, res) => {
  try {
    const storeContext = req.storeContext || {};
    const storeId = storeContext.store_id;
    const canAccessAllStores = storeContext.can_access_all_stores || false;

    let query, params;

    if (canAccessAllStores && req.query.store_id) {
      // 管理員可指定分店
      query = 'SELECT id, staff_name FROM store_checkout_staff WHERE store_id = ? ORDER BY staff_name';
      params = [req.query.store_id];
    } else if (storeId) {
      // 一般員工只看自己分店
      query = 'SELECT id, staff_name FROM store_checkout_staff WHERE store_id = ? ORDER BY staff_name';
      params = [storeId];
    } else {
      return res.json({ success: true, data: [] });
    }

    db.all(query, params, (err, rows) => {
      if (err) {
        console.error('查詢員工名單錯誤:', err);
        return res.status(500).json({ success: false, error: '查詢員工名單失敗' });
      }

      res.json({
        success: true,
        data: rows || []
      });
    });
  } catch (error) {
    console.error('取得員工名單錯誤:', error);
    res.status(500).json({ success: false, error: '取得員工名單失敗' });
  }
});

/**
 * @route POST /api/reverse-checkout/:customerId
 * @desc 執行反結賬
 *   - 將客人標記為已反結賬
 *   - 將所有訂單項目標記為已反結賬 (is_reversed = 1)
 *   - 將總金額設為 0, 人數設為 0
 *   - 記錄敏感操作日誌
 * @access Private
 */
router.post('/reverse-checkout/:customerId', authMiddleware.authenticate, (req, res) => {
  try {
    const { customerId } = req.params;
    const { reverseEmployeeName } = req.body;  // 從 Google Sheet 選取的員工姓名
    const employee = req.employee;
    const storeId = req.storeContext?.store_id || 'default_store';
    const ipAddress = req.ip || req.connection.remoteAddress;

    if (!reverseEmployeeName) {
      return res.status(400).json({
        success: false,
        error: '請選擇反結賬員工'
      });
    }

    // 先查詢客人資料，確認存在且已結賬
    db.get(
      `SELECT c.*, t.table_number as actual_table_number
       FROM customers c
       LEFT JOIN tables t ON c.table_number = t.table_number
       WHERE c.id = ? AND c.is_checked_out = 1`,
      [customerId],
      (err, customer) => {
        if (err) {
          console.error('查詢客人資料錯誤:', err);
          return res.status(500).json({ success: false, error: '查詢客人資料失敗' });
        }

        if (!customer) {
          return res.status(404).json({
            success: false,
            error: '找不到該結賬單據或尚未結賬'
          });
        }

        if (customer.is_reversed) {
          return res.status(400).json({
            success: false,
            error: '該單據已被反結賬'
          });
        }

        // 開始事務
        db.serialize(() => {
          db.run('BEGIN TRANSACTION');

          // 1. 取得所有 order_items（用於記錄詳情）
          db.all(
            `SELECT oi.*, p.name as product_name
             FROM order_items oi
             LEFT JOIN products p ON oi.product_id = p.id
             WHERE oi.customer_id = ?`,
            [customerId],
            (err, items) => {
              if (err) {
                console.error('查詢訂單項目錯誤:', err);
                db.run('ROLLBACK');
                return res.status(500).json({ success: false, error: '查詢訂單項目失敗' });
              }

              // 2. 更新 customers：標記為反結賬
              const reversedAt = new Date().toISOString();
              db.run(
                `UPDATE customers SET
                   is_reversed = 1,
                   reversed_by = ?,
                   reversed_at = ?,
                   reverse_employee_name = ?,
                   total_amount = 0,
                   people_count = 0,
                   cloud_uploaded = 0,
                   cloud_uploaded_at = NULL
                 WHERE id = ?`,
                [employee.id, reversedAt, reverseEmployeeName, customerId],
                function(err) {
                  if (err) {
                    console.error('更新客人反結賬狀態錯誤:', err);
                    db.run('ROLLBACK');
                    return res.status(500).json({ success: false, error: '更新反結賬狀態失敗' });
                  }

                  // 3. 更新所有 order_items 為已反結賬
                  db.run(
                    `UPDATE order_items SET is_reversed = 1 WHERE customer_id = ?`,
                    [customerId],
                    function(err) {
                      if (err) {
                        console.error('更新訂單項目反結賬狀態錯誤:', err);
                        db.run('ROLLBACK');
                        return res.status(500).json({ success: false, error: '更新訂單項目狀態失敗' });
                      }

                      // 4. 記錄敏感操作日誌
                      const logId = uuidv4();
                      const actionDetails = JSON.stringify({
                        operation: 'reverse_checkout',
                        customer_id: customerId,
                        table_number: customer.table_number,
                        original_total_amount: customer.total_amount,
                        original_people_count: customer.people_count,
                        reverse_employee_name: reverseEmployeeName,
                        reversed_at: reversedAt,
                        items: (items || []).map(item => ({
                          product_id: item.product_id,
                          product_name: item.product_name || '未知商品',
                          quantity: item.quantity,
                          price: item.price_at_time
                        }))
                      });

                      db.run(
                        `INSERT INTO audit_logs (id, employee_id, action_type, action_details, ip_address, store_id)
                         VALUES (?, ?, 'sensitive_reverse_checkout', ?, ?, ?)`,
                        [logId, employee.id, actionDetails, ipAddress, storeId],
                        function(err) {
                          if (err) {
                            console.error('記錄敏感操作日誌錯誤:', err);
                            // 不 rollback，繼續執行
                            console.error('敏感操作日誌記錄失敗，但不影響反結賬操作');
                          }

                          db.run('COMMIT', (err) => {
                            if (err) {
                              console.error('提交事務錯誤:', err);
                              return res.status(500).json({ success: false, error: '提交事務失敗' });
                            }

                            console.log(`[ReverseCheckout] 反結賬成功: customer=${customerId}, table=${customer.table_number}, by=${employee.full_name || employee.username}`);

                            res.json({
                              success: true,
                              data: {
                                customer_id: customerId,
                                table_number: customer.table_number,
                                original_total_amount: customer.total_amount,
                                reversed_at: reversedAt,
                                reverse_employee_name: reverseEmployeeName
                              },
                              message: '反結賬成功'
                            });
                          });
                        }
                      );
                    }
                  );
                }
              );
            }
          );
        });
      }
    );
  } catch (error) {
    console.error('反結賬錯誤:', error);
    res.status(500).json({ success: false, error: '反結賬失敗' });
  }
});

/**
 * @route POST /api/reverse-checkout/:customerId/partial
 * @desc 部份反結賬 — 只針對指定商品做反結賬（不影響其他商品和入座人數）
 *   - 將指定商品的 order_items 標記為已反結賬 (is_reversed = 1)
 *   - 重新計算客人總金額（扣除已反結賬商品金額）
 *   - 記錄敏感操作日誌
 * @access Private
 */
router.post('/reverse-checkout/:customerId/partial', authMiddleware.authenticate, (req, res) => {
  try {
    const { customerId } = req.params;
    const { reverseEmployeeName, productName } = req.body;
    const employee = req.employee;
    const storeId = req.storeContext?.store_id || 'default_store';
    const ipAddress = req.ip || req.connection.remoteAddress;

    if (!reverseEmployeeName) {
      return res.status(400).json({
        success: false,
        error: '請選擇反結賬員工'
      });
    }

    if (!productName) {
      return res.status(400).json({
        success: false,
        error: '請指定要反結賬的商品名稱'
      });
    }

    // 先查詢客人資料，確認存在且已結賬
    db.get(
      `SELECT c.*, t.table_number as actual_table_number
       FROM customers c
       LEFT JOIN tables t ON c.table_number = t.table_number
       WHERE c.id = ? AND c.is_checked_out = 1`,
      [customerId],
      (err, customer) => {
        if (err) {
          console.error('查詢客人資料錯誤:', err);
          return res.status(500).json({ success: false, error: '查詢客人資料失敗' });
        }

        if (!customer) {
          return res.status(404).json({
            success: false,
            error: '找不到該結賬單據或尚未結賬'
          });
        }

        // 開始事務
        db.serialize(() => {
          db.run('BEGIN TRANSACTION');

          // 1. 查詢該商品在 order_items 中的記錄（已結賬未反結賬的項目）
          db.all(
            `SELECT oi.id, oi.product_id, oi.quantity, oi.price_at_time, p.name as product_name
             FROM order_items oi
             JOIN products p ON oi.product_id = p.id
             WHERE oi.customer_id = ?
               AND p.name = ?
               AND COALESCE(oi.is_reversed, 0) = 0`,
            [customerId, productName],
            (err, items) => {
              if (err) {
                console.error('查詢訂單項目錯誤:', err);
                db.run('ROLLBACK');
                return res.status(500).json({ success: false, error: '查詢訂單項目失敗' });
              }

              if (!items || items.length === 0) {
                db.run('ROLLBACK');
                return res.status(404).json({
                  success: false,
                  error: `找不到商品「${productName}」的未反結賬記錄`
                });
              }

              // 計算反結賬總金額
              let reversedAmount = 0;
              let reversedQuantity = 0;
              const reversedItemIds = items.map(item => {
                const itemTotal = item.price_at_time * item.quantity;
                reversedAmount += itemTotal;
                reversedQuantity += item.quantity;
                return item.id;
              });

              // 2. 更新指定商品的 order_items 為已反結賬
              const placeholders = reversedItemIds.map(() => '?').join(',');
              db.run(
                `UPDATE order_items SET is_reversed = 1 WHERE id IN (${placeholders})`,
                reversedItemIds,
                function(err) {
                  if (err) {
                    console.error('更新訂單項目反結賬狀態錯誤:', err);
                    db.run('ROLLBACK');
                    return res.status(500).json({ success: false, error: '更新訂單項目狀態失敗' });
                  }

                  // 3. 重新計算客人的總金額（查詢剩餘未反結賬 order_items 的總和）
                  db.get(
                    `SELECT COALESCE(SUM(price_at_time * quantity), 0) as remaining_amount
                     FROM order_items
                     WHERE customer_id = ? AND COALESCE(is_reversed, 0) = 0`,
                    [customerId],
                    (err, row) => {
                      if (err) {
                        console.error('計算剩餘金額錯誤:', err);
                        db.run('ROLLBACK');
                        return res.status(500).json({ success: false, error: '計算剩餘金額失敗' });
                      }

                      const newTotalAmount = row ? row.remaining_amount : 0;

                      // 4. 更新客人的 total_amount
                      const reversedAt = new Date().toISOString();
                      db.run(
                        `UPDATE customers SET
                           total_amount = ?,
                           cloud_uploaded = 0,
                           cloud_uploaded_at = NULL
                         WHERE id = ?`,
                        [newTotalAmount, customerId],
                        function(err) {
                          if (err) {
                            console.error('更新客人總金額錯誤:', err);
                            db.run('ROLLBACK');
                            return res.status(500).json({ success: false, error: '更新客人總金額失敗' });
                          }

                          // 5. 記錄敏感操作日誌（與全單反結賬共用 sensitive_reverse_checkout 類型，透過 partial_reverse 標記區分）
                          const logId = uuidv4();
                          const actionDetails = JSON.stringify({
                            operation: 'partial_reverse_checkout',
                            partial_reverse: true,
                            customer_id: customerId,
                            table_number: customer.table_number,
                            product_name: productName,
                            reversed_quantity: reversedQuantity,
                            reversed_amount: reversedAmount,
                            new_total_amount: newTotalAmount,
                            original_total_amount: customer.total_amount,
                            original_people_count: customer.people_count,
                            reverse_employee_name: reverseEmployeeName,
                            reversed_at: reversedAt,
                            items: items.map(item => ({
                              order_item_id: item.id,
                              product_id: item.product_id,
                              product_name: item.product_name,
                              quantity: item.quantity,
                              price: item.price_at_time
                            }))
                          });

                          db.run(
                            `INSERT INTO audit_logs (id, employee_id, action_type, action_details, ip_address, store_id)
                             VALUES (?, ?, 'sensitive_reverse_checkout', ?, ?, ?)`,
                            [logId, employee.id, actionDetails, ipAddress, storeId],
                            function(err) {
                              if (err) {
                                console.error('記錄敏感操作日誌錯誤:', err);
                              }

                              db.run('COMMIT', (err) => {
                                if (err) {
                                  console.error('提交事務錯誤:', err);
                                  return res.status(500).json({ success: false, error: '提交事務失敗' });
                                }

                                console.log(`[PartialReverseCheckout] 部份反結賬成功: customer=${customerId}, table=${customer.table_number}, product=${productName}, qty=${reversedQuantity}, amount=${reversedAmount}, by=${employee.full_name || employee.username}`);

                                res.json({
                                  success: true,
                                  data: {
                                    customer_id: customerId,
                                    table_number: customer.table_number,
                                    product_name: productName,
                                    reversed_quantity: reversedQuantity,
                                    reversed_amount: reversedAmount,
                                    new_total_amount: newTotalAmount,
                                    original_total_amount: customer.total_amount,
                                    reversed_at: reversedAt,
                                    reverse_employee_name: reverseEmployeeName
                                  },
                                  message: `商品「${productName}」反結賬成功`
                                });
                              });
                            }
                          );
                        }
                      );
                    }
                  );
                }
              );
            }
          );
        });
      }
    );
  } catch (error) {
    console.error('部份反結賬錯誤:', error);
    res.status(500).json({ success: false, error: '部份反結賬失敗' });
  }
});

module.exports = router;
