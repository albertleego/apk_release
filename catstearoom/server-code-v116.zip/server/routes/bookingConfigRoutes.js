/**
 * Booking Config API Route
 * GET  /api/booking-config  — 公開：回傳包場報價設定
 * POST /api/booking-config  — 需管理員登入 token（role=admin）或 API Key：儲存設定到 SQLite
 */
const express = require('express');
const router = express.Router();
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');

// ============================================================
//  初始化 table（首次載入時自動建立）
// ============================================================
db.run(`CREATE TABLE IF NOT EXISTS booking_config (
    id INTEGER PRIMARY KEY DEFAULT 1,
    config TEXT NOT NULL DEFAULT '{}',
    updated_at TEXT
)`, (err) => {
    if (err) console.error('❌ booking_config table 建立失敗:', err.message);
    else console.log('✅ booking_config table ready');
});

// ============================================================
//  GET / — 回傳設定（公開，無需 auth）
// ============================================================
router.get('/', (req, res) => {
    db.get(`SELECT config, updated_at FROM booking_config WHERE id = 1`, (err, row) => {
        if (err) {
            return res.status(500).json({ success: false, error: err.message });
        }
        if (row) {
            try {
                const config = JSON.parse(row.config);
                return res.json({
                    success: true,
                    data: config,
                    updated_at: row.updated_at
                });
            } catch (e) {
                return res.json({
                    success: true,
                    data: {},
                    updated_at: null
                });
            }
        }
        // 未有設定 → 回傳空物件，由前端用預設值補齊
        return res.json({
            success: true,
            data: {},
            updated_at: null
        });
    });
});

// ============================================================
//  GET /food-prices — 公開：回傳「預訂食物」9 款食物價格
//  來源係收銀系統 products 表（改名/改價即自動反映）
// ============================================================
const FOOD_PREORDER_NAMES = [
    '藍莓芝士蛋糕', '朱古力松露蛋糕', '巴斯克芝士蛋糕',
    '芝士火腿三文治', '雞蛋火腿三文治', '芝士蛋三文治',
    '牛油曲奇 (3塊)', '朱古力曲奇 (3塊)', '抹茶合桃曲奇 (3塊)'
];

router.get('/food-prices', (req, res) => {
    const placeholders = FOOD_PREORDER_NAMES.map(() => '?').join(',');
    db.all(
        `SELECT name, MAX(price) AS price FROM products
         WHERE is_available = 1 AND name IN (${placeholders})
         GROUP BY name`,
        FOOD_PREORDER_NAMES,
        (err, rows) => {
            if (err) {
                return res.status(500).json({ success: false, error: err.message });
            }
            const prices = {};
            (rows || []).forEach(r => { prices[r.name] = r.price; });
            res.json({ success: true, prices });
        }
    );
});

// ============================================================
//  POST / — 儲存設定（管理員登入 token 或 API Key）
// ============================================================
function saveBookingConfig(req, res) {
    try {
        const config = req.body;

        if (!config || typeof config !== 'object' || Array.isArray(config)) {
            return res.status(400).json({
                success: false,
                error: '請求 body 必須係一個 JSON object'
            });
        }

        const configStr = JSON.stringify(config);
        const now = new Date().toISOString();

        db.run(
            `INSERT OR REPLACE INTO booking_config (id, config, updated_at) VALUES (1, ?, ?)`,
            [configStr, now],
            function(err) {
                if (err) {
                    console.error('❌ 儲存 booking config 失敗:', err.message);
                    return res.status(500).json({ success: false, error: err.message });
                }
                console.log('✅ booking config 已儲存');
                return res.json({
                    success: true,
                    message: '設定已儲存',
                    updated_at: now
                });
            }
        );
    } catch (error) {
        console.error('❌ 儲存 booking config 異常:', error.message);
        return res.status(500).json({ success: false, error: error.message });
    }
}

router.post('/', (req, res) => {
    // 方式 1：有效 API Key（向後兼容，例如 script / 第三方工具）
    const apiKey = req.headers['x-api-key'] || req.headers['X-API-Key'];
    const validKey = process.env.ALIYUN_API_KEY || process.env.API_KEY;
    if (apiKey && validKey && apiKey === validKey) {
        return saveBookingConfig(req, res);
    }
    // 方式 2：管理員員工登入 token（officer 係 role=staff，會被 requireAdmin 拒絕 → 403）
    authMiddleware.authenticate(req, res, () => {
        authMiddleware.requireAdmin(req, res, () => {
            saveBookingConfig(req, res);
        });
    });
});

module.exports = router;
