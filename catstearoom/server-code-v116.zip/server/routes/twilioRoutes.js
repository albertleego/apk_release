const express = require('express');
const router = express.Router();
const { db } = require('../../database/db');

/**
 * @route GET /api/twilio/respond
 * @desc 用戶 Click WhatsApp URL Button → 直接更新 DB status
 * @access Public
 * URL: /api/twilio/respond?action=confirm&id=xxx&lang=zh-TW
 *       /api/twilio/respond?action=cancel&id=xxx&lang=zh-TW
 */
router.get('/respond', (req, res) => {
    const action = req.query.action || '';
    const waitinglistId = req.query.id || '';

    const targetStatus = action === 'cancel' ? 'cancelled' : 'confirmed';
    const isConfirm = targetStatus === 'confirmed';
    var lang = req.query.lang || 'zh-TW';
    if (['zh-TW','zh-CN','en'].indexOf(lang) < 0) lang = 'zh-TW';

    const STORE_PHONES = {
        'store_1': '53635287',
        'store_2': '55884627',
        'store_3': '54450336',
        'store_4': '84028472'
    };
    const STORE_NAMES = { 'store_1': '荃灣店', 'store_2': '尖沙咀店', 'store_3': '旺角店', 'store_4': '銅鑼灣店' };
    const STORE_NAMES_EN = { 'store_1': 'Tsuen Wan', 'store_2': 'Tsim Sha Tsui', 'store_3': 'Mong Kok', 'store_4': 'Causeway Bay' };

    // 語言文字
    var T = {};
    T['zh-TW'] = { htmlLang:'zh-TW', title:' - Auto Cafe',
        confirmTitle:'已確認留位！',
        confirmMsg:function(p){return '座位保留10分鐘<br><br>如未能於10分鐘內到店，請致電<br><a class="tel" href="tel:+852'+p+'">'+p+'</a>';},
        cancelTitle:'已取消留位',
        cancelMsg:'我哋已經收到你嘅取消。<br>下次有機會再為你服務！😊',
        invalidLink:'連結無效',
        invalidMsg:'請確保使用完整嘅連結',
        sysError:'系統錯誤',
        sysMsg:'請稍後再試',
        notFoundTitle:isConfirm?'未能確認留位':'未能取消留位',
        notFoundMsg:'找不到對應嘅候位記錄，可能已經處理過。<br>如有疑問請致電店舖查詢。',
        updateFail:'更新失敗',
        updateMsg:'請稍後再試',
        backHome:'返回首頁',
        alreadySeatedTitle:'已入座',
        alreadySeatedMsg:'客人已經入座，無需再操作。<br>如有疑問請致電店舖查詢。' };
    T['zh-CN'] = { htmlLang:'zh-CN', title:' - Auto Cafe',
        confirmTitle:'已确认留位！',
        confirmMsg:function(p){return '座位保留10分钟<br><br>如未能于10分钟内到店，请致电<br><a class="tel" href="tel:+852'+p+'">'+p+'</a>';},
        cancelTitle:'已取消留位',
        cancelMsg:'我们已经收到你的取消。<br>下次有机会再为你服务！😊',
        invalidLink:'链接无效',
        invalidMsg:'请确保使用完整的链接',
        sysError:'系统错误',
        sysMsg:'请稍后再试',
        notFoundTitle:isConfirm?'未能确认留位':'未能取消留位',
        notFoundMsg:'找不到对应的候位记录，可能已经处理过。<br>如有疑问请致电店铺查询。',
        updateFail:'更新失败',
        updateMsg:'请稍后再试',
        backHome:'返回首页',
        alreadySeatedTitle:'已入座',
        alreadySeatedMsg:'客人已经入座，无需再操作。<br>如有疑问请致电店铺查询。' };
    T['en'] = { htmlLang:'en', title:' - Auto Cafe',
        confirmTitle:'Seat Confirmed!',
        confirmMsg:function(p){return 'Seat reserved for 10 minutes.<br><br>If you cannot arrive in time, please call<br><a class="tel" href="tel:+852'+p+'">'+p+'</a>';},
        cancelTitle:'Queue Cancelled',
        cancelMsg:'We have received your cancellation.<br>Hope to serve you again next time! 😊',
        invalidLink:'Invalid Link',
        invalidMsg:'Please use a valid link',
        sysError:'System Error',
        sysMsg:'Please try again later',
        notFoundTitle:isConfirm?'Confirmation Failed':'Cancellation Failed',
        notFoundMsg:'Could not find the queue record. It may have already been processed.<br>Please call the store for assistance.',
        updateFail:'Update Failed',
        updateMsg:'Please try again later',
        backHome:'Back to Home',
        alreadySeatedTitle:'Already Seated',
        alreadySeatedMsg:'The guest has already been seated.<br>No further action is needed.<br>Please call the store for assistance.' };
    function t(key) { var d = T[lang] || T['zh-TW']; return d[key]; }

    function sendPage(title, message, icon) {
        var htmlLang = T[lang] ? T[lang].htmlLang : 'zh-TW';
        var backBtn = t('backHome');
        res.send(`<!DOCTYPE html>
<html lang="${htmlLang}">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>${title}${t('title')}</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:-apple-system,'Noto Sans TC','Noto Sans SC',sans-serif;background:#f5f5f5;display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px;}
.card{background:white;border-radius:16px;box-shadow:0 2px 12px rgba(0,0,0,.1);padding:40px 30px;text-align:center;max-width:420px;width:100%;}
.icon{font-size:64px;margin-bottom:16px;}
h1{font-size:24px;color:#333;margin-bottom:8px;}
p{font-size:17px;color:#888;margin-bottom:6px;line-height:1.6;}
a.tel{display:inline-block;margin:10px 0;padding:10px 24px;background:#E8F5E9;color:#2E7D32;border-radius:10px;font-size:22px;font-weight:700;text-decoration:none;border:2px solid #A5D6A7;}
.btn{display:inline-block;margin-top:16px;padding:12px 32px;border:none;border-radius:10px;background:#8B4513;color:white;font-size:18px;font-weight:600;cursor:pointer;text-decoration:none;}
</style>
</head>
<body>
<div class="card">
<div class="icon">${icon}</div>
<h1>${title}</h1>
<p>${message}</p>
<a class="btn" href="/booking/">${backBtn}</a>
</div>
</body>
</html>`);
    }

    function showConfirmPage(storeId) {
        const storePhone = STORE_PHONES[storeId] || '53635287';
        sendPage(t('confirmTitle'), t('confirmMsg')(storePhone), '✅');
    }

    function showCancelPage() {
        sendPage(t('cancelTitle'), t('cancelMsg'), '✅');
    }

    if (!waitinglistId) {
        return sendPage(t('invalidLink'), t('invalidMsg'), '❌');
    }

    db.get(`SELECT id, store_id, status FROM waitinglist WHERE id = ?`, [waitinglistId], (err, item) => {
        if (err) {
            console.error('twilio/respond DB 錯誤:', err.message);
            return sendPage(t('sysError'), t('sysMsg'), '⚠️');
        }
        if (!item) {
            console.log(`twilio/respond: 找不到 id ${waitinglistId} 的候位記錄`);
            return sendPage(t('notFoundTitle'), t('notFoundMsg'), '🔍');
        }

        if (item.status === 'arrived') {
            console.log(`twilio/respond: 候位 ${item.id} 已入座，跳過 ${targetStatus} 操作`);
            return sendPage(t('alreadySeatedTitle'), t('alreadySeatedMsg'), '💺');
        }

        const nowHK = new Date(Date.now() + 8*60*60*1000).toISOString().replace('Z', '');
        db.run(
            `UPDATE waitinglist SET status = ?, updated_at = ? WHERE id = ?`,
            [targetStatus, nowHK, item.id],
            function(updateErr) {
                if (updateErr) {
                    console.error('twilio/respond 更新錯誤:', updateErr.message);
                    return sendPage(t('updateFail'), t('updateMsg'), '⚠️');
                }

                console.log(`twilio/respond: 候位 ${item.id} (${item.store_id}) → ${targetStatus} (lang=${lang})`);

                if (targetStatus === 'confirmed') {
                    showConfirmPage(item.store_id);
                } else {
                    showCancelPage();
                }
            }
        );
    });
});

/**
 * @route POST /api/twilio/whatsapp-callback
 * @desc 接收 WhatsApp 按鈕回調（備用 webhook 方式）
 * @access Public (Twilio webhook)
 */
router.post('/whatsapp-callback', (req, res) => {
    try {
        const from = req.body.From || '';
        const buttonResult = req.body.ButtonResult || '';
        const body = (req.body.Body || '').toLowerCase();

        console.log(`Twilio webhook: From=${from}, ButtonResult=${buttonResult}, Body=${body}`);

        const phone = from.replace('whatsapp:', '').replace('+', '').replace(/[^0-9]/g, '');
        const phoneWithPrefix = '+' + phone;

        if (!phone) {
            return res.status(200).send('<Response></Response>');
        }

        let targetStatus = null;
        if (buttonResult === 'Confirm' || body.includes('confirm')) targetStatus = 'confirmed';
        else if (buttonResult === 'Cancel' || body.includes('cancel')) targetStatus = 'cancelled';

        if (!targetStatus) {
            return res.status(200).send('<Response></Response>');
        }

        const todayHK = new Date(Date.now() + 8*60*60*1000).toISOString().slice(0,10);
        const query = `SELECT id, store_id, status FROM waitinglist
            WHERE (phone = ? OR phone = ?)
            AND status IN ('waiting', 'contacted', 'confirmed')
            AND created_at LIKE ?
            ORDER BY created_at DESC LIMIT 1`;

        db.get(query, [phoneWithPrefix, phone, todayHK + '%'], (err, item) => {
            if (err || !item) {
                return res.status(200).send('<Response></Response>');
            }
            const nowHK = new Date(Date.now() + 8*60*60*1000).toISOString().replace('Z', '');
            db.run(`UPDATE waitinglist SET status = ?, updated_at = ? WHERE id = ?`,
                [targetStatus, nowHK, item.id]);
        });

        res.status(200).send('<Response></Response>');
    } catch (error) {
        console.error('Twilio webhook 錯誤:', error);
        res.status(200).send('<Response></Response>');
    }
});

module.exports = router;
