/**
 * 數據同步衝突解決器
 * 處理當同一個記錄在本地和遠程都被修改時的衝突
 */
class ConflictResolver {
    constructor(config = {}) {
        this.config = {
            defaultStrategy: 'last_write_wins',
            ...config
        };

        // 註冊的策略處理器
        this.strategies = {
            'last_write_wins': this.resolveLastWriteWins.bind(this),
            'client_wins': this.resolveClientWins.bind(this),
            'server_wins': this.resolveServerWins.bind(this),
            'merge': this.resolveMerge.bind(this),
            'custom': null // 自定義策略
        };

        // 表特定的衝突解決策略
        this.tableStrategies = {};

        console.log('ConflictResolver 初始化完成');
    }

    /**
     * 設置表特定的衝突解決策略
     */
    setTableStrategy(tableName, strategy) {
        this.tableStrategies[tableName] = strategy;
        console.log(`設置表 ${tableName} 的衝突解決策略: ${strategy}`);
        return this;
    }

    /**
     * 設置自定義策略處理器
     */
    setCustomResolver(resolverFunction) {
        this.strategies.custom = resolverFunction;
        return this;
    }

    /**
     * 解決衝突
     * @param {Object} localRecord 本地記錄
     * @param {Object} remoteRecord 遠程記錄
     * @param {Object} context 上下文信息
     * @returns {Object} 解決後的記錄
     */
    async resolve(localRecord, remoteRecord, context = {}) {
        const { tableName, operation = 'update' } = context;

        // 確定使用的策略
        const strategy = this.getStrategyForTable(tableName);

        console.log(`解決衝突: 表=${tableName}, 策略=${strategy}, 操作=${operation}`);

        // 如果本地記錄不存在，直接使用遠程記錄（反之亦然）
        if (!localRecord && remoteRecord) {
            console.log('本地記錄不存在，使用遠程記錄');
            return { ...remoteRecord, _conflict_resolved: 'remote_only' };
        }

        if (localRecord && !remoteRecord) {
            console.log('遠程記錄不存在，使用本地記錄');
            return { ...localRecord, _conflict_resolved: 'local_only' };
        }

        // 調用對應的策略處理器
        const resolver = this.strategies[strategy];
        if (!resolver) {
            throw new Error(`未知的衝突解決策略: ${strategy}`);
        }

        const resolved = await resolver(localRecord, remoteRecord, context);

        // 添加衝突解決標記
        return {
            ...resolved,
            _conflict_resolved: true,
            _conflict_strategy: strategy,
            _conflict_timestamp: new Date().toISOString()
        };
    }

    /**
     * 獲取表特定的策略
     */
    getStrategyForTable(tableName) {
        if (this.tableStrategies[tableName]) {
            return this.tableStrategies[tableName];
        }

        // 根據表名決定默認策略
        if (tableName === 'customers') {
            return 'client_wins'; // 客戶數據以本地為準
        } else if (tableName === 'products') {
            return 'server_wins'; // 商品信息以服務器為準
        } else if (tableName === 'order_items' || tableName === 'transactions') {
            return 'merge'; // 訂單和交易記錄合併
        }

        return this.config.defaultStrategy;
    }

    /**
     * 策略：最後寫入勝出（比較時間戳）
     */
    async resolveLastWriteWins(localRecord, remoteRecord, context) {
        const localTimestamp = this.getRecordTimestamp(localRecord, context);
        const remoteTimestamp = this.getRecordTimestamp(remoteRecord, context);

        console.log(`最後寫入勝出比較: 本地=${localTimestamp}, 遠程=${remoteTimestamp}`);

        if (localTimestamp >= remoteTimestamp) {
            console.log('本地記錄更新，使用本地記錄');
            return localRecord;
        } else {
            console.log('遠程記錄更新，使用遠程記錄');
            return remoteRecord;
        }
    }

    /**
     * 策略：客戶端勝出
     */
    async resolveClientWins(localRecord, remoteRecord, context) {
        console.log('客戶端勝出策略，使用本地記錄');
        return localRecord;
    }

    /**
     * 策略：服務器勝出
     */
    async resolveServerWins(localRecord, remoteRecord, context) {
        console.log('服務器勝出策略，使用遠程記錄');
        return remoteRecord;
    }

    /**
     * 策略：合併記錄
     */
    async resolveMerge(localRecord, remoteRecord, context) {
        console.log('合併策略，合併本地和遠程記錄');

        const { tableName } = context;

        // 根據表類型選擇合併策略
        switch (tableName) {
            case 'order_items':
                return this.mergeOrderItems(localRecord, remoteRecord);
            case 'transactions':
                return this.mergeTransactions(localRecord, remoteRecord);
            default:
                return this.mergeGeneric(localRecord, remoteRecord);
        }
    }

    /**
     * 合併訂單項目
     */
    mergeOrderItems(local, remote) {
        // 訂單項目通常不應該有衝突，如果有的話選擇數量更大的
        if (local.quantity !== remote.quantity) {
            return {
                ...local,
                quantity: Math.max(local.quantity, remote.quantity),
                _merged_from: ['local', 'remote']
            };
        }

        // 其他字段以本地為準
        return local;
    }

    /**
     * 合併交易記錄
     */
    mergeTransactions(local, remote) {
        // 交易記錄不應該有衝突，如果有的話創建新記錄
        // 返回兩個記錄的數組？這裡簡化處理，以本地為準
        console.warn('交易記錄衝突，創建新記錄處理');
        return {
            ...local,
            _conflict_note: '交易衝突，已創建新記錄',
            _original_local: local.id,
            _original_remote: remote.id
        };
    }

    /**
     * 通用合併
     */
    mergeGeneric(local, remote) {
        const merged = { ...remote };

        // 合併策略：優先使用非空值
        Object.keys(local).forEach(key => {
            if (local[key] !== null && local[key] !== undefined && local[key] !== '') {
                if (remote[key] === null || remote[key] === undefined || remote[key] === '') {
                    merged[key] = local[key];
                } else if (typeof local[key] === 'number' && typeof remote[key] === 'number') {
                    // 數值類型：取平均值（根據需求調整）
                    merged[key] = (local[key] + remote[key]) / 2;
                } else if (key.endsWith('_at') || key === 'timestamp' || key === 'updated_at') {
                    // 時間戳：取最新的
                    const localTime = new Date(local[key]).getTime();
                    const remoteTime = new Date(remote[key]).getTime();
                    merged[key] = localTime > remoteTime ? local[key] : remote[key];
                }
                // 其他情況保持遠程值
            }
        });

        merged._merged = true;
        merged._merged_fields = Object.keys(local).filter(key => local[key] !== remote[key]);

        return merged;
    }

    /**
     * 獲取記錄的時間戳
     */
    getRecordTimestamp(record, context) {
        const { tableName } = context;

        // 優先使用 updated_at
        if (record.updated_at) {
            return new Date(record.updated_at).getTime();
        }

        // 其次使用 created_at
        if (record.created_at) {
            return new Date(record.created_at).getTime();
        }

        // 特定表的時間戳字段
        if (tableName === 'customers' && record.checkout_time) {
            return new Date(record.checkout_time).getTime();
        }

        if (tableName === 'transactions' && record.created_at) {
            return new Date(record.created_at).getTime();
        }

        // 默認使用當前時間
        console.warn(`無法獲取記錄時間戳，使用當前時間，表=${tableName}, ID=${record.id}`);
        return Date.now();
    }

    /**
     * 檢測是否為衝突（記錄都修改過）
     */
    isConflict(localRecord, remoteRecord, context) {
        if (!localRecord || !remoteRecord) {
            return false; // 一個記錄不存在，不是衝突
        }

        const localTimestamp = this.getRecordTimestamp(localRecord, context);
        const remoteTimestamp = this.getRecordTimestamp(remoteRecord, context);

        // 如果兩個記錄的時間戳都大於最後同步時間，則認為有衝突
        const { lastSyncTime } = context;
        if (lastSyncTime) {
            const lastSyncTimestamp = new Date(lastSyncTime).getTime();
            return localTimestamp > lastSyncTimestamp && remoteTimestamp > lastSyncTimestamp;
        }

        // 如果時間戳不同，認為有衝突
        return localTimestamp !== remoteTimestamp;
    }

    /**
     * 批量解決衝突
     */
    async resolveBatch(conflicts, context) {
        console.log(`批量解決 ${conflicts.length} 個衝突`);

        const resolved = [];
        const errors = [];

        for (const conflict of conflicts) {
            try {
                const result = await this.resolve(
                    conflict.local,
                    conflict.remote,
                    { ...context, ...conflict.context }
                );
                resolved.push(result);
            } catch (error) {
                console.error(`解決衝突失敗:`, error);
                errors.push({
                    conflict,
                    error: error.message
                });
            }
        }

        return {
            resolved,
            errors,
            total: conflicts.length,
            success: errors.length === 0
        };
    }
}

module.exports = ConflictResolver;