/**
 * 語言支持模組 - Traditional Chinese (繁體中文)
 * 提供系統所有界面和訊息的多語言支持
 */

const LANGUAGES = {
  'zh-TW': {
    // 通用訊息
    'success': '成功',
    'error': '錯誤',
    'loading': '載入中...',
    'processing': '處理中...',
    'saving': '儲存中...',
    'please_wait': '請稍候...',

    // 按鈕標籤
    'submit': '提交',
    'cancel': '取消',
    'confirm': '確認',
    'save': '儲存',
    'delete': '刪除',
    'edit': '編輯',
    'view': '查看',
    'refresh': '刷新',
    'retry': '重試',
    'close': '關閉',
    'back': '返回',

    // 表單標籤
    'username': '用戶名',
    'password': '密碼',
    'email': '電子郵件',
    'phone': '電話',
    'address': '地址',
    'search': '搜尋',

    // 設備控制
    'device_printer': '小票打印機',
    'device_locker': '儲物柜系統',
    'device_audio': '音響系統',
    'device_nfc': 'NFC讀卡器',
    'device_door_lock': '門鎖系統',
    'device_vending': '商品售賣機',
    'device_cashier': '收銀系統',

    // 狀態訊息
    'status_online': '連線中',
    'status_offline': '離線',
    'status_ready': '就緒',
    'status_busy': '忙碌',
    'status_error': '錯誤',
    'status_warning': '警告',
    'status_maintenance': '維護中',

    // 入場機器
    'entry_machine_title': '自動咖啡館 - 入場機器',
    'entry_process': '處理入場',
    'select_people_count': '選擇人數',
    'member_card_scan': '會員卡感應',
    'nfc_scan_hint': '請將會員卡靠近感應器',
    'simulate_nfc_scan': '模擬感應會員卡',
    'test_print': '測試打印',
    'test_locker': '測試儲物柜',
    'entry_records': '入場記錄',
    'today_guests': '今日已接待',
    'groups_of_guests': '組客人',

    // 收銀系統
    'cashier_title': '自動咖啡館 - 收銀系統',
    'waiting_customers': '等待結賬客人',
    'process_checkout': '處理結賬',
    'payment_method': '付款方式',
    'payment_cash': '現金',
    'payment_card': '信用卡',
    'payment_member': '會員卡',
    'total_amount': '總金額',
    'tax': '稅金',
    'discount': '折扣',
    'final_amount': '應付金額',
    'change': '找零',

    // 商品售賣機
    'vending_title': '自動咖啡館 - 商品售賣機',
    'scan_qr_first': '請先掃描桌號QR Code',
    'product_categories': '商品分類',
    'all_products': '全部商品',
    'coffee': '咖啡',
    'tea': '茶飲',
    'dessert': '甜點',
    'snack': '零食',
    'add_to_cart': '加入購物車',
    'shopping_cart': '購物車',
    'cart_empty': '購物車是空的',
    'checkout': '結賬',
    'confirm_purchase': '確認購買',

    // 離場機器
    'exit_machine_title': '自動咖啡館 - 離場機器',
    'scan_qr_checkout': '請掃描桌號QR Code結賬',
    'customer_info': '客人信息',
    'checkout_info': '結賬信息',
    'process_checkout_btn': '執行結賬',
    'print_receipt': '打印收據',
    'purchase_history': '購買記錄',
    'door_lock_control': '門鎖控制',
    'test_door_lock': '測試門鎖',
    'manual_open': '手動開門',
    'emergency_open': '緊急開門',
    'exit_records': '離場記錄',
    'exit_stats': '離場統計',
    'total_revenue': '今日營業額',
    'avg_checkout': '平均結賬',
    'peak_hour': '高峰時段',
    'recent_checkout': '最近30分鐘',

    // 錯誤訊息
    'error_network': '網絡連接錯誤',
    'error_server': '伺服器錯誤',
    'error_database': '數據庫錯誤',
    'error_device': '設備連接錯誤',
    'error_validation': '驗證錯誤',
    'error_permission': '權限不足',
    'error_not_found': '找不到資源',
    'error_timeout': '操作超時',

    // 成功訊息
    'success_saved': '儲存成功',
    'success_updated': '更新成功',
    'success_deleted': '刪除成功',
    'success_operation': '操作成功',
    'success_checkout': '結賬成功',
    'success_entry': '入場處理成功',
    'success_purchase': '購買成功',

    // 確認對話框
    'confirm_delete': '確定要刪除嗎？',
    'confirm_checkout': '確定要結賬嗎？',
    'confirm_exit': '確定要離場嗎？',
    'confirm_emergency_stop': '確定要執行緊急停止嗎？',

    // 通知訊息
    'notification_new_customer': '有新的客人入場',
    'notification_checkout_request': '有客人請求結賬',
    'notification_device_error': '設備發生錯誤',
    'notification_system_warning': '系統警告',

    // 時間單位
    'second': '秒',
    'minute': '分鐘',
    'hour': '小時',
    'day': '天',
    'week': '週',
    'month': '月',
    'year': '年',

    // 金額格式
    'currency_symbol': '$',
    'currency_name': '元',

    // 系統訊息
    'system_started': '系統已啟動',
    'system_stopped': '系統已停止',
    'system_maintenance': '系統維護中',
    'system_error': '系統錯誤',

    // 門鎖狀態
    'door_locked': '門鎖狀態: 鎖定',
    'door_unlocked': '門鎖狀態: 解鎖',
    'door_opening': '門鎖開啟中...',
    'door_closing': '門鎖關閉中...',
    'door_error': '門鎖錯誤',

    // 儲物柜狀態
    'locker_available': '儲物柜可用',
    'locker_occupied': '儲物柜已使用',
    'locker_reserved': '儲物柜已預約',
    'locker_maintenance': '儲物柜維護中',
    'locker_error': '儲物柜錯誤',

    // 打印機狀態
    'printer_ready': '打印機就緒',
    'printer_printing': '打印機打印中',
    'printer_out_of_paper': '打印機缺紙',
    'printer_error': '打印機錯誤',
    'printer_offline': '打印機離線',

    // 音響系統
    'audio_playing': '音響播放中',
    'audio_stopped': '音響已停止',
    'audio_error': '音響系統錯誤',
  },

  'en-US': {
    // 預留給未來英文支持
    // 可以根據需要添加
  }
};

class LanguageManager {
  constructor(defaultLang = 'zh-TW') {
    this.currentLang = defaultLang;
    this.translations = LANGUAGES[defaultLang] || LANGUAGES['zh-TW'];
  }

  /**
   * 設置當前語言
   * @param {string} lang - 語言代碼 (zh-TW, en-US)
   */
  setLanguage(lang) {
    if (LANGUAGES[lang]) {
      this.currentLang = lang;
      this.translations = LANGUAGES[lang];
      return true;
    }
    return false;
  }

  /**
   * 獲取翻譯
   * @param {string} key - 翻譯鍵
   * @param {Object} params - 替換參數
   * @returns {string} 翻譯後的文字
   */
  t(key, params = {}) {
    let text = this.translations[key] || key;

    // 替換參數
    Object.keys(params).forEach(paramKey => {
      const placeholder = `{${paramKey}}`;
      text = text.replace(new RegExp(placeholder, 'g'), params[paramKey]);
    });

    return text;
  }

  /**
   * 獲取當前語言
   * @returns {string} 當前語言代碼
   */
  getCurrentLanguage() {
    return this.currentLang;
  }

  /**
   * 獲取所有支持的語言
   * @returns {Array} 語言代碼列表
   */
  getSupportedLanguages() {
    return Object.keys(LANGUAGES);
  }

  /**
   * 格式化金額
   * @param {number} amount - 金額
   * @param {string} currency - 貨幣符號 (可選)
   * @returns {string} 格式化後的金額
   */
  formatCurrency(amount, currency = null) {
    const symbol = currency || this.t('currency_symbol');
    return `${symbol}${amount.toLocaleString(this.currentLang)}`;
  }

  /**
   * 格式化時間
   * @param {Date|string} date - 日期對象或字符串
   * @param {string} format - 格式 (short, medium, long, full)
   * @returns {string} 格式化後的時間
   */
  formatDate(date, format = 'medium') {
    const dateObj = date instanceof Date ? date : new Date(date);
    const options = {};

    switch (format) {
      case 'short':
        options.year = 'numeric';
        options.month = '2-digit';
        options.day = '2-digit';
        break;
      case 'long':
        options.year = 'numeric';
        options.month = 'long';
        options.day = 'numeric';
        options.weekday = 'long';
        break;
      case 'full':
        options.year = 'numeric';
        options.month = 'long';
        options.day = 'numeric';
        options.weekday = 'long';
        options.hour = '2-digit';
        options.minute = '2-digit';
        options.second = '2-digit';
        break;
      case 'medium':
      default:
        options.year = 'numeric';
        options.month = 'short';
        options.day = 'numeric';
        options.hour = '2-digit';
        options.minute = '2-digit';
    }

    return dateObj.toLocaleDateString(this.currentLang, options);
  }

  /**
   * 格式化相對時間
   * @param {Date|string} date - 日期對象或字符串
   * @returns {string} 相對時間描述
   */
  formatRelativeTime(date) {
    const dateObj = date instanceof Date ? date : new Date(date);
    const now = new Date();
    const diffMs = now - dateObj;
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHour = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHour / 24);

    if (diffSec < 60) {
      return `${diffSec} ${this.t('second')}前`;
    } else if (diffMin < 60) {
      return `${diffMin} ${this.t('minute')}前`;
    } else if (diffHour < 24) {
      return `${diffHour} ${this.t('hour')}前`;
    } else if (diffDay < 7) {
      return `${diffDay} ${this.t('day')}前`;
    } else {
      return this.formatDate(dateObj, 'short');
    }
  }
}

// 創建默認實例
const languageManager = new LanguageManager('zh-TW');

module.exports = {
  LanguageManager,
  languageManager,
  t: (key, params) => languageManager.t(key, params),
  setLanguage: (lang) => languageManager.setLanguage(lang),
  getCurrentLanguage: () => languageManager.getCurrentLanguage(),
  formatCurrency: (amount, currency) => languageManager.formatCurrency(amount, currency),
  formatDate: (date, format) => languageManager.formatDate(date, format),
  formatRelativeTime: (date) => languageManager.formatRelativeTime(date)
};