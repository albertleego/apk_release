// 入場機器前端邏輯

// 日期格式函數（避免 toLocaleString 產生極窄空格   導致 ?）
function formatDateTime(d) {
    d = d || new Date();
    return `${d.getFullYear()}/${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getDate()).padStart(2,'0')} ${d.getHours()}:${String(d.getMinutes()).padStart(2,'0')}:${String(d.getSeconds()).padStart(2,'0')}`;
}

class EntryMachine {
    constructor() {
        this.socket = null;
        this.peopleCount = 1;
        this.selectedPeopleCount = 1; // 用於人數選擇卡片
        this.childrenCount = 0; // 最終小朋友人數
        this.selectedChildrenCount = 0; // 用於小朋友人數選擇卡片
        this.pricingData = null; // 收費標準數據
        this.memberCardId = null;
        this.memberInfo = null;
        this.currentQRCode = null;
        this.recentEntries = [];
        this.visitorType = null; // 'first-time' or 'returning'
        this.currentLanguage = 'zh-TW';
        this.returnTimer = null; // 20秒返回計時器
        this.footerHideTimer = null; // footer 顯示後 10 秒自動隱藏計時器
        this.eventsBound = false; // 防止事件重複綁定
        this.isProcessing = false; // 防止重複提交
        this.isAuthenticated = false; // 登入狀態
        this.currentEmployee = null;
        this.currentToken = null;
        this.tokenExpiresAt = null;
        this.connectionHealthy = true;   // 主機/打印機是否正常
        this.healthCheckTimer = null;    // 30s 定時檢查
        this.recoveryTimer = null;       // 2s 恢復檢查
        this.recoveryAttempts = 0;       // 恢復檢查次數
        this.maxRecoveryAttempts = 30;   // 最多檢查30次
        this.init();
    }

    // 翻譯字典
    static translations = {
        'zh-TW': {
            'firstTimeQuestion': '請問您是第一次來嗎',
            'firstTimeYes': '是的\n我第一次來',
            'firstTimeNo': '不是\n我之前來過',
            'rulesVideoTitle': '店內規則說明影片',
            'rulesVideoLoading': '正在載入規則影片...',
            'skipVideoBtn': '跳過影片',
            'continueAfterVideoBtn': '影片觀看完畢，繼續',
            'selectPeopleTitle': '選擇客人人數',
            'confirmPeopleBtn': '確認人數',
            'entryGuidanceTitle': '入場指引',
            'entryGuidanceText': '請提取小票\n存放鞋子後\n門口掃小票二維碼\n即可入場',
            'restartProcessBtn': '返回主頁',
            'peopleUnit': '位',
            'processingTitle': '處理中...',
            'stepVerify': '驗證輸入',
            'stepAssignTable': '分配桌位',
            'stepAssignLocker': '分配儲物柜',
            'stepGenerateQR': '生成QR Code',
            'stepPrint': '打印小票',
            'progressReady': '準備開始處理...',
            'progressVerify': '驗證輸入...',
            'progressAssignTable': '分配桌位...',
            'progressAssignLocker': '分配儲物柜...',
            'progressGenerateQR': '生成QR Code...',
            'progressPrint': '打印小票...',
            'cancelBtn': '取消',
            'fullSeatTitle': '目前已經滿座',
            'fullSeatMessage': '請掃以下二維碼登記候位\n有位置後會優先致電和whatsapp 您',
            'fullSeatCloseBtn': '關閉',
            'selectChildrenTitle': '請問有幾位未滿11歲的小朋友？',
            'childrenUnit': '位',
            'confirmChildrenBtn': '確認',
            'backToPeopleBtn': '返回人數選擇',
            'errorChildrenExceedTotal': '小朋友人數不能大於總人數',
            'errorChildrenRatioStore24': '抱歉, 每1位小朋友都需要1位大人陪同 (大小同價)',
            'errorChildrenRatioStore13': '抱歉, 每位大人只能帶同最多2位小朋友進場 (大小同價)',
            'pricingTitle': '收費',
            'pricingLoading': '載入中...',
            'pricingConfirmBtn': '確認，下一步',
            'pricingWeekday': '閒日',
            'pricingHolidayNonpeak': '星期六日及公眾假期\n2pm前 及 6pm後',
            'pricingHolidayPeak': '星期六日及公眾假期\n2pm - 6pm',
            'pricingCurrentLabel': '▼ 目前收費',
            'pricingNotice': '本店有輕食及甜品售賣，不設正餐',
            'pricingDrinkNotice': '咖啡茶水任飲',
            'pricingMinHour': '未滿一小時以一小時計算',
            'pricingStudentDiscount': '中學生減 $10'
        },
        'zh-CN': {
            'firstTimeQuestion': '请问您是第一次来吗',
            'firstTimeYes': '是的\n我第一次来',
            'firstTimeNo': '不是\n我之前来过',
            'rulesVideoTitle': '店内规则说明视频',
            'rulesVideoLoading': '正在加载规则视频...',
            'skipVideoBtn': '跳过视频',
            'continueAfterVideoBtn': '视频观看完毕，继续',
            'selectPeopleTitle': '选择客人人数',
            'confirmPeopleBtn': '确认人数',
            'entryGuidanceTitle': '入场指引',
            'entryGuidanceText': '请提取小票\n存放鞋子后\n门口扫小票二维码\n即可入场',
            'restartProcessBtn': '返回主页',
            'peopleUnit': '位',
            'processingTitle': '处理中...',
            'stepVerify': '验证输入',
            'stepAssignTable': '分配桌位',
            'stepAssignLocker': '分配储物柜',
            'stepGenerateQR': '生成QR Code',
            'stepPrint': '打印小票',
            'progressReady': '准备开始处理...',
            'progressVerify': '验证输入...',
            'progressAssignTable': '分配桌位...',
            'progressAssignLocker': '分配储物柜...',
            'progressGenerateQR': '生成QR Code...',
            'progressPrint': '打印小票...',
            'cancelBtn': '取消',
            'fullSeatTitle': '目前已经满座',
            'fullSeatMessage': '请扫以下二维码登记候位\n有位置后会优先致电和whatsapp 您',
            'fullSeatCloseBtn': '关闭',
            'selectChildrenTitle': '请问有几位未满11岁的小朋友？',
            'childrenUnit': '位',
            'confirmChildrenBtn': '确认',
            'backToPeopleBtn': '返回人数选择',
            'errorChildrenExceedTotal': '小朋友人数不能大于总人数',
            'errorChildrenRatioStore24': '抱歉, 每1位小朋友都需要1位大人陪同 (大小同价)',
            'errorChildrenRatioStore13': '抱歉, 每位大人只能带同最多2位小朋友进场 (大小同价)',
            'pricingTitle': '收费',
            'pricingLoading': '加载中...',
            'pricingConfirmBtn': '确认，下一步',
            'pricingWeekday': '闲日',
            'pricingHolidayNonpeak': '星期六日及公众假期\n2pm前 及 6pm后',
            'pricingHolidayPeak': '星期六日及公众假期\n2pm - 6pm',
            'pricingCurrentLabel': '▼ 目前收费',
            'pricingNotice': '本店有轻食及甜品售卖，不设正餐',
            'pricingDrinkNotice': '咖啡茶水任饮',
            'pricingMinHour': '未满一小时以一小时计算',
            'pricingStudentDiscount': '中学生减 $10'
        },
        'en': {
            'firstTimeQuestion': 'Is this your first visit?',
            'firstTimeYes': 'Yes\nthis is my first time',
            'firstTimeNo': 'No\nI have been here before',
            'rulesVideoTitle': 'Store Rules Video',
            'rulesVideoLoading': 'Loading rules video...',
            'skipVideoBtn': 'Skip Video',
            'continueAfterVideoBtn': 'Continue after video',
            'selectPeopleTitle': 'Select Number of Guests',
            'confirmPeopleBtn': 'Confirm',
            'entryGuidanceTitle': 'Entry Guidance',
            'entryGuidanceText': 'Please collect receipt\nAfter storing shoes\nScan receipt QR code at entrance\nThen enter',
            'restartProcessBtn': 'Homepage',
            'peopleUnit': ' pax',
            'processingTitle': 'Processing...',
            'stepVerify': 'Verify Input',
            'stepAssignTable': 'Assign Table',
            'stepAssignLocker': 'Assign Locker',
            'stepGenerateQR': 'Generate QR Code',
            'stepPrint': 'Print Receipt',
            'progressReady': 'Preparing...',
            'progressVerify': 'Verifying...',
            'progressAssignTable': 'Assigning table...',
            'progressAssignLocker': 'Assigning locker...',
            'progressGenerateQR': 'Generating QR Code...',
            'progressPrint': 'Printing receipt...',
            'cancelBtn': 'Cancel',
            'fullSeatTitle': 'Currently Full',
            'fullSeatMessage': 'Please scan the QR code below to join the waiting list\nWe will prioritize calling and WhatsApp you when seats become available',
            'fullSeatCloseBtn': 'Close',
            'selectChildrenTitle': 'How many children under 11?',
            'childrenUnit': '',
            'confirmChildrenBtn': 'Confirm',
            'backToPeopleBtn': 'Back',
            'errorChildrenExceedTotal': 'Children count cannot exceed total guests',
            'errorChildrenRatioStore24': 'Sorry, each child needs at least 1 adult guardian (same price for all)',
            'errorChildrenRatioStore13': 'Sorry, each adult can bring at most 2 children (same price for all)',
            'pricingTitle': 'Pricing',
            'pricingLoading': 'Loading...',
            'pricingConfirmBtn': 'Confirm & Next',
            'pricingWeekday': 'Weekday',
            'pricingHolidayNonpeak': 'Weekends & PH - Before 2pm & After 6pm',
            'pricingHolidayPeak': 'Weekends & PH - 2pm-6pm',
            'pricingCurrentLabel': '▼ Current Rate',
            'pricingNotice': 'Light meals & desserts available, no full-course meals',
            'pricingDrinkNotice': 'Free-flow coffee & tea',
            'pricingMinHour': 'Minimum charge of 1 hour applies',
            'pricingStudentDiscount': 'Student discount -$10'
        }
    };

    // 解析入場時間字符串，支援兩種格式：
    // 1. ISO 字符串 (UTC) 例如 "2026-03-24T07:31:00.000Z"
    // 2. 本地時間字符串 "YYYY-MM-DD HH:MM:SS"
    parseEntryTime(entryTimeString) {
        if (!entryTimeString) return new Date();

        // 檢查是否為 ISO 格式 (包含 'T' 或結尾有 'Z')
        if (entryTimeString.includes('T') || entryTimeString.endsWith('Z')) {
            // ISO 格式，直接解析為 UTC
            return new Date(entryTimeString);
        } else {
            // 本地時間格式 "YYYY-MM-DD HH:MM:SS"
            // 手動解析並創建本地時間 Date 物件
            const [datePart, timePart] = entryTimeString.split(' ');
            const [year, month, day] = datePart.split('-').map(Number);
            const [hours, minutes, seconds] = timePart.split(':').map(Number);
            return new Date(year, month - 1, day, hours, minutes, seconds);
        }
    }

    applyTranslations(lang) {
        const translations = EntryMachine.translations[lang];
        if (!translations) return;

        // 更新所有帶有 data-i18n 屬性的元素
        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n');
            if (translations[key]) {
                // 特殊處理包含換行符的文本
                if (translations[key].includes('\n')) {
                    // 使用 innerHTML 並將換行符轉換為 <br>
                    element.innerHTML = translations[key].replace(/\n/g, '<br>');
                } else {
                    element.textContent = translations[key];
                }
            }
        });

        // 更新所有帶有 data-i18n-placeholder 屬性的輸入框
        document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
            const key = element.getAttribute('data-i18n-placeholder');
            if (translations[key]) {
                element.placeholder = translations[key];
            }
        });

        // 更新人數快速選擇按鈕的單位（1位/2位 → 1 pax/2 pax）
        const unit = translations['peopleUnit'] || '位';
        document.querySelectorAll('.btn-people').forEach(btn => {
            const count = btn.dataset.count;
            if (count) {
                btn.textContent = count + unit;
            }
        });
    }

    async init() {
        // 初始化時間顯示
        this.updateTime();
        setInterval(() => this.updateTime(), 1000);

        // 連接Socket.IO
        this.connectSocket();

        // 綁定事件監聽器
        this.bindEvents();

        // 檢查登入狀態
        this.checkSavedLogin();

        // 應用初始翻譯
        this.applyTranslations(this.currentLanguage);

        // 載入今日統計
        this.loadTodayStats();

        // 載入最近的入場記錄
        this.loadRecentEntries();

        // 初始化系統訊息
        this.addMessage('系統啟動完成', 'info');

        // 初始化人數選擇卡片狀態（無預設選擇）
        this.clearPeopleSelection();

        // 初始化會員 QR Code 掃描
        this.initMemberQRReader();

        // 啟動健康檢查（每30秒檢查主機 + 打印機連線）
        this.startHealthCheckSchedule();
    }

    connectSocket() {
        this.socket = io();

        this.socket.on('connect', () => {
            this.updateStatus('online');
            this.addMessage('已連線到伺服器', 'success');
        });

        this.socket.on('disconnect', () => {
            this.updateStatus('offline');
            this.addMessage('與伺服器斷開連線', 'error');
        });

        this.socket.on('new-customer', (data) => {
            this.addMessage(`新客人入場: 桌號 ${data.table_number}, ${data.people_count}位`, 'info');
            this.loadRecentEntries();
            this.loadTodayStats();
        });

        this.socket.on('print-receipt', (data) => {
            this.addMessage(`小票打印完成: 桌號 ${data.table_number}`, 'success');
        });

        this.socket.on('print-receipt-failed', (data) => {
            this.addMessage(`⚠ 打印小票失敗！桌號 ${data.table_number}: ${data.error}`, 'error');
            this.showPrintFailedAlert(data);
        });

        this.socket.on('lockers-opened', (data) => {
            this.addMessage(`儲物柜已開啟: ${data.locker_numbers.join(', ')}`, 'success');
        });
    }

    bindEvents() {
        // 防止重複綁定事件
        if (this.eventsBound) {
            console.log('事件已綁定，跳過重複綁定');
            return;
        }

        this.eventsBound = true;

        // 語言選擇
        document.querySelectorAll('.language-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const lang = e.target.dataset.lang;
                this.setLanguage(lang);
            });
        });

        // 時間處點 6 下：顯示 footer（10 秒後自動隱藏）
        const currentTimeEl = document.getElementById('current-time');
        if (currentTimeEl) {
            let timeClickCount = 0;
            let timeClickResetTimer = null;
            currentTimeEl.addEventListener('click', () => {
                timeClickCount++;
                if (timeClickResetTimer) clearTimeout(timeClickResetTimer);
                timeClickResetTimer = setTimeout(() => { timeClickCount = 0; }, 3000);
                if (timeClickCount >= 6) {
                    timeClickCount = 0;
                    if (timeClickResetTimer) clearTimeout(timeClickResetTimer);
                    this.showFooterTemporarily();
                }
            });
        }

        // 訪客類型選擇
        const firstTimeBtn = document.getElementById('first-time-btn');
        const returningBtn = document.getElementById('returning-btn');

        if (firstTimeBtn) {
            console.log('Found first-time-btn element');
            firstTimeBtn.addEventListener('click', (e) => {
                console.log('First-time button click event fired');
                e.stopPropagation();
                this.handleFirstTimeVisitor();
            });
        } else {
            console.error('First-time button element not found');
        }

        if (returningBtn) {
            console.log('Found returning-btn element');
            returningBtn.addEventListener('click', (e) => {
                console.log('Returning button click event fired');
                e.stopPropagation();
                this.handleReturningVisitor();
            });
        } else {
            console.error('Returning button element not found');
        }

        // 人數選擇卡片事件
        const decreaseSelectionBtn = document.getElementById('decrease-selection-btn');
        const increaseSelectionBtn = document.getElementById('increase-selection-btn');
        const confirmPeopleBtn = document.getElementById('confirm-people-btn');

        if (decreaseSelectionBtn) decreaseSelectionBtn.addEventListener('click', () => this.adjustSelectedPeopleCount(-1));
        if (increaseSelectionBtn) increaseSelectionBtn.addEventListener('click', () => this.adjustSelectedPeopleCount(1));
        if (confirmPeopleBtn) confirmPeopleBtn.addEventListener('click', async () => {
            try {
                await this.confirmPeopleCount();
            } catch (error) {
                console.error('確認人數時發生錯誤:', error);
                this.addMessage('確認人數時發生錯誤: ' + error.message, 'error');
            }
        });

        // 返回主頁按鈕
        const backToHomeBtn = document.getElementById('back-to-home-btn');
        if (backToHomeBtn) backToHomeBtn.addEventListener('click', () => this.restartProcess());

        // 收費標準卡片事件
        const backToPeopleFromPricingBtn = document.getElementById('back-to-people-from-pricing-btn');
        const confirmPricingBtn = document.getElementById('confirm-pricing-btn');
        if (backToPeopleFromPricingBtn) backToPeopleFromPricingBtn.addEventListener('click', () => {
            // 收費標準在選擇人數之前，返回則回主頁
            document.getElementById('pricing-card').classList.add('hidden');
            document.getElementById('visitor-type-card').classList.remove('hidden');
        });
        if (confirmPricingBtn) confirmPricingBtn.addEventListener('click', async () => {
            try {
                await this.confirmPricing();
            } catch (error) {
                console.error('確認收費標準時發生錯誤:', error);
                this.addMessage('確認收費標準時發生錯誤: ' + error.message, 'error');
            }
        });

        // 人數選擇卡片中的快速選擇按鈕
        document.querySelectorAll('#people-count-card .btn-people').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const button = e.currentTarget;
                const count = parseInt(button.dataset.count);
                this.setSelectedPeopleCount(count);

                // 更新按鈕狀態
                document.querySelectorAll('#people-count-card .btn-people').forEach(b => b.classList.remove('active'));
                button.classList.add('active');
            });
        });

        // 小朋友人數選擇卡片事件
        const decreaseChildrenBtn = document.getElementById('decrease-children-btn');
        const increaseChildrenBtn = document.getElementById('increase-children-btn');
        const confirmChildrenBtn = document.getElementById('confirm-children-btn');
        const backToPeopleBtn = document.getElementById('back-to-people-btn');

        if (decreaseChildrenBtn) decreaseChildrenBtn.addEventListener('click', () => this.adjustSelectedChildrenCount(-1));
        if (increaseChildrenBtn) increaseChildrenBtn.addEventListener('click', () => this.adjustSelectedChildrenCount(1));
        if (confirmChildrenBtn) confirmChildrenBtn.addEventListener('click', async () => {
            try {
                await this.confirmChildrenCount();
            } catch (error) {
                console.error('確認小朋友人數時發生錯誤:', error);
                this.addMessage('確認小朋友人數時發生錯誤: ' + error.message, 'error');
            }
        });
        if (backToPeopleBtn) backToPeopleBtn.addEventListener('click', () => {
            document.getElementById('children-count-card').classList.add('hidden');
            this.clearPeopleSelection();
            document.getElementById('people-count-card').classList.remove('hidden');
        });

        // 小朋友人數快速選擇按鈕
        document.querySelectorAll('#children-count-card .btn-people').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const button = e.currentTarget;
                const count = parseInt(button.dataset.count);
                this.setSelectedChildrenCount(count);
            });
        });

        // 影片控制
        const skipVideoBtn = document.getElementById('skip-video-btn');
        const continueAfterVideoBtn = document.getElementById('continue-after-video-btn');
        const videoBackHomeBtn = document.getElementById('video-back-home-btn');
        if (skipVideoBtn) skipVideoBtn.addEventListener('click', () => this.skipVideo());
        if (continueAfterVideoBtn) continueAfterVideoBtn.addEventListener('click', () => this.continueAfterVideo());
        if (videoBackHomeBtn) videoBackHomeBtn.addEventListener('click', () => this.restartProcess());

        // 人數控制
        const decreaseBtn = document.getElementById('decrease-btn');
        const increaseBtn = document.getElementById('increase-btn');
        if (decreaseBtn) decreaseBtn.addEventListener('click', () => this.adjustPeopleCount(-1));
        if (increaseBtn) increaseBtn.addEventListener('click', () => this.adjustPeopleCount(1));

        // 入場面板中的人數快速選擇按鈕
        document.querySelectorAll('#entry-panel .btn-people').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const button = e.currentTarget;
                const count = parseInt(button.dataset.count);
                this.setPeopleCount(count);

                // 更新按鈕狀態
                document.querySelectorAll('#entry-panel .btn-people').forEach(b => b.classList.remove('active'));
                button.classList.add('active');
            });
        });

        // 處理入場
        const processEntryBtn = document.getElementById('process-entry-btn');
        if (processEntryBtn) processEntryBtn.addEventListener('click', () => this.processEntry());

        // 測試按鈕
        const testPrintBtn = document.getElementById('test-print-btn');
        const testLockerBtn = document.getElementById('test-locker-btn');
        if (testPrintBtn) testPrintBtn.addEventListener('click', () => this.testPrint());
        if (testLockerBtn) testLockerBtn.addEventListener('click', () => this.testLocker());

        // 設備控制
        const printerTestBtn = document.getElementById('printer-test-btn');
        const printerResetBtn = document.getElementById('printer-reset-btn');
        const lockerTestBtn = document.getElementById('locker-test-btn');
        const lockerResetBtn = document.getElementById('locker-reset-btn');
        const audioTestBtn = document.getElementById('audio-test-btn');
        const audioStopBtn = document.getElementById('audio-stop-btn');
        if (printerTestBtn) printerTestBtn.addEventListener('click', () => this.testPrinter());
        if (printerResetBtn) printerResetBtn.addEventListener('click', () => this.resetPrinter());
        if (lockerTestBtn) lockerTestBtn.addEventListener('click', () => this.testLockerSystem());
        if (lockerResetBtn) lockerResetBtn.addEventListener('click', () => this.resetLockerSystem());
        if (audioTestBtn) audioTestBtn.addEventListener('click', () => this.testAudio());
        if (audioStopBtn) audioStopBtn.addEventListener('click', () => this.stopAudio());

        // 手動重連按鈕
        const retryBtn = document.getElementById('retry-connection-btn');
        if (retryBtn) retryBtn.addEventListener('click', () => this.retryConnection());

        // 刷新記錄
        const refreshEntriesBtn = document.getElementById('refresh-entries-btn');
        if (refreshEntriesBtn) refreshEntriesBtn.addEventListener('click', () => this.loadRecentEntries());

        // 複製QR Code
        const copyQrBtn = document.getElementById('copy-qr-btn');
        if (copyQrBtn) copyQrBtn.addEventListener('click', () => this.copyQRCode());

        // 系統訊息控制已移除


        // 處理模態框
        const cancelProcessBtn = document.getElementById('cancel-process-btn');
        if (cancelProcessBtn) cancelProcessBtn.addEventListener('click', () => this.cancelProcessing());

        // 滿座提示模態框
        const closeFullSeatBtn = document.getElementById('close-full-seat-btn');
        if (closeFullSeatBtn) closeFullSeatBtn.addEventListener('click', () => this.hideFullSeatModal());

        // 登入相關
        const staffLoginBtn = document.getElementById('staff-login-btn');
        if (staffLoginBtn) {
            staffLoginBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                if (this.isAuthenticated) {
                    this.logout();
                } else {
                    this.showLoginModal();
                }
            });
        }

        const cancelLoginBtn = document.getElementById('cancel-login-btn');
        if (cancelLoginBtn) cancelLoginBtn.addEventListener('click', () => this.hideLoginModal());

        const loginForm = document.getElementById('login-form');
        if (loginForm) loginForm.addEventListener('submit', (e) => this.handleLoginSubmit(e));

        // 退出 App（需重新驗證登入帳號密碼）
        const exitAppBtn = document.getElementById('exit-app-btn');
        if (exitAppBtn) exitAppBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (this.isAuthenticated) this.showExitModal();
        });

        const cancelExitBtn = document.getElementById('cancel-exit-btn');
        if (cancelExitBtn) cancelExitBtn.addEventListener('click', () => this.hideExitModal());

        const exitForm = document.getElementById('exit-form');
        if (exitForm) exitForm.addEventListener('submit', (e) => this.handleExitSubmit(e));
    }

    setLanguage(lang) {
        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        // 更新語言按鈕狀態
        document.querySelectorAll('.language-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.lang === lang) {
                btn.classList.add('active');
            }
        });
        this.currentLanguage = lang;
        this.applyTranslations(lang);
        this.addMessage(`語言已切換為: ${lang}`, 'info');

        // 如果當前顯示入場指引頁面，重新生成內容以更新翻譯
        const videoSection = document.getElementById('video-section');
        if (videoSection && !videoSection.classList.contains('hidden')) {
            const titleElement = videoSection.querySelector('h2 span');
            if (titleElement && titleElement.getAttribute('data-i18n') === 'entryGuidanceTitle') {
                // 重新生成入場指引內容
                this.updateVideoSectionToEntryGuidance();
            }
        }
    }

    handleFirstTimeVisitor() {
        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        console.log('First time visitor button clicked');
        this.visitorType = 'first-time';
        this.addMessage('歡迎新客人！請先查看收費標準', 'info');

        // 顯示收費標準頁面（第一次來的客人先看收費，再選人數）
        document.getElementById('visitor-type-card').classList.add('hidden');
        this.showPricingCard();
    }

    handleReturningVisitor() {
        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        console.log('Returning visitor button clicked');
        this.visitorType = 'returning';
        this.addMessage('歡迎回來！請選擇人數', 'info');

        // 清除預設選擇，顯示人數選擇卡片
        this.clearPeopleSelection();
        document.getElementById('visitor-type-card').classList.add('hidden');
        document.getElementById('people-count-card').classList.remove('hidden');
    }

    startVideoPlayback() {
        this.addMessage('開始播放規則影片...', 'info');

        // 禁用繼續按鈕直到影片完成
        document.getElementById('continue-after-video-btn').disabled = true;

        // 更新影片佔位符顯示
        const videoPlaceholder = document.querySelector('.video-placeholder');
        if (videoPlaceholder) {
            videoPlaceholder.innerHTML = `
                <i class="fas fa-play-circle fa-spin"></i>
                <p>規則影片播放中... (3秒)</p>
            `;
        }

        // 模擬影片播放
        setTimeout(() => {
            this.addMessage('規則影片播放完成', 'success');
            // 更新影片佔位符
            if (videoPlaceholder) {
                videoPlaceholder.innerHTML = `
                    <i class="fas fa-check-circle"></i>
                    <p>規則影片播放完成</p>
                `;
            }
            // 啟用繼續按鈕
            document.getElementById('continue-after-video-btn').disabled = false;
        }, 3000); // 3秒模擬影片長度
    }

    skipVideo() {
        // 取消返回計時器
        this.cancelReturnTimer();

        this.addMessage('已跳過規則影片', 'warning');
        // 直接顯示入場面板
        document.getElementById('video-section').classList.add('hidden');
        document.getElementById('entry-panel').classList.remove('hidden');

        // 重置影片佔位符（為下一次做準備）
        const videoPlaceholder = document.querySelector('.video-placeholder');
        if (videoPlaceholder) {
            videoPlaceholder.innerHTML = `
                <i class="fas fa-play-circle"></i>
                <p data-i18n="rulesVideoLoading"></p>
            `;
            // 重新應用翻譯
            this.applyTranslations(this.currentLanguage);
        }
    }

    async continueAfterVideo() {
        // 取消返回計時器
        this.cancelReturnTimer();

        this.addMessage('規則影片觀看完畢，開始入場處理', 'success');

        // 禁用繼續按鈕防止重複點擊
        const continueBtn = document.getElementById('continue-after-video-btn');
        if (continueBtn) continueBtn.disabled = true;

        try {
            // 執行入場處理流程
            console.log('continueAfterVideo: calling processEntry with skipDuplicateCheck=true');
            await this.processEntry(true);

            // 入場處理完成後，更新影片區域為入場指引
            this.updateVideoSectionToEntryGuidance();

        } catch (error) {
            this.addMessage('入場處理失敗: ' + error.message, 'error');
            // 重新啟用繼續按鈕以便重試
            if (continueBtn) continueBtn.disabled = false;
        }
    }

    updateVideoSectionToEntryGuidance() {
        const videoSection = document.getElementById('video-section');
        if (!videoSection) return;

        // 確保視頻區域可見，隱藏入場面板
        videoSection.classList.remove('hidden');
        document.getElementById('entry-panel').classList.add('hidden');

        // 更新標題
        const titleElement = videoSection.querySelector('h2 span');
        if (titleElement) {
            titleElement.setAttribute('data-i18n', 'entryGuidanceTitle');
        }

        // 更新內容區域
        const videoContainer = videoSection.querySelector('.video-container');
        if (videoContainer) {
            videoContainer.innerHTML = `
                <div class="video-placeholder">
                    <i class="fas fa-clipboard-check"></i>
                    <p data-i18n="entryGuidanceText">請提取小票<br>存放鞋子後<br>門口掃小票二維碼<br>即可入場</p>
                </div>
                <div class="video-controls" style="justify-content: center; margin-top: 30px;">
                    <button class="btn-primary btn-lg" id="restart-process-btn">
                        <i class="fas fa-home"></i> <span data-i18n="restartProcessBtn">返回主頁</span>
                    </button>
                </div>
            `;
        }

        // 應用翻譯
        this.applyTranslations(this.currentLanguage);

        // 綁定重新開始按鈕事件
        const restartBtn = document.getElementById('restart-process-btn');
        if (restartBtn) {
            restartBtn.addEventListener('click', () => this.restartProcess());
        }

        this.addMessage('入場指引已顯示', 'info');

        // 設置20秒後自動返回初始頁面
        this.startReturnTimer();
    }

    restartProcess() {
        // 取消現有計時器
        this.cancelReturnTimer();

        this.addMessage('重新開始入場流程', 'info');

        // 隱藏所有卡片，只顯示初始訪客類型選擇
        document.getElementById('video-section').classList.add('hidden');
        document.getElementById('people-count-card').classList.add('hidden');
        document.getElementById('pricing-card').classList.add('hidden');
        document.getElementById('children-count-card').classList.add('hidden');
        document.getElementById('entry-panel').classList.add('hidden');
        document.getElementById('visitor-type-card').classList.remove('hidden');

        // 重置影片區域內容
        const videoSection = document.getElementById('video-section');
        if (videoSection) {
            const videoContainer = videoSection.querySelector('.video-container');
            if (videoContainer) {
                videoContainer.innerHTML = `
                    <div class="video-placeholder">
                        <i class="fas fa-play-circle"></i>
                        <p data-i18n="rulesVideoLoading">正在載入規則影片...</p>
                    </div>
                    <div class="video-controls hidden-skip">
                        <button class="btn-secondary" id="skip-video-btn">
                            <i class="fas fa-forward"></i> <span data-i18n="skipVideoBtn">跳過影片</span>
                        </button>
                        <button class="btn-secondary" id="video-back-home-btn">
                            <i class="fas fa-home"></i> <span data-i18n="restartProcessBtn">返回主頁</span>
                        </button>
                        <button class="btn-primary" id="continue-after-video-btn" disabled>
                            <i class="fas fa-check-circle"></i> <span data-i18n="continueAfterVideoBtn">影片觀看完畢，繼續</span>
                        </button>
                    </div>
                `;
            }
        }

        // 重置狀態
        this.selectedPeopleCount = 1;
        this.peopleCount = 1;
        this.selectedChildrenCount = 0;
        this.childrenCount = 0;
        this.visitorType = null;

        // 重新應用翻譯
        this.applyTranslations(this.currentLanguage);

        // 綁定影片控制按鈕（因為HTML已重新生成）
        const skipVideoBtn = document.getElementById('skip-video-btn');
        const continueAfterVideoBtn = document.getElementById('continue-after-video-btn');
        const videoBackHomeBtn = document.getElementById('video-back-home-btn');
        if (skipVideoBtn) skipVideoBtn.addEventListener('click', () => this.skipVideo());
        if (continueAfterVideoBtn) continueAfterVideoBtn.addEventListener('click', () => this.continueAfterVideo());
        if (videoBackHomeBtn) videoBackHomeBtn.addEventListener('click', () => this.restartProcess());
    }

    // 啟動20秒返回初始頁面計時器
    startReturnTimer() {
        // 先取消現有計時器
        this.cancelReturnTimer();

        this.returnTimer = setTimeout(() => {
            this.addMessage('20秒未操作，自動返回初始頁面', 'info');
            this.restartProcess();
        }, 20000); // 20秒
    }

    // 取消返回計時器
    cancelReturnTimer() {
        if (this.returnTimer) {
            clearTimeout(this.returnTimer);
            this.returnTimer = null;
        }
    }

    updateTime() {
        const now = new Date();
        const hh = String(now.getHours()).padStart(2, '0');
        const mm = String(now.getMinutes()).padStart(2, '0');

        document.getElementById('current-time').textContent = `${hh}:${mm}`;
        document.getElementById('last-update').textContent = `最後更新: ${hh}:${mm}`;
    }

    updateStatus(status) {
        const statusBar = document.getElementById('connection-status');
        if (!statusBar) return;
        if (status === 'online') {
            statusBar.classList.add('online');
            statusBar.innerHTML = '<i class="fas fa-wifi"></i><span>連線中</span>';
        } else {
            statusBar.classList.remove('online');
            statusBar.innerHTML = '<i class="fas fa-wifi"></i><span>離線中</span>';
        }
    }

    /**
     * 顯示 footer（時間處雙擊），10 秒後自動重新隱藏
     */
    showFooterTemporarily() {
        const footer = document.getElementById('footer');
        if (!footer) return;
        footer.classList.remove('hidden');
        if (this.footerHideTimer) {
            clearTimeout(this.footerHideTimer);
        }
        this.footerHideTimer = setTimeout(() => {
            footer.classList.add('hidden');
            this.footerHideTimer = null;
        }, 10000);
    }

    adjustPeopleCount(change) {
        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        let newCount = this.peopleCount + change;

        if (newCount < 1) newCount = 1;
        if (newCount > 10) newCount = 10;

        this.setPeopleCount(newCount);
    }

    setPeopleCount(count) {
        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        this.peopleCount = count;
        document.getElementById('people-count').textContent = count;

        // 更新按鈕狀態
        document.getElementById('decrease-btn').disabled = count <= 1;
        document.getElementById('increase-btn').disabled = count >= 10;
    }

    adjustSelectedPeopleCount(change) {
        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        let newCount = this.selectedPeopleCount + change;

        if (newCount < 1) newCount = 1;
        if (newCount > 10) newCount = 10;

        this.setSelectedPeopleCount(newCount);
    }

    setSelectedPeopleCount(count) {
        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        console.log(`setSelectedPeopleCount called: count=${count}, previous selectedPeopleCount=${this.selectedPeopleCount}`);
        this.selectedPeopleCount = count;
        const countElement = document.getElementById('people-count-selection');
        if (countElement) {
            countElement.textContent = count;
        }

        // 更新按鈕狀態
        const decreaseSelectionBtn = document.getElementById('decrease-selection-btn');
        const increaseSelectionBtn = document.getElementById('increase-selection-btn');
        if (decreaseSelectionBtn) decreaseSelectionBtn.disabled = count <= 1;
        if (increaseSelectionBtn) increaseSelectionBtn.disabled = count >= 10;

        // 更新快速選擇按鈕狀態
        document.querySelectorAll('#people-count-card .btn-people').forEach(btn => {
            const btnCount = parseInt(btn.dataset.count);
            btn.classList.toggle('active', btnCount === count);
        });
    }

    /** 清除總人數選擇（無按鈕亮起） */
    clearPeopleSelection() {
        this.selectedPeopleCount = 0;
        const countElement = document.getElementById('people-count-selection');
        if (countElement) countElement.textContent = '0';
        const decreaseSelectionBtn = document.getElementById('decrease-selection-btn');
        const increaseSelectionBtn = document.getElementById('increase-selection-btn');
        if (decreaseSelectionBtn) decreaseSelectionBtn.disabled = true;
        if (increaseSelectionBtn) increaseSelectionBtn.disabled = false;
        document.querySelectorAll('#people-count-card .btn-people').forEach(btn => {
            btn.classList.remove('active');
        });
    }

    /** 清除小朋友人數選擇（無按鈕亮起） */
    clearChildrenSelection() {
        this.selectedChildrenCount = 0;
        const countElement = document.getElementById('children-count-selection');
        if (countElement) countElement.textContent = '0';
        const decreaseChildrenBtn = document.getElementById('decrease-children-btn');
        const increaseChildrenBtn = document.getElementById('increase-children-btn');
        if (decreaseChildrenBtn) decreaseChildrenBtn.disabled = true;
        if (increaseChildrenBtn) increaseChildrenBtn.disabled = false;
        document.querySelectorAll('#children-count-card .btn-people').forEach(btn => {
            btn.classList.remove('active');
        });
    }

    async confirmPeopleCount() {
        // 防止重複執行
        if (this.isProcessing) {
            this.addMessage('正在處理中，請稍候...', 'warning');
            console.log('confirmPeopleCount: already processing, returning early');
            return;
        }

        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        this.isProcessing = true;
        console.log('confirmPeopleCount: isProcessing set to true, visitorType=', this.visitorType, 'selectedPeopleCount=', this.selectedPeopleCount, 'peopleCount=', this.peopleCount);

        try {
            // 驗證是否有選擇人數
            if (!this.selectedPeopleCount || this.selectedPeopleCount < 1) {
                this.addMessage('請先選擇客人人數', 'error');
                return;
            }

            // 將選擇的人數應用到入場面板
            this.peopleCount = this.selectedPeopleCount;
            document.getElementById('people-count').textContent = this.peopleCount;

            console.log(`confirmPeopleCount: peopleCount set to ${this.peopleCount} from selectedPeopleCount ${this.selectedPeopleCount}`);
            this.addMessage(`已選擇 ${this.selectedPeopleCount} 位客人`, 'info');

            // 隱藏人數選擇卡片
            document.getElementById('people-count-card').classList.add('hidden');

            // 清除小朋友預設選擇並更新UI
            this.clearChildrenSelection();
            this.refreshChildrenButtons();
            document.getElementById('children-count-card').classList.remove('hidden');
        } catch (error) {
            // 處理頂層錯誤
            this.addMessage('確認人數時發生錯誤: ' + error.message, 'error');
        } finally {
            this.isProcessing = false; // 重置處理標誌
        }
    }

    // ========================================================================
    //  收費標準展示
    // ========================================================================

    async showPricingCard() {
        this.cancelReturnTimer();

        // 隱藏人數選擇卡片，顯示收費標準卡片
        document.getElementById('people-count-card').classList.add('hidden');
        document.getElementById('pricing-card').classList.remove('hidden');

        // 顯示載入狀態
        const container = document.getElementById('pricing-container');
        container.innerHTML = `<div class="pricing-loading"><i class="fas fa-spinner fa-spin"></i> ${this.getTranslation('pricingLoading')}</div>`;

        try {
            const storeId = this.currentEmployee?.store_id || '';
            const response = await fetch(`/api/entry/pricing?store_id=${storeId}`);
            const result = await response.json();

            if (result.success && result.data) {
                this.pricingData = result.data;
                this.renderPricingData();
            } else {
                container.innerHTML = `<div class="pricing-loading" style="color: #e74c3c;">無法載入收費標準</div>`;
            }
        } catch (error) {
            console.error('獲取收費標準錯誤:', error);
            container.innerHTML = `<div class="pricing-loading" style="color: #e74c3c;">載入失敗: ${error.message}</div>`;
        }
    }

    renderPricingData() {
        const container = document.getElementById('pricing-container');
        const data = this.pricingData;
        if (!data || !data.periods) {
            container.innerHTML = `<div class="pricing-loading" style="color: #e74c3c;">無收費標準資料</div>`;
            return;
        }

        let html = '';
        data.periods.forEach(period => {
            const isCurrent = period.isCurrent;
            const periodTitle = this.getTranslation(period.labelKey) || period.label;
            const titleParts = periodTitle.split('\n');
            const titleHtml = titleParts.length > 1
                ? `${this.escapeHtml(titleParts[0])}<br><span class="pricing-period-subtitle">${this.escapeHtml(titleParts[1])}</span>`
                : this.escapeHtml(periodTitle);

            html += `<div class="pricing-period${isCurrent ? ' current' : ''}">
                <div class="pricing-period-header">
                    <span class="pricing-period-title">${titleHtml}</span>
                    ${isCurrent ? `<span class="pricing-current-badge"><i class="fas fa-arrow-down"></i> ${this.getTranslation('pricingCurrentLabel')}</span>` : ''}
                </div>`;

            period.items.forEach(item => {
                html += `<div class="pricing-item">
                    <span class="pricing-item-name">${this.escapeHtml(item.name)}</span>
                    <span class="pricing-item-price">${item.price}</span>
                </div>`;
            });

            // 閒日欄位新增「中學生減 $10」
            if (period.id === 'weekday') {
                html += `<div class="pricing-item-student">
                    <span class="pricing-student-text">${this.getTranslation('pricingStudentDiscount')}</span>
                </div>`;
            }

            html += `</div>`;
        });

        container.innerHTML = html;
    }

    async confirmPricing() {
        this.cancelReturnTimer();

        // 隱藏收費標準卡片，顯示人數選擇卡片
        document.getElementById('pricing-card').classList.add('hidden');
        this.clearPeopleSelection();
        document.getElementById('people-count-card').classList.remove('hidden');
    }

    // ========================================================================
    //  小朋友人數選擇
    // ========================================================================

    adjustSelectedChildrenCount(change) {
        const newCount = this.selectedChildrenCount + change;
        if (newCount < 0 || newCount > this.selectedPeopleCount) return;
        this.setSelectedChildrenCount(newCount);
    }

    setSelectedChildrenCount(count) {
        this.cancelReturnTimer();
        this.selectedChildrenCount = count;
        document.getElementById('children-count-selection').textContent = count;
        document.getElementById('decrease-children-btn').disabled = count <= 0;
        document.getElementById('increase-children-btn').disabled = count >= this.selectedPeopleCount;

        // 更新快速選擇按鈕的 active 狀態
        document.querySelectorAll('#children-count-card .btn-people').forEach(btn => {
            const btnCount = parseInt(btn.dataset.count);
            btn.classList.toggle('active', btnCount === count);
        });
    }

    /** 根據總人數顯示/隱藏小朋友人數按鈕，並重置選中狀態 */
    refreshChildrenButtons() {
        const maxTotal = this.selectedPeopleCount;
        document.querySelectorAll('#children-count-card .btn-people').forEach(btn => {
            const btnCount = parseInt(btn.dataset.count);
            btn.style.display = btnCount > maxTotal ? 'none' : '';
        });
        // 若當前選中數大於總人數，重置為0
        if (this.selectedChildrenCount > maxTotal) {
            this.setSelectedChildrenCount(0);
        }
    }

    /** 根據 store_id 取得小朋友比例限制規則 */
    getStoreChildrenRule() {
        const storeId = this.currentEmployee?.store_id;
        // store_1 (荃灣) / store_3 (旺角): 上限 2/3
        if (storeId === 'store_1' || storeId === 'store_3') {
            return { maxRatio: 2/3, errorKey: 'errorChildrenRatioStore13' };
        }
        // store_2 (尖沙咀) / store_4 (銅鑼灣): 上限 1/2
        if (storeId === 'store_2' || storeId === 'store_4') {
            return { maxRatio: 1/2, errorKey: 'errorChildrenRatioStore24' };
        }
        // 其他店舖不設限制
        return null;
    }

    async confirmChildrenCount() {
        if (this.isProcessing) {
            this.addMessage('正在處理中，請稍候...', 'warning');
            return;
        }

        this.cancelReturnTimer();
        this.isProcessing = true;

        try {
            this.childrenCount = this.selectedChildrenCount;

            // 基本驗證：小朋友人數不能大於總人數
            if (this.childrenCount > this.peopleCount) {
                alert(this.getTranslation('errorChildrenExceedTotal'));
                return;
            }

            // 根據店舖規則驗證比例
            const rule = this.getStoreChildrenRule();
            if (rule) {
                const adults = this.peopleCount - this.childrenCount;
                if (adults <= 0 && this.childrenCount > 0) {
                    // 沒有大人但有小朋友 → 不允許
                    this.showChildrenRatioError(this.getTranslation(rule.errorKey));
                    return;
                }
                const ratio = this.childrenCount / this.peopleCount;
                if (ratio > rule.maxRatio) {
                    this.showChildrenRatioError(this.getTranslation(rule.errorKey));
                    return;
                }
            }

            // 驗證通過，繼續流程
            document.getElementById('children-count-card').classList.add('hidden');

            if (this.visitorType === 'first-time') {
                // 第一次來的客人：顯示影片區域
                document.getElementById('video-section').classList.remove('hidden');
                this.startVideoPlayback();
            } else {
                // 之前來過的客人：跳過影片，直接開始入場處理
                console.log('confirmChildrenCount: calling processEntry with skipDuplicateCheck=true');
                try {
                    await this.processEntry(true);
                    this.updateVideoSectionToEntryGuidance();
                } catch (error) {
                    this.addMessage('入場處理失敗: ' + error.message, 'error');
                    document.getElementById('entry-panel').classList.remove('hidden');
                }
            }
        } catch (error) {
            this.addMessage('確認小朋友人數時發生錯誤: ' + error.message, 'error');
        } finally {
            this.isProcessing = false;
        }
    }

    getTranslation(key) {
        const translations = EntryMachine.translations[this.currentLanguage];
        return translations?.[key] || key;
    }

    showChildrenRatioError(message) {
        document.getElementById('children-ratio-error-message').textContent = message;
        document.getElementById('children-ratio-error-modal').classList.remove('hidden');
        // 綁定確認按鈕事件（用一次即清除，避免重複）
        const confirmBtn = document.getElementById('children-ratio-error-confirm-btn');
        const handler = () => {
            document.getElementById('children-ratio-error-modal').classList.add('hidden');
            confirmBtn.removeEventListener('click', handler);
            this.restartProcess();
        };
        confirmBtn.addEventListener('click', handler);
    }

    initMemberQRReader() {
        const qrInput = document.getElementById('member-qr-input');
        if (!qrInput) return;

        // 自動對焦輸入框
        const focusInput = () => {
            setTimeout(() => qrInput.focus(), 300);
        };
        focusInput();

        // 點擊讀取區也對焦輸入框
        const reader = document.getElementById('member-reader');
        if (reader) {
            reader.addEventListener('click', focusInput);
        }

        // QR Scanner 掃完後會輸入文字 + Enter
        let scanTimeout = null;
        qrInput.addEventListener('keydown', async (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                const cardId = qrInput.value.trim();
                qrInput.value = '';
                if (cardId) {
                    await this.lookupMemberCard(cardId);
                }
                // 重新對焦以便下次掃描
                setTimeout(() => qrInput.focus(), 100);
            } else {
                // 有按鍵輸入時取消返回計時器（用戶正在操作）
                this.cancelReturnTimer();
                // 清除超時，重新計時（掃描器連續輸入時不觸發）
                if (scanTimeout) clearTimeout(scanTimeout);
            }
        });
    }

    async lookupMemberCard(cardId) {
        this.addMessage(`正在查詢會員 QR Code...`, 'info');
        this.cancelReturnTimer();

        try {
            const response = await fetch('/api/entry/nfc-scan', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ cardId })
            });

            const result = await response.json();

            if (result.success && result.is_member) {
                this.memberCardId = cardId;
                this.memberInfo = result.member_info;
                this.showMemberInfo(result.member_info);
                this.addMessage(`會員驗證成功: ${result.member_info.name}`, 'success');
            } else {
                this.memberCardId = null;
                this.memberInfo = null;
                this.hideMemberInfo();
                this.addMessage('非會員 QR Code 或卡片無效', 'warning');
            }
        } catch (error) {
            this.memberCardId = null;
            this.memberInfo = null;
            this.hideMemberInfo();
            this.addMessage('會員查詢失敗: ' + error.message, 'error');
        }
    }

    showMemberInfo(memberInfo) {
        document.getElementById('member-name').textContent = memberInfo.name || '未提供';
        document.getElementById('member-balance').textContent = '$' + memberInfo.balance.toFixed(2);
        document.getElementById('member-info').classList.remove('hidden');
    }

    hideMemberInfo() {
        document.getElementById('member-info').classList.add('hidden');
    }

    async processEntry(skipDuplicateCheck = false) {
        console.log('processEntry called:', {
            skipDuplicateCheck,
            isProcessing: this.isProcessing,
            peopleCount: this.peopleCount,
            memberCardId: this.memberCardId
        });

        // 防止重複提交
        if (!skipDuplicateCheck && this.isProcessing) {
            console.log('processEntry: duplicate check prevented execution');
            this.addMessage('正在處理入場，請稍候...', 'warning');
            return;
        }

        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        this.isProcessing = true;

        // 顯示處理模態框
        this.showProcessingModal();

        try {
            // 步驟1: 驗證輸入
            this.updateProgress(1, 20, 'progressVerify');

            // 驗證人數
            if (typeof this.peopleCount !== 'number' || this.peopleCount < 1 || this.peopleCount > 10) {
                throw new Error(`無效的人數: ${this.peopleCount}。請選擇 1-10 位客人。`);
            }

            await this.delay(500);

            // 步驟2: 發送入場請求
            this.updateProgress(2, 40, 'progressAssignTable');
            console.log('processEntry: making API request with peopleCount=', this.peopleCount, 'memberCardId=', this.memberCardId);
            const response = await fetch('/api/entry/entry', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    peopleCount: this.peopleCount,
                    childrenCount: this.childrenCount || 0,
                    memberCardId: this.memberCardId,
                    store_id: this.currentEmployee?.store_id || null
                })
            });

            if (!response.ok) {
                // 嘗試獲取更詳細的錯誤訊息
                let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
                try {
                    const errorData = await response.json();
                    if (errorData.error) {
                        errorMessage = errorData.error;
                        if (errorData.message) {
                            errorMessage += ` - ${errorData.message}`;
                        }
                    }
                } catch (e) {
                    // 忽略JSON解析錯誤，使用默認錯誤訊息
                }

                // 檢查是否為滿座錯誤
                if (errorMessage.includes('暫時沒有合適的桌位，請稍後再試')) {
                    this.hideProcessingModal();
                    this.isProcessing = false; // 重置處理標誌
                    this.showFullSeatModal();
                    return; // 退出處理流程
                }

                console.log('processEntry: API request failed:', errorMessage);
                throw new Error(errorMessage);
            }

            console.log('processEntry: API request successful, status:', response.status);
            const result = await response.json();
            console.log('processEntry: API response:', result);

            // 步驟3: 分配儲物柜
            this.updateProgress(3, 60, 'progressAssignLocker');
            await this.delay(1000);

            // 步驟4: 生成QR Code
            this.updateProgress(4, 80, 'progressGenerateQR');
            await this.delay(500);

            // 步驟5: 打印小票
            this.updateProgress(5, 100, 'progressPrint');

            // 顯示結果
            await this.showResult(result);

            // 通過 Android APK USB 打印小票
            if (result.data && result.data.receipt_base64) {
                this.printReceiptViaUSB(result.data.receipt_base64);
            }

            // 等待模態框關閉（延遲一下讓用戶看到完成狀態）
            await new Promise(resolve => {
                setTimeout(() => {
                    this.hideProcessingModal();
                    this.addMessage(`入場處理完成: 桌號 ${result.data.table_number}`, 'success');
                    resolve();
                }, 1500);
            });

        } catch (error) {
            this.addMessage('入場處理失敗: ' + error.message, 'error');
            this.hideProcessingModal();
            throw error; // 重新拋出錯誤以便外層處理
        } finally {
            this.isProcessing = false; // 確保處理標誌被重置
        }
    }

    showProcessingModal() {
        document.getElementById('processing-modal').classList.remove('hidden');
        // 重置進度條
        this.updateProgress(1, 20, 'progressReady');
    }

    hideProcessingModal() {
        document.getElementById('processing-modal').classList.add('hidden');
    }

    showFullSeatModal() {
        document.getElementById('full-seat-modal').classList.remove('hidden');
    }

    hideFullSeatModal() {
        document.getElementById('full-seat-modal').classList.add('hidden');
    }

    /**
     * 顯示打印失敗警告（頂部浮動橫幅）
     */
    showPrintFailedAlert(data) {
        // 移除舊的警告
        const oldAlert = document.getElementById('print-failed-alert');
        if (oldAlert) oldAlert.remove();

        const alert = document.createElement('div');
        alert.id = 'print-failed-alert';
        alert.className = 'print-failed-alert';
        alert.innerHTML = `
            <div class="print-failed-content">
                <i class="fas fa-exclamation-triangle"></i>
                <div class="print-failed-text">
                    <strong>打印小票失敗！</strong>
                    <span>桌號 ${data.table_number} — 請聯絡工作人員手動補印</span>
                </div>
                <button class="print-failed-close" onclick="this.parentElement.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        document.body.appendChild(alert);
    }

    updateProgress(step, percent, i18nKey) {
        // 更新進度條
        document.getElementById('progress-fill').style.width = percent + '%';
        // 更新進度文字（查翻譯）
        const translations = EntryMachine.translations[this.currentLanguage] || {};
        const progressText = document.getElementById('progress-text');
        progressText.textContent = translations[i18nKey] || i18nKey;

        // 更新步驟狀態
        document.querySelectorAll('.step').forEach((stepEl, index) => {
            const span = stepEl.querySelector('span');
            const stepKey = span ? span.getAttribute('data-i18n') : null;
            const stepLabel = (stepKey && translations[stepKey]) ? translations[stepKey] : (span ? span.textContent : '');
            if (index + 1 < step) {
                stepEl.classList.add('completed');
                stepEl.classList.remove('active');
                stepEl.innerHTML = '<i class="fas fa-check-circle"></i><span' + (stepKey ? ' data-i18n="' + stepKey + '"' : '') + '>' + this.escapeHtml(stepLabel) + '</span>';
            } else if (index + 1 === step) {
                stepEl.classList.add('active');
                stepEl.classList.remove('completed');
                stepEl.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span' + (stepKey ? ' data-i18n="' + stepKey + '"' : '') + '>' + this.escapeHtml(stepLabel) + '</span>';
            } else {
                stepEl.classList.remove('active', 'completed');
                stepEl.innerHTML = '<i class="fas fa-circle"></i><span' + (stepKey ? ' data-i18n="' + stepKey + '"' : '') + '>' + this.escapeHtml(stepLabel) + '</span>';
            }
        });
    }

    async showResult(result) {
        if (!result.success) {
            this.addMessage('入場處理失敗: ' + result.error, 'error');
            return;
        }

        const data = result.data;

        // 保存QR Code資料（即使不顯示也保存）
        this.currentQRCode = data.qr_code;

        // 只有在入場面板可見時才顯示QR Code
        const entryPanel = document.getElementById('entry-panel');
        if (entryPanel && !entryPanel.classList.contains('hidden')) {
            this.displayQRCode(data.qr_code_image || data.qr_code);

            // 更新QR Code信息（如果元素存在）
            const qrTableNumber = document.getElementById('qr-table-number');
            const qrEntryTime = document.getElementById('qr-entry-time');
            const qrLockers = document.getElementById('qr-lockers');
            const qrCodeText = document.getElementById('qr-code-text');
            const copyQrBtn = document.getElementById('copy-qr-btn');

            if (qrTableNumber) qrTableNumber.textContent = data.table_number;
            if (qrEntryTime) qrEntryTime.textContent = formatDateTime();
            if (qrLockers) qrLockers.textContent = data.lockers.join(', ') || '無';
            if (qrCodeText) qrCodeText.textContent = data.qr_code;
            if (copyQrBtn) copyQrBtn.disabled = false;
        }

        // 播放音效（如果是會員則跳過）
        if (!data.skip_audio) {
            this.playWelcomeAudio();
        }

        // 添加到入場記錄
        this.addToRecentEntries(data);
    }

    displayQRCode(qrData) {
        const canvas = document.getElementById('qr-canvas');
        const placeholder = document.getElementById('qr-placeholder');

        if (!canvas || !placeholder) {
            console.log('QR Code顯示元素不存在，跳過顯示');
            return;
        }

        if (qrData.startsWith('data:image')) {
            // 如果是base64圖片
            const img = new Image();
            img.onload = () => {
                const ctx = canvas.getContext('2d');
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                placeholder.classList.add('hidden');
                canvas.classList.remove('hidden');
            };
            img.src = qrData;
        } else {
            // 如果是文本，使用簡單的QR Code生成（簡化版）
            placeholder.classList.add('hidden');
            canvas.classList.remove('hidden');

            const ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#000';
            ctx.font = '14px Arial';
            ctx.textAlign = 'center';
            ctx.fillText(qrData.substring(0, 20), canvas.width / 2, canvas.height / 2);
            ctx.fillText(qrData.substring(20, 40) || '', canvas.width / 2, canvas.height / 2 + 20);
        }
    }

    async loadTodayStats() {
        try {
            const response = await fetch('/api/entry/waiting');
            const result = await response.json();

            if (result.success) {
                const todayCount = result.customers.filter(c => {
                    const entryDate = this.parseEntryTime(c.entry_time).toDateString();
                    const today = new Date().toDateString();
                    return entryDate === today;
                }).length;

                const todayCountElement = document.getElementById('today-count');
                if (todayCountElement) {
                    todayCountElement.textContent = todayCount;
                }
            }
        } catch (error) {
            console.error('載入今日統計失敗:', error);
        }
    }

    async loadRecentEntries() {
        try {
            const response = await fetch('/api/entry/waiting');
            const result = await response.json();

            if (result.success) {
                this.recentEntries = result.customers;
                this.displayRecentEntries();
            }
        } catch (error) {
            console.error('載入入場記錄失敗:', error);
        }
    }

    displayRecentEntries() {
        const entriesList = document.getElementById('entries-list');

        // 如果元素不存在，直接返回
        if (!entriesList) {
            return;
        }

        if (this.recentEntries.length === 0) {
            entriesList.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-clock"></i>
                    <p>暫無入場記錄</p>
                </div>
            `;
            return;
        }

        entriesList.innerHTML = '';

        this.recentEntries.slice(0, 10).forEach(entry => {
            const entryTime = this.parseEntryTime(entry.entry_time).toLocaleTimeString('zh-TW', {
                hour: '2-digit',
                minute: '2-digit'
            });

            const status = entry.is_checked_out ? '已離場' : '在場中';
            const statusClass = entry.is_checked_out ? 'status-checked-out' : 'status-active';

            const entryEl = document.createElement('div');
            entryEl.className = 'entry-item';
            entryEl.innerHTML = `
                <span>${entryTime}</span>
                <span>${entry.table_number || entry.actual_table}</span>
                <span>${entry.people_count}位</span>
                <span class="${statusClass}">${status}</span>
            `;

            entriesList.appendChild(entryEl);
        });
    }

    addToRecentEntries(data) {
        const entry = {
            table_number: data.table_number,
            people_count: data.people_count,
            entry_time: new Date().toISOString(),
            is_checked_out: false
        };

        this.recentEntries.unshift(entry);
        if (this.recentEntries.length > 10) {
            this.recentEntries = this.recentEntries.slice(0, 10);
        }

        this.displayRecentEntries();
        this.loadTodayStats();
    }

    addMessage(text, type = 'info') {
        // 系統訊息頁面已移除，改為控制台輸出
        const now = new Date();
        const timeString = now.toLocaleTimeString('zh-TW', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });

        const logPrefix = `[${timeString}]`;
        const styledPrefix = `%c${logPrefix}`;
        const style = this.getConsoleStyle(type);

        // 輸出到控制台
        console.log(`${styledPrefix} ${text}`, style);
    }

    getConsoleStyle(type) {
        const styles = {
            'info': 'color: #3498db; font-weight: bold',
            'success': 'color: #27ae60; font-weight: bold',
            'warning': 'color: #f39c12; font-weight: bold',
            'error': 'color: #e74c3c; font-weight: bold'
        };
        return styles[type] || styles.info;
    }



    async copyQRCode() {
        if (!this.currentQRCode) {
            this.addMessage('請先生成QR Code', 'warning');
            return;
        }

        try {
            await navigator.clipboard.writeText(this.currentQRCode);
            this.addMessage('QR Code已複製到剪貼板', 'success');
        } catch (error) {
            this.addMessage('複製失敗: ' + error.message, 'error');
        }
    }

    // 測試功能
    async testPrint() {
        try {
            const response = await fetch('/api/entry/test-printer', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    text: '入場機器 USB 打印測試\n' + formatDateTime()
                })
            });

            const result = await response.json();
            if (result.success) {
                this.addMessage('✅ USB 打印測試成功 (KPOS_216)', 'success');
            } else {
                this.addMessage('❌ 打印測試失敗: ' + (result.message || result.error), 'error');
            }
        } catch (error) {
            this.addMessage('❌ 打印測試失敗: ' + error.message, 'error');
        }
    }

    async testLocker() {
        try {
            const response = await fetch('/api/entry/open-locker', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    locker_number: Math.floor(Math.random() * 10) + 1
                })
            });

            const result = await response.json();
            this.addMessage('測試儲物柜指令已發送', 'info');
        } catch (error) {
            this.addMessage('測試儲物柜失敗: ' + error.message, 'error');
        }
    }

    async testPrinter() {
        try {
            const response = await fetch('/api/entry/test-printer', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    text: '打印機測試 - 自動進場系統\n' + formatDateTime()
                })
            });

            const result = await response.json();
            if (result.success) {
                this.addMessage('✅ USB 打印機測試成功', 'success');
            } else {
                this.addMessage('❌ 打印機測試失敗: ' + (result.message || result.error), 'error');
            }
        } catch (error) {
            this.addMessage('❌ 打印機測試失敗: ' + error.message, 'error');
        }
    }

    resetPrinter() {
        this.addMessage('打印機重置指令已發送', 'warning');
        // 實際環境中會發送硬件重置指令
    }

    testLockerSystem() {
        this.addMessage('儲物柜系統測試指令已發送', 'info');
        // 實際環境中會測試所有儲物柜
    }

    resetLockerSystem() {
        this.addMessage('儲物柜系統重置指令已發送', 'warning');
        // 實際環境中會重置儲物柜控制器
    }

    testAudio() {
        this.addMessage('播放歡迎音效', 'info');
        this.playWelcomeAudio();
    }

    stopAudio() {
        this.addMessage('停止音效播放', 'info');
        // 實際環境中會停止音頻播放
    }

    testMemberScan() {
        this.addMessage('會員 QR Code 掃描器測試中...', 'info');
        setTimeout(() => {
            this.addMessage('✓ QR Code 掃描器就緒', 'success');
        }, 500);
    }

    resetMemberReader() {
        this.addMessage('會員掃描器已重置', 'warning');
        this.hideMemberInfo();
        this.memberCardId = null;
        this.memberInfo = null;
        const qrInput = document.getElementById('member-qr-input');
        if (qrInput) {
            qrInput.value = '';
            qrInput.focus();
        }
    }

    playWelcomeAudio() {
        // 實際環境中會播放音頻文件
        this.addMessage('播放歡迎錄音', 'info');

        // 模擬音頻播放
        try {
            const AudioContextClass = window.AudioContext || window.webkitAudioContext;
            if (!AudioContextClass) {
                throw new Error('Web Audio API not supported');
            }
            const audioContext = new AudioContextClass();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();

            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);

            oscillator.frequency.value = 440;
            oscillator.type = 'sine';

            gainNode.gain.setValueAtTime(0, audioContext.currentTime);
            gainNode.gain.linearRampToValueAtTime(0.1, audioContext.currentTime + 0.1);
            gainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + 0.5);

            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.5);

            this.addMessage('歡迎錄音播放完成', 'success');
        } catch (error) {
            this.addMessage('音頻播放模擬失敗: ' + error.message, 'warning');
        }
    }

    cancelProcessing() {
        this.hideProcessingModal();
        this.addMessage('入場處理已取消', 'warning');
    }

    // ===== 登入相關方法 =====

    checkSavedLogin() {
        try {
            const savedToken = sessionStorage.getItem('entry_token');
            const savedEmployee = sessionStorage.getItem('entry_employee');
            const savedExpires = sessionStorage.getItem('entry_token_expires');

            if (savedToken && savedEmployee && savedExpires) {
                const expiresAt = new Date(savedExpires);
                if (expiresAt > new Date()) {
                    this.currentToken = savedToken;
                    this.currentEmployee = JSON.parse(savedEmployee);
                    this.tokenExpiresAt = expiresAt;
                    this.isAuthenticated = true;
                    this.updateLoginUI();
                    // 有有效token，立即隱藏登入遮罩
                    this.hideForcedLogin();
                    return;
                }
                // 令牌過期，清除
                this.clearSavedLogin();
            }
        } catch (error) {
            console.error('檢查登入狀態失敗:', error);
            this.clearSavedLogin();
        }

        // 未登入或令牌已過期，強制顯示登入
        this.showForcedLogin();
    }

    showForcedLogin() {
        // 顯示遮罩和登入模態框（無取消按鈕）
        const overlay = document.getElementById('login-overlay');
        if (overlay) overlay.classList.remove('hidden');
        document.body.classList.add('login-required');
        this.showLoginModal(true);
    }

    hideForcedLogin() {
        const overlay = document.getElementById('login-overlay');
        if (overlay) overlay.classList.add('hidden');
        document.body.classList.remove('login-required');
        this.hideLoginModal();
    }

    saveLoginToStorage(token, employee, expiresAt) {
        try {
            sessionStorage.setItem('entry_token', token);
            sessionStorage.setItem('entry_employee', JSON.stringify(employee));
            if (expiresAt) {
                sessionStorage.setItem('entry_token_expires', expiresAt);
            }
        } catch (error) {
            console.error('保存登入信息失敗:', error);
        }
    }

    clearSavedLogin() {
        sessionStorage.removeItem('entry_token');
        sessionStorage.removeItem('entry_employee');
        sessionStorage.removeItem('entry_token_expires');
    }

    updateLoginUI() {
        const loginBtn = document.getElementById('staff-login-btn');
        const loginText = document.getElementById('login-btn-text');
        // 退出按鈕只有登入後才顯示
        const exitBtn = document.getElementById('exit-app-btn');
        if (exitBtn) exitBtn.classList.toggle('hidden', !this.isAuthenticated);
        if (this.isAuthenticated && this.currentEmployee) {
            loginBtn.classList.add('logged-in');
            loginText.textContent = this.currentEmployee.full_name || '已登入';
            loginBtn.title = '點擊登出';
        } else {
            loginBtn.classList.remove('logged-in');
            loginText.textContent = '登入';
            loginBtn.title = '';
        }
    }

    showLoginModal(force = false) {
        const loginModal = document.getElementById('login-modal');
        const loginForm = document.getElementById('login-form');
        if (!loginModal || !loginForm) return;

        loginForm.reset();
        loginModal.classList.remove('hidden');

        // 強制登入模式：隱藏取消按鈕
        const cancelBtn = document.getElementById('cancel-login-btn');
        if (cancelBtn) {
            cancelBtn.style.display = force ? 'none' : '';
        }
    }

    hideLoginModal() {
        const loginModal = document.getElementById('login-modal');
        if (loginModal) loginModal.classList.add('hidden');
    }

    async handleLoginSubmit(event) {
        event.preventDefault();

        const username = document.getElementById('login-username').value.trim();
        const password = document.getElementById('login-password').value;

        if (!username || !password) return;

        const submitBtn = document.getElementById('submit-login-btn');
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 登入中...';
        }

        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });

            const result = await response.json();

            if (response.ok && result.success) {
                const { employee, token, expires_at } = result.data || {};
                this.currentToken = token;
                this.currentEmployee = employee;
                this.isAuthenticated = true;

                // 計算過期時間（預設24小時）
                const expiresAt = expires_at ? new Date(expires_at) : new Date();
                if (!expires_at) expiresAt.setHours(expiresAt.getHours() + 24);
                this.tokenExpiresAt = expiresAt;

                this.saveLoginToStorage(token, employee, expiresAt.toISOString());
                this.updateLoginUI();
                this.hideForcedLogin();
                this.addMessage(`登入成功，歡迎 ${result.employee.full_name}`, 'success');
            } else {
                this.addMessage(`登入失敗: ${result.message || '帳號或密碼錯誤'}`, 'error');
                // 登入失敗時重置按鈕
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '登入';
                }
            }
        } catch (error) {
            this.addMessage(`登入請求失敗: ${error.message}`, 'error');
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '登入';
            }
        }
    }

    logout() {
        this.isAuthenticated = false;
        this.currentEmployee = null;
        this.currentToken = null;
        this.tokenExpiresAt = null;
        this.clearSavedLogin();
        this.updateLoginUI();
        this.addMessage('已登出', 'info');
        // 入場機器需要登入才能使用，登出後強制顯示登入
        this.showForcedLogin();
    }

    // ===== 退出 App（重新驗證登入帳號密碼）=====

    showExitModal() {
        const exitModal = document.getElementById('exit-app-modal');
        const exitForm = document.getElementById('exit-form');
        if (!exitModal || !exitForm) return;

        // 重置表單後，預填已登入的帳號（唯讀，必須與登入帳號一致）
        exitForm.reset();
        const usernameInput = document.getElementById('exit-username');
        if (usernameInput && this.currentEmployee) {
            usernameInput.value = this.currentEmployee.username || '';
        }
        this.hideExitError();
        exitModal.classList.remove('hidden');

        // 自動聚焦密碼輸入框
        const passwordInput = document.getElementById('exit-password');
        if (passwordInput) setTimeout(() => passwordInput.focus(), 300);
    }

    hideExitModal() {
        const exitModal = document.getElementById('exit-app-modal');
        if (exitModal) exitModal.classList.add('hidden');
    }

    showExitError(message) {
        const err = document.getElementById('exit-error');
        if (err) {
            err.textContent = message;
            err.classList.remove('hidden');
        }
    }

    hideExitError() {
        const err = document.getElementById('exit-error');
        if (err) err.classList.add('hidden');
    }

    async handleExitSubmit(event) {
        event.preventDefault();
        this.hideExitError();

        const username = document.getElementById('exit-username').value.trim();
        const password = document.getElementById('exit-password').value;
        if (!username || !password) return;

        const submitBtn = document.getElementById('submit-exit-btn');
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 驗證中...';
        }

        try {
            // 用同一套登入 API 驗證帳號密碼
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });
            const result = await response.json();

            // 帳號必須與已登入的帳號一致
            const loggedUsername = (this.currentEmployee?.username || '').toLowerCase();
            const enteredUsername = (result.data?.employee?.username || username).toLowerCase();
            if (response.ok && result.success && enteredUsername === loggedUsername) {
                this.addMessage('驗證成功，退出系統', 'info');
                this.exitApp();
            } else {
                this.showExitError('帳號或密碼不正確');
                this.addMessage('退出驗證失敗: 帳號或密碼不正確', 'error');
            }
        } catch (error) {
            this.showExitError('驗證失敗: ' + error.message);
            this.addMessage('退出驗證請求失敗: ' + error.message, 'error');
        } finally {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '確認退出';
            }
        }
    }

    exitApp() {
        if (window.AutoCafeApp && typeof window.AutoCafeApp.exitApp === 'function') {
            this.hideExitModal();
            window.AutoCafeApp.exitApp();
        } else {
            this.showExitError('無法退出：非 App 環境');
            this.addMessage('⚠️ 未偵測到 App bridge，無法退出', 'warning');
        }
    }

    // ===== 健康檢查（主機 + 打印機連線）=====

    /**
     * 啟動 30 秒定時健康檢查
     */
    startHealthCheckSchedule() {
        if (this.healthCheckTimer) return;
        // 初始設為黃色（檢查中）
        this.updateDeviceStatus(null, null);
        // 啟動後立即檢查一次
        this.checkHealth();
        this.healthCheckTimer = setInterval(() => this.checkHealth(), 10000);
        console.log('[health] 健康檢查已啟動 (每10秒)');
    }

    /**
     * 停止 30 秒定時健康檢查
     */
    stopHealthCheckSchedule() {
        if (this.healthCheckTimer) {
            clearInterval(this.healthCheckTimer);
            this.healthCheckTimer = null;
        }
    }

    /**
     * 更新右上角主機/打印機狀態指示燈
     * @param {boolean|null} hostOk  true=正常 false=失敗 null=檢查中
     * @param {boolean|null} printerOk
     */
    updateDeviceStatus(hostOk, printerOk) {
        const hostDot = document.querySelector('#host-status-indicator .device-status-dot');
        const printerDot = document.querySelector('#printer-status-indicator .device-status-dot');

        if (hostDot) {
            hostDot.className = 'device-status-dot ' +
                (hostOk === null ? 'status-checking' : hostOk ? 'status-ok' : 'status-fail');
        }
        if (printerDot) {
            printerDot.className = 'device-status-dot ' +
                (printerOk === null ? 'status-checking' : printerOk ? 'status-ok' : 'status-fail');
        }
    }

    /**
     * 檢查 Android 本地 USB 打印機（EM5827）
     * @returns {boolean} true=已連接, false=未連接/無橋接
     */
    checkAndroidPrinter() {
        try {
            if (window.AndroidPrinter) {
                const json = AndroidPrinter.getPrinterStatus();
                console.log('[health] AndroidPrinter:', json);
                const info = JSON.parse(json);
                const debugEl = document.getElementById('printer-debug');
                if (debugEl) {
                    debugEl.textContent = 'USB: ' + (info.connected ? '✅ 已連' : '❌ 未連') + ' ' + (info.devices ? info.devices.length+'裝置' : '');
                    debugEl.title = json;
                }
                if (!info.connected) {
                    console.log('[health] 打印機未連接, devices:', info.devices || info.error);
                }
                return info.connected === true;
            } else {
                const debugEl = document.getElementById('printer-debug');
                if (debugEl) debugEl.textContent = 'USB: ⚪ 無Bridge';
                return false;
            }
        } catch (e) {
            console.log('[health] AndroidPrinter bridge error:', e.message);
            const debugEl = document.getElementById('printer-debug');
            if (debugEl) debugEl.textContent = 'USB: ⚠️ ' + e.message.substring(0,20);
            return false;
        }
    }

    /**
     * 通過 AndroidPrinter bridge USB 打印小票（base64 ESC/POS 數據）
     */
    printReceiptViaUSB(base64Data) {
        try {
            if (window.AndroidPrinter) {
                const json = AndroidPrinter.printReceipt(base64Data);
                const result = JSON.parse(json);
                console.log('[print] USB 打印結果:', result);
                if (result.success) {
                    this.addMessage(`✅ USB 打印成功 (${result.bytes} bytes)`, 'success');
                } else if (result.error === 'need_permission') {
                    this.addMessage('⚠️ 請允許 USB 權限後重試', 'warning');
                    // 5秒後自動再試
                    setTimeout(() => {
                        const retry = AndroidPrinter.printReceipt(base64Data);
                        const retryResult = JSON.parse(retry);
                        if (retryResult.success) {
                            this.addMessage(`✅ USB 打印成功 (${retryResult.bytes} bytes)`, 'success');
                        } else {
                            this.addMessage('❌ USB 打印失敗: ' + (retryResult.error || '未知錯誤'), 'error');
                        }
                    }, 5000);
                } else {
                    this.addMessage('❌ USB 打印失敗: ' + (result.error || '未知錯誤'), 'error');
                }
            } else {
                this.addMessage('⚠️ 無 AndroidPrinter bridge，無法 USB 打印', 'warning');
            }
        } catch (e) {
            console.log('[print] USB 打印異常:', e.message);
            this.addMessage('❌ USB 打印異常: ' + e.message, 'error');
        }
    }

    /**
     * 執行一次健康檢查，檢查主機與打印機連線狀態
     */
    async checkHealth() {
        let hostOk = false;
        let printerOk = false;

        try {
            const response = await fetch('/api/entry/health');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const result = await response.json();

            if (result.success && result.data) {
                hostOk = result.data.host === 'ok';
                // Server 已唔再 check printer（printer 喺 Android 度）
                // 改用 native bridge 偵測 USB 打印機
                printerOk = this.checkAndroidPrinter();
            }
        } catch (error) {
            // fetch 失敗代表主機不可達
            hostOk = false;
            printerOk = false;
        }

        // 無論成功或失敗，都更新指示燈
        this.updateDeviceStatus(hostOk, printerOk);

        if (hostOk && printerOk) {
            this.onHealthRecovered();
        } else {
            this.onHealthFailed(hostOk, printerOk);
        }
    }

    /**
     * 連線恢復處理
     */
    onHealthRecovered() {
        if (!this.connectionHealthy) {
            console.log('[health] 連線已恢復');
            this.connectionHealthy = true;
            this.hideConnectionBlocked();
            this.stopRecoveryCheck();
            // 隱藏「點擊重連」按鈕、恢復嘗試文字顯示
            const retryBtn = document.getElementById('retry-connection-btn');
            if (retryBtn) retryBtn.classList.add('hidden');
            const attemptEl = document.getElementById('connection-error-attempt');
            if (attemptEl) {
                attemptEl.classList.remove('hidden');
                attemptEl.textContent = '正在嘗試重新連線...';
            }
            // 重啟 30 秒定時檢查
            this.stopHealthCheckSchedule();
            this.startHealthCheckSchedule();
        }
    }

    /**
     * 連線失敗處理
     */
    onHealthFailed(hostOk, printerOk) {
        if (this.connectionHealthy) {
            // 首次失敗：顯示遮罩，啟動 2 秒恢復檢查
            console.log('[health] 連線失敗:', { hostOk, printerOk });
            this.connectionHealthy = false;
            this.stopHealthCheckSchedule();
            this.showConnectionBlocked(hostOk, printerOk);
            this.startRecoveryCheck();
        }
        // 若已在恢復模式，checkHealth 由 recovery timer 驅動，這裡不重複啟動
    }

    /**
     * 啟動 2 秒恢復檢查（最多 30 次）
     */
    startRecoveryCheck() {
        if (this.recoveryTimer) return;

        this.recoveryAttempts = 0;
        console.log('[health] 啟動恢復檢查 (每2秒，最多30次)');

        this.recoveryTimer = setInterval(() => {
            this.recoveryAttempts++;
            // 更新 UI 上的嘗試次數
            const attemptEl = document.getElementById('connection-error-attempt');
            if (attemptEl) {
                attemptEl.textContent = `正在嘗試重新連線... (${this.recoveryAttempts}/${this.maxRecoveryAttempts})`;
            }

            if (this.recoveryAttempts >= this.maxRecoveryAttempts) {
                // 超過 30 次仍無法連線，顯示「點擊重連」按鈕
                console.log('[health] 恢復檢查已達上限，顯示手動重連按鈕');
                this.stopRecoveryCheck();
                const attemptEl = document.getElementById('connection-error-attempt');
                if (attemptEl) attemptEl.classList.add('hidden');
                const retryBtn = document.getElementById('retry-connection-btn');
                if (retryBtn) retryBtn.classList.remove('hidden');
                return;
            }

            this.checkHealth();
        }, 2000);
    }

    /**
     * 停止恢復檢查
     */
    stopRecoveryCheck() {
        if (this.recoveryTimer) {
            clearInterval(this.recoveryTimer);
            this.recoveryTimer = null;
        }
        this.recoveryAttempts = 0;
    }

    /**
     * 手動點擊重連
     */
    async retryConnection() {
        console.log('[health] 用戶點擊「點擊重連」');
        const retryBtn = document.getElementById('retry-connection-btn');
        if (retryBtn) retryBtn.classList.add('hidden');
        const attemptEl = document.getElementById('connection-error-attempt');
        if (attemptEl) {
            attemptEl.classList.remove('hidden');
            attemptEl.textContent = '正在嘗試重新連線...';
        }
        await this.checkHealth();
        // 一次檢查失敗，再顯示「點擊重連」按鈕讓用戶可重複按
        if (!this.connectionHealthy) {
            if (attemptEl) attemptEl.classList.add('hidden');
            if (retryBtn) retryBtn.classList.remove('hidden');
        }
    }

    /**
     * 顯示連線錯誤遮罩，阻止使用者操作
     */
    showConnectionBlocked(hostOk, printerOk) {
        // 組合錯誤訊息
        const failed = [];
        if (!hostOk) failed.push('主機');
        if (!printerOk) failed.push('打印機');

        const msg = failed.join('/') + '連線失敗';
        const msgEl = document.getElementById('connection-error-message');
        const attemptEl = document.getElementById('connection-error-attempt');
        if (msgEl) msgEl.textContent = msg;
        if (attemptEl) attemptEl.textContent = '正在嘗試重新連線...';

        // 顯示遮罩
        const overlay = document.getElementById('connection-error-overlay');
        if (overlay) overlay.classList.remove('hidden');
    }

    /**
     * 隱藏連線錯誤遮罩，恢復正常操作
     */
    hideConnectionBlocked() {
        const overlay = document.getElementById('connection-error-overlay');
        if (overlay) overlay.classList.add('hidden');
    }

    // ===== 工具方法 =====

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }
}

// 初始化應用
document.addEventListener('DOMContentLoaded', () => {
    window.entryMachine = new EntryMachine();
});

// 添加一些CSS樣式到文檔中
const style = document.createElement('style');
style.textContent = `
    .status-active { color: #4CAF50; font-weight: 600; }
    .status-checked-out { color: #6c757d; }
`;
document.head.appendChild(style);