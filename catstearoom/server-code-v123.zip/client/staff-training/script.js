/**
 * 員工考核頁流程控制
 *
 * 步驟：填寫資料 → 閱讀培訓內容 → 回答測驗 → 查看成績
 *
 * 評分由伺服器負責（POST /api/staff-training/submit），
 * 前端只保存「已選項目」，唔會持有正確答案。
 */

(function () {
    'use strict';

    var state = {
        employeeName: '',
        role: '',
        questions: [],
        totalQuestions: 0,
        selected: {},        // { 題號: [optionIndex, ...] }
        startedAt: 0,
        submitting: false
    };

    // ── DOM 快取 ──

    var screens = {
        start: document.getElementById('screen-start'),
        content: document.getElementById('screen-content'),
        quiz: document.getElementById('screen-quiz'),
        result: document.getElementById('screen-result')
    };

    var stepIndicator = document.getElementById('stepIndicator');
    var progressFill = document.getElementById('progressFill');
    var startError = document.getElementById('startError');
    var quizError = document.getElementById('quizError');
    var answeredCount = document.getElementById('answeredCount');
    var btnStart = document.getElementById('btnStart');
    var btnToQuiz = document.getElementById('btnToQuiz');
    var btnSubmit = document.getElementById('btnSubmit');
    var btnRestart = document.getElementById('btnRestart');

    // ── 步驟切換 ──

    function showScreen(name) {
        Object.keys(screens).forEach(function (key) {
            screens[key].hidden = (key !== name);
        });

        var stepOrder = { start: 1, content: 2, quiz: 3, result: 4 };
        var current = stepOrder[name];

        Array.prototype.forEach.call(stepIndicator.children, function (el) {
            el.classList.toggle('is-active', Number(el.dataset.step) === current);
        });
        progressFill.style.width = (current / 4 * 100) + '%';

        window.scrollTo(0, 0);
    }

    // ── 步驟 1：填寫資料 ──

    btnStart.addEventListener('click', function () {
        var nameInput = document.getElementById('inputName');
        var name = nameInput.value.trim();
        var roleEl = document.querySelector('input[name="role"]:checked');

        if (!name) {
            showError(startError, '請輸入姓名');
            nameInput.focus();
            return;
        }
        if (!roleEl) {
            showError(startError, '請選擇職位');
            return;
        }

        hideError(startError);
        state.employeeName = name;
        state.role = roleEl.value;

        renderContent();
        showScreen('content');
    });

    // ── 步驟 2：培訓內容 ──

    function renderContent() {
        // 依職位揀軌別：FT 睇全職版，PT 睇兼職版
        var byTrack = window.TRAINING_CONTENT;
        var data = byTrack && byTrack[state.role];
        if (!data) return;

        document.getElementById('contentTitle').textContent = data.title;

        var body = document.getElementById('contentBody');
        body.innerHTML = '';

        data.sections.forEach(function (section) {
            var wrap = document.createElement('div');
            wrap.className = 'content-section';

            var h3 = document.createElement('h3');
            h3.textContent = section.heading;
            wrap.appendChild(h3);

            if (section.note) {
                var note = document.createElement('p');
                note.className = 'content-note';
                note.textContent = section.note;
                wrap.appendChild(note);
            }

            var list = document.createElement('ul');
            list.className = 'content-list';

            section.items.forEach(function (item) {
                var li = document.createElement('li');

                if (typeof item === 'string') {
                    li.textContent = item;
                } else {
                    if (item.text) {
                        var label = document.createElement('div');
                        label.textContent = item.text;
                        li.appendChild(label);
                    }
                    if (item.script) {
                        li.appendChild(buildScriptBlock(item.script));
                    }
                    if (item.sub) {
                        var subList = document.createElement('ul');
                        subList.className = 'content-sublist';
                        item.sub.forEach(function (s) {
                            var subLi = document.createElement('li');
                            subLi.textContent = s;
                            subList.appendChild(subLi);
                        });
                        li.appendChild(subList);
                    }
                }

                list.appendChild(li);
            });

            wrap.appendChild(list);
            body.appendChild(wrap);
        });
    }

    function buildScriptBlock(lines) {
        var block = document.createElement('div');
        block.className = 'script-block';
        lines.forEach(function (line) {
            var div = document.createElement('div');
            div.textContent = line;
            block.appendChild(div);
        });
        return block;
    }

    btnToQuiz.addEventListener('click', function () {
        loadQuiz();
    });

    // ── 步驟 3：測驗 ──

    function loadQuiz() {
        btnToQuiz.disabled = true;
        btnToQuiz.textContent = '載入中…';

        fetch('/api/staff-training/quiz?track=' + encodeURIComponent(state.role))
            .then(function (res) {
                if (!res.ok) throw new Error('HTTP ' + res.status);
                return res.json();
            })
            .then(function (data) {
                if (!data.success) throw new Error('載入失敗');

                state.questions = data.questions;
                state.totalQuestions = data.questions.length;
                state.selected = {};
                state.startedAt = Date.now();

                document.getElementById('quizTotal').textContent = state.totalQuestions;
                document.getElementById('quizTotal2').textContent = state.totalQuestions;

                renderQuiz();
                showScreen('quiz');
            })
            .catch(function (err) {
                console.error('載入測驗失敗:', err);
                showError(startError, '無法載入測驗題目，請檢查網絡後重新開始');
                showScreen('start');
            })
            .finally(function () {
                btnToQuiz.disabled = false;
                btnToQuiz.textContent = '我已閱讀完畢，開始測驗';
            });
    }

    function renderQuiz() {
        var body = document.getElementById('quizBody');
        body.innerHTML = '';

        state.questions.forEach(function (q, index) {
            var wrap = document.createElement('div');
            wrap.className = 'question';
            wrap.dataset.questionNumber = q.number;

            var head = document.createElement('div');
            head.className = 'question-head';

            var num = document.createElement('span');
            num.className = 'q-number';
            num.textContent = (index + 1);

            var text = document.createElement('span');
            text.className = 'q-text';
            text.textContent = q.text;

            head.appendChild(num);
            head.appendChild(text);
            wrap.appendChild(head);

            // 本頁所有題目皆為多選題
            q.options.forEach(function (optionText, optIndex) {
                var label = document.createElement('label');
                label.className = 'option';

                var input = document.createElement('input');
                input.type = 'checkbox';
                input.value = optIndex;
                input.addEventListener('change', function () {
                    onOptionChange(q.number, optIndex, input.checked);
                });

                var span = document.createElement('span');
                span.className = 'option-text';
                span.textContent = optionText;

                label.appendChild(input);
                label.appendChild(span);
                wrap.appendChild(label);
            });

            body.appendChild(wrap);
        });

        updateAnsweredCount();
    }

    function onOptionChange(questionNumber, optIndex, checked) {
        var picked = state.selected[questionNumber] || [];

        if (checked) {
            if (picked.indexOf(optIndex) === -1) picked.push(optIndex);
        } else {
            picked = picked.filter(function (i) { return i !== optIndex; });
        }

        if (picked.length) {
            state.selected[questionNumber] = picked;
        } else {
            delete state.selected[questionNumber];
        }

        updateAnsweredCount();
    }

    function updateAnsweredCount() {
        answeredCount.textContent = Object.keys(state.selected).length;
    }

    btnSubmit.addEventListener('click', function () {
        if (state.submitting) return;

        var unanswered = state.questions
            .filter(function (q) { return !state.selected[q.number]; })
            .map(function (q) { return q.number; });

        if (unanswered.length) {
            showError(quizError, '還有 ' + unanswered.length + ' 題未作答（第 ' + unanswered.join('、') + ' 題），請完成後再提交');
            var firstEl = document.querySelector('.question[data-question-number="' + unanswered[0] + '"]');
            if (firstEl) firstEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
            return;
        }

        hideError(quizError);
        submitQuiz();
    });

    function submitQuiz() {
        state.submitting = true;
        btnSubmit.disabled = true;
        btnSubmit.textContent = '提交中…';

        var payload = {
            employeeName: state.employeeName,
            role: state.role,
            responses: state.selected,
            durationSeconds: Math.round((Date.now() - state.startedAt) / 1000)
        };

        fetch('/api/staff-training/submit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
            .then(function (res) {
                return res.json().then(function (data) {
                    return { ok: res.ok, data: data };
                });
            })
            .then(function (result) {
                if (!result.ok || !result.data.success) {
                    throw new Error(result.data && result.data.message ? result.data.message : '提交失敗');
                }
                renderResult(result.data);
                showScreen('result');
            })
            .catch(function (err) {
                console.error('提交測驗失敗:', err);
                showError(quizError, err.message || '網絡錯誤，請稍後再試');
            })
            .finally(function () {
                state.submitting = false;
                btnSubmit.disabled = false;
                btnSubmit.textContent = '提交答案';
            });
    }

    // ── 步驟 4：成績 ──

    function renderResult(data) {
        var badge = document.getElementById('resultBadge');
        badge.textContent = data.passed ? '及格' : '不及格';
        badge.className = 'result-badge ' + (data.passed ? 'is-pass' : 'is-fail');

        document.getElementById('resultScore').textContent = data.percentage + '%';
        document.getElementById('resultLine').textContent =
            '答對 ' + data.correct + ' / ' + data.total + ' 題';
        document.getElementById('resultSub').textContent =
            data.employeeName + '（' + data.role + '）　及格標準：' + data.passPercentage + '%';

        renderReview(data);
    }

    /**
     * 作答紀錄：逐題列出題目同員工揀咗嘅答案。
     *
     * 正確答案只留喺伺服器（見 server/routes/staffTrainingRoutes.js），
     * 呢度只顯示「員工自己揀咗邊個選項」同該題答對定答錯，
     * 唔會顯示正確答案。
     */
    function renderReview(data) {
        var card = document.getElementById('reviewCard');
        var list = document.getElementById('reviewList');
        var summary = document.getElementById('reviewSummary');
        if (!card || !list || !summary) return;

        var wrongIds = (data.wrongQuestionIds || []).map(Number);
        var wrongSet = {};
        wrongIds.forEach(function (n) { wrongSet[n] = true; });

        list.innerHTML = '';

        state.questions
            .slice()
            .sort(function (a, b) { return a.number - b.number; })
            .forEach(function (q) {
                var picked = state.selected[q.number] || [];
                var isWrong = wrongSet[Number(q.number)] === true;

                var item = document.createElement('div');
                item.className = 'review-item ' + (isWrong ? 'is-wrong' : 'is-correct');

                var head = document.createElement('div');
                head.className = 'review-head';

                var num = document.createElement('span');
                num.className = 'review-num';
                num.textContent = '第 ' + q.number + ' 題';
                head.appendChild(num);

                var status = document.createElement('span');
                status.className = 'review-status';
                if (!picked.length) {
                    status.classList.add('is-unanswered');
                    status.textContent = '未作答';
                } else {
                    status.textContent = isWrong ? '答錯' : '答對';
                }
                head.appendChild(status);

                item.appendChild(head);

                var text = document.createElement('p');
                text.className = 'review-text';
                text.textContent = q.text;
                item.appendChild(text);

                var options = document.createElement('ul');
                options.className = 'review-options';

                q.options.forEach(function (optionText, optIndex) {
                    var wasPicked = picked.indexOf(optIndex) !== -1;

                    var li = document.createElement('li');
                    li.className = 'review-option' + (wasPicked ? ' is-picked' : '');

                    var mark = document.createElement('span');
                    mark.className = 'review-mark';
                    mark.textContent = wasPicked ? '✓' : '';

                    var label = document.createElement('span');
                    label.textContent = optionText;

                    li.appendChild(mark);
                    li.appendChild(label);
                    options.appendChild(li);
                });

                item.appendChild(options);
                list.appendChild(item);
            });

        var unanswered = state.questions.filter(function (q) {
            return !(state.selected[q.number] || []).length;
        }).length;

        summary.textContent = '共 ' + state.questions.length + ' 題，答錯 ' + wrongIds.length + ' 題'
            + (unanswered ? '（其中 ' + unanswered + ' 題未作答）' : '')
            + '。以下逐題列出你揀咗嘅答案。';

        card.hidden = false;
    }

    btnRestart.addEventListener('click', function () {
        // 重新考核：返去培訓內容（保留姓名／職位），可以重讀後再考，
        // 唔使重新填一次資料。
        state.selected = {};
        state.questions = [];
        showScreen('content');
    });

    // ── 工具 ──

    function showError(el, message) {
        el.textContent = message;
        el.hidden = false;
    }

    function hideError(el) {
        el.textContent = '';
        el.hidden = true;
    }

    showScreen('start');
})();
