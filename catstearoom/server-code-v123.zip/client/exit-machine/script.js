// 離場機器前端邏輯

// 機器用途（用途設定）
//   both        = 桌號與商品結賬（預設；先試入場小票二維碼，唔中再試商品條碼）
//   table       = 桌號結賬（只接受入場小票二維碼）
//   product     = 商品結賬（只接受商品條碼，累積清單後一起結賬）
//   add-product = 加入商品（掃到未建檔嘅條碼時，即場新增商品）
const SCAN_MODE_KEY = 'exit_scan_mode';
const SCAN_MODES = ['both', 'table', 'product', 'add-product'];
const DEFAULT_SCAN_MODE = 'both';

// 新增商品的分類後備清單（與收銀系統一致；API 讀唔到時用）
const DEFAULT_PRODUCT_CATEGORIES = ['收費', '貓零食', '甜品輕食', '沖調飲品', '輕便飲品', '紀念品', '寵物用品'];

class ExitMachine {
    constructor() {
        this.socket = null;
        this.customer = null;
        this.checkoutInfo = null;
        this.doorOpen = false;
        this.doorTimer = null;
        this.selectedPaymentMethod = null;

        // KPay 卡機收款
        this.kpayOutTradeNo = null;
        this.paymentPollTimer = null;

        // 登入相關
        this.isAuthenticated = false;
        this.currentEmployee = null;
        this.currentToken = null;
        this.tokenExpiresAt = null;

        // 頁尾顯示後 10 秒自動隱藏計時器
        this.footerHideTimer = null;

        // 機器用途（用途設定），由 localStorage 載入
        this.scanMode = DEFAULT_SCAN_MODE;

        // 商品結賬購物車：所有商品都掛在呢張無桌號客人單度
        this.productCartId = null;
        this.cartOpenedAt = null;

        // 掃描提示自動消失計時器
        this.scanNoticeTimer = null;

        // KPay 設定用的重驗證憑證（只存記憶體，不寫 localStorage；
        // 關閉設定視窗即清除，下次進入需重新驗證）
        this.reAuthToken = null;
        this.reAuthRole = null;
        this.reAuthName = null;

        this.init();
    }

    // 翻譯字典
    static translations = {
        'zh-TW': {
            // 退出機器翻譯
            'title': 'Founts-AI 離場機器',
            'qrScanTitle': 'QR Code掃描',
            'qrScanInstruction': '請掃描桌號QR Code結賬',
            'qrInputPlaceholder': '或手動輸入QR Code',
            'manualInputTitle': '手動輸入',
            'manualInputPlaceholder': '請輸入號碼',
            'verifyBtn': '驗證',
            'startScanBtn': '開始掃描',
            'emptyStateScanQR': '請先掃描QR Code',
        'scanPromptTitle': '請掃瞄條碼/二維碼',
        'receiptTitle': '單據內容',
        'paymentMethodsTitle': '選擇付款方式',
        'paymentVisaMaster': 'Visa/Master',
        'paymentWeChat': '微信支付',
        'paymentAlipay': '支付寶',
        'paymentFps': '轉數快',
        'paymentPayme': 'PayMe',
        'kpayWaitingTitle': '請喺卡機完成付款',
        'kpayCardWaitingDesc': '請喺收銀卡機上拍卡，完成後自動確認',
        'kpayScanWaitingDesc': '請用手機掃描卡機螢幕上的二維碼，付款完成後自動確認',
        'kpayWaitingInstruction': '請勿離開，交易完成後會自動確認',
        'kpayErrorTitle': '付款未完成',
        'kpayRetryBtn': '重試',
        'tapCardTitle': '請在卡機完成付款',
        'tapCardMessage': '請將卡貼近感應器',
        'tapCardDesc': '等待讀卡器感應您的卡片',
        'tapCardInstruction1': '請勿移動卡片直到交易完成',
        'tapCardInstruction2': '交易完成前請勿離開',
        'scanQrTitle': '請用手機掃碼付款',
        'scanQrMessage': '請出示付款二維碼',
        'scanQrDesc': '請將付款碼對準掃描器',
        'qrCodeLoading': '等待掃描付款碼...',
        'scanningPaymentCode': '掃描中...',
        'scanQrInstruction1': '請打開微信或支付寶出示付款碼',
        'scanQrInstruction2': '將付款碼對準掃描器完成支付',
            'emptyStateWaitCheckout': '等待結賬信息',
            'emptyStateNoPurchase': '無購買記錄',
            'historyCountLabel': '商品數量:',
            'historyTotalLabel': '總金額:',
            'footerMachineVersion': '離場機器 v1.0',
            'footerSystemName': '自動咖啡館系統',
            'lastUpdate': '最後更新: {time}',
            'emergencyStopBtn': '全系統緊急停止',
            'statusConnected': '連線中',
            'doorStatusLocked': '門鎖狀態: 鎖定',
            'mergedCustomerCheckoutTitle': '客人結賬信息',
            'customerInfoTitle': '客人信息',
            'checkoutInfoTitle': '結賬信息',
            'processCheckoutBtn': '執行結賬',
            'printReceiptBtn': '打印收據',
            'purchaseHistoryTitle': '購買記錄',
            'checkoutConfirmTitle': '結賬確認',
            'modalTableLabel': '桌號:',
            'modalPeopleLabel': '客人數:',
            'modalEntryTimeLabel': '入場時間:',
            'modalDurationLabel': '在場時間:',
            'modalAmountLabel': '結賬金額:',
            'paymentMethodTitle': '付款方式',
            'paymentCash': '現金',
            'paymentCard': '信用卡',
            'paymentMember': '會員卡',
            'cancelBtn': '取消',
            'simulatePaymentBtn': '模擬付款',
            'confirmCheckoutBtn': '確認結賬',
            'doorOpenTitle': '門鎖已開啟',
            'doorPleasePass': '請通行',
            'doorOpenMessage': '門鎖已開啟，請在 {seconds} 秒內通過',
            'doorAutoClose': '通過後門鎖將自動關閉',
            'doorDoNotBlock': '請勿強行阻擋門鎖關閉',
            'checkoutCompletionTitle': '已完成結賬',
            'checkoutCompletionMessage': '門口掃小票二維碼可離開',
            'confirmBtn': '確認',
            'checkoutInstructionTitle': '結賬說明',
            'instructionStep1': '掃描桌號QR Code',
            'instructionStep2': '確認客人信息與購買記錄',
            'instructionStep3': '選擇付款方式並確認結賬',
            'instructionStep4': '列印收據並離開',
            'instructionStep1Desc': '使用掃描器或手動輸入QR Code',
            'instructionStep2Desc': '核對客人信息和購買項目',
            'instructionStep3Desc': '選擇現金、信用卡或會員卡付款',
            'instructionStep4Desc': '列印收據後通過出口離開',

            // 用途設定
            'scanModeBtn': '用途設定',
            'scanModeTitle': '用途設定',
            'scanModeNote': '請選擇這台機器的用途。設定儲存在本機，重新開啟仍會保留。',
            'scanModeBoth': '桌號與商品結賬',
            'scanModeBothDesc': '入場小票二維碼與商品條碼都可以掃',
            'scanModeTable': '桌號結賬',
            'scanModeTableDesc': '只接受入場小票二維碼',
            'scanModeProduct': '商品結賬',
            'scanModeProductDesc': '只接受商品條碼，可連續掃描後一起結賬',
            'scanModeAddProduct': '加入商品',
            'scanModeAddProductDesc': '掃到未建檔的條碼時，可即場新增商品',
            'scanModeCurrentPrefix': '目前用途：',
            'saveBtn': '儲存',
            'productCompletionMessage': '感謝惠顧，歡迎再來',
            'addProductTitle': '新增商品',
            'saveProductBtn': '保存商品'
        },
        'zh-CN': {
            // 简体中文翻译
            'title': 'Founts-AI 离场机器',
            'qrScanTitle': 'QR Code扫描',
            'qrScanInstruction': '请扫描桌号QR Code结账',
            'qrInputPlaceholder': '或手动输入QR Code',
            'manualInputTitle': '手动输入',
            'manualInputPlaceholder': '请输入号码',
            'verifyBtn': '验证',
            'startScanBtn': '开始扫描',
            'emptyStateScanQR': '请先扫描QR Code',
        'scanPromptTitle': '请扫瞄条码/二维码',
        'receiptTitle': '单据内容',
        'paymentMethodsTitle': '选择付款方式',
        'paymentVisaMaster': 'Visa/Master',
        'paymentWeChat': '微信支付',
        'paymentAlipay': '支付宝',
        'paymentFps': '转数快',
        'paymentPayme': 'PayMe',
        'kpayWaitingTitle': '请在卡机完成付款',
        'kpayCardWaitingDesc': '请在收银卡机上拍卡，完成后自动确认',
        'kpayScanWaitingDesc': '请用手机扫描卡机屏幕上的二维码，付款完成后自动确认',
        'kpayWaitingInstruction': '请不要离开，交易完成后会自动确认',
        'kpayErrorTitle': '付款未完成',
        'kpayRetryBtn': '重试',
        'tapCardTitle': '请在卡机完成付款',
        'tapCardMessage': '请将卡贴近感应器',
        'tapCardDesc': '等待读卡器感应您的卡片',
        'tapCardInstruction1': '请勿移动卡片直到交易完成',
        'tapCardInstruction2': '交易完成前请勿离开',
        'scanQrTitle': '请用手机扫码付款',
        'scanQrMessage': '请出示付款二维码',
        'scanQrDesc': '请将付款码对准扫描器',
        'qrCodeLoading': '等待扫描付款码...',
        'scanningPaymentCode': '扫描中...',
        'scanQrInstruction1': '请打开微信或支付宝出示付款码',
        'scanQrInstruction2': '将付款码对准扫描器完成支付',
            'emptyStateWaitCheckout': '等待结账信息',
            'emptyStateNoPurchase': '无购买记录',
            'historyCountLabel': '商品数量:',
            'historyTotalLabel': '总金额:',
            'footerMachineVersion': '离场机器 v1.0',
            'footerSystemName': '自动咖啡馆系统',
            'lastUpdate': '最后更新: {time}',
            'emergencyStopBtn': '全系统紧急停止',
            'statusConnected': '连线中',
            'doorStatusLocked': '门锁状态: 锁定',
            'mergedCustomerCheckoutTitle': '客人结账信息',
            'customerInfoTitle': '客人信息',
            'checkoutInfoTitle': '结账信息',
            'processCheckoutBtn': '执行结账',
            'printReceiptBtn': '打印收据',
            'purchaseHistoryTitle': '购买记录',
            'checkoutConfirmTitle': '结账确认',
            'modalTableLabel': '桌号:',
            'modalPeopleLabel': '客人数:',
            'modalEntryTimeLabel': '入场时间:',
            'modalDurationLabel': '在场时间:',
            'modalAmountLabel': '结账金额:',
            'paymentMethodTitle': '付款方式',
            'paymentCash': '现金',
            'paymentCard': '信用卡',
            'paymentMember': '会员卡',
            'cancelBtn': '取消',
            'simulatePaymentBtn': '模拟付款',
            'confirmCheckoutBtn': '确认结账',
            'doorOpenTitle': '门锁已开启',
            'doorPleasePass': '请通行',
            'doorOpenMessage': '门锁已开启，请在 {seconds} 秒内通过',
            'doorAutoClose': '通过后门锁将自动关闭',
            'doorDoNotBlock': '请勿强行阻挡门锁关闭',
            'checkoutCompletionTitle': '已完成结账',
            'checkoutCompletionMessage': '门口扫小票二维码可离开',
            'confirmBtn': '确认',
            'checkoutInstructionTitle': '结账说明',
            'instructionStep1': '扫描桌号QR Code',
            'instructionStep2': '确认客人信息与购买记录',
            'instructionStep3': '选择付款方式并确认结账',
            'instructionStep4': '打印收据并离开',
            'instructionStep1Desc': '使用扫描器或手动输入QR Code',
            'instructionStep2Desc': '核对客人信息和购买项目',
            'instructionStep3Desc': '选择现金、信用卡或会员卡付款',
            'instructionStep4Desc': '打印收据后通过出口离开',

            // 用途设置
            'scanModeBtn': '用途设置',
            'scanModeTitle': '用途设置',
            'scanModeNote': '请选择这台机器的用途。设置保存在本机，重新开启仍会保留。',
            'scanModeBoth': '桌号与商品结账',
            'scanModeBothDesc': '入场小票二维码与商品条码都可以扫',
            'scanModeTable': '桌号结账',
            'scanModeTableDesc': '只接受入场小票二维码',
            'scanModeProduct': '商品结账',
            'scanModeProductDesc': '只接受商品条码，可连续扫描后一起结账',
            'scanModeAddProduct': '加入商品',
            'scanModeAddProductDesc': '扫到未建档的条码时，可现场新增商品',
            'scanModeCurrentPrefix': '当前用途：',
            'saveBtn': '保存',
            'productCompletionMessage': '感谢惠顾，欢迎再来',
            'addProductTitle': '新增商品',
            'saveProductBtn': '保存商品'
        },
        'en': {
            // English translations
            'title': 'Founts-AI Exit Machine',
            'qrScanTitle': 'QR Code Scan',
            'qrScanInstruction': 'Please scan table QR Code to checkout',
            'qrInputPlaceholder': 'Or manually enter QR Code',
            'manualInputTitle': 'Manual Input',
            'manualInputPlaceholder': 'Please enter the number',
            'verifyBtn': 'Verify',
            'startScanBtn': 'Start Scan',
            'emptyStateScanQR': 'Please scan QR Code first',
        'scanPromptTitle': 'Scan the barcode / QR code',
        'receiptTitle': 'Receipt Content',
        'paymentMethodsTitle': 'Select Payment Method',
        'paymentVisaMaster': 'Visa/Master',
        'paymentWeChat': 'WeChat Pay',
        'paymentAlipay': 'Alipay',
        'paymentFps': 'FPS',
        'paymentPayme': 'PayMe',
        'kpayWaitingTitle': 'Please complete payment on the card terminal',
        'kpayCardWaitingDesc': 'Please tap your card on the card terminal',
        'kpayScanWaitingDesc': 'Please scan the QR code on the card terminal screen with your phone; payment is confirmed automatically',
        'kpayWaitingInstruction': 'Please wait, you will be confirmed automatically after payment',
        'kpayErrorTitle': 'Payment incomplete',
        'kpayRetryBtn': 'Retry',
        'tapCardTitle': 'Please Pay on the Card Terminal',
        'tapCardMessage': 'Please bring card close to reader',
        'tapCardDesc': 'Waiting for card reader to detect your card',
        'tapCardInstruction1': 'Do not move card until transaction completes',
        'tapCardInstruction2': 'Do not leave before transaction completes',
        'scanQrTitle': 'Please Scan with Your Phone',
        'scanQrMessage': 'Please show payment QR code',
        'scanQrDesc': 'Please align payment code with scanner',
        'qrCodeLoading': 'Waiting to scan payment code...',
        'scanningPaymentCode': 'Scanning...',
        'scanQrInstruction1': 'Please open WeChat or Alipay to show payment code',
        'scanQrInstruction2': 'Align payment code with scanner to complete payment',
            'emptyStateWaitCheckout': 'Waiting for checkout info',
            'emptyStateNoPurchase': 'No purchase records',
            'historyCountLabel': 'Items:',
            'historyTotalLabel': 'Total:',
            'footerMachineVersion': 'Exit Machine v1.0',
            'footerSystemName': 'Auto Cafe System',
            'lastUpdate': 'Last update: --:--:--',
            'emergencyStopBtn': 'Full System Emergency Stop',
            'statusConnected': 'Connected',
            'doorStatusLocked': 'Door Status: Locked',
            'mergedCustomerCheckoutTitle': 'Customer Checkout Info',
            'customerInfoTitle': 'Customer Info',
            'checkoutInfoTitle': 'Checkout Info',
            'processCheckoutBtn': 'Process Checkout',
            'printReceiptBtn': 'Print Receipt',
            'purchaseHistoryTitle': 'Purchase History',
            'checkoutConfirmTitle': 'Checkout Confirmation',
            'modalTableLabel': 'Table:',
            'modalPeopleLabel': 'People:',
            'modalEntryTimeLabel': 'Entry Time:',
            'modalDurationLabel': 'Duration:',
            'modalAmountLabel': 'Amount:',
            'paymentMethodTitle': 'Payment Method',
            'paymentCash': 'Cash',
            'paymentCard': 'Credit Card',
            'paymentMember': 'Member Card',
            'cancelBtn': 'Cancel',
            'simulatePaymentBtn': 'Simulate Payment',
            'confirmCheckoutBtn': 'Confirm Checkout',
            'doorOpenTitle': 'Door Opened',
            'doorPleasePass': 'Please Pass',
            'doorOpenMessage': 'Door opened, please pass within {seconds} seconds',
            'doorAutoClose': 'Door will auto close after passing',
            'doorDoNotBlock': 'Do not block door closing',
            'checkoutCompletionTitle': 'Checkout Completed',
            'checkoutCompletionMessage': 'Please scan receipt QR code at the door to exit',
            'confirmBtn': 'Confirm',
            'checkoutInstructionTitle': 'Checkout Instructions',
            'instructionStep1': 'Scan table QR Code',
            'instructionStep2': 'Confirm customer info and purchase history',
            'instructionStep3': 'Select payment method and confirm checkout',
            'instructionStep4': 'Print receipt and exit',
            'instructionStep1Desc': 'Use scanner or manually enter QR Code',
            'instructionStep2Desc': 'Verify customer information and purchase items',
            'instructionStep3Desc': 'Choose cash, credit card, or member card payment',
            'instructionStep4Desc': 'Print receipt and exit through the door',

            // Usage settings
            'scanModeBtn': 'Usage',
            'scanModeTitle': 'Usage Settings',
            'scanModeNote': 'Choose what this machine is used for. The setting is stored on this device and kept after restart.',
            'scanModeBoth': 'Table & Product Checkout',
            'scanModeBothDesc': 'Accepts both entry-ticket QR codes and product barcodes',
            'scanModeTable': 'Table Checkout',
            'scanModeTableDesc': 'Accepts entry-ticket QR codes only',
            'scanModeProduct': 'Product Checkout',
            'scanModeProductDesc': 'Accepts product barcodes only; scan several items and check out together',
            'scanModeAddProduct': 'Add Product',
            'scanModeAddProductDesc': 'When an unknown barcode is scanned, create the product on the spot',
            'scanModeCurrentPrefix': 'Current usage: ',
            'saveBtn': 'Save',
            'productCompletionMessage': 'Thank you, please come again',
            'addProductTitle': 'Add Product',
            'saveProductBtn': 'Save Product'
        }
    };

    async init() {
        // 初始化時間顯示
        this.updateTime();
        setInterval(() => this.updateTime(), 1000);

        // 檢查登入狀態（強制登入）
        this.checkSavedLogin();

        // 連接Socket.IO
        this.connectSocket();

        // 綁定事件監聽器
        this.bindEvents();

        // 載入語言偏好設定
        this.loadLanguagePreference();

        // 載入機器用途設定
        this.loadScanMode();

        // 載入今日統計
        this.loadTodayStats();
        this.loadExitRecords();

        // 初始化系統訊息
        this.addMessage('離場機器啟動完成', 'info');

        // 開發模式測試
        if (window.location.search.includes('debug=1')) {
            console.log('Debug mode enabled, running quick test in 2 seconds...');
            setTimeout(() => {
                this.quickTest();
            }, 2000);
        }
    }

    connectSocket() {
        this.socket = io();

        this.socket.on('connect', () => {
            this.updateStatus('online');
            this.addMessage('已連線到伺服器', 'success');
        });

        this.socket.on('disconnect', () => {
            this.updateStatus('offline');
            this.addMessage('與伺服器斷開連線', 'error');
        });

        this.socket.on('checkout-complete', (data) => {
            this.addMessage(`桌號 ${data.table_number} 已結賬, 金額: $${data.total_amount}`, 'success');
            this.loadTodayStats();
            this.loadExitRecords();
        });

        this.socket.on('door-opened', (data) => {
            this.addMessage('門鎖已開啟', 'success');
            this.showDoorOpenModal();
        });

        this.socket.on('door-closed', (data) => {
            this.addMessage('門鎖已關閉', 'info');
            this.updateDoorStatus(false);
        });
    }

    bindEvents() {
        // QR Code掃描
        const startScanBtn = document.getElementById('start-scan-btn');
        if (startScanBtn) {
            startScanBtn.addEventListener('click', () => this.startQRScan());
        }
        document.getElementById('manual-scan-btn').addEventListener('click', () => this.manualQRScan());

        // 條碼掃描器（HID 鍵盤）通常喺條碼後面補一個 Enter。
        // 冇呢個監聽就要每次掃完再撳「驗證」，連續掃描一件件商品會好麻煩。
        const qrInputEl = document.getElementById('qr-input');
        if (qrInputEl) {
            qrInputEl.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this.manualQRScan();
                }
            });
        }

        // 語言選擇 (按鈕)
        document.querySelectorAll('.language-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const lang = e.target.dataset.lang;
                this.changeLanguage(lang);
                // 更新按鈕激活狀態
                document.querySelectorAll('.language-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
            });
        });

        // 時間處點 6 下：顯示 footer（10 秒後自動隱藏）
        const currentTimeEl = document.getElementById('current-time');
        if (currentTimeEl) {
            let timeClickCount = 0;
            let timeClickResetTimer = null;
            currentTimeEl.addEventListener('click', () => {
                timeClickCount++;
                if (timeClickResetTimer) clearTimeout(timeClickResetTimer);
                timeClickResetTimer = setTimeout(() => { timeClickCount = 0; }, 3000);
                if (timeClickCount >= 6) {
                    timeClickCount = 0;
                    if (timeClickResetTimer) clearTimeout(timeClickResetTimer);
                    this.showFooterTemporarily();
                }
            });
        }

        // 結賬按鈕 (使用合併卡片中的按鈕)
        const processCheckoutBtn = document.getElementById('merged-process-checkout-btn');
        if (processCheckoutBtn) {
            processCheckoutBtn.addEventListener('click', () => {
                console.log('merged-process-checkout-btn clicked');
                this.showCheckoutModal();
            });
        }
        const printReceiptBtn = document.getElementById('merged-print-receipt-btn');
        if (printReceiptBtn) {
            printReceiptBtn.addEventListener('click', () => {
                console.log('merged-print-receipt-btn clicked');
                this.printReceipt();
            });
        }


        // 模態框控制
        document.getElementById('cancel-checkout-modal-btn').addEventListener('click', () => {
            console.log('cancel-checkout-modal-btn clicked');
            this.hideCheckoutModal();
        });
        document.getElementById('confirm-checkout-modal-btn').addEventListener('click', () => {
            console.log('confirm-checkout-modal-btn clicked');
            this.confirmCheckout();
        });
        document.getElementById('close-door-modal-btn').addEventListener('click', () => {
            console.log('close-door-modal-btn clicked');
            this.hideDoorModal();
        });

        // 支付模態框取消按鈕（取消進行中嘅 KPay 付款）
        document.getElementById('cancel-tap-card-modal-btn').addEventListener('click', () => {
            this.cancelKpayPayment();
        });

        document.getElementById('cancel-scan-qr-modal-btn').addEventListener('click', () => {
            this.cancelKpayPayment();
        });

        // ===== 登入事件 =====
        const staffLoginBtn = document.getElementById('staff-login-btn');
        if (staffLoginBtn) {
            staffLoginBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                if (this.isAuthenticated) {
                    this.logout();
                } else {
                    this.showLoginModal();
                }
            });
        }

        const cancelLoginBtn = document.getElementById('cancel-login-btn');
        if (cancelLoginBtn) cancelLoginBtn.addEventListener('click', () => this.hideLoginModal());

        const loginForm = document.getElementById('login-form');
        if (loginForm) loginForm.addEventListener('submit', (e) => this.handleLoginSubmit(e));

        // 退出 App（只有登入後才顯示；需重新輸入已登入員工的密碼）
        const exitAppBtn = document.getElementById('exit-app-btn');
        if (exitAppBtn) {
            exitAppBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                if (this.isAuthenticated) this.showExitModal();
            });
        }

        const cancelExitBtn = document.getElementById('cancel-exit-btn');
        if (cancelExitBtn) cancelExitBtn.addEventListener('click', () => this.hideExitModal());

        const exitForm = document.getElementById('exit-form');
        if (exitForm) exitForm.addEventListener('submit', (e) => this.handleExitSubmit(e));

        // ===== KPay 設定事件 =====
        const settingsBtn = document.getElementById('settings-btn');
        if (settingsBtn) {
            settingsBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.showReauthModal();
            });
        }

        const reauthForm = document.getElementById('reauth-form');
        if (reauthForm) reauthForm.addEventListener('submit', (e) => this.handleReauthSubmit(e));

        const cancelReauthBtn = document.getElementById('cancel-reauth-btn');
        if (cancelReauthBtn) cancelReauthBtn.addEventListener('click', () => this.hideReauthModal());

        const cancelSettingsBtn = document.getElementById('cancel-settings-btn');
        if (cancelSettingsBtn) cancelSettingsBtn.addEventListener('click', () => this.hideKpaySettingsModal());

        // ===== 用途設定事件 =====
        const scanModeBtn = document.getElementById('scan-mode-btn');
        if (scanModeBtn) {
            scanModeBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.showScanModeModal();
            });
        }

        const cancelScanModeBtn = document.getElementById('cancel-scan-mode-btn');
        if (cancelScanModeBtn) cancelScanModeBtn.addEventListener('click', () => this.hideScanModeModal());

        const saveScanModeBtn = document.getElementById('save-scan-mode-btn');
        if (saveScanModeBtn) saveScanModeBtn.addEventListener('click', () => this.saveScanMode());

        document.querySelectorAll('input[name="scan-mode"]').forEach(radio => {
            radio.addEventListener('change', () => this.updateScanModeSelection());
        });

        // ===== 加入商品（新增商品視窗）事件 =====
        const productForm = document.getElementById('product-form');
        if (productForm) productForm.addEventListener('submit', (e) => this.handleAddProductSubmit(e));

        const cancelProductBtn = document.getElementById('cancel-product-btn');
        if (cancelProductBtn) cancelProductBtn.addEventListener('click', () => this.hideAddProductModal());

        const noInventoryCheckbox = document.getElementById('product-no-inventory');
        if (noInventoryCheckbox) {
            noInventoryCheckbox.addEventListener('change', (e) => this.updateInventoryFieldState(e.target.checked));
        }

        const timeRestrictionCheckbox = document.getElementById('product-time-restriction');
        if (timeRestrictionCheckbox) {
            timeRestrictionCheckbox.addEventListener('change', (e) => this.updateTimeRestrictionFieldsState(e.target.checked));
        }

        const saveSettingsBtn = document.getElementById('save-settings-btn');
        if (saveSettingsBtn) saveSettingsBtn.addEventListener('click', () => this.saveKpaySettings());
    }

    changeLanguage(lang) {
        console.log('Language changed to:', lang);
        localStorage.setItem('preferredLanguage', lang);
        this.translatePage(lang);
    }

    translatePage(lang) {
        const translations = ExitMachine.translations[lang];
        if (!translations) {
            console.warn(`No translations found for language: ${lang}`);
            return;
        }

        // 更新所有帶有 data-i18n 屬性的元素
        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n');
            if (translations[key]) {
                // 處理帶有佔位符的翻譯
                let text = translations[key];
                if (key === 'doorOpenMessage' && element.hasAttribute('data-i18n-seconds')) {
                    const seconds = element.getAttribute('data-i18n-seconds');
                    text = text.replace('{seconds}', seconds);
                }
                element.textContent = text;
            }
        });

        // 更新帶有 data-i18n-placeholder 的輸入框
        document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
            const key = element.getAttribute('data-i18n-placeholder');
            if (translations[key]) {
                element.placeholder = translations[key];
            }
        });

        // 更新 HTML lang 屬性
        document.documentElement.lang = lang;

        // 更新日期時間格式
        this.updateTime();

        // 用途提示係即時組合出嚟（唔係 data-i18n），所以切語言要自己更新
        this.updateScanModeHint();
    }

    loadLanguagePreference() {
        const savedLang = localStorage.getItem('preferredLanguage') || 'zh-TW';
        // 更新按鈕激活狀態
        document.querySelectorAll('.language-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.lang === savedLang) {
                btn.classList.add('active');
            }
        });
        this.translatePage(savedLang);
    }

    updateTime() {
        const now = new Date();
        const lang = localStorage.getItem('preferredLanguage') || 'zh-TW';
        const timeString = now.toLocaleTimeString(lang);
        const dateString = now.toLocaleDateString(lang, {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        });

        document.getElementById('current-time').textContent = timeString;

        // 更新最後更新文字（使用翻譯）
        const translations = ExitMachine.translations[lang];
        if (translations && translations['lastUpdate']) {
            const lastUpdateText = translations['lastUpdate'].replace('{time}', `${dateString} ${timeString}`);
            document.getElementById('last-update').textContent = lastUpdateText;
        } else {
            document.getElementById('last-update').textContent = `最後更新: ${dateString} ${timeString}`;
        }
    }

    updateStatus(status) {
        const statusEl = document.getElementById('connection-status');
        if (!statusEl) return;
        if (status === 'online') {
            statusEl.classList.add('online');
            statusEl.innerHTML = '<i class="fas fa-wifi"></i><span>連線中</span>';
        } else {
            statusEl.classList.remove('online');
            statusEl.innerHTML = '<i class="fas fa-wifi"></i><span>離線中</span>';
        }
    }

    /**
     * 顯示 footer（時間處點 6 下），10 秒後自動重新隱藏
     */
    showFooterTemporarily() {
        const footer = document.getElementById('footer');
        if (!footer) return;
        footer.classList.remove('hidden');
        if (this.footerHideTimer) {
            clearTimeout(this.footerHideTimer);
        }
        this.footerHideTimer = setTimeout(() => {
            footer.classList.add('hidden');
            this.footerHideTimer = null;
        }, 10000);
    }

    // ===== 用途設定 =====

    /** 讀取本機儲存的機器用途（無效值一律回預設） */
    loadScanMode() {
        let saved = null;
        try {
            saved = localStorage.getItem(SCAN_MODE_KEY);
        } catch (e) {
            console.warn('讀取用途設定失敗:', e.message);
        }
        this.scanMode = SCAN_MODES.includes(saved) ? saved : DEFAULT_SCAN_MODE;
        this.updateScanModeSelection();
        this.updateScanModeHint();
    }

    showScanModeModal() {
        const modal = document.getElementById('scan-mode-modal');
        if (!modal) return;
        this.updateScanModeSelection();
        modal.classList.remove('hidden');
    }

    hideScanModeModal() {
        const modal = document.getElementById('scan-mode-modal');
        if (modal) modal.classList.add('hidden');
    }

    /** 依 this.scanMode 勾選 radio；同時維護 .selected（舊 WebView 唔支援 :has()） */
    updateScanModeSelection() {
        document.querySelectorAll('input[name="scan-mode"]').forEach(radio => {
            const selected = radio.value === this.scanMode;
            radio.checked = selected;
            const option = radio.closest('.scan-mode-option');
            if (option) option.classList.toggle('selected', selected);
        });
    }

    /** 掃描提示卡上顯示目前用途，等店員一眼睇到呢台機而家做緊乜 */
    updateScanModeHint() {
        const hint = document.getElementById('scan-mode-hint');
        if (!hint) return;
        const lang = localStorage.getItem('preferredLanguage') || 'zh-TW';
        const t = ExitMachine.translations[lang] || ExitMachine.translations['zh-TW'];
        const nameKey = {
            'both': 'scanModeBoth',
            'table': 'scanModeTable',
            'product': 'scanModeProduct',
            'add-product': 'scanModeAddProduct'
        }[this.scanMode] || 'scanModeBoth';
        const prefix = (t && t['scanModeCurrentPrefix']) || '目前用途：';
        hint.textContent = prefix + ((t && t[nameKey]) || '');
    }

    saveScanMode() {
        const checked = document.querySelector('input[name="scan-mode"]:checked');
        const mode = checked ? checked.value : DEFAULT_SCAN_MODE;
        if (!SCAN_MODES.includes(mode)) return;

        this.scanMode = mode;
        try {
            localStorage.setItem(SCAN_MODE_KEY, mode);
        } catch (e) {
            console.warn('儲存用途設定失敗:', e.message);
        }
        this.updateScanModeSelection();
        this.updateScanModeHint();
        this.hideScanModeModal();
    }

    // ===== 退出 App（重新驗證登入帳號密碼）=====

    showExitModal() {
        const exitModal = document.getElementById('exit-app-modal');
        const exitForm = document.getElementById('exit-form');
        if (!exitModal || !exitForm) return;

        // 重置表單後，預填已登入的帳號（唯讀，必須與登入帳號一致）
        exitForm.reset();
        const usernameInput = document.getElementById('exit-username');
        if (usernameInput && this.currentEmployee) {
            usernameInput.value = this.currentEmployee.username || '';
        }
        this.hideExitError();
        exitModal.classList.remove('hidden');

        // 自動聚焦密碼輸入框
        const passwordInput = document.getElementById('exit-password');
        if (passwordInput) setTimeout(() => passwordInput.focus(), 300);
    }

    hideExitModal() {
        const exitModal = document.getElementById('exit-app-modal');
        if (exitModal) exitModal.classList.add('hidden');
    }

    showExitError(message) {
        const err = document.getElementById('exit-error');
        if (err) {
            err.textContent = message;
            err.classList.remove('hidden');
        }
    }

    hideExitError() {
        const err = document.getElementById('exit-error');
        if (err) err.classList.add('hidden');
    }

    async handleExitSubmit(event) {
        event.preventDefault();
        this.hideExitError();

        const username = document.getElementById('exit-username').value.trim();
        const password = document.getElementById('exit-password').value;
        if (!username || !password) return;

        const submitBtn = document.getElementById('submit-exit-btn');
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 驗證中...';
        }

        try {
            // 用同一套登入 API 驗證帳號密碼
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });
            const result = await response.json();

            // 帳號必須與已登入的帳號一致
            const loggedUsername = (this.currentEmployee?.username || '').toLowerCase();
            const enteredUsername = (result.data?.employee?.username || username).toLowerCase();
            if (response.ok && result.success && enteredUsername === loggedUsername) {
                this.addMessage('驗證成功，退出系統', 'info');
                this.exitApp();
            } else {
                this.showExitError('帳號或密碼不正確');
                this.addMessage('退出驗證失敗: 帳號或密碼不正確', 'error');
            }
        } catch (error) {
            this.showExitError('驗證失敗: ' + error.message);
            this.addMessage('退出驗證請求失敗: ' + error.message, 'error');
        } finally {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '確認退出';
            }
        }
    }

    /**
     * 退出 App（經 Android bridge 關閉程式）
     */
    exitApp() {
        if (window.AutoCafeApp && typeof window.AutoCafeApp.exitApp === 'function') {
            this.hideExitModal();
            window.AutoCafeApp.exitApp();
        } else {
            this.showExitError('無法退出：非 App 環境');
            this.addMessage('⚠️ 未偵測到 App bridge，無法退出', 'warning');
        }
    }

    startQRScan() {
        // 模擬QR Code掃描過程
        const qrScanner = document.querySelector('.qr-scanner');
        qrScanner.style.borderColor = '#4CAF50';
        qrScanner.style.borderStyle = 'solid';

        // 顯示掃描動畫
        const scanLine = document.querySelector('.scan-line');
        scanLine.style.animation = 'scan 1s linear';

        // 模擬掃描結果
        setTimeout(() => {
            qrScanner.style.borderColor = '#e74c3c';
            qrScanner.style.borderStyle = 'dashed';
            scanLine.style.animation = '';

            // 生成測試QR Code
            const testQRCode = JSON.stringify({
                qr_code: 'CAFE-EXIT-' + Date.now() + '-TEST',
                table_number: 'A' + (Math.floor(Math.random() * 10) + 1),
                customer_id: 'customer-exit-test-' + Date.now()
            });

            this.processQRCode(testQRCode);
        }, 2000);
    }

    manualQRScan() {
        console.log('manualQRScan called');
        const input = document.getElementById('qr-input');
        const qrInput = input.value.trim();
        console.log('QR input value:', qrInput);
        if (!qrInput) {
            alert('請輸入QR Code');
            return;
        }

        // 即刻清空輸入框：唔清嘅話，下一次掃描嘅字元會駁喺今次殘留嘅字後面
        input.value = '';

        console.log('Calling processQRCode with:', qrInput);
        this.processQRCode(qrInput);
    }

    /**
     * 掃描入口：依「用途設定」分流
     */
    async processQRCode(qrCode) {
        const code = String(qrCode || '').trim();
        if (!code) return;
        console.log('processQRCode:', code, '/ 用途:', this.scanMode);

        switch (this.scanMode) {
            case 'table':
                return this.handleTableScan(code, { rejectProduct: true });
            case 'product':
                return this.handleProductScan(code);
            case 'add-product':
                return this.handleAddProductScan(code);
            case 'both':
            default:
                return this.handleBothScan(code);
        }
    }

    /**
     * 預設用途：桌號與商品結賬
     * 已載入客人（未結賬）→ 商品直接加落佢張單；
     * 否則先當入場小票二維碼處理（同未加用途設定之前一樣），唔中再試商品條碼。
     */
    async handleBothScan(code) {
        if (this.customer && !(this.checkoutInfo && this.checkoutInfo.checked_out)) {
            const lookup = await this.lookupProductCode(code);
            if (lookup.ok && lookup.found) {
                return this.addProductToOrder(lookup.product, this.customer.id);
            }
        }

        const status = await this.handleTableScan(code, { quiet: true });
        if (status !== 'invalid') return status === 'ok';

        const handled = await this.handleProductScan(code, { combined: true });
        if (!handled) this.clearCustomer();
        return handled;
    }

    /**
     * 桌號結賬流程（原本嘅掃描流程）
     * @param {string} qrCode 掃到的碼
     * @param {{quiet?: boolean, rejectProduct?: boolean}} opts
     *        quiet         = 靜靜咁試（混合用途用），唔清畫面唔出提示
     *        rejectProduct = 用途只准桌號，遇到商品碼要講明原因
     * @returns {Promise<'ok'|'invalid'|'error'>} ok=載入客人成功, invalid=主機話個碼唔啱, error=連線出錯
     */
    async handleTableScan(qrCode, opts = {}) {
        const { quiet = false, rejectProduct = false } = opts;
        console.log('handleTableScan:', qrCode);
        try {
            console.log('Making API call to /api/exit/scan');
            const response = await fetch('/api/exit/scan', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    qr_code: qrCode,
                    store_id: this.currentEmployee?.store_id || null
                })
            });

            console.log('API response status:', response.status);
            const result = await response.json();
            console.log('API result:', result);

            if (result.success && result.valid) {
                this.customer = result.customer;
                this.checkoutInfo = result;
                console.log('API success: customer=', this.customer);
                console.log('API success: checkoutInfo=', this.checkoutInfo);

                // 載入咗桌號客人 → 未完成嘅商品購物車要放棄，避免兩張單同時存在
                if (this.productCartId && this.productCartId !== result.customer.id) {
                    this.abandonProductCart();
                }

                // 切換到掃描結果界面
                console.log('Hiding scan prompt card and manual input, showing scan result container');
                const scanPromptCard = document.querySelector('.scan-prompt-card');
                const manualInputSection = document.querySelector('.manual-input-section');
                const scanResultContainer = document.querySelector('.scan-result-container');
                if (scanPromptCard) {
                    scanPromptCard.classList.add('hidden');
                }
                if (manualInputSection) {
                    manualInputSection.classList.add('hidden');
                }
                if (scanResultContainer) {
                    scanResultContainer.classList.remove('hidden');
                }
                console.log('UI切换完成');

                if (result.checked_out) {
                    this.showCheckoutCompletionUI();
                } else {
                    this.displayMergedCustomerCheckoutInfo();
                    this.displayPurchaseHistory();
                    this.bindPaymentOptions();
                }
                this.addMessage('QR Code驗證成功', 'success');
                this.clearScanNotice();
                return 'ok';
            }

            // 主機話呢個碼唔係有效嘅入場小票
            if (quiet) return 'invalid';

            this.clearCustomer();

            // 用途只准桌號時，如果呢個碼其實係本分店商品，講清楚原因
            if (rejectProduct) {
                const lookup = await this.lookupProductCode(qrCode);
                if (lookup.ok && lookup.found) {
                    this.showScanNotice('此模式只接受入場小票二維碼；如需商品結賬，請先更改用途設定');
                    return 'invalid';
                }
            }

            this.showScanNotice(result.error || 'QR Code無效');
            this.addMessage(result.error || 'QR Code無效', 'error');
            return 'invalid';
        } catch (error) {
            console.log('API call failed, using mock data:', error.message);
            console.error('Error stack:', error.stack);
            // 使用模擬數據進行測試
            const mockResult = {
                success: true,
                valid: true,
                customer: {
                    id: 'mock-customer-' + Date.now(),
                    table_number: 'A' + (Math.floor(Math.random() * 10) + 1),
                    people_count: Math.floor(Math.random() * 6) + 1,
                    entry_time: new Date(Date.now() - Math.floor(Math.random() * 120) * 60000).toISOString(),
                    total_amount: Math.floor(Math.random() * 500) + 100,
                    qr_code: qrCode || 'MOCK-QR-' + Date.now()
                },
                checked_out: false,
                order_items: [
                    {
                        product_name: '拿鐵咖啡',
                        quantity: 2,
                        price_at_time: 120
                    },
                    {
                        product_name: '巧克力蛋糕',
                        quantity: 1,
                        price_at_time: 80
                    }
                ],
                summary: {
                    total_items: 3,
                    total_amount: 320
                }
            };

            this.customer = mockResult.customer;
            this.checkoutInfo = mockResult;
            console.log('Mock data set: customer=', this.customer);
            console.log('Mock data set: checkoutInfo=', this.checkoutInfo);

            // 切換到掃描結果界面
            console.log('Mock: Hiding scan prompt card and manual input, showing scan result container');
            const scanPromptCard = document.querySelector('.scan-prompt-card');
            const manualInputSection = document.querySelector('.manual-input-section');
            const scanResultContainer = document.querySelector('.scan-result-container');
            if (scanPromptCard) {
                scanPromptCard.classList.add('hidden');
            }
            if (manualInputSection) {
                manualInputSection.classList.add('hidden');
            }
            if (scanResultContainer) {
                scanResultContainer.classList.remove('hidden');
            }
            console.log('Mock UI切换完成');

            if (mockResult.checked_out) {
                this.showCheckoutCompletionUI();
            } else {
                this.displayMergedCustomerCheckoutInfo();
                this.displayPurchaseHistory();
                this.bindPaymentOptions();
            }
            this.addMessage('QR Code驗證成功 (模擬數據)', 'success');
            return 'error';
        }
    }

    // ===== 商品掃描（用途設定：商品結賬 / 加入商品 / 混合用途）=====

    /**
     * 以商品條碼（即商品 UUID）查本分店商品
     * @returns {Promise<{ok: boolean, found?: boolean, product?: object, error?: string}>}
     *          ok=false 代表連線或主機出錯，要同「查唔到」分開處理
     */
    async lookupProductCode(code) {
        try {
            const response = await fetch('/api/exit/product-scan', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    code: code,
                    store_id: this.currentEmployee?.store_id || null
                })
            });
            const result = await response.json();
            if (!response.ok) {
                return { ok: false, error: result.error || ('HTTP ' + response.status) };
            }
            if (!result.found) return { ok: true, found: false };
            return { ok: true, found: true, product: result.product };
        } catch (error) {
            console.error('商品條碼查詢失敗:', error);
            return { ok: false, error: error.message };
        }
    }

    /** 掃描提示（會自動消失） */
    showScanNotice(message, type = 'warning') {
        const notice = document.getElementById('scan-notice');
        if (!notice) {
            alert(message);
            return;
        }
        notice.textContent = message;
        notice.classList.remove('hidden', 'success', 'error');
        if (type === 'success' || type === 'error') notice.classList.add(type);

        if (this.scanNoticeTimer) clearTimeout(this.scanNoticeTimer);
        this.scanNoticeTimer = setTimeout(() => {
            notice.classList.add('hidden');
            this.scanNoticeTimer = null;
        }, 6000);
    }

    clearScanNotice() {
        const notice = document.getElementById('scan-notice');
        if (notice) notice.classList.add('hidden');
        if (this.scanNoticeTimer) {
            clearTimeout(this.scanNoticeTimer);
            this.scanNoticeTimer = null;
        }
    }

    /** 由提示卡切換到掃描結果畫面（並重設結賬完成訊息） */
    showScanResultPanels() {
        const scanPromptCard = document.querySelector('.scan-prompt-card');
        const manualInputSection = document.querySelector('.manual-input-section');
        const scanResultContainer = document.querySelector('.scan-result-container');
        if (scanPromptCard) scanPromptCard.classList.add('hidden');
        if (manualInputSection) manualInputSection.classList.add('hidden');
        if (scanResultContainer) {
            scanResultContainer.classList.remove('hidden');
            scanResultContainer.classList.remove('show-completion');
        }
        const completionSection = document.getElementById('checkout-completion-section');
        if (completionSection) completionSection.classList.add('hidden');
        this.toggleCompletionMessage(false);
    }

    /** 切換結賬完成訊息：false = 桌號版，true = 商品版 */
    toggleCompletionMessage(isProductSale) {
        const tableMsg = document.querySelector('.completion-message [data-i18n="checkoutCompletionMessage"]');
        const productMsg = document.getElementById('product-completion-message');
        if (tableMsg) tableMsg.classList.toggle('hidden', isProductSale);
        if (productMsg) productMsg.classList.toggle('hidden', !isProductSale);
    }

    /** 依結賬類型顯示對應嘅完成畫面 */
    showCompletionForCurrentSale() {
        const isProductSale = !!(this.checkoutInfo && this.checkoutInfo.is_product_sale);
        this.showCheckoutCompletionUI();
        this.toggleCompletionMessage(isProductSale);
        if (isProductSale) {
            // 呢張購物車已經完成，下次掃描要開過一張新嘅
            this.productCartId = null;
            this.cartOpenedAt = null;
        }
    }

    /**
     * 商品結賬：只接受本分店嘅商品條碼，掃到就加入購物車
     * @param {string} code
     * @param {{combined?: boolean}} opts combined = 混合用途，兩個碼都唔中時講法唔同
     */
    async handleProductScan(code, opts = {}) {
        const { combined = false } = opts;
        const lookup = await this.lookupProductCode(code);

        if (!lookup.ok) {
            this.showScanNotice('商品條碼查詢失敗：' + (lookup.error || '請稍後再試'), 'error');
            return false;
        }
        if (!lookup.found) {
            this.showScanNotice(combined
                ? '掃不到對應的入場小票二維碼或本分店商品條碼'
                : '此模式只接受本分店的商品條碼');
            return false;
        }
        if (!lookup.product.is_available) {
            this.showScanNotice('商品「' + lookup.product.name + '」已下架，無法發售');
            return false;
        }
        return this.addProductToCart(lookup.product);
    }

    /**
     * 加入商品結賬購物車。
     * 商品結賬要經 KPay 收款，而 KPay 一定綁客人，所以第一次掃描時
     * 先開一張無桌號客人（table_number = ''）做購物車。
     */
    async addProductToCart(product) {
        try {
            if (!this.productCartId) {
                const cartRes = await fetch('/api/exit/product-cart', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ store_id: this.currentEmployee?.store_id || null })
                });
                const cartData = await cartRes.json();
                if (!cartRes.ok || !cartData.success) {
                    this.showScanNotice(cartData.error || '無法開啟購物車', 'error');
                    return false;
                }
                this.productCartId = cartData.customer_id;
                this.cartOpenedAt = new Date().toISOString();
            }
            return this.addProductToOrder(product, this.productCartId);
        } catch (error) {
            this.showScanNotice('加入商品失敗：' + error.message, 'error');
            return false;
        }
    }

    /**
     * 把商品加入指定訂單
     * @param {object} product
     * @param {string} customerId 桌號客人（加到該桌帳單）或無桌號購物車
     */
    async addProductToOrder(product, customerId) {
        try {
            const response = await fetch('/api/cashier/add-order-item', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    customer_id: customerId,
                    product_id: product.id,
                    quantity: 1,
                    store_id: this.currentEmployee?.store_id || null
                })
            });
            const result = await response.json();
            if (!response.ok || !result.success) {
                this.showScanNotice(result.error || result.message || '加入商品失敗', 'error');
                return false;
            }

            this.showScanNotice('已加入：' + (result.product_name || product.name), 'success');

            if (customerId === this.productCartId) {
                await this.refreshProductCart();
            } else if (this.customer && this.customer.qr_code) {
                // 加到桌號帳單 → 重新載入該客人資料，金額同清單一齊更新
                await this.handleTableScan(this.customer.qr_code, { quiet: true });
            }
            return true;
        } catch (error) {
            this.showScanNotice('加入商品失敗：' + error.message, 'error');
            return false;
        }
    }

    /** 重畫商品購物車（清單 + 總額） */
    async refreshProductCart() {
        if (!this.productCartId) return;
        try {
            const storeId = this.currentEmployee?.store_id;
            const url = '/api/vending/customer/' + encodeURIComponent(this.productCartId) + '/orders'
                + (storeId ? '?store_id=' + encodeURIComponent(storeId) : '');
            const response = await fetch(url);
            const data = await response.json();
            if (!response.ok || !data.success) {
                this.showScanNotice(data.error || '讀取購物車失敗', 'error');
                return;
            }

            const orderItems = data.orders || [];
            const totalItems = data.total_items || 0;
            const totalAmount = data.total_amount || 0;

            // 借用現有嘅客人／結賬資訊結構，令付款同結賬流程可以直接重用
            this.customer = {
                id: this.productCartId,
                table_number: '',
                people_count: 0,
                entry_time: this.cartOpenedAt || new Date().toISOString(),
                total_amount: totalAmount,
                qr_code: ''
            };
            this.checkoutInfo = {
                success: true,
                valid: true,
                checked_out: false,
                is_product_sale: true,
                order_items: orderItems,
                summary: { total_items: totalItems, total_amount: totalAmount }
            };

            this.showScanResultPanels();
            this.displayProductSaleInfo(totalItems, totalAmount);
            this.displayPurchaseHistory();
            this.bindPaymentOptions();
        } catch (error) {
            this.showScanNotice('讀取購物車失敗：' + error.message, 'error');
        }
    }

    /** 商品結賬左邊嘅資訊面板（含清除購物車） */
    displayProductSaleInfo(itemCount, totalAmount) {
        const container = document.getElementById('merged-customer-checkout-info');
        if (!container) return;
        container.innerHTML = `
            <div class="detail-row">
                <span class="detail-label">用途:</span>
                <span class="detail-value">商品結賬</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">商品件數:</span>
                <span class="detail-value">${itemCount}件</span>
            </div>
            <div class="detail-row total">
                <span class="detail-label">結賬金額:</span>
                <span class="detail-value">$${totalAmount}</span>
            </div>
            <div class="product-cart-actions">
                <button class="btn-small btn-danger" id="clear-product-cart-btn">
                    <i class="fas fa-trash-alt"></i> <span>清除購物車</span>
                </button>
            </div>
        `;
        const clearBtn = document.getElementById('clear-product-cart-btn');
        if (clearBtn) clearBtn.addEventListener('click', () => this.clearProductCart());
    }

    /** 靜靜咁放棄購物車（唔問、唔提示）；切換到桌號結賬時用 */
    async abandonProductCart() {
        const cartId = this.productCartId;
        this.productCartId = null;
        this.cartOpenedAt = null;
        if (!cartId) return;

        // 有進行中嘅 KPay 付款要先取消（冇付款記錄就會失敗，可以忽略）
        try {
            await fetch('/api/kpay/cancel', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ customer_id: cartId })
            });
        } catch (error) {
            console.warn('取消付款失敗（可能沒有進行中付款）:', error.message);
        }

        try {
            const response = await fetch('/api/exit/product-cart/cancel', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    customer_id: cartId,
                    store_id: this.currentEmployee?.store_id || null
                })
            });
            const result = await response.json();
            if (!response.ok || !result.success) {
                console.warn('放棄購物車失敗:', result.error || response.status);
            }
        } catch (error) {
            console.warn('放棄購物車失敗:', error.message);
        }
    }

    /** 清除購物車（店員按掣）：確認後放棄購物車並回到掃描畫面 */
    async clearProductCart() {
        if (!this.productCartId) return;
        if (!confirm('確定要清除購物車內所有商品嗎？')) return;

        await this.abandonProductCart();
        this.clearCustomer();
        this.showScanNotice('購物車已清除', 'success');
    }

    // ===== 加入商品（掃到未建檔條碼 → 即場新增商品）=====

    /**
     * 掃到條碼後：已有呢件商品就只提示；未有就問係唔係要即場新增
     */
    async handleAddProductScan(code) {
        const lookup = await this.lookupProductCode(code);

        if (!lookup.ok) {
            this.showScanNotice('商品條碼查詢失敗：' + (lookup.error || '請稍後再試'), 'error');
            return false;
        }

        // 已經有呢件商品 → 唔進入新增，避免建立重複商品
        if (lookup.found) {
            this.showScanNotice('商品已存在：' + lookup.product.name
                + '（$' + lookup.product.price + '）'
                + (lookup.product.is_available ? '' : '，已下架'), 'error');
            return false;
        }

        if (!confirm('條碼 ' + code + ' 未有對應商品，是否加入商品？')) {
            return false;
        }

        await this.showAddProductModal(code);
        return true;
    }

    /** 開啟新增商品視窗，並把掃到的條碼填入「商品UUID」（即商品條碼） */
    async showAddProductModal(code) {
        const modal = document.getElementById('product-modal');
        const form = document.getElementById('product-form');
        if (!modal || !form) return;

        form.reset();
        const uuidInput = document.getElementById('product-uuid');
        if (uuidInput) uuidInput.value = code;

        const uuidError = document.getElementById('product-uuid-error');
        if (uuidError) {
            uuidError.style.display = 'none';
            uuidError.textContent = '';
        }

        this.updateInventoryFieldState(false);
        this.updateTimeRestrictionFieldsState(false);
        await this.loadProductCategories();

        modal.classList.remove('hidden');
        const nameInput = document.getElementById('product-name');
        if (nameInput) setTimeout(() => nameInput.focus(), 300);
    }

    hideAddProductModal() {
        const modal = document.getElementById('product-modal');
        if (modal) modal.classList.add('hidden');
    }

    updateInventoryFieldState(noInventory) {
        const stockInput = document.getElementById('product-stock');
        const minStockInput = document.getElementById('product-min-stock');
        const noInventoryCheckbox = document.getElementById('product-no-inventory');
        if (!stockInput || !minStockInput || !noInventoryCheckbox) return;

        if (noInventory) {
            stockInput.disabled = true;
            stockInput.value = 0;
            minStockInput.disabled = true;
            minStockInput.value = 0;
            noInventoryCheckbox.checked = true;
        } else {
            stockInput.disabled = false;
            minStockInput.disabled = false;
            noInventoryCheckbox.checked = false;
        }
    }

    updateTimeRestrictionFieldsState(hasTimeRestriction) {
        const timeFields = document.getElementById('time-restriction-fields');
        if (timeFields) timeFields.style.display = hasTimeRestriction ? 'block' : 'none';
    }

    /** 讀取本分店商品分類；讀唔到就用後備清單 */
    async loadProductCategories() {
        let categories = null;
        try {
            const storeId = this.currentEmployee?.store_id;
            const response = await fetch('/api/products/categories'
                + (storeId ? '?store_id=' + encodeURIComponent(storeId) : ''), {
                headers: this.currentToken ? { 'Authorization': 'Bearer ' + this.currentToken } : {}
            });
            const result = await response.json();
            if (response.ok && result.success) {
                categories = (result.data && result.data.categories) || [];
            }
        } catch (error) {
            console.warn('讀取商品分類失敗，改用後備分類:', error.message);
        }

        if (!categories || categories.length === 0) {
            categories = DEFAULT_PRODUCT_CATEGORIES.slice();
        }

        const select = document.getElementById('product-category');
        if (!select) return;
        while (select.options.length > 1) select.remove(1);
        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = category;
            select.appendChild(option);
        });
    }

    /** 新增商品送出（欄位與收銀系統的新增商品一致） */
    async handleAddProductSubmit(event) {
        event.preventDefault();

        const uuidErrorElement = document.getElementById('product-uuid-error');
        if (uuidErrorElement) {
            uuidErrorElement.style.display = 'none';
            uuidErrorElement.textContent = '';
        }

        const customUUID = document.getElementById('product-uuid').value.trim();
        const noInventory = document.getElementById('product-no-inventory').checked;
        const productData = {
            name: document.getElementById('product-name').value.trim(),
            description: '',
            price: parseFloat(document.getElementById('product-price').value),
            stock: parseInt(document.getElementById('product-stock').value),
            min_stock: parseInt(document.getElementById('product-min-stock').value),
            category: document.getElementById('product-category').value,
            product_order: parseInt(document.getElementById('product-order').value) || 0,
            track_inventory: noInventory ? 0 : 1,
            // 商品時效字段
            has_time_restriction: document.getElementById('product-time-restriction').checked ? 1 : 0,
            weekday_start_time: document.getElementById('product-weekday-start').value || null,
            weekday_end_time: document.getElementById('product-weekday-end').value || null,
            holiday_start_time: document.getElementById('product-holiday-start').value || null,
            holiday_end_time: document.getElementById('product-holiday-end').value || null,
            weekday_start_time_2: document.getElementById('product-weekday-start-2').value || null,
            weekday_end_time_2: document.getElementById('product-weekday-end-2').value || null,
            holiday_start_time_2: document.getElementById('product-holiday-start-2').value || null,
            holiday_end_time_2: document.getElementById('product-holiday-end-2').value || null
        };

        if (noInventory) {
            productData.stock = 0;
            productData.min_stock = 0;
        }

        const showFormError = (message) => {
            if (uuidErrorElement) {
                uuidErrorElement.textContent = message;
                uuidErrorElement.style.display = 'block';
            }
            this.showScanNotice('新增商品失敗：' + message, 'error');
        };

        if (!productData.name || isNaN(productData.price) || productData.stock < 0) {
            showFormError('請填寫有效的商品名稱與價格');
            return;
        }
        // 商品 UUID 就係商品條碼
        if (customUUID) productData.id = customUUID;

        const saveBtn = document.getElementById('save-product-btn');
        if (saveBtn) {
            saveBtn.disabled = true;
            saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 儲存中...';
        }

        try {
            const storeId = this.currentEmployee?.store_id;
            const response = await fetch('/api/products'
                + (storeId ? '?store_id=' + encodeURIComponent(storeId) : ''), {
                method: 'POST',
                headers: Object.assign(
                    { 'Content-Type': 'application/json' },
                    this.currentToken ? { 'Authorization': 'Bearer ' + this.currentToken } : {}
                ),
                body: JSON.stringify(productData)
            });
            const result = await response.json();

            if (response.ok && result.success) {
                this.hideAddProductModal();
                this.showScanNotice('已新增商品：' + productData.name, 'success');
            } else {
                showFormError(result.message || result.error || '新增商品失敗');
            }
        } catch (error) {
            showFormError(error.message);
        } finally {
            if (saveBtn) {
                saveBtn.disabled = false;
                saveBtn.innerHTML = '保存商品';
            }
        }
    }

    displayCustomerInfo() {
        const customerInfo = document.getElementById('merged-customer-info');
        if (!customerInfo) return;

        customerInfo.innerHTML = `
            <div class="detail-row">
                <span class="detail-label">桌號:</span>
                <span class="detail-value">${this.customer.table_number}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">客人數:</span>
                <span class="detail-value">${this.customer.people_count}位</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">入場時間:</span>
                <span class="detail-value">${new Date(this.customer.entry_time).toLocaleTimeString('zh-TW')}</span>
            </div>
            <div class="detail-row total">
                <span class="detail-label">當前消費:</span>
                <span class="detail-value">$${this.customer.total_amount}</span>
            </div>
        `;
    }

    displayCheckoutInfo() {
        const checkoutInfo = document.getElementById('merged-checkout-info');
        if (!checkoutInfo) {
            console.warn('Element merged-checkout-info not found');
            return;
        }

        if (this.checkoutInfo.checked_out) {
            checkoutInfo.innerHTML = `
                <div class="detail-row">
                    <span class="detail-label">狀態:</span>
                    <span class="detail-value" style="color: #4CAF50;">已結賬</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">結賬時間:</span>
                    <span class="detail-value">${new Date(this.customer.checkout_time).toLocaleTimeString('zh-TW')}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">在場時間:</span>
                    <span class="detail-value">${this.calculateDuration(this.customer.entry_time, this.customer.checkout_time)}</span>
                </div>
            `;
        } else {
            checkoutInfo.innerHTML = `
                <div class="detail-row">
                    <span class="detail-label">狀態:</span>
                    <span class="detail-value" style="color: #e74c3c;">未結賬</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">在場時間:</span>
                    <span class="detail-value">${this.calculateDuration(this.customer.entry_time, new Date())}</span>
                </div>
                <div class="detail-row total">
                    <span class="detail-label">待結金額:</span>
                    <span class="detail-value">$${this.customer.total_amount}</span>
                </div>
            `;
        }
    }

    calculateDuration(startTime, endTime) {
        const start = new Date(startTime);
        const end = new Date(endTime);
        const diffMs = end - start;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMins / 60);
        const remainingMins = diffMins % 60;

        if (diffHours > 0) {
            return `${diffHours}小時${remainingMins}分鐘`;
        } else {
            return `${diffMins}分鐘`;
        }
    }

    displayPurchaseHistory() {
        console.log('displayPurchaseHistory called');
        const purchaseHistory = document.getElementById('purchase-history');
        console.log('Purchase history element:', purchaseHistory);

        // 安全檢查
        if (!this.checkoutInfo) {
            console.warn('checkoutInfo is null or undefined');
            purchaseHistory.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-history"></i>
                    <p>無購買記錄</p>
                </div>
            `;
            return;
        }

        if (!this.checkoutInfo.order_items || this.checkoutInfo.order_items.length === 0) {
            purchaseHistory.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-history"></i>
                    <p>無購買記錄</p>
                </div>
            `;
            return;
        }

        purchaseHistory.innerHTML = '';

        this.checkoutInfo.order_items.forEach((item, index) => {
            const itemEl = document.createElement('div');
            itemEl.className = 'purchase-item';
            itemEl.innerHTML = `
                <span>${item.product_name || '商品'}</span>
                <span>x${item.quantity}</span>
                <span>$${item.price_at_time * item.quantity}</span>
            `;
            purchaseHistory.appendChild(itemEl);
        });

        // 更新摘要
        let itemCount = 0;
        let totalAmount = 0;

        if (this.checkoutInfo.summary) {
            itemCount = this.checkoutInfo.summary.total_items || 0;
            totalAmount = this.checkoutInfo.summary.total_amount || 0;
        } else {
            // 計算總數
            this.checkoutInfo.order_items.forEach(item => {
                itemCount += item.quantity || 0;
                totalAmount += (item.price_at_time || 0) * (item.quantity || 0);
            });
        }

        document.getElementById('history-count').textContent = itemCount;
        document.getElementById('history-total').textContent = `$${totalAmount.toFixed(2)}`;
    }

    clearCustomer() {
        // 停止 KPay 付款輪詢 + 收起等待 modal
        this.stopPaymentPolling();
        this.hideKpayModals();
        this.kpayOutTradeNo = null;

        this.customer = null;
        this.checkoutInfo = null;

        // 重置合併的客人結賬信息
        const mergedCustomerCheckoutInfo = document.getElementById('merged-customer-checkout-info');
        if (mergedCustomerCheckoutInfo) {
            mergedCustomerCheckoutInfo.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-user-circle"></i>
                    <p data-i18n="emptyStateScanQR">請先掃描QR Code</p>
                </div>
            `;
        }

        // 重置購買記錄
        const purchaseHistory = document.getElementById('purchase-history');
        if (purchaseHistory) {
            purchaseHistory.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-history"></i>
                    <p data-i18n="emptyStateNoPurchase">無購買記錄</p>
                </div>
            `;
        }

        // 重置摘要計數
        const historyCount = document.getElementById('history-count');
        if (historyCount) {
            historyCount.textContent = '0';
        }
        const historyTotal = document.getElementById('history-total');
        if (historyTotal) {
            historyTotal.textContent = '$0';
        }

        // 顯示掃描提示卡片和手動輸入區，隱藏掃描結果容器
        const scanPromptCard = document.querySelector('.scan-prompt-card');
        const manualInputSection = document.querySelector('.manual-input-section');
        const scanResultContainer = document.querySelector('.scan-result-container');
        if (scanPromptCard) {
            scanPromptCard.classList.remove('hidden');
        }
        if (manualInputSection) {
            manualInputSection.classList.remove('hidden');
        }
        // 重置三個面板和結賬完成訊息
        const receiptPanel = document.querySelector('.receipt-panel');
        const customerCheckoutPanel = document.querySelector('.customer-checkout-panel');
        const paymentMethodsPanel = document.querySelector('.payment-methods-panel');
        const completionSection = document.getElementById('checkout-completion-section');
        if (receiptPanel) receiptPanel.classList.remove('hidden');
        if (customerCheckoutPanel) customerCheckoutPanel.classList.remove('hidden');
        if (paymentMethodsPanel) paymentMethodsPanel.classList.remove('hidden');
        if (completionSection) completionSection.classList.add('hidden');

        if (scanResultContainer) {
            console.log('Removing show-completion class from scan-result-container');
            scanResultContainer.classList.remove('show-completion');
            scanResultContainer.classList.add('hidden');
        }

        this.updateCheckoutButtons();
    }

    updateCheckoutButtons() {
        const hasCustomer = !!this.customer;
        const isCheckedOut = this.checkoutInfo?.checked_out;
        console.log('updateCheckoutButtons: hasCustomer=', hasCustomer, 'isCheckedOut=', isCheckedOut);

        const processBtn = document.getElementById('merged-process-checkout-btn');
        const printBtn = document.getElementById('merged-print-receipt-btn');
        if (processBtn) {
            processBtn.disabled = !hasCustomer || isCheckedOut;
            console.log('processBtn disabled:', processBtn.disabled);
        }
        if (printBtn) {
            printBtn.disabled = !hasCustomer;
            console.log('printBtn disabled:', printBtn.disabled);
        }
    }

    showCheckoutModal() {
        console.log('showCheckoutModal called');
        console.log('customer:', this.customer);
        console.log('checkoutInfo:', this.checkoutInfo);
        if (!this.customer || this.checkoutInfo?.checked_out) {
            console.log('Cannot show modal: no customer or already checked out');
            return;
        }

        // 更新模態框內容
        document.getElementById('modal-table').textContent = this.customer.table_number;
        document.getElementById('modal-people').textContent = `${this.customer.people_count}位`;

        const entryTime = new Date(this.customer.entry_time).toLocaleTimeString('zh-TW', {
            hour: '2-digit',
            minute: '2-digit'
        });
        document.getElementById('modal-entry-time').textContent = entryTime;

        const duration = this.calculateDuration(this.customer.entry_time, new Date());
        document.getElementById('modal-duration').textContent = duration;

        document.getElementById('modal-amount').textContent = `$${this.customer.total_amount}`;

        // 確保付款方式有選中項
        const modal = document.getElementById('checkout-modal');
        const paymentInputs = modal.querySelectorAll('input[name="payment-method"]');
        console.log('Payment inputs in modal:', paymentInputs.length);

        let hasChecked = false;
        for (const input of paymentInputs) {
            if (input.checked) {
                hasChecked = true;
                console.log('Checked payment input:', input.value);
                break;
            }
        }

        // 如果沒有選中項，選中第一個
        if (!hasChecked && paymentInputs.length > 0) {
            paymentInputs[0].checked = true;
            console.log('Set first payment input as checked:', paymentInputs[0].value);
        }

        // 顯示模態框
        modal.classList.remove('hidden');
        console.log('Modal shown');
    }

    hideCheckoutModal() {
        document.getElementById('checkout-modal').classList.add('hidden');
    }

    async confirmCheckout(paymentMethodOverride = null) {
        console.log('=== confirmCheckout START ===');
        console.log('customer:', this.customer);
        console.log('checkoutInfo:', this.checkoutInfo);
        if (!this.customer) {
            console.log('No customer, returning');
            return;
        }

        // 嘗試多種方法獲取付款方式
        let paymentMethod = 'cash'; // 默認值

        // If payment method override is provided, use it
        if (paymentMethodOverride !== null) {
            paymentMethod = paymentMethodOverride;
            console.log('Using payment method override:', paymentMethod);
        } else {
            let paymentMethodInput = null;

            // 方法1: 標準選擇器
            paymentMethodInput = document.querySelector('input[name="payment-method"]:checked');
            console.log('Method 1 - Standard selector:', paymentMethodInput);

            // 方法2: 查找模態框內的選擇器
            if (!paymentMethodInput) {
                const modal = document.getElementById('checkout-modal');
                if (modal && !modal.classList.contains('hidden')) {
                    paymentMethodInput = modal.querySelector('input[name="payment-method"]:checked');
                    console.log('Method 2 - Modal selector:', paymentMethodInput);
                }
            }

            // 方法3: 查找任何付款方式輸入
            if (!paymentMethodInput) {
                const allPaymentInputs = document.querySelectorAll('input[name="payment-method"]');
                console.log('Method 3 - All inputs:', allPaymentInputs);
                for (const input of allPaymentInputs) {
                    if (input.checked) {
                        paymentMethodInput = input;
                        console.log('Found checked input:', input);
                        break;
                    }
                }
            }

            // 方法4: 使用默認選中的第一個
            if (!paymentMethodInput) {
                const firstPaymentInput = document.querySelector('input[name="payment-method"]');
                console.log('Method 4 - First input:', firstPaymentInput);
                if (firstPaymentInput) {
                    // 檢查是否有checked屬性
                    if (firstPaymentInput.hasAttribute('checked') || firstPaymentInput.checked) {
                        paymentMethodInput = firstPaymentInput;
                    }
                }
            }

            if (paymentMethodInput) {
                paymentMethod = paymentMethodInput.value;
                console.log('Payment method found:', paymentMethod);
            } else {
                console.log('No payment method selected, using default: cash');
            }
        }

        console.log('Final paymentMethod:', paymentMethod);
        console.log('=== confirmCheckout PROCESSING ===');

        try {
            const response = await fetch('/api/exit/checkout', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    customer_id: this.customer.id,
                    payment_method: paymentMethod,
                    store_id: this.currentEmployee?.store_id || null
                })
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage(`結賬成功: 桌號 ${result.table_number}, 金額: $${result.total_amount}`, 'success');
                this.hideCheckoutModal();
                this.checkoutInfo.checked_out = true;
                this.displayCheckoutInfo();
                this.showCompletionForCurrentSale();
                this.updateCheckoutButtons();
                this.loadTodayStats();
                this.loadExitRecords();

                // 顯示門鎖開啟選項
                console.log('Calling showDoorOpenOption immediately');
                this.showDoorOpenOption();
            } else {
                this.addMessage('結賬失敗: ' + result.error, 'error');
            }
        } catch (error) {
            console.log('Checkout API failed, using mock success:', error.message);
            // 模擬結賬成功
            const mockResult = {
                success: true,
                table_number: this.customer.table_number,
                total_amount: this.customer.total_amount
            };

            this.addMessage(`結賬成功: 桌號 ${mockResult.table_number}, 金額: $${mockResult.total_amount}`, 'success');
            this.hideCheckoutModal();
            this.checkoutInfo.checked_out = true;
            this.displayCheckoutInfo();
            this.showCompletionForCurrentSale();
            this.updateCheckoutButtons();
            this.loadTodayStats();
            this.loadExitRecords();

            // 顯示門鎖開啟選項
            console.log('Calling showDoorOpenOption immediately (mock)');
            this.showDoorOpenOption();
        }
    }

    async printReceipt() {
        if (!this.customer) {
            return;
        }

        try {
            const response = await fetch('/api/receipt/print-checkout', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    table_number: this.customer.table_number,
                    qr_code: this.customer.qr_code,
                    total_amount: this.customer.total_amount,
                    checkout_time: new Date().toLocaleString('zh-TW'),
                    order_items: this.checkoutInfo.order_items || [],
                    store_id: this.currentEmployee?.store_id || null
                })
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage('收據打印指令已發送', 'success');
            } else {
                this.addMessage('打印失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('打印失敗: ' + error.message, 'error');
        }
    }

    showDoorOpenOption() {
        console.log('showDoorOpenOption called');
        if (confirm('結賬成功！是否現在開啟門鎖離場？')) {
            this.openDoorForExit();
        }
    }

    async openDoorForExit() {
        if (!this.customer) {
            return;
        }

        try {
            const response = await fetch('/api/exit/door-scan', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    qr_code: this.customer.qr_code,
                    store_id: this.currentEmployee?.store_id || null
                })
            });

            const result = await response.json();

            if (result.success && result.door_open) {
                this.addMessage('門鎖已開啟，請通行', 'success');
                this.showDoorOpenModal();
                this.updateDoorStatus(true);
            } else {
                this.addMessage(result.message || '無法開啟門鎖', 'error');
            }
        } catch (error) {
            this.addMessage('開啟門鎖失敗: ' + error.message, 'error');
        }
    }

    updateDoorStatus(isOpen) {
        this.doorOpen = isOpen;

        const doorIcon = document.getElementById('door-icon');
        const doorText = document.getElementById('door-text');
        const doorStatus = document.getElementById('door-status');

        // 如果元素存在才更新
        if (doorIcon) {
            if (isOpen) {
                doorIcon.innerHTML = '<i class="fas fa-door-open"></i>';
                doorIcon.style.color = '#4CAF50';
            } else {
                doorIcon.innerHTML = '<i class="fas fa-door-closed"></i>';
                doorIcon.style.color = '#e74c3c';
            }
        }

        if (doorText) {
            if (isOpen) {
                doorText.textContent = '門鎖狀態: 開啟';
                doorText.style.color = '#4CAF50';
            } else {
                doorText.textContent = '門鎖狀態: 鎖定';
                doorText.style.color = '#e74c3c';
            }
        }

        if (doorStatus) {
            doorStatus.textContent = isOpen ? '門鎖狀態: 開啟' : '門鎖狀態: 鎖定';
        }

        if (isOpen) {
            // 啟動門鎖計時器
            this.startDoorTimer();
        } else {
            // 停止計時器
            this.stopDoorTimer();
        }
    }

    startDoorTimer() {
        this.stopDoorTimer(); // 先停止現有計時器

        let seconds = 10;
        const timerFill = document.querySelector('.timer-fill');
        const timerSeconds = document.getElementById('timer-seconds');

        if (timerFill) {
            timerFill.style.animation = 'timerShrink 10s linear forwards';
        }
        if (timerSeconds) {
            timerSeconds.textContent = seconds;
        }

        this.doorTimer = setInterval(() => {
            seconds--;
            if (timerSeconds) {
                timerSeconds.textContent = seconds;
            }

            if (seconds <= 0) {
                this.stopDoorTimer();
                this.updateDoorStatus(false);
                this.addMessage('門鎖已自動關閉', 'info');
            }
        }, 1000);
    }

    stopDoorTimer() {
        if (this.doorTimer) {
            clearInterval(this.doorTimer);
            this.doorTimer = null;
        }

        const timerFill = document.querySelector('.timer-fill');
        if (timerFill) {
            timerFill.style.animation = '';
        }
    }

    showDoorOpenModal() {
        let seconds = 10;
        const doorOpenSeconds = document.getElementById('door-open-seconds');
        doorOpenSeconds.textContent = seconds;

        const countdown = setInterval(() => {
            seconds--;
            doorOpenSeconds.textContent = seconds;

            if (seconds <= 0) {
                clearInterval(countdown);
                this.hideDoorModal();
            }
        }, 1000);

        document.getElementById('door-modal').classList.remove('hidden');
    }

    hideDoorModal() {
        document.getElementById('door-modal').classList.add('hidden');
    }

    async loadTodayStats() {
        try {
            const response = await fetch('/api/exit/stats/today');
            const result = await response.json();

            if (result.success) {
                const stats = result.stats;
                document.getElementById('total-revenue').textContent = `$${stats.total_revenue || 0}`;
                document.getElementById('avg-checkout').textContent = `$${stats.avg_checkout ? stats.avg_checkout.toFixed(2) : 0}`;
                document.getElementById('peak-hour').textContent = stats.first_checkout ? new Date(stats.first_checkout).getHours() + ':00' : '--:--';
                document.getElementById('recent-checkout').textContent = Math.floor(Math.random() * 5); // 模擬數據
                document.getElementById('today-exits').textContent = stats.total_checkouts || 0;
            }
        } catch (error) {
            console.error('載入今日統計失敗:', error);
        }
    }

    async loadExitRecords() {
        try {
            // 簡化實現 - 使用現有API獲取結賬記錄
            const response = await fetch('/api/cashier/stats/today');
            const result = await response.json();

            if (result.success) {
                // 模擬離場記錄
                this.displayExitRecords(result.top_products || []);
            }
        } catch (error) {
            console.error('載入離場記錄失敗:', error);
        }
    }

    displayExitRecords(records) {
        const recordsList = document.querySelector('.records-list');

        if (!records || records.length === 0) {
            recordsList.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-clock"></i>
                    <p>暫無離場記錄</p>
                </div>
            `;
            return;
        }

        recordsList.innerHTML = '';

        // 顯示模擬記錄
        for (let i = 0; i < Math.min(5, records.length); i++) {
            const time = new Date(Date.now() - (i * 30 * 60000)).toLocaleTimeString('zh-TW', {
                hour: '2-digit',
                minute: '2-digit'
            });

            const recordEl = document.createElement('div');
            recordEl.className = 'record-item';
            recordEl.innerHTML = `
                <span>${time}</span>
                <span>B${i + 1}</span>
                <span>$${Math.floor(Math.random() * 500) + 100}</span>
            `;
            recordsList.appendChild(recordEl);
        }
    }

    addMessage(text, type = 'info') {
        // 系統訊息已禁用，不在界面上顯示
        return;
    }

    getMessageIcon(type) {
        switch(type) {
            case 'success': return 'check-circle';
            case 'warning': return 'exclamation-triangle';
            case 'error': return 'times-circle';
            default: return 'info-circle';
        }
    }

    clearMessages() {
        const messageLog = document.getElementById('message-log');
        if (messageLog) {
            messageLog.innerHTML = '';
            this.addMessage('訊息記錄已清空', 'info');
        }
    }

    systemCheck() {
        this.addMessage('開始系統檢查...', 'info');

        setTimeout(() => {
            this.addMessage('✓ 門鎖系統測試完成', 'success');
        }, 1000);

        setTimeout(() => {
            this.addMessage('✓ QR Code掃描器測試完成', 'success');
        }, 2000);

        setTimeout(() => {
            this.addMessage('✓ 打印機測試完成', 'success');
        }, 3000);

        setTimeout(() => {
            this.addMessage('系統檢查完成，所有功能正常', 'success');
        }, 4000);
    }

    testDoor() {
        this.addMessage('測試門鎖中...', 'info');

        // 模擬門鎖測試
        setTimeout(() => {
            this.addMessage('門鎖測試完成', 'success');
        }, 1000);
    }

    manualOpenDoor() {
        if (confirm('確定要手動開啟門鎖嗎？')) {
            this.addMessage('手動開啟門鎖', 'warning');
            this.updateDoorStatus(true);
            this.showDoorOpenModal();
        }
    }

    emergencyOpenDoor() {
        if (confirm('確定要執行緊急開門嗎？這會繞過所有安全檢查。')) {
            this.addMessage('緊急開門已執行', 'error');
            this.updateDoorStatus(true);
            this.showDoorOpenModal();
        }
    }

    quickTest() {
        console.log('=== QUICK TEST START ===');
        // 模擬掃描QR碼
        const testQRCode = 'TEST-QR-' + Date.now();
        console.log('Testing with QR code:', testQRCode);
        this.processQRCode(testQRCode);

        // 等待一下然後檢查按鈕狀態
        setTimeout(() => {
            console.log('After scan: customer=', this.customer);
            console.log('After scan: checkoutInfo=', this.checkoutInfo);

            const processBtn = document.getElementById('merged-process-checkout-btn');
            console.log('Process button disabled:', processBtn.disabled);

            // 如果按鈕啟用，嘗試點擊
            if (!processBtn.disabled) {
                console.log('Attempting to click process button');
                processBtn.click();
            } else {
                console.log('Process button is disabled, cannot proceed');
            }
        }, 1000);
    }

    displayMergedCustomerCheckoutInfo() {
        console.log('displayMergedCustomerCheckoutInfo called');
        const container = document.getElementById('merged-customer-checkout-info');
        console.log('Container found:', container);
        if (!container) return;

        if (!this.customer) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-user-circle"></i>
                    <p data-i18n="emptyStateScanQR">請先掃描QR Code</p>
                </div>
            `;
            return;
        }

        let html = `
            <div class="detail-row">
                <span class="detail-label">桌號:</span>
                <span class="detail-value">${this.customer.table_number}</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">客人數:</span>
                <span class="detail-value">${this.customer.people_count}位</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">入場時間:</span>
                <span class="detail-value">${new Date(this.customer.entry_time).toLocaleTimeString('zh-TW')}</span>
            </div>`;

        if (this.checkoutInfo && this.checkoutInfo.summary) {
            html += `
            <div class="detail-row">
                <span class="detail-label">商品數量:</span>
                <span class="detail-value">${this.checkoutInfo.summary.total_items}件</span>
            </div>`;
        }

        html += `
            <div class="detail-row total">
                <span class="detail-label">結賬金額:</span>
                <span class="detail-value">$${this.customer.total_amount}</span>
            </div>`;

        container.innerHTML = html;
    }

    showCheckoutCompletionUI() {
        console.log('showCheckoutCompletionUI called');
        // 隱藏三個面板
        const receiptPanel = document.querySelector('.receipt-panel');
        const customerCheckoutPanel = document.querySelector('.customer-checkout-panel');
        const paymentMethodsPanel = document.querySelector('.payment-methods-panel');
        if (receiptPanel) receiptPanel.classList.add('hidden');
        if (customerCheckoutPanel) customerCheckoutPanel.classList.add('hidden');
        if (paymentMethodsPanel) paymentMethodsPanel.classList.add('hidden');

        // 顯示結賬完成訊息
        const completionSection = document.getElementById('checkout-completion-section');
        if (completionSection) {
            completionSection.classList.remove('hidden');
        }

        // 添加置中樣式到掃描結果容器
        const scanResultContainer = document.querySelector('.scan-result-container');
        if (scanResultContainer) {
            console.log('Adding show-completion class to scan-result-container');
            scanResultContainer.classList.add('show-completion');
        }
    }

    bindPaymentOptions() {
        console.log('bindPaymentOptions called');
        // 只綁付款方式面板嘅掣（避免誤綁結賬 modal 內嘅 radio label）
        const paymentButtons = document.querySelectorAll('.payment-methods-panel .payment-option');
        console.log('Found payment buttons:', paymentButtons.length);
        paymentButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const paymentMethod = e.currentTarget.dataset.payment;
                this.handlePaymentMethodSelect(paymentMethod);
            });
        });
    }

    handlePaymentMethodSelect(paymentMethod) {
        console.log('Payment method selected:', paymentMethod);
        this.selectedPaymentMethod = paymentMethod;
        this.initiatePayment(paymentMethod);
    }

    showKpayWaitingModal(isCard) {
        console.log('showKpayWaitingModal called, isCard:', isCard);
        const modal = document.getElementById(isCard ? 'tap-card-modal' : 'scan-qr-modal');
        if (modal) modal.classList.remove('hidden');
    }

    hideKpayModals() {
        const tapCardModal = document.getElementById('tap-card-modal');
        const scanQrModal = document.getElementById('scan-qr-modal');
        if (tapCardModal) tapCardModal.classList.add('hidden');
        if (scanQrModal) scanQrModal.classList.add('hidden');
    }

    // ===== KPay 卡機收款流程 =====

    // 啟動 KPay 卡機收款（mock 模式 3 秒後自動模擬成功）
    async initiatePayment(paymentMethod) {
        if (!this.customer) return;

        const isCard = (paymentMethod === 'card');
        this.showKpayWaitingModal(isCard);
        this.addMessage('正在啟動卡機收款...', 'info');

        try {
            const response = await fetch('/api/kpay/pay', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    customer_id: this.customer.id,
                    payment_type: paymentMethod,
                    store_id: this.currentEmployee?.store_id || null
                })
            });
            const result = await response.json();

            if (!result.success) {
                this.hideKpayModals();
                this.addMessage('啟動收款失敗: ' + (result.error || result.message || '未知錯誤'), 'error');
                return;
            }

            this.kpayOutTradeNo = result.out_trade_no;
            this.addMessage('請喺卡機完成付款', 'info');
            this.pollPaymentStatus();
        } catch (error) {
            this.hideKpayModals();
            this.addMessage('啟動收款失敗: ' + error.message, 'error');
        }
    }

    // 輪詢支付狀態（每 2 秒；付款成功 → 結賬 UI + 開門）
    pollPaymentStatus() {
        this.stopPaymentPolling();
        this.paymentPollTimer = setInterval(async () => {
            try {
                const response = await fetch('/api/kpay/status?customer_id=' + encodeURIComponent(this.customer.id));
                const result = await response.json();
                if (!result.success) return;

                if (result.status === 'success') {
                    this.stopPaymentPolling();
                    this.hideKpayModals();
                    this.onKpayPaymentSuccess();
                } else if (result.status === 'failed' || result.status === 'cancelled' || result.status === 'timeout') {
                    this.stopPaymentPolling();
                    this.hideKpayModals();
                    // 卡機回報的原因（例如「請顧客使用另一張卡」）比狀態碼有用，優先顯示
                    const reason = result.payment && result.payment.reason;
                    this.addMessage(
                        reason
                            ? '付款未完成：' + reason
                            : '付款未完成 (' + result.status + ')，請重試或選其他方式',
                        'error'
                    );
                }
                // pending → 繼續等
            } catch (error) {
                // 網絡錯誤唔好即停，等下次輪詢
                console.warn('查詢支付狀態失敗:', error.message);
            }
        }, 2000);
    }

    stopPaymentPolling() {
        if (this.paymentPollTimer) {
            clearInterval(this.paymentPollTimer);
            this.paymentPollTimer = null;
        }
    }

    // 取消進行中嘅付款
    // server close 後會補 query；若客喺 close race window 已俾咗錢 → server 回 status:'success' → 照當成功
    async cancelKpayPayment() {
        this.stopPaymentPolling();
        let result = null;
        if (this.customer) {
            try {
                const response = await fetch('/api/kpay/cancel', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ customer_id: this.customer.id })
                });
                result = await response.json();
            } catch (e) { /* ignore */ }
        }
        if (result && result.success && result.status === 'success') {
            this.onKpayPaymentSuccess();
            return;
        }
        this.hideKpayModals();
        this.addMessage('已取消付款', 'info');
    }

    // 付款成功（server 已喺 callback 度結賬 + emit checkout-complete）
    onKpayPaymentSuccess() {
        this.addMessage(`結賬成功: 桌號 ${this.customer.table_number}, 金額: $${this.customer.total_amount}`, 'success');
        if (this.checkoutInfo) this.checkoutInfo.checked_out = true;
        if (this.customer) this.customer.checkout_time = new Date().toISOString();
        this.displayCheckoutInfo();
        this.showCompletionForCurrentSale();
        this.updateCheckoutButtons();
        this.loadTodayStats();
        this.loadExitRecords();
        console.log('Calling showDoorOpenOption after payment success');
        this.showDoorOpenOption();
    }

    // ===== 登入相關方法 =====

    checkSavedLogin() {
        try {
            const savedToken = localStorage.getItem('exit_token');
            const savedEmployee = localStorage.getItem('exit_employee');
            const savedExpires = localStorage.getItem('exit_token_expires');

            if (savedToken && savedEmployee && savedExpires) {
                const expiresAt = new Date(savedExpires);
                if (expiresAt > new Date()) {
                    this.currentToken = savedToken;
                    this.currentEmployee = JSON.parse(savedEmployee);
                    this.tokenExpiresAt = expiresAt;
                    this.isAuthenticated = true;
                    this.updateLoginUI();
                    // 有有效token，隱藏登入遮罩
                    this.hideForcedLogin();
                    return;
                }
                // 令牌過期，清除
                this.clearSavedLogin();
            }
        } catch (error) {
            console.error('檢查登入狀態失敗:', error);
            this.clearSavedLogin();
        }

        // 未登入或令牌已過期，顯示登入
        this.showForcedLogin();
    }

    showForcedLogin() {
        const overlay = document.getElementById('login-overlay');
        if (overlay) overlay.classList.remove('hidden');
        document.body.classList.add('login-required');
        this.showLoginModal(true);
    }

    hideForcedLogin() {
        const overlay = document.getElementById('login-overlay');
        if (overlay) overlay.classList.add('hidden');
        document.body.classList.remove('login-required');
        this.hideLoginModal();
    }

    saveLoginToStorage(token, employee, expiresAt) {
        try {
            localStorage.setItem('exit_token', token);
            localStorage.setItem('exit_employee', JSON.stringify(employee));
            if (expiresAt) {
                localStorage.setItem('exit_token_expires', expiresAt);
            }
        } catch (error) {
            console.error('保存登入信息失敗:', error);
        }
    }

    clearSavedLogin() {
        localStorage.removeItem('exit_token');
        localStorage.removeItem('exit_employee');
        localStorage.removeItem('exit_token_expires');
    }

    updateLoginUI() {
        const loginBtn = document.getElementById('staff-login-btn');
        const loginText = document.getElementById('login-btn-text');
        const settingsBtn = document.getElementById('settings-btn');
        // 用途設定與退出 app 按鈕只有登入後才顯示
        const exitBtn = document.getElementById('exit-app-btn');
        const scanModeBtn = document.getElementById('scan-mode-btn');
        if (this.isAuthenticated && this.currentEmployee) {
            loginBtn.classList.add('logged-in');
            loginText.textContent = this.currentEmployee.full_name || '已登入';
            loginBtn.title = '點擊登出';
            // KPay 設定只在登入後顯示（進入時仍須重新驗證）
            if (settingsBtn) settingsBtn.classList.remove('hidden');
            if (scanModeBtn) scanModeBtn.classList.remove('hidden');
            if (exitBtn) exitBtn.classList.remove('hidden');
        } else {
            loginBtn.classList.remove('logged-in');
            loginText.textContent = '登入';
            loginBtn.title = '';
            if (settingsBtn) settingsBtn.classList.add('hidden');
            if (scanModeBtn) scanModeBtn.classList.add('hidden');
            if (exitBtn) exitBtn.classList.add('hidden');
        }
    }

    showLoginModal(force = false) {
        const loginModal = document.getElementById('login-modal');
        const loginForm = document.getElementById('login-form');
        if (!loginModal || !loginForm) return;

        loginForm.reset();
        loginModal.classList.remove('hidden');

        const cancelBtn = document.getElementById('cancel-login-btn');
        if (cancelBtn) {
            cancelBtn.style.display = force ? 'none' : '';
        }
    }

    hideLoginModal() {
        const loginModal = document.getElementById('login-modal');
        if (loginModal) loginModal.classList.add('hidden');
    }

    // ===== KPay 設定 =====

    // 顯示重驗證視窗（修改設定前必須重新輸入員工帳號密碼）
    showReauthModal() {
        const modal = document.getElementById('reauth-modal');
        const form = document.getElementById('reauth-form');
        if (!modal || !form) return;
        form.reset();
        this._setMsg('reauth-error', null);
        modal.classList.remove('hidden');
        const input = document.getElementById('reauth-username');
        if (input) input.focus();
    }

    hideReauthModal() {
        const modal = document.getElementById('reauth-modal');
        if (modal) modal.classList.add('hidden');
    }

    // 重驗證：呼叫既有 /api/auth/login，成功後把 token 與角色存於記憶體
    async handleReauthSubmit(event) {
        event.preventDefault();
        const submitBtn = document.getElementById('submit-reauth-btn');
        const username = (document.getElementById('reauth-username') || {}).value || '';
        const password = (document.getElementById('reauth-password') || {}).value || '';
        if (!username || !password) return;

        this._setMsg('reauth-error', null);
        if (submitBtn) submitBtn.disabled = true;

        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username: username.trim(), password })
            });
            const result = await response.json();

            if (!result.success) {
                this._setMsg('reauth-error', result.message || result.error || '驗證失敗');
                return;
            }

            this.reAuthToken = result.data.token;
            this.reAuthRole = result.data.employee.role;
            this.reAuthName = result.data.employee.full_name || username;

            this.hideReauthModal();
            this.showKpaySettingsModal();
        } catch (error) {
            this._setMsg('reauth-error', '連線失敗：' + error.message);
        } finally {
            if (submitBtn) submitBtn.disabled = false;
        }
    }

    showKpaySettingsModal() {
        const modal = document.getElementById('kpay-settings-modal');
        if (!modal) return;
        this._setMsg('settings-error', null);
        this._setMsg('settings-success', null);
        this._setMsg('settings-warning', null);
        const fieldsBox = document.getElementById('settings-fields');
        if (fieldsBox) fieldsBox.innerHTML = '<p class="settings-note">載入中……</p>';
        modal.classList.remove('hidden');
        this.loadKpaySettings();
    }

    hideKpaySettingsModal() {
        const modal = document.getElementById('kpay-settings-modal');
        if (modal) modal.classList.add('hidden');
        // 關閉即清除重驗證憑證，下次進入需重新驗證
        this.reAuthToken = null;
        this.reAuthRole = null;
        this.reAuthName = null;
    }

    async loadKpaySettings() {
        try {
            const response = await fetch('/api/kpay/settings', {
                headers: { 'Authorization': 'Bearer ' + this.reAuthToken }
            });
            const result = await response.json();

            if (!result.success) {
                this._setMsg('settings-error', result.message || result.error || '讀取設定失敗');
                return;
            }
            this.renderKpaySettings(result.data);
        } catch (error) {
            this._setMsg('settings-error', '連線失敗：' + error.message);
        }
    }

    // 依 role 與 editable 標記產生欄位（伺服器端仍會再檢查一次權限）
    renderKpaySettings(data) {
        const fieldsBox = document.getElementById('settings-fields');
        const roleNote = document.getElementById('settings-role-note');
        if (!fieldsBox) return;

        if (roleNote) {
            const roleText = data.role === 'admin' ? '管理員' : '員工';
            roleNote.textContent =
                `目前以「${this.reAuthName || ''}」（${roleText}）驗證。` +
                `儲存後需重啟服務才會生效。`;
        }

        const esc = (s) => String(s === undefined || s === null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

        let html = '';
        for (const [key, f] of Object.entries(data.fields)) {
            html += '<div class="settings-field">';
            html += `<label for="field-${esc(key)}">${esc(f.label)}</label>`;
            if (f.hint) html += `<span class="field-hint">${esc(f.hint)}</span>`;

            if (f.secret) {
                // 機密欄位：永不回填值；留空表示不變更
                const status = f.is_set ? '已設定' : '未設定';
                html += `<input type="password" id="field-${esc(key)}" data-key="${esc(key)}" `
                    + `data-secret="1" autocomplete="new-password" `
                    + `placeholder="${f.editable ? `留空表示不變更（目前${status}）` : status}" `
                    + `${f.editable ? '' : 'disabled'}>`;
            } else if (f.editable) {
                html += `<input type="text" id="field-${esc(key)}" data-key="${esc(key)}" `
                    + `value="${esc(f.value)}">`;
            } else {
                html += `<div class="readonly-value">${esc(f.value) || '（未設定）'}</div>`;
            }
            html += '</div>';
        }
        fieldsBox.innerHTML = html;

        const saveBtn = document.getElementById('save-settings-btn');
        if (saveBtn) {
            const hasEditable = Object.values(data.fields).some((f) => f.editable);
            saveBtn.disabled = !hasEditable;
        }
    }

    async saveKpaySettings() {
        const saveBtn = document.getElementById('save-settings-btn');
        this._setMsg('settings-error', null);
        this._setMsg('settings-info', null);
        this._setMsg('settings-success', null);
        this._setMsg('settings-warning', null);

        const payload = {};
        document.querySelectorAll('#settings-fields [data-key]').forEach((el) => {
            const key = el.getAttribute('data-key');
            const value = el.value;
            // 機密欄位留空 = 不變更（不送出）
            if (el.getAttribute('data-secret') === '1' && value.trim() === '') return;
            payload[key] = value;
        });

        if (Object.keys(payload).length === 0) {
            this._setMsg('settings-warning', '沒有可儲存的欄位。');
            return;
        }

        if (saveBtn) saveBtn.disabled = true;
        try {
            const response = await fetch('/api/kpay/settings', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + this.reAuthToken
                },
                body: JSON.stringify(payload)
            });
            const result = await response.json();

            if (!result.success) {
                this._setMsg('settings-error', result.message || result.error || '儲存失敗');
                return;
            }

            const d = result.data;
            if (!d.changed || d.changed.length === 0) {
                this._setMsg('settings-info', d.message || '設定未變更。');
            } else {
                let msg = `已更新 ${d.changed.length} 個欄位，請重啟服務以生效。`;
                if (d.backup_file) msg += `（已備份為 ${d.backup_file}）`;
                this._setMsg('settings-success', msg);
            }
            if (d.warnings && d.warnings.length) {
                this._setMsg('settings-warning', d.warnings.join('；'));
            }
            // 重新載入以反映最新值
            this.loadKpaySettings();
        } catch (error) {
            this._setMsg('settings-error', '連線失敗：' + error.message);
        } finally {
            if (saveBtn) saveBtn.disabled = false;
        }
    }

    // 訊息顯示輔助：id 對應 error / success / warning / notice 元素
    _setMsg(elementId, text) {
        const el = document.getElementById(elementId);
        if (!el) return;
        if (!text) {
            el.textContent = '';
            el.classList.add('hidden');
            return;
        }
        el.textContent = text;
        el.classList.remove('hidden');
    }

    async handleLoginSubmit(event) {
        event.preventDefault();

        const username = document.getElementById('login-username').value.trim();
        const password = document.getElementById('login-password').value;

        if (!username || !password) return;

        const submitBtn = document.getElementById('submit-login-btn');
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 登入中...';
        }

        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });

            const result = await response.json();

            if (response.ok && result.success) {
                const { employee, token, expires_at } = result.data || {};
                this.currentToken = token;
                this.currentEmployee = employee;
                this.isAuthenticated = true;

                const expiresAt = expires_at ? new Date(expires_at) : new Date();
                if (!expires_at) expiresAt.setHours(expiresAt.getHours() + 24);
                this.tokenExpiresAt = expiresAt;

                this.saveLoginToStorage(token, employee, expiresAt.toISOString());
                this.updateLoginUI();
                this.hideForcedLogin();
                this.addMessage(`登入成功，歡迎 ${employee.full_name}`, 'success');
            } else {
                this.addMessage(`登入失敗: ${result.message || '帳號或密碼錯誤'}`, 'error');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '登入';
                }
            }
        } catch (error) {
            this.addMessage(`登入請求失敗: ${error.message}`, 'error');
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '登入';
            }
        }
    }

    logout() {
        this.isAuthenticated = false;
        this.currentEmployee = null;
        this.currentToken = null;
        this.tokenExpiresAt = null;
        // 登出同時清除 KPay 設定的重驗證憑證與已開啟的視窗
        this.reAuthToken = null;
        this.reAuthRole = null;
        this.reAuthName = null;
        this.hideReauthModal();
        this.hideKpaySettingsModal();
        this.clearSavedLogin();
        this.updateLoginUI();
        this.addMessage('已登出', 'info');
        this.clearCustomer();
        this.showForcedLogin();
    }

}

// 初始化應用
document.addEventListener('DOMContentLoaded', () => {
    window.exitMachine = new ExitMachine();
});