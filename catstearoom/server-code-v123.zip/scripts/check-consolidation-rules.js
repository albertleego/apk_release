#!/usr/bin/env node
/**
 * 代碼整合守則檢查（guard script）
 *
 * 確保 Feature Flags 集中喺 server/config/runtime.js，唔准喺其他 code 直接寫 env。
 * 違規 → 退出碼 1（git pre-commit 會擋住 commit）。
 *
 * 用法：
 *   node scripts/check-consolidation-rules.js
 * 或經 pre-commit hook 自動跑。
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const CONFIG_FILE = 'server/config/runtime.js';

// 受 runtime.js 管理嘅環境變數：RUNNING_MODE + MODE_DEFAULTS 內嘅 feature flags
// ENABLE_SYNC / SYNC_MOCK_MODE 係平板 data sync 本身嘅 config（唔係 feature flag），容許直接用
const FEATURE_FLAG_RE = /process\.env\.(RUNNING_MODE|ENABLE_[A-Z0-9_]+|ALLOW_CROSS_STORE_ADMIN)\b/g;
const SYNC_ALLOWLIST = ['ENABLE_SYNC', 'SYNC_MOCK_MODE'];

/** 遞歸收集所有 .js 同 .md 檔（跳過 node_modules / .git） */
// 點解要掃 .md：2026-09-17 喺 MD Files/ 發現三個真實憑證（一個 Twilio auth token
// 同一個 production admin 密碼）—— 舊版只掃 code 檔，文件嘅密碼一路溜過。
function collectFiles(dir, out = []) {
    if (dir.includes('node_modules') || dir.includes('.git')) return out;
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
    catch (e) { return out; }
    for (const entry of entries) {
        if (entry.name === 'node_modules' || entry.name === '.git') continue;
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) collectFiles(full, out);
        else if (entry.name.endsWith('.js') || /\.(md|MD)$/.test(entry.name)) out.push(full);
    }
    return out;
}

// ---------- 第一層檢查：feature flags 集中喺 runtime.js ----------
const violations = [];
for (const file of collectFiles(ROOT)) {
    const rel = path.relative(ROOT, file).replace(/\\/g, '/');
    if (rel === CONFIG_FILE) continue; // runtime.js 本身例外
    if (!rel.endsWith('.js')) continue; // feature flag 檢查只針對 code；.md 唔會引用 process.env
    const lines = fs.readFileSync(file, 'utf8').split('\n');
    lines.forEach((line, i) => {
        const matches = line.match(FEATURE_FLAG_RE);
        if (!matches) return;
        for (const m of matches) {
            const flagName = m.replace('process.env.', '');
            if (SYNC_ALLOWLIST.includes(flagName)) continue;
            violations.push(`${rel}:${i + 1}: ${m} 唔應該喺 runtime.js 以外直接用，請改用 runtime.xxx()`);
        }
    });
}

// ---------- 第二層檢查：硬寫 credential（密碼 / API key / token）----------
// 掃 .js / .py / .sh / .json，檢查有冇硬寫敏感值入 code。
// 豁免：.env 相關、config 範例檔、placeholder / 假值 / 空值、
//       gitignored 工作目錄（唔會 commit）、console.log 訊息、test 檔。
const CRED_SUSPECT_RE = /\b(password|passwd|api[_-]?key|apikey|token|secret|client[_-]?secret|access[_-]?key|private[_-]?key)\b\s*[:=]\s*['"][^'"]{6,}['"]/i;
// 真正洩漏過、需要防止回流的 live credential（唔含 DB seed 預設值 / test 值）。
// 呢個清單係「一旦外洩過就永久封鎖」嘅安全網：唔理出現喺咩格式（KEY=值、
// 表格、自由文字），只要值再出現就報錯。
const KNOWN_LIVE_KEYS = [
    '1c44e7dffb6748ce7c8ce52a7a0c6fcfe03aa515ba4b065f5a24a4ac35a36763', // ALIYUN_API_KEY（live，已輪換計劃中）
    'a693cdc9124815afa23a90e3dd66bb80e69546cafcfe8fdb1b9ceb6173ab29ac', // staging（g8y）ALIYUN_API_KEY，2026-08-30 輪換
    'temp123456!', // 舊阿里雲 root 密碼
    'temp1234!',   // 舊阿里雲 root 密碼
    // 2026-09-17 掃 .md 時新發現，已由用戶輪換：
    'adminlee',                            // production admin 密碼（MD Files 四處）
    'auto-cafe-2024',                      // catstearoom.dev nginx Basic Auth 密碼
    'faee9db503ab457394ecde7d0ae6a9a3',    // Twilio AUTH_TOKEN（MD Files/TWILIO.MD）
];
const PLACEHOLDER_PATTERN = /^['"]?[<(\[{]?(your_|your-|xxx+|<|placeholder|changeme|example|dummy|your|[A-Z_]+_KEY|[A-Z_]+_SECRET|[A-Z_]+_PASSWORD)/i;
// gitignored 工作目錄 / backup 檔 / test 檔（唔會 commit，掃佢哋只會誤報）
const CRED_EXEMPT_PATTERNS = [
    /\.env(\.|$)/,                 // .env 同 .env.*（真正放 secret 嘅地方）
    /\.example\.[a-z]+$/,          // config 範例（.env.example 等）
    /\.gitignore$/,                // 唔係 code
    /check-consolidation-rules\.js$/, // 自己
    /(^|\/)(aliyun-current|aliyun-modify-work|temp-aliyun-fix|temp-aliyun-fix-modify|aliyun-backup-product-modal)\//, // gitignored 工作目錄
    /(^|\/)(aliyun_enhanced_cashier|aliyun-backup-product-modal)/, // gitignored 備份檔
    /\.(backup|bak)\./,
    /\.backup$|\.bak$/,
    /(^|\/)(test|test-|test_|\.test\.)[^/]*\.(js|py|ts|sh)$/, // test 檔（gitignored test*.js）
    /ALIYUN_ROOT_PASSWORD|PRODUCTION_ECS_PASSWORD|DEMO_STAGING_ECS_PASSWORD/, // 密碼變數名出現喺錯誤訊息 / 提示文案（唔係值）
];
const CRED_ALLOWED_VALUE_RE = /^(process\.env\.|config\.|runtime\.|os\.environ|process\.env\[|const\s+ALIYUN_API_KEY)/;

// ── Markdown 專用（2026-09-17 加）──
// 文件嘅 .env 範例通常**冇引號**（`KEY=值`），上面嘅 CRED_SUSPECT_RE 要求引號所以捉唔到。
// 呢個 pattern 亦處理 `- **Password**: \`值\`` 同 `KEY=值 # 註解` 呢類寫法。
const MD_CRED_RE = /\b(password|passwd|api[_-]?key|apikey|auth[_-]?token|token|secret|client[_-]?secret|access[_-]?key|private[_-]?key)\b\s*\*{0,2}\s*[:=]\s*\*{0,2}\s*[`'"]?([A-Za-z0-9_!@#$%^&*.\-+]{6,})[`'"]?/i;

// 明顯唔係真憑證嘅值：佔位符、變數引用、指令選項、shell 展開
const MD_VALUE_OK_RE = /^(your_|your-|xxx|placeholder|changeme|example|dummy|YOUR_|SOME_|MY_|--|\$|\.\.\.)/i;

// 文件唔應該有真憑證，但有幾類行係正常寫法，唔算違規：
const MD_LINE_OK_RE = [
    /^\s*\/\//,                       // 註解
    /^\s*#/,                          // 註解 / shell 註解
    /process\.env\./,                 // 講解程式碼
    /<[^>]+>/,                        // 用角括號做佔位（<你的密碼>）
    /\$\{?[A-Z_]+/,                   // shell 變數展開
    // JS 程式碼片段：文件用「縮排區塊」展示程式碼時唔會有 ``` 圍欄，
    // 所以要靠內容特徵分辨（例：const apiKey = req.headers[...]）。
    /\breq\.|\bres\.|\bnext\(\)/,     // Express middleware 片段
    /^\s*(const|let|var|function|return|if|else|for|while|await|import|export)\b/,
    // JS 物件字面值，例如 `token: apiKey`（真憑證通常係 KEY=值 或 **Key**: `值`）
    /^\s*[\w$]+\s*:\s*[A-Za-z_$][\w$]*\s*,?\s*$/,
];

const knownLeakedFiles = new Set();
const credViolations = [];
const ALREADY_TRACKED_EXT = /\.(js|py|sh|json|ts|mjs|cjs)$/;

for (const file of collectFiles(ROOT)) {
    const rel = path.relative(ROOT, file).replace(/\\/g, '/');
    if (rel === CONFIG_FILE) continue; // runtime.js 本身例外（第一層）
    if (CRED_EXEMPT_PATTERNS.some(p => p.test(rel))) continue;
    const isMd = /\.(md|MD)$/.test(rel);
    if (!ALREADY_TRACKED_EXT.test(rel) && !isMd) continue;

    const content = fs.readFileSync(file, 'utf8');
    const lines = content.split('\n');

    // Markdown 內標為「程式語言」嘅 code fence：入面係示範程式碼（例：apiKey = req.headers[...]），
    // 唔係憑證，所以要跳過。留意 ```env / ```bash 唔喺呢個清單 —— 嗰啲係真嘅設定範例，要照掃。
    const MD_CODE_LANGS = /^(js|javascript|ts|typescript|py|python|java|json|c|cpp|go|rust|rb|ruby|php|cs|kotlin|swift)$/i;
    let inFence = false;
    let fenceIsCodeLang = false;

    // (a) 硬寫 credential pattern
    lines.forEach((line, i) => {
        const trimmed = line.trim();

        if (isMd) {
            const fence = trimmed.match(/^```\s*(\w*)/);
            if (fence) {
                if (!inFence) {
                    inFence = true;
                    fenceIsCodeLang = MD_CODE_LANGS.test(fence[1] || '');
                } else {
                    inFence = false;
                    fenceIsCodeLang = false;
                }
                return; // fence 分隔線本身唔係內容
            }
            if (fenceIsCodeLang) return; // 程式碼範例，跳過

            // 文件：用寬鬆 pattern（值通常冇引號），但要排除正常寫法
            if (MD_LINE_OK_RE.some(p => p.test(trimmed))) return;
            const mm = trimmed.match(MD_CRED_RE);
            if (!mm) return;
            if (MD_VALUE_OK_RE.test(mm[2])) return;        // 佔位符 / 變數 / 選項
            if (PLACEHOLDER_PATTERN.test(mm[2])) return;   // your_xxx 之類
            // ⚠️ 只顯示前 4 個字元，避免把憑證寫入 CI log
            credViolations.push(
                `${rel}:${i + 1}: 文件含疑似真實憑證（${mm[1]}=${mm[2].slice(0, 4)}…）— 文件唔應該放真憑證，請改佔位符`
            );
            return;
        }

        if (CRED_ALLOWED_VALUE_RE.test(trimmed)) return;             // 讀 env / config 嘅唔算
        if (PLACEHOLDER_PATTERN.test(trimmed)) return;               // placeholder 唔算
        if (/^console\.(log|error|warn|info)/.test(trimmed)) return; // log 訊息唔算 credential
        // 值來源係 env / config（例如 apiKey='${process.env.X}'）唔算硬寫
        if (/process\.env\.|process\.env\[|config\.|runtime\.|os\.environ/.test(trimmed)) return;
        const m = trimmed.match(CRED_SUSPECT_RE);
        if (m) {
            credViolations.push(`${rel}:${i + 1}: 疑似硬寫 credential：${m[0].slice(0, 60)} — 請改用 .env / config，唔好寫入 code`);
        }
    });

    // (b) 已知 live key 殘留
    if (KNOWN_LIVE_KEYS.some(k => content.includes(k))) {
        knownLeakedFiles.add(rel);
    }
}

for (const rel of knownLeakedFiles) {
    credViolations.push(`${rel}: 含已知 live credential（已被標記洩漏），請移除或改讀 .env`);
}

const allViolations = [...violations, ...credViolations];

if (allViolations.length) {
    console.error('❌ 代碼整合守則違規：');
    allViolations.forEach(v => console.error('  ' + v));
    console.error('\n修正方法：');
    console.error('  · feature flags → 去 server/config/runtime.js 定義，用 runtime.xxx() 引用');
    console.error('  · credential → 放入 .env（gitignored），code 用 process.env.XXX 讀取');
    process.exit(1);
}
console.log('✓ 代碼整合守則檢查通過（feature flags 集中喺 runtime.js + 無硬寫 credential）');
