#!/usr/bin/env python3
"""
把已領養貓貓的相片上傳到 Google Drive 的「己領養」資料夾。

用法：
    python3 scripts/upload-adopted-photo.py --file <相片路徑> --name <檔名>

輸出（單行 JSON，方便 node 解析）：
    {"ok": true,  "id": "...", "name": "...", "action": "created|updated"}
    {"ok": false, "error": "..."}

由 server/services/catStatus.js 旁邊的路由呼叫（後台按「已領養」時問要不要存檔）。

⚠️ 為什麼用 drive_token.json（OAuth 帳戶）而不是 service account：
   2026-09-30 實測，用 service account（scripts/google-sheets-key.json）
   上傳會回 403：
       "Service Accounts do not have storage quota. Leverage shared drives..."
   服務帳戶本身**沒有儲存配額**，所以即使有資料夾的編輯權，也不能把檔案
   放進一般（My Drive）資料夾 —— 這是 Google 的硬性限制。
   只有兩種情況可以：資料夾位於「團隊雲端硬碟」，或改用有配額的真人帳戶。
   這裡用後者（drive_token.json = albertleetmail@gmail.com，
   與定時任務 cbos_download.py 下載 Drive 檔案同一個帳戶），
   所以**該帳戶必須對資料夾有編輯權**。

   若日後把資料夾搬進團隊雲端硬碟，改回 service account 只需改下面
   _creds() 一處。

設計取捨：
  * 同名檔案已存在就**更新內容**而不是再建一個 —— 同一隻貓重複按「已領養」
    不會在 Drive 留下一堆重複檔。
  * 任何失敗都以 {"ok": false} 回報，**不會拋 traceback 到 stdout**，
    因為呼叫方（node）要解析這一行 JSON。
"""

import argparse
import json
import os
import sys

from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

_HERE = os.path.dirname(os.path.abspath(__file__))
TOKEN_PATH = os.environ.get('DRIVE_TOKEN_PATH', os.path.join(_HERE, 'drive_token.json'))

# 「己領養」資料夾（站主把編輯權分享給上面的 service account）
FOLDER_ID = os.environ.get('DRIVE_ADOPTED_FOLDER_ID', '1HYidOfmxwikE7uH7AM0gHL3FpAlKk1uE')

MIME_BY_EXT = {
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.webp': 'image/webp',
}


def fail(msg):
    print(json.dumps({'ok': False, 'error': str(msg)}, ensure_ascii=False))
    sys.exit(0)   # 用 0 退出：呼叫方靠 JSON 的 ok 判斷，不是 exit code


def drive_service():
    """用 OAuth refresh token 建立 Drive client（見檔頭：為何不用 service account）"""
    if not os.path.exists(TOKEN_PATH):
        raise RuntimeError('找不到 Drive 憑證: ' + TOKEN_PATH)
    with open(TOKEN_PATH) as f:
        t = json.load(f)
    creds = Credentials(
        None,
        refresh_token=t['refresh_token'],
        token_uri=t.get('token_uri', 'https://oauth2.googleapis.com/token'),
        client_id=t['client_id'],
        client_secret=t['client_secret'],
    )
    creds.refresh(Request())
    # token 更新後寫回，與 cbos_download.py 的做法一致
    if creds.token and creds.token != t.get('access_token'):
        t['access_token'] = creds.token
        try:
            with open(TOKEN_PATH, 'w') as f:
                json.dump(t, f)
        except OSError:
            pass   # 寫不回不影響本次上傳
    return build('drive', 'v3', credentials=creds)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--file', required=True, help='本機相片路徑')
    ap.add_argument('--name', required=True, help='上傳到 Drive 的檔名（不含路徑）')
    args = ap.parse_args()

    if not os.path.exists(args.file):
        return fail('找不到相片檔案: ' + args.file)

    ext = os.path.splitext(args.file)[1].lower()
    mime = MIME_BY_EXT.get(ext, 'application/octet-stream')

    try:
        svc = drive_service()
    except Exception as e:
        return fail('認證失敗: ' + str(e)[:200])

    # 同名檔案已存在就更新，避免重複
    try:
        safe = args.name.replace('\\', '\\\\').replace("'", "\\'")
        q = ("name = '%s' and '%s' in parents and trashed = false"
             % (safe, FOLDER_ID))
        found = svc.files().list(q=q, fields='files(id,name)', pageSize=1).execute().get('files', [])
    except Exception as e:
        return fail('查詢現有檔案失敗: ' + str(e)[:200])

    media = MediaFileUpload(args.file, mimetype=mime, resumable=False)
    try:
        if found:
            file_id = found[0]['id']
            svc.files().update(fileId=file_id, media_body=media).execute()
            action = 'updated'
        else:
            meta = {'name': args.name, 'parents': [FOLDER_ID]}
            created = svc.files().create(body=meta, media_body=media,
                                         fields='id,name').execute()
            file_id = created['id']
            action = 'created'
    except Exception as e:
        return fail('上傳失敗: ' + str(e)[:200])

    print(json.dumps({'ok': True, 'id': file_id, 'name': args.name, 'action': action},
                     ensure_ascii=False))


if __name__ == '__main__':
    main()
