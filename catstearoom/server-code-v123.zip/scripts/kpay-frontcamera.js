#!/usr/bin/env node
/**
 * KPay 前鏡頭掃碼參數測試
 *
 * 背景：paymentType 3（反掃）預設用卡機**後鏡頭**掃客人的付款碼。
 *   離場機係自助 Kiosk，客人企喺卡機前面，所以要用**前鏡頭**。
 *   指引 §2 提到反掃/Kiosk 相關參數有 frontCamera / qrCodeContent / memberCode，
 *   但專案內冇參數格式說明，要靠實測。
 *
 * 本 script 依序試幾種常見格式，每種停留讓人眼確認「用邊個鏡頭」：
 *   前鏡頭 → 螢幕會見到你自己／身後；後鏡頭 → 見到卡機後面嘅嘢。
 *
 * 安全：只覆寫本 process 嘅 KPAY_MODE，唔經 /api/kpay route、唔寫 DB。
 *      每項測完即刻 close。
 *
 * 用法：
 *   node scripts/kpay-frontcamera.js                      # 用預設變體清單
 *   node scripts/kpay-frontcamera.js --type 7             # 改測 type 7
 *   node scripts/kpay-frontcamera.js --hold 20            # 每項停留 20 秒
 *   node scripts/kpay-frontcamera.js --extra frontCamera=true   # 只試一個值
 */

const path = require('path');
const net = require('net');

const ROOT = path.resolve(__dirname, '..');
require('dotenv').config({ path: path.join(ROOT, '.env'), quiet: true });
process.env.KPAY_MODE = 'lan'; // 只覆寫本 process

const kpayService = require(path.join(ROOT, 'server', 'services', 'kpayService'));

const argv = process.argv.slice(2);
const getOpt = (name, fallback) => {
  const i = argv.indexOf('--' + name);
  return i !== -1 && argv[i + 1] ? argv[i + 1] : fallback;
};

const STORE_ID = 'default_store';
const PAYMENT_TYPE = parseInt(getOpt('type', '3'), 10);
const HOLD_MS = parseInt(getOpt('hold', '12'), 10) * 1000;
const AMOUNT = parseFloat(getOpt('amount', '1'));
const EXTRA_RAW = getOpt('extra', null);

// 要試嘅 frontCamera 格式變體（KPay 文件未提供格式，逐個試）
const VARIANTS = EXTRA_RAW
  ? [{ label: EXTRA_RAW, params: parseExtra(EXTRA_RAW) }]
  : [
      { label: 'frontCamera: true', params: { frontCamera: true } },
      { label: 'frontCamera: 1', params: { frontCamera: 1 } },
      { label: 'frontCamera: "1"', params: { frontCamera: '1' } },
      { label: 'frontCamera: "Y"', params: { frontCamera: 'Y' } }
    ];

const SETTLE_MS = 8000;
const MAX_RETRY = 4;
const RETRY_BASE_MS = 4000;
const TRANSIENT_CODES = [50002, 50004];
const CODE_NOTE = {
  10000: '接受',
  11000: '已轉前台收款',
  20009: '支付類型不支持',
  50002: '終端忙（暫時）',
  50006: '末筆交易未完成（卡機有殘留單）'
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ts = () => new Date().toISOString().slice(11, 19);

// 解析 "frontCamera=true" 呢類字串；自動判斷型別
function parseExtra(str) {
  const out = {};
  for (const pair of str.split(',')) {
    const [k, v] = pair.split('=');
    if (!k) continue;
    let val = v;
    if (v === 'true') val = true;
    else if (v === 'false') val = false;
    else if (v !== undefined && v !== '' && !Number.isNaN(Number(v))) val = Number(v);
    out[k.trim()] = val;
  }
  return out;
}

function checkTcp(ip, port, timeoutMs = 5000) {
  return new Promise((resolve) => {
    const sock = new net.Socket();
    let done = false;
    const fin = (ok, reason) => {
      if (done) return;
      done = true;
      sock.destroy();
      resolve({ ok, reason });
    };
    sock.setTimeout(timeoutMs);
    sock.once('connect', () => fin(true));
    sock.once('timeout', () => fin(false, '逾時'));
    sock.once('error', (e) => fin(false, e.code || e.message));
    sock.connect(port, ip);
  });
}

async function main() {
  const cfg = await kpayService.getConfig(STORE_ID);

  console.log('═'.repeat(66));
  console.log('  KPay 前鏡頭掃碼參數測試');
  console.log(`  卡機：http://${cfg.kpos_ip}:${cfg.kpos_port}`);
  console.log(`  paymentType=${PAYMENT_TYPE}   金額=$${AMOUNT}   每項停留=${HOLD_MS / 1000}s`);
  console.log('═'.repeat(66));

  const tcp = await checkTcp(cfg.kpos_ip, cfg.kpos_port);
  if (!tcp.ok) {
    console.error(`✗ 連唔到 KPOS（${tcp.reason}）`);
    process.exit(1);
  }
  console.log(`[${ts()}] ✓ TCP 通`);
  await kpayService.sign(STORE_ID);
  console.log(`[${ts()}] ✓ 簽到完成`);
  console.log('');
  console.log('請留意卡機螢幕：邊個變體會顯示「前鏡頭」畫面（見到你自己／身後）？');
  console.log('');

  for (let i = 0; i < VARIANTS.length; i += 1) {
    const v = VARIANTS[i];
    const outTradeNo = 'KPTFC' + Date.now() + 'V' + i;
    console.log('─'.repeat(66));
    console.log(`[${ts()}] 變體 ${i + 1}/${VARIANTS.length}：${v.label}`);

    let code = null;
    let message = '';
    let attempt = 0;
    let keyRefreshed = false;

    // 注意：kpayService.sales() 唔收 extra 參數，所以呢度自己砌 payload 發 request，
    // 但簽名邏輯完全沿用 kpayService（同正式流程一致）
    while (true) {
      attempt += 1;
      const payload = {
        outTradeNo,
        description: `KPay 鏡頭測試 ${v.label}（非真實營運）`,
        payAmount: kpayService.formatAmount(AMOUNT),
        tipsAmount: kpayService.formatAmount(0),
        paymentType: PAYMENT_TYPE,
        payCurrency: '344',
        ...v.params
      };

      const reqPath = '/v2/pos/sales';
      const bodyStr = JSON.stringify(payload);
      const timestamp = Date.now();
      const nonceStr = kpayService.genNonce();
      const content = kpayService.buildSignatureContent('POST', reqPath, timestamp, nonceStr, bodyStr);
      const keys = await kpayService.sign(STORE_ID);
      const signature = kpayService.signContent(content, keys.appPrivateKey);

      try {
        const res = await fetch(`http://${cfg.kpos_ip}:${cfg.kpos_port}${reqPath}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            appId: cfg.app_id,
            timestamp: String(timestamp),
            nonceStr,
            signature
          },
          body: bodyStr,
          signal: AbortSignal.timeout(30000)
        });
        const json = await res.json();
        code = json.code;
        message = json.message || '';
        console.log(`  回應：code=${code} ${message}${CODE_NOTE[code] ? '  → ' + CODE_NOTE[code] : ''}`);
      } catch (e) {
        console.log(`  ✗ 請求失敗：${e.message}`);
        code = 'ERR';
        break;
      }

      // 40001/40004 都當作工作密鑰問題：清 cache 重簽一次再試
      // （指引只提 40004，但實測 40001 亦會出現，成因相同）
      if ((code === 40001 || code === 40004) && !keyRefreshed) {
        keyRefreshed = true;
        console.log('  （簽名／密鑰問題，清 cache 重簽後重試一次）');
        kpayService.clearKeys(STORE_ID);
        continue;
      }

      if (!TRANSIENT_CODES.includes(code)) break;
      if (attempt > MAX_RETRY) {
        console.log(`  ⚠️ 重試 ${MAX_RETRY} 次仍然係 ${code}，跳過`);
        break;
      }
      const wait = RETRY_BASE_MS * attempt;
      console.log(`  （暫時錯誤，等 ${wait / 1000} 秒重試 ${attempt}/${MAX_RETRY}）`);
      await sleep(wait);
    }

    const accepted = code === 10000 || code === 11000;

    if (accepted) {
      console.log('');
      console.log(`  ★★★ 請睇卡機螢幕（${HOLD_MS / 1000} 秒）★★★`);
      console.log(`      變體：${v.label}`);
      console.log('      問：係前鏡頭（見到你自己）定後鏡頭（見到卡機後面）？');
      await sleep(HOLD_MS);
    }

    // 無論如何都嘗試關閉，唔好留低殘留單
    try {
      const q = await kpayService.query(outTradeNo, STORE_ID);
      const d = (q && q.data) || {};
      console.log(`  query: payResult=${d.payResult}${d.reason ? '  reason=' + d.reason : ''}`);
    } catch (e) {
      console.log(`  query 失敗: ${e.message}`);
    }
    try {
      const c = await kpayService.close(outTradeNo, STORE_ID);
      console.log(`  close: code=${c && c.code} ${(c && c.message) || ''}`);
    } catch (e) {
      console.log(`  close 失敗: ${e.message} —— ⚠️ 卡機可能有殘留單`);
    }
    console.log(`  等 ${SETTLE_MS / 1000} 秒…`);
    await sleep(SETTLE_MS);
  }

  console.log('');
  console.log('═'.repeat(66));
  console.log('  測試完結。請報告：邊幾個變體用咗前鏡頭？');
  console.log('  若全部都用後鏡頭，代表參數名或格式唔啱 —— 要問 KPay 攞正確規格。');
  console.log('═'.repeat(66));
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error('');
    console.error('✗ 測試失敗：', e.message);
    process.exit(1);
  });
