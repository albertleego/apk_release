#!/usr/bin/env node
/**
 * KPay 付款類型支援矩陣測試
 *
 * 目的：一次過查出真卡機支援邊幾種 paymentType，補完支援矩陣。
 *   唔需要真正付款 —— 唔支援嘅類型會即刻回錯誤（例：20009 支付類型不支持）；
 *   支援嘅類型會喺卡機彈收款畫面，本 script 會即刻 close 取消，唔會產生交易。
 *
 * 安全設計：
 *   - 只覆寫本 process 嘅 KPAY_MODE，唔影響運行中 server
 *   - 唔經 /api/kpay route、唔寫 DB、唔 emit socket event
 *   - 每項測完即刻 close，並等 KPOS 回復空閒先測下一項
 *   - 卡機側嘅 outTradeNo 全部帶 KPTMX 前綴，易辨認
 *
 * 用法：
 *   node scripts/kpay-matrix.js                    # 測齊 1/2/6/8
 *   node scripts/kpay-matrix.js --types 6,8        # 只測指定類型
 *   node scripts/kpay-matrix.js --amount 1         # 金額（預設 $1）
 */

const path = require('path');
const net = require('net');

const ROOT = path.resolve(__dirname, '..');
require('dotenv').config({ path: path.join(ROOT, '.env'), quiet: true });
process.env.KPAY_MODE = 'lan'; // 只覆寫本 process

const kpayService = require(path.join(ROOT, 'server', 'services', 'kpayService'));

const argv = process.argv.slice(2);
const getOpt = (name, fallback) => {
  const i = argv.indexOf('--' + name);
  return i !== -1 && argv[i + 1] ? argv[i + 1] : fallback;
};

const STORE_ID = 'default_store';
const AMOUNT = parseFloat(getOpt('amount', '1'));
const TYPES = getOpt('types', '1,2,6,8')
  .split(',')
  .map((s) => parseInt(s.trim(), 10))
  .filter((n) => !Number.isNaN(n));

// 前端按鈕 → paymentType 嘅對照（來自 server/routes/kpayRoutes.js PAYMENT_TYPE_MAP）
const TYPE_LABEL = {
  1: '卡類（Visa/Master，拍卡）',
  2: '二維碼正掃（微信／支付寶）',
  6: 'PayMe 正掃',
  8: '轉數快 FPS 正掃'
};

// 卡機 code → 白話
const CODE_NOTE = {
  10000: '接受',
  11000: '已轉前台收款（正常等待付款）',
  20009: '支付類型不支持',
  50002: '終端忙（暫時，可重試）',
  50004: '請求過於頻繁（暫時，可重試）',
  40004: '工作密鑰失效'
};

// ⚠️ 50002/50004 係「暫時」錯誤，唔代表唔支援 —— 必須重試，唔可以當結論
const TRANSIENT_CODES = [50002, 50004];

const SETTLE_MS = 8000;  // close 之後等卡機回復空閒（太短會撞到限流）
const MAX_RETRY = 4;     // 暫時錯誤嘅最大重試次數
const RETRY_BASE_MS = 4000; // 退避基數：4s, 8s, 12s…
// --hold N：收款畫面上彈之後留住 N 秒先 close，方便人眼確認「呢個 type 彈咩畫面」
const HOLD_MS = parseInt(getOpt('hold', '0'), 10) * 1000;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function ts() {
  return new Date().toISOString().slice(11, 19);
}

// 預先確認 TCP 通，免得逐項等逾時
function checkTcp(ip, port, timeoutMs = 5000) {
  return new Promise((resolve) => {
    const sock = new net.Socket();
    let done = false;
    const fin = (ok, reason) => {
      if (done) return;
      done = true;
      sock.destroy();
      resolve({ ok, reason });
    };
    sock.setTimeout(timeoutMs);
    sock.once('connect', () => fin(true));
    sock.once('timeout', () => fin(false, '逾時'));
    sock.once('error', (e) => fin(false, e.code || e.message));
    sock.connect(port, ip);
  });
}

async function main() {
  const cfg = await kpayService.getConfig(STORE_ID);

  console.log('═'.repeat(66));
  console.log('  KPay 付款類型支援矩陣測試');
  console.log(`  卡機：http://${cfg.kpos_ip}:${cfg.kpos_port}   金額：$${AMOUNT}`);
  console.log('═'.repeat(66));

  const tcp = await checkTcp(cfg.kpos_ip, cfg.kpos_port);
  if (!tcp.ok) {
    console.error(`✗ 連唔到 KPOS（${tcp.reason}）`);
    process.exit(1);
  }
  console.log(`[${ts()}] ✓ TCP 通`);

  console.log(`[${ts()}] 簽到…`);
  await kpayService.sign(STORE_ID);
  console.log(`[${ts()}] ✓ 簽到完成`);
  console.log('');

  const results = [];

  for (const type of TYPES) {
    const label = TYPE_LABEL[type] || `type ${type}`;
    const outTradeNo = 'KPTMX' + Date.now() + 'T' + type;
    console.log('─'.repeat(66));
    console.log(`[${ts()}] 測試 paymentType=${type}  ${label}`);
    console.log(`          outTradeNo=${outTradeNo}`);

    let code = null;
    let message = '';
    let attempt = 0;

    // 撞到 50002/50004 就退避重試 —— 呢啲係暫時錯誤，重試完先知道真正結果
    while (true) {
      attempt += 1;
      try {
        const r = await kpayService.sales({
          outTradeNo,
          amount: AMOUNT,
          paymentType: type,
          description: `KPay 類型測試 type=${type}（非真實營運）`,
          storeId: STORE_ID
        });
        code = r && r.code;
        message = (r && r.message) || '';
        const note = CODE_NOTE[code] || '';
        console.log(`  回應：code=${code} ${message}${note ? '  → ' + note : ''}`);
      } catch (e) {
        console.log(`  ✗ 請求失敗：${e.message}`);
        code = 'ERR';
        message = e.message;
        break;
      }

      if (!TRANSIENT_CODES.includes(code)) break;

      if (attempt > MAX_RETRY) {
        console.log(`  ⚠️ 重試 ${MAX_RETRY} 次仍然係 ${code} —— 未能判定，需人手覆核`);
        break;
      }
      const wait = RETRY_BASE_MS * attempt;
      console.log(`  （暫時錯誤，等 ${wait / 1000} 秒後重試 ${attempt}/${MAX_RETRY}）`);
      await sleep(wait);
    }

    if (code === 'ERR') {
      results.push({ type, label, code, message, verdict: 'error' });
      continue;
    }

    const accepted = code === 10000 || code === 11000;
    const unsupported = code === 20009;
    // 重試完仲係暫時錯誤 → 未知，唔可以當「唔支援」
    const verdict = accepted ? 'ok' : unsupported ? 'unsupported'
      : TRANSIENT_CODES.includes(code) ? 'unknown' : 'other';
    results.push({ type, label, code, message, verdict });

    if (accepted && HOLD_MS > 0) {
      console.log('');
      console.log(`  ★ 卡機應該已彈出收款畫面 —— 請睇下係咩畫面，${HOLD_MS / 1000} 秒後自動取消`);
      console.log(`     （paymentType = ${type}）`);
      await sleep(HOLD_MS);
    }

    if (accepted) {
      // 類型被接受 → 卡機應該彈咗收款畫面，即刻取消，唔好留低
      console.log('  → 類型被接受。即刻 query + close 取消…');
      try {
        const q = await kpayService.query(outTradeNo, STORE_ID);
        const d = (q && q.data) || {};
        console.log(`     query: payResult=${d.payResult}${d.reason ? '  reason=' + d.reason : ''}`);
      } catch (e) {
        console.log(`     query 失敗: ${e.message}`);
      }
      try {
        const c = await kpayService.close(outTradeNo, STORE_ID);
        console.log(`     close: code=${c && c.code} ${(c && c.message) || ''}`);
      } catch (e) {
        console.log(`     close 失敗: ${e.message} —— ⚠️ 卡機可能有未取消嘅單，請手動檢查`);
      }
      console.log(`     等 ${SETTLE_MS / 1000} 秒讓卡機回復空閒…`);
      await sleep(SETTLE_MS);
    }
  }

  // ===== 總結 =====
  console.log('');
  console.log('═'.repeat(66));
  console.log('  支援矩陣總結');
  console.log('─'.repeat(66));
  const VERDICT_LABEL = {
    ok: '✓ 支援',
    unsupported: '✗ 不支援',
    unknown: '? 未判定',
    error: '✗ 錯誤',
    other: '? 待確認'
  };

  for (const r of results) {
    const mark = VERDICT_LABEL[r.verdict] || '? 待確認';
    console.log(`  type ${String(r.type).padEnd(2)}  ${mark.padEnd(9)} code=${String(r.code).padEnd(6)} ${r.label}`);
    if (r.message) console.log(`           ${r.message}`);
  }
  console.log('═'.repeat(66));

  const unsupported = results.filter((r) => r.verdict === 'unsupported');
  const unknown = results.filter((r) => r.verdict === 'unknown' || r.verdict === 'other');

  if (unsupported.length) {
    console.log('');
    console.log(`⚠️  明確唔支援（20009）：${unsupported.map((r) => 'type ' + r.type).join('、')}`);
    console.log('    若正式機型一樣，離場機 UI 對應按鈕要停用或改設計。');
  }
  if (unknown.length) {
    console.log('');
    console.log(`❓ 未能判定：${unknown.map((r) => 'type ' + r.type).join('、')}`);
    console.log('    卡機一直回暫時錯誤（忙／太頻繁），代表結果無效 —— 請隔一陣再單獨重測。');
    console.log('    單獨重測：node scripts/kpay-matrix.js --types ' + unknown.map((r) => r.type).join(','));
  }
  if (unsupported.length || unknown.length) {
    console.log('    建議拎住結果問 KPay：正式機型支援邊幾種 paymentType？');
  }
  console.log('');
  console.log('備註：測試單只存在於卡機側，本 script 冇寫入任何紀錄。');
  console.log('      若卡機仍有殘留收款畫面，請手動取消或用 admin 密碼 void。');
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error('');
    console.error('✗ 測試失敗：', e.message);
    process.exit(1);
  });
