#!/usr/bin/env python3
"""
在本機重新授權 Google Drive，取得可用的 drive_token.json。

═══════════════════════════════════════════════════════════════════
為什麼需要重跑這支：
  原本的 token 只有 `drive.file` 範圍 —— 意思是「只能存取這個 app
  建立、或你經 Google 挑選器授權的檔案」。即使資料夾是你自己的，
  app 一樣看不到它（所有權不影響，這是 Google 對 drive.file 的定義）。
  2026-09-30 實測：用該 token 讀「己領養」資料夾回 404。

  上傳已領養貓貓相片需要完整 `drive` 範圍，所以要重新授權一次。

為什麼不用 service account：
  服務帳戶本身沒有儲存配額，上傳會回 403「Service Accounts do not
  have storage quota」——即使有資料夾的編輯權也一樣。

用法（在 Windows 的 repo 根目錄）：
    pip install google-auth-oauthlib        # 只需一次
    python scripts/local-drive-auth.py

  它會開瀏覽器要你登入並同意（請用 albertleetmail@gmail.com，
  即「己領養」資料夾的持有人），成功後會更新
      scripts/drive_token.json

  然後把該檔上傳到阿里雲：
      scp scripts/drive_token.json autocafe-prod:/home/autocafe/catstearoom/scripts/

  ⚠️ drive_token.json 是機密檔（可存取你的 Drive），不要 commit。
═══════════════════════════════════════════════════════════════════
"""

import json
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
TOKEN_PATH = os.path.join(_HERE, 'drive_token.json')

SCOPES = ['https://www.googleapis.com/auth/drive']


def main():
    if not os.path.exists(TOKEN_PATH):
        print('找不到 %s' % TOKEN_PATH)
        print('請先把它放在 scripts/ 內（內含 client_id / client_secret）')
        return 1

    with open(TOKEN_PATH) as f:
        old = json.load(f)

    client_id = old.get('client_id')
    client_secret = old.get('client_secret')
    if not client_id or not client_secret:
        print('drive_token.json 內沒有 client_id / client_secret，無法重新授權')
        return 1

    try:
        from google_auth_oauthlib.flow import InstalledAppFlow
    except ImportError:
        print('缺少套件，請先執行：pip install google-auth-oauthlib')
        return 1

    client_config = {
        'installed': {
            'client_id': client_id,
            'client_secret': client_secret,
            'auth_uri': 'https://accounts.google.com/o/oauth2/auth',
            'token_uri': old.get('token_uri', 'https://oauth2.googleapis.com/token'),
            'redirect_uris': ['http://localhost'],
        }
    }

    print('即將開瀏覽器，請用 albertleetmail@gmail.com 登入並按「允許」')
    print('（範圍：完整 Google Drive 存取）\n')
    flow = InstalledAppFlow.from_client_config(client_config, SCOPES)
    creds = flow.run_local_server(port=0, prompt='consent')

    # 保留原本的欄位結構，只換 refresh_token 與 scopes
    out = dict(old)
    out['refresh_token'] = creds.refresh_token
    out['token'] = creds.token
    out['scopes'] = SCOPES
    out['token_uri'] = old.get('token_uri', 'https://oauth2.googleapis.com/token')

    with open(TOKEN_PATH, 'w') as f:
        json.dump(out, f, indent=1)

    print('\n已更新：%s' % TOKEN_PATH)
    print('授權範圍：%s' % SCOPES[0])
    print('\n下一步（把新 token 上傳到阿里雲）：')
    print('  scp scripts/drive_token.json autocafe-prod:/home/autocafe/catstearoom/scripts/')
    return 0


if __name__ == '__main__':
    sys.exit(main())
