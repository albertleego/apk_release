/**
 * merchantChatRoutes.js — 商家 AI chatroom API
 *
 * 掛載點：/api/merchant（只有 runtime.merchantChat() 開啟時，見 server/index.js）
 * 2026-09-14 前係 /api/merchant-chat，隨頁面一併改名為 /api/merchant。
 *
 * 權限模型：
 *   - 商家路線   → merchantAuth.requireMerchant（讀 httpOnly cookie `merchant_token`）
 *   - 主商家路線 → 加上 requireOwner（帳號名喺 runtime.merchantChatOwnerUsernames()）
 *                 包括開關其他商家、代設 API key、檢視所有商家對話
 *
 * ⚠️ 隔離鐵律：每一條商家查詢都必須同時比對 `id` 同 `merchant_employee_id`。
 *    只比對 id 的話，商家改一改 URL 就讀到其他商家嘅對話。
 *
 * ⚠️ SSE：呢個係全專案第一個串流端點。串流開始之後**永遠唔可以** next(err)，
 *    因為 server/index.js 嘅全域錯誤處理會行 res.status(500).json()，
 *    喺標頭已送出嘅情況下會拋 ERR_HTTP_HEADERS_SENT。所有錯誤自己包、自己 end。
 */
const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { db } = require('../../database/db');
const merchantAuth = require('../middleware/merchantAuth');
const aiChat = require('../services/aiChatService');
const peers = require('../services/merchantChatPeers');
const runtime = require('../config/runtime');

const requireMerchant = merchantAuth.requireMerchant;

// ── 可調限制（全部經 .env，預設合理值）──
const MAX_CHARS = parseInt(process.env.AI_CHAT_MAX_CHARS || '8000', 10);            // 單條訊息字數
const MAX_MESSAGES = parseInt(process.env.AI_CHAT_MAX_MESSAGES || '200', 10);        // 每個對話保留訊息數
const MAX_CONVERSATIONS = parseInt(process.env.AI_CHAT_MAX_CONVERSATIONS || '50', 10); // 每商家對話數
const RATE_PER_MIN = parseInt(process.env.AI_CHAT_RATE_PER_MIN || '10', 10);         // 每分鐘請求數
const HISTORY_LIMIT = parseInt(process.env.AI_CHAT_HISTORY_LIMIT || '20', 10);       // 送去模型嘅歷史訊息數
const TITLE_MAX = 60;

// ── sqlite3 callback → Promise ──
function dbRun(sql, params) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function (err) {
            if (err) return reject(err);
            resolve({ changes: this.changes });
        });
    });
}
function dbGet(sql, params) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => (err ? reject(err) : resolve(row)));
    });
}
function dbAll(sql, params) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => (err ? reject(err) : resolve(rows || [])));
    });
}

// ── 每商家限流（純記憶體，唔加 npm 依賴；重啟即清空，對用途嚟講足夠）──
const rateBuckets = new Map(); // employee_id -> [timestamp, ...]

function checkRate(employeeId) {
    const now = Date.now();
    const windowStart = now - 60 * 1000;
    const hits = (rateBuckets.get(employeeId) || []).filter((t) => t > windowStart);
    if (hits.length >= RATE_PER_MIN) {
        rateBuckets.set(employeeId, hits);
        return false;
    }
    hits.push(now);
    rateBuckets.set(employeeId, hits);
    // 防止 Map 無限增長（每個商家最多留 RATE_PER_MIN 個 timestamp）
    if (rateBuckets.size > 1000) {
        for (const [k, v] of rateBuckets) {
            if (!v.some((t) => t > windowStart)) rateBuckets.delete(k);
        }
    }
    return true;
}

// ── SSE 工具 ──
function sseWrite(res, event, data) {
    if (res.writableEnded) return;
    try {
        res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    } catch (e) {
        // 客戶端已斷線：寫入失敗係預期之內，唔記 log（避免重複刷爆日誌）
    }
}

function openSse(res) {
    res.status(200).set({
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        'Connection': 'keep-alive',
        // nginx 預設會緩衝回應，冇呢個 header 逐字效果會消失
        'X-Accel-Buffering': 'no'
    });
    if (typeof res.flushHeaders === 'function') res.flushHeaders();
}

function trimTitle(text) {
    const t = String(text || '').replace(/\s+/g, ' ').trim();
    if (!t) return '新對話';
    return t.length > TITLE_MAX ? `${t.slice(0, TITLE_MAX)}…` : t;
}

// ── 「主 merchant」與 chatroom 開關 ──
// 開關預設關閉：chat_settings 冇 row = 未開啟，要主 merchant 逐個開。
function isOwner(merchant) {
    const owners = runtime.merchantChatOwnerUsernames();
    if (!owners.length) return false;
    return owners.includes(String(merchant && merchant.username || '').toLowerCase());
}

/** 主 merchant 自己永遠可用（否則無法 bootstrap，要開自己都要人開） */
async function isChatEnabled(merchant) {
    if (isOwner(merchant)) return true;
    const row = await dbGet(
        'SELECT enabled FROM chat_settings WHERE merchant_employee_id = ?',
        [merchant.employee_id]
    );
    return !!(row && row.enabled);
}

/** 未開啟就用 403 + 中文提示（前端據此顯示「尚未開啟」頁） */
async function requireChatEnabled(req, res, next) {
    try {
        if (await isChatEnabled(req.merchant)) return next();
        return res.status(403).json({ success: false, error: '此功能尚未開通，請聯絡管理員。' });
    } catch (e) {
        console.error('[merchant-chat] 檢查開關失敗:', e.message);
        return res.status(500).json({ success: false, error: '檢查功能狀態失敗' });
    }
}

function requireOwner(req, res, next) {
    if (!isOwner(req.merchant)) {
        return res.status(403).json({ success: false, error: '需要主商家權限' });
    }
    next();
}

// ════════════════════════════════════════════════════════════
// 跨實例：peer 認證 + 共用核心邏輯
//
// 「總控」實例嘅主商家面板要管到其他實例嘅商家，靠 MERCHANT_CHAT_PEER_KEY 認證。
// owner 路線（本地）同 peer 路線（外來）行同一套核心函式，避免兩邊行為唔一致。
// ════════════════════════════════════════════════════════════
const PEER_HEADER = 'x-merchant-chat-peer-key';

/** 固定時間比對，避免用回應時間猜密鑰 */
function safeEqual(a, b) {
    const ba = Buffer.from(String(a));
    const bb = Buffer.from(String(b));
    if (ba.length !== bb.length) return false;
    return crypto.timingSafeEqual(ba, bb);
}

function requirePeerKey(req, res, next) {
    const expected = runtime.merchantChatPeerKey();
    if (!expected) {
        // 未啟用就當冇呢個端點（唔好透露存在）
        return res.status(404).json({ success: false, error: '找不到資源' });
    }
    const got = req.headers[PEER_HEADER];
    if (!got || !safeEqual(got, expected)) {
        console.warn('[merchant-chat] peer 認證失敗，來源 IP:', req.ip);
        return res.status(401).json({ success: false, error: 'peer 認證失敗' });
    }
    next();
}

/** 本實例嘅標籤（畀「總控」分辨資料來自邊個實例） */
function localInstanceLabel() {
    return process.env.MERCHANT_CHAT_INSTANCE_LABEL
        || (process.env.PORT ? `local:${process.env.PORT}` : 'local');
}

/** 列出本實例所有 merchant 帳號（單一真實來源，owner 同 peer 都用） */
async function coreListMerchants() {
    const rows = await dbAll(
        `SELECT e.id, e.username, e.full_name, e.is_active,
                COALESCE(s.enabled, 0) AS enabled,
                s.api_key,
                s.updated_at AS enabled_updated_at
           FROM employees e
           LEFT JOIN chat_settings s ON s.merchant_employee_id = e.id
          WHERE e.role = 'merchant'
          ORDER BY e.username ASC`,
        []
    );
    await refreshApiKeyFromDb();
    const platformSource = aiChat.keySource(); // 'database' | 'env' | 'none'
    const owners = runtime.merchantChatOwnerUsernames();

    return rows.map((r) => {
        const isOwnerRow = owners.includes(String(r.username || '').toLowerCase());
        let keySource = 'none';
        if (r.api_key) keySource = 'merchant';
        else if (platformSource === 'database') keySource = 'platform';
        else if (platformSource === 'env') keySource = 'env';

        return {
            id: r.id,
            username: r.username,
            fullName: r.full_name,
            isActive: r.is_active === 1,
            isOwner: isOwnerRow,
            // 主商家永遠開啟：DB 可能冇 row，但實際生效狀態係開
            enabled: isOwnerRow ? true : r.enabled === 1,
            keyMasked: aiChat.maskKey(r.api_key), // 只露尾 4 碼
            keySource,
            updatedAt: r.enabled_updated_at
        };
    });
}

/** 開關某個商家。@returns {{ok:boolean, error?:string, merchant?:object}} */
async function coreSetEnabled(id, enabled, actorId) {
    const target = await dbGet(
        "SELECT id, username FROM employees WHERE id = ? AND role = 'merchant'",
        [id]
    );
    if (!target) return { ok: false, error: '找不到此商家帳號' };

    if (runtime.merchantChatOwnerUsernames().includes(String(target.username || '').toLowerCase())) {
        return { ok: false, error: '主商家帳號永遠開啟，無法關閉' };
    }

    await dbRun(
        `INSERT INTO chat_settings (merchant_employee_id, enabled, updated_by, updated_at)
         VALUES (?, ?, ?, CURRENT_TIMESTAMP)
         ON CONFLICT(merchant_employee_id) DO UPDATE SET
            enabled = excluded.enabled,
            updated_by = excluded.updated_by,
            updated_at = CURRENT_TIMESTAMP`,
        [target.id, enabled ? 1 : 0, actorId]
    );
    return { ok: true, merchant: { id: target.id, username: target.username, enabled } };
}

/**
 * 設定／清除某個商家嘅專用金鑰。
 * @param {string|null} rawKey 空字串 = 清除、null = 參數錯誤、非空 = 設定（會先驗證）
 * @param {Function} rateCheck 限流檢查（驗證會打真實 API）
 */
async function coreSetApiKey(id, rawKey, actorId, rateCheck) {
    if (rawKey !== null && rawKey.length > 400) {
        return { ok: false, status: 400, error: '金鑰長度不合理' };
    }
    const target = await dbGet(
        "SELECT id, username FROM employees WHERE id = ? AND role = 'merchant'",
        [id]
    );
    if (!target) return { ok: false, status: 404, error: '找不到此商家帳號' };

    if (!rawKey) {
        await dbRun(
            `INSERT INTO chat_settings (merchant_employee_id, api_key, updated_by, updated_at)
             VALUES (?, NULL, ?, CURRENT_TIMESTAMP)
             ON CONFLICT(merchant_employee_id) DO UPDATE SET
                api_key = NULL,
                updated_by = excluded.updated_by,
                updated_at = CURRENT_TIMESTAMP`,
            [target.id, actorId]
        );
        await refreshApiKeyFromDb();
        return {
            ok: true,
            username: target.username,
            keyMasked: null,
            keySource: aiChat.keySource() === 'none' ? 'none' : 'platform'
        };
    }

    if (!rateCheck()) return { ok: false, status: 429, error: '操作過於頻繁，請稍後再試。' };

    const check = await aiChat.validateKey(rawKey);
    if (!check.ok) {
        // ⚠️ 只 log 失敗事實，唔可以 log 個 key
        console.warn(`[merchant-chat] 為 ${target.username} 設定嘅金鑰驗證失敗`);
        return { ok: false, status: 400, error: check.error || '金鑰驗證失敗' };
    }

    await dbRun(
        `INSERT INTO chat_settings (merchant_employee_id, api_key, updated_by, updated_at)
         VALUES (?, ?, ?, CURRENT_TIMESTAMP)
         ON CONFLICT(merchant_employee_id) DO UPDATE SET
            api_key = excluded.api_key,
            updated_by = excluded.updated_by,
            updated_at = CURRENT_TIMESTAMP`,
        [target.id, rawKey, actorId]
    );
    return { ok: true, username: target.username, keyMasked: aiChat.maskKey(rawKey), keySource: 'merchant' };
}

/**
 * 主商家代其他商家改帳號／密碼（**唔需要對方當前密碼** —— 呢個係主商家權限）。
 * 商家改自己嘅仍然行 /api/auth/merchant-account（要當前密碼）。
 *
 * @param {Object} patch { username?, newPassword? }
 * @returns {{ok:boolean, status?:number, error?:string, changed?:boolean,
 *            username?:string, passwordChanged?:boolean}}
 */
async function coreSetAccount(id, patch, actorId) {
    const target = await dbGet(
        "SELECT id, username, full_name FROM employees WHERE id = ? AND role = 'merchant'",
        [id]
    );
    if (!target) return { ok: false, status: 404, error: '找不到此商家帳號' };

    const updates = [];
    const params = [];
    const newPassword = typeof patch.newPassword === 'string' ? patch.newPassword : '';
    const newFullName = typeof patch.fullName === 'string' ? patch.fullName.trim() : '';

    // 商家帳號（登入身份）**建立之後完全不可更改** —— 連主商家都唔可以。
    // 需要換帳號名嘅話，做法係建立一個新帳號再停用舊嘅。
    if (patch.username) {
        return { ok: false, status: 400, error: '商家帳號不可更改，如需更換請建立新帳號' };
    }

    if (newFullName && newFullName !== target.full_name) {
        if (newFullName.length > 50) {
            return { ok: false, status: 400, error: '顯示名稱不可超過 50 個字元' };
        }
        updates.push('full_name = ?');
        params.push(newFullName);
    }

    let passwordChanged = false;
    if (newPassword) {
        if (newPassword.length < 6) {
            return { ok: false, status: 400, error: '密碼最少 6 個字元' };
        }
        updates.push('password_hash = ?');
        params.push(await bcrypt.hash(newPassword, 10));
        passwordChanged = true;
    }

    if (!updates.length) {
        return {
            ok: true, changed: false,
            username: target.username,
            fullName: newFullName || target.full_name,
            passwordChanged: false
        };
    }


    updates.push('updated_at = ?');
    params.push(new Date().toISOString());
    params.push(id);
    await dbRun(`UPDATE employees SET ${updates.join(', ')} WHERE id = ?`, params);

    // 改密碼 → 踢走該商家所有 session（強制重新登入，同 merchant-account 行為一致）
    if (passwordChanged) {
        await dbRun('DELETE FROM sessions WHERE employee_id = ?', [id]);
    }

    console.log(`[merchant-chat] 主商家 ${actorId} 更新咗 ${target.username} 嘅帳號設定`
        + (updates.some((u) => u.startsWith('full_name')) ? '（含顯示名稱）' : '')
        + (passwordChanged ? '（含密碼）' : ''));
    return {
        ok: true, changed: true,
        username: target.username, // 帳號名不可改，一律回原值
        fullName: newFullName || target.full_name,
        passwordChanged
    };
}

/** 列出對話（merchantId 可空 = 全部） */
async function coreListConversations(merchantId) {
    const rows = await dbAll(
        `SELECT c.id, c.title, c.created_at, c.updated_at,
                e.username, e.full_name,
                (SELECT COUNT(*) FROM chat_messages m WHERE m.conversation_id = c.id) AS message_count
           FROM chat_conversations c
           LEFT JOIN employees e ON e.id = c.merchant_employee_id
          ${merchantId ? 'WHERE c.merchant_employee_id = ?' : ''}
          ORDER BY c.updated_at DESC
          LIMIT 500`,
        merchantId ? [merchantId] : []
    );
    return rows.map((r) => ({
        id: r.id,
        title: r.title,
        merchantUsername: r.username,
        merchantName: r.full_name,
        messageCount: r.message_count,
        createdAt: r.created_at,
        updatedAt: r.updated_at
    }));
}

/** 讀指定對話嘅訊息 */
async function coreGetMessages(convId) {
    const conv = await dbGet(
        `SELECT c.id, c.title, c.system_prompt, e.username, e.full_name
           FROM chat_conversations c
           LEFT JOIN employees e ON e.id = c.merchant_employee_id
          WHERE c.id = ?`,
        [convId]
    );
    if (!conv) return null;

    const rows = await dbAll(
        `SELECT id, role, content, created_at FROM chat_messages
          WHERE conversation_id = ? ORDER BY created_at ASC, rowid ASC`,
        [convId]
    );
    return {
        conversation: {
            id: conv.id,
            title: conv.title,
            systemPrompt: conv.system_prompt,
            merchantUsername: conv.username,
            merchantName: conv.full_name
        },
        messages: rows.map((r) => ({ id: r.id, role: r.role, content: r.content, createdAt: r.created_at }))
    };
}

/**
 * 由 DB 讀返平台 API key 落 aiChatService（DB 優先於 .env）。
 *
 * 每次 /me 同送訊息前都跑一次：SQLite 主鍵查詢成本極低，但換來「pm2 restart
 * 之後仍然生效」同「表未建立時唔會爆」兩個好處，唔需要喺 index.js 搞啟動順序。
 */
async function refreshApiKeyFromDb() {
    try {
        const row = await dbGet("SELECT value FROM chat_platform_settings WHERE key = 'ai_api_key'", []);
        aiChat.setApiKey(row && row.value ? row.value : null);
    } catch (e) {
        // 表未建立（首次啟動／舊 DB）→ 保持現狀，回落 .env，唔應該因此令服務失敗
    }
}

/**
 * 解析某個商家實際上應該用邊條 key。優先次序：
 *   1. merchant  — 該商家專用 key（主商家喺「商家管理」逐個代設）
 *   2. platform  — 平台共用 key（主商家設定，chat_platform_settings）
 *   3. env       — .env 嘅 AI_API_KEY
 *   4. none      — 都冇，AI 功能對呢個商家停用
 *
 * @returns {Promise<{key: string, source: 'merchant'|'platform'|'env'|'none'}>}
 */
async function resolveApiKey(merchantId) {
    try {
        const row = await dbGet(
            'SELECT api_key FROM chat_settings WHERE merchant_employee_id = ?',
            [merchantId]
        );
        if (row && row.api_key) return { key: row.api_key, source: 'merchant' };
    } catch (e) {
        // 欄位未加（舊 DB）→ 當作冇逐商家 key
    }
    await refreshApiKeyFromDb();
    const platformKey = aiChat.getApiKey();
    if (platformKey) return { key: platformKey, source: aiChat.keySource() === 'database' ? 'platform' : 'env' };
    return { key: '', source: 'none' };
}

// ════════════════════════════════════════════════════════════
// 商家路線（全部要 requireMerchant）
// ════════════════════════════════════════════════════════════

/** 目前登入商家 + 目前用量 + AI 服務狀態 */
router.get('/me', requireMerchant, async (req, res) => {
    try {
        // 逐商家 key 優先 → 平台 key → .env（順便令主商家啱啱存嘅 key 即時生效）
        const resolved = await resolveApiKey(req.merchant.employee_id);
        const row = await dbGet(
            'SELECT COUNT(*) AS c FROM chat_conversations WHERE merchant_employee_id = ?',
            [req.merchant.employee_id]
        );
        const owner = isOwner(req.merchant);
        res.json({
            success: true,
            merchant: {
                id: req.merchant.employee_id,
                username: req.merchant.username,
                fullName: req.merchant.full_name
            },
            // enabled=false 時前端顯示「尚未開啟」頁；isOwner=true 時多一個商家管理版面
            enabled: owner ? true : await isChatEnabled(req.merchant),
            isOwner: owner,
            usage: { conversations: row ? row.c : 0 },
            limits: {
                maxConversations: MAX_CONVERSATIONS,
                maxMessages: MAX_MESSAGES,
                maxChars: MAX_CHARS,
                ratePerMinute: RATE_PER_MIN
            },
            // 呢個商家實際上能唔能用 AI（睇佢自己嘅 key 解析結果）
            aiReady: !!resolved.key,
            aiKeySource: resolved.source
        });
    } catch (e) {
        console.error('[merchant-chat] /me 失敗:', e.message);
        res.status(500).json({ success: false, error: '讀取帳戶資料失敗' });
    }
});

/** 對話列表（只列自己嘅） */
router.get('/conversations', requireMerchant, requireChatEnabled, async (req, res) => {
    try {
        const rows = await dbAll(
            `SELECT c.id, c.title, c.system_prompt, c.created_at, c.updated_at,
                    (SELECT COUNT(*) FROM chat_messages m WHERE m.conversation_id = c.id) AS message_count
               FROM chat_conversations c
              WHERE c.merchant_employee_id = ?
              ORDER BY c.updated_at DESC`,
            [req.merchant.employee_id]
        );
        res.json({
            success: true,
            conversations: rows.map((r) => ({
                id: r.id,
                title: r.title,
                systemPrompt: r.system_prompt,
                messageCount: r.message_count,
                createdAt: r.created_at,
                updatedAt: r.updated_at
            }))
        });
    } catch (e) {
        console.error('[merchant-chat] 讀取對話列表失敗:', e.message);
        res.status(500).json({ success: false, error: '讀取對話列表失敗' });
    }
});

/** 新增對話 */
router.post('/conversations', requireMerchant, requireChatEnabled, async (req, res) => {
    try {
        const countRow = await dbGet(
            'SELECT COUNT(*) AS c FROM chat_conversations WHERE merchant_employee_id = ?',
            [req.merchant.employee_id]
        );
        if (countRow && countRow.c >= MAX_CONVERSATIONS) {
            return res.status(400).json({
                success: false,
                error: `對話數量已達上限（${MAX_CONVERSATIONS} 個），請先刪除不需要的對話。`
            });
        }

        const rawTitle = typeof req.body?.title === 'string' ? req.body.title : '';
        const id = uuidv4();
        await dbRun(
            `INSERT INTO chat_conversations (id, merchant_employee_id, title, system_prompt)
             VALUES (?, ?, ?, NULL)`,
            [id, req.merchant.employee_id, rawTitle.trim() ? trimTitle(rawTitle) : '新對話']
        );
        res.json({ success: true, conversation: { id, title: rawTitle.trim() ? trimTitle(rawTitle) : '新對話', systemPrompt: null, messageCount: 0 } });
    } catch (e) {
        console.error('[merchant-chat] 新增對話失敗:', e.message);
        res.status(500).json({ success: false, error: '新增對話失敗' });
    }
});

/** 更新對話（標題 / 系統提示詞） */
router.patch('/conversations/:id', requireMerchant, requireChatEnabled, async (req, res) => {
    try {
        const existing = await dbGet(
            'SELECT id, system_prompt FROM chat_conversations WHERE id = ? AND merchant_employee_id = ?',
            [req.params.id, req.merchant.employee_id]
        );
        if (!existing) return res.status(404).json({ success: false, error: '找不到此對話' });

        const sets = [];
        const params = [];

        if (typeof req.body?.title === 'string') {
            sets.push('title = ?');
            params.push(trimTitle(req.body.title));
        }
        if (typeof req.body?.systemPrompt === 'string') {
            const sp = req.body.systemPrompt.trim();
            if (sp.length > MAX_CHARS) {
                return res.status(400).json({ success: false, error: `系統提示詞不可超過 ${MAX_CHARS} 個字元` });
            }
            sets.push('system_prompt = ?');
            params.push(sp || null); // 清空 = 用伺服器預設
        }

        if (!sets.length) return res.status(400).json({ success: false, error: '沒有需要更新的欄位' });

        sets.push('updated_at = CURRENT_TIMESTAMP');
        params.push(req.params.id, req.merchant.employee_id);
        await dbRun(
            `UPDATE chat_conversations SET ${sets.join(', ')} WHERE id = ? AND merchant_employee_id = ?`,
            params
        );

        const updated = await dbGet(
            'SELECT id, title, system_prompt FROM chat_conversations WHERE id = ? AND merchant_employee_id = ?',
            [req.params.id, req.merchant.employee_id]
        );
        res.json({
            success: true,
            conversation: { id: updated.id, title: updated.title, systemPrompt: updated.system_prompt }
        });
    } catch (e) {
        console.error('[merchant-chat] 更新對話失敗:', e.message);
        res.status(500).json({ success: false, error: '更新對話失敗' });
    }
});

/** 刪除對話（連訊息一齊刪） */
router.delete('/conversations/:id', requireMerchant, requireChatEnabled, async (req, res) => {
    try {
        // 先確認擁有權，再刪（兩句都帶 merchant_employee_id）
        const existing = await dbGet(
            'SELECT id FROM chat_conversations WHERE id = ? AND merchant_employee_id = ?',
            [req.params.id, req.merchant.employee_id]
        );
        if (!existing) return res.status(404).json({ success: false, error: '找不到此對話' });

        await dbRun('DELETE FROM chat_messages WHERE conversation_id = ?', [req.params.id]);
        await dbRun(
            'DELETE FROM chat_conversations WHERE id = ? AND merchant_employee_id = ?',
            [req.params.id, req.merchant.employee_id]
        );
        res.json({ success: true });
    } catch (e) {
        console.error('[merchant-chat] 刪除對話失敗:', e.message);
        res.status(500).json({ success: false, error: '刪除對話失敗' });
    }
});

/** 讀取對話訊息 */
router.get('/conversations/:id/messages', requireMerchant, requireChatEnabled, async (req, res) => {
    try {
        const conv = await dbGet(
            'SELECT id, title, system_prompt FROM chat_conversations WHERE id = ? AND merchant_employee_id = ?',
            [req.params.id, req.merchant.employee_id]
        );
        if (!conv) return res.status(404).json({ success: false, error: '找不到此對話' });

        const rows = await dbAll(
            `SELECT id, role, content, created_at FROM chat_messages
              WHERE conversation_id = ? ORDER BY created_at ASC, rowid ASC`,
            [req.params.id]
        );
        res.json({
            success: true,
            conversation: { id: conv.id, title: conv.title, systemPrompt: conv.system_prompt },
            messages: rows.map((r) => ({ id: r.id, role: r.role, content: r.content, createdAt: r.created_at }))
        });
    } catch (e) {
        console.error('[merchant-chat] 讀取訊息失敗:', e.message);
        res.status(500).json({ success: false, error: '讀取訊息失敗' });
    }
});

/**
 * 送訊息 + 串流回覆（SSE）
 *
 * 事件：meta → (thinking) → delta → done｜error
 */
router.post('/conversations/:id/messages', requireMerchant, requireChatEnabled, async (req, res) => {
    const merchantId = req.merchant.employee_id;
    const conversationId = req.params.id;

    const text = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
    if (!text) {
        return res.status(400).json({ success: false, error: '請輸入訊息內容' });
    }
    if (text.length > MAX_CHARS) {
        return res.status(400).json({ success: false, error: `訊息不可超過 ${MAX_CHARS} 個字元` });
    }
    // 未設定 key 就唔好開串流（開咗就要用 SSE 格式報錯，較麻煩）
    // key 優先用呢個商家自己嘅，冇就回落平台／.env
    const resolvedKey = await resolveApiKey(merchantId);
    if (!resolvedKey.key) {
        return res.status(503).json({ success: false, error: aiChat.notConfiguredMessage() });
    }

    let conv;
    try {
        conv = await dbGet(
            'SELECT id, title, system_prompt FROM chat_conversations WHERE id = ? AND merchant_employee_id = ?',
            [conversationId, merchantId]
        );
    } catch (e) {
        console.error('[merchant-chat] 讀取對話失敗:', e.message);
        return res.status(500).json({ success: false, error: '讀取對話失敗' });
    }
    if (!conv) return res.status(404).json({ success: false, error: '找不到此對話' });

    if (!checkRate(merchantId)) {
        return res.status(429).json({
            success: false,
            error: `發送過於頻繁，每分鐘最多 ${RATE_PER_MIN} 條訊息，請稍後再試。`
        });
    }

    // 到呢一步先開始串流；之後所有錯誤都只可以用 SSE 事件報
    const userMessageId = uuidv4();
    const assistantMessageId = uuidv4();
    let clientGone = false;
    let finished = false;

    const abortController = new AbortController();
    req.on('close', () => {
        if (finished) return;
        clientGone = true;
        abortController.abort(); // 客戶端走咗 → 即刻停 upstream，唔好繼續燒額度
    });

    try {
        await dbRun(
            'INSERT INTO chat_messages (id, conversation_id, role, content) VALUES (?, ?, ?, ?)',
            [userMessageId, conversationId, 'user', text]
        );
        await dbRun(
            'UPDATE chat_conversations SET updated_at = CURRENT_TIMESTAMP WHERE id = ? AND merchant_employee_id = ?',
            [conversationId, merchantId]
        );
        // 第一個訊息順手做標題
        const countRow = await dbGet(
            'SELECT COUNT(*) AS c FROM chat_messages WHERE conversation_id = ?',
            [conversationId]
        );
        if (countRow && countRow.c === 1) {
            await dbRun(
                'UPDATE chat_conversations SET title = ? WHERE id = ? AND merchant_employee_id = ?',
                [trimTitle(text), conversationId, merchantId]
            );
        }
    } catch (e) {
        console.error('[merchant-chat] 儲存訊息失敗:', e.message);
        return res.status(500).json({ success: false, error: '儲存訊息失敗' });
    }

    openSse(res);
    sseWrite(res, 'meta', { conversationId, userMessageId });

    // 組歷史（只取最近 HISTORY_LIMIT 條，避免 payload 無限增長）
    let historyRows;
    try {
        historyRows = await dbAll(
            `SELECT role, content FROM chat_messages
              WHERE conversation_id = ?
              ORDER BY created_at DESC, rowid DESC
              LIMIT ?`,
            [conversationId, HISTORY_LIMIT]
        );
        historyRows.reverse();
        // Anthropic 要求第一條係 user；若被截到開頭係 assistant 就丟掉
        while (historyRows.length && historyRows[0].role !== 'user') historyRows.shift();
    } catch (e) {
        console.error('[merchant-chat] 讀取歷史失敗:', e.message);
        sseWrite(res, 'error', { message: '讀取對話歷史失敗' });
        finished = true;
        return res.end();
    }

    let assistantText = '';
    let usage = {};

    try {
        const result = await aiChat.streamChat({
            apiKey: resolvedKey.key, // 逐商家 key 優先
            system: conv.system_prompt || aiChat.defaultSystemPrompt(),
            messages: historyRows.map((r) => ({ role: r.role, content: r.content })),
            signal: abortController.signal,
            onThinking: (t) => sseWrite(res, 'thinking', { text: t }),
            onText: (t) => {
                assistantText += t;
                sseWrite(res, 'delta', { text: t });
            }
        });
        usage = result.usage || {};

        if (clientGone) {
            finished = true;
            return res.end();
        }

        // 模型一個字正文都冇 —— 唔好靜靜地當成功，要明確講出嚟。
        // 最常見原因：思考模式嘅思考內容先消耗 max_tokens，額度唔夠就冇正文
        // （實測 finishReason 會係 'max_tokens'）。前端會顯示呢個訊息。
        if (!assistantText) {
            const msg = result.stopReason === 'max_tokens'
                ? 'AI 未產生回覆：思考用盡了回覆額度。請重試，或把 AI_MAX_TOKENS 調高，或把 AI_THINKING 設為 off。'
                : 'AI 未產生回覆，請重試。';
            console.warn('[merchant-chat] 空回覆，finishReason=', result.stopReason || '(無)');
            sseWrite(res, 'error', { message: msg });
            finished = true;
            return res.end();
        }

        // 空回覆都要存（記錄實情），但唔好存到空白
        if (assistantText) {
            await dbRun(
                `INSERT INTO chat_messages (id, conversation_id, role, content, input_tokens, output_tokens)
                 VALUES (?, ?, 'assistant', ?, ?, ?)`,
                [
                    assistantMessageId,
                    conversationId,
                    assistantText,
                    usage.input_tokens || null,
                    usage.output_tokens || null
                ]
            );
            await dbRun(
                'UPDATE chat_conversations SET updated_at = CURRENT_TIMESTAMP WHERE id = ? AND merchant_employee_id = ?',
                [conversationId, merchantId]
            );
            await pruneOldMessages(conversationId);
        }

        sseWrite(res, 'done', {
            messageId: assistantMessageId,
            usage,
            finishReason: result.stopReason || null
        });
        finished = true;
        res.end();
    } catch (e) {
        finished = true;
        if (clientGone || e.message === 'CLIENT_DISCONNECTED') {
            return res.end(); // 客戶端已走，冇需要再寫
        }
        console.error('[merchant-chat] 串流失敗:', e.message);
        sseWrite(res, 'error', { message: e.message || 'AI 服務發生錯誤' });
        res.end();
    }
});

/** 超出上限就丟最舊嘅訊息（防止單一對話無限增長撐爆磁碟） */
async function pruneOldMessages(conversationId) {
    try {
        const row = await dbGet(
            'SELECT COUNT(*) AS c FROM chat_messages WHERE conversation_id = ?',
            [conversationId]
        );
        if (!row || row.c <= MAX_MESSAGES) return;
        const excess = row.c - MAX_MESSAGES;
        await dbRun(
            `DELETE FROM chat_messages WHERE id IN (
                SELECT id FROM chat_messages WHERE conversation_id = ?
                 ORDER BY created_at ASC, rowid ASC LIMIT ?
             )`,
            [conversationId, excess]
        );
    } catch (e) {
        console.error('[merchant-chat] 修剪舊訊息失敗:', e.message);
    }
}

// ════════════════════════════════════════════════════════════
// 主 merchant 路線（開關其他商家嘅 chatroom）
// 「主 merchant」= .env 嘅 MERCHANT_CHAT_OWNER_USERNAME（逗號分隔）。
// 空 = 冇人有管理權（功能等於全部關閉，除咗冇人可以開）。
// ════════════════════════════════════════════════════════════

/**
 * 全部 merchant 帳號 + 各自 chatroom 開關狀態。
 * 若設定了 MERCHANT_CHAT_PEERS，會同時聚合其他實例嘅商家（每項帶 instance 標籤）。
 * 'local' = 本實例；其餘為 peer 標籤。
 */
router.get('/owner/merchants', requireMerchant, requireOwner, async (req, res) => {
    try {
        const local = await coreListMerchants();
        const label = localInstanceLabel();
        const merchants = local.map((m) => Object.assign({}, m, {
            instance: 'local',
            instanceLabel: label,
            reachable: true
        }));
        const errors = [];

        // 逐個 peer 拉；任何一個掛掉都唔應該令成個面板壞掉
        const peerList = peers.list();
        if (peerList.length && runtime.merchantChatPeerKey()) {
            const results = await Promise.all(peerList.map((p) => peers.info(p)));
            results.forEach((r, i) => {
                const peer = peerList[i];
                if (!r.ok || !r.data || !Array.isArray(r.data.merchants)) {
                    errors.push((r.data && r.data.error) || `實例「${peer.label}」回應異常`);
                    return;
                }
                r.data.merchants.forEach((m) => {
                    merchants.push(Object.assign({}, m, {
                        instance: peer.label,
                        instanceLabel: peer.label,
                        reachable: true
                    }));
                });
            });
        } else if (peerList.length) {
            errors.push('已設定 MERCHANT_CHAT_PEERS 但缺少 MERCHANT_CHAT_PEER_KEY，無法連接其他實例');
        }

        res.json({
            success: true,
            instance: label,
            peersEnabled: peers.isEnabled(),
            peers: peerList.map((p) => p.label),
            errors,
            merchants
        });
    } catch (e) {
        console.error('[merchant-chat] 讀取商家清單失敗:', e.message);
        res.status(500).json({ success: false, error: '讀取商家清單失敗' });
    }
});

/** 開關某個商家。:instance = 'local' 或 peer 標籤 */
router.post('/owner/merchants/:instance/:id/enabled', requireMerchant, requireOwner, async (req, res) => {
    const enabled = req.body?.enabled === true || req.body?.enabled === 'true' || req.body?.enabled === 1;
    const instance = req.params.instance;

    try {
        if (instance !== 'local') {
            const peer = peers.findByLabel(instance);
            if (!peer) return res.status(404).json({ success: false, error: `找不到實例「${instance}」` });
            const r = await peers.setEnabled(peer, req.params.id, enabled);
            if (!r.ok) {
                return res.status(r.status || 502).json({ success: false, error: (r.data && r.data.error) || '遠端操作失敗' });
            }
            console.log(`[merchant-chat] 主商家 ${req.merchant.username} 透過實例 ${instance} 更新商家開關`);
            return res.json(r.data);
        }

        const result = await coreSetEnabled(req.params.id, enabled, req.merchant.employee_id);
        if (!result.ok) {
            const status = result.error === '找不到此商家帳號' ? 404 : 400;
            return res.status(status).json({ success: false, error: result.error });
        }
        console.log(`[merchant-chat] 主商家 ${req.merchant.username} 將 ${result.merchant.username} 嘅 chatroom 設為 ${enabled ? '開啟' : '關閉'}`);
        res.json({ success: true, merchant: result.merchant });
    } catch (e) {
        console.error('[merchant-chat] 更新商家開關失敗:', e.message);
        res.status(500).json({ success: false, error: '更新設定失敗' });
    }
});

/**
 * 設定／清除某個商家專用嘅 AI key。:instance = 'local' 或 peer 標籤
 * body: { apiKey: "..." } → 設定（會先驗證）
 *       { apiKey: "" }    → 清除，回落平台 key／.env
 *
 * key 嘅優先次序：商家自己 → 平台 → .env（見 resolveApiKey）
 */
router.post('/owner/merchants/:instance/:id/api-key', requireMerchant, requireOwner, async (req, res) => {
    const raw = typeof req.body?.apiKey === 'string' ? req.body.apiKey.trim() : null;
    if (raw === null) {
        return res.status(400).json({ success: false, error: '缺少 apiKey 參數' });
    }
    const instance = req.params.instance;

    try {
        if (instance !== 'local') {
            const peer = peers.findByLabel(instance);
            if (!peer) return res.status(404).json({ success: false, error: `找不到實例「${instance}」` });
            const r = await peers.setApiKey(peer, req.params.id, raw);
            if (!r.ok) {
                return res.status(r.status || 502).json({ success: false, error: (r.data && r.data.error) || '遠端操作失敗' });
            }
            return res.json(r.data);
        }

        const result = await coreSetApiKey(
            req.params.id, raw, req.merchant.employee_id,
            () => checkRate(req.merchant.employee_id)
        );
        if (!result.ok) {
            return res.status(result.status || 400).json({ success: false, error: result.error });
        }
        console.log(`[merchant-chat] 主商家 ${req.merchant.username} ${raw ? '設定' : '清除'}咗 ${result.username} 嘅專用金鑰`);
        res.json({ success: true, keyMasked: result.keyMasked, keySource: result.keySource });
    } catch (e) {
        console.error('[merchant-chat] 設定商家金鑰失敗:', e.message);
        res.status(500).json({ success: false, error: '設定金鑰失敗' });
    }
});

/**
 * 主商家代其他商家改帳號／密碼。:instance = 'local' 或 peer 標籤
 * body: { username?, newPassword? }（兩者都可選，至少一個）
 *
 * ⚠️ 同商家自己改（/api/auth/merchant-account）唔同：呢條唔需要對方當前密碼。
 *    改密碼會即刻踢走對方所有 session。
 */
router.post('/owner/merchants/:instance/:id/account', requireMerchant, requireOwner, async (req, res) => {
    const username = typeof req.body?.username === 'string' ? req.body.username.trim() : '';
    const newPassword = typeof req.body?.newPassword === 'string' ? req.body.newPassword : '';
    const fullName = typeof req.body?.fullName === 'string' ? req.body.fullName.trim() : '';
    // 帳號名建立後完全不可改（連主商家都唔可以）
    if (username) {
        return res.status(400).json({ success: false, error: '商家帳號不可更改，如需更換請建立新帳號' });
    }
    if (!newPassword && !fullName) {
        return res.status(400).json({ success: false, error: '請至少提供顯示名稱或新密碼其中一項' });
    }
    const instance = req.params.instance;

    try {
        if (instance !== 'local') {
            const peer = peers.findByLabel(instance);
            if (!peer) return res.status(404).json({ success: false, error: `找不到實例「${instance}」` });
            const r = await peers.setAccount(peer, req.params.id, { username, newPassword, fullName });
            if (!r.ok) {
                return res.status(r.status || 502).json({ success: false, error: (r.data && r.data.error) || '遠端操作失敗' });
            }
            return res.json(r.data);
        }

        const result = await coreSetAccount(req.params.id, { username, newPassword, fullName }, req.merchant.username);
        if (!result.ok) {
            return res.status(result.status || 400).json({ success: false, error: result.error });
        }
        res.json({
            success: true,
            merchant: { id: req.params.id, username: result.username, fullName: result.fullName },
            changed: result.changed,
            passwordChanged: result.passwordChanged
        });
    } catch (e) {
        console.error('[merchant-chat] 更新商家帳號失敗:', e.message);
        res.status(500).json({ success: false, error: '更新帳號失敗' });
    }
});

// ── 平台 AI 金鑰（只有主商家掂得到；商家帳號永遠改唔到）──

/** 讀取目前 AI 設定狀態。⚠️ 永遠唔會回傳 key 本身，只回傳來源同模型名 */
router.get('/owner/settings', requireMerchant, requireOwner, async (req, res) => {
    try {
        await refreshApiKeyFromDb();
        res.json({
            success: true,
            aiConfigured: aiChat.isConfigured(),
            keySource: aiChat.keySource(), // 'database'（介面設定）| 'env'（.env）| 'none'
            keyMasked: aiChat.maskedKey(), // 只露尾 4 碼（••••••••3f2a）；冇 key = null
            model: aiChat.modelName(),
            baseUrl: aiChat.baseUrl()
        });
    } catch (e) {
        console.error('[merchant-chat] 讀取平台設定失敗:', e.message);
        res.status(500).json({ success: false, error: '讀取設定失敗' });
    }
});

/** 設定平台 AI 金鑰：**先驗證，有效才存**（避免打錯一個字之後極難排查） */
router.post('/owner/settings/api-key', requireMerchant, requireOwner, async (req, res) => {
    const apiKey = typeof req.body?.apiKey === 'string' ? req.body.apiKey.trim() : '';
    if (!apiKey) {
        return res.status(400).json({ success: false, error: '請輸入 API 金鑰' });
    }
    if (apiKey.length > 400) {
        return res.status(400).json({ success: false, error: '金鑰長度不合理' });
    }
    // 驗證會打一次真實 API，所以同樣要限流，避免有人用爛 key 刷端點
    if (!checkRate(req.merchant.employee_id)) {
        return res.status(429).json({ success: false, error: '操作過於頻繁，請稍後再試。' });
    }

    let check;
    try {
        check = await aiChat.validateKey(apiKey);
    } catch (e) {
        console.error('[merchant-chat] 金鑰驗證時發生異常:', e.message);
        return res.status(500).json({ success: false, error: '驗證金鑰時發生錯誤' });
    }
    if (!check.ok) {
        // ⚠️ 只 log 失敗事實，唔可以 log 個 key
        console.warn('[merchant-chat] 主商家提供嘅 API 金鑰驗證失敗');
        return res.status(400).json({ success: false, error: check.error || '金鑰驗證失敗' });
    }

    try {
        await dbRun(
            `INSERT INTO chat_platform_settings (key, value, updated_by, updated_at)
             VALUES ('ai_api_key', ?, ?, CURRENT_TIMESTAMP)
             ON CONFLICT(key) DO UPDATE SET
                value = excluded.value,
                updated_by = excluded.updated_by,
                updated_at = CURRENT_TIMESTAMP`,
            [apiKey, req.merchant.employee_id]
        );
        aiChat.setApiKey(apiKey); // 即時生效，唔使 pm2 restart
        console.log(`[merchant-chat] 主商家 ${req.merchant.username} 已更新平台 AI 金鑰`);
        res.json({ success: true, aiConfigured: true, keySource: 'database' });
    } catch (e) {
        console.error('[merchant-chat] 儲存金鑰失敗:', e.message);
        res.status(500).json({ success: false, error: '儲存金鑰失敗' });
    }
});

/** 清除平台金鑰（回落返 .env；兩邊都冇 = AI 停用） */
router.delete('/owner/settings/api-key', requireMerchant, requireOwner, async (req, res) => {
    try {
        await dbRun("DELETE FROM chat_platform_settings WHERE key = 'ai_api_key'", []);
        aiChat.setApiKey(null);
        await refreshApiKeyFromDb();
        console.log(`[merchant-chat] 主商家 ${req.merchant.username} 清除咗平台 AI 金鑰`);
        res.json({ success: true, aiConfigured: aiChat.isConfigured(), keySource: aiChat.keySource() });
    } catch (e) {
        console.error('[merchant-chat] 清除金鑰失敗:', e.message);
        res.status(500).json({ success: false, error: '清除金鑰失敗' });
    }
});

// ════════════════════════════════════════════════════════════
// 主商家檢視所有商家嘅對話（唯讀）
//
// 2026-09-14：原本係獨立嘅員工 admin 頁 /chat-admin/，按用戶要求合併入
// 商家管理面板，所以改為 requireOwner。員工 admin 那條路線已移除。
// ════════════════════════════════════════════════════════════

/** 對話列表；?instance= 指定實例（預設 local）、?merchantId= 只列某個商家 */
router.get('/owner/conversations', requireMerchant, requireOwner, async (req, res) => {
    const merchantId = typeof req.query.merchantId === 'string' ? req.query.merchantId.trim() : '';
    const instance = typeof req.query.instance === 'string' && req.query.instance.trim()
        ? req.query.instance.trim() : 'local';

    try {
        if (instance !== 'local') {
            const peer = peers.findByLabel(instance);
            if (!peer) return res.status(404).json({ success: false, error: `找不到實例「${instance}」` });
            const r = await peers.conversations(peer, merchantId);
            if (!r.ok) {
                return res.status(r.status || 502).json({ success: false, error: (r.data && r.data.error) || '遠端讀取失敗' });
            }
            return res.json(r.data);
        }

        res.json({ success: true, conversations: await coreListConversations(merchantId) });
    } catch (e) {
        console.error('[merchant-chat] owner 讀取對話列表失敗:', e.message);
        res.status(500).json({ success: false, error: '讀取對話列表失敗' });
    }
});

/** 指定對話嘅訊息（主商家唯讀）；?instance= 指定實例（預設 local） */
router.get('/owner/conversations/:id/messages', requireMerchant, requireOwner, async (req, res) => {
    const instance = typeof req.query.instance === 'string' && req.query.instance.trim()
        ? req.query.instance.trim() : 'local';

    try {
        if (instance !== 'local') {
            const peer = peers.findByLabel(instance);
            if (!peer) return res.status(404).json({ success: false, error: `找不到實例「${instance}」` });
            const r = await peers.messages(peer, req.params.id);
            if (!r.ok) {
                return res.status(r.status || 502).json({ success: false, error: (r.data && r.data.error) || '遠端讀取失敗' });
            }
            return res.json(r.data);
        }

        const result = await coreGetMessages(req.params.id);
        if (!result) return res.status(404).json({ success: false, error: '找不到此對話' });
        res.json(Object.assign({ success: true }, result));
    } catch (e) {
        console.error('[merchant-chat] owner 讀取訊息失敗:', e.message);
        res.status(500).json({ success: false, error: '讀取訊息失敗' });
    }
});

// ════════════════════════════════════════════════════════════
// Peer 路線（畀「總控」實例呼叫；只靠 MERCHANT_CHAT_PEER_KEY 認證）
//
// ⚠️ 呢啲端點會落在對外開放嘅實例上（例：production 嘅 catstearoom.dev），
//    所以：只認密鑰、用 timing-safe 比對、密鑰要夠強、建議只經內網／127.0.0.1 呼叫。
// ════════════════════════════════════════════════════════════

/** 本實例身份 + 所有商家（給總控聚合用） */
router.get('/peer/info', requirePeerKey, async (req, res) => {
    try {
        res.json({
            success: true,
            instance: localInstanceLabel(),
            merchants: await coreListMerchants()
        });
    } catch (e) {
        console.error('[merchant-chat] peer 讀取商家清單失敗:', e.message);
        res.status(500).json({ success: false, error: '讀取商家清單失敗' });
    }
});

router.post('/peer/merchants/:id/enabled', requirePeerKey, async (req, res) => {
    const enabled = req.body?.enabled === true || req.body?.enabled === 'true' || req.body?.enabled === 1;
    try {
        const result = await coreSetEnabled(req.params.id, enabled, 'peer');
        if (!result.ok) {
            return res.status(result.error === '找不到此商家帳號' ? 404 : 400).json({ success: false, error: result.error });
        }
        console.log(`[merchant-chat] 經 peer 將 ${result.merchant.username} 嘅 chatroom 設為 ${enabled ? '開啟' : '關閉'}`);
        res.json({ success: true, merchant: result.merchant });
    } catch (e) {
        console.error('[merchant-chat] peer 更新商家開關失敗:', e.message);
        res.status(500).json({ success: false, error: '更新設定失敗' });
    }
});

router.post('/peer/merchants/:id/api-key', requirePeerKey, async (req, res) => {
    const raw = typeof req.body?.apiKey === 'string' ? req.body.apiKey.trim() : null;
    if (raw === null) return res.status(400).json({ success: false, error: '缺少 apiKey 參數' });
    try {
        // peer 之間冇共用記憶體限流桶，用 'peer' 做 key 一樣有效
        const result = await coreSetApiKey(req.params.id, raw, 'peer', () => checkRate('peer'));
        if (!result.ok) {
            return res.status(result.status || 400).json({ success: false, error: result.error });
        }
        res.json({ success: true, keyMasked: result.keyMasked, keySource: result.keySource });
    } catch (e) {
        console.error('[merchant-chat] peer 設定商家金鑰失敗:', e.message);
        res.status(500).json({ success: false, error: '設定金鑰失敗' });
    }
});

/** 主商家經總控代改本實例商家嘅帳號／密碼 */
router.post('/peer/merchants/:id/account', requirePeerKey, async (req, res) => {
    const username = typeof req.body?.username === 'string' ? req.body.username.trim() : '';
    const newPassword = typeof req.body?.newPassword === 'string' ? req.body.newPassword : '';
    const fullName = typeof req.body?.fullName === 'string' ? req.body.fullName.trim() : '';
    // 帳號名建立後完全不可改
    if (username) {
        return res.status(400).json({ success: false, error: '商家帳號不可更改，如需更換請建立新帳號' });
    }
    if (!newPassword && !fullName) {
        return res.status(400).json({ success: false, error: '請至少提供顯示名稱或新密碼其中一項' });
    }
    try {
        const result = await coreSetAccount(req.params.id, { username, newPassword, fullName }, 'peer');
        if (!result.ok) {
            return res.status(result.status || 400).json({ success: false, error: result.error });
        }
        res.json({
            success: true,
            merchant: { id: req.params.id, username: result.username, fullName: result.fullName },
            changed: result.changed,
            passwordChanged: result.passwordChanged
        });
    } catch (e) {
        console.error('[merchant-chat] peer 更新商家帳號失敗:', e.message);
        res.status(500).json({ success: false, error: '更新帳號失敗' });
    }
});

router.get('/peer/conversations', requirePeerKey, async (req, res) => {
    const merchantId = typeof req.query.merchantId === 'string' ? req.query.merchantId.trim() : '';
    try {
        res.json({ success: true, conversations: await coreListConversations(merchantId) });
    } catch (e) {
        console.error('[merchant-chat] peer 讀取對話列表失敗:', e.message);
        res.status(500).json({ success: false, error: '讀取對話列表失敗' });
    }
});

router.get('/peer/conversations/:id/messages', requirePeerKey, async (req, res) => {
    try {
        const result = await coreGetMessages(req.params.id);
        if (!result) return res.status(404).json({ success: false, error: '找不到此對話' });
        res.json(Object.assign({ success: true }, result));
    } catch (e) {
        console.error('[merchant-chat] peer 讀取訊息失敗:', e.message);
        res.status(500).json({ success: false, error: '讀取訊息失敗' });
    }
});

module.exports = router;
