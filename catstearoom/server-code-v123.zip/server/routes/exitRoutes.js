const express = require('express');
const router = express.Router();
const storeAwareMiddleware = require('../middleware/store-aware');
const kpayService = require('../services/kpayService');
const { getCustomerByQRCode, checkoutCustomer, getKpayPaymentByCustomer } = require('../../database/db');

// 為所有路由添加分店上下文中間件
router.use(storeAwareMiddleware.initStoreContext);

// QR Code掃描驗證（離場結賬）
router.post('/scan', async (req, res) => {
  try {
    const { qr_code } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';

    if (!qr_code) {
      return res.status(400).json({ error: '請提供QR Code' });
    }

    // 解析QR Code數據
    let qrData;
    try {
      qrData = JSON.parse(qr_code);
    } catch (e) {
      qrData = { qr_code: qr_code };
    }

    const qrCodeValue = qrData.qr_code || qr_code;

    // 查找客人（分店過濾）
    const customer = await getCustomerByQRCode(qrCodeValue, storeId);

    if (!customer) {
      return res.status(404).json({
        error: 'QR Code無效或客人已結賬',
        valid: false,
        can_exit: false
      });
    }

    // 檢查是否已結賬
    if (customer.is_checked_out) {
      return res.json({
        success: true,
        valid: true,
        checked_out: true,
        can_exit: true,
        message: '客人已結賬，可以離場',
        customer: {
          table_number: customer.table_number,
          checkout_time: customer.checkout_time,
          total_amount: customer.total_amount
        }
      });
    }

    // 獲取客人詳細訂單信息
    const db = require('../../database/db').db;
    const orderItems = await new Promise((resolve, reject) => {
      db.all(
        `SELECT oi.*, p.name as product_name
         FROM order_items oi
         LEFT JOIN products p ON oi.product_id = p.id
         WHERE oi.customer_id = ? AND COALESCE(oi.is_reversed, 0) = 0
         ORDER BY oi.purchased_at ASC`,
        [customer.id],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });

    // 計算總金額（含立減/折扣優惠）
    const totalAmount = orderItems.reduce((sum, item) => {
      const basePrice = item.price_at_time || 0;
      const flatDisc = item.flat_discount || 0;
      const pctDisc = item.percent_discount || 0;
      let effPrice = basePrice - flatDisc;
      if (pctDisc > 0) effPrice = effPrice * (100 - pctDisc) / 100;
      const effective = basePrice >= 0 ? Math.max(0, effPrice) : effPrice;
      return sum + Math.round(effective * item.quantity * 100) / 100;
    }, 0);

    // 更新數據庫中的總金額（如果不同步）
    if (Math.abs(totalAmount - customer.total_amount) > 0.01) {
      db.run(
        `UPDATE customers SET total_amount = ? WHERE id = ?`,
        [totalAmount, customer.id]
      );
    }

    res.json({
      success: true,
      valid: true,
      checked_out: false,
      can_exit: false, // 需要先結賬才能離場
      message: 'QR Code驗證成功，請結賬後離場',
      customer: {
        id: customer.id,
        table_number: customer.table_number,
        people_count: customer.people_count,
        entry_time: customer.entry_time,
        total_amount: totalAmount,
        qr_code: customer.qr_code
      },
      order_items: orderItems,
      summary: {
        total_items: orderItems.reduce((sum, item) => sum + item.quantity, 0),
        total_amount: totalAmount,
        item_count: orderItems.length
      }
    });

  } catch (error) {
    console.error('離場掃描錯誤:', error);
    res.status(500).json({
      error: '離場掃描失敗',
      message: error.message
    });
  }
});

// 執行結賬
router.post('/checkout', async (req, res) => {
  try {
    const { customer_id } = req.body;

    if (!customer_id) {
      return res.status(400).json({ error: '請提供客人ID' });
    }

    // 檢查客人是否存在且未結賬
    const customer = await new Promise((resolve, reject) => {
      const db = require('../../database/db').db;
      db.get(
        `SELECT * FROM customers WHERE id = ? AND is_checked_out = 0`,
        [customer_id],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!customer) {
      return res.status(404).json({ error: '客人不存在或已結賬' });
    }

    // 防繞過支付：非 mock 模式必須有成功嘅 KPay 支付記錄先可以結賬
    const kpayCfg = await kpayService.getConfig(customer.store_id || 'default_store');
    if (kpayCfg.mode !== 'mock') {
      const payment = await getKpayPaymentByCustomer(customer_id);
      if (!payment || payment.status !== 'success') {
        return res.status(400).json({ error: '請先完成付款', message: '必須通過卡機完成付款後才能結賬' });
      }
    }

    // 執行結賬
    await checkoutCustomer(customer_id);

    // 添加交易記錄
    const transactionId = require('uuid').v4();
    const db = require('../../database/db').db;
    db.run(
      `INSERT INTO transactions (id, customer_id, transaction_type, amount, description)
       VALUES (?, ?, ?, ?, ?)`,
      [
        transactionId,
        customer_id,
        'checkout',
        customer.total_amount,
        `離場結賬 - 桌號 ${customer.table_number}`
      ],
      (err) => {
        if (err) console.error('添加交易記錄錯誤:', err);
      }
    );

    // 觸發Socket事件
    const io = req.app.get('io');
    io.emit('checkout-complete', {
      customer_id: customer_id,
      table_number: customer.table_number,
      total_amount: customer.total_amount,
      checkout_time: new Date().toISOString(),
      exit_machine: true
    });

    // 通知門鎖系統允許離開（5分鐘有效期）
    io.emit('device-control', {
      device: 'door-lock',
      action: 'allow-exit',
      qr_code: customer.qr_code,
      valid_until: Date.now() + 300000, // 5分鐘
      customer_id: customer_id
    });

    // 觸發打印結賬小票
    const receiptData = {
      table_number: customer.table_number,
      qr_code: customer.qr_code,
      total_amount: customer.total_amount,
      checkout_time: new Date().toLocaleString('zh-TW'),
      transaction_id: transactionId
    };

    io.emit('print-exit-receipt', receiptData);

    res.json({
      success: true,
      message: '結賬成功，可以離場',
      customer_id: customer_id,
      table_number: customer.table_number,
      total_amount: customer.total_amount,
      checkout_time: new Date().toISOString(),
      exit_valid_until: Date.now() + 300000,
      receipt_data: receiptData
    });

  } catch (error) {
    console.error('結賬錯誤:', error);
    res.status(500).json({
      error: '結賬失敗',
      message: error.message
    });
  }
});

// 門鎖QR Code驗證（離場時）
router.post('/door-scan', async (req, res) => {
  try {
    const { qr_code } = req.body;

    if (!qr_code) {
      return res.status(400).json({ error: '請提供QR Code' });
    }

    // 解析QR Code數據
    let qrData;
    try {
      qrData = JSON.parse(qr_code);
    } catch (e) {
      qrData = { qr_code: qr_code };
    }

    const qrCodeValue = qrData.qr_code || qr_code;

    // 查找客人
    const db = require('../../database/db').db;
    const customer = await new Promise((resolve, reject) => {
      db.get(
        `SELECT * FROM customers WHERE qr_code = ?`,
        [qrCodeValue],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!customer) {
      return res.json({
        success: false,
        valid: false,
        door_open: false,
        message: '無效的QR Code'
      });
    }

    // 檢查是否已結賬
    if (!customer.is_checked_out) {
      return res.json({
        success: false,
        valid: true,
        checked_out: false,
        door_open: false,
        message: '請先結賬後再離場',
        customer: {
          table_number: customer.table_number,
          total_amount: customer.total_amount
        }
      });
    }

    // 檢查結賬時間是否在有效期內（5分鐘內）
    const checkoutTime = new Date(customer.checkout_time).getTime();
    const currentTime = Date.now();
    const timeSinceCheckout = currentTime - checkoutTime;

    if (timeSinceCheckout > 300000) { // 5分鐘
      return res.json({
        success: false,
        valid: true,
        checked_out: true,
        door_open: false,
        message: '結賬已過期，請重新結賬',
        customer: {
          table_number: customer.table_number,
          checkout_time: customer.checkout_time,
          minutes_ago: Math.floor(timeSinceCheckout / 60000)
        }
      });
    }

    // 可以開門
    const io = req.app.get('io');
    io.emit('device-control', {
      device: 'door-lock',
      action: 'open',
      qr_code: qrCodeValue,
      customer_id: customer.id
    });

    res.json({
      success: true,
      valid: true,
      checked_out: true,
      door_open: true,
      message: '驗證成功，門鎖已開啟',
      customer: {
        table_number: customer.table_number,
        checkout_time: customer.checkout_time,
        total_amount: customer.total_amount
      },
      door_status: {
        open: true,
        duration: 10000 // 門鎖開啟10秒
      }
    });

  } catch (error) {
    console.error('門鎖掃描錯誤:', error);
    res.status(500).json({
      error: '門鎖掃描失敗',
      message: error.message
    });
  }
});

// 獲取今日離場統計
router.get('/stats/today', (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];

    const db = require('../../database/db').db;
    db.all(
      `SELECT
        COUNT(*) as total_checkouts,
        SUM(total_amount) as total_revenue,
        AVG(total_amount) as avg_checkout,
        MIN(checkout_time) as first_checkout,
        MAX(checkout_time) as last_checkout
       FROM customers
       WHERE DATE(checkout_time) = ? AND is_checked_out = 1`,
      [today],
      (err, stats) => {
        if (err) {
          console.error('獲取離場統計錯誤:', err);
          return res.status(500).json({ error: '獲取統計失敗', message: err.message });
        }

        res.json({
          success: true,
          date: today,
          stats: stats[0] || {
            total_checkouts: 0,
            total_revenue: 0,
            avg_checkout: 0,
            first_checkout: null,
            last_checkout: null
          }
        });
      }
    );
  } catch (error) {
    console.error('獲取離場統計錯誤:', error);
    res.status(500).json({
      error: '獲取離場統計失敗',
      message: error.message
    });
  }
});

// 測試門鎖開啟（測試用）
router.post('/test-door-open', (req, res) => {
  try {
    const io = req.app.get('io');
    io.emit('device-control', {
      device: 'door-lock',
      action: 'open',
      test_mode: true,
      duration: 5000
    });

    res.json({
      success: true,
      message: '已發送開啟門鎖指令（測試模式）'
    });
  } catch (error) {
    console.error('測試門鎖開啟錯誤:', error);
    res.status(500).json({
      error: '測試門鎖開啟失敗',
      message: error.message
    });
  }
});

// ─────────────────────────────────────────────────────────────
// 商品掃描（離場機器「用途設定」用）
//
// 商品的 UUID（products.id）就係商品條碼，唔另設 barcode 欄位；
// 商品結賬亦唔另設流程，而係開一張無桌號客人（table_number = ''），
// 之後完全重用收銀系統現有嘅落單、KPay 收款、結賬 API。
// ─────────────────────────────────────────────────────────────

// 以條碼（商品 UUID）查商品（限本分店）
router.post('/product-scan', async (req, res) => {
  try {
    const { code } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';
    const productId = String(code || '').trim();

    if (!productId) {
      return res.status(400).json({ error: '請提供商品條碼' });
    }

    const db = require('../../database/db').db;
    const product = await new Promise((resolve, reject) => {
      db.get(
        `SELECT id, name, price, stock, category, is_available, track_inventory
           FROM products
          WHERE id = ? AND store_id = ?`,
        [productId, storeId],
        (err, row) => (err ? reject(err) : resolve(row))
      );
    });

    // 搵唔到就當作「未存在」，交由前端按用途決定點提示
    if (!product) {
      return res.json({ success: true, found: false });
    }

    // 已下架商品照樣回傳（連 is_available），等前端可以分辨「已存在但下架」
    return res.json({ success: true, found: true, product });
  } catch (error) {
    console.error('商品條碼查詢錯誤:', error);
    return res.status(500).json({ error: '商品條碼查詢失敗', message: error.message });
  }
});

// 開一張無桌號購物車（商品結賬用）
// KPay 收款必須綁客人，所以要先開一張 table_number = '' 嘅無桌號客人。
router.post('/product-cart', async (req, res) => {
  try {
    const storeId = req.storeContext?.store_id || 'default_store';
    const db = require('../../database/db').db;
    const customerId = require('uuid').v4();
    const qrCode = `NO-TABLE-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    await new Promise((resolve, reject) => {
      db.run(
        `INSERT INTO customers
           (id, table_number, qr_code, people_count, entry_time, total_amount, is_checked_out, store_id)
         VALUES (?, '', ?, 0, ?, 0, 0, ?)`,
        [customerId, qrCode, new Date().toISOString(), storeId],
        (err) => (err ? reject(err) : resolve())
      );
    });

    return res.json({ success: true, customer_id: customerId, qr_code: qrCode });
  } catch (error) {
    console.error('開購物車錯誤:', error);
    return res.status(500).json({ error: '開購物車失敗', message: error.message });
  }
});

// 放棄購物車（店員按「清除」，或清走掃過一件就離開嘅殘留購物車）
// 未付款、未入帳嘅購物車唔算一筆生意，所以直接刪走，並還原庫存。
// ⚠️ 呼叫前前端要確保已經取消進行中嘅 KPay 付款（/api/kpay/cancel）。
router.post('/product-cart/cancel', async (req, res) => {
  try {
    const { customer_id } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';

    if (!customer_id) {
      return res.status(400).json({ error: '請提供購物車ID' });
    }

    const db = require('../../database/db').db;

    const customer = await new Promise((resolve, reject) => {
      db.get(
        `SELECT id, is_checked_out FROM customers WHERE id = ? AND store_id = ?`,
        [customer_id, storeId],
        (err, row) => (err ? reject(err) : resolve(row))
      );
    });

    if (!customer) {
      return res.status(404).json({ error: '購物車不存在' });
    }

    // 已結賬嘅購物車唔可以再取消，避免抹走已入帳嘅記錄
    if (customer.is_checked_out) {
      return res.status(400).json({ error: '此購物車已經結賬，無法清除' });
    }

    // 還原庫存（只還原 track_inventory = 1 嘅商品）
    const items = await new Promise((resolve, reject) => {
      db.all(
        `SELECT oi.product_id, oi.quantity, p.track_inventory
           FROM order_items oi
           LEFT JOIN products p ON p.id = oi.product_id
          WHERE oi.customer_id = ?`,
        [customer_id],
        (err, rows) => (err ? reject(err) : resolve(rows || []))
      );
    });

    for (const item of items) {
      if (item.track_inventory !== 1) continue;
      await new Promise((resolve) => {
        db.run(
          `UPDATE products SET stock = stock + ? WHERE id = ? AND store_id = ?`,
          [item.quantity, item.product_id, storeId],
          () => resolve()
        );
      });
    }

    await new Promise((resolve, reject) => {
      db.run(
        `DELETE FROM order_items WHERE customer_id = ?`,
        [customer_id],
        (err) => (err ? reject(err) : resolve())
      );
    });

    await new Promise((resolve, reject) => {
      db.run(
        `DELETE FROM customers WHERE id = ? AND store_id = ?`,
        [customer_id, storeId],
        (err) => (err ? reject(err) : resolve())
      );
    });

    return res.json({ success: true, removed_items: items.length });
  } catch (error) {
    console.error('清除購物車錯誤:', error);
    return res.status(500).json({ error: '清除購物車失敗', message: error.message });
  }
});

module.exports = router;