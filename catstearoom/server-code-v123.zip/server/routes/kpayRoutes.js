/**
 * KPay 卡機收款 Routes（離場機真支付，路線 A：LAN KPOS）
 *
 * POST /api/kpay/pay       啟動 KPOS 收款（pending）→ 前端輪詢 /status
 * POST /api/kpay/callback  KPOS 異步回調（callback-driven 結賬，收銀主機即時見已結賬）
 * GET  /api/kpay/status    查支付狀態（pending 超 65 秒會主動 query）
 * POST /api/kpay/cancel    關閉進行中嘅支付（close 後補 query 確認，防 race window）
 * POST /api/kpay/refund    撤銷／退款已成功嘅支付（mode: refund=已結算 / void=未結算）
 *
 * 付款成功 → processKpayResult()：update kpay_payments → checkoutCustomer()
 *   → 插 transactions(payment_method) → emit checkout-complete / device-control allow-exit /
 *     print-exit-receipt（同 exitRoutes /checkout 形狀一致，收銀主機經 socket 即時更新）。
 */

const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const authMiddleware = require('../middleware/auth');
const storeAwareMiddleware = require('../middleware/store-aware');
const kpayService = require('../services/kpayService');
const dbOps = require('../../database/db');
const { db, checkoutCustomer, getCustomerById, getKpayConfig } = dbOps;
const {
  createKpayPayment,
  updateKpayPayment,
  claimKpayPayment,
  getKpayPaymentByOutTradeNo,
  getKpayPaymentByCustomer
} = dbOps;

// 軟驗證（有 token 就延長 session，冇就放行）+ 分店上下文（向後兼容）
router.use(authMiddleware.softAuthenticate);
router.use(storeAwareMiddleware.initStoreContext);

// ===== 常數 =====
// 前端付款掣 → KPay paymentType
// ⚠️ 2026-09-23 真機實測修正（demo 機 192.168.3.167）：
//   改用**正掃**。原因：離場機係自助（無人看守），依 KPay 指引必須用 Kiosk 模式，
//   而 Kiosk 模式**只支援正掃**（官方確認）——原本嘅反掃（3／7）喺 Kiosk 模式下
//   會回 700013「二維碼串碼不能為空」。
//   KPay 已於 2026-09-23 為測試機開通正掃（開通後**卡機要重啟**先生效）：
//     type 2（微信／支付寶 正掃）→ 10000
//     type 6（PayMe 正掃）      → 10000
const PAYMENT_TYPE_MAP = { card: 1, wechat: 2, alipay: 2, fps: 8, payme: 6 };
// 反掃類型（卡機鏡頭掃客人手機付款碼）→ 要加 frontCamera 指定前鏡頭。
// 正掃（客人掃卡機螢幕）**唔用卡機鏡頭**，唔可以加 frontCamera（加咗會變「二維碼無效」）。
// 2026-09-23：改用正掃後已無類型需要 frontCamera；保留機制以便日後切回反掃。
const FRONT_CAMERA_TYPES = new Set();
// KPay payMethod → transactions.payment_method
const PAY_METHOD_MAP = {
  1: 'visa', 2: 'mastercard', 3: 'unionpay', 4: 'wechat', 5: 'alipay',
  6: 'amex', 7: 'diners', 8: 'jcb', 9: 'unionpay_qr', 12: 'payme', 14: 'fps'
};
// 非成功 payResult → 狀態
const FAIL_STATUS_MAP = { '-1': 'timeout', '3': 'failed', '4': 'failed', '5': 'cancelled', '6': 'cancelled' };

let ioInstance = null;

// 節流記錄：out_trade_no → 上次動作嘅時間戳。用途見 /status handler。
// 流程結束（非 pending）時會清走，避免隨交易數量無限增長。
const lastQrNudgeAt = new Map();    // 上次送 POS_QR_QUERY 叫卡機查結果
const lastStatusQueryAt = new Map(); // 上次向卡機讀 query 結果

function normalizePaymentType(t) {
  if (typeof t === 'number') return t; // 直接 KPay paymentType
  return PAYMENT_TYPE_MAP[String(t || '').toLowerCase()] || null;
}

function mapPayMethod(payMethod) {
  return PAY_METHOD_MAP[payMethod] || 'kpay';
}

async function clearCheckoutPending(customerId) {
  await new Promise((resolve, reject) => {
    db.run(
      `UPDATE customers SET checkout_pending = 0, checkout_pending_at = NULL WHERE id = ?`,
      [customerId],
      (err) => (err ? reject(err) : resolve())
    );
  });
}

function emitCheckoutEvents(customer, payment) {
  if (!ioInstance) {
    // 冇 io = 呢啲事件發唔出（結賬仍會完成，但門唔會開、小票唔會印）
    console.error(
      `[kpay] ⚠️ socket.io 未初始化，結賬事件無法發出（outTradeNo=${payment.out_trade_no}）`
    );
    return;
  }
  const payMethod = mapPayMethod(payment.pay_method);
  // 呢啲事件原本完全冇 log，客人話「門冇開」時查唔到，所以加記錄
  console.log(
    `[kpay] 結賬完成事件: 桌號=${customer.table_number} 金額=$${payment.amount} ` +
    `付款方式=${payMethod} outTradeNo=${payment.out_trade_no}`
  );
  ioInstance.emit('checkout-complete', {
    customer_id: customer.id,
    table_number: customer.table_number,
    total_amount: payment.amount,
    checkout_time: new Date().toISOString(),
    exit_machine: true,
    payment_method: payMethod
  });
  // 通知門鎖系統允許離開（5 分鐘有效期）
  ioInstance.emit('device-control', {
    device: 'door-lock',
    action: 'allow-exit',
    qr_code: customer.qr_code,
    valid_until: Date.now() + 300000,
    customer_id: customer.id
  });
  console.log(`[kpay] 已發 device-control allow-exit（桌號=${customer.table_number}，5 分鐘有效）`);
  // 觸發打印結賬小票
  ioInstance.emit('print-exit-receipt', {
    table_number: customer.table_number,
    qr_code: customer.qr_code,
    total_amount: payment.amount,
    checkout_time: new Date().toLocaleString('zh-TW'),
    transaction_id: payment.out_trade_no
  });
  console.log(`[kpay] 已發 print-exit-receipt（桌號=${customer.table_number}）`);
}

/**
 * 處理支付結果（回調 / 主動 query / cancel confirm / mock 共用；idempotent）
 * @param {Object} payment kpay_payments row（僅作欄位來源，處理權以 claim 為準）
 * @param {Object} result  { payResult, payMethod, transactionNo, refNo, payAmount, reason }
 *   reason = 卡機回報嘅失敗說明（例：「請顧客使用另一張卡」／「用戶取消交易」），
 *            存落 kpay_payments.reason 俾離場機顯示
 */
async function processKpayResult(payment, result) {
  const customerId = payment.customer_id;

  // ⚠️ payResult=1 = 交易**處理中**，唔係失敗。
  // 必須喺「原子領取」之前就 return —— 因為領取會將狀態改成 processing，
  // 之後一旦被標成 failed，真正嘅成功回調就會 claim 唔到而被丟棄，
  // 結果係「客人付咗錢但系統唔結賬」（2026-09-23 真機實測到呢個情況）。
  // 維持 pending，繼續等真正嘅結果。
  if (String(result.payResult) === '1') {
    return { success: false, status: 'pending', processing: true };
  }

  // 原子領取處理權：pending → processing 只會有一個並發 caller 成功
  // （KPOS retry / 65s 主動 query / cancel confirm 同時到 → 唔會 double checkoutCustomer / double emit）
  const claimed = await claimKpayPayment(payment.out_trade_no);
  if (!claimed) {
    // 已有並發處理緊或者已處理 → no-op（idempotent）
    const cur = await getKpayPaymentByOutTradeNo(payment.out_trade_no);
    return { success: !!(cur && cur.status === 'success'), status: cur ? cur.status : 'none' };
  }

  try {
    if (result.payResult === 2) {
      // 金額校驗（payAmount 12 位零填充）
      const expected = kpayService.formatAmount(payment.amount);
      if (result.payAmount && result.payAmount !== expected) {
        console.error(`[kpay] 金額不符: 期望 ${expected}, 實收 ${result.payAmount}`);
        await updateKpayPayment(payment.out_trade_no, { status: 'failed' });
        await clearCheckoutPending(customerId);
        return { success: false, status: 'failed' };
      }

      // 註：叫卡機離開 QR 頁嘅 POS_QR_QUERY **唔喺呢度送**。
      // 呢個函式係喺卡機轉頁之後（回調／query 回報結果）先被呼叫，嗰時卡機早已
      // 離開 QR 頁，送過去只會回 50002。改喺 /status handler 嘅 pending 期間
      // 每 QR_NUDGE_INTERVAL_MS 週期性送，先至趕得上。

      await updateKpayPayment(payment.out_trade_no, {
        status: 'success',
        pay_method: result.payMethod || null,
        transaction_no: result.transactionNo || null,
        ref_no: result.refNo || null,
        paid_at: new Date().toISOString()
      });

      const customer = await getCustomerById(customerId);
      if (customer && !customer.is_checked_out) {
        await checkoutCustomer(customerId);
        // 添加交易記錄（payment_method 第一次由離場機填寫）
        db.run(
          `INSERT INTO transactions (id, customer_id, transaction_type, amount, description, payment_method)
           VALUES (?, ?, 'checkout', ?, ?, ?)`,
          [
            uuidv4(),
            customerId,
            payment.amount,
            `離場結賬(KPay ${payment.out_trade_no}) - 桌號 ${customer.table_number}`,
            mapPayMethod(result.payMethod)
          ],
          (err) => { if (err) console.error('[kpay] 添加交易記錄錯誤:', err); }
        );
        emitCheckoutEvents(customer, payment);
      } else {
        console.warn('[kpay] 客人已結賬或不存在，只記錄支付成功:', customerId);
      }
      return { success: true, status: 'success' };
    }

    // 失敗 / 超時 / 撤銷 / 取消
    const status = FAIL_STATUS_MAP[String(result.payResult)] || 'failed';
    // 卡機嘅 reason 係俾客人／操作員睇嘅說明，唔好丟（原本只傳 payResult 就丟咗）
    if (result.reason) {
      console.log(`[kpay] 交易未成功 (${status})，卡機原因: ${result.reason}`);
    }
    await updateKpayPayment(payment.out_trade_no, { status, reason: result.reason || null });
    await clearCheckoutPending(customerId);
    return { success: false, status, reason: result.reason || null };
  } catch (e) {
    // 領咗處理權但中途死 → 標 failed，等唔會永久卡死喺 'processing'
    console.error('[kpay] 處理支付結果中途錯誤，標記 failed:', e.message);
    await updateKpayPayment(payment.out_trade_no, { status: 'failed' }).catch(() => {});
    await clearCheckoutPending(customerId).catch(() => {});
    throw e;
  }
}

// ===== 啟動 KPOS 收款 =====
router.post('/pay', async (req, res) => {
  let outTradeNo = null;
  let customerId = null;
  try {
    const { customer_id, payment_type } = req.body;
    if (!customer_id) return res.status(400).json({ error: '請提供客人ID' });
    customerId = customer_id;

    const customer = await getCustomerById(customer_id);
    if (!customer) return res.status(404).json({ error: '客人不存在' });
    if (customer.is_checked_out) return res.status(400).json({ error: '客人已結賬' });

    const storeId = req.storeContext?.store_id || customer.store_id || 'default_store';

    // 已有進行中支付 → 直接回傳，前端恢復輪詢（避免重複開單）
    const latest = await getKpayPaymentByCustomer(customer_id);
    if (latest && latest.status === 'pending') {
      return res.json({ success: true, out_trade_no: latest.out_trade_no, amount: latest.amount, status: 'pending', resumed: true });
    }

    const paymentType = normalizePaymentType(payment_type);
    if (!paymentType) return res.status(400).json({ error: '無效的付款方式' });

    outTradeNo = 'EX' + Date.now() + Math.random().toString(36).slice(2, 6).toUpperCase();
    const amount = customer.total_amount || 0;

    await createKpayPayment({ customerId: customer_id, outTradeNo, amount, paymentType, storeId });

    // 凍結計費：付款期間 billing scheduler 唔好再加時段費
    await new Promise((resolve, reject) => {
      db.run(
        `UPDATE customers SET checkout_pending = 1, checkout_pending_at = ? WHERE id = ?`,
        [new Date().toISOString(), customer_id],
        (err) => (err ? reject(err) : resolve())
      );
    });

    const cfg = await kpayService.getConfig(storeId);
    const result = await kpayService.sales({
      outTradeNo,
      amount,
      paymentType,
      callbackUrl: cfg.callback_url,
      description: `離場結賬 - 桌號 ${customer.table_number}`,
      storeId,
      frontCamera: FRONT_CAMERA_TYPES.has(paymentType)
    });

    const code = result && (result.code !== undefined ? result.code : result.data?.code);
    // 10000 成功 / 11000 已轉前台收款 → 正常等待付款
    if (code === 10000 || code === 11000 || code === undefined) {
      return res.json({ success: true, out_trade_no: outTradeNo, amount, status: 'pending', mode: cfg.mode });
    }

    // 其他 error code → 標記失敗
    await updateKpayPayment(outTradeNo, { status: 'failed' });
    await clearCheckoutPending(customer_id);
    return res.status(500).json({ error: '啟動收款失敗', kpay_code: code, message: (result && result.message) || 'KPOS 拒絕收款' });
  } catch (error) {
    console.error('[kpay] 啟動支付錯誤:', error);
    // 清理殘留 pending（KPOS 連唔到等情況）
    if (outTradeNo) {
      await updateKpayPayment(outTradeNo, { status: 'failed' }).catch(() => {});
    }
    if (customerId) {
      await clearCheckoutPending(customerId).catch(() => {});
    }
    return res.status(500).json({ error: '啟動支付失敗', message: error.message });
  }
});

// ===== KPOS 異步回調（callback-driven 結賬；唔需要 auth）=====
router.post('/callback', async (req, res) => {
  try {
    const body = req.body || {};
    // ⚠️ 入嚟第一件事就記低 —— 呢個 handler 對於「冇 outTradeNo」同「未知交易」
    // 兩種拒絕都係**靜默**嘅，令「卡機冇打嚟」同「打咗嚟但被拒」分辨唔到。
    // 2026-09-23 真機測試就係因為咁查唔出 Kiosk 正掃付款回調到底有冇到。
    console.log('[kpay] 收到支付回調:', JSON.stringify(body).slice(0, 500));

    const outTradeNo = body.outTradeNO || body.out_trade_no;
    if (!outTradeNo) {
      console.warn('[kpay] 回調缺少 outTradeNO，拒收。body keys =', Object.keys(body).join(', '));
      return res.status(400).json({ code: 40004, message: '缺少 outTradeNO' });
    }

    const payment = await getKpayPaymentByOutTradeNo(outTradeNo);
    if (!payment) {
      console.warn('[kpay] 回調帶嚟未知交易，拒收:', outTradeNo);
      return res.status(404).json({ code: 40004, message: '未知交易' });
    }

    const storeId = payment.store_id || 'default_store';

    // 驗簽（mock 跳過；lan 用 platformPublicKey，body 用原 byte 驗）
    const verified = await kpayService.verifyCallback({ headers: req.headers, body, rawBody: req.rawBody, storeId });
    if (!verified) {
      console.warn('[kpay] 回調簽名無效:', outTradeNo);
      return res.status(401).json({ code: 40002, message: '簽名無效' });
    }

    // idempotent：已處理過直接 {code:10000}（KPOS 會重試最多 3 次）
    if (payment.status === 'success') {
      return res.json({ code: 10000 });
    }

    await processKpayResult(payment, {
      payResult: body.payResult,
      payMethod: body.payMethod,
      transactionNo: body.transactionNo,
      refNo: body.refNo,
      payAmount: body.payAmount,
      reason: body.reason
    });

    return res.json({ code: 10000 });
  } catch (error) {
    console.error('[kpay] 回調處理錯誤:', error);
    return res.status(500).json({ code: 50000, message: error.message });
  }
});

// ===== Kiosk 終端操作回調 =====
// Kiosk 模式下簽到（/v2/pos/sign）必須附 actionCallbackUrl，否則 /v2/pos/action
// 會回 700017「ActionCallback未設置」。卡機執行 action 後會回調此路徑。
// ⚠️ 官方文件只列出參數名，未載明回調格式 → 先完整記錄再按實際內容處理。
router.post('/action-callback', async (req, res) => {
  try {
    const body = req.body || {};
    // 只記錄 header 名與內容，不記錄簽名值本身
    console.log('[kpay] 收到終端操作回調:', JSON.stringify(body));
    console.log('[kpay] 回調 header 名:', Object.keys(req.headers || {}).join(', '));
    // KPay 要求回 {code:10000}，否則會重試
    return res.json({ code: 10000 });
  } catch (error) {
    console.error('[kpay] 終端操作回調處理錯誤:', error);
    return res.status(500).json({ code: 50000, message: error.message });
  }
});

// ===== 查支付狀態 =====
router.get('/status', async (req, res) => {
  try {
    const customer_id = req.query.customer_id || req.body.customer_id;
    if (!customer_id) return res.status(400).json({ error: '請提供客人ID' });

    let payment = await getKpayPaymentByCustomer(customer_id);
    if (!payment) return res.json({ success: true, status: 'none', payment: null });

    // 流程已結束 → 清走節流記錄（呢啲 map 唔應該隨交易數量無限增長）
    if (payment.status !== 'pending') {
      lastQrNudgeAt.delete(payment.out_trade_no);
      lastStatusQueryAt.delete(payment.out_trade_no);
    }

    if (payment.status === 'pending') {
      const key = payment.out_trade_no;
      const storeId = payment.store_id || 'default_store';

      // (1) 叫卡機去查交易結果 —— Kiosk 正掃嘅關鍵。
      // ⚠️ 2026-09-23 真機實測：客人付款後卡機會停留喺正掃 QR 頁等自己嘅計時器
      //   （實測付款後 30 秒仍然 payResult=1、完全冇動；無介入時三次測試都係 ~70 秒
      //   先完成）。送 POS_QR_QUERY 後 4 秒內就完成。所以要**週期性**送，
      //   唔可以等收到付款回調先送 —— 回調發出時卡機已經離開 QR 頁，必回 50002。
      // 未付款時盲送亦安全（實測回 10000、交易完好），所以 pending 期間照送。
      // best-effort：dismissQrPage 永不 throw，唔會影響 /status 嘅回應。
      if (Date.now() - (lastQrNudgeAt.get(key) || 0) >= kpayService.QR_NUDGE_INTERVAL_MS) {
        lastQrNudgeAt.set(key, Date.now());
        kpayService.dismissQrPage(storeId);
      }

      // (2) 後備：主動讀一次結果，防回調遺失（正常情況回調即時到，唔會靠呢條）。
      if (Date.now() - (lastStatusQueryAt.get(key) || 0) >= kpayService.STATUS_QUERY_INTERVAL_MS) {
        lastStatusQueryAt.set(key, Date.now());
        try {
          const qr = await kpayService.query(payment.out_trade_no, payment.store_id || 'default_store');
          const data = qr && (qr.data || qr);
          if (data && data.payResult === 2) {
            await processKpayResult(payment, {
              payResult: 2,
              payMethod: data.payMethod,
              transactionNo: data.transactionNo,
              refNo: data.refNo,
              payAmount: data.payAmount
            });
          } else if (data && data.payResult !== undefined && data.payResult !== 2) {
            await processKpayResult(payment, { payResult: data.payResult, reason: data.reason });
          }
        } catch (e) {
          console.warn('[kpay] 主動查詢失敗:', e.message);
        }
      }
    }

    const fresh = await getKpayPaymentByCustomer(customer_id);
    return res.json({ success: true, status: fresh ? fresh.status : 'none', payment: fresh });
  } catch (error) {
    console.error('[kpay] 查詢狀態錯誤:', error);
    return res.status(500).json({ error: '查詢支付狀態失敗', message: error.message });
  }
});

// ===== 取消進行中嘅支付 =====
router.post('/cancel', async (req, res) => {
  try {
    const { customer_id } = req.body;
    if (!customer_id) return res.status(400).json({ error: '請提供客人ID' });

    const payment = await getKpayPaymentByCustomer(customer_id);
    if (!payment) return res.status(404).json({ error: '沒有進行中的付款' });
    if (payment.status !== 'pending') {
      return res.json({ success: true, status: payment.status });
    }

    const storeId = payment.store_id || 'default_store';

    // 關閉「進行中未付款」嘅銷售（POST /v2/pos/sales/close，body 淨 {outTradeNo}）
    const closeRes = await kpayService.close(payment.out_trade_no, storeId).catch((e) => {
      console.error('[kpay] 關閉交易失敗:', e.message);
      return null;
    });
    if (closeRes === null) {
      // KPOS 唔到 → 唔好亂清 pending，保留待 polling 收返真實結果
      return res.status(500).json({ error: '關閉卡機交易失敗', message: 'KPOS 無回應，請稍後再試' });
    }

    // close 後補一次 query：客人可能喺 close race window 已俾咗錢
    // （close 返 20010/20017 = 已成交/已關閉 → 呢步 query 會收到 payResult 2 → 當成功結賬）
    let settled = false;
    try {
      const q = await kpayService.query(payment.out_trade_no, storeId);
      const data = q && (q.data || q);
      if (data && data.payResult === 2) {
        await processKpayResult(payment, {
          payResult: 2,
          payMethod: data.payMethod,
          transactionNo: data.transactionNo,
          refNo: data.refNo,
          payAmount: data.payAmount
        });
        settled = true;
      }
    } catch (e) {
      console.warn('[kpay] 取消後查詢確認失敗:', e.message);
    }

    if (settled) {
      return res.json({ success: true, status: 'success' });
    }
    await updateKpayPayment(payment.out_trade_no, { status: 'cancelled' });
    await clearCheckoutPending(customer_id);
    return res.json({ success: true, status: 'cancelled' });
  } catch (error) {
    console.error('[kpay] 取消支付錯誤:', error);
    return res.status(500).json({ error: '取消支付失敗', message: error.message });
  }
});

// ===== 撤銷 / 退款 =====
// 兩者互補，睇交易結算咗未：
//   void（撤銷）= 當日**未結算**嘅已成交交易 → /v2/pos/sales/cancel（要 originOutTradeNo）
//   refund（退款）= **已結算**嘅交易 → /v2/pos/sales/refund（原路返還）
// ⚠️ 卡機自己知結算咗未，我哋唔知 → 由 caller 用 mode 指定（默認 refund）。
// 管理員密碼由 .env KPAY_MANAGER_PASSWORD 提供（同其他 KPAY_* 一致，每店一份）。

// 卡類 pay_method（1 Visa / 2 Master / 3 銀聯 / 6 Amex / 7 Diners / 8 JCB）
// → 退款時 refundType=1；其餘（微信/支付寶/PayMe/FPS/八達通）refundType=2
const CARD_PAY_METHODS = new Set([1, 2, 3, 6, 7, 8]);

// 調整類交易要一個**新**嘅 outTradeNo（官方：不可重複，每筆交易都要唯一）
function newAdjustTradeNo(prefix) {
  return prefix + Date.now() + Math.random().toString(36).slice(2, 6).toUpperCase();
}

// 送完退款／撤銷請求只係「已受理」（code 10000）——卡機會彈畫面等操作員確認金額。
// 所以一定要主動 query 到 payResult=2 先算真係退咗。
// （官方亦明文要求：第三方系統必須具備主動查詢交易狀態嘅邏輯，唔可以純靠回調。）
const ADJUST_CONFIRM_TIMEOUT_MS = parseInt(process.env.KPAY_ADJUST_CONFIRM_TIMEOUT_MS || '90000', 10);
const ADJUST_POLL_INTERVAL_MS = 3000;

async function confirmAdjustment(outTradeNo, storeId) {
  const deadline = Date.now() + ADJUST_CONFIRM_TIMEOUT_MS;
  let last = null;
  while (Date.now() < deadline) {
    try {
      const qr = await kpayService.query(outTradeNo, storeId);
      const d = (qr && qr.data) || qr || {};
      last = d;
      if (d.payResult === 2) return { confirmed: true, data: d };
      // payResult 1 = 處理中，繼續等；其他 = 明確失敗
      if (d.payResult !== undefined && d.payResult !== 1) {
        return {
          confirmed: false,
          pending: false,
          reason: d.reason || `卡機回報 payResult=${d.payResult}`,
          data: d
        };
      }
    } catch (e) {
      console.warn('[kpay] 確認調整結果 query 失敗:', e.message);
    }
    await new Promise((r) => setTimeout(r, ADJUST_POLL_INTERVAL_MS));
  }
  return {
    confirmed: false,
    pending: true,
    reason: '卡機未在時限內確認（可能仍在等操作員輸入金額）',
    data: last
  };
}

router.post('/refund', async (req, res) => {
  try {
    const { out_trade_no, amount, mode } = req.body || {};
    if (!out_trade_no) return res.status(400).json({ error: '請提供 out_trade_no' });

    const payment = await getKpayPaymentByOutTradeNo(out_trade_no);
    if (!payment) return res.status(404).json({ error: '找不到該筆支付' });
    if (payment.status !== 'success') {
      return res.status(400).json({
        error: '只有成功嘅支付先可以撤銷或退款',
        current_status: payment.status
      });
    }

    const storeId = payment.store_id || 'default_store';
    const cfg = await kpayService.getConfig(storeId);
    const useVoid = String(mode || 'refund').toLowerCase() === 'void';
    const adjustNo = newAdjustTradeNo(useVoid ? 'EXV' : 'EXR');
    // 唔指定金額 = 全額退款（一定要明確送，否則卡機會叫操作員手動輸入）
    const refundedAmount = amount !== undefined && amount !== null ? Number(amount) : payment.amount;

    let result;
    if (useVoid) {
      result = await kpayService.cancelTransaction({
        outTradeNo: adjustNo,
        originOutTradeNo: payment.out_trade_no,
        callbackUrl: cfg.callback_url,
        storeId
      });
    } else {
      // refundType 由原本嘅 pay_method 推斷（卡類 1 / 二維碼 2）
      // 明確送 refundAmount（唔送 = 卡機會叫操作員手動輸入金額）
      result = await kpayService.refund({
        outTradeNo: adjustNo,
        refundType: CARD_PAY_METHODS.has(payment.pay_method) ? 1 : 2,
        transactionNo: payment.transaction_no,
        refNo: payment.ref_no,
        // 卡類退款要原交易提交時間（UTC ms）
        commitTime: payment.created_at ? new Date(payment.created_at).getTime() : undefined,
        refundAmount: refundedAmount,
        callbackUrl: cfg.callback_url,
        storeId
      });
    }

    const code = result && (result.code !== undefined ? result.code : result.data?.code);
    if (code !== 10000) {
      console.warn(`[kpay] ${useVoid ? '撤銷' : '退款'}失敗 (code=${code}):`, result && result.message);
      return res.status(500).json({
        error: useVoid ? '撤銷失敗' : '退款失敗',
        kpay_code: code,
        message: (result && result.message) || 'KPOS 拒絕'
      });
    }

    // 記低調整單號，方便之後再確認（10000 只係「已受理」）
    await updateKpayPayment(payment.out_trade_no, { refund_out_trade_no: adjustNo });

    // ⚠️ 一定要 query 到 payResult=2 先算真係退咗；否則操作員可能喺卡機上取消咗
    // mock 模式冇真卡機、query 唔會返 payResult → 直接當成功（mock 本身就係模擬，冇嘢可確認）
    const confirm = cfg.mode === 'mock'
      ? { confirmed: true, mock: true }
      : await confirmAdjustment(adjustNo, storeId);
    if (!confirm.confirmed) {
      console.warn(`[kpay] ${useVoid ? '撤銷' : '退款'}未確認 (${adjustNo}): ${confirm.reason}`);
      return res.json({
        success: false,
        mode: useVoid ? 'void' : 'refund',
        status: confirm.pending ? 'pending_confirmation' : 'failed',
        adjust_out_trade_no: adjustNo,
        original_out_trade_no: payment.out_trade_no,
        message: confirm.reason
        // 未確認 → 唔標記 refunded，原支付維持 'success'，等之後可以再確認或重試
      });
    }

    // kpay_payments 標記已退款（防止重複退款：上面 status !== 'success' 會擋）
    await updateKpayPayment(payment.out_trade_no, { status: 'refunded' });

    // 交易紀錄插一筆負數（同 checkout 對沖）
    db.run(
      `INSERT INTO transactions (id, customer_id, transaction_type, amount, description, payment_method, store_id)
       VALUES (?, ?, 'refund', ?, ?, ?, ?)`,
      [
        uuidv4(),
        payment.customer_id,
        -Math.abs(refundedAmount),
        `${useVoid ? '撤銷' : '退款'}(KPay ${payment.out_trade_no}) 原單 $${payment.amount}`,
        mapPayMethod(payment.pay_method),
        storeId
      ],
      (err) => { if (err) console.error('[kpay] 添加退款紀錄錯誤:', err); }
    );

    console.log(
      `[kpay] ${useVoid ? '撤銷' : '退款'}成功: 原單=${payment.out_trade_no} ` +
      `新單=${adjustNo} 金額=$${refundedAmount}`
    );
    return res.json({
      success: true,
      mode: useVoid ? 'void' : 'refund',
      adjust_out_trade_no: adjustNo,
      original_out_trade_no: payment.out_trade_no,
      amount: refundedAmount
    });
  } catch (error) {
    console.error('[kpay] 撤銷／退款錯誤:', error);
    return res.status(500).json({ error: '撤銷／退款失敗', message: error.message });
  }
});

// ===== 其餘 KPay API（薄層轉發）=====
// 呢啲 API 唔涉及本地結賬邏輯，只係將請求轉去 KPOS 並回傳結果。
// ⚠️ 一定要放喺**最後** —— Express 按定義順序匹配，上面嘅具體 route
//    （/pay /callback /status /cancel /refund）必須先匹配到。
const PASSTHROUGH_POST = {
  settlement: 'settlement',
  print: 'print',
  action: 'action',
  'tip-adjustment': 'tipAdjustment',
  'tip-adjustment-cancel': 'tipAdjustmentCancel',
  'offline-sales': 'offlineSales',
  'offline-sales-cancel': 'offlineSalesCancel',
  preauth: 'preauth',
  'preauth-adjustment': 'preauthAdjustment',
  'preauth-cancel': 'preauthCancel',
  'preauth-complete': 'preauthComplete',
  'preauth-complete-cancel': 'preauthCompleteCancel'
};
const PASSTHROUGH_GET = {
  'query-settlement': 'querySettlement',
  'terminal-status': 'terminalStatus'
};

// terminal-status 回嘅係**終端狀態碼**（唔係錯誤碼），要當成功回傳畀 caller 判斷。
// 官方狀態表見 references/index.md「終端狀態示例」。
const TERMINAL_STATUS_TEXT = {
  91000: '終端正常（在首頁）',
  91001: '終端未簽到',
  91002: '終端簽到中',
  91003: '終端網絡不可用',
  91004: '末筆交易失敗，需要查詢交易結果',
  91005: '末筆交易失敗，需要沖正',
  91006: '末筆交易撤銷失敗，需要重試',
  91007: '末筆交易小票未完成打印',
  91008: '小票打印失敗，請檢查打印機',
  91009: '終端應用需要升級',
  91010: '終端需要簽退、重新簽到',
  91011: '終端剩餘空間不足',
  91012: '交易處理中',
  91013: '交易沖正中',
  91014: '交易結果查詢中',
  91015: '交易結果待查詢',
  50002: '終端繁忙（KPay 不在首頁）'
};

function makePassthrough(map) {
  return async (req, res) => {
    const fnName = map[req.params.op];
    if (!fnName) {
      return res.status(404).json({ error: '不支援的操作', operation: req.params.op });
    }
    try {
      const src = req.method === 'GET' ? req.query : (req.body || {});
      const storeId = req.storeContext?.store_id || src.store_id || 'default_store';
      const args = { ...src, storeId };
      delete args.store_id;

      const result = await kpayService[fnName](args);
      const code = result && (result.code !== undefined ? result.code : result.data?.code);

      // 查終端狀態：任何狀態碼都係有效結果，唔係錯誤
      if (req.params.op === 'terminal-status') {
        return res.json({
          success: true,
          operation: 'terminal-status',
          kpay_code: code,
          status: TERMINAL_STATUS_TEXT[code] || '未知狀態',
          message: (result && result.message) || ''
        });
      }

      // 查結算數據：50012「結算數據為空」係正常狀態（未結算／批次已查過），唔係錯誤。
      // 真機實測：結算完再查會回 50012，回 500 會誤導呼叫方以為系統故障。
      if (req.params.op === 'query-settlement' && code === 50012) {
        return res.json({
          success: true,
          operation: 'query-settlement',
          kpay_code: code,
          message: (result && result.message) || '結算數據為空',
          data: []
        });
      }

      if (code !== undefined && code !== 10000 && code !== 11000) {
        console.warn(`[kpay] ${req.params.op} 失敗 (code=${code}):`, result && result.message);
        return res.status(500).json({
          error: 'KPOS 拒絕',
          operation: req.params.op,
          kpay_code: code,
          message: (result && result.message) || '',
          data: result && result.data
        });
      }
      // 結算成功後工作密鑰已清 cache，前端／排程可據此知道要重新簽到
      return res.json({
        success: true,
        operation: req.params.op,
        kpay_code: code,
        data: result && result.data
      });
    } catch (error) {
      console.error(`[kpay] ${req.params.op} 錯誤:`, error);
      return res.status(500).json({
        error: '操作失敗',
        operation: req.params.op,
        message: error.message
      });
    }
  };
}

router.post('/:op', makePassthrough(PASSTHROUGH_POST));
router.get('/:op', makePassthrough(PASSTHROUGH_GET));

// ===== 初始化（由 server/index.js 喺 app.set('io') 後調用）=====
// 註冊 mock 回調 handler：mock 模式 sales() 3 秒後觸發，行同一 idempotent 邏輯
function init(io) {
  ioInstance = io;
  kpayService.setMockCallbackHandler(async (payload) => {
    const outTradeNo = payload.outTradeNO;
    const payment = await getKpayPaymentByOutTradeNo(outTradeNo);
    if (!payment || payment.status !== 'pending') return;
    await processKpayResult(payment, payload);
  });
}

router.init = init;
module.exports = router;
