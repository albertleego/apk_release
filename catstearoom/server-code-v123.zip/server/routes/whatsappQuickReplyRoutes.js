// ─────────────────────────────────────────────────────────────
// WhatsApp — 快捷回覆（罐頭訊息）
//
// 掛喺 /api/whatsapp/admin/quick-replies（見 server/index.js）。
//
// 權限設計（重要）：
//   讀 = 所有登入者（包括 officer）—— officer 要用快捷回覆係日常操作
//   寫 = 只有商家本人 —— 改罐頭訊息內容屬「設定」
//   ⚠️ officer 角色喺 Phase 3 引入；引入之前兩者等同，但端點已經分好，
//      到時唔使返轉頭改。
//
// 純文字快捷回覆完全唔涉及 Meta API —— 只係插入輸入框嘅文字，
// 唔會自動送出，所以唔需要審批、亦唔受 24 小時窗口限制。
//
// 媒體附件（ENABLE_WHATSAPP_QUICK_REPLY_MEDIA）係例外：附件要經 Meta 發送，
// 所以會用到 Graph API。上傳本身只寫本地磁碟。
// ─────────────────────────────────────────────────────────────
'use strict';

const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const { db } = require('../../database/db');
const runtime = require('../config/runtime');
const merchantAuth = require('../middleware/merchantAuth');
const media = require('../services/whatsappQuickReplyMedia');

const router = express.Router();

const getStoreId = () => process.env.WHATSAPP_STORE_ID || 'store_1';
const mediaEnabled = () => runtime.whatsappQuickReplyMedia();

const SHORTCUT_MAX = 40;
const BODY_MAX = 2000;
// ⚠️ Meta 對「媒體訊息」嘅 caption 上限係 1024 字，而純文字訊息係 4096。
//    帶附件時超過 1024 會被 Meta 直接拒絕，所以喺呢度就要擋。
const CAPTION_MAX_WITH_MEDIA = 1024;

// ── sqlite3 callback → Promise（跟 merchantChatRoutes.js 既有慣例）──
function dbRun(sql, params) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function (err) {
            if (err) return reject(err);
            resolve({ changes: this.changes });
        });
    });
}
function dbGet(sql, params) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => (err ? reject(err) : resolve(row)));
    });
}
function dbAll(sql, params) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => (err ? reject(err) : resolve(rows || [])));
    });
}

function fail(res, status, error) {
    return res.status(status).json({ success: false, error });
}

// ⚠️ requireMerchant 同 resolveActor 已經喺 server/index.js 嘅資料夾層掛咗，
//    呢度再掛係防禦性冗餘（requireMerchant 冪等）。
router.use(merchantAuth.requireMerchant);
router.use(merchantAuth.resolveActor);
router.use(merchantAuth.requireSameOrigin);

/** 驗證輸入。回 null = 通過，否則回錯誤訊息。 */
function validateInput({ shortcut, body, hasMedia }) {
    const s = String(shortcut || '').trim();
    const b = String(body || '').trim();
    if (!s) return '請輸入快捷回覆的名稱';
    if (s.length > SHORTCUT_MAX) return `名稱過長（上限 ${SHORTCUT_MAX} 字）`;
    if (!b) return '請輸入快捷回覆的內容';
    if (b.length > BODY_MAX) return `內容過長（上限 ${BODY_MAX} 字）`;
    if (hasMedia && b.length > CAPTION_MAX_WITH_MEDIA) {
        return `附有附件時，內容上限為 ${CAPTION_MAX_WITH_MEDIA} 字（目前 ${b.length} 字）`;
    }
    return null;
}

// ─────────────────────────────────────────────────────────────
// 媒體附件（只喺 flag 開啟時存在；冇開回 404，唔會影響純文字功能）
//
// ⚠️ 路由順序：媒體路由一定要排喺 /:id 系列之前。
// ─────────────────────────────────────────────────────────────

/** 上傳附件：base64 JSON（沿用收銀機 logo 嘅既有做法，零新依賴） */
router.post('/media', merchantAuth.requireAdminActor, async (req, res) => {
    try {
        if (!mediaEnabled()) return fail(res, 404, '附件功能未開啟');
        const b = req.body || {};
        const out = await media.saveMedia({
            storeId: getStoreId(),
            mime: b.mime,
            filename: b.filename,
            base64: b.data,
            employeeId: (req.merchant && req.merchant.employee_id) || null,
        });
        res.json({ success: true, media: out });
    } catch (e) {
        // definitelyNotSent = 輸入問題（格式、大小、配額），回明確原因
        if (e && e.definitelyNotSent) {
            const status = /過大/.test(e.message) ? 413 : 400;
            return fail(res, status, e.message);
        }
        console.error('[whatsapp] 上傳附件失敗:', e.message);
        fail(res, 500, '上傳失敗，請稍後再試');
    }
});

/** 讀取附件（租戶隔離；**唔可以掛 static**） */
router.get('/media/:mediaId', async (req, res) => {
    try {
        if (!mediaEnabled()) return fail(res, 404, '附件功能未開啟');

        const row = await media.getMedia(req.params.mediaId, getStoreId());
        if (!row) return fail(res, 404, '找不到附件');

        const full = media.absolutePath(row);
        if (!full) return fail(res, 404, '找不到附件');

        // 檔案缺失（被手動刪、磁碟還原等）要回 404，**絕不可 500** ——
        // 前端有 onerror 兜底，但 500 會令畫面出現未預期錯誤。
        let st;
        try { st = fs.statSync(full); } catch (_) { return fail(res, 404, '找不到附件'); }
        if (!st.isFile()) return fail(res, 404, '找不到附件');

        res.set('Content-Type', row.mime);
        // 我哋由自己嘅 origin 提供商家上傳嘅內容，冇 nosniff 就有 stored-XSS 風險
        res.set('X-Content-Type-Options', 'nosniff');
        res.set('Cache-Control', 'private, max-age=300');
        const safeName = String(row.filename || 'file').replace(/[^\w.\-一-龥]/g, '_');
        res.set('Content-Disposition', `inline; filename="${safeName}"`);

        const stream = fs.createReadStream(full);
        stream.on('error', () => {
            if (!res.headersSent) fail(res, 404, '找不到附件');
            else res.destroy();
        });
        stream.pipe(res);
    } catch (e) {
        console.error('[whatsapp] 讀取附件失敗:', e.message);
        if (!res.headersSent) fail(res, 500, '讀取附件失敗');
    }
});

// ─────────────────────────────────────────────────────────────
// GET / —— 列出（所有登入者都可以讀，officer 靠呢個用快捷回覆）
// ─────────────────────────────────────────────────────────────
router.get('/', async (req, res) => {
    try {
        const rows = await dbAll(
            `SELECT q.id, q.shortcut, q.body, q.sort_order,
                    m.id AS media_id, m.kind AS media_kind, m.mime AS media_mime,
                    m.filename AS media_filename, m.size_bytes AS media_size
               FROM wa_quick_replies q
               LEFT JOIN wa_quick_reply_media m
                      ON m.quick_reply_id = q.id AND m.store_id = q.store_id
              WHERE q.store_id = ? ORDER BY q.sort_order ASC, q.created_at ASC`,
            [getStoreId()]
        );
        const on = mediaEnabled();
        res.json({
            success: true,
            // 只有 admin 可以改快捷回覆。「商家」只係第一道閘，唔係身分。
            canManage: Boolean(req.actor && req.actor.role === 'admin'),
            mediaEnabled: on,
            captionMaxWithMedia: CAPTION_MAX_WITH_MEDIA,
            quickReplies: rows.map((r) => ({
                id: r.id,
                shortcut: r.shortcut,
                body: r.body,
                sortOrder: r.sort_order,
                media: (on && r.media_id) ? {
                    id: r.media_id,
                    kind: r.media_kind,
                    mime: r.media_mime,
                    filename: r.media_filename || '',
                    size: r.media_size || 0,
                } : null,
            })),
        });
    } catch (e) {
        console.error('[whatsapp] 讀取快捷回覆失敗:', e.message);
        fail(res, 500, '讀取快捷回覆失敗');
    }
});

// ─────────────────────────────────────────────────────────────
// POST / —— 新增（只有商家本人）
// ─────────────────────────────────────────────────────────────
router.post('/', merchantAuth.requireAdminActor, async (req, res) => {
    try {
        const shortcut = String((req.body && req.body.shortcut) || '').trim();
        const body = String((req.body && req.body.body) || '').trim();
        const mediaId = (req.body && req.body.mediaId) || null;

        if (mediaId && !mediaEnabled()) return fail(res, 400, '附件功能未開啟');

        // 有指定附件就要確認佢存在、屬同一個 store、而且未被其他快捷回覆佔用
        let pending = null;
        if (mediaId) {
            pending = await media.getMedia(mediaId, getStoreId());
            if (!pending) return fail(res, 400, '附件不存在，請重新上傳');
            if (pending.quick_reply_id) return fail(res, 400, '這個附件已被其他快捷回覆使用');
        }

        const err = validateInput({ shortcut, body, hasMedia: Boolean(mediaId) });
        if (err) return fail(res, 400, err);

        const last = await dbGet(
            `SELECT MAX(sort_order) AS m FROM wa_quick_replies WHERE store_id = ?`,
            [getStoreId()]
        );
        const sortOrder = ((last && last.m) || 0) + 1;

        const id = crypto.randomUUID();
        const nowIso = new Date().toISOString();
        await dbRun(
            `INSERT INTO wa_quick_replies
               (id, store_id, shortcut, body, sort_order, created_by_employee_id, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [id, getStoreId(), shortcut, body, sortOrder,
                (req.merchant && req.merchant.employee_id) || null, nowIso, nowIso]
        );

        if (pending) await media.bindToQuickReply(pending.id, id, getStoreId());

        res.json({ success: true, quickReply: { id, shortcut, body, sortOrder } });
    } catch (e) {
        console.error('[whatsapp] 新增快捷回覆失敗:', e.message);
        fail(res, 500, '新增快捷回覆失敗');
    }
});

// ─────────────────────────────────────────────────────────────
// PUT /:id —— 修改（只有商家本人）
// ─────────────────────────────────────────────────────────────
router.put('/:id', merchantAuth.requireAdminActor, async (req, res) => {
    try {
        const shortcut = String((req.body && req.body.shortcut) || '').trim();
        const body = String((req.body && req.body.body) || '').trim();
        const hasMediaField = req.body && Object.prototype.hasOwnProperty.call(req.body, 'mediaId');
        const newMediaId = hasMediaField ? (req.body.mediaId || null) : undefined;

        // ⚠️ 一定要同時比對 store_id，唔可以只用 id
        const existing = await dbGet(
            `SELECT id FROM wa_quick_replies WHERE id = ? AND store_id = ?`,
            [req.params.id, getStoreId()]
        );
        if (!existing) return fail(res, 404, '找不到這個快捷回覆');

        if (newMediaId && !mediaEnabled()) return fail(res, 400, '附件功能未開啟');

        // 目前綁住嘅附件
        const current = await dbGet(
            `SELECT * FROM wa_quick_reply_media WHERE quick_reply_id = ? AND store_id = ?`,
            [req.params.id, getStoreId()]
        );

        // 決定最終附件
        let targetMediaId = current ? current.id : null;
        let pending = null;
        if (hasMediaField) {
            if (newMediaId === null) {
                targetMediaId = null;
            } else if (!current || current.id !== newMediaId) {
                pending = await media.getMedia(newMediaId, getStoreId());
                if (!pending) return fail(res, 400, '附件不存在，請重新上傳');
                if (pending.quick_reply_id) return fail(res, 400, '這個附件已被其他快捷回覆使用');
                targetMediaId = pending.id;
            }
            // ⚠️ newMediaId === current.id 時乜都唔做 —— 否則會自我刪除
        }

        const err = validateInput({ shortcut, body, hasMedia: Boolean(targetMediaId) });
        if (err) return fail(res, 400, err);

        await dbRun(
            `UPDATE wa_quick_replies SET shortcut = ?, body = ?, updated_at = ?
              WHERE id = ? AND store_id = ?`,
            [shortcut, body, new Date().toISOString(), req.params.id, getStoreId()]
        );

        if (pending) await media.bindToQuickReply(pending.id, req.params.id, getStoreId());

        // 換咗附件或者清空 → 刪走舊嗰個
        if (current && current.id !== targetMediaId) {
            await media.deleteMediaById(current.id, getStoreId());
        }

        res.json({ success: true });
    } catch (e) {
        console.error('[whatsapp] 修改快捷回覆失敗:', e.message);
        fail(res, 500, '修改快捷回覆失敗');
    }
});

// ─────────────────────────────────────────────────────────────
// DELETE /:id —— 刪除（只有商家本人）
// ─────────────────────────────────────────────────────────────
router.delete('/:id', merchantAuth.requireAdminActor, async (req, res) => {
    try {
        const storeId = getStoreId();
        const existing = await dbGet(
            `SELECT id FROM wa_quick_replies WHERE id = ? AND store_id = ?`,
            [req.params.id, storeId]
        );
        if (!existing) return fail(res, 404, '找不到這個快捷回覆');

        const out = await dbRun(
            `DELETE FROM wa_quick_replies WHERE id = ? AND store_id = ?`,
            [req.params.id, storeId]
        );
        if (!out.changes) return fail(res, 404, '找不到這個快捷回覆');

        // 連帶刪除附件（檔案 + 列）。失敗唔應該令整個刪除失敗 ——
        // 就算漏咗，孤兒清理排程都會收尾。
        const m = await dbGet(
            `SELECT id FROM wa_quick_reply_media WHERE quick_reply_id = ? AND store_id = ?`,
            [req.params.id, storeId]
        );
        if (m) {
            try { await media.deleteMediaById(m.id, storeId); }
            catch (err) { console.warn('[whatsapp] 刪除附件失敗（孤兒清理會收尾）:', err.message); }
        }

        res.json({ success: true });
    } catch (e) {
        console.error('[whatsapp] 刪除快捷回覆失敗:', e.message);
        fail(res, 500, '刪除快捷回覆失敗');
    }
});

module.exports = router;
