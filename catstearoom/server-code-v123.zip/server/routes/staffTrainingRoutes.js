const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');
const quiz = require('../config/staffTrainingQuiz');

// 職位同時就係題庫軌別：FT=全職 24 題 / PT=兼職 15 題
const VALID_ROLES = ['FT', 'PT'];

/**
 * @route GET /api/staff-training/quiz
 * @desc 取得指定軌別嘅測驗題目（不含答案）+ 及格門檻
 * @query track - FT（預設）| PT
 * @access Public（店舖平板／員工手機直接開，唔使登入）
 */
router.get('/quiz', (req, res) => {
    const requested = String(req.query.track || '').trim().toUpperCase();
    if (requested && !quiz.isValidTrack(requested)) {
        return res.status(400).json({
            success: false,
            message: '職位不正確，只可以是 FT 或 PT'
        });
    }

    const track = requested || quiz.DEFAULT_TRACK;
    const questions = quiz.publicQuestions(track);

    res.json({
        success: true,
        track: track,
        title: quiz.TRACKS[track].title,
        passPercentage: quiz.passPercentageFor(track),
        totalQuestions: questions.length,
        questions: questions
    });
});

/**
 * @route POST /api/staff-training/submit
 * @desc 提交作答 → 伺服器端評分 → 寫入成績
 * @body { employeeName, role (FT|PT), storeId?, responses: { [題號]: number[] }, durationSeconds? }
 * @access Public
 *
 * 評分刻意放喺伺服器端：正確答案唔會出現喺網頁原始碼，
 * 員工無法用「檢視原始碼」直接抄答案。
 * role 決定用邊條軌嘅題庫同及格標準。
 */
router.post('/submit', (req, res) => {
    const { employeeName, role, storeId, responses, durationSeconds } = req.body || {};

    const name = typeof employeeName === 'string' ? employeeName.trim() : '';
    if (!name) {
        return res.status(400).json({ success: false, message: '請填寫姓名' });
    }
    if (name.length > 50) {
        return res.status(400).json({ success: false, message: '姓名過長' });
    }
    if (!VALID_ROLES.includes(role)) {
        return res.status(400).json({ success: false, message: '請選擇職位（FT 或 PT）' });
    }
    if (!responses || typeof responses !== 'object' || Array.isArray(responses)) {
        return res.status(400).json({ success: false, message: '作答內容格式不正確' });
    }

    // 題號必須落喺該軌嘅範圍內。唔擋嘅話，前端題號同軌別唔一致時
    // （例如 FT 嘅 1-24 送去 PT 軌）會靜靜咁用錯答案評分。
    const questionCount = quiz.questionsFor(role).length;
    const outOfRange = Object.keys(responses).filter(function (k) {
        const n = Number(k);
        return !Number.isInteger(n) || n < 1 || n > questionCount;
    });
    if (outOfRange.length) {
        return res.status(400).json({
            success: false,
            message: '作答題號與職位不符，請重新整理頁面後再試'
        });
    }

    // 未作答的題目當作空集合（會計為答錯）
    const result = quiz.grade(role, responses);

    const duration = Number.isFinite(Number(durationSeconds)) && Number(durationSeconds) >= 0
        ? Math.round(Number(durationSeconds))
        : null;

    const id = uuidv4();
    const wrongJson = JSON.stringify(result.wrongQuestionIds);

    db.run(
        `INSERT INTO staff_training_records
         (id, employee_name, role, store_id, correct_count, total_count, percentage, passed,
          wrong_question_ids, duration_seconds, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now', '+8 hours'))`,
        [
            id,
            name,
            role,
            storeId || null,
            result.correct,
            result.total,
            result.percentage,
            result.passed ? 1 : 0,
            wrongJson,
            duration
        ],
        function (err) {
            if (err) {
                console.error('寫入員工考核成績錯誤:', err);
                return res.status(500).json({ success: false, message: '成績儲存失敗，請稍後再試' });
            }

            res.json({
                success: true,
                recordId: id,
                employeeName: name,
                role: role,
                correct: result.correct,
                total: result.total,
                percentage: result.percentage,
                passed: result.passed,
                passPercentage: quiz.passPercentageFor(role),
                // 只回傳答錯嘅卷面題號，唔回傳正確答案（避免單次提交就套到全部答案）
                wrongQuestionIds: result.wrongQuestionIds
            });
        }
    );
});

/**
 * @route GET /api/staff-training/records
 * @desc 查詢考核成績紀錄（後台）
 * @access Private/Admin
 */
router.get('/records', authMiddleware.authenticate, authMiddleware.requireAdmin, (req, res) => {
    const { role, passed, limit } = req.query;

    let query = `SELECT id, employee_name, role, store_id, correct_count, total_count,
                        percentage, passed, wrong_question_ids, duration_seconds, created_at
                 FROM staff_training_records WHERE 1=1`;
    const params = [];

    if (role) {
        query += ' AND role = ?';
        params.push(role);
    }
    if (passed !== undefined) {
        query += ' AND passed = ?';
        params.push(passed === 'true' ? 1 : 0);
    }

    const rowLimit = Math.min(Math.max(parseInt(limit, 10) || 200, 1), 1000);
    query += ' ORDER BY created_at DESC LIMIT ?';
    params.push(rowLimit);

    db.all(query, params, (err, rows) => {
        if (err) {
            console.error('查詢員工考核紀錄錯誤:', err);
            return res.status(500).json({ success: false, message: '伺服器錯誤' });
        }

        const records = (rows || []).map(function (r) {
            let wrongQuestionIds = [];
            try {
                wrongQuestionIds = JSON.parse(r.wrong_question_ids || '[]');
            } catch (e) {
                wrongQuestionIds = [];
            }
            return Object.assign({}, r, {
                passed: r.passed === 1,
                wrongQuestionIds: wrongQuestionIds
            });
        });

        res.json({ success: true, count: records.length, records: records });
    });
});

module.exports = router;
