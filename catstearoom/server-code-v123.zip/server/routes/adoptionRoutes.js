// ─────────────────────────────────────────────────────────────
// 領養申請 —— 公開提交 + 審核後台 API
//
// 掛喺 /api/adoption（見 server/index.js）。
//
// 權限設計：
//   POST /submit               = 公開（客人填表）
//   /admin/*                   = 需要職員身分（admin 或 officer）
//                                ⚠️ 真正嘅權限判斷係 requireActor，
//                                   merchantGate 只係大門。
//
// 公開端點為什麼都要掛 requireSameOrigin：
//   呢個 router 掛喺 /api 之下，冇 cookie 認證都會開放。
//   加上同源檢查可以擋走由其他網站代填嘅請求（成本極低）。
//   ⚠️ 表單頁喺 catstearoom.com，經 nginx proxy 打呢個 API ——
//      對瀏覽器而言係 same-origin，所以唔會被誤擋。
//
// 相片走 base64 JSON（與 whatsappQuickReplyRoutes 一致，零新依賴）。
// ─────────────────────────────────────────────────────────────
'use strict';

const express = require('express');
const crypto = require('crypto');
const path = require('path');
const { execFile } = require('child_process');
const { db } = require('../../database/db');
const merchantAuth = require('../middleware/merchantAuth');
const adoptionMedia = require('../services/adoptionMedia');
const adoptionPublish = require('../services/adoptionPublish');
const adoptionMail = require('../services/adoptionMail');
const catStatus = require('../services/catStatus');

const router = express.Router();

// 欄位長度上限（公開端點，一定要設）
const MAX = {
    cat_name: 60,
    cat_gender: 10,
    cat_age: 30,
    cat_intro: 1000,
    adoption_requirement: 1000,
    fee_amount: 100,
    fee_note: 200,
    contact_method: 120,
    submitter_role: 10,
    submitter_name: 60,
};
const MAX_PHOTO_B64 = 8 * 1024 * 1024; // 與 nginx client_max_body_size 對齊

router.use(merchantAuth.resolveActor);
router.use(merchantAuth.requireSameOrigin);

// ── 小工具 ───────────────────────────────────────────────────

function bad(res, msg, code) {
    return res.status(400).json({ success: false, code: code || 'INVALID', error: msg });
}

/** 取出並修剪字串欄位，同時檢查長度 */
function pick(body, key, { required } = {}) {
    const v = String((body && body[key]) || '').trim();
    if (required && !v) return { error: `請填寫${key}` };
    if (v.length > MAX[key]) return { error: `欄位過長（上限 ${MAX[key]} 字）` };
    return { value: v };
}

function getSubmission(id) {
    return new Promise((resolve, reject) => {
        db.get('SELECT * FROM adoption_submissions WHERE id = ?', [id],
            (err, row) => (err ? reject(err) : resolve(row || null)));
    });
}

function touch(id) {
    return new Promise((resolve, reject) => {
        db.run('UPDATE adoption_submissions SET updated_at = CURRENT_TIMESTAMP WHERE id = ?',
            [id], (err) => (err ? reject(err) : resolve()));
    });
}

// ── 公開：提交申請 ───────────────────────────────────────────

router.post('/submit', async (req, res) => {
    try {
        const b = req.body || {};

        const fields = {};
        for (const key of ['cat_name', 'cat_gender', 'cat_age', 'cat_intro',
            'adoption_requirement', 'contact_method',
            'submitter_role', 'submitter_name']) {
            const r = pick(b, key, { required: ['cat_name', 'adoption_requirement', 'contact_method'].includes(key) });
            if (r.error) return bad(res, r.error);
            fields[key] = r.value;
        }
        const fee = pick(b, 'fee_amount');
        if (fee.error) return bad(res, fee.error);
        const feeNote = pick(b, 'fee_note');
        if (feeNote.error) return bad(res, feeNote.error);

        const feeRequired = (b.fee_required === true || b.fee_required === 'true' || b.fee_required === 1) ? 1 : 0;
        if (feeRequired && !fee.value) return bad(res, '請填寫領養費數額');

        const photo = String(b.photo_base64 || '');
        if (!photo) return bad(res, '請上傳貓貓相片');
        if (photo.length > MAX_PHOTO_B64) return bad(res, '相片過大，請重新上傳');

        const id = crypto.randomUUID();

        // 先存相片再寫 DB —— 若相片有問題就唔會留低一筆冇相嘅申請
        let photoFile;
        try {
            photoFile = await adoptionMedia.savePhoto({
                base64: photo,
                mime: b.photo_mime,
                fileBase: id,
            });
        } catch (err) {
            if (err.userFacing) return bad(res, err.message, 'PHOTO');
            throw err;
        }

        const row = {
            ...fields,
            fee_required: feeRequired,
            fee_amount: feeRequired ? fee.value : '',
            fee_note: feeRequired ? feeNote.value : '',
        };
        // 先產生一次 body_html 方便後台直接預覽（審核時可再改）
        const bodyHtml = adoptionPublish.buildBodyHtml(row);

        await new Promise((resolve, reject) => {
            db.run(
                `INSERT INTO adoption_submissions
                   (id, status, photo_file, cat_name, cat_gender, cat_age, cat_intro,
                    adoption_requirement, fee_required, fee_amount, fee_note,
                    contact_method, submitter_role, submitter_name, body_html)
                 VALUES (?, 'pending', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [id, photoFile, fields.cat_name, fields.cat_gender, fields.cat_age,
                    fields.cat_intro, fields.adoption_requirement, feeRequired,
                    row.fee_amount, row.fee_note, fields.contact_method,
                    fields.submitter_role, fields.submitter_name, bodyHtml],
                (err) => (err ? reject(err) : resolve())
            );
        });

        // ⚠️ 通知信失敗唔可以令提交失敗 —— 客人已經填完，唔應該叫佢再填一次
        adoptionMail.notifyNewSubmission(row).catch((err) => {
            console.error('領養申請通知信發送失敗:', err.message);
        });

        res.json({ success: true, id });
    } catch (err) {
        console.error('領養申請提交錯誤:', err);
        res.status(500).json({ success: false, error: '系統錯誤，請稍後再試' });
    }
});

// ── 後台：需要職員身分 ───────────────────────────────────────

router.use('/admin', merchantAuth.requireActor);

/**
 * 後台：列出領養頁上所有貓貓（靜態兩份 + 已刊登的），連同目前狀態。
 * 狀態的唯一來源是 catstearoom-data/cat-status.json（見 services/catStatus.js）。
 */
router.get('/admin/cats', async (req, res) => {
    try {
        res.json({ success: true, cats: await catStatus.listAll() });
    } catch (err) {
        console.error('讀取貓貓清單錯誤:', err);
        res.status(500).json({ success: false, error: '讀取失敗' });
    }
});

/**
 * 後台：設定某隻貓的「已領養」／「隱藏」。
 * body: { key: "cats:31", adopted?: true|false, hidden?: true|false }
 *   adopted = true  → 領養頁在名字下加小紅字「(已領養)」
 *   hidden  = true  → 領養頁不再顯示這隻貓（後台仍列出，可用「恢復」還原）
 * 只傳其中一項時，另一項維持不變。
 */
router.post('/admin/cats/status', (req, res) => {
    try {
        const b = req.body || {};
        const entry = catStatus.setStatus(b.key, {
            adopted: b.adopted === undefined ? undefined : !!b.adopted,
            hidden: b.hidden === undefined ? undefined : !!b.hidden,
        });
        res.json({ success: true, entry });
    } catch (err) {
        if (err.userFacing) return bad(res, err.message);
        console.error('設定貓貓狀態錯誤:', err);
        res.status(500).json({ success: false, error: '設定失敗' });
    }
});

/**
 * 後台：把某隻貓的相片存到 Google Drive 的「己領養」資料夾。
 * body: { key: "cats:119" }
 *
 * 用一支 Python 輔助程式做上傳（scripts/upload-adopted-photo.py）——
 * 它沿用專案已有的 Google 認證，與 cron 下載 Drive 檔案同一套。
 * 見該檔檔頭：不能用 service account，它沒有儲存配額。
 */
const ARCHIVE_SCRIPT = path.join(__dirname, '..', '..', 'scripts', 'upload-adopted-photo.py');

function runArchiveScript(filePath, driveName) {
    return new Promise((resolve) => {
        execFile(process.env.PYTHON_BIN || 'python3',
            [ARCHIVE_SCRIPT, '--file', filePath, '--name', driveName],
            { timeout: 120000, maxBuffer: 1024 * 1024 },
            (err, stdout) => {
                if (err && !stdout) {
                    return resolve({ ok: false, error: '無法執行上傳程式: ' + err.message });
                }
                // 輔助程式只輸出一行 JSON（失敗也用 exit 0，靠 ok 判斷）
                const line = String(stdout || '').trim().split('\n').pop();
                try {
                    resolve(JSON.parse(line));
                } catch (e) {
                    resolve({ ok: false, error: '上傳程式回傳無法解析: ' + line.slice(0, 120) });
                }
            });
    });
}

router.post('/admin/cats/archive-photo', async (req, res) => {
    try {
        const key = String((req.body || {}).key || '');
        const info = await catStatus.photoFor(key);
        if (!info) return bad(res, '找不到這隻貓的相片');

        const all = await catStatus.listAll();
        const cat = all.find((c) => c.key === key);
        // 檔名：編號 + 名字（站主指定），例如「119 拉拉 女 10個月.jpeg」
        const ext = path.extname(info.filePath) || '.jpeg';
        const driveName = `${key.split(':')[1]} ${cat ? cat.name : ''}`.trim() + ext;

        const out = await runArchiveScript(info.filePath, driveName);
        if (!out.ok) return bad(res, out.error || '存到 Google Drive 失敗');
        res.json({ success: true, name: out.name, action: out.action });
    } catch (err) {
        console.error('存相片到 Google Drive 錯誤:', err);
        res.status(500).json({ success: false, error: '存檔失敗' });
    }
});

router.get('/admin/list', (req, res) => {
    const status = String(req.query.status || '').trim();
    const where = ['pending', 'approved', 'rejected'].includes(status)
        ? 'WHERE status = ?' : '';
    const params = where ? [status] : [];

    db.all(
        `SELECT id, status, cat_no, cat_name, cat_gender, cat_age, contact_method,
                submitter_role, submitter_name,
                fee_required, fee_amount, fee_note, photo_file, created_at, updated_at
           FROM adoption_submissions ${where}
          ORDER BY CASE status WHEN 'pending' THEN 0 ELSE 1 END, created_at DESC`,
        params,
        (err, rows) => {
            if (err) {
                console.error('讀取領養申請失敗:', err);
                return res.status(500).json({ success: false, error: '讀取失敗' });
            }
            res.json({ success: true, submissions: rows || [] });
        }
    );
});

/**
 * 讀取申請的相片（**只給後台用**）。
 *
 * ⚠️ 為什麼需要這條路由：
 *    對外網站（catstearoom.com）的相片是經 nginx 的
 *    `location ^~ /assets/img/cats-live/` alias 提供 —— 那條規則只在
 *    catstearoom.com 的 server block 內。
 *    但後台在 catstearoom.dev，它的 nginx 把所有請求 proxy 去本服務，
 *    所以 /assets/img/cats-live/... 在該網域會 404（相片顯示不出來）。
 *    呢條路由令後台可以經 API 取得同一批相片，唔需要改另一個 nginx 設定。
 *
 * 對外網站仍然走 nginx alias（較快、唔經 Node）。
 */
router.get('/admin/photo/:file', merchantAuth.requireActor, (req, res) => {
    // ⚠️ 一定要 basename，防止 ../ 跳脫出相片目錄
    const safe = path.basename(String(req.params.file || ''));
    if (!safe || safe === '.' || safe === '..') return res.status(400).end();
    res.sendFile(path.join(adoptionMedia.photosDir(), safe), (err) => {
        if (err && !res.headersSent) res.status(404).end();
    });
});

router.get('/admin/:id', async (req, res) => {
    try {
        const row = await getSubmission(req.params.id);
        if (!row) return res.status(404).json({ success: false, error: '找不到這筆申請' });
        // ⚠️ 用 API 路徑而唔係 /assets/img/cats-live/ ——
        //    後台在 catstearoom.dev，那個路徑在該網域會 404（見上方說明）
        res.json({
            success: true,
            submission: row,
            photoUrl: row.photo_file
                ? `/api/adoption/admin/photo/${encodeURIComponent(row.photo_file)}`
                : null,
        });
    } catch (err) {
        console.error('讀取領養申請失敗:', err);
        res.status(500).json({ success: false, error: '讀取失敗' });
    }
});

/** 修改內容（審核前或審核後都可） */
router.put('/admin/:id', async (req, res) => {
    try {
        const row = await getSubmission(req.params.id);
        if (!row) return res.status(404).json({ success: false, error: '找不到這筆申請' });

        const b = req.body || {};
        const fields = {};
        for (const key of ['cat_name', 'cat_gender', 'cat_age', 'cat_intro',
            'adoption_requirement', 'contact_method', 'submitter_role', 'submitter_name',
            'body_html', 'review_note']) {
            if (b[key] === undefined) continue;
            const limit = key === 'body_html' ? 20000 : (MAX[key] || 2000);
            const v = String(b[key] || '').trim();
            if (v.length > limit) return bad(res, `${key} 過長`);
            fields[key] = v;
        }
        const fee = pick(b, 'fee_amount');
        if (fee.error) return bad(res, fee.error);
        const feeNote = pick(b, 'fee_note');
        if (feeNote.error) return bad(res, feeNote.error);

        const feeRequired = (b.fee_required === true || b.fee_required === 'true' || b.fee_required === 1) ? 1 : 0;

        const setParts = [];
        const params = [];
        for (const [k, v] of Object.entries(fields)) { setParts.push(`${k} = ?`); params.push(v); }
        setParts.push('fee_required = ?'); params.push(feeRequired);
        setParts.push('fee_amount = ?'); params.push(feeRequired ? fee.value : '');
        setParts.push('fee_note = ?'); params.push(feeRequired ? feeNote.value : '');
        setParts.push('updated_at = CURRENT_TIMESTAMP');
        params.push(req.params.id);

        await new Promise((resolve, reject) => {
            db.run(`UPDATE adoption_submissions SET ${setParts.join(', ')} WHERE id = ?`,
                params, (err) => (err ? reject(err) : resolve()));
        });

        // body_html 傳空字串 = 「由目前欄位重新產生」
        // （後台的「重新產生貼文」按鈕用；唔傳 = 保持原樣，
        //   所以手改過嘅內容唔會無故被覆蓋）
        if (fields.body_html === '') {
            const fresh = await getSubmission(req.params.id);
            const regenerated = adoptionPublish.buildBodyHtml(fresh);
            await new Promise((resolve, reject) => {
                db.run('UPDATE adoption_submissions SET body_html = ? WHERE id = ?',
                    [regenerated, req.params.id], (err) => (err ? reject(err) : resolve()));
            });
        }

        // 已刊登的貓改動後要即時反映
        if (row.status === 'approved') await adoptionPublish.rewriteLiveJson();

        const updated = await getSubmission(req.params.id);
        res.json({ success: true, submission: updated });
    } catch (err) {
        console.error('修改領養申請錯誤:', err);
        res.status(500).json({ success: false, error: '修改失敗' });
    }
});

/** 審核通過 → 指派編號並寫入 live JSON */
router.post('/admin/:id/approve', async (req, res) => {
    try {
        const row = await getSubmission(req.params.id);
        if (!row) return res.status(404).json({ success: false, error: '找不到這筆申請' });
        if (row.status === 'approved') return bad(res, '這筆申請已經通過');
        if (!row.photo_file) return bad(res, '這筆申請沒有相片，無法刊登');
        if (!row.body_html) return bad(res, '請先產生貼文內容');

        const catNo = await adoptionPublish.nextCatNo();
        await new Promise((resolve, reject) => {
            db.run(
                `UPDATE adoption_submissions
                    SET status = 'approved', cat_no = ?, review_note = ?,
                        updated_at = CURRENT_TIMESTAMP
                  WHERE id = ?`,
                [catNo, String((req.body && req.body.review_note) || '').trim(), req.params.id],
                (err) => (err ? reject(err) : resolve())
            );
        });

        const total = await adoptionPublish.rewriteLiveJson();
        res.json({ success: true, cat_no: catNo, published: total });
    } catch (err) {
        console.error('通過領養申請錯誤:', err);
        res.status(500).json({ success: false, error: '審核失敗' });
    }
});

/** 拒絕（唔會刪相片，方便日後翻查或改為通過） */
router.post('/admin/:id/reject', async (req, res) => {
    try {
        const row = await getSubmission(req.params.id);
        if (!row) return res.status(404).json({ success: false, error: '找不到這筆申請' });

        const wasApproved = row.status === 'approved';

        await new Promise((resolve, reject) => {
            db.run(
                `UPDATE adoption_submissions
                    SET status = 'rejected', cat_no = NULL, review_note = ?,
                        updated_at = CURRENT_TIMESTAMP
                  WHERE id = ?`,
                [String((req.body && req.body.review_note) || '').trim(), req.params.id],
                (err) => (err ? reject(err) : resolve())
            );
        });

        // 由「已刊登」改為拒絕 → 要由 live JSON 抽走
        if (wasApproved) await adoptionPublish.rewriteLiveJson();

        res.json({ success: true });
    } catch (err) {
        console.error('拒絕領養申請錯誤:', err);
        res.status(500).json({ success: false, error: '操作失敗' });
    }
});

module.exports = router;
