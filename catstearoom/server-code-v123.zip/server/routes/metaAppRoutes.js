// ─────────────────────────────────────────────────────────────
// Meta 應用回調端點
//
// 掛喺 /api/meta（見 server/index.js）。呢三條路由係 Meta 嘅伺服器直接呼叫，
// **冇任何 cookie**，所以：
//   ⚠️ 一定要掛喺商家閘之外，亦唔可以加 requireActor —— 加咗 Meta 一定 403。
//   ⚠️ 驗證身分**只靠 signed_request 嘅 HMAC 簽名**，冇其他。
//
// 用途（Meta App Dashboard → Facebook Login → 設定 內嘅三個欄位）：
//   Deauthorize callback URL  → POST /api/meta/deauthorize
//   Data Deletion Request URL → POST /api/meta/data-deletion
//
// ⚠️ 呢兩條係 Meta 嘅**強制要求**（用 Facebook Login 嘅 App 都要有），
//    留空或者回唔到正確格式會阻住 App Review。
//
// ⚠️ 鐵律：呢個 router 永遠唔可以 throw。呼叫端係 Meta 嘅伺服器，
//    回 500 會令 Meta 重試同記錄錯誤。所有失敗都要變成明確嘅 JSON。
// ─────────────────────────────────────────────────────────────
'use strict';

const express = require('express');
const crypto = require('crypto');
const { db } = require('../../database/db');
const runtime = require('../config/runtime');
const { parseSignedRequest } = require('../services/metaSignedRequest');

const router = express.Router();

const MAX_CODE_LEN = 64;

// ── sqlite3 callback → Promise（跟其他 route 既有慣例）──
function dbRun(sql, params) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function (err) {
            if (err) return reject(err);
            resolve({ changes: this.changes });
        });
    });
}
function dbGet(sql, params) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => (err ? reject(err) : resolve(row)));
    });
}

function warn(...args) {
    console.warn('[meta]', ...args);
}

/** 對外公開嘅網址前綴。優先用 .env 設定，冇就由請求推導 */
function publicBaseUrl(req) {
    const cfg = runtime.metaAppBaseUrl();
    if (cfg) return cfg.replace(/\/+$/, '');
    const proto = String(req.headers['x-forwarded-proto'] || req.protocol || 'https')
        .split(',')[0].trim() || 'https';
    const host = String(req.headers['x-forwarded-host'] || req.get('host') || '').trim();
    return host ? proto + '://' + host : '';
}

/** 驗簽。失敗回 null 並已經寫好回應 */
function verifyOrReject(req, res) {
    const secret = runtime.whatsappAppSecret();
    if (!secret) {
        warn('未設定 WHATSAPP_APP_SECRET，無法驗證 signed_request');
        res.status(503).json({ success: false, error: '服務尚未完成設定' });
        return null;
    }
    const body = req.body || {};
    const r = parseSignedRequest(body.signed_request, secret);
    if (!r.ok) {
        // ⚠️ 唔好回太詳細 —— 呢個端點係公開嘅，唔應該幫攻擊者確認佢嘅猜測
        warn('signed_request 驗證失敗：' + r.reason);
        res.status(400).json({ success: false, error: '簽名驗證失敗' });
        return null;
    }
    return r.data;
}

/** 記錄一筆請求。失敗唔應該影響回應 —— Meta 收到錯誤會重試同記錄 */
async function record(kind, data) {
    const code = (kind === 'data_deletion' ? 'DEL-' : 'DEA-')
        + crypto.randomBytes(8).toString('hex');
    const nowIso = new Date().toISOString();
    try {
        await dbRun(
            `INSERT INTO wa_deletion_requests
               (id, confirmation_code, kind, fb_user_id, payload_json, status, requested_at)
             VALUES (?, ?, ?, ?, ?, 'pending', ?)`,
            [
                crypto.randomUUID(),
                code,
                kind,
                data && data.user_id ? String(data.user_id) : null,
                JSON.stringify(data || {}).slice(0, 4000),
                nowIso,
            ]
        );
    } catch (e) {
        // 記錄落唔到唔應該令 Meta 收到錯誤 —— 但一定要大聲講，唔可以靜默
        warn('寫入 wa_deletion_requests 失敗（請求仍會回成功）:', e.message);
    }
    return code;
}

// ─────────────────────────────────────────────────────────────

/**
 * GET /api/meta — 健康檢查。
 * 方便你（或者 Meta）直接開個 URL 確認端點活住。
 */
router.get('/', (req, res) => {
    res.json({
        success: true,
        service: 'meta-app-callbacks',
        configured: !!runtime.whatsappAppSecret(),
        endpoints: {
            deauthorize: '/api/meta/deauthorize',
            dataDeletion: '/api/meta/data-deletion',
            dataDeletionStatus: '/api/meta/data-deletion-status/<confirmation_code>',
        },
    });
});

/**
 * POST /api/meta/deauthorize
 *
 * 商家喺 Facebook 設定入面移除我哋嘅 App 授權時，Meta 會 POST 過嚟。
 * Meta 只要求回 200；冇規定回應格式。
 */
router.post('/deauthorize', async (req, res) => {
    const data = verifyOrReject(req, res);
    if (!data) return;

    await record('deauthorize', data);

    // ⚠️ 唔會即時撤銷任何存取 —— 因為 signed_request 只有 Facebook user_id，
    //    而本系統嘅資料係按 wa_id（電話）同 WABA 組織。兩者對應要等 Embedded
    //    Signup 落實之後才存得到。呢一刻只記錄，由人手處理。
    //    呢個係已知限制，寫喺 MERCHANT_APP_GUIDE。
    res.json({ success: true });
});

/**
 * POST /api/meta/data-deletion
 *
 * Meta 要求回一個指定格式嘅 JSON：
 *   { "url": "<狀態頁>", "confirmation_code": "<代碼>" }
 * 唔回呢個格式會令 Meta 視為未完成設定。
 */
router.post('/data-deletion', async (req, res) => {
    const data = verifyOrReject(req, res);
    if (!data) return;

    const code = await record('data_deletion', data);
    const base = publicBaseUrl(req);

    res.json({
        url: base ? base + '/api/meta/data-deletion-status/' + encodeURIComponent(code) : '',
        confirmation_code: code,
    });
});

/**
 * GET /api/meta/data-deletion-status/:code
 *
 * 上面回俾 Meta 嘅 `url` 指去呢度。任何人拿到代碼就睇得到狀態 ——
 * 代碼係 16 個 hex 字元嘅隨機值，等同一個無法猜測嘅憑證，可以接受。
 *
 * ⚠️ 只回狀態，唔回 payload 內容 —— 嗰個可能含 Facebook user id。
 */
router.get('/data-deletion-status/:code', async (req, res) => {
    const code = String(req.params.code || '').trim();
    if (!code || code.length > MAX_CODE_LEN) {
        return res.status(400).json({ success: false, error: '代碼格式錯誤' });
    }

    let row = null;
    try {
        row = await dbGet(
            `SELECT confirmation_code, status, requested_at, completed_at
               FROM wa_deletion_requests
              WHERE confirmation_code = ? AND kind = 'data_deletion'`,
            [code]
        );
    } catch (e) {
        warn('查詢刪除請求失敗:', e.message);
        return res.status(500).json({ success: false, error: '伺服器暫時無法處理，請稍後再試' });
    }

    if (!row) return res.status(404).json({ success: false, error: '找不到此請求' });

    const LABELS = {
        pending: '已收到請求，處理中',
        completed: '已完成刪除',
        failed: '處理失敗，請聯絡我們',
    };

    res.json({
        success: true,
        confirmation_code: row.confirmation_code,
        status: row.status,
        status_text: LABELS[row.status] || row.status,
        requested_at: row.requested_at,
        completed_at: row.completed_at,
    });
});

module.exports = router;
