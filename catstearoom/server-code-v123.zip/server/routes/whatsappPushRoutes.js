// ─────────────────────────────────────────────────────────────
// WhatsApp — 推播裝置登記
//
// 掛喺 /api/whatsapp/admin/push（見 server/index.js；flag 未開就唔掛載，
// 前端據 404 得知功能未啟用，同自動回覆端點同一手法）。
//
// 權限：
//   /api/whatsapp/admin 資料夾層已掛 requireMerchant（第一道閘）+
//   resolveActor（第二道閘）。呢個 router 每條路由再加 requireActor，
//   令「一定要有職員身分」成為硬性要求（admin 或 officer 都可以登記 ——
//   推播係每部裝置各自嘅事，唔屬「改設定」）。
//   ⚠️ 冇 requireActor 嘅話，淨係過咗商家大門就可以登記裝置 = 開咗一個洞。
//
// 呢個 router 唔涉及 Meta API，亦唔會發任何訊息 —— 只係寫 wa_push_tokens。
// ─────────────────────────────────────────────────────────────
'use strict';

const express = require('express');
const merchantAuth = require('../middleware/merchantAuth');
const push = require('../services/whatsappPush');

const router = express.Router();

// ⚠️ 跟收件匣 router 同一做法：兩道閘喺 router 內部都再掛一次。
//    理由同 whatsappInboxRoutes.js:62-66 一樣 —— 呢個 router 要能夠獨立
//    掛載（例如測試），唔可以依賴 server/index.js 嘅資料夾層。
//    requireMerchant 係冪等嘅，重複掛唔會多查一次 DB。
router.use(merchantAuth.requireMerchant);
router.use(merchantAuth.resolveActor);
// 所有寫入之前先擋跨站請求
router.use(merchantAuth.requireSameOrigin);

const getStoreId = () => process.env.WHATSAPP_STORE_ID || 'store_1';

// 錯誤碼 → 俾用戶睇嘅文字（標準中文書面語）
const REGISTER_ERRORS = {
    TOKEN_REQUIRED: '缺少推播 token',
    TOKEN_TOO_LONG: '推播 token 過長',
    PLATFORM_INVALID: '平台只可以是 android 或 ios',
    STORE_REQUIRED: '缺少分店代號',
    DB_ERROR: '伺服器暫時無法儲存，請稍後再試',
};

/**
 * GET / — 已登記裝置清單。
 * ⚠️ 刻意唔回完整 FCM token（見 whatsappPush.listDevices 嘅註解）。
 */
router.get('/', merchantAuth.requireActor, async (req, res) => {
    const devices = await push.listDevices(getStoreId());
    res.json({
        success: true,
        // configured = 憑證齊全且 flag 有開；前端可據此提示「推播尚未啟用」
        configured: push.isConfigured(),
        devices,
    });
});

/** POST /register — App 取得 FCM token 後登記 */
router.post('/register', merchantAuth.requireActor, async (req, res) => {
    const body = req.body || {};
    const r = await push.registerToken({
        storeId: getStoreId(),
        token: body.token,
        platform: body.platform,
        deviceLabel: body.device_label,
    });
    if (!r.ok) {
        const code = r.error || 'DB_ERROR';
        return res.status(400).json({
            success: false,
            code,
            error: REGISTER_ERRORS[code] || '登記失敗',
        });
    }
    res.json({ success: true });
});

/** POST /unregister — App 登出或關閉推播時刪除 */
router.post('/unregister', merchantAuth.requireActor, async (req, res) => {
    const r = await push.unregisterToken((req.body || {}).token);
    if (!r.ok) {
        return res.status(400).json({
            success: false,
            code: r.error || 'DB_ERROR',
            error: r.error === 'TOKEN_REQUIRED' ? '缺少推播 token' : '伺服器暫時無法處理，請稍後再試',
        });
    }
    res.json({ success: true });
});

module.exports = router;
