// ─────────────────────────────────────────────────────────────
// WhatsApp Cloud API — Webhook 端點
//
// 掛喺 /api/whatsapp（見 server/index.js）。呢個 route 冇 auth ——
// Meta 無法帶憑證，所以安全**完全**建立喺 HMAC 驗簽之上。
//
// 兩條路徑：
//   GET  /webhook  Meta 訂閱驗證握手
//   POST /webhook  收訊息同狀態回調
//
// ⚠️ req.rawBody 由 server/index.js:197 嘅 bodyParser verify hook 全域提供，
//    唔需要（亦唔應該）為呢個 route 另加 express.raw()。
// ─────────────────────────────────────────────────────────────
'use strict';

const express = require('express');
const router = express.Router();
const inbound = require('../services/whatsappInboundService');

// 用函式而唔係 module-level const：方便測試時改 env，亦同倉庫其他地方一致。
const getVerifyToken = () => (process.env.WHATSAPP_VERIFY_TOKEN || '').trim();
const getPhoneNumberId = () => (process.env.WHATSAPP_PHONE_NUMBER_ID || '').trim();
// ⚠️ App Secret 改為經 runtime.js 讀 —— 同一個 secret 而家喺三個地方用
//    （webhook 驗簽、Meta Deauthorize、Meta Data Deletion），集中一處定義
//    才唔會改漏（CLAUDE.md 守則 2：config 集中喺 runtime.js）。
const runtime = require('../config/runtime');
const getAppSecret = () => runtime.whatsappAppSecret();

// ─────────────────────────────────────────────────────────────
// GET /webhook —— Meta 訂閱驗證握手
// ─────────────────────────────────────────────────────────────
router.get('/webhook', (req, res) => {
    const expected = getVerifyToken();
    if (!expected) {
        // 未設定就當冇呢個端點（同 merchantChatRoutes 未配置時回 404 嘅慣例一致）
        console.warn('[whatsapp] 未設定 WHATSAPP_VERIFY_TOKEN，拒收驗證請求');
        return res.status(404).end();
    }

    const mode = req.query['hub.mode'];
    const token = req.query['hub.verify_token'];
    const challenge = req.query['hub.challenge'];

    if (mode !== 'subscribe' || !token || !inbound.safeEqual(token, expected)) {
        console.warn(`[whatsapp] webhook 驗證失敗 mode=${mode} tokenLen=${String(token || '').length}`);
        return res.status(403).end();
    }

    // ⚠️ 一定要回**純文字** challenge。用 res.json() 會回 "1234567890"（帶雙引號），
    //    Meta 會當驗證失敗。
    console.log('[whatsapp] webhook 驗證成功');
    res.status(200).type('text/plain').send(String(challenge || ''));
});

// ─────────────────────────────────────────────────────────────
// POST /webhook —— 接收事件
// ─────────────────────────────────────────────────────────────
router.post('/webhook', async (req, res) => {
    // 1) 先記錄「有嘢入嚟」——但只記長度，唔記 body 全文。
    //    body 含客人電話同訊息內容（個人資料），而 logger 係同步 appendFileSync，
    //    寫大物件會拖慢 event loop。
    //    KPay 教訓（2026-09-23）：唔記嘅話，「卡機冇打嚟」同「打咗嚟但被拒」分辨唔到。
    console.log(`[whatsapp] webhook 收到請求，body 長度=${req.rawBody ? req.rawBody.length : 'n/a'}`);

    // 2) 驗簽（fail closed）
    const signature = inbound.getHeader(req.headers, 'x-hub-signature-256');
    const check = inbound.verifySignature(req.rawBody, signature, getAppSecret());
    if (!check.ok) {
        // 一定要記明確原因 —— 靜默拒絕會令真機 debug 完全查唔出問題
        console.warn(`[whatsapp] webhook 驗簽失敗：${check.reason}`);
        return res.status(401).end();
    }

    const payload = req.body || {};

    if (payload.object !== 'whatsapp_business_account') {
        // 唔係我哋關心嘅事件類型 —— 回 200，唔好令 Meta 重試
        console.log(`[whatsapp] 忽略非 WABA 事件 object=${payload.object}`);
        return res.status(200).end();
    }

    // 3) 先落庫（快、同步），再 ack。
    //    次序重要：事件喺 ack 之前已經落磁碟，就算程序喺處理途中崩潰都唔會唔見。
    let result = { inserted: [], skipped: 0 };
    try {
        result = await inbound.ingestPayload(payload, getPhoneNumberId());
    } catch (e) {
        // 落庫失敗 = 真係冇收到。回 500 讓 Meta 重試，唔好回 200 靜靜漏訊息。
        console.error('[whatsapp] webhook 事件落庫失敗:', e.message);
        return res.status(500).end();
    }

    // 4) 立即回 200。Meta 對回應時間有要求（約 5 秒），超時會退避重試，
    //    重試可以持續數日，訊息會延遲極久才入庫。
    res.status(200).end();

    if (result.skipped > 0) {
        console.log(`[whatsapp] ${result.skipped} 條事件係重複（Meta 重試），已略過`);
    }

    // 5) 回應之後才做實際處理
    setImmediate(() => {
        for (const id of result.inserted) {
            inbound.processEventById(id).catch((e) => {
                console.error('[whatsapp] 處理事件時發生未預期例外:', e.message);
            });
        }
    });
});

module.exports = router;
