// ─────────────────────────────────────────────────────────────
// WhatsApp Cloud API — 訊息模板管理
//
// 掛喺 /api/whatsapp/admin/templates（見 server/index.js），全部經 requireMerchant。
//
// 為什麼需要呢個功能：
//   主動發起對話（客人未先傳訊）必須用**已批准**的模板，唔可以用自由格式文字。
//   另外，申請 Meta Tech Provider 的 App Review 要求提交一段影片，
//   展示「你的 App 建立訊息模板，所有欄位」—— 所以呢個介面同時係審查素材。
//
// Meta 的模板 API 係唯一真實來源，所以唔另存本地 DB。
// ─────────────────────────────────────────────────────────────
'use strict';

const express = require('express');
const router = express.Router();
const merchantAuth = require('../middleware/merchantAuth');
const whatsappService = require('../services/whatsappService');
const runtime = require('../config/runtime');

// ⚠️ requireMerchant 同 resolveActor 已經喺 server/index.js 嘅資料夾層掛咗，
//    呢度再掛係防禦性冗餘（requireMerchant 冪等）。
router.use(merchantAuth.requireMerchant);
router.use(merchantAuth.resolveActor);
router.use(merchantAuth.requireSameOrigin);

function fail(res, status, error, extra) {
    return res.status(status).json(Object.assign({ success: false, error }, extra || {}));
}

/** 把 Graph API 的錯誤轉做俾用戶睇嘅文字（標準中文書面語）。 */
function describeTemplateError(e) {
    const code = e && e.apiCode;
    if (code === 100) return '模板內容不符合 Meta 的格式要求，請檢查名稱、語言或變數。';
    if (code === 368) return 'WhatsApp 商業帳號目前受限制，暫時無法建立模板。';
    if (code === 190) return 'WhatsApp 授權已失效，請檢查系統設定。';
    if (e && e.message && e.message.includes('already exists')) return '已有同名模板，請改用其他名稱。';
    return '建立模板失敗，請稍後再試。';
}

// ─────────────────────────────────────────────────────────────
// GET / —— 列出所有模板（含審批狀態）
// ─────────────────────────────────────────────────────────────
router.get('/', merchantAuth.requireActor, async (req, res) => {
    try {
        if (!whatsappService.isTemplateConfigured()) {
            return fail(res, 503, whatsappService.templateNotConfiguredMessage(), { code: 'NOT_CONFIGURED' });
        }
        const out = await whatsappService.listTemplates();

        // 正規化俾前端用
        const templates = (out.data || []).map((t) => {
            const comps = Array.isArray(t.components) ? t.components : [];
            const pick = (type) => (comps.find((c) => c.type === type) || {});
            const header = pick('HEADER');
            const body = pick('BODY');
            const footer = pick('FOOTER');
            return {
                id: t.id,
                name: t.name,
                status: t.status,               // APPROVED | PENDING | REJECTED | ...
                category: t.category,
                language: t.language,
                header: header.text || '',
                body: body.text || '',
                footer: footer.text || '',
                rejectedReason: t.rejected_reason || null,
            };
        });

        res.json({
            success: true,
            dryRun: out.dryRun,
            // 只有 admin 可以建立／刪除模板（前端據此隱藏控制項並顯示唯讀提示）
            canManage: Boolean(req.actor && req.actor.role === 'admin'),
            categories: whatsappService.TEMPLATE_CATEGORIES,
            templates,
        });
    } catch (e) {
        console.error('[whatsapp] 列出模板失敗:', e.message);
        fail(res, 502, describeTemplateError(e));
    }
});

// ─────────────────────────────────────────────────────────────
// POST / —— 建立模板並送交審批
// ─────────────────────────────────────────────────────────────
// ⚠️ 一定要 requireAdminActor：建立模板會改變對外送訊行為，屬「改設定」。
//    之前呢條路由完全冇權限閘（只有 requireMerchant），任何登入者都建立得到。
router.post('/', merchantAuth.requireAdminActor, async (req, res) => {
    try {
        if (!whatsappService.isTemplateConfigured()) {
            return fail(res, 503, whatsappService.templateNotConfiguredMessage(), { code: 'NOT_CONFIGURED' });
        }

        const b = req.body || {};
        const out = await whatsappService.createTemplate({
            name: b.name,
            category: b.category,
            language: b.language,
            header: b.header,
            body: b.body,
            footer: b.footer,
            examples: b.examples,
        });

        res.json({
            success: true,
            dryRun: out.dryRun,
            template: { id: out.id, status: out.status, name: String(b.name || '').trim() },
        });
    } catch (e) {
        // definitelyNotSent = 使用者輸入問題（格式、缺欄位），回 400 並顯示原因
        if (e && e.definitelyNotSent) {
            return fail(res, 400, e.message);
        }
        console.error('[whatsapp] 建立模板失敗:', e.message);
        fail(res, 502, describeTemplateError(e));
    }
});

// ─────────────────────────────────────────────────────────────
// DELETE /:name —— 刪除模板（該名稱下所有語言版本）
// ─────────────────────────────────────────────────────────────
// ⚠️ 同上：刪除模板同樣屬「改設定」。
router.delete('/:name', merchantAuth.requireAdminActor, async (req, res) => {
    try {
        if (!whatsappService.isTemplateConfigured()) {
            return fail(res, 503, whatsappService.templateNotConfiguredMessage(), { code: 'NOT_CONFIGURED' });
        }
        const out = await whatsappService.deleteTemplate(req.params.name);
        res.json({ success: true, dryRun: out.dryRun });
    } catch (e) {
        if (e && e.definitelyNotSent) {
            return fail(res, 400, e.message);
        }
        console.error('[whatsapp] 刪除模板失敗:', e.message);
        fail(res, 502, '刪除模板失敗，請稍後再試。');
    }
});

module.exports = router;
