/**
 * KPay 設定 Routes（離場機用）
 *
 * GET  /api/kpay/settings   讀取現行 KPay 設定（機密只回報「已設定／未設定」）
 * PUT  /api/kpay/settings   寫入 .env（**需重啟服務才生效**）
 *
 * 設計背景（見 `MD Files/KPAY_INTEGRATION_GUIDE.MD` §4、§6）：
 *   - KPay 設定一律放**每間平板嘅 `.env`**（唔經 runtime.js、唔經 DB）
 *   - `kpay_configs` 表**不可使用**：schema 預設 mode='lan'，一旦有 row 會靜默覆蓋 .env
 *   - 本路由只寫 `.env`，機密仍留在 gitignored 檔案
 *
 * 權限（伺服器端強制，不依賴前端隱藏）：
 *   - staff：只可改 KPAY_KPOS_IP / KPAY_KPOS_PORT
 *   - admin：可改其餘全部
 *   解鎖流程由前端呼叫 `/api/auth/login` 取得 token，本路由用 `authenticate` 驗證，
 *   並以 `req.employee.role` 決定可寫欄位。
 *
 * ⚠️ 本路由**必須在 `app.use('/api/kpay', kpayRoutes)` 之前掛載**，
 *    否則會被 kpayRoutes 的 `router.get('/:op')` 薄層轉發攔截。
 */

const express = require('express');
const router = express.Router();
const path = require('path');
const dotenv = require('dotenv');
const fs = require('fs');

const authMiddleware = require('../middleware/auth');
const { writeEnvKeys, hasEnvKey } = require('../utils/envFile');

// 與 server/index.js 的 homeDir 慣例一致（repo root）
const ENV_PATH = path.resolve(__dirname, '..', '..', '.env');

/**
 * 欄位定義。
 *   staffEditable — staff 角色可否修改（admin 一律可改）
 *   secret        — 不回傳值，只回報是否已設定
 *   hint          — 界面用嘅說明
 */
const FIELDS = {
  KPAY_KPOS_IP: {
    label: 'KPOS 機 IP', staffEditable: true,
    hint: 'KPay 收款機在店內網絡的固定 IP'
  },
  KPAY_KPOS_PORT: {
    label: 'KPOS 機連接埠', staffEditable: true,
    hint: '預設 18080'
  },
  KPAY_MODE: {
    label: '運作模式', staffEditable: false,
    hint: 'mock = 模擬付款；lan = 連接真卡機'
  },
  KPAY_APP_ID: {
    label: '應用 ID', staffEditable: false,
    hint: 'KPay 分發的 APPID'
  },
  KPAY_APP_SECRET: {
    label: '應用密鑰', staffEditable: false, secret: true,
    hint: '留空表示不變更'
  },
  KPAY_MANAGER_PASSWORD: {
    label: '管理員密碼', staffEditable: false, secret: true,
    hint: '撤銷／退款操作使用；留空表示不變更'
  },
  KPAY_CALLBACK_URL: {
    label: '回調網址', staffEditable: false,
    hint: '路徑必須是 /api/kpay/callback（回調簽名綁定路徑）'
  }
};

const CALLBACK_PATH = '/api/kpay/callback';

// ===== 讀取 .env（檔案為準，非 process.env）=====
function readEnvFile() {
  try {
    return dotenv.parse(fs.readFileSync(ENV_PATH, 'utf8'));
  } catch (_) {
    return {};
  }
}

// ===== 驗證 =====
// 回傳錯誤訊息字串；通過則回 null
function validateField(key, rawValue) {
  const value = String(rawValue).trim();

  if (key === 'KPAY_MODE') {
    if (value !== 'mock' && value !== 'lan') return '運作模式只可以是 mock 或 lan';
    return null;
  }
  if (key === 'KPAY_KPOS_IP') {
    if (!value) return 'KPOS 機 IP 不可為空';
    // 容許 IPv4 或主機名稱
    const ipv4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
    if (ipv4.test(value)) {
      const ok = value.split('.').every((n) => Number(n) >= 0 && Number(n) <= 255);
      if (!ok) return 'IP 位址格式不正確';
      return null;
    }
    if (/^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?$/.test(value)) return null;
    return 'IP 位址格式不正確';
  }
  if (key === 'KPAY_KPOS_PORT') {
    const port = Number(value);
    if (!Number.isInteger(port) || port < 1 || port > 65535) return '連接埠必須是 1 至 65535';
    return null;
  }
  if (key === 'KPAY_CALLBACK_URL') {
    if (!value) return '回調網址不可為空';
    let u;
    try {
      u = new URL(value);
    } catch (_) {
      return '回調網址格式不正確（需含 http:// 或 https://）';
    }
    if (u.pathname !== CALLBACK_PATH) {
      return `回調網址的路徑必須是 ${CALLBACK_PATH}（回調簽名綁定路徑，改了會驗證失敗）`;
    }
    return null;
  }
  if (key === 'KPAY_APP_ID') {
    if (!value) return '應用 ID 不可為空';
    if (value.length > 32) return '應用 ID 不可超過 32 字元';
    return null;
  }
  if (key === 'KPAY_APP_SECRET') {
    if (value.length > 64) return '應用密鑰不可超過 64 字元';
    return null;
  }
  if (key === 'KPAY_MANAGER_PASSWORD') {
    if (value.length > 64) return '管理員密碼不可超過 64 字元';
    return null;
  }
  return null;
}

// ===== GET：讀取現行設定（永不回傳機密值）=====
router.get('/', authMiddleware.authenticate, (req, res) => {
  try {
    const env = readEnvFile();
    const role = req.employee && req.employee.role;
    const isAdmin = role === 'admin';

    const fields = {};
    for (const [key, def] of Object.entries(FIELDS)) {
      const editable = isAdmin || def.staffEditable;
      if (def.secret) {
        // 只回報是否已設定，永不回傳值
        fields[key] = {
          label: def.label,
          hint: def.hint,
          secret: true,
          editable,
          is_set: hasEnvKey(ENV_PATH, key)
        };
      } else {
        fields[key] = {
          label: def.label,
          hint: def.hint,
          secret: false,
          editable,
          value: env[key] !== undefined ? env[key] : ''
        };
      }
    }

    res.json({
      success: true,
      data: {
        role,
        env_path: ENV_PATH,
        fields,
        restart_required_note: '設定儲存後需重啟服務才會生效'
      }
    });
  } catch (error) {
    console.error('[kpay-settings] 讀取設定錯誤:', error);
    res.status(500).json({ success: false, error: '讀取設定失敗', message: error.message });
  }
});

// ===== PUT：寫入 .env =====
router.put('/', authMiddleware.authenticate, async (req, res) => {
  try {
    const body = req.body || {};
    const role = req.employee && req.employee.role;
    const isAdmin = role === 'admin';

    // 未知欄位一律拒絕，避免誤寫其他設定
    const unknown = Object.keys(body).filter((k) => !FIELDS[k]);
    if (unknown.length) {
      return res.status(400).json({
        success: false,
        error: '不支援的欄位',
        message: `不支援的欄位：${unknown.join('、')}`
      });
    }

    // 角色權限檢查（伺服器端強制）
    const forbidden = Object.keys(body).filter((k) => !isAdmin && !FIELDS[k].staffEditable);
    if (forbidden.length) {
      const names = forbidden.map((k) => FIELDS[k].label).join('、');
      return res.status(403).json({
        success: false,
        error: '權限不足',
        message: `您的角色（${role}）不可修改：${names}。請以管理員帳號解鎖。`
      });
    }

    // 驗證 + 組出要寫入的 patch（機密留空 = 不變更）
    const patch = {};
    for (const [key, rawValue] of Object.entries(body)) {
      const def = FIELDS[key];
      const value = rawValue === undefined || rawValue === null ? '' : String(rawValue);

      if (def.secret && value.trim() === '') continue; // 留空 → 不變更

      const err = validateField(key, value);
      if (err) {
        return res.status(400).json({
          success: false,
          error: '參數錯誤',
          message: `${def.label}：${err}`
        });
      }
      patch[key] = value.trim();
    }

    if (Object.keys(patch).length === 0) {
      return res.json({
        success: true,
        data: { changed: [], restart_required: false, message: '沒有需要變更的欄位' }
      });
    }

    const { changed, backupPath } = writeEnvKeys(ENV_PATH, patch);

    if (changed.length === 0) {
      return res.json({
        success: true,
        data: { changed: [], restart_required: false, message: '設定與現行值相同，未作變更' }
      });
    }

    // 稽核：只記欄位名，不記值
    // ⚠️ createAuditLog 的 actionDetails 會直接寫入 TEXT 欄位，必須傳字串
    //    （傳物件會被 SQLite 轉成 "[object Object]"）
    try {
      await authMiddleware.createAuditLog(
        req.employee.id,
        'kpay_settings_update',
        JSON.stringify({ changed, role, source: 'exit-machine' }),
        req.ip,
        req.employee.store_id
      );
    } catch (e) {
      // 稽核失敗不應阻擋設定寫入（但要求記錄）
      console.error('[kpay-settings] 寫入稽核記錄失敗:', e.message);
    }

    console.log(`[kpay-settings] ${req.employee.username}(${role}) 更新 KPay 設定: ${changed.join(', ')}`);

    // mode 改為 lan 會即時啟用 exitRoutes 防繞過閘（重啟後生效）
    const warnings = [];
    if (changed.includes('KPAY_MODE') && patch.KPAY_MODE === 'lan') {
      warnings.push('設為 lan 後，未完成 KPay 付款的客人將無法結帳（現金／會員卡出口會被擋）');
    }
    if (changed.includes('KPAY_CALLBACK_URL')) {
      warnings.push('回調網址改變後，卡機必須能連到新位址，且路徑必須維持 /api/kpay/callback');
    }

    res.json({
      success: true,
      data: {
        changed,
        role,
        backup_file: backupPath ? path.basename(backupPath) : null,
        restart_required: true,
        message: '設定已儲存，請重啟服務以生效',
        warnings
      }
    });
  } catch (error) {
    console.error('[kpay-settings] 寫入設定錯誤:', error);
    res.status(500).json({ success: false, error: '寫入設定失敗', message: error.message });
  }
});

module.exports = router;
