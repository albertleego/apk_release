// ─────────────────────────────────────────────────────────────
// WhatsApp — 自動回覆設定
//
// 掛喺 /api/whatsapp/admin/auto-reply（見 server/index.js）。
//
// 權限：讀 = 所有登入者；寫 = 只有商家本人（改回覆內容屬「設定」）。
// ─────────────────────────────────────────────────────────────
'use strict';

const express = require('express');
const runtime = require('../config/runtime');
const merchantAuth = require('../middleware/merchantAuth');
const cfgSvc = require('../services/whatsappAutoReplyConfig');
const { isWithinBusinessHours, getHongKongTimeInfo } = require('../utils/hongKongTime');

const router = express.Router();

const getStoreId = () => process.env.WHATSAPP_STORE_ID || 'store_1';

function fail(res, status, error, extra) {
    return res.status(status).json(Object.assign({ success: false, error }, extra || {}));
}

// ⚠️ requireMerchant 同 resolveActor 已經喺 server/index.js 嘅資料夾層掛咗，
//    呢度再掛係防禦性冗餘（requireMerchant 冪等）。
router.use(merchantAuth.requireMerchant);
router.use(merchantAuth.resolveActor);
router.use(merchantAuth.requireSameOrigin);

// ─────────────────────────────────────────────────────────────
// GET / —— 讀設定 + 目前係唔係客服時間
// ─────────────────────────────────────────────────────────────
router.get('/', async (req, res) => {
    try {
        const config = await cfgSvc.loadConfig(getStoreId());
        // ⚠️ 「現在係唔係客服時間」由**伺服器**計。
        //    喺瀏覽器再實作一次跨夜邏輯，就係兩邊漂移嘅開始。
        const inBusinessHours = isWithinBusinessHours(config.hours);
        const hk = getHongKongTimeInfo();

        res.json({
            success: true,
            // 只有 admin 可以改自動回覆。「商家」只係第一道閘，唔係身分。
            canManage: Boolean(req.actor && req.actor.role === 'admin'),
            config,
            status: {
                inBusinessHours,
                hongKongTime: hk.timeString,
                dayOfWeek: hk.dayOfWeek,
                serverNow: Date.now(),
            },
            greetingResetHours: runtime.whatsappGreetingResetHours(),
            limits: {
                greetingMax: cfgSvc.GREETING_MAX,
                keywordMax: cfgSvc.KEYWORD_MAX,
                keywordReplyMax: cfgSvc.KEYWORD_REPLY_MAX,
                maxKeywords: cfgSvc.MAX_KEYWORDS,
            },
        });
    } catch (e) {
        console.error('[whatsapp] 讀取自動回覆設定失敗:', e.message);
        fail(res, 500, '讀取設定失敗');
    }
});

// ─────────────────────────────────────────────────────────────
// PUT / —— 儲存設定（只有商家本人）
// ─────────────────────────────────────────────────────────────
router.put('/', merchantAuth.requireAdminActor, async (req, res) => {
    try {
        const out = await cfgSvc.saveConfig(
            getStoreId(),
            req.body || {},
            (req.merchant && req.merchant.employee_id) || null
        );
        res.json({
            success: true,
            config: out.config,
            // 清洗嘅時候丟棄咗嘅部分，要話俾商家知（唔好靜默）
            warnings: out.warnings,
            status: { inBusinessHours: isWithinBusinessHours(out.config.hours) },
        });
    } catch (e) {
        console.error('[whatsapp] 儲存自動回覆設定失敗:', e.message);
        fail(res, 500, '儲存設定失敗');
    }
});

module.exports = router;
