/**
 * merchantChatPeers.js — 跨實例聚合的「對外」一端
 *
 * 背景：每個實例（不同 port／不同目錄）有自己嘅 SQLite，商家帳號同對話都係分開嘅。
 * 主商家要喺「總控」實例嘅面板管理其他實例嘅商家，就要靠呢個模組去呼叫 peer。
 *
 * 設定（runtime.js 讀）：
 *   MERCHANT_CHAT_PEERS=標籤|baseUrl,標籤|baseUrl   ← 只喺「總控」實例需要設
 *   MERCHANT_CHAT_PEER_KEY=<共用密鑰>                ← 每個參與嘅實例都要設同一個值
 *
 * ⚠️ 安全：
 *   1. peer 端點只靠 X-Merchant-Chat-Peer-Key 保護，所以密鑰要夠強。
 *   2. baseUrl 建議填 127.0.0.1 或內網地址 —— 唔好經公網傳。
 *   3. 呢個模組永遠唔會回傳或記錄 key 嘅值。
 */
const runtime = require('../config/runtime');

const PEER_HEADER = 'x-merchant-chat-peer-key';
const PEER_TIMEOUT_MS = parseInt(process.env.MERCHANT_CHAT_PEER_TIMEOUT_MS || '15000', 10);

/** 已設定的 peer 清單（未設 = 空陣列，即係唔做聚合） */
function list() {
    return runtime.merchantChatPeers();
}

function isEnabled() {
    return list().length > 0 && !!runtime.merchantChatPeerKey();
}

function findByLabel(label) {
    return list().filter((p) => p.label === label)[0] || null;
}

/**
 * 呼叫一個 peer。永遠唔會 throw —— 失敗會回 { ok:false, data:{ error } }，
 * 令「總控」面板唔會因為某個 peer 掛掉而整個壞掉。
 */
async function callPeer(peer, path, opts = {}) {
    const key = runtime.merchantChatPeerKey();
    if (!key) {
        return { ok: false, status: 0, data: { error: '此實例未設定 MERCHANT_CHAT_PEER_KEY' } };
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), PEER_TIMEOUT_MS);
    try {
        const res = await fetch(`${peer.baseUrl}${path}`, {
            method: opts.method || 'GET',
            headers: {
                'content-type': 'application/json',
                [PEER_HEADER]: key
            },
            body: opts.body ? JSON.stringify(opts.body) : undefined,
            signal: controller.signal
        });
        const data = await res.json().catch(() => ({}));
        return { ok: res.ok, status: res.status, data };
    } catch (e) {
        if (e.name === 'AbortError') {
            return {
                ok: false, status: 0,
                data: { error: `實例「${peer.label}」無回應（超過 ${Math.round(PEER_TIMEOUT_MS / 1000)} 秒）` }
            };
        }
        return { ok: false, status: 0, data: { error: `無法連接實例「${peer.label}」：${e.message}` } };
    } finally {
        clearTimeout(timer);
    }
}

module.exports = {
    list,
    isEnabled,
    findByLabel,
    info: (peer) => callPeer(peer, '/api/merchant/peer/info'),
    setEnabled: (peer, id, enabled) => callPeer(
        peer,
        `/api/merchant/peer/merchants/${encodeURIComponent(id)}/enabled`,
        { method: 'POST', body: { enabled } }
    ),
    setApiKey: (peer, id, apiKey) => callPeer(
        peer,
        `/api/merchant/peer/merchants/${encodeURIComponent(id)}/api-key`,
        { method: 'POST', body: { apiKey } }
    ),
    setAccount: (peer, id, patch) => callPeer(
        peer,
        `/api/merchant/peer/merchants/${encodeURIComponent(id)}/account`,
        { method: 'POST', body: patch }
    ),
    conversations: (peer, merchantId) => callPeer(
        peer,
        `/api/merchant/peer/conversations?merchantId=${encodeURIComponent(merchantId || '')}`
    ),
    messages: (peer, convId) => callPeer(
        peer,
        `/api/merchant/peer/conversations/${encodeURIComponent(convId)}/messages`
    )
};
