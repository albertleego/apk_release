/**
 * 領養頁貓貓的「已領養／隱藏」狀態
 *
 * ─────────────────────────────────────────────────────────────
 * 為什麼狀態不放在網站的 cats.json：
 *   /var/www/catstearoom-site/ 是部署時 rsync --delete 的目標，任何寫進去的
 *   檔案下次部署都會被刪走。所以狀態放在它的**兄弟目錄** catstearoom-data
 *   （runtime.adoptionDataDir()），再由 nginx 用
 *   `location ^~ /assets/data/live/` alias 指過去 —— 與 live/cats.json 同一個模式。
 *
 * ⚠️ 這個檔案是「已領養／隱藏」的**唯一來源**：
 *    cats.json / cats2.json 已經不再帶 adopted 欄位（後台按一下就改這裡）。
 *    它在 git 之外，所以**要備份** —— 不見了就等於全部標記消失。
 *
 * 狀態鍵的格式：`<dataset>:<no>`，例如 cats:31、cats2:5、live:1042。
 *   dataset 用 cats / cats2 / live 區分三個來源，因為三者的 no 各自由 1 起
 *   （live 由 1000 起），單靠 no 無法分辨。
 * ─────────────────────────────────────────────────────────────
 */

'use strict';

const fs = require('fs');
const path = require('path');
const { db } = require('../../database/db');
const runtime = require('../config/runtime');

const STATUS_FILE = 'cat-status.json';

/** 網站上的兩份靜態貓貓名單（dataset 名稱 → 檔名） */
const STATIC_SETS = [
    { dataset: 'cats', file: 'cats.json' },
    { dataset: 'cats2', file: 'cats2.json' },
];

function statusPath() {
    return path.join(runtime.adoptionDataDir(), STATUS_FILE);
}

/** 讀狀態表；檔案不存在（未有任何改動）時回空物件 */
function read() {
    try {
        const obj = JSON.parse(fs.readFileSync(statusPath(), 'utf8'));
        return obj && typeof obj === 'object' && !Array.isArray(obj) ? obj : {};
    } catch (err) {
        if (err.code !== 'ENOENT') console.error('讀取貓貓狀態失敗:', err.message);
        return {};
    }
}

/** 原子寫入（先寫 .tmp 再 rename），避免讀到寫到一半的檔案 */
function write(map) {
    const file = statusPath();
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const tmp = `${file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(map, null, 1), 'utf8');
    fs.renameSync(tmp, file);
}

/**
 * 靜態名單的目錄。
 * 預設讀「網站實際服務中」的那份，確保後台見到的與訪客見到的完全一致；
 * 本機開發時該路徑不存在，就退回 repo 內的那份。
 */
function staticDataDir() {
    if (process.env.ADOPTION_SITE_DATA_DIR) return process.env.ADOPTION_SITE_DATA_DIR;
    const onSite = '/var/www/catstearoom-site/assets/data';
    if (fs.existsSync(onSite)) return onSite;
    return path.join(__dirname, '..', '..', 'catstearoom-website', 'assets', 'data');
}

function readStaticCats() {
    const out = [];
    for (const set of STATIC_SETS) {
        try {
            const arr = JSON.parse(fs.readFileSync(path.join(staticDataDir(), set.file), 'utf8'));
            if (!Array.isArray(arr)) continue;
            for (const c of arr) {
                out.push({
                    dataset: set.dataset,
                    no: c.no,
                    name: String(c.name || ''),
                    local: String(c.local || ''),   // 相片相對路徑（存檔時要用）
                });
            }
        } catch (err) {
            if (err.code !== 'ENOENT') console.error(`讀取 ${set.file} 失敗:`, err.message);
        }
    }
    return out;
}

/** 審核通過、已刊登的貓（由後台 /adoption-admin/ 刊登） */
function listLiveCats() {
    return new Promise((resolve) => {
        db.all(
            `SELECT cat_no, cat_name, cat_gender, cat_age
               FROM adoption_submissions
              WHERE status = 'approved' AND cat_no IS NOT NULL
              ORDER BY cat_no DESC`,
            [],
            (err, rows) => {
                if (err) {
                    console.error('讀取已刊登貓貓失敗:', err.message);
                    return resolve([]);
                }
                resolve((rows || []).map((r) => ({
                    dataset: 'live',
                    no: r.cat_no,
                    name: [r.cat_name, r.cat_gender, r.cat_age].filter(Boolean).join(' '),
                })));
            }
        );
    });
}

/** 三個來源 + 目前狀態，供後台列出 */
async function listAll() {
    const map = read();
    // ⚠️ 順序要跟領養頁一致：審核通過（live）的排【最前】，靜態的排後面。
    //    領養頁就是這樣排的（見 catstearoom-website/assets/js/cats.js），
    //    後台若反過來，新刊登的貓會沉在 206 隻靜態貓之後，很難找。
    const cats = (await listLiveCats()).concat(readStaticCats());
    return cats.map((c) => {
        const key = `${c.dataset}:${c.no}`;
        const st = map[key] || {};
        return {
            key,
            dataset: c.dataset,
            no: c.no,
            name: c.name,
            adopted: !!st.adopted,
            hidden: !!st.hidden,
        };
    });
}

/**
 * 設定某隻貓的狀態。
 * adopted / hidden 傳 undefined = 不改該項；傳 false = 取消該項。
 * 兩項都取消時就整筆刪掉，狀態檔不會留低空殼。
 */
function setStatus(key, { adopted, hidden } = {}) {
    if (!/^(cats|cats2|live):\d+$/.test(String(key || ''))) {
        const err = new Error('貓貓編號格式不正確');
        err.userFacing = true;
        throw err;
    }

    const map = read();
    const entry = Object.assign({}, map[key]);

    if (adopted !== undefined) {
        if (adopted) entry.adopted = true; else delete entry.adopted;
    }
    if (hidden !== undefined) {
        if (hidden) entry.hidden = true; else delete entry.hidden;
    }

    if (!entry.adopted && !entry.hidden) delete map[key];
    else map[key] = entry;

    write(map);
    return entry;
}

/**
 * 某隻貓的相片在磁碟上的位置，供「存到 Google Drive」用。
 *   static（cats / cats2）：catstearoom-website 的 assets/img/...（部署後在網站根目錄）
 *   live（後台刊登）：catstearoom-data/photos/<photo_file>
 * 回 { name, filePath }；找不到相片就回 null。
 */
async function photoFor(key) {
    const m = /^(cats|cats2|live):(\d+)$/.exec(String(key || ''));
    if (!m) return null;
    const [, dataset, noStr] = m;
    const no = Number(noStr);

    if (dataset === 'live') {
        const row = await new Promise((resolve) => {
            db.get('SELECT cat_name, photo_file FROM adoption_submissions WHERE cat_no = ?',
                [no], (err, r) => resolve(err ? null : r));
        });
        if (!row || !row.photo_file) return null;
        return {
            name: String(row.cat_name || ''),
            filePath: path.join(runtime.adoptionDataDir(), 'photos', row.photo_file),
        };
    }

    // 靜態名單：由 local 相對路徑換算成實際檔案位置
    const set = STATIC_SETS.find((s) => s.dataset === dataset);
    let local = '';
    try {
        const arr = JSON.parse(fs.readFileSync(path.join(staticDataDir(), set.file), 'utf8'));
        const c = (Array.isArray(arr) ? arr : []).find((x) => x.no === no);
        local = c ? String(c.local || '') : '';
    } catch (err) {
        return null;
    }
    if (!local) return null;
    // local 形如 ../assets/img/cats/cat-119.jpeg（相對於 /adoption/）；
    // 換算成網站根目錄下的路徑
    const rel = local.replace(/^(\.\.\/)+/, '').replace(/^\//, '');
    const siteRoot = staticDataDir().replace(/\/assets\/data$/, '');
    return { name: '', filePath: path.join(siteRoot, rel) };
}

module.exports = { listAll, setStatus, read, write, statusPath, staticDataDir, photoFor };
