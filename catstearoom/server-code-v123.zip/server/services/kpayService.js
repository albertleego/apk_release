/**
 * KPay 智能收款機（KPOS）LAN POS API client —— 路線 A
 *
 * 離場機真支付：本地 server 直接 call 店內 KPOS
 *   http://<kpos-ip>:18080/v2/pos/*
 * 實時桌號數據只留喺本地主機，唔上雲，所以用 LAN POS API（路線 A），唔用 Cloud API。
 * KPOS 必須同 server 喺同一 LAN/VLAN，MAC → 固定 IP（見 MD Files/KPAY_INTEGRATION_GUIDE.MD）。
 *
 * Mock 模式（KPAY_MODE=mock，預設）：
 *   所有操作本地模擬，sales() 3 秒後觸發模擬成功回調（行同一 idempotent callback handler），
 *   用嚟開發/測試離場機成條 UI 流程；攞到真 KPay credentials 同卡機先轉 lan。
 *
 * 簽名規則（SHA256withRSA，官方 POS API 對接）：
 *   POST/PUT content = `METHOD\n{path}\ntimestamp\nnonceStr\n{json body}\n`（每行以 \n 結尾）
 *   GET content = `METHOD\n{path}\ntimestamp\nnonceStr\n`（冇 body 行，4 行）
 *   → 用工作私鑰（appPrivateKey）sign → Base64 → header `signature`
 *   回調驗簽用 platformPublicKey（headers 帶 signature/timestamp/nonceStr，body 用原 byte）。
 *
 * 工作密鑰換領：POST /v2/pos/sign，headers **只有** timestamp + nonceStr（冇 signature header、冇 appId header），
 *   body `{appId, appSecret}`；code 10000 後 `data.platformPublicKey` / `data.appPrivateKey` 為 raw base64，
 *   Node crypto 用之前要包成 `-----BEGIN {TYPE} KEY-----` PEM。
 *
 * 參考文檔：https://docs-posserver.kpay-group.com/ （docsify SPA，掛 nginx HTTP Basic Auth）
 *   ⚠️ 文檔帳密**唔可以寫入任何版控檔案**（呢行曾經寫死過，已移除）。
 *   要用就由營運筆記／KPay 來信攞，以 shell 變數間接傳入：
 *     curl -sL -u "$KPAY_DOC_ID:$KPAY_DOC_PW" ".../zh-hk/apiv2/index.md"
 */

const crypto = require('crypto');
const { getKpayConfig } = require('../../database/db');

// ===== 配置 =====
const DEFAULT_KPOS_PORT = 18080;
// KPOS 無回應 timeout。預設 10000（行為不變）；可用 KPAY_HTTP_TIMEOUT_MS 覆寫。
// 實測卡機 WiFi 每次新建連線要 ~2.7 秒，10 秒對慢網路偏緊。
const HTTP_TIMEOUT_MS = parseInt(process.env.KPAY_HTTP_TIMEOUT_MS || '10000', 10);
// KPOS 收款預設 65 秒超時。2026-09-23 起 kpayRoutes 唔再用佢做查詢門檻
// （改成 STATUS_QUERY_INTERVAL_MS 節流），而家由 scripts/kpay-test.js 輪詢時用。
const SALES_TIMEOUT_MS = 65000;
// pending 期間向卡機送 POS_QR_QUERY 嘅最短間隔（節流）。
// 呢個係令卡機**提早離開正掃 QR 頁**嘅關鍵：實測客人付款後卡機會停留喺 QR 頁
// 足足 30 秒以上唔動（要等佢自己嘅計時器），但送 POS_QR_QUERY 後 4 秒內就完成。
// 見 MD Files/other/Kpay/KPAY_INTEGRATION_GUIDE.MD。
// ⚠️ 呢個係**最短間隔**，實際節奏仲受前端輪詢頻率限制：前端每 2 秒 poll 一次
// /api/kpay/status，而 nudge 只喺 poll 入面做，所以實際間隔 ≈ 設定值 + 最多 2 秒。
// 設 5000 時實測 7 秒一次（客人付款後 9 秒完成）；設 4000 會貼近 5 秒。
const QR_NUDGE_INTERVAL_MS = parseInt(process.env.KPAY_QR_NUDGE_INTERVAL_MS || '4000', 10);
// pending 期間向卡機讀 query 結果嘅最短間隔（後備：回調遺失時用）。
// 正常情況靠回調（即時且已驗證可靠），所以呢個可以疏啲。
// ⚠️ 兩個間隔都要節流：前端每 2 秒 poll 一次 /api/kpay/status，
//    而卡機對請求頻率極敏感（會回 50002 終端繁忙／50004 請求過於頻繁）。
const STATUS_QUERY_INTERVAL_MS = parseInt(process.env.KPAY_STATUS_QUERY_INTERVAL_MS || '15000', 10);

// 工作密鑰快取（每分店一份；結算/過期後要重簽）
const keyCache = {}; // store_id -> { appPrivateKey, platformPublicKey }

// mock 回調 handler（由 kpayRoutes 註冊，避免 circular dependency）
let _mockCallbackHandler = null;

function setMockCallbackHandler(fn) {
  _mockCallbackHandler = fn;
}

// 32 位隨機 nonceStr（官方要求；避免重放）
const NONCE_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
function genNonce() {
  const bytes = crypto.randomBytes(32);
  let out = '';
  for (let i = 0; i < 32; i += 1) {
    out += NONCE_CHARS[bytes[i] % NONCE_CHARS.length];
  }
  return out;
}

// ===== 配置 =====
async function getConfig(storeId) {
  const row = await getKpayConfig(storeId);
  const cfg = {
    mode: (process.env.KPAY_MODE || 'mock'),          // mock | lan
    kpos_ip: process.env.KPAY_KPOS_IP || '192.168.3.200',
    kpos_port: parseInt(process.env.KPAY_KPOS_PORT || String(DEFAULT_KPOS_PORT), 10),
    app_id: process.env.KPAY_APP_ID || '',
    app_secret: process.env.KPAY_APP_SECRET || '',
    callback_url: process.env.KPAY_CALLBACK_URL || '',
    // Kiosk 模式終端操作回調（未設定時由 callback_url 推導：同主機、路徑換為
    // /api/kpay/action-callback）。Kiosk 模式下簽到必填，否則 action 回 700017。
    action_callback_url: process.env.KPAY_ACTION_CALLBACK_URL || ''
  };
  if (!cfg.action_callback_url && cfg.callback_url) {
    try {
      const u = new URL(cfg.callback_url);
      u.pathname = '/api/kpay/action-callback';
      cfg.action_callback_url = u.toString();
    } catch (_) { /* callback_url 不合法就留空 */ }
  }
  // 分店 kpay_configs 覆寫 .env fallback（⚠️ 唔好 populate kpay_configs 表：schema 預設 mode='lan'，
  // 有 row 會 silent 覆蓋 .env —— 見 MD Files/KPAY_INTEGRATION_GUIDE.MD）
  if (row) {
    if (row.mode) cfg.mode = row.mode;
    if (row.kpos_ip) cfg.kpos_ip = row.kpos_ip;
    if (row.kpos_port) cfg.kpos_port = row.kpos_port;
    if (row.app_id) cfg.app_id = row.app_id;
    if (row.app_secret) cfg.app_secret = row.app_secret;
    if (row.callback_url) cfg.callback_url = row.callback_url;
  }
  return cfg;
}

// ===== 金額格式化：12 位零填充最小貨幣單位（$1.00 → "000000000100"）=====
function formatAmount(amount) {
  const cents = Math.round(Number(amount || 0) * 100);
  return String(cents).padStart(12, '0');
}

// 官方 API 嘅金額欄位本身就係 12 位零填充字串。若 caller 直接轉發官方格式
// （例如 route 層原樣 passthrough），再用 formatAmount 會**二次格式化**（100 分變 10000 分）。
// 呢個 helper 自動判斷：已經係 12 位數字就原樣用，否則當金額去 format。
function toAmount12(v) {
  const s = String(v === undefined || v === null ? 0 : v);
  return /^\d{12}$/.test(s) ? s : formatAmount(v);
}

// ===== PEM helper：KPay 工作密鑰係 raw base64，Node crypto 要用之前包返 PEM =====
// raw / 已帶 armor / 帶換行 都支援（剝走現有 armor + 空白後再包）
function toPem(raw, type) {
  const body = String(raw || '')
    .replace(/-----BEGIN [A-Z ]*KEY-----/g, '')
    .replace(/-----END [A-Z ]*KEY-----/g, '')
    .replace(/\s+/g, '');
  return `-----BEGIN ${type} KEY-----\n${body}\n-----END ${type} KEY-----`;
}

// ===== 簽名 =====
// body 有先至加 body 行（GET / body 空 → 4 行）；每行以 \n 結尾（含最後一行）
function buildSignatureContent(method, path, timestamp, nonceStr, body) {
  const lines = [method, path, String(timestamp), String(nonceStr)];
  if (body !== undefined && body !== null && body !== '') lines.push(body);
  return lines.join('\n') + '\n';
}

function signContent(content, privateKey) {
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(content, 'utf8');
  return signer.sign(toPem(privateKey, 'PRIVATE'), 'base64');
}

function verifyContent(content, signature, publicKey) {
  try {
    const verifier = crypto.createVerify('RSA-SHA256');
    verifier.update(content, 'utf8');
    return verifier.verify(toPem(publicKey, 'PUBLIC'), signature, 'base64');
  } catch (e) {
    console.error('[kpay] 驗簽錯誤:', e.message);
    return false;
  }
}

// ===== HTTP（仿 aliyunProxyRoutes：global fetch + AbortController timeout）=====
async function httpPost(url, payload, headers) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), HTTP_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...headers },
      body: JSON.stringify(payload),
      signal: controller.signal
    });
    clearTimeout(timer);
    return await res.json();
  } catch (e) {
    clearTimeout(timer);
    if (e.name === 'AbortError') throw new Error(`KPOS 無回應（超過 ${HTTP_TIMEOUT_MS / 1000} 秒）`);
    throw e;
  }
}

async function httpGet(url, headers) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), HTTP_TIMEOUT_MS);
  try {
    const res = await fetch(url, { method: 'GET', headers, signal: controller.signal });
    clearTimeout(timer);
    return await res.json();
  } catch (e) {
    clearTimeout(timer);
    if (e.name === 'AbortError') throw new Error(`KPOS 無回應（超過 ${HTTP_TIMEOUT_MS / 1000} 秒）`);
    throw e;
  }
}

// ===== 簽名 header：timestamp + nonceStr 每次重新生成（防重放，retry 都要新簽）=====
function authHeaders(cfg, keys, method, path, body) {
  const timestamp = Date.now();
  const nonceStr = genNonce();
  const content = buildSignatureContent(method, path, timestamp, nonceStr, body);
  const signature = signContent(content, keys.appPrivateKey);
  return { appId: cfg.app_id, timestamp: String(timestamp), nonceStr, signature };
}

// ===== 40004（工作密鑰失效）→ 清 cache + 原樣重試一次（makeRequest 內部會重簽）=====
async function requestWithKeyRefresh(storeId, makeRequest) {
  let result = await makeRequest();
  if (result && result.code === 40004) {
    clearKeys(storeId);
    console.warn('[kpay] 工作密鑰失效（40004），重簽後重試一次');
    result = await makeRequest();
  }
  return result;
}

// ===== 簽到：換工作密鑰（appPrivateKey + platformPublicKey）=====
// 官方：POST /v2/pos/sign，headers 只有 timestamp + nonceStr（冇 signature header、冇 appId header）
async function sign(storeId) {
  const cfg = await getConfig(storeId);
  if (cfg.mode === 'mock') {
    return { appPrivateKey: 'mock-private-key', platformPublicKey: 'mock-public-key' };
  }
  if (keyCache[storeId]) return keyCache[storeId];
  if (!cfg.app_id || !cfg.app_secret) {
    throw new Error('KPay 未配置：缺少 appId/appSecret');
  }
  const timestamp = Date.now();
  const nonceStr = genNonce();
  const path = '/v2/pos/sign';
  const payload = { appId: cfg.app_id, appSecret: cfg.app_secret };
  // Kiosk 模式必填：終端操作（/v2/pos/action）的回調地址。
  // 實測未設定時，action 會回 700017「ActionCallback未設置」。
  if (cfg.action_callback_url) payload.actionCallbackUrl = cfg.action_callback_url;

  const result = await httpPost(`http://${cfg.kpos_ip}:${cfg.kpos_port}${path}`, payload, {
    timestamp: String(timestamp),
    nonceStr
  });

  if (!result || result.code !== 10000) {
    throw new Error('KPay 簽到失敗: ' + JSON.stringify(result));
  }
  // keys 喺 result.data 下面（保平安 fallback 埋 top-level）
  const d = (result.data && typeof result.data === 'object') ? result.data : result;
  if (!d || !d.appPrivateKey || !d.platformPublicKey) {
    throw new Error('KPay 簽到缺少工作密鑰: ' + JSON.stringify(result));
  }
  keyCache[storeId] = {
    appPrivateKey: d.appPrivateKey,
    platformPublicKey: d.platformPublicKey
  };
  return keyCache[storeId];
}

function clearKeys(storeId) {
  delete keyCache[storeId];
}

// ===== 消費（KPOS 彈收款畫面）=====
// 回 code：10000 成功、11000 已轉前台收款（正常等待付款）、40001/40002/40004 認證/簽名/密鑰問題、50002 終端忙碌
async function sales({ outTradeNo, amount, paymentType, callbackUrl, description, storeId, frontCamera }) {
  const cfg = await getConfig(storeId);

  if (cfg.mode === 'mock') {
    // mock：3 秒後模擬成功回調（行同一 idempotent callback handler）
    console.log(`[kpay][mock] 模擬收款: outTradeNo=${outTradeNo}, amount=${amount}, paymentType=${paymentType}`);
    if (_mockCallbackHandler) {
      setTimeout(() => {
        _mockCallbackHandler({
          outTradeNO: outTradeNo,
          payAmount: formatAmount(amount),
          payResult: 2, // 成功
          payMethod: 0,
          transactionNo: 'MOCK-TXN-' + Date.now(),
          refNo: 'MOCK-REF-' + Date.now(),
          storeId
        }).catch(err => console.error('[kpay][mock] 模擬回調處理錯誤:', err));
      }, 3000);
    }
    return { code: 11000, data: { outTradeNo, status: 'PAYING' } };
  }

  const path = '/v2/pos/sales';
  const payload = {
    outTradeNo,
    description: description || '自動咖啡館離場結賬',
    payAmount: formatAmount(amount),
    tipsAmount: formatAmount(0),
    paymentType,
    payCurrency: '344' // HKD
  };
  // callbackUrl 有先至送（分店實際 callbackUrl 先係 signature 綁定嗰個 path）
  if (callbackUrl) payload.callbackUrl = callbackUrl;
  // 反掃類型（3 微信／支付寶、7 PayMe）→ 用**前鏡頭**：
  // 離場機係自助 Kiosk，客人企喺卡機前面出示手機付款碼。2026-09-17 真機實測可正常付款。
  // ⚠️ frontCamera 只收布林值（送 1 會回 10001 參數無效）；
  //    正掃類型（8 轉數快）**唔可以**送，送咗畫面會變「二維碼無效」。
  if (frontCamera) payload.frontCamera = true;
  // 其餘唔送：memberCode（會員編號）、qrCodeContent（Kiosk 預先取得嘅付款碼內容）目前用唔著

  const makeRequest = async () => {
    const keys = await sign(storeId);
    const headers = authHeaders(cfg, keys, 'POST', path, JSON.stringify(payload));
    return httpPost(`http://${cfg.kpos_ip}:${cfg.kpos_port}${path}`, payload, headers);
  };

  const result = await requestWithKeyRefresh(storeId, makeRequest);

  // ⚠️ Kiosk 模式**唔支援小費**：送咗 tipsAmount 會回 700004「Kiosk 模式不支持小費」。
  // 真機實測：同一請求去掉 tipsAmount 即成功（2026-09-23）。
  // 呢度自動退回重試一次 —— 同一份 code 同時支援標準模式（要送）同 Kiosk 模式（唔可以送），
  // 唔需要人手設定模式旗標，亦唔怕設定同卡機實際模式唔一致。
  if (result && result.code === 700004 && payload.tipsAmount !== undefined) {
    console.log('[kpay] Kiosk 模式不支援小費，去掉 tipsAmount 後重試');
    delete payload.tipsAmount;
    // KPOS 對連續請求敏感：實測即刻重試會回 50004「請求過於頻繁」，要等一等
    await new Promise((r) => setTimeout(r, 3000));
    return requestWithKeyRefresh(storeId, makeRequest);
  }
  return result;
}

// ===== 主動查詢（65 秒內收唔到回調要 query；KPay 上線測試強制要求）=====
async function query(outTradeNo, storeId) {
  const cfg = await getConfig(storeId);
  if (cfg.mode === 'mock') {
    return { code: 20011, data: { outTradeNo, status: 'PAYING' } };
  }
  const path = '/v2/pos/query?outTradeNo=' + encodeURIComponent(outTradeNo);

  const makeRequest = async () => {
    const keys = await sign(storeId);
    const headers = authHeaders(cfg, keys, 'GET', path, '');
    return httpGet(`http://${cfg.kpos_ip}:${cfg.kpos_port}${path}`, headers);
  };
  return requestWithKeyRefresh(storeId, makeRequest);
}

// ===== 關閉「進行中未付款」嘅銷售（取消取消單時用）=====
// POST /v2/pos/sales/close，body 淨 `{outTradeNo}`。
// 注意：/v2/pos/sales/cancel 係撤銷「已成交未結算」交易（要 originOutTradeNo），離場機取消唔用。
async function close(outTradeNo, storeId) {
  const cfg = await getConfig(storeId);
  if (cfg.mode === 'mock') {
    return { code: 10000, data: { outTradeNo } };
  }
  const path = '/v2/pos/sales/close';
  const payload = { outTradeNo };

  const makeRequest = async () => {
    const keys = await sign(storeId);
    const headers = authHeaders(cfg, keys, 'POST', path, JSON.stringify(payload));
    return httpPost(`http://${cfg.kpos_ip}:${cfg.kpos_port}${path}`, payload, headers);
  };
  return requestWithKeyRefresh(storeId, makeRequest);
}

// ===== 敏感欄位加密 =====
// 官方要求：managerPassword 要用簽到返回嘅 platformPublicKey 做 RSA 加密先可以傳。
// 用 PKCS#1 v1.5 padding（Java 端 Cipher.getInstance("RSA/ECB/PKCS1Padding") 對應）。
function encryptWithPlatformKey(text, publicKeyRaw) {
  return crypto
    .publicEncrypt(
      { key: toPem(publicKeyRaw, 'PUBLIC'), padding: crypto.constants.RSA_PKCS1_PADDING },
      Buffer.from(String(text), 'utf8')
    )
    .toString('base64');
}

// ===== 撤銷（當日**未結算**嘅已成交交易）=====
// POST /v2/pos/sales/cancel。要 originOutTradeNo（＝原本 sales 上送嘅 outTradeNo）。
// ⚠️ 只可以撤銷「當日未結算」嘅交易；已結算嘅要用 refund()。
// managerPassword 可選：送咗就跳過卡機上嘅管理員密碼校驗。
async function cancelTransaction({
  outTradeNo, originOutTradeNo, managerPassword, callbackUrl, includeReceipt, storeId
}) {
  const cfg = await getConfig(storeId);
  if (cfg.mode === 'mock') {
    console.log(`[kpay][mock] 模擬撤銷: 原單=${originOutTradeNo} 新單=${outTradeNo}`);
    return { code: 10000, message: 'Success' };
  }
  if (!outTradeNo || !originOutTradeNo) {
    throw new Error('KPay 撤銷需要 outTradeNo 同 originOutTradeNo');
  }

  const path = '/v2/pos/sales/cancel';
  const payload = { outTradeNo, originOutTradeNo };
  if (callbackUrl) payload.callbackUrl = callbackUrl;
  if (includeReceipt !== undefined) payload.includeReceipt = includeReceipt;
  // 送咗管理員密碼就跳過卡機上嘅密碼校驗（自動化撤銷唔想有人喺卡機前面按）
  const adminPassword = managerPassword || process.env.KPAY_MANAGER_PASSWORD || '';
  if (adminPassword) {
    const keys = await sign(storeId);
    payload.managerPassword = encryptWithPlatformKey(adminPassword, keys.platformPublicKey);
  }

  const makeRequest = async () => {
    const keys = await sign(storeId);
    const headers = authHeaders(cfg, keys, 'POST', path, JSON.stringify(payload));
    return httpPost(`http://${cfg.kpos_ip}:${cfg.kpos_port}${path}`, payload, headers);
  };
  return requestWithKeyRefresh(storeId, makeRequest);
}

// ===== 退款（**已結算**嘅交易；原路返還）=====
// POST /v2/pos/sales/refund。
//   refundType 1 = 卡類  → 要 refNo + commitTime（原交易提交時間 UTC ms）
//   refundType 2 = 二維碼 → 要 transactionNo（KPay 商戶訂單號）
// refundAmount 傳「金額」（例如 12.5），內部轉 12 位零填充；唔傳 = 全額退款。
// managerPassword 必填，會用 platformPublicKey RSA 加密後上送。
async function refund({
  outTradeNo, refundType, transactionNo, refNo, commitTime,
  refundAmount, managerPassword, callbackUrl, includeReceipt, storeId
}) {
  const cfg = await getConfig(storeId);
  if (cfg.mode === 'mock') {
    console.log(`[kpay][mock] 模擬退款: 新單=${outTradeNo} type=${refundType} 金額=${refundAmount || '全額'}`);
    return { code: 10000, message: 'Success' };
  }
  if (!outTradeNo) throw new Error('KPay 退款需要 outTradeNo');
  if (refundType !== 1 && refundType !== 2) throw new Error('KPay 退款 refundType 只可以係 1（卡類）或 2（二維碼）');
  if (refundType === 2 && !transactionNo) throw new Error('二維碼退款需要 transactionNo');
  if (refundType === 1 && (!refNo || !commitTime)) throw new Error('卡類退款需要 refNo 同 commitTime');

  // 管理員密碼：參數優先，否則讀 .env（每店一份，同其他 KPAY_* 一致）
  const adminPassword = managerPassword || process.env.KPAY_MANAGER_PASSWORD || '';
  if (!adminPassword) {
    throw new Error('KPay 退款需要管理員密碼：請設定 .env 嘅 KPAY_MANAGER_PASSWORD');
  }

  const path = '/v2/pos/sales/refund';
  const payload = { outTradeNo, refundType };
  if (transactionNo) payload.transactionNo = transactionNo;
  if (refNo) payload.refNo = refNo;
  if (commitTime) payload.commitTime = commitTime;
  if (refundAmount !== undefined && refundAmount !== null) {
    payload.refundAmount = formatAmount(refundAmount);
  }
  if (callbackUrl) payload.callbackUrl = callbackUrl;
  if (includeReceipt !== undefined) payload.includeReceipt = includeReceipt;

  const keys = await sign(storeId);
  payload.managerPassword = encryptWithPlatformKey(adminPassword, keys.platformPublicKey);

  const makeRequest = async () => {
    const k = await sign(storeId);
    const headers = authHeaders(cfg, k, 'POST', path, JSON.stringify(payload));
    return httpPost(`http://${cfg.kpos_ip}:${cfg.kpos_port}${path}`, payload, headers);
  };
  return requestWithKeyRefresh(storeId, makeRequest);
}

// ============================================================================
// 通用簽名請求 helper（畀下面嘅擴充 API 用）
// ⚠️ sales / refund / cancelTransaction / close 保持原本寫法唔郁 —— 嗰啲已經真機驗證過，
//    唔想為咗去重複而改壞已知可用嘅路徑。
// ============================================================================

// 通用 POST：自動簽名、managerPassword RSA 加密、40004/40001 重簽
async function postSigned(path, payload, { storeId, managerPassword, mockResult } = {}) {
  const cfg = await getConfig(storeId);
  if (cfg.mode === 'mock') {
    console.log(`[kpay][mock] ${path} payload=${JSON.stringify(payload)}`);
    return mockResult || { code: 10000, message: 'Success' };
  }
  const body = { ...payload };
  if (managerPassword) {
    const keys = await sign(storeId);
    body.managerPassword = encryptWithPlatformKey(managerPassword, keys.platformPublicKey);
  }
  const makeRequest = async () => {
    const keys = await sign(storeId);
    const headers = authHeaders(cfg, keys, 'POST', path, JSON.stringify(body));
    return httpPost(`http://${cfg.kpos_ip}:${cfg.kpos_port}${path}`, body, headers);
  };
  return requestWithKeyRefresh(storeId, makeRequest);
}

// 通用 GET（簽名係 4 行，冇 body 行）
async function getSigned(pathWithQuery, { storeId, mockResult } = {}) {
  const cfg = await getConfig(storeId);
  if (cfg.mode === 'mock') {
    console.log(`[kpay][mock] GET ${pathWithQuery}`);
    return mockResult || { code: 10000, message: 'Success' };
  }
  const makeRequest = async () => {
    const keys = await sign(storeId);
    // 簽名用嘅 path 要同實際請求一致（含 query string）
    const headers = authHeaders(cfg, keys, 'GET', pathWithQuery, '');
    return httpGet(`http://${cfg.kpos_ip}:${cfg.kpos_port}${pathWithQuery}`, headers);
  };
  return requestWithKeyRefresh(storeId, makeRequest);
}

// ===== 結算 & 簽退 =====
// POST /v2/pos/settlement。三個欄位都係 REQUIRED Boolean。
// autoSignIn=true → 結算成功後自動重新簽到（默認 false，即結算完要自己再 sign）。
// ⚠️ 結算後工作密鑰會失效，所以成功後清 cache，下次請求自動重簽。
async function settlement({
  settlementReceipt = true, detailsReceipt = true, autoSignIn = true, flushAfter = true, storeId
} = {}) {
  const result = await postSigned('/v2/pos/settlement', {
    settlementReceipt: !!settlementReceipt,
    detailsReceipt: !!detailsReceipt,
    autoSignIn: !!autoSignIn
  }, { storeId });

  if (result && result.code === 10000) {
    clearKeys(storeId);
    console.log('[kpay] 結算完成，已清工作密鑰 cache（下次請求會重新簽到）');

    // 結算小票係卡機自己印嘅，我哋控制唔到佢嘅尾巴 → 補一個走紙指令逼出緩衝區。
    // （真機實測：唔補嘅話總金額會印唔出，出現喺下一張小票頂部）
    if (flushAfter && (settlementReceipt || detailsReceipt)) {
      await new Promise((r) => setTimeout(r, 3000)); // 等卡機印完
      try {
        await postSigned('/v2/pos/print',
          { steps: [{ printType: 'FEED', feedLine: PRINT_TAIL_FEED_LINES }] },
          { storeId });
        console.log('[kpay] 結算小票已補走紙（逼出緩衝區）');
      } catch (e) {
        console.warn('[kpay] 結算後補走紙失敗（唔影響結算本身）:', e.message);
      }
    }
  }
  return result;
}

// ===== 查詢結算數據 =====
// GET /v2/pos/query/settlement；previousBatch=true 查上一批
async function querySettlement({ previousBatch, storeId } = {}) {
  const qs = previousBatch ? '?previousBatch=true' : '';
  return getSigned('/v2/pos/query/settlement' + qs, { storeId });
}

// ===== 打印自定義小票 =====
// POST /v2/pos/print
// ⚠️ 官方 body 係 { steps: [...] } —— 一個**陣列**，每項一個打印指令。
//    真機實測：傳扁平物件（printType 喺頂層）會回 10001 參數無效。
// printType：TEXT 文字 / LR_TEXT 同行左右 / QR_CODE 二維碼 / BAR_CODE 條形碼 / IMAGE 圖片 / FEED 換行
// textSize：S / M / L（默認 M）；alignment：LEFT / RIGHT / CENTER（默認 LEFT，只對 TEXT 有效）
// 熱敏打印機切紙前要行夠紙，令最後幾行完全離開打印頭，否則**票尾會被切走／印唔完整**。
// 真機實測：唔補走紙的話，票尾不完整，最後一行甚至會留喺緩衝區、出現喺下一張小票頂部。
// 5 行係起始值，按實際出紙效果調整。
// 8 行：真機實測 5 行時票尾完整但幾乎冇可見空白（切紙可能食咗一部分），
// 15 行則空白過多浪費紙。8 行係折衷，可用 KPAY_PRINT_TAIL_FEED_LINES 覆寫。
const PRINT_TAIL_FEED_LINES = parseInt(process.env.KPAY_PRINT_TAIL_FEED_LINES || '8', 10);

async function print({ steps, storeId, autoFeed = true, ...single } = {}) {
  // 容許傳單一指令（printType 喺頂層），自動包成 steps 陣列，方便單行小票
  const list = Array.isArray(steps) ? [...steps] : (single && single.printType ? [single] : null);
  if (!list || list.length === 0) {
    throw new Error('KPay 打印需要 steps 陣列（每項一個打印指令），或單一 printType 指令');
  }
  // 尾隨走紙：逼出緩衝區 + 令票尾離開打印頭
  if (autoFeed && list[list.length - 1].printType !== 'FEED') {
    list.push({ printType: 'FEED', feedLine: PRINT_TAIL_FEED_LINES });
  }
  return postSigned('/v2/pos/print', { steps: list }, { storeId });
}

// ===== 查詢終端狀態 =====
// GET /v2/pos/status/query（冇請求數據，只有 header）
async function terminalStatus({ storeId } = {}) {
  return getSigned('/v2/pos/status/query', { storeId });
}

// ===== 終端操作指令（Kiosk 模式）=====
// POST /v2/pos/action；官方文件示範 action="POS_SIGNIN"
async function action({ action: act, storeId } = {}) {
  if (!act) throw new Error('KPay 終端操作需要 action');
  return postSigned('/v2/pos/action', { action: act }, { storeId });
}

// ===== Kiosk 正掃：叫卡機離開 QR 頁 =====
// 離場機係自助 Kiosk，客人掃卡機螢幕嘅 QR 付款。付款成功後卡機仍會停留喺正掃 QR 頁
// 好耐，客人容易誤以為未付款成功。送 POS_QR_QUERY（正掃 - 查詢交易結果）可令佢提早
// 顯示「收款完成」。
//
// 實測（2026-09-23 真機，關鍵數據）：
//   客人 17:19:29 付款，之後每 3 秒查一次 query，**到 17:19:59（付款後 30 秒）
//   全部都係 payResult=1**，卡機完全冇動；17:19:59 送 POS_QR_QUERY →
//   17:20:03（4 秒後）payResult=2。即係卡機會停留喺 QR 頁等自己嘅計時器
//   （無介入時三次實測都係 ~70 秒），而呢個指令可以即刻推佢去查結果。
//   - 未付款時盲送亦安全：回 10000，交易完好（payResult 保持 1）→ 可以放心週期性送。
//   - 卡機已自行離開 QR 頁 → 50002「終端繁忙」，持續幾分鐘。
//     ⚠️ 呢個 50002 唔係真嘅繁忙：同一時間 status/query 回 91000 Normal、query 正常。
//     實質意思係「呢個指令唔適用於卡機當前頁面」（官方 /v2/pos/status/query 文件
//     亦咁講：Kiosk 模式下會撞到 50002，要用 status/query 查終端當前狀態再決定送邊個 action）。
//
// ⚠️ 純畫面體驗：失敗**絕不影響結賬**。內部吞掉所有錯誤（連 action() throw 都接住），
//    所以呼叫方可以放心唔 await，唔會產生 unhandled rejection。
async function dismissQrPage(storeId) {
  try {
    const r = await action({ action: 'POS_QR_QUERY', storeId });
    const code = r && r.code;
    if (code === 10000) {
      console.log('[kpay] 已叫卡機查交易結果（POS_QR_QUERY）');
    } else if (code !== 50002) {
      // 50002 = 卡機唔喺正掃 QR 頁（已自行離開／未進入）。呢個係預期情況，
      // 而 pending 期間每 5 秒會送一次，所以**刻意唔記 log**，否則會洗版。
      console.log(`[kpay] POS_QR_QUERY 非預期回應（code=${code}）—— 唔影響結賬`);
    }
  } catch (e) {
    console.log(`[kpay] POS_QR_QUERY 出錯: ${e.message} —— 唔影響結賬`);
  }
}

// ===== 小費調整 =====
// POST /v2/pos/tip/adjustment；outTradeNo 係**新**單號，originOutTradeNo 係原消費單號
async function tipAdjustment({
  outTradeNo, originOutTradeNo, tipsAmount, callbackUrl, includeReceipt, storeId
} = {}) {
  if (!outTradeNo || !originOutTradeNo) throw new Error('小費調整需要 outTradeNo 同 originOutTradeNo');
  const payload = {
    outTradeNo,
    originOutTradeNo,
    tipsAmount: toAmount12(tipsAmount || 0)
  };
  if (callbackUrl) payload.callbackUrl = callbackUrl;
  if (includeReceipt !== undefined) payload.includeReceipt = includeReceipt;
  return postSigned('/v2/pos/tip/adjustment', payload, { storeId });
}

// ===== 小費調整撤銷 =====
// POST /v2/pos/tip/adjustment/cancel；managerPassword 可選
async function tipAdjustmentCancel({
  outTradeNo, originOutTradeNo, callbackUrl, includeReceipt, managerPassword, storeId
} = {}) {
  if (!outTradeNo || !originOutTradeNo) throw new Error('小費調整撤銷需要 outTradeNo 同 originOutTradeNo');
  const payload = { outTradeNo, originOutTradeNo };
  if (callbackUrl) payload.callbackUrl = callbackUrl;
  if (includeReceipt !== undefined) payload.includeReceipt = includeReceipt;
  return postSigned('/v2/pos/tip/adjustment/cancel', payload, {
    storeId,
    managerPassword: managerPassword || process.env.KPAY_MANAGER_PASSWORD || ''
  });
}

// ===== 離線消費交易 =====
// POST /v2/pos/offline/sales（網絡唔通時先入卡機，之後補傳）
async function offlineSales({
  outTradeNo, description, payAmount, tipsAmount, paymentType, payCurrency,
  callbackUrl, includeReceipt, remark, discountAmount, discountDescription, storeId
} = {}) {
  if (!outTradeNo) throw new Error('離線消費需要 outTradeNo');
  const payload = {
    outTradeNo,
    payAmount: toAmount12(payAmount),
    tipsAmount: toAmount12(tipsAmount || 0),
    payCurrency: payCurrency || '344'
  };
  if (description) payload.description = description;
  if (paymentType !== undefined) payload.paymentType = paymentType;
  if (callbackUrl) payload.callbackUrl = callbackUrl;
  if (includeReceipt !== undefined) payload.includeReceipt = includeReceipt;
  if (remark) payload.remark = remark;
  if (discountAmount !== undefined) payload.discountAmount = toAmount12(discountAmount);
  if (discountDescription) payload.discountDescription = discountDescription;
  return postSigned('/v2/pos/offline/sales', payload, { storeId });
}

// ===== 取消離線交易 =====
// POST /v2/pos/offline/sales/cancel；managerPassword 可選
async function offlineSalesCancel({
  outTradeNo, originOutTradeNo, callbackUrl, includeReceipt, managerPassword, storeId
} = {}) {
  if (!outTradeNo || !originOutTradeNo) throw new Error('取消離線交易需要 outTradeNo 同 originOutTradeNo');
  const payload = { outTradeNo, originOutTradeNo };
  if (callbackUrl) payload.callbackUrl = callbackUrl;
  if (includeReceipt !== undefined) payload.includeReceipt = includeReceipt;
  return postSigned('/v2/pos/offline/sales/cancel', payload, {
    storeId,
    managerPassword: managerPassword || process.env.KPAY_MANAGER_PASSWORD || ''
  });
}

// ===== 預授權系列（5 支）=====
// 全部要 managerPassword（除咗發起）；refNo + commitTime 係卡類交易識別
const PREAUTH_PATHS = {
  preauth: '/v2/pos/preauth',
  adjustment: '/v2/pos/preauth/adjustment',
  cancel: '/v2/pos/preauth/cancel',
  complete: '/v2/pos/preauth/complete',
  completeCancel: '/v2/pos/preauth/complete/cancel'
};

// 發起預授權：POST /v2/pos/preauth（唔使 managerPassword）
async function preauth({
  outTradeNo, description, payAmount, payCurrency, callbackUrl, includeReceipt, remark, storeId
} = {}) {
  if (!outTradeNo) throw new Error('預授權需要 outTradeNo');
  const payload = {
    outTradeNo,
    payAmount: toAmount12(payAmount),
    payCurrency: payCurrency || '344'
  };
  if (description) payload.description = description;
  if (callbackUrl) payload.callbackUrl = callbackUrl;
  if (includeReceipt !== undefined) payload.includeReceipt = includeReceipt;
  if (remark) payload.remark = remark;
  return postSigned(PREAUTH_PATHS.preauth, payload, { storeId });
}

// 預授權調整：adjustAmount 必填；decreaseAmount=true 表示減少
async function preauthAdjustment({
  outTradeNo, refNo, commitTime, adjustAmount, decreaseAmount,
  callbackUrl, includeReceipt, managerPassword, storeId
} = {}) {
  if (!outTradeNo) throw new Error('預授權調整需要 outTradeNo');
  const payload = {
    outTradeNo,
    adjustAmount: toAmount12(adjustAmount)
  };
  if (refNo) payload.refNo = refNo;
  if (commitTime) payload.commitTime = commitTime;
  if (decreaseAmount !== undefined) payload.decreaseAmount = decreaseAmount;
  if (callbackUrl) payload.callbackUrl = callbackUrl;
  if (includeReceipt !== undefined) payload.includeReceipt = includeReceipt;
  return postSigned(PREAUTH_PATHS.adjustment, payload, {
    storeId,
    managerPassword: managerPassword || process.env.KPAY_MANAGER_PASSWORD || ''
  });
}

// 預授權撤銷
async function preauthCancel({
  outTradeNo, refNo, commitTime, callbackUrl, includeReceipt, managerPassword, storeId
} = {}) {
  if (!outTradeNo) throw new Error('預授權撤銷需要 outTradeNo');
  const payload = { outTradeNo };
  if (refNo) payload.refNo = refNo;
  if (commitTime) payload.commitTime = commitTime;
  if (callbackUrl) payload.callbackUrl = callbackUrl;
  if (includeReceipt !== undefined) payload.includeReceipt = includeReceipt;
  return postSigned(PREAUTH_PATHS.cancel, payload, {
    storeId,
    managerPassword: managerPassword || process.env.KPAY_MANAGER_PASSWORD || ''
  });
}

// 預授權完成（扣款）；partialComplete=true 表示部分完成
async function preauthComplete({
  outTradeNo, refNo, commitTime, completeAmount, partialComplete,
  callbackUrl, includeReceipt, managerPassword, storeId
} = {}) {
  if (!outTradeNo) throw new Error('預授權完成需要 outTradeNo');
  const payload = {
    outTradeNo,
    completeAmount: toAmount12(completeAmount)
  };
  if (refNo) payload.refNo = refNo;
  if (commitTime) payload.commitTime = commitTime;
  if (partialComplete !== undefined) payload.partialComplete = partialComplete;
  if (callbackUrl) payload.callbackUrl = callbackUrl;
  if (includeReceipt !== undefined) payload.includeReceipt = includeReceipt;
  return postSigned(PREAUTH_PATHS.complete, payload, {
    storeId,
    managerPassword: managerPassword || process.env.KPAY_MANAGER_PASSWORD || ''
  });
}

// 預授權完成撤銷（撤銷已扣嘅款）
async function preauthCompleteCancel({
  outTradeNo, refNo, commitTime, callbackUrl, includeReceipt, managerPassword, storeId
} = {}) {
  if (!outTradeNo) throw new Error('預授權完成撤銷需要 outTradeNo');
  const payload = { outTradeNo };
  if (refNo) payload.refNo = refNo;
  if (commitTime) payload.commitTime = commitTime;
  if (callbackUrl) payload.callbackUrl = callbackUrl;
  if (includeReceipt !== undefined) payload.includeReceipt = includeReceipt;
  return postSigned(PREAUTH_PATHS.completeCancel, payload, {
    storeId,
    managerPassword: managerPassword || process.env.KPAY_MANAGER_PASSWORD || ''
  });
}

// ===== 驗回調簽名（KPOS POST 過嚟，必須驗簽）=====
// mock 模式跳過驗簽；lan 模式用 platformPublicKey 驗「POST\n{callback_url path}\nts\nnonce\n{raw body}\n」。
// path 一定要用 cfg.callback_url 嘅實際 path（簽名綁死呢個 path，改咗就驗唔過）。
async function verifyCallback({ headers, body, rawBody, storeId }) {
  const cfg = await getConfig(storeId);
  if (cfg.mode === 'mock') return true;
  if (!cfg.callback_url) {
    // LAN 冇 callback_url = 冇嘢可驗，fail closed（唔好放唔可驗證嘅回調入嚟）
    console.error('[kpay] LAN 模式必須配置 KPAY_CALLBACK_URL 先可以驗回調簽名');
    return false;
  }
  let path = '/api/kpay/callback';
  try {
    path = new URL(cfg.callback_url).pathname;
  } catch (e) {
    console.warn('[kpay] KPAY_CALLBACK_URL 解析失敗，用預設 path 驗簽:', cfg.callback_url);
  }
  const keys = await sign(storeId);

  // ⚠️ Node/Express 會將 HTTP header 名**一律轉做全小寫**（HTTP 規範：header 名大小寫不敏感）。
  //    KPay 文件寫嘅係 `nonceStr`，但 req.headers 入面實際係 `noncestr` ——
  //    直接寫 headers.nonceStr 會永遠 undefined，令驗簽未計就 return false。
  //    2026-09-17 真機實測就係呢個 bug 令所有回調被拒。
  const getHeader = (name) => {
    const want = name.toLowerCase();
    const key = Object.keys(headers || {}).find((k) => k.toLowerCase() === want);
    return key ? headers[key] : undefined;
  };
  const signature = getHeader('signature');
  const timestamp = getHeader('timestamp');
  const nonceStr = getHeader('nonceStr');

  if (!signature || !timestamp || !nonceStr) {
    // 只印 header 名，唔印值（避免記錄簽名等敏感資料）
    console.error(
      '[kpay] 回調缺少必要 header（需要 signature/timestamp/nonceStr）。收到嘅 header 名：',
      Object.keys(headers || {}).join(', ')
    );
    return false;
  }

  // body 行要用原 byte（rawBody）；冇 rawBody 先至 fallback re-stringify（脆弱，LAN 唔可信）
  let bodyLine = rawBody !== undefined && rawBody !== null ? rawBody.toString('utf8') : null;
  if (bodyLine === null) {
    console.warn('[kpay] 冇 raw body，用 JSON.stringify 重組驗簽（唔可靠）');
    bodyLine = JSON.stringify(body || {});
  }
  const content = buildSignatureContent('POST', path, timestamp, nonceStr, bodyLine);
  return verifyContent(content, signature, keys.platformPublicKey);
}

module.exports = {
  getConfig,
  formatAmount,
  STATUS_QUERY_INTERVAL_MS,
  QR_NUDGE_INTERVAL_MS,
  toPem,
  buildSignatureContent,
  signContent,
  verifyContent,
  genNonce,
  sign,
  clearKeys,
  sales,
  query,
  close,
  cancelTransaction,
  refund,
  encryptWithPlatformKey,
  // 通用能力
  settlement,
  querySettlement,
  print,
  terminalStatus,
  action,
  dismissQrPage,
  // 小費
  tipAdjustment,
  tipAdjustmentCancel,
  // 離線交易
  offlineSales,
  offlineSalesCancel,
  // 預授權
  preauth,
  preauthAdjustment,
  preauthCancel,
  preauthComplete,
  preauthCompleteCancel,
  verifyCallback,
  setMockCallbackHandler,
  SALES_TIMEOUT_MS
};
