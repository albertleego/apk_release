// ─────────────────────────────────────────────────────────────
// WhatsApp Cloud API 客戶端（Meta Graph API）
//
// 職責：純 HTTP。唔碰 DB、唔碰 HTTP request/response object。
// 形狀跟 server/services/aiChatService.js：
//   · base URL 由 env 嚟
//   · isConfigured() / notConfiguredMessage()
//   · 明確嘅 timeout 常數
//   · global fetch + AbortController（跟 aliyunProxyRoutes.js:44-67 既有慣例）
//
// ⚠️ 絕對唔可以 log：access token、app secret、完整 request 選項物件。
//    logger 係同步 appendFileSync，而且倉庫有上傳日誌功能 —— 呢條係真實洩漏路徑。
//    要分辨「用緊邊條 token」時只用 maskToken()。
// ─────────────────────────────────────────────────────────────
'use strict';

const runtime = require('../config/runtime');

const GRAPH_VERSION = (process.env.WHATSAPP_GRAPH_VERSION || 'v21.0').trim();
const PHONE_NUMBER_ID = (process.env.WHATSAPP_PHONE_NUMBER_ID || '').trim();
const ACCESS_TOKEN = (process.env.WHATSAPP_ACCESS_TOKEN || '').trim();
// WABA ID：發訊息唔需要佢，但訊息模板（建立／列出／刪除）一定要經 WABA 層。
const WABA_ID = (process.env.WHATSAPP_WABA_ID || '').trim();
const SEND_TIMEOUT_MS = parseInt(process.env.WHATSAPP_SEND_TIMEOUT_MS, 10) || 15000;
// 單一媒體下載上限。媒體係即時向 Graph 串流、唔落碟，所以呢個係防止一次拉爆頻寬／記憶體。
const MEDIA_MAX_BYTES = parseInt(process.env.WHATSAPP_MEDIA_MAX_BYTES, 10) || 8 * 1024 * 1024;

const API_BASE = `https://graph.facebook.com/${GRAPH_VERSION}`;

// ── Meta 錯誤碼 → 俾用戶睇嘅文字 ──
// 全部用標準中文書面語（CLAUDE.md：界面文字唔可以用廣東話口語）。
// 前端直接顯示呢啲字串，唔好喺前端再砌一次。
const ERROR_TITLES = {
    131047: '已超過 24 小時客服窗口，無法發送。請客人再次發送訊息。',
    131026: '無法送達，對方可能未使用 WhatsApp。',
    190: 'WhatsApp 授權已失效，請檢查系統設定。',
    133010: '商業號碼尚未完成註冊。',
    368: 'WhatsApp 商業帳號目前受限制。',
    131031: 'WhatsApp 商業帳號目前受限制。',
    // 媒體相關（新增）
    131053: '媒體檔案格式不受支援，請改用 JPG／PNG 圖片、MP4 影片或 PDF 文件。',
    131052: '媒體檔案無法下載，請重新上傳附件。',
};

function isConfigured() {
    return Boolean(ACCESS_TOKEN && PHONE_NUMBER_ID);
}

function notConfiguredMessage() {
    if (!ACCESS_TOKEN) return '未設定 WHATSAPP_ACCESS_TOKEN';
    if (!PHONE_NUMBER_ID) return '未設定 WHATSAPP_PHONE_NUMBER_ID';
    return 'WhatsApp Cloud API 未設定';
}

/**
 * 標記一個「肯定冇送出」嘅錯誤。
 *
 * 用途：上層要分辨兩種失敗 ——
 *   · 肯定冇送出（設定錯、號碼無效）→ 可以安全重試
 *   · 模糊失敗（逾時、網絡中斷）→ 請求可能已經成功，重試有可能重複發送俾客人
 * 唔標記嘅錯誤一律當模糊處理（保守嗰邊）。
 */
function definitelyNotSent(message) {
    const err = new Error(message);
    err.definitelyNotSent = true;
    return err;
}

/** 只露最後 4 個字元 —— 用嚟分辨「用緊邊條 token」，唔可以印全條。 */
function maskToken() {
    if (!ACCESS_TOKEN) return '(未設定)';
    return ACCESS_TOKEN.length <= 4 ? '****' : `****${ACCESS_TOKEN.slice(-4)}`;
}

/** Graph API 錯誤 → 俾用戶睇嘅文字。冇對應碼就回一個安全嘅通用訊息。 */
function describeError(code) {
    if (code && ERROR_TITLES[code]) return ERROR_TITLES[code];
    return '發送失敗，請稍後再試。';
}

/**
 * 單一 Graph API 請求。所有出站呼叫都經呢度，方便統一 timeout 同錯誤形狀。
 * 唔會 log request body（可能含客人資料）。
 */
async function graphRequest(path, { method = 'POST', body = null, formData = null, timeoutMs = SEND_TIMEOUT_MS } = {}) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
        const headers = { Authorization: `Bearer ${ACCESS_TOKEN}` };
        let payload;
        if (formData) {
            // ⚠️ 用 FormData 時**絕對唔可以**自己設 Content-Type：
            //    fetch 要自己加 `multipart/form-data; boundary=...`，
            //    手動設就會冇 boundary，Meta 回 400 而檔案完全送唔出。
            payload = formData;
        } else if (body) {
            headers['Content-Type'] = 'application/json';
            payload = JSON.stringify(body);
        }
        const res = await fetch(`${API_BASE}${path}`, {
            method,
            headers,
            body: payload,
            signal: controller.signal,
        });
        clearTimeout(timer);

        const text = await res.text().catch(() => '');
        let json = null;
        try { json = text ? JSON.parse(text) : null; } catch (_) { /* 非 JSON 回應，下面照樣處理 */ }

        if (!res.ok) {
            const apiError = (json && json.error) || {};
            const err = new Error(`WhatsApp API ${res.status}: ${String(text).slice(0, 200)}`);
            err.httpStatus = res.status;
            err.apiCode = apiError.code;
            err.apiMessage = apiError.message;
            throw err;
        }
        return json;
    } catch (e) {
        clearTimeout(timer);
        if (e.name === 'AbortError') {
            // 逾時係「模糊失敗」：請求可能已經成功送出。上層要當 unknown，唔可以自動重試。
            const err = new Error(`WhatsApp API 無回應（超過 ${Math.round(timeoutMs / 1000)} 秒）`);
            err.isTimeout = true;
            throw err;
        }
        throw e;
    }
}

/**
 * 送出文字訊息。
 * @param {string} to 收件人 wa_id（純數字，不含 + 或 whatsapp: 前綴）
 * @returns {Promise<{dryRun: boolean, messageId: string}>}
 */
async function sendText(to, body) {
    const recipient = String(to || '').replace(/[^0-9]/g, '');
    if (!recipient) throw definitelyNotSent('收件人號碼無效');

    // DRY_RUN：完全唔打 Graph，回傳合成 wamid。
    // 令整個收件匣 UX（送出泡泡、失敗顯示、24 小時窗）可以零成本完整測試。
    // ⚠️ 一定要排喺 isConfigured() 檢查**之前** —— dry-run 嘅用意正正係
    //    未拿到憑證都可以行完整條流程。
    if (runtime.whatsappDryRun()) {
        // 只記尾 4 位 —— 客人電話號碼係個人資料，而日誌會被上傳。
        console.log(`[whatsapp] DRY_RUN 送出文字 → ****${recipient.slice(-4)} 長度=${String(body || '').length}`);
        return {
            dryRun: true,
            messageId: `dryrun.${Date.now()}.${Math.random().toString(36).slice(2, 10)}`,
        };
    }

    if (!isConfigured()) throw definitelyNotSent(notConfiguredMessage());

    const json = await graphRequest(`/${PHONE_NUMBER_ID}/messages`, {
        body: {
            messaging_product: 'whatsapp',
            recipient_type: 'individual',
            to: recipient,
            type: 'text',
            text: { preview_url: false, body: String(body || '') },
        },
    });

    const messageId = json && json.messages && json.messages[0] && json.messages[0].id;
    if (!messageId) throw new Error('WhatsApp API 回應沒有 message id');
    return { dryRun: false, messageId };
}

/**
 * 送出範本訊息。
 *
 * ⚠️ 範本係 Meta **唯一**允許喺 24 小時客服窗外發送嘅方式 —— 窗口關閉之後
 *    收件匣唯一可以跟進客人嘅方法就係呢個。
 *
 * @param {string} to 收件人 wa_id（純數字）
 * @param {{name:string, language:string, bodyParams?:string[]}} tpl
 * @returns {Promise<{dryRun: boolean, messageId: string}>}
 */
async function sendTemplate(to, tpl) {
    const recipient = String(to || '').replace(/[^0-9]/g, '');
    if (!recipient) throw definitelyNotSent('收件人號碼無效');

    const name = String((tpl && tpl.name) || '').trim();
    const language = String((tpl && tpl.language) || '').trim();
    if (!name || !language) throw definitelyNotSent('範本名稱或語言無效');
    const params = ((tpl && tpl.bodyParams) || []).map((p) => String(p == null ? '' : p));

    // DRY_RUN 一樣要排喺 isTemplateConfigured() 之前（同 sendText 一致）
    if (runtime.whatsappDryRun()) {
        console.log(`[whatsapp] DRY_RUN 送出範本 → ****${recipient.slice(-4)} `
            + `name=${name} lang=${language} params=${params.length}`);
        return {
            dryRun: true,
            messageId: `dryrun.${Date.now()}.${Math.random().toString(36).slice(2, 10)}`,
        };
    }

    if (!isTemplateConfigured()) throw definitelyNotSent(templateNotConfiguredMessage());

    const payload = {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to: recipient,
        type: 'template',
        template: { name: name, language: { code: language } },
    };
    if (params.length) {
        payload.template.components = [{
            type: 'body',
            parameters: params.map((text) => ({ type: 'text', text: text })),
        }];
    }

    const json = await graphRequest(`/${PHONE_NUMBER_ID}/messages`, { body: payload });
    const messageId = json && json.messages && json.messages[0] && json.messages[0].id;
    if (!messageId) throw new Error('WhatsApp API 回應沒有 message id');
    return { dryRun: false, messageId };
}

/** 標記客人訊息為已讀（客人那邊會顯示藍勾）。 */
async function markRead(waMessageId) {
    if (!isConfigured()) return { skipped: true };
    if (runtime.whatsappDryRun()) return { dryRun: true };

    return graphRequest(`/${PHONE_NUMBER_ID}/messages`, {
        body: {
            messaging_product: 'whatsapp',
            status: 'read',
            message_id: waMessageId,
        },
    });
}

/**
 * 取媒體的臨時下載連結。
 * ⚠️ 回傳嘅 url 只有約 5 分鐘有效，而且下載時**一定要再帶 Bearer token**，
 *    直接 fetch 個 url 會 401（常見 bug）。
 */
async function getMediaInfo(mediaId) {
    if (!isConfigured()) throw new Error(notConfiguredMessage());
    return graphRequest(`/${mediaId}`, { method: 'GET', timeoutMs: 20000 });
}

/**
 * 開啟媒體下載串流。呼叫者負責把 upstream.body 接到 response，
 * 並在完成時呼叫 cleanup()（否則 timeout timer 會殘留）。
 *
 * 唔會 buffer 成個檔 —— 生產機得 1 核 / 3.4GB 無 swap，而且曾經寫爆磁碟。
 *
 * @returns {Promise<{info: object, upstream: Response, cleanup: Function}>}
 */
async function openMediaStream(mediaId) {
    if (!isConfigured()) throw new Error(notConfiguredMessage());

    const info = await getMediaInfo(mediaId);
    if (info && info.file_size && info.file_size > MEDIA_MAX_BYTES) {
        const err = new Error(`媒體檔案過大（${info.file_size} bytes，上限 ${MEDIA_MAX_BYTES}）`);
        err.tooLarge = true;
        throw err;
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 30000);
    const cleanup = () => clearTimeout(timer);

    let upstream;
    try {
        upstream = await fetch(info.url, {
            headers: { Authorization: `Bearer ${ACCESS_TOKEN}` },
            signal: controller.signal,
        });
    } catch (e) {
        cleanup();
        if (e.name === 'AbortError') throw new Error('下載媒體逾時');
        throw e;
    }

    if (!upstream.ok) {
        cleanup();
        throw new Error(`下載媒體失敗（${upstream.status}）`);
    }

    return { info, upstream, cleanup };
}

// ─────────────────────────────────────────────────────────────
// 出站媒體（圖片／影片／文件）
//
// 兩段式：先上傳本地檔案取得 media id，再用該 id 發送訊息。
// 文字係媒體嘅 **caption**，唔係另一條訊息。
// ⚠️ 呢個令「帶附件時文字上限由 4096 降為 1024」—— 上層要自己擋。
// ─────────────────────────────────────────────────────────────

const MEDIA_UPLOAD_TIMEOUT_MS = parseInt(process.env.WHATSAPP_MEDIA_UPLOAD_TIMEOUT_MS, 10) || 30000;

// 直接對應 Meta 嘅訊息 type 同 payload 鍵名
const MEDIA_KINDS = ['image', 'video', 'document'];

/** 第一段：上傳到 Meta，取得 media id。 */
async function uploadMedia({ buffer, mime, filename }) {
    const fd = new FormData();
    fd.append('messaging_product', 'whatsapp');
    fd.append('type', mime);
    fd.append('file', new Blob([buffer], { type: mime }), filename || 'file');

    const json = await graphRequest(`/${PHONE_NUMBER_ID}/media`, {
        formData: fd,
        timeoutMs: MEDIA_UPLOAD_TIMEOUT_MS,
    });
    const id = json && json.id;
    if (!id) throw new Error('Meta 冇回傳 media id');
    return id;
}

/**
 * 兩段式送出媒體訊息。
 * @param {string} to wa_id（純數字）
 * @param {{buffer:Buffer, mime:string, filename:string, kind:string, caption:string}} opts
 * @returns {Promise<{dryRun:boolean, messageId:string, metaMediaId:string|null}>}
 *
 * 失敗時 err.phase = 'upload' | 'send' —— 上層靠呢個判斷「肯定未送出」
 * 定「模糊失敗」。上傳階段失敗 = 第二段從未執行 = 一定冇送出。
 */
async function sendMedia(to, { buffer, mime, filename, kind, caption }) {
    const recipient = String(to || '').replace(/[^0-9]/g, '');
    if (!recipient) throw definitelyNotSent('收件人號碼無效');
    if (!MEDIA_KINDS.includes(kind)) throw definitelyNotSent('附件類型不正確');
    if (!buffer || !buffer.length) throw definitelyNotSent('附件檔案不存在，請重新選擇快捷回覆');

    // ⚠️ dry-run 一定要排喺 isConfigured() 之前（同 sendText 一致）——
    //    測試模式嘅用意正正係未拿到憑證都可以行完整條流程。
    if (runtime.whatsappDryRun()) {
        console.log(`[whatsapp] DRY_RUN 送出媒體 type=${kind} size=${buffer.length} caption長度=${String(caption || '').length}`);
        return {
            dryRun: true,
            messageId: `dryrun.${Date.now()}.${Math.random().toString(36).slice(2, 10)}`,
            metaMediaId: null,
        };
    }

    if (!isConfigured()) throw definitelyNotSent(notConfiguredMessage());

    // ── 第一段：上傳 ──
    let mediaId;
    try {
        mediaId = await uploadMedia({ buffer, mime, filename });
    } catch (e) {
        // ⚠️ 上傳失敗 ⇒ 第二段從未執行 ⇒ **肯定未送出**。
        //    唔標記嘅話逾時會被誤判為「狀態未知」，叫用戶去確認客人
        //    有冇收到 —— 但其實根本冇送過。
        e.phase = 'upload';
        throw e;
    }

    // ── 第二段：發送 ──
    const mediaBody = { id: mediaId };
    if (caption) mediaBody.caption = String(caption);
    if (kind === 'document') mediaBody.filename = String(filename || 'file');   // Meta 要求 document 一定要有 filename

    const payload = {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to: recipient,
        type: kind,
    };
    payload[kind] = mediaBody;

    try {
        const json = await graphRequest(`/${PHONE_NUMBER_ID}/messages`, { body: payload });
        const messageId = json && json.messages && json.messages[0] && json.messages[0].id;
        if (!messageId) throw new Error('WhatsApp API 回應沒有 message id');
        return { dryRun: false, messageId, metaMediaId: mediaId };
    } catch (e) {
        e.phase = 'send';
        e.uploadedMediaId = mediaId;   // 診斷用（唔會 log 出去）
        throw e;
    }
}

// ─────────────────────────────────────────────────────────────
// 訊息模板（Message Templates）
//
// 主動發起對話（客人未先傳訊）必須用已批准的模板。模板屬 WABA 層，
// 所以要 WHATSAPP_WABA_ID。
//
// Meta 的模板 API 係唯一真實來源，所以唔另存本地 DB —— 每次直接查，
// 避免本地與 Meta 唔同步。
// ─────────────────────────────────────────────────────────────

// Meta 只接受呢三個類別。分類錯誤係模板被拒嘅常見原因：
//   MARKETING       推廣、優惠、重新接觸客人
//   UTILITY         訂單、預約、帳戶等交易相關通知
//   AUTHENTICATION  一次性密碼
const TEMPLATE_CATEGORIES = ['MARKETING', 'UTILITY', 'AUTHENTICATION'];

// 模板名稱規則：只准小寫英文字母、數字、底線
const TEMPLATE_NAME_RE = /^[a-z0-9_]{1,512}$/;

function isTemplateConfigured() {
    return Boolean(WABA_ID && ACCESS_TOKEN);
}

/** 由 Meta 嘅 components 陣列抽出 BODY 文字（冇就回空字串） */
function templateBodyOf(tpl) {
    const comps = (tpl && tpl.components) || [];
    const body = comps.filter((c) => c && String(c.type).toUpperCase() === 'BODY')[0];
    return body ? String(body.text || '') : '';
}

/**
 * body 入面需要幾個變數值。
 * Meta 嘅佔位符係 {{1}}、{{2}}…（由 1 開始，順序對應 parameters 陣列）。
 * ⚠️ 要數**不重複**嘅編號 —— {{1}} 出現兩次仍然只係一個參數。
 */
function templateVarCount(text) {
    const m = String(text || '').match(/\{\{(\d+)\}\}/g) || [];
    const idx = new Set(m.map((s) => parseInt(s.replace(/[^0-9]/g, ''), 10)));
    idx.delete(NaN);
    return idx.size;
}

/** 把 {{1}}… 換成實際值（只作**顯示**用途；真正送出嘅係 parameters 陣列） */
function renderTemplateBody(text, params) {
    let out = String(text || '');
    const list = params || [];
    for (let i = 0; i < list.length; i++) {
        out = out.split(`{{${i + 1}}}`).join(String(list[i] == null ? '' : list[i]));
    }
    return out;
}

function templateNotConfiguredMessage() {
    if (!ACCESS_TOKEN) return '未設定 WHATSAPP_ACCESS_TOKEN';
    if (!WABA_ID) return '未設定 WHATSAPP_WABA_ID（模板功能需要）';
    return 'WhatsApp 模板功能未設定';
}

/** 列出 WABA 下所有模板（含審批狀態）。 */
async function listTemplates() {
    if (!isTemplateConfigured()) throw new Error(templateNotConfiguredMessage());
    if (runtime.whatsappDryRun()) {
        return { dryRun: true, data: [] };
    }
    const json = await graphRequest(
        `/${WABA_ID}/message_templates` +
        '?fields=id,name,status,category,language,components,rejected_reason,quality_score' +
        '&limit=200',
        { method: 'GET', timeoutMs: 20000 }
    );
    return { dryRun: false, data: (json && json.data) || [] };
}

/**
 * 建立模板並送交 Meta 審批。
 * @param {{name:string, category:string, language:string, header?:string,
 *          body:string, footer?:string, examples?:string[]}} input
 * @returns {Promise<{dryRun:boolean, id?:string, status?:string, meta?:object}>}
 */
async function createTemplate(input) {
    if (!isTemplateConfigured()) throw new Error(templateNotConfiguredMessage());

    const name = String(input.name || '').trim();
    if (!TEMPLATE_NAME_RE.test(name)) {
        throw definitelyNotSent('模板名稱只可以用小寫英文字母、數字和底線（不可有空格或大寫）');
    }

    const category = String(input.category || '').trim().toUpperCase();
    if (!TEMPLATE_CATEGORIES.includes(category)) {
        throw definitelyNotSent('類別必須是 MARKETING、UTILITY 或 AUTHENTICATION');
    }

    const language = String(input.language || '').trim();
    if (!language) throw definitelyNotSent('請選擇語言');

    const body = String(input.body || '').trim();
    if (!body) throw definitelyNotSent('模板內容不可為空');

    const components = [];
    const header = String(input.header || '').trim();
    if (header) components.push({ type: 'HEADER', format: 'TEXT', text: header });
    const footer = String(input.footer || '').trim();

    // ⚠️ 內容有 {{1}} {{2}} 等變數時，Meta 要求提供範例值，否則會被拒。
    //    呢個係模板被拒嘅常見原因之一。
    const varCount = (body.match(/\{\{\d+\}\}/g) || []).length;
    const examples = Array.isArray(input.examples) ? input.examples.map((s) => String(s).trim()) : [];
    if (varCount > 0) {
        if (examples.filter(Boolean).length < varCount) {
            throw definitelyNotSent(`內容有 ${varCount} 個變數，需要提供同樣數量的範例值`);
        }
    }

    const bodyComponent = { type: 'BODY', text: body };
    if (varCount > 0) bodyComponent.example = { body_text: [examples.slice(0, varCount)] };
    components.push(bodyComponent);
    if (footer) components.push({ type: 'FOOTER', text: footer });

    const payload = { name, category, language, components };

    if (runtime.whatsappDryRun()) {
        console.log(`[whatsapp] DRY_RUN 建立模板 name=${name} category=${category} lang=${language}`);
        return { dryRun: true, id: `dryrun-tpl-${Date.now()}`, status: 'PENDING' };
    }

    const json = await graphRequest(`/${WABA_ID}/message_templates`, { body: payload });
    return { dryRun: false, id: json && json.id, status: (json && json.status) || 'PENDING', meta: json };
}

/** 刪除模板（按名稱，會刪除該名稱下所有語言版本）。 */
async function deleteTemplate(name) {
    if (!isTemplateConfigured()) throw new Error(templateNotConfiguredMessage());
    const n = String(name || '').trim();
    if (!TEMPLATE_NAME_RE.test(n)) throw definitelyNotSent('模板名稱格式不正確');

    if (runtime.whatsappDryRun()) {
        console.log(`[whatsapp] DRY_RUN 刪除模板 name=${n}`);
        return { dryRun: true, deleted: true };
    }

    const json = await graphRequest(
        `/${WABA_ID}/message_templates?name=${encodeURIComponent(n)}`,
        { method: 'DELETE' }
    );
    return { dryRun: false, deleted: true, meta: json };
}

module.exports = {
    isConfigured,
    isTemplateConfigured,
    templateNotConfiguredMessage,
    notConfiguredMessage,
    maskToken,
    describeError,
    sendText,
    sendTemplate,
    sendMedia,
    uploadMedia,
    MEDIA_KINDS,
    markRead,
    getMediaInfo,
    openMediaStream,
    listTemplates,
    createTemplate,
    deleteTemplate,
    templateBodyOf,
    templateVarCount,
    renderTemplateBody,
    TEMPLATE_CATEGORIES,
    ERROR_TITLES,
};
