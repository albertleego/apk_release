// ─────────────────────────────────────────────────────────────
// Meta signed_request 驗證與解析
//
// Meta 呼叫 Deauthorize callback 同 Data Deletion Request 時，會 POST 一個
// `signed_request` 表單欄位過嚟。格式係：
//
//     <base64url(signature)>.<base64url(payload)>
//
// 其中 signature = HMAC-SHA256(**base64url(payload) 呢個字串本身**, app_secret)
//
// ⚠️⚠️ 最容易出錯嘅一點：HMAC 係計喺 **payload 嘅 base64url 字串**上面，
//    唔係 decode 之後嘅 bytes。搞錯就會全部驗簽失敗，而且症狀係「永遠唔通過」
//    但睇唔出原因。
//
// ⚠️ 呢個檔**唔可以 throw** —— 呼叫端係 Meta 嘅伺服器，回 500 會令 Meta
//    重試同記錄錯誤。所有失敗都要變成 { ok:false, reason }。
// ─────────────────────────────────────────────────────────────
'use strict';

const crypto = require('crypto');

/** base64url → Buffer（Meta 用 -_ 而唔係 +/，而且冇 padding） */
function base64UrlToBuffer(s) {
    let t = String(s || '').replace(/-/g, '+').replace(/_/g, '/');
    while (t.length % 4 !== 0) t += '=';
    return Buffer.from(t, 'base64');
}

/**
 * 驗證並解析 signed_request。
 *
 * @param {string} signedRequest  Meta POST 過嚟嘅 signed_request 欄位
 * @param {string} appSecret      Meta App 嘅 App Secret
 * @returns {{ok: boolean, data?: object, reason?: string}}
 *          失敗時帶明確原因（唔會 throw）
 */
function parseSignedRequest(signedRequest, appSecret) {
    if (!appSecret) return { ok: false, reason: '未設定 App Secret' };
    if (!signedRequest || typeof signedRequest !== 'string') {
        return { ok: false, reason: '缺少 signed_request' };
    }

    const parts = signedRequest.split('.');
    if (parts.length !== 2) return { ok: false, reason: 'signed_request 格式錯誤' };

    const sigPart = parts[0];
    const payloadPart = parts[1];
    if (!sigPart || !payloadPart) return { ok: false, reason: 'signed_request 格式錯誤' };

    // ⚠️ 一定要喺 timingSafeEqual 之前比長度 —— 長度唔同佢會直接拋錯
    const expected = crypto.createHmac('sha256', appSecret).update(payloadPart).digest();
    const actual = base64UrlToBuffer(sigPart);
    if (expected.length !== actual.length) return { ok: false, reason: '簽名長度不符' };
    if (!crypto.timingSafeEqual(expected, actual)) return { ok: false, reason: '簽名不符' };

    let data;
    try {
        data = JSON.parse(base64UrlToBuffer(payloadPart).toString('utf8'));
    } catch (e) {
        return { ok: false, reason: 'payload 唔係有效 JSON' };
    }
    if (!data || typeof data !== 'object') return { ok: false, reason: 'payload 格式錯誤' };

    // Meta 會帶 algorithm，有就一定要係 HMAC-SHA256
    if (data.algorithm && data.algorithm !== 'HMAC-SHA256') {
        return { ok: false, reason: '不支援嘅簽名演算法：' + data.algorithm };
    }

    return { ok: true, data: data };
}

module.exports = {
    parseSignedRequest,
    // 測試用
    _base64UrlToBuffer: base64UrlToBuffer,
};
