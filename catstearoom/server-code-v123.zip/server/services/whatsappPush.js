// ─────────────────────────────────────────────────────────────
// whatsappPush.js — 客人新訊息 → 商家手機 App 推播通知（FCM HTTP v1）
//
// 為何唔用 firebase-admin：本專案部署流程**冇 `npm install`**，加新依賴會令
// require() 拋錯、整個伺服器起唔到（連收銀機一齊停）。所以只用專案已有嘅
// jsonwebtoken 簽 RS256 JWT，再用 Node 原生 fetch 直接打 FCM HTTP v1：
//
//   1. jwt.sign(claims, sa.private_key, { algorithm: 'RS256' })
//   2. POST  https://oauth2.googleapis.com/token        換 access token
//   3. POST  https://fcm.googleapis.com/v1/projects/{id}/messages:send
//
// ✅ 2026-09-30 用真實 service account 實測全條路徑通過（換 token HTTP 200）。
//
// ⚠️⚠️ 鐵律：呢個模組嘅**任何**函式永遠唔可以 throw。
//    推播失敗絕對唔可以影響入站訊息入庫 —— 同 whatsappAutoReplyService
//    同一條規矩（見 whatsappInboundService.js:410-414 嘅註解）。
//    所有錯誤一律變成 { ok:false, error } 回傳值或者 console.warn。
// ─────────────────────────────────────────────────────────────
'use strict';

const fs = require('fs');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const { db } = require('../../database/db');
const runtime = require('../config/runtime');

const SCOPE = 'https://www.googleapis.com/auth/firebase.messaging';
const TOKEN_URL = 'https://oauth2.googleapis.com/token';
const FCM_BASE = 'https://fcm.googleapis.com/v1/projects';

// 實測 expires_in = 3599 秒；取 55 分鐘留安全邊際，避免每次通知都換 token
const ACCESS_TOKEN_TTL_MS = 55 * 60 * 1000;
const HTTP_TIMEOUT_MS = 10000;

// FCM registration token 可以好長（實測可達 4KB）；截斷防止被塞爆
const MAX_TOKEN_LEN = 4096;
const MAX_LABEL_LEN = 64;
const MAX_DATA_VALUE_LEN = 256;

// 只有呢兩個 errorCode 代表「呢個 token 已經冇用，可以刪」。
//
// ⚠️⚠️ INVALID_ARGUMENT **唔可以**放喺呢個名單。
//    2026-09-30 用真實憑證實測：傳一個格式錯誤嘅 registration token 去
//    messages:send，FCM 回嘅係 INVALID_ARGUMENT（唔係 UNREGISTERED）。
//    即係 INVALID_ARGUMENT 代表「今次呢個請求有問題」（payload 格式、
//    token 格式…），唔代表「裝置已卸載 app」。
//    照刪嘅話，一次 payload 出錯就會清走所有正常裝置嘅 token。
//    正確做法：INVALID_ARGUMENT 只記日誌，等人去查。
const DELETE_TOKEN_CODES = ['UNREGISTERED', 'SENDER_ID_MISMATCH'];

// ── service account 快取（以路徑 + mtime 為 key，換檔自動重讀）──
let saCache = null;
let saCacheKey = '';

// ── access token 快取 ──
let cachedToken = null;
let cachedTokenExpiresAt = 0;
let refreshInFlight = null;

function warn(...args) {
    console.warn('[whatsapp:push]', ...args);
}

/**
 * 讀 service account JSON。
 * ⚠️ 用 JSON.parse —— 佢會自動把 `\n` 還原成真換行，所以**唔可以**再
 *    多做一次 `.replace(/\\n/g, '\n')`（實測 2026-09-30：JSON.parse 之後
 *    private_key 已經係真換行）。做多咗唔會壞，但反映理解錯誤，唔好加。
 * @returns {object|null} 讀唔到／格式錯 → null（唔 throw）
 */
function loadServiceAccount() {
    try {
        const file = runtime.fcmServiceAccountFile();
        if (!file) return null;

        let mtime = 0;
        try { mtime = fs.statSync(file).mtimeMs; } catch (e) { return null; }
        const key = file + '|' + mtime;
        if (saCache && saCacheKey === key) return saCache;

        const sa = JSON.parse(fs.readFileSync(file, 'utf8'));
        if (!sa || sa.type !== 'service_account') {
            warn('service account JSON 嘅 type 唔係 service_account，推播停用');
            return null;
        }
        if (!sa.project_id || !sa.client_email || !sa.private_key) {
            warn('service account JSON 缺少 project_id / client_email / private_key，推播停用');
            return null;
        }
        saCache = sa;
        saCacheKey = key;
        return sa;
    } catch (e) {
        // 憑證檔損壞唔可以令入站流程失敗
        warn('讀 service account 失敗（推播停用）:', e.message);
        return null;
    }
}

/**
 * 推播是否可用：flag 有開 + 憑證檔讀得到。
 * ⚠️ flag 關掉時回 false，呼叫端會完全唔做事。
 */
function isConfigured() {
    try {
        if (!runtime.whatsappPush()) return false;
        return !!loadServiceAccount();
    } catch (e) {
        return false;
    }
}

/** 換 access token（有快取；同一時間只會有一次 refresh 在飛） */
async function getAccessToken() {
    const now = Date.now();
    if (cachedToken && now < cachedTokenExpiresAt) return cachedToken;
    if (refreshInFlight) return refreshInFlight;

    refreshInFlight = (async () => {
        const sa = loadServiceAccount();
        if (!sa) return null;

        const iat = Math.floor(now / 1000);
        const assertion = jwt.sign(
            {
                iss: sa.client_email,
                scope: SCOPE,
                aud: sa.token_uri || TOKEN_URL,
                iat,
                exp: iat + 3600,
            },
            sa.private_key,
            { algorithm: 'RS256' }
        );

        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), HTTP_TIMEOUT_MS);
        try {
            const res = await fetch(sa.token_uri || TOKEN_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'grant_type=' + encodeURIComponent('urn:ietf:params:oauth:grant-type:jwt-bearer')
                    + '&assertion=' + encodeURIComponent(assertion),
                signal: controller.signal,
            });
            const body = await res.json().catch(() => ({}));
            if (!res.ok || !body.access_token) {
                // ⚠️ 唔好印 body —— 佢可能含 token 相關內容
                warn('換 access token 失敗 HTTP ' + res.status + ': ' + (body.error || '未知錯誤'));
                return null;
            }
            cachedToken = body.access_token;
            cachedTokenExpiresAt = Date.now() + ACCESS_TOKEN_TTL_MS;
            return cachedToken;
        } finally {
            clearTimeout(timer);
        }
    })();

    try {
        return await refreshInFlight;
    } finally {
        refreshInFlight = null;
    }
}

/** 強制下次重新換 token（收到 401 時用） */
function invalidateAccessToken() {
    cachedToken = null;
    cachedTokenExpiresAt = 0;
}

/**
 * 發一則推播去單一 token。
 * @returns {Promise<{ok:boolean, errorCode?:string, error?:string}>} 永不 throw
 */
async function sendToToken(token, { title, body, data } = {}, _retried) {
    try {
        if (!isConfigured()) return { ok: false, error: 'not_configured' };
        if (!token || typeof token !== 'string') return { ok: false, error: 'no_token' };

        // dry-run：完全唔打 FCM，只記錄（令整條流程可以在冇憑證下測試）
        if (runtime.whatsappDryRun()) {
            warn('dry-run，略過發送 →', String(title || '').slice(0, 40));
            return { ok: true, dryRun: true };
        }

        const accessToken = await getAccessToken();
        if (!accessToken) return { ok: false, error: 'no_access_token' };

        const sa = loadServiceAccount();
        if (!sa) return { ok: false, error: 'no_service_account' };

        // data 嘅值一定要係字串（FCM 規定），而且要截斷
        const safeData = {};
        Object.keys(data || {}).forEach((k) => {
            const v = data[k];
            if (v === undefined || v === null) return;
            safeData[k] = String(v).slice(0, MAX_DATA_VALUE_LEN);
        });

        const message = {
            token,
            notification: {
                title: String(title || '新訊息').slice(0, 200),
                body: String(body || '').slice(0, 500),
            },
            data: safeData,
            // high priority —— 令裝置在打瞌睡時都會即刻收到（否則可能延遲幾分鐘）
            android: { priority: 'high' },
            apns: {
                headers: { 'apns-priority': '10' },
                payload: { aps: { sound: 'default' } },
            },
        };

        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), HTTP_TIMEOUT_MS);
        try {
            const res = await fetch(FCM_BASE + '/' + sa.project_id + '/messages:send', {
                method: 'POST',
                headers: {
                    'Authorization': 'Bearer ' + accessToken,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message }),
                signal: controller.signal,
            });

            if (res.ok) return { ok: true };

            const payload = await res.json().catch(() => ({}));
            const err = payload.error || {};
            const errorCode = extractFcmCode(err);

            // access token 可能係喺快取期間被撤銷 → 強制重換一次再試
            if (res.status === 401 && !_retried) {
                invalidateAccessToken();
                return sendToToken(token, { title, body, data }, true);
            }

            if (errorCode) {
                warn('發送失敗 errorCode=' + errorCode + ' HTTP ' + res.status);
            } else {
                warn('發送失敗 HTTP ' + res.status + ': ' + (err.status || ''));
            }
            return { ok: false, errorCode, error: err.message || err.status || ('HTTP ' + res.status) };
        } finally {
            clearTimeout(timer);
        }
    } catch (e) {
        // AbortError = 逾時；其他 = 網絡問題。兩者都唔可以拋出去
        warn('發送異常（已忽略）:', e.name === 'AbortError' ? '逾時' : e.message);
        return { ok: false, error: e.name === 'AbortError' ? 'timeout' : e.message };
    }
}

/** 從 FCM 錯誤回應抽出 errorCode（喺 details[] 入面嘅 FcmError） */
function extractFcmCode(err) {
    const details = Array.isArray(err.details) ? err.details : [];
    for (let i = 0; i < details.length; i++) {
        const d = details[i];
        if (d && typeof d['@type'] === 'string' && d['@type'].indexOf('FcmError') !== -1) {
            return d.errorCode || null;
        }
    }
    return null;
}

/**
 * 發推播去一個分店嘅所有已登記裝置。
 * @returns {Promise<{ok:boolean, sent:number, failed:number, pruned:number}>} 永不 throw
 */
async function sendToStore(storeId, payload) {
    const result = { ok: false, sent: 0, failed: 0, pruned: 0 };
    try {
        if (!runtime.whatsappPush()) return result;
        if (!isConfigured()) return result;

        const tokens = await listTokens(storeId);
        if (!tokens.length) return Object.assign(result, { ok: true });

        // 同一個 token 只發一次（UNIQUE 約束理應已保證，呢層係保險）
        const seen = {};
        for (const row of tokens) {
            if (seen[row.token]) continue;
            seen[row.token] = true;

            const r = await sendToToken(row.token, payload);
            if (r.ok) {
                result.sent++;
                touchToken(row.token);
            } else {
                result.failed++;
                // ⚠️ 只喺明確「token 已失效」時才刪（見 DELETE_TOKEN_CODES 註解）
                if (r.errorCode && DELETE_TOKEN_CODES.indexOf(r.errorCode) !== -1) {
                    await deleteTokenByValue(row.token);
                    result.pruned++;
                    warn('已刪除失效 token（' + r.errorCode + '）');
                }
            }
        }
        result.ok = result.sent > 0;
        return result;
    } catch (e) {
        warn('sendToStore 異常（已忽略）:', e.message);
        return result;
    }
}

// ─────────────────────────────────────────────────────────────
// 入站訊息推播
// ─────────────────────────────────────────────────────────────

// 「未設定憑證」只提示一次 —— 否則客人每傳一句就嘈一次，正常嘅日誌會被淹沒
let notConfiguredWarned = false;

/**
 * 客人新訊息 → 推播俾該分店所有已登記裝置。
 * 由 whatsappInboundService 以 fire-and-forget 方式呼叫。
 *
 * ⚠️ 永遠唔會 throw —— 連同步錯誤都會被包住。推播失敗絕對唔可以影響
 *    入站訊息入庫（見 whatsappInboundService.js:411-414 嘅鐵律註解）。
 *
 * @param {object} p
 * @param {string} p.storeId
 * @param {string} p.conversationId  點通知可以直接開返該對話
 * @param {string} p.waMessageId     去重用（同一則訊息唔應該彈兩次）
 * @param {string} p.title           客人名；冇名就用電話號碼
 * @param {string} p.body            訊息預覽
 * @param {string} p.msgType
 */
async function notifyInbound({ storeId, conversationId, waMessageId, title, body, msgType }) {
    try {
        if (!runtime.whatsappPush()) return { ok: false, skipped: 'flag_off' };
        if (!isConfigured()) {
            if (!notConfiguredWarned) {
                notConfiguredWarned = true;
                warn('推播已略過（未設定憑證）—— 之後唔再重複提示');
            }
            return { ok: false, skipped: 'not_configured' };
        }

        const text = String(body || '').trim()
            || (msgType ? '[' + msgType + ']' : '新訊息');

        // ⚠️ 私隱：預覽會顯示喺鎖屏。呢個同 WhatsApp 預設行為一致，
        //    但商家可以喺 Android 嘅 notification channel 自行關閉預覽。
        return await sendToStore(storeId, {
            title: String(title || '新訊息').slice(0, 200),
            body: text,
            data: {
                type: 'inbound_message',
                conversationId: String(conversationId || ''),
                waMessageId: String(waMessageId || ''),
            },
        });
    } catch (e) {
        warn('notifyInbound 異常（已忽略）:', e.message);
        return { ok: false, error: e.message };
    }
}

// ─────────────────────────────────────────────────────────────
// 裝置登記（wa_push_tokens）
// ─────────────────────────────────────────────────────────────

function dbRun(sql, params) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function (err) {
            if (err) return reject(err);
            resolve({ changes: this.changes });
        });
    });
}
function dbAll(sql, params) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => (err ? reject(err) : resolve(rows || [])));
    });
}

function isAndroidOrIos(p) {
    return p === 'android' || p === 'ios';
}

/**
 * 登記（或更新）一部裝置。
 * ⚠️ 用 ON CONFLICT(token) —— 同一部裝置重複登記唔應該產生多列。
 * @returns {Promise<{ok:boolean, error?:string}>} 永不 throw
 */
async function registerToken({ storeId, token, platform, deviceLabel }) {
    try {
        const t = String(token || '').trim();
        if (!t) return { ok: false, error: 'TOKEN_REQUIRED' };
        if (t.length > MAX_TOKEN_LEN) return { ok: false, error: 'TOKEN_TOO_LONG' };
        if (!isAndroidOrIos(platform)) return { ok: false, error: 'PLATFORM_INVALID' };
        if (!storeId) return { ok: false, error: 'STORE_REQUIRED' };

        const nowIso = new Date().toISOString();
        const label = deviceLabel ? String(deviceLabel).trim().slice(0, MAX_LABEL_LEN) : null;

        await dbRun(
            `INSERT INTO wa_push_tokens
               (id, store_id, token, platform, device_label, last_seen_at, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)
             ON CONFLICT(token) DO UPDATE SET
               store_id     = excluded.store_id,
               platform     = excluded.platform,
               device_label = excluded.device_label,
               last_seen_at = excluded.last_seen_at,
               updated_at   = excluded.updated_at`,
            [crypto.randomUUID(), storeId, t, platform, label, nowIso, nowIso, nowIso]
        );
        return { ok: true };
    } catch (e) {
        warn('registerToken 失敗:', e.message);
        return { ok: false, error: 'DB_ERROR' };
    }
}

/** 取消登記（App 登出或關閉推播時）。刪唔到都當成功 —— 結果一樣 */
async function unregisterToken(token) {
    try {
        const t = String(token || '').trim();
        if (!t) return { ok: false, error: 'TOKEN_REQUIRED' };
        await dbRun(`DELETE FROM wa_push_tokens WHERE token = ?`, [t]);
        return { ok: true };
    } catch (e) {
        warn('unregisterToken 失敗:', e.message);
        return { ok: false, error: 'DB_ERROR' };
    }
}

/** 該分店嘅所有 token（無 token 時回空陣列） */
async function listTokens(storeId) {
    try {
        return await dbAll(`SELECT token, platform FROM wa_push_tokens WHERE store_id = ?`, [storeId]);
    } catch (e) {
        warn('listTokens 失敗:', e.message);
        return [];
    }
}

/**
 * 該分店已登記裝置嘅**對外安全**清單（唔含完整 token）。
 *
 * ⚠️ 絕對唔可以回完整 FCM token 俾前端 —— 攞到 token 嘅人就可以
 *    任意向該裝置發推播（冒認商家名義）。呢度只回尾 8 個字元供辨認。
 */
async function listDevices(storeId) {
    try {
        const rows = await dbAll(
            `SELECT id, token, platform, device_label, last_seen_at, created_at
               FROM wa_push_tokens WHERE store_id = ? ORDER BY last_seen_at DESC`,
            [storeId]
        );
        return rows.map((r) => ({
            id: r.id,
            platform: r.platform,
            device_label: r.device_label || null,
            token_tail: String(r.token || '').slice(-8),
            last_seen_at: r.last_seen_at || null,
            created_at: r.created_at || null,
        }));
    } catch (e) {
        warn('listDevices 失敗:', e.message);
        return [];
    }
}

/** 內部用：FCM 回報 token 已失效 → 清走 */
async function deleteTokenByValue(token) {
    try {
        await dbRun(`DELETE FROM wa_push_tokens WHERE token = ?`, [token]);
    } catch (e) {
        warn('deleteTokenByValue 失敗:', e.message);
    }
}

/** 內部用：記錄成功發送時間（唔 await，失敗唔影響） */
function touchToken(token) {
    try {
        db.run(`UPDATE wa_push_tokens SET last_seen_at = ? WHERE token = ?`,
            [new Date().toISOString(), token], () => {});
    } catch (e) { /* 純統計，唔理 */ }
}

module.exports = {
    isConfigured,
    notifyInbound,
    sendToToken,
    sendToStore,
    registerToken,
    unregisterToken,
    listTokens,
    listDevices,
    // 測試用
    _extractFcmCode: extractFcmCode,
    _DELETE_TOKEN_CODES: DELETE_TOKEN_CODES,
    _invalidateAccessToken: invalidateAccessToken,
};
