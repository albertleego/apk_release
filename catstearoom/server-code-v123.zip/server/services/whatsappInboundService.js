// ─────────────────────────────────────────────────────────────
// WhatsApp Cloud API — 入站事件處理
//
// 職責：驗簽、payload 解析、DB 寫入、24 小時客服窗計算。
// 唔碰 HTTP request/response（嗰啲喺 whatsappWebhookRoutes.js）。
//
// ⚠️ 教訓（來自 KPay 2026-09-17 真機）：靜默拒絕會令真機 debug 完全查唔出問題。
//    所以呢個檔所有拒絕路徑都要回一個**明確原因**，唔可以靜靜 return false。
// ─────────────────────────────────────────────────────────────
'use strict';

const crypto = require('crypto');
const { db } = require('../../database/db');
const whatsappService = require('./whatsappService');
const autoReply = require('./whatsappAutoReplyService');
// ⚠️ 單向依賴：whatsappPush 只需要 db / runtime / jsonwebtoken，
//    唔會 require 返呢個檔，所以冇循環依賴。
const push = require('./whatsappPush');

// ── sqlite3 callback → Promise（跟 merchantChatRoutes.js:41-58 既有慣例）──
function dbRun(sql, params) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function (err) {
            if (err) return reject(err);
            resolve({ changes: this.changes });
        });
    });
}
function dbGet(sql, params) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => (err ? reject(err) : resolve(row)));
    });
}
function dbAll(sql, params) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => (err ? reject(err) : resolve(rows || [])));
    });
}

const PREVIEW_MAX = 120;
const WINDOW_MS = 24 * 60 * 60 * 1000;

// ─────────────────────────────────────────────────────────────
// 24 小時客服窗（純函式）
//
// 呢個係成個功能最容易錯嘅業務規則，而倉庫有「daytype 按年份揀錯 tab」同
// 「時間戳格式混用」嘅前科，所以抽成純函式並處理所有邊界。
// ─────────────────────────────────────────────────────────────

/** 客人最後入訊時間 → 窗口到期（ISO）。解析失敗回 null，**唔可以**回 NaN 存入 DB。 */
function computeWindowExpiresAt(lastInboundAtIso) {
    if (!lastInboundAtIso) return null;
    const t = Date.parse(lastInboundAtIso);
    if (!Number.isFinite(t)) return null;
    return new Date(t + WINDOW_MS).toISOString();
}

/**
 * 窗口狀態。
 * 邊界：客人第一次發訊息之前 window_expires_at 係 null → known=false、open=false，
 *       即係唔可以主動發任何自由格式訊息。
 * 窗口過期後客人再發一次，window_expires_at 會被覆蓋 → 重新開 24 小時。
 */
function windowState(expiresAtIso, now = Date.now()) {
    if (!expiresAtIso) return { open: false, remainingMs: 0, known: false };
    const t = Date.parse(expiresAtIso);
    if (!Number.isFinite(t)) return { open: false, remainingMs: 0, known: false };
    const remainingMs = t - now;
    return { open: remainingMs > 0, remainingMs: Math.max(0, remainingMs), known: true };
}

// ─────────────────────────────────────────────────────────────
// 驗簽
// ─────────────────────────────────────────────────────────────

/** 定時攻擊安全的字串比較（長度不同時 timingSafeEqual 會拋錯，所以要先比長度）。 */
function safeEqual(a, b) {
    const ba = Buffer.from(String(a));
    const bb = Buffer.from(String(b));
    if (ba.length !== bb.length) return false;
    return crypto.timingSafeEqual(ba, bb);
}

/**
 * ⚠️ Express 會將 HTTP header 名一律轉做**全小寫**。
 *    KPay 就係因為 `nonceStr` 實際係 `noncestr` 而令全部回調被拒（2026-09-17 真機才發現）。
 *    `X-Hub-Signature-256` 喺 req.headers 入面係 `x-hub-signature-256` —— 直接寫
 *    req.headers['X-Hub-Signature-256'] 會永遠 undefined。呢度會以完全相同方式再中一次。
 */
function getHeader(headers, name) {
    const want = String(name).toLowerCase();
    const key = Object.keys(headers || {}).find((k) => k.toLowerCase() === want);
    return key ? headers[key] : undefined;
}

/**
 * 驗 Meta 的 X-Hub-Signature-256（HMAC-SHA256，key = App Secret）。
 * @returns {{ok: boolean, reason?: string}} 失敗時帶明確原因
 */
function verifySignature(rawBody, signatureHeader, appSecret) {
    if (!appSecret) return { ok: false, reason: '未設定 WHATSAPP_APP_SECRET' };
    // 冇 rawBody 就 fail closed —— 用 JSON.stringify(req.body) 重組嘅 body 唔可靠。
    if (!rawBody) return { ok: false, reason: '冇 raw body，無法驗簽' };

    const got = String(signatureHeader || '');
    if (!got) return { ok: false, reason: '缺少 X-Hub-Signature-256 header' };

    const expected = 'sha256=' + crypto.createHmac('sha256', appSecret).update(rawBody).digest('hex');
    if (got.length !== expected.length) return { ok: false, reason: '簽名長度不符' };
    if (!crypto.timingSafeEqual(Buffer.from(got), Buffer.from(expected))) {
        return { ok: false, reason: '簽名內容不符' };
    }
    return { ok: true };
}

// ─────────────────────────────────────────────────────────────
// Payload 解析
// ─────────────────────────────────────────────────────────────

/** Meta 的 timestamp 係 unix 秒（字串）。 */
function waTimestampToIso(ts) {
    const n = parseInt(ts, 10);
    if (!Number.isFinite(n) || n <= 0) return new Date().toISOString();
    return new Date(n * 1000).toISOString();
}

function toE164(waId) {
    const digits = String(waId || '').replace(/[^0-9]/g, '');
    return digits ? `+${digits}` : '';
}

/** 把 Meta 的 message object 正規化成我哋 DB 嘅欄位。 */
function normalizeMessage(m) {
    const type = m.type || 'unknown';
    const out = {
        msgType: type,
        textBody: null,
        caption: null,
        mediaId: null,
        mediaMime: null,
        mediaFilename: null,
        mediaSha256: null,
        mediaSize: null,
        contextWaMessageId: null,
    };

    if (type === 'text') {
        out.textBody = (m.text && m.text.body) || '';
    } else if (type === 'button') {
        // 客人撳咗訊息內嘅快速回覆按鈕
        out.textBody = (m.button && m.button.text) || '';
    } else if (type === 'interactive') {
        const i = m.interactive || {};
        out.textBody = (i.button_reply && i.button_reply.title)
            || (i.list_reply && i.list_reply.title)
            || '';
    } else if (['image', 'audio', 'video', 'document', 'sticker'].includes(type)) {
        const media = m[type] || {};
        out.mediaId = media.id || null;
        out.mediaMime = media.mime_type || null;
        out.mediaFilename = media.filename || null;
        out.mediaSha256 = media.sha256 || null;
        out.caption = media.caption || null;
    } else if (type === 'location') {
        const l = m.location || {};
        out.textBody = `[位置] ${l.latitude || ''},${l.longitude || ''}`;
    } else if (type === 'contacts') {
        out.textBody = '[聯絡人]';
    }

    if (m.context && m.context.id) out.contextWaMessageId = m.context.id;
    return out;
}

/**
 * 展開 payload 成一個個事件。
 * ⚠️ 一定要展開**全部** messages[] 同 statuses[]，唔可以只讀 [0] ——
 *    客人連打兩句，第二句會靜靜消失。
 */
function extractEvents(payload, expectedPhoneNumberId) {
    const out = [];
    const entries = Array.isArray(payload && payload.entry) ? payload.entry : [];

    for (const entry of entries) {
        const changes = Array.isArray(entry && entry.changes) ? entry.changes : [];
        for (const change of changes) {
            const value = change && change.value;
            if (!value) continue;

            const phoneNumberId = (value.metadata && value.metadata.phone_number_id) || '';
            // 唔屬於本機設定嘅號碼 → 記低但唔處理（將來同一個 App 掛多個號碼時防止串號）
            const belongs = !expectedPhoneNumberId || phoneNumberId === expectedPhoneNumberId;

            const profileByWaId = {};
            const contacts = Array.isArray(value.contacts) ? value.contacts : [];
            for (const c of contacts) {
                if (c && c.wa_id) profileByWaId[c.wa_id] = (c.profile && c.profile.name) || '';
            }

            const messages = Array.isArray(value.messages) ? value.messages : [];
            for (const m of messages) {
                if (!m || !m.id) continue;
                out.push({
                    eventKey: m.id,
                    eventType: 'inbound_message',
                    phoneNumberId,
                    belongs,
                    message: m,
                    profileName: profileByWaId[m.from] || '',
                });
            }

            const statuses = Array.isArray(value.statuses) ? value.statuses : [];
            for (const s of statuses) {
                if (!s || !s.id) continue;
                // ⚠️ 同一 wamid 會依序有 sent / delivered / read。event_key 只用 wamid 嘅話，
                //    後面嘅狀態會全部被當成重複而丟棄。
                out.push({
                    eventKey: `${s.id}:${s.status}:${s.timestamp}`,
                    eventType: 'status',
                    phoneNumberId,
                    belongs,
                    status: s,
                });
            }
        }
    }
    return out;
}

// ─────────────────────────────────────────────────────────────
// 入庫
// ─────────────────────────────────────────────────────────────

/**
 * 把 payload 內所有事件寫入 wa_webhook_events。
 * event_key 有 UNIQUE 約束 → Meta 重試會自動變成 no-op。
 *
 * @returns {Promise<{inserted: string[], skipped: number}>} inserted = 新事件嘅 row id
 */
async function ingestPayload(payload, expectedPhoneNumberId) {
    const events = extractEvents(payload, expectedPhoneNumberId);
    const inserted = [];
    let skipped = 0;
    const nowIso = new Date().toISOString();

    for (const ev of events) {
        const id = crypto.randomUUID();
        try {
            const res = await dbRun(
                `INSERT OR IGNORE INTO wa_webhook_events
                   (id, event_key, event_type, phone_number_id, status, received_at)
                 VALUES (?, ?, ?, ?, 'pending', ?)`,
                [id, ev.eventKey, ev.belongs ? ev.eventType : 'ignored_phone', ev.phoneNumberId, nowIso]
            );
            if (res.changes > 0) {
                inserted.push(id);
                pendingEvents.set(id, ev);
            } else {
                skipped += 1;
            }
        } catch (e) {
            console.error('[whatsapp] 寫入 webhook 事件失敗:', e.message);
        }
    }
    return { inserted, skipped };
}

// 剛入庫嘅事件暫存喺記憶體，避免即刻由 DB 讀返。
// 程序若喺處理途中崩潰，重啟後可以靠 replayPendingEvents() 由 DB 補做。
const pendingEvents = new Map();

async function processEventById(id) {
    const ev = pendingEvents.get(id);
    if (!ev) {
        await dbRun(
            `UPDATE wa_webhook_events SET status='failed', error='事件內容不在記憶體（重啟？）', processed_at=? WHERE id=?`,
            [new Date().toISOString(), id]
        );
        return;
    }

    try {
        if (!ev.belongs) {
            await dbRun(
                `UPDATE wa_webhook_events SET status='ignored', error=?, processed_at=? WHERE id=?`,
                [`phone_number_id ${ev.phoneNumberId} 唔屬於本機`, new Date().toISOString(), id]
            );
            return;
        }

        if (ev.eventType === 'inbound_message') {
            await handleInboundMessage(ev);
        } else if (ev.eventType === 'status') {
            await handleStatusUpdate(ev);
        }

        await dbRun(
            `UPDATE wa_webhook_events SET status='processed', processed_at=? WHERE id=?`,
            [new Date().toISOString(), id]
        );
    } catch (e) {
        console.error('[whatsapp] 處理事件失敗:', e.message);
        await dbRun(
            `UPDATE wa_webhook_events SET status='failed', error=?, processed_at=? WHERE id=?`,
            [String(e.message).slice(0, 200), new Date().toISOString(), id]
        );
    } finally {
        pendingEvents.delete(id);
    }
}

/** 客人傳入訊息：upsert contact / conversation，寫入 message。 */
async function handleInboundMessage({ message, profileName, phoneNumberId }) {
    const waId = String(message.from || '').replace(/[^0-9]/g, '');
    if (!waId) throw new Error('入站訊息冇 sender');

    // 第二層去重：wa_message_id 有 partial unique index
    const dup = await dbGet(`SELECT id FROM wa_messages WHERE wa_message_id = ?`, [message.id]);
    if (dup) return;

    const storeId = process.env.WHATSAPP_STORE_ID || 'store_1';
    const nowIso = new Date().toISOString();
    const waTs = waTimestampToIso(message.timestamp);

    // 1) 客人
    await dbRun(
        `INSERT INTO wa_contacts (id, wa_id, phone_e164, profile_name, store_id, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(wa_id) DO UPDATE SET
           profile_name = CASE WHEN excluded.profile_name != '' THEN excluded.profile_name
                               ELSE wa_contacts.profile_name END,
           updated_at = excluded.updated_at`,
        [crypto.randomUUID(), waId, toE164(waId), profileName || '', storeId, nowIso, nowIso]
    );
    const contact = await dbGet(`SELECT id FROM wa_contacts WHERE wa_id = ?`, [waId]);
    if (!contact) throw new Error('建立客人記錄失敗');

    // 2) 對話（一個客人一個開著嘅 thread）
    const norm = normalizeMessage(message);
    const preview = (norm.textBody || norm.caption || `[${norm.msgType}]`).slice(0, PREVIEW_MAX);
    // 窗口由客人訊息時間計算 —— 客人一發訊息，24 小時窗就重新開
    const windowExpiresAt = computeWindowExpiresAt(waTs);

    // ⚠️ 要喺 UPDATE 之前讀返自動回覆嘅狀態 —— 下面嘅 UPDATE 唔會覆蓋呢幾欄，
    //    但「上一次入訊時間」會被覆蓋，而佢係判斷「新一次接觸」嘅依據。
    const prevConv = await dbGet(
        `SELECT id, last_inbound_at, greeted_at, fallback_sent_at, auto_keywords_sent, handle_status
           FROM wa_conversations WHERE wa_contact_id = ? AND status = 'open'
          ORDER BY last_message_at DESC LIMIT 1`,
        [contact.id]
    );
    // ⚠️⚠️ `isNewConversation` 呢個名而家同時代表兩件事：
    //      1) 真係冇對話（第一次接觸）
    //      2) 上一次已經被商家按 Solved 收尾（提早結束 session）
    //    ⚠️ 呢個變數**只可以**用嚟餵自動回覆嘅 session 判斷。
    //       千萬唔可以用佢去做下面 INSERT / UPDATE 嘅分支條件 ——
    //       否則 Solved 之後嘅入訊會另開一個 conversation row，
    //       把客人嘅訊息紀錄拆散。
    const isNewConversation = !prevConv || prevConv.handle_status === 'solved';
    let conv = prevConv ? { id: prevConv.id } : null;

    if (!conv) {
        const convId = crypto.randomUUID();
        await dbRun(
            `INSERT INTO wa_conversations
               (id, wa_contact_id, phone_number_id, store_id, status, last_inbound_at,
                window_expires_at, last_message_at, last_message_preview, unread_count,
                created_at, updated_at)
             VALUES (?, ?, ?, ?, 'open', ?, ?, ?, ?, 1, ?, ?)`,
            [convId, contact.id, phoneNumberId, storeId, waTs, windowExpiresAt, waTs, preview, nowIso, nowIso]
        );
        conv = { id: convId };
    } else if (prevConv.handle_status === 'solved') {
        // 客人喺對話被 Solved 之後再傳訊息 → 對話又活起來。
        // ⚠️⚠️ **呢度絕對唔可以清 greeted_at / fallback_sent_at / auto_keywords_sent。**
        //    同一則 webhook payload 嘅多個事件係**並行**處理（見 whatsappWebhookRoutes
        //    嘅迴圈），若喺呢度清 NULL，會抹掉第一條訊息啱啱 claim 落嘅 greeted_at，
        //    令第二條再 claim 成功 → 客人收到兩次問候語。
        //    清 NULL 只可以喺 PATCH /conversations/:id 做（單一寫入者）。
        await dbRun(
            `UPDATE wa_conversations
                SET last_inbound_at = ?, window_expires_at = ?, last_message_at = ?,
                    last_message_preview = ?, unread_count = unread_count + 1,
                    handle_status = 'active', solved_at = NULL, updated_at = ?
              WHERE id = ?`,
            [waTs, windowExpiresAt, waTs, preview, nowIso, conv.id]
        );
    } else {
        await dbRun(
            `UPDATE wa_conversations
                SET last_inbound_at = ?, window_expires_at = ?, last_message_at = ?,
                    last_message_preview = ?, unread_count = unread_count + 1, updated_at = ?
              WHERE id = ?`,
            [waTs, windowExpiresAt, waTs, preview, nowIso, conv.id]
        );
    }

    // 3) 訊息本體（媒體只存 id，唔即時下載、唔落碟）
    await dbRun(
        `INSERT OR IGNORE INTO wa_messages
           (id, conversation_id, wa_contact_id, direction, wa_message_id, msg_type,
            text_body, caption, media_id, media_mime, media_filename, media_sha256, media_size,
            context_wa_message_id, is_read, created_at, updated_at)
         VALUES (?, ?, ?, 'in', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)`,
        [
            crypto.randomUUID(), conv.id, contact.id, message.id, norm.msgType,
            norm.textBody, norm.caption, norm.mediaId, norm.mediaMime, norm.mediaFilename,
            norm.mediaSha256, norm.mediaSize, norm.contextWaMessageId, waTs, nowIso,
        ]
    );

    // 4) 自動回覆 —— 排喺所有入庫之後。
    // ⚠️ 一定要喺呢度食掉任何錯誤：外層 processEventById 係 try/catch，
    //    自動回覆拋出去會令成個 webhook 事件被標為 'failed'，
    //    但入站訊息其實已經成功入庫 —— 會令診斷完全誤導。
    //    （runAutoReply 內部已經包好，呢層係第二重保險。）
    try {
        await autoReply.runAutoReply({
            storeId,
            conversationId: conv.id,
            waContactId: contact.id,
            waId,
            isNewConversation,
            prevLastInboundAt: prevConv ? prevConv.last_inbound_at : null,
            greetedAt: prevConv ? prevConv.greeted_at : null,
            fallbackSentAt: prevConv ? prevConv.fallback_sent_at : null,
            keywordsSentJson: prevConv ? prevConv.auto_keywords_sent : null,
            inboundCreatedAt: waTs,
            inboundText: norm.textBody || norm.caption || '',
            windowExpiresAt,
        });
    } catch (e) {
        console.error('[whatsapp] 自動回覆呼叫失敗（已忽略，不影響入站訊息）:', e.message);
    }

    // 5) 推播通知 —— 客人新訊息 → 商家手機 App（像 WhatsApp 一樣彈通知）。
    // ⚠️ 同上面自動回覆**同一條鐵律**：一定要喺呢度食掉任何錯誤。
    //    外層 processEventById 係 try/catch，推播拋出去會令成個 webhook 事件
    //    被標為 'failed'，但入站訊息其實已經成功入庫 —— 會令診斷完全誤導。
    //    notifyInbound 內部已經包好，呢層 .catch 係第二重保險。
    // ⚠️ 唔可以 await —— Meta 要求 webhook 快速回應，等 FCM 會拖長回應時間。
    //    所以用 setImmediate 排去下一個 tick，完全唔阻塞今次處理。
    // ⚠️ 只通知入站訊息 —— 出站同狀態更新都唔應該通知（否則商家會收到
    //    自己覆客人嘅通知）。
    // ⚠️ 私隱：標題係客人名、內文係訊息預覽，會顯示喺鎖屏。已在
    //    whatsappPush.notifyInbound 註明商家可自行關閉預覽。
    setImmediate(() => {
        try {
            push.notifyInbound({
                storeId,
                conversationId: conv.id,
                waMessageId: message.id,
                title: profileName || toE164(waId),
                body: preview,
                msgType: norm.msgType,
            }).catch((e) => console.warn('[whatsapp] 推播失敗（已忽略）:', e.message));
        } catch (e) {
            // ⚠️⚠️ 呢個 try/catch **唔可以刪** —— setImmediate 嘅 callback 已經
            //    離開 handleInboundMessage 嘅 try/catch 範圍，一旦呢度拋出去，
            //    就係未捕捉例外，會令整個伺服器（連收銀機）掛掉。
            //    notifyInbound 內部雖然已經包好錯誤，但呢層唔應該依賴嗰個假設：
            //    實測 2026-09-30，將 notifyInbound 換成一個會同步拋錯嘅函式，
            //    就會直接 crash process（煙霧測試第 22c 節攔到）。
            console.warn('[whatsapp] 推播排程失敗（已忽略）:', e.message);
        }
    });
}

/** 出站訊息的狀態回調：sent / delivered / read / failed。 */
async function handleStatusUpdate({ status }) {
    const wamid = status.id;
    const newStatus = String(status.status || '');
    const errors = Array.isArray(status.errors) ? status.errors : [];
    const firstError = errors[0] || null;
    const code = firstError ? (firstError.code || null) : null;
    // 只有 failed 才需要俾用戶睇嘅文字（其他狀態前端自己對應）
    const title = newStatus === 'failed' ? whatsappService.describeError(code) : null;

    await dbRun(
        `UPDATE wa_messages
            SET status = ?, error_code = ?, error_title = ?, updated_at = ?
          WHERE wa_message_id = ? AND direction = 'out'`,
        [newStatus, code, title, new Date().toISOString(), wamid]
    );
}

/**
 * 啟動時補做：把 DB 內仍係 pending 嘅事件標為 failed（因為記憶體已清空，內容冇咗）。
 * 保留呢個函式係為咗「唔會靜靜漏咗」—— 至少喺日誌同 DB 睇得到有幾多條補唔返。
 */
async function replayPendingEvents() {
    try {
        const rows = await dbAll(`SELECT id FROM wa_webhook_events WHERE status = 'pending'`, []);
        if (!rows.length) return 0;
        await dbRun(
            `UPDATE wa_webhook_events SET status='failed', error='程序重啟，事件內容已遺失', processed_at=?
              WHERE status='pending'`,
            [new Date().toISOString()]
        );
        console.warn(`[whatsapp] 啟動時發現 ${rows.length} 條未處理事件（程序重啟期間遺失）`);
        return rows.length;
    } catch (e) {
        console.error('[whatsapp] 補做 pending 事件失敗:', e.message);
        return 0;
    }
}

module.exports = {
    // 純函式（俾 API 層重用）
    computeWindowExpiresAt,
    windowState,
    safeEqual,
    getHeader,
    toE164,
    // 流程
    verifySignature,
    extractEvents,
    ingestPayload,
    processEventById,
    replayPendingEvents,
};
