// ─────────────────────────────────────────────────────────────
// WhatsApp 自動回覆引擎
//
// 掛喺 whatsappInboundService.handleInboundMessage 嘅最後一步。
//
// ⚠️⚠️ 最重要嘅一條規則：**呢個檔永遠唔可以向外拋錯。**
//     外層 processEventById 會 catch 所有例外然後將 webhook 事件標為 'failed'
//     —— 但入站訊息其實已經成功入庫。自動回覆失敗唔應該令事件睇落失敗。
//     所以 runAutoReply 內部自己包好，呼叫端亦再加一層 try/catch。
//
// 觸發規則（每個入訊最多只發一條）：
//   0. flag 未開 / 四個項目全關 → 唔做
//   1. 對話由**人手負責緊** → 完全靜音（機械人唔可以蓋過同事）
//      判斷 = whatsappConversationState.effectiveRole()：
//        handle_role 非 'bot' 就當有人手，直到靜默超過
//        runtime.whatsappHumanMuteMinutes()（預設 30 分鐘）自動退回 bot
//      ⚠️ 同「問候重新開場」嘅 24 小時係兩個唔同嘅窗口，以前共用同一個值
//   2. 關鍵字命中（最長優先，每個對話每一欄只回一次；一欄可填多個詞共用同一回覆）
//   3. 新一次接觸 + 問候名額未用 → 問候（依客服時間內／外揀）
//   4. 未發過後備 + 冇關鍵字命中 → 後備
//
// 「新一次接觸」= 客人靜默超過 whatsappGreetingResetHours（預設 24 小時）
// 之後再傳訊息。⚠️ 需要呢個概念係因為對話一旦建立就永遠唔會關閉
// （wa_conversations.status 永遠係 'open'），只靠「新對話」判斷嘅話，
// 問候語每位客人一生只會收到一次。
// ─────────────────────────────────────────────────────────────
'use strict';

const crypto = require('crypto');
const { db } = require('../../database/db');
const runtime = require('../config/runtime');
const whatsappService = require('./whatsappService');
const cfgSvc = require('./whatsappAutoReplyConfig');
const convState = require('./whatsappConversationState');
const { isWithinBusinessHours } = require('../utils/hongKongTime');

const PREVIEW_MAX = 120;
const REPLY_MAX = 4096;

/**
 * 24 小時窗口係唔係開。
 * ⚠️ 刻意唔由 whatsappInboundService 匯入 windowState —— 該檔會反過來
 *    匯入本檔，會造成循環依賴。呢個檢查只係防禦性（入訊一刻窗口必定開）。
 */
function windowOpen(expiresAtIso) {
    if (!expiresAtIso) return false;
    const t = Date.parse(expiresAtIso);
    return Number.isFinite(t) && t > Date.now();
}

function dbRun(sql, params) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function (err) {
            if (err) return reject(err);
            resolve({ changes: this.changes });
        });
    });
}
function dbGet(sql, params) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => (err ? reject(err) : resolve(row)));
    });
}

// ─────────────────────────────────────────────────────────────
// 純決策（唔碰 DB、唔碰網絡）—— 跟 whatsappInboundService 將 windowState
// 抽出嚟嘅既有做法，方便獨立測試。
// ─────────────────────────────────────────────────────────────

/** 一欄最長嘅詞有幾長 —— 排序用（愈長愈具體，應該優先） */
function longestPart(keyword) {
    const parts = cfgSvc.splitKeywordParts(keyword);
    let max = 0;
    for (const p of parts) if (p.length > max) max = p.length;
    return max;
}

/**
 * 由文字揀一個關鍵字回覆。
 * ⚠️ 最長優先：否則「營業」會搶走「營業時間」。
 *    排序用**最長嘅單一詞**，唔係整欄字串長度 —— 一欄填多個詞時，
 *    字串長度會令「訂位、訂座」無端贏過「營業時間」。
 * ⚠️ 空字串關鍵字會命中所有訊息 —— 呢度再防一次（DB 可能被人手改過）。
 *
 * 一欄可以填多個詞（用逗號／頓號分隔），任何一個命中都算觸發，
 * 共用同一個回覆。⚠️ 去重係**以欄為單位**：一欄係一條規則，
 *    同一對話回過一次就唔會再回 —— 否則客人先講「訂位」再講「訂座」
 *    會收到兩條一模一樣嘅訊息。
 *
 * 每欄各自有符合方式（config 嘅 match 欄位），逐個詞套用：
 *   'exact'    —— 客人整條訊息（去掉前後空白）要完全相同
 *   'contains' —— 訊息包含該詞即可（預設；舊設定冇 match 欄位都當呢個）
 * 兩者都唔分大小寫。
 */
function pickKeywordReply(text, keywords, alreadySent) {
    const raw = String(text || '');
    const hay = raw.toLowerCase();
    const trimmed = raw.trim().toLowerCase();
    if (!hay) return null;
    // ⚠️ alreadySent 存嘅係**整欄字串**（去重單位）。舊資料係單一關鍵字，
    //    單詞欄嘅整欄字串就等於嗰個詞，所以舊資料一樣對得上。
    const sent = new Set((alreadySent || []).map((k) => String(k).toLowerCase()));

    const ordered = (keywords || [])
        .filter((k) => k && String(k.keyword || '').trim())
        .slice()
        .sort((a, b) => longestPart(b.keyword) - longestPart(a.keyword));

    for (const k of ordered) {
        const entryKey = String(k.keyword).trim();
        const parts = cfgSvc.splitKeywordParts(entryKey);
        if (!parts.length) continue;

        const mode = k.match === 'exact' ? 'exact' : 'contains';
        let hit = false;
        for (const p of parts) {
            const needle = p.toLowerCase();
            if (mode === 'exact' ? trimmed === needle : hay.includes(needle)) { hit = true; break; }
        }
        if (!hit) continue;
        if (sent.has(entryKey.toLowerCase())) continue;   // 呢一欄喺呢個對話已經回過
        return { keyword: entryKey, reply: String(k.reply || '') };
    }
    return null;
}

/** 名額係唔係喺今次 session 之內仍然可用 */
function slotFree(lastAtIso, sessionCutoffIso) {
    if (!lastAtIso) return true;
    if (!sessionCutoffIso) return true;
    return lastAtIso < sessionCutoffIso;
}

/**
 * ⚠️ 唔發送時**一定**要回報原因（{reason} 而唔係 null）—— 2026-09-28
 *    試過因為「人手靜音」而靜靜唔發，查咗半個鐘 DB 才知係呢條規則。
 *
 * @returns {{kind:string, text:string, keyword?:string}|{reason:string}}
 */
function decide({ config, isOpenNow, isNewSession, sessionCutoffIso,
                  greetedAt, fallbackSentAt, keywordsSent, handledByHuman, text }) {
    // ⚠️ 冇單一總開關 —— 每個項目各自有 flag，商家想用邊項就開邊項。
    //    四個都關 = 完全唔會自動發訊息（等同舊版嘅總開關 off）。

    // 對話由人手負責緊（或者冷靜期未過）→ 機械人唔可以蓋過同事。
    // 判斷喺 whatsappConversationState.effectiveRole()，窗口長度見
    // runtime.whatsappHumanMuteMinutes()（預設 30 分鐘）。
    if (handledByHuman) return { reason: 'handled_by_human' };

    // 1) 關鍵字（最優先）
    if (config.keywordsEnabled) {
        const kw = pickKeywordReply(text, config.keywords, keywordsSent);
        if (kw && kw.reply) {
            return { kind: 'keyword', text: kw.reply, keyword: kw.keyword,
                     consumeGreeting: isNewSession };
        }
    }

    // 2) 問候 —— 客服時間內／外各自有開關
    const greetOn = isOpenNow ? config.greetingInEnabled : config.greetingOutEnabled;
    if (greetOn && isNewSession && slotFree(greetedAt, sessionCutoffIso)) {
        const greet = isOpenNow ? config.greetingInHours : config.greetingOutOfHours;
        if (greet && greet.trim()) {
            return { kind: isOpenNow ? 'greeting_in' : 'greeting_out', text: greet };
        }
        // 開關開咗但留空 → 跌落後備
    }

    // 3) 後備
    if (config.fallbackEnabled && config.fallbackReply && config.fallbackReply.trim()
        && slotFree(fallbackSentAt, sessionCutoffIso)) {
        return { kind: 'fallback', text: config.fallbackReply };
    }

    return { reason: 'no_rule_matched' };
}

// ─────────────────────────────────────────────────────────────
// 副作用
// ─────────────────────────────────────────────────────────────

/**
 * 判斷係唔係「新一次接觸」，並回傳 session 起點（ISO）供名額判斷用。
 * ⚠️ prevLastInboundAt 解析失敗時**唔會**當作新 session ——
 *    否則每條訊息都會補發問候（洗版）。呢個係刻意嘅 fail-safe 方向。
 */
function computeSession({ isNewConversation, prevLastInboundAt, nowMs, resetMs }) {
    if (isNewConversation) return { isNewSession: true, sessionCutoffIso: null };
    if (!prevLastInboundAt) return { isNewSession: true, sessionCutoffIso: null };
    const t = Date.parse(prevLastInboundAt);
    if (!Number.isFinite(t)) return { isNewSession: false, sessionCutoffIso: null };
    const gap = nowMs - t;
    if (gap <= 0) return { isNewSession: false, sessionCutoffIso: null };
    if (gap > resetMs) {
        // session 起點 = 今次入訊之前嘅嗰一刻（用 cutoff 做名額比較即可）
        return { isNewSession: true, sessionCutoffIso: new Date(nowMs - resetMs).toISOString() };
    }
    return { isNewSession: false, sessionCutoffIso: null };
}

/** 名額 claim：用原子 UPDATE，唔可以 SELECT 完再判斷（同 payload 多條訊息係並行） */
async function claimGreeting(convId, nowIso, cutoffIso) {
    if (!cutoffIso) {
        const r = await dbRun(
            `UPDATE wa_conversations SET greeted_at = ?, updated_at = ? WHERE id = ? AND greeted_at IS NULL`,
            [nowIso, nowIso, convId]);
        return r.changes === 1;
    }
    const r = await dbRun(
        `UPDATE wa_conversations SET greeted_at = ?, updated_at = ? WHERE id = ? AND (greeted_at IS NULL OR greeted_at < ?)`,
        [nowIso, nowIso, convId, cutoffIso]);
    return r.changes === 1;
}

async function claimFallback(convId, nowIso, cutoffIso) {
    if (!cutoffIso) {
        const r = await dbRun(
            `UPDATE wa_conversations SET fallback_sent_at = ?, updated_at = ? WHERE id = ? AND fallback_sent_at IS NULL`,
            [nowIso, nowIso, convId]);
        return r.changes === 1;
    }
    const r = await dbRun(
        `UPDATE wa_conversations SET fallback_sent_at = ?, updated_at = ? WHERE id = ? AND (fallback_sent_at IS NULL OR fallback_sent_at < ?)`,
        [nowIso, nowIso, convId, cutoffIso]);
    return r.changes === 1;
}

/** 關鍵字去重：compare-and-swap（JSON 欄位冇原子 append） */
async function claimKeyword(convId, oldJson, newJson) {
    const r = await dbRun(
        `UPDATE wa_conversations SET auto_keywords_sent = ?, updated_at = ?
          WHERE id = ? AND COALESCE(auto_keywords_sent, '') = ?`,
        [newJson, new Date().toISOString(), convId, oldJson || '']);
    return r.changes === 1;
}

/**
 * 主入口。⚠️ 保證唔會 throw。
 *
 * @param {object} ctx
 *   storeId, conversationId, waContactId, waId,
 *   isNewConversation, prevLastInboundAt, greetedAt, fallbackSentAt,
 *   keywordsSentJson, inboundCreatedAt, inboundText, windowExpiresAt
 */
async function runAutoReply(ctx) {
    try {
        if (!runtime.whatsappAutoReply()) return { sent: false, reason: 'flag_off' };

        const convId = ctx.conversationId;
        if (!convId) return { sent: false, reason: 'no_conversation' };

        // 防禦：窗口應該一定開（入訊一刻就開），但補做舊 wamid 嘅路徑可能唔係
        if (ctx.windowExpiresAt && !windowOpen(ctx.windowExpiresAt)) {
            return { sent: false, reason: 'window_closed' };
        }

        const config = await cfgSvc.loadConfig(ctx.storeId);
        // 四個項目全關 = 等同舊版總開關 off，唔需要做任何嘢
        if (!config.greetingInEnabled && !config.greetingOutEnabled
            && !config.keywordsEnabled && !config.fallbackEnabled) {
            return { sent: false, reason: 'all_rules_off' };
        }

        const nowMs = Date.now();
        // ⚠️ 兩個窗口係唔同嘅嘢，一定要分開（見 runtime.js 嘅註解）：
        //    sessionMs = 客人幾耐冇出聲就當新一次接觸（問候重發）
        //    muteMs    = 同事回覆完幾耐之內機械人唔出聲
        const sessionMs = runtime.whatsappGreetingResetHours() * 3600 * 1000;
        const muteMs = runtime.whatsappHumanMuteMinutes() * 60 * 1000;

        // ── 而家邊個負責（負責角色）──
        // ⚠️ 一定要喺**呢度**讀，唔可以由 whatsappInboundService 讀咗經 ctx 傳入。
        //    中間隔咗 contact upsert、訊息 insert、config load，而
        //    db.js 嘅 busy_timeout = 30000 意味鎖等待可達數十秒 —— 快照會令
        //    「最後一刻檢查」退化成「入訊最開始檢查」，放大同事回覆同
        //    機械人回應之間嘅競態窗口。
        const convRow = await dbGet(
            `SELECT handle_role, handle_at FROM wa_conversations WHERE id = ?`, [convId]);

        let handledByHumanNow = convState.handledByHuman(convRow, nowMs, muteMs);

        // ── 防漏寫 fallback ──
        // 對話角色由人手回覆路徑維護。日後若有人加咗**新嘅**人手發送路徑而
        // 忘記設定角色（例如 Meta 嘅 message_echoes），機械人就會插嘴。
        // 所以 handle_at 為 NULL 時（即從來冇被正式指派過）才掃一次訊息表確認，
        // 並自我修復寫返角色 —— 咁標題欄下次都會正確。
        //
        // ⚠️ handle_at 有值就完全唔掃（正常路徑零額外成本）。而且角色一旦
        //    被自動退回 bot（過咗冷靜期），handle_at 仍然有值，所以唔會
        //    錯誤地重新靜音。
        if (!handledByHumanNow && convRow && !convRow.handle_at) {
            const cutoffIso = new Date(nowMs - muteMs).toISOString();
            const leak = await dbGet(
                // ⚠️ 一定要排除 msg_type='system'（角色轉換記錄）。佢係 direction='out'
                //    而且 is_auto=0，唔排除就會被當成人手回覆。
                `SELECT created_at, sender_role FROM wa_messages
                  WHERE conversation_id = ? AND direction = 'out' AND COALESCE(is_auto, 0) = 0
                    AND msg_type <> 'system'
                    AND created_at >= ?
                  ORDER BY created_at DESC LIMIT 1`,
                [convId, cutoffIso]
            );
            if (leak) {
                handledByHumanNow = true;
                // 用訊息自己記錄嘅角色（比硬寫 merchant 準確，將來 officer 都啱）
                const derivedRole = leak.sender_role || 'merchant';
                await dbRun(
                    `UPDATE wa_conversations SET handle_role = ?, handle_at = ?, updated_at = ?
                      WHERE id = ? AND handle_at IS NULL`,
                    [derivedRole, leak.created_at, new Date().toISOString(), convId]
                ).catch((err) => console.error('[whatsapp] 回寫負責角色失敗:', err.message));
            }
        }

        const { isNewSession, sessionCutoffIso } = computeSession({
            isNewConversation: ctx.isNewConversation,
            prevLastInboundAt: ctx.prevLastInboundAt,
            nowMs, resetMs: sessionMs,
        });

        let keywordsSent = [];
        try { keywordsSent = JSON.parse(ctx.keywordsSentJson || '[]') || []; }
        catch (_) { keywordsSent = []; }

        const isOpenNow = isWithinBusinessHours(config.hours, nowMs);

        const decision = decide({
            config, isOpenNow, isNewSession, sessionCutoffIso,
            greetedAt: ctx.greetedAt,
            fallbackSentAt: ctx.fallbackSentAt,
            keywordsSent,
            handledByHuman: handledByHumanNow,
            text: ctx.inboundText,
        });

        if (!decision.kind) {
            // ⚠️ 一定要記錄原因。「冇規則命中」同「被同事靜音」係完全兩回事，
            //    但以前兩者都只回 no_rule_matched，查起上嚟要靠通靈。
            const reason = decision.reason || 'no_rule_matched';
            console.log(`[whatsapp] 自動回覆未發送 reason=${reason}`);
            return { sent: false, reason };
        }

        const nowIso = new Date().toISOString();

        // ── 原子 claim（同 payload 多條訊息係並行處理）──
        if (decision.kind === 'keyword') {
            const next = keywordsSent.concat([decision.keyword]);
            const ok = await claimKeyword(convId, ctx.keywordsSentJson, JSON.stringify(next));
            if (!ok) return { sent: false, reason: 'keyword_race' };
            // 第一次訊息命中關鍵字時，順便消耗問候名額 —— 否則下一條會補發問候
            if (decision.consumeGreeting) {
                await claimGreeting(convId, nowIso, sessionCutoffIso).catch(() => {});
            }
        } else if (decision.kind === 'greeting_in' || decision.kind === 'greeting_out') {
            const ok = await claimGreeting(convId, nowIso, sessionCutoffIso);
            if (!ok) return { sent: false, reason: 'greeting_race' };
        } else if (decision.kind === 'fallback') {
            const ok = await claimFallback(convId, nowIso, sessionCutoffIso);
            if (!ok) return { sent: false, reason: 'fallback_race' };
        }

        return await sendAutoReply(ctx, decision, nowIso);
    } catch (e) {
        // ⚠️ 永遠唔可以拋出去（見檔頭）。拋出去會令 webhook 事件被標為 failed，
        //    但入站訊息其實已經成功入庫。
        console.error('[whatsapp] 自動回覆失敗（已忽略，不影響入站訊息）:', e.message);
        return { sent: false, reason: 'error', error: e.message };
    }
}

/** 落庫 + 背景發送 */
async function sendAutoReply(ctx, decision, nowIso) {
    const text = String(decision.text || '').slice(0, REPLY_MAX);
    const messageId = crypto.randomUUID();

    // ⚠️ created_at 要用 max(現在, 入訊訊息時間 + 1ms)。
    //    入站訊息嘅 created_at = Meta 時間戳；若伺服器時鐘比 Meta 慢幾秒，
    //    自動回覆就會排喺客人嗰句之前（訊息串 ORDER BY created_at ASC）。
    const inboundMs = Date.parse(ctx.inboundCreatedAt);
    const created = new Date(
        Math.max(Date.now(), Number.isFinite(inboundMs) ? inboundMs + 1 : 0)
    ).toISOString();

    // 先落庫（status='queued'）—— 即使發送失敗，用戶都睇得到失敗原因
    await dbRun(
        `INSERT INTO wa_messages
           (id, conversation_id, wa_contact_id, direction, msg_type, text_body,
            status, is_auto, auto_kind, sent_by_employee_id, sender_role, created_at, updated_at)
         VALUES (?, ?, ?, 'out', 'text', ?, 'queued', 1, ?, NULL, 'bot', ?, ?)`,
        [messageId, ctx.conversationId, ctx.waContactId, text, decision.kind, created, nowIso]
    );

    // ⚠️ 只更新 last_message_at / preview，**唔可以** 動 unread_count
    //    （unread_count 係俾商家睇嘅待處理提示，只有 /read 可以清零）
    await dbRun(
        `UPDATE wa_conversations SET last_message_at = ?, last_message_preview = ?, updated_at = ?
          WHERE id = ?`,
        [created, text.slice(0, PREVIEW_MAX), nowIso, ctx.conversationId]
    );

    // 背景發送。⚠️ 一定要完整 try/catch：呢個 callback 喺回應之後執行，
    //    係孤兒 promise，冇 catch 嘅話 unhandled rejection 會殺掉整個進程
    //    （收件匣同平板同一個 process）。
    setImmediate(async () => {
        try {
            const out = await whatsappService.sendText(ctx.waId, text);
            await dbRun(
                `UPDATE wa_messages SET status = 'sent', wa_message_id = ?, updated_at = ? WHERE id = ?`,
                [out.dryRun ? null : out.messageId, new Date().toISOString(), messageId]
            );
        } catch (e) {
            const ambiguous = !e.definitelyNotSent && (Boolean(e.isTimeout) || !e.httpStatus);
            const status = ambiguous ? 'unknown' : 'failed';
            const title = ambiguous
                ? '發送狀態未知，請先確認客人是否已收到。'
                : whatsappService.describeError(e.apiCode);
            await dbRun(
                `UPDATE wa_messages SET status = ?, error_code = ?, error_title = ?, updated_at = ?
                  WHERE id = ?`,
                [status, e.apiCode || null, title, new Date().toISOString(), messageId]
            ).catch((err) => console.error('[whatsapp] 更新自動回覆狀態出錯:', err.message));
            console.warn(`[whatsapp] 自動回覆發送失敗 status=${status} code=${e.apiCode || '-'} msg=${e.message}`);
        }
    });

    return { sent: true, kind: decision.kind, messageId };
}

module.exports = {
    runAutoReply,
    decide,
    pickKeywordReply,
    computeSession,
    slotFree,
};
