/**
 * 領養申請的 Email 通知
 *
 * ─────────────────────────────────────────────────────────────
 * 設計原則：**通知失敗唔可以令提交失敗**。
 *   客人已經填完表、相片都上傳咗，唔應該因為 SMTP 出問題而叫佢再填一次。
 *   所以 sendMail 係 best-effort：失敗只記 log，唔會 throw 去 caller。
 *
 * 為什麼 lazy require nodemailer：
 *   本專案原本冇任何寄信功能，nodemailer 係新依賴。若某個環境未安裝
 *   （例如平板 EDGE 模式），require 會 throw，令整個 server 起唔到。
 *   所以改成用到先 require，並捕捉錯誤。
 *
 * 設定沿用定時任務已有的 scripts/email_config.json
 * （即 scripts/aliyun-cron/notify_email.py 用嘅同一份，唔需要再填一次）。
 * 想用另一個信箱就設 ADOPTION_SMTP_* 環境變數，會覆寫檔案設定。
 * 兩者都冇 = 停用通知，唔會報錯。
 * ─────────────────────────────────────────────────────────────
 */

'use strict';

const fs = require('fs');
const path = require('path');
const adoptionPublish = require('./adoptionPublish');

/**
 * 設定來源（依序）：
 *   1. scripts/email_config.json —— **沿用定時任務（scripts/aliyun-cron/notify_email.py）
 *      已經在用的同一份設定**，所以唔需要另外填一次。
 *      格式：{ "sender": "...@gmail.com", "password": "應用密碼", "to": "..." }
 *      呢個檔已 gitignore，只存在於伺服器。
 *   2. 環境變數 ADOPTION_SMTP_* —— 想用另一個信箱時用。
 *
 * ⚠️ Gmail 要用「應用密碼」，並走 STARTTLS（port 587），唔係 SSL 465。
 *    同 notify_email.py 一致。
 */
function configPath() {
    return process.env.EMAIL_CONFIG_PATH
        || path.join(__dirname, '..', '..', 'scripts', 'email_config.json');
}

function configFromFile() {
    try {
        const raw = fs.readFileSync(configPath(), 'utf8');
        const cfg = JSON.parse(raw);
        if (!cfg.sender || !cfg.password) return null;
        return {
            host: 'smtp.gmail.com',
            port: 587,
            secure: false,          // 587 = STARTTLS；nodemailer 會自動升級
            auth: { user: cfg.sender, pass: cfg.password },
            from: cfg.sender,
            to: cfg.to || cfg.sender,
        };
    } catch (err) {
        // 檔案唔存在係正常情況（例如本機開發、或未設定過）
        if (err.code !== 'ENOENT') {
            console.warn('讀取 email_config.json 失敗:', err.message);
        }
        return null;
    }
}

function configFromEnv() {
    const host = process.env.ADOPTION_SMTP_HOST;
    const user = process.env.ADOPTION_SMTP_USER;
    const pass = process.env.ADOPTION_SMTP_PASS;
    if (!host || !user || !pass) return null;

    const port = parseInt(process.env.ADOPTION_SMTP_PORT || '587', 10);
    return {
        host,
        port,
        secure: port === 465,       // 465 = SSL；其餘（587）用 STARTTLS
        auth: { user, pass },
        from: process.env.ADOPTION_SMTP_FROM || user,
        to: process.env.ADOPTION_NOTIFY_TO || user,
    };
}

function config() {
    return configFromFile() || configFromEnv();
}

/** 通知信係唔係已啟用（未設定 SMTP 就係停用） */
function enabled() {
    return config() !== null;
}

function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/** 領養費顯示文字：數額與用途都有就寫成「$500（絕育費）」 */
function feeTextOf(row) {
    if (!row.fee_required) return '無';
    const amount = String(row.fee_amount || '').trim();
    const note = String(row.fee_note || '').trim();
    if (amount && note) return `${amount}（${note}）`;
    return amount || note || '有';
}

function buildText(row) {
    const lines = [
        '有新的領養申請',
        '',
        `貓貓姓名：${row.cat_name || ''}`,
        `性別：${row.cat_gender || ''}`,
        `年齡：${row.cat_age || ''}`,
        `聯絡方式：${row.contact_method || ''}`,
        `您是：${row.submitter_role || '（未填）'}`,
        `稱呼：${row.submitter_name || '（未填）'}`,
        `領養費：${feeTextOf(row)}`,
        '',
        '貓貓簡介：',
        row.cat_intro || '（未填）',
        '',
        '領養要求：',
        row.adoption_requirement || '（未填）',
        '',
        '請到後台審核：https://catstearoom.dev/adoption-admin/',
    ];
    return lines.join('\n');
}

function buildHtml(row) {
    const tr = (k, v) => `<tr><td style="padding:4px 12px 4px 0;color:#666">${esc(k)}</td><td style="padding:4px 0"><strong>${esc(v)}</strong></td></tr>`;
    return `<div style="font-family:system-ui,-apple-system,'Noto Sans TC',sans-serif;font-size:15px;line-height:1.6">
  <h2 style="margin:0 0 12px">有新的領養申請</h2>
  <table style="border-collapse:collapse;margin-bottom:16px">
    ${tr('貓貓姓名', row.cat_name)}
    ${tr('性別', row.cat_gender)}
    ${tr('年齡', row.cat_age)}
    ${tr('聯絡方式', row.contact_method)}
    ${tr('您是', row.submitter_role)}
    ${tr('稱呼', row.submitter_name)}
    ${tr('領養費', feeTextOf(row))}
  </table>
  <p style="margin:0 0 4px"><strong>貓貓簡介</strong></p>
  <p style="margin:0 0 16px;white-space:pre-wrap">${esc(row.cat_intro) || '<span style="color:#999">（未填）</span>'}</p>
  <p style="margin:0 0 4px"><strong>領養要求</strong></p>
  <p style="margin:0 0 20px;white-space:pre-wrap">${esc(row.adoption_requirement) || '<span style="color:#999">（未填）</span>'}</p>
  <p style="margin:0"><a href="https://catstearoom.dev/adoption-admin/" style="background:#9b7a58;color:#fff;padding:10px 20px;border-radius:4px;text-decoration:none">前往後台審核</a></p>
</div>`;
}

/**
 * 有新申請時寄通知。
 * ⚠️ 永遠唔會 throw —— 呼叫方唔需要 try/catch。
 */
async function notifyNewSubmission(row) {
    const cfg = config();
    if (!cfg) return { skipped: true, reason: 'SMTP 未設定' };

    let nodemailer;
    try {
        nodemailer = require('nodemailer');
    } catch (err) {
        console.warn('未安裝 nodemailer，略過領養通知信');
        return { skipped: true, reason: 'nodemailer 未安裝' };
    }

    try {
        const transporter = nodemailer.createTransport({
            host: cfg.host,
            port: cfg.port,
            secure: cfg.secure,
            auth: cfg.auth,
        });
        await transporter.sendMail({
            from: cfg.from,
            to: cfg.to,
            subject: `[貓之茶房] 新的領養申請：${row.cat_name || '（無名）'}`,
            text: buildText(row),
            html: buildHtml(row),
        });
        return { sent: true };
    } catch (err) {
        // 只記 log，唔 throw
        console.error('領養通知信寄送失敗:', err.message);
        return { sent: false, error: err.message };
    }
}

module.exports = {
    enabled,
    notifyNewSubmission,
    buildText,
    buildHtml,
};
