// ─────────────────────────────────────────────────────────────
// WhatsApp 對話狀態：負責角色（handle）與訊息狀態（status）
//
// 負責角色存喺 wa_conversations.handle_role：
//   'bot'     —— 機械人負責（預設）
//   其他字串   —— 有人手負責（'merchant'，將來有 'officer'）
//
// ⚠️⚠️ **刻意唔設角色白名單。** 判斷只有一條：
//      role === 'bot' → 機械人；其他任何非空字串 → 有人手負責。
//    用白名單嘅話，日後 officer 嘅 role 字串一旦唔係剛好 'officer'
//    （例如 'staff' / 'manager'），就會被吞成 'bot' —— 機械人會喺
//    同事處理緊嘅對話插嘴。呢個係 2026-09-28 設計評審抓出嚟嘅坑。
//
// 訊息狀態存喺 wa_conversations.handle_status：
//   'active'  —— 一般
//   'pending' —— 同 active **完全一樣**，只係一個標籤（負責人標「我跟緊」）
//   'solved'  —— 提早結束呢一次 session（原本要等 24 小時靜默）
//
// ⚠️ 呢個檔案係**純函式**，唔碰 DB、唔碰網絡，方便獨立測試。
//    讀寫 DB 嘅部分喺 server/routes/whatsappInboxRoutes.js。
// ─────────────────────────────────────────────────────────────
'use strict';

const HANDLE_BOT = 'bot';

// 可以指派嘅負責角色。⚠️ 呢個係**驗證白名單**（PATCH /conversations/:id 用）。
//   'merchant' 保留只為咗**舊資料**仍然有效（2026-09-28 之前寫落嘅對話），
//   新嘅操作者只會係 admin 或 officer ——「商家」唔係一個身分。
const HANDLE_ROLES = [HANDLE_BOT, 'admin', 'officer', 'merchant'];

// 顯示用標籤（⚠️ 用英文係負責人指定）。
// ⚠️ **冇 `merchant → admin` 嘅映射** ——「商家」唔係身分，唔應該顯示成 admin。
//    舊資料（sender_role='merchant'）會經下面嘅 fallback 顯示原始值，
//    唔改寫歷史。
// 前端 client/whatsapp-inbox/index.html 有一份相同嘅對照。
const ROLE_LABELS = { bot: 'bot', admin: 'admin', officer: 'officer' };
function roleLabel(role) {
    const r = String(role || HANDLE_BOT);
    return ROLE_LABELS[r] || r;
}

const STATUSES = ['active', 'pending', 'solved'];
const STATUS_ACTIVE = 'active';
const STATUS_SOLVED = 'solved';
// ⚠️ 'expired' **唔喺** STATUSES 入面 —— 佢係系統自動判定，唔可以手動設定。
const STATUS_EXPIRED = 'expired';

/**
 * 由對話列算出「而家實際上邊個負責」。
 *
 * 呢一個函式同時決定兩件事 —— 標題欄顯示咩、以及機械人要不要出聲 ——
 * 所以顯示同行為永遠唔會漂移。
 *
 * @param {object} conv   至少要 { handle_role, handle_at }
 * @param {number} nowMs
 * @param {number} muteMs 冷靜期（毫秒）。超過就自動退回機械人
 * @returns {string} 'bot' 或人手角色字串
 */
function effectiveRole(conv, nowMs, muteMs) {
    const role = String((conv && conv.handle_role) || HANDLE_BOT);
    if (role === HANDLE_BOT) return HANDLE_BOT;

    const t = Date.parse((conv && conv.handle_at) || '');
    // ⚠️ 有角色但時間戳壞掉 → **仍然當有人手負責**（fail-closed）。
    //    方向係刻意嘅：資料損壞時寧願機械人唔出聲，也不要佢喺同事
    //    處理緊嘅對話插嘴。恢復方法：手動揀返「機械人」或者按 Solved。
    //
    //    ⚠️ 呢度同「顯示」嘅安全方向係相反嘅。顯示可以用 fail-safe
    //       （唔認識就當 bot），但**靜音唔可以**。
    if (!Number.isFinite(t)) return role;

    return (nowMs - t) > muteMs ? HANDLE_BOT : role;
}

/** 係唔係有人手負責緊（機械人應該收聲） */
function handledByHuman(conv, nowMs, muteMs) {
    return effectiveRole(conv, nowMs, muteMs) !== HANDLE_BOT;
}

/** 上一次 session 係唔係已經被 Solved 收尾 */
function isSolved(conv) {
    return Boolean(conv) && conv.handle_status === STATUS_SOLVED;
}

/** 未知／損壞嘅狀態一律當 active（fail-safe：唔會變成「已結束」） */
function normalizeStatus(v) {
    return STATUSES.includes(v) ? v : STATUS_ACTIVE;
}

/**
 * 對外顯示嘅「實際狀態」= 儲存值 + 自動判定嘅 Expired。
 *
 * Expired 嘅定義：24 小時客服窗已經關閉，而對話又未 Solved。
 *   - 話務上嘅意思係「唔可以再自由回覆，要用範本」——所以佢係商家最需要
 *     一眼睇到嘅狀態。
 *   - ⚠️ Solved 優先：已解決嘅對話唔會因為過期而變成 Expired。
 *   - ⚠️ Pending 一樣會過期（窗口關咗就係關咗，同商家有冇標「我跟緊」無關）。
 *
 * ⚠️ 刻意**唔用排程寫入**：計算出嚟永遠準確、唔會漏跑、亦唔使寫入放大。
 *    客人再傳訊息會令窗口重開，Expired 就會自動消失。
 *
 * ⚠️ 判斷一定要同 whatsappInboundService.windowState() 一致（open = 到期時間
 *    仍然喺將來）。呢度唔可以 require 佢 —— 佢會反過來 require
 *    whatsappAutoReplyService，而後者 require 本檔，會造成循環依賴。
 */
function effectiveStatus(conv, nowMs) {
    const st = normalizeStatus(conv && conv.handle_status);
    if (st === STATUS_SOLVED) return STATUS_SOLVED;

    const exp = Date.parse((conv && conv.window_expires_at) || '');
    // ⚠️ 冇窗口時間或者解析失敗（unknown）→ **唔可以斷定過期**，照回原狀態。
    //    方向同 windowState() 一致：唔肯定就唔好話「已經冇得回覆」。
    if (Number.isFinite(exp) && exp <= nowMs) return STATUS_EXPIRED;
    return st;
}

module.exports = {
    HANDLE_BOT,
    HANDLE_ROLES,
    ROLE_LABELS,
    roleLabel,
    STATUSES,
    STATUS_ACTIVE,
    STATUS_SOLVED,
    STATUS_EXPIRED,
    effectiveRole,
    handledByHuman,
    isSolved,
    normalizeStatus,
    effectiveStatus,
};
