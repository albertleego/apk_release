// ─────────────────────────────────────────────────────────────
// WhatsApp 自動回覆 — 設定讀寫
//
// 設定存喺 store_configs（config_key = 'wa_auto_reply'，config_type = 'json'）。
// 用 store_configs 而唔開新表：呢類設定係**單例**（一間店一組），
// UNIQUE(store_id, config_key) 天然吻合，而且已經有既有讀寫慣例
// （hot_fix_enabled、advance_booking_minutes）可以照跟。
//
// ⚠️ store_configs 嘅 created_at/updated_at 係 SQLite 格式（DATETIME DEFAULT
//    CURRENT_TIMESTAMP），同 WhatsApp 表嘅 ISO 唔同。本檔只寫唔讀呢兩個欄。
// ─────────────────────────────────────────────────────────────
'use strict';

const { db } = require('../../database/db');
const { parseHm } = require('../utils/hongKongTime');

const CONFIG_KEY = 'wa_auto_reply';

const GREETING_MAX = 1000;
const KEYWORD_MAX = 60;
const KEYWORD_REPLY_MAX = 1000;
const MAX_KEYWORDS = 50;

function dbRun(sql, params) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function (err) {
            if (err) return reject(err);
            resolve({ changes: this.changes });
        });
    });
}
function dbGet(sql, params) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => (err ? reject(err) : resolve(row)));
    });
}

/**
 * 預設設定。
 *
 * ⚠️ 冇單一嘅總開關 —— 每個自動回覆項目各自有開關，商家想用邊項就開邊項。
 *
 * ⚠️ 四個開關預設**全部 false**（明確 opt-in）。呢個係安全方向：
 *    升級現有設定時，若果冇呢幾個欄位，唔會突然開始自動發訊息俾客人 ——
 *    商家要自己逐個剔。舊版嘅 `enabled` 欄位已經唔再用。
 */
function defaultConfig() {
    const days = [];
    for (let i = 0; i < 7; i++) days.push({ day: i, closed: false, open: '10:00', close: '22:00' });
    return {
        greetingInEnabled: false,
        greetingOutEnabled: false,
        keywordsEnabled: false,
        fallbackEnabled: false,
        hours: { days },
        greetingInHours: '',
        greetingOutOfHours: '',
        keywords: [],
        fallbackReply: '',
    };
}

function clip(s, n) { return String(s == null ? '' : s).slice(0, n); }

// 一個關鍵字欄可以填多個詞，共用同一個回覆（例如「訂位、訂座」）。
// 三個分隔符都要收：半形逗號、全形逗號、中文頓號 —— 手機中文輸入法通常打全形。
const KEYWORD_SEPARATORS = /[,，、]/;

/** 拆開一個關鍵字欄嘅多個詞；空白項一律丟棄 */
function splitKeywordParts(s) {
    return String(s == null ? '' : s)
        .split(KEYWORD_SEPARATORS)
        .map((x) => x.trim())
        .filter(Boolean);
}


/**
 * 清洗設定。**唔會 throw** —— 無效嘅部分會被丟棄或取代為預設，
 * 令自動回覆喺任何情況下都有可預期嘅行為（fail-safe 方向：偏向營業中）。
 *
 * @returns {{config: object, warnings: string[]}}
 */
function sanitizeConfig(raw) {
    const warnings = [];
    const out = defaultConfig();
    const src = raw && typeof raw === 'object' ? raw : {};

    // 每個項目各自嘅開關（明確 true 才開；舊設定冇呢幾個欄位就係 false）
    out.greetingInEnabled = src.greetingInEnabled === true;
    out.greetingOutEnabled = src.greetingOutEnabled === true;
    out.keywordsEnabled = src.keywordsEnabled === true;

    // 營業時間：一定要 7 日
    const days = src.hours && Array.isArray(src.hours.days) ? src.hours.days : null;
    if (days && days.length === 7) {
        const clean = [];
        let ok = true;
        for (let i = 0; i < 7; i++) {
            const d = days.find((x) => x && Number(x.day) === i);
            if (!d) { ok = false; break; }
            const closed = d.closed === true;
            const open = d.open || '00:00';
            const close = d.close || '00:00';
            if (!closed) {
                if (parseHm(open) === null || parseHm(close) === null) { ok = false; break; }
                if (parseHm(open) === parseHm(close)) {
                    // 零長度窗當休息 —— 唔猜「00:00-00:00」係咩意思
                    clean.push({ day: i, closed: true, open, close });
                    warnings.push(`星期${i} 的開始與結束時間相同，已當作休息`);
                    continue;
                }
            }
            clean.push({ day: i, closed, open, close });
        }
        if (ok) out.hours = { days: clean };
        else warnings.push('營業時間格式不正確，已保留原有設定');
    } else if (days) {
        warnings.push('營業時間必須有 7 日，已保留原有設定');
    }

    out.greetingInHours = clip(src.greetingInHours, GREETING_MAX);
    out.greetingOutOfHours = clip(src.greetingOutOfHours, GREETING_MAX);

    const kws = Array.isArray(src.keywords) ? src.keywords : [];
    const seen = new Set();
    for (const k of kws.slice(0, MAX_KEYWORDS)) {
        if (!k) continue;
        const keywordRaw = clip(k.keyword, KEYWORD_MAX).trim();
        const reply = clip(k.reply, KEYWORD_REPLY_MAX).trim();
        // ⚠️ 空字串關鍵字會命中**所有**訊息 —— 一定要擋
        const parts = splitKeywordParts(keywordRaw);
        if (!parts.length) { warnings.push('有空白的關鍵字已被忽略'); continue; }
        if (!reply) { warnings.push(`關鍵字「${keywordRaw}」沒有回覆內容，已被忽略`); continue; }

        // 重複嘅詞一律剔除，兩個來源都算：同一欄內重複、同其他規則重複。
        // ⚠️ 唔剔除嘅話，同一個詞會屬於兩條規則，最後邊條命中取決於字串長度，
        //    商家完全睇唔出点解。所以後面嗰欄要讓路。
        const fresh = [];
        const dupes = [];
        for (const p of parts) {
            const key = p.toLowerCase();
            if (seen.has(key) || fresh.some((f) => f.toLowerCase() === key)) { dupes.push(p); continue; }
            fresh.push(p);
        }
        if (!fresh.length) {
            warnings.push(`關鍵字「${keywordRaw}」全部同其他規則重複，已忽略`);
            continue;
        }
        if (dupes.length) {
            warnings.push(`關鍵字「${keywordRaw}」有重複的詞，已剔除：${dupes.join('、')}`);
        }
        fresh.forEach((p) => seen.add(p.toLowerCase()));

        // 統一用頓號重新串起 —— 商家打半形逗號都會變成頓號，睇得到實際收咗啲乜
        // 符合方式：'exact' = 客人訊息要完全相同；其餘一律當 'contains'。
        // ⚠️ 舊設定冇 match 欄位 → 當 'contains'，即維持原有行為。
        out.keywords.push({
            keyword: fresh.join('、'),
            reply,
            match: k.match === 'exact' ? 'exact' : 'contains',
        });
    }

    out.fallbackEnabled = src.fallbackEnabled === true;
    out.fallbackReply = clip(src.fallbackReply, GREETING_MAX);

    return { config: out, warnings };
}

/** 讀取設定（無 row 或損壞都回預設，唔會 throw） */
async function loadConfig(storeId) {
    try {
        const row = await dbGet(
            `SELECT config_value FROM store_configs WHERE store_id = ? AND config_key = ?`,
            [storeId, CONFIG_KEY]
        );
        if (!row || !row.config_value) return defaultConfig();
        let parsed;
        try { parsed = JSON.parse(row.config_value); }
        catch (e) {
            console.warn('[whatsapp] wa_auto_reply 設定 JSON 損壞，改用預設:', e.message);
            return defaultConfig();
        }
        return sanitizeConfig(parsed).config;
    } catch (e) {
        console.error('[whatsapp] 讀取自動回覆設定失敗:', e.message);
        return defaultConfig();
    }
}

/** 儲存設定（先清洗再寫） */
async function saveConfig(storeId, raw, employeeId) {
    const { config, warnings } = sanitizeConfig(raw);
    const json = JSON.stringify(config);
    await dbRun(
        `INSERT INTO store_configs (id, store_id, config_key, config_value, config_type, description, updated_at)
         VALUES (?, ?, ?, ?, 'json', 'WhatsApp 自動回覆設定', CURRENT_TIMESTAMP)
         ON CONFLICT(store_id, config_key) DO UPDATE SET
           config_value = excluded.config_value,
           config_type = 'json',
           updated_at = CURRENT_TIMESTAMP`,
        [`wa_auto_reply_${storeId}`, storeId, CONFIG_KEY, json]
    );
    return { config, warnings };
}

module.exports = {
    CONFIG_KEY,
    GREETING_MAX,
    KEYWORD_MAX,
    KEYWORD_REPLY_MAX,
    MAX_KEYWORDS,
    defaultConfig,
    sanitizeConfig,
    loadConfig,
    saveConfig,
    splitKeywordParts,
};
