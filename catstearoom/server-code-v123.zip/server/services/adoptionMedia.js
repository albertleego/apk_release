/**
 * 領養申請的相片儲存
 *
 * ─────────────────────────────────────────────────────────────
 * 為什麼不用 multer：
 *   本專案既有的上傳一律走「base64 JSON」（見 whatsappQuickReplyMedia.js
 *   同收銀機 logo），package.json 亦冇任何 multipart 套件。為保持一致
 *   同零新依賴，呢度沿用同一做法。
 *
 * 為什麼檔案要放 /var/www/catstearoom-data：
 *   /var/www/catstearoom-site/ 係部署時 rsync --delete 嘅唯一目標，
 *   任何寫入該目錄嘅檔案下次部署都會消失。呢個目錄係網站根目錄嘅
 *   兄弟目錄，由 nginx 用 `location ^~ /assets/img/cats-live/` alias 指過去。
 *
 * 對外網址：/assets/img/cats-live/<檔名>
 * 實際路徑：<adoptionDataDir>/photos/<檔名>
 * ─────────────────────────────────────────────────────────────
 */

const fs = require('fs');
const path = require('path');
const runtime = require('../config/runtime');

// 5MB 上限。相片喺前端已縮到 300x300，正常遠低於此；
// 呢個上限係防有人繞過前端直接打 API。
const MAX_BYTES = 5 * 1024 * 1024;
const MAX_BASE64_CHARS = Math.ceil(MAX_BYTES * 4 / 3) + 1024;

// 對應現有相片的格式（cats/ 內 95 jpeg、17 jpg、1 png、5 webp）
const ALLOWED = {
    'image/jpeg': 'jpg',
    'image/jpg': 'jpg',
    'image/png': 'png',
    'image/webp': 'webp',
};

function dataDir() {
    return runtime.adoptionDataDir();
}

function photosDir() {
    return path.join(dataDir(), 'photos');
}

/** 建立必要目錄（伺服器啟動時與每次寫入前都叫一次，成本極低） */
function ensureDirs() {
    for (const d of [dataDir(), photosDir()]) {
        if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
    }
}

function extensionFor(mime) {
    return ALLOWED[String(mime || '').trim().toLowerCase()] || null;
}

/**
 * 檢查圖片檔頭是否與宣稱的 MIME 相符。
 * 唔想單靠客戶端聲稱嘅 Content-Type 就寫檔落磁碟。
 */
function contentMatchesMime(buf, ext) {
    if (buf.length < 12) return false;
    const isJpg = buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
    const isPng = buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47;
    const isWebp = buf.slice(0, 4).toString('ascii') === 'RIFF'
        && buf.slice(8, 12).toString('ascii') === 'WEBP';
    if (ext === 'jpg') return isJpg;
    if (ext === 'png') return isPng;
    if (ext === 'webp') return isWebp;
    return false;
}

/**
 * 儲存一張相片。
 *
 * @param {object} p
 * @param {string} p.base64    data URL 或純 base64
 * @param {string} p.mime      客戶端聲稱的 MIME
 * @param {string} p.fileBase  檔名主體（用 submission id，避免審核後改名）
 * @returns {Promise<string>}  寫入的檔名
 */
async function savePhoto({ base64, mime, fileBase }) {
    const ext = extensionFor(mime);
    if (!ext) {
        const e = new Error('相片格式不支援，請上傳 JPG、PNG 或 WEBP');
        e.userFacing = true;
        throw e;
    }

    const raw = String(base64 || '');
    if (!raw) {
        const e = new Error('請上傳貓貓相片');
        e.userFacing = true;
        throw e;
    }
    // ⚠️ 先檢查 base64 長度才解碼 —— 避免為一個註定被拒的檔案配置記憶體
    if (raw.length > MAX_BASE64_CHARS) {
        const e = new Error('相片過大（上限 5MB）');
        e.userFacing = true;
        throw e;
    }

    const comma = raw.indexOf(',');
    const b64 = comma >= 0 ? raw.slice(comma + 1) : raw;
    const buf = Buffer.from(b64, 'base64');

    if (!buf.length) {
        const e = new Error('相片內容無法解讀');
        e.userFacing = true;
        throw e;
    }
    if (buf.length > MAX_BYTES) {
        const e = new Error('相片過大（上限 5MB）');
        e.userFacing = true;
        throw e;
    }
    if (!contentMatchesMime(buf, ext)) {
        const e = new Error('相片內容與格式不符，請重新上傳');
        e.userFacing = true;
        throw e;
    }

    ensureDirs();
    const filename = `${fileBase}.${ext}`;
    await fs.promises.writeFile(path.join(photosDir(), filename), buf);
    return filename;
}

/** 刪除一張相片（檔案不存在時靜默通過） */
async function deletePhoto(filename) {
    if (!filename) return;
    // 防止路徑跳脫：只接受單純檔名
    const safe = path.basename(String(filename));
    try {
        await fs.promises.unlink(path.join(photosDir(), safe));
    } catch (err) {
        if (err.code !== 'ENOENT') console.error('刪除領養相片失敗:', err);
    }
}

/** 對外網址（寫入 cats.json 的 local 欄位用） */
function publicUrl(filename) {
    return `../assets/img/cats-live/${filename}`;
}

module.exports = {
    dataDir,
    photosDir,
    ensureDirs,
    savePhoto,
    deletePhoto,
    publicUrl,
    MAX_BYTES,
};
