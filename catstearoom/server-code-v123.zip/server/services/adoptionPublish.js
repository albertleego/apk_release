/**
 * 領養貼文的產生與發佈
 *
 * ─────────────────────────────────────────────────────────────
 * 兩件事：
 *   1. buildBodyHtml() —— 由表單內容產生彈窗用的貼文 HTML
 *      （套用與現有 118 筆完全相同的模板）
 *   2. rewriteLiveJson() —— 把已通過的貓寫成
 *      <adoptionDataDir>/cats.json，供 /adoption/ 頁面讀取
 *
 * 為什麼唔直接寫入網站嘅 cats.json：
 *   網站根目錄係 rsync --delete 嘅目標，下次部署會覆蓋。
 *   所以新貓另存一份，前端合併兩邊（見 cats.js）。
 *
 * ⚠️ 呢個檔案產生嘅 HTML 會被前端以 innerHTML 注入，所以所有
 *    由使用者輸入嘅文字都必須 escape，唔可以原樣插入。
 * ─────────────────────────────────────────────────────────────
 */

const fs = require('fs');
const path = require('path');
const { db } = require('../../database/db');
const runtime = require('../config/runtime');
const adoptionMedia = require('./adoptionMedia');

// 新貓的編號由 1000 起 —— 與現有 cats.json 的 1..118 保持距離，
// 避免前端以 `no` 組出的 DOM id 相撞（撞號會令彈窗互搶）。
const CAT_NO_START = 1000;

/** HTML escape —— 防止使用者輸入被當成標籤執行 */
function esc(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

/** 把使用者輸入的多行文字轉成 <br> 分隔的 HTML（已 escape） */
function multiline(s) {
    return esc(s).split(/\r?\n/).map((l) => l.trim()).filter(Boolean).join('<br>');
}

/** 與 multiline 相同，但每行前面加一個標記（領養要求逐項用 🟢） */
function bulleted(s, mark) {
    return esc(s).split(/\r?\n/).map((l) => l.trim()).filter(Boolean)
        .map((l) => `${mark} ${l}`).join('<br>');
}

/** 顯示用日期，例如 "8 Sep 2026"（與現有資料一致） */
function formatDate(d) {
    const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

/**
 * 判斷聯絡方式係 WhatsApp 定 Email，並產生對應的 <a>。
 * 表單容許兩種，所以呢度要自己判斷。
 */
function buildContactAnchor(contactRaw, role, name) {
    const raw = String(contactRaw || '').trim();
    if (!raw) return '';

    // 署名那行：申請人選的身分（貓義工／前主人），可補上「稱呼」。
    // 舊資料沒有這兩個欄位時，role 會是空 → 沿用原本的「貓義工」。
    const who = [String(role || '').trim() || '貓義工',
        String(name || '').trim()].filter(Boolean).join(' ');

    if (raw.includes('@')) {
        const email = raw.replace(/^mailto:/i, '').trim();
        return `<a href="mailto:${esc(email)}" target="_blank" rel="noopener">請按此電郵 ${esc(email)}<br>${esc(who)} 😺</a>`;
    }

    // 取數字（容許 +852 9391 2517 / 852-93912517 等寫法）
    const digits = raw.replace(/\D/g, '');
    if (!digits) return '';
    // 本地 8 位號碼補上 852
    const full = digits.length === 8 ? `852${digits}` : digits;
    return `<a href="http://wa.me/${full}" target="_blank" rel="noopener">請按此 Whatsapp ${esc(raw)}<br>${esc(who)} 😺</a>`;
}

/**
 * 由申請內容產生貼文 HTML。
 * 模板與現有 cats.json 的 118 筆一致。
 */
function buildBodyHtml(row, { date } = {}) {
    const parts = [];

    // 1. 免責聲明（固定文字）
    parts.push('<p><strong><span style="color: orange;">貓之茶房免費義務刊登</span></strong>'
        + '<br><strong><span style="color: orange;">與此post貓義工/原主人並無關聯</span></strong></p>');

    // 2. 貓貓簡介（選擇性）
    const intro = multiline(row.cat_intro);
    if (intro) parts.push(`<p>${intro}</p>`);

    // 3. 領養要求 + 領養費
    const req = bulleted(row.adoption_requirement, '🟢');
    // 領養費：數額與用途都有就一併顯示，例如「$500（絕育費）」
    const feeAmount = String(row.fee_amount || '').trim();
    const feeNote = String(row.fee_note || '').trim();
    let feeText = '無';
    if (row.fee_required) {
        feeText = feeAmount && feeNote ? `${feeAmount}（${feeNote}）`
            : (feeAmount || feeNote || '有');
    }
    const reqLines = [];
    if (req) reqLines.push(req);
    reqLines.push(`🟢 領養費用 : ${esc(feeText)}`);
    reqLines.push('<span style="color: gray;">*如有領養費可請義工出示相關單據</span>');
    parts.push(`<p>ℹ️ 領養要求ℹ️<br>${reqLines.join('<br>')}</p>`);

    // 4. 聯絡方式
    const anchor = buildContactAnchor(row.contact_method, row.submitter_role, row.submitter_name);
    if (anchor) {
        parts.push('<p>🐱 有興趣申請領養請連同以下資料 🐱</p>');
        parts.push('<p>窗網影片</p>');
        parts.push(`<p>${anchor}</p>`);
    }

    // 5. 刊登日期（右下角，灰字）
    const d = date || new Date();
    parts.push('<p align="right"><span style="color: gray; font-size: small;">刊登日期:<br></span>'
        + `<span style="color: gray; font-size: small;">${formatDate(d)}<br>`
        + '貓之茶房免費義務刊登<br>與此post 貓義工/原主人並無關聯</span></p>');

    return parts.join('');
}

/** 顯示名稱：與現有格式一致，例如 "Mochi 灰灰 男 8歲" */
function buildDisplayName(row) {
    const bits = [String(row.cat_name || '').trim()];
    const gender = String(row.cat_gender || '').trim();
    const age = String(row.cat_age || '').trim();
    if (gender) bits.push(gender);
    if (age) bits.push(age);
    return bits.join(' ');
}

/** 讀出目前所有已通過的申請。
 *  ⚠️ 用 cat_no DESC —— 領養頁要把**最新刊登的排最前**
 *     （cat_no 由 1000 起遞增，所以號碼越大 = 越新）。 */
function listApproved() {
    return new Promise((resolve, reject) => {
        db.all(
            `SELECT * FROM adoption_submissions
              WHERE status = 'approved' AND cat_no IS NOT NULL
              ORDER BY cat_no DESC`,
            [],
            (err, rows) => (err ? reject(err) : resolve(rows || []))
        );
    });
}

/** 取得下一個未被使用的編號 */
function nextCatNo() {
    return new Promise((resolve, reject) => {
        db.get(
            `SELECT MAX(cat_no) AS maxNo FROM adoption_submissions
              WHERE status = 'approved' AND cat_no IS NOT NULL`,
            [],
            (err, row) => {
                if (err) return reject(err);
                const max = row && row.maxNo ? Number(row.maxNo) : (CAT_NO_START - 1);
                resolve(Math.max(max + 1, CAT_NO_START));
            }
        );
    });
}

/**
 * 重寫 <adoptionDataDir>/cats.json。
 * 審核通過、修改、下架之後都要叫一次。
 *
 * 輸出格式與現有 cats.json 完全相同，前端的 cats.js 可直接吃：
 *   [{ no, name, local, body }, ...]
 */
async function rewriteLiveJson() {
    const rows = await listApproved();
    const cats = rows.map((row) => ({
        no: row.cat_no,
        name: buildDisplayName(row),
        local: adoptionMedia.publicUrl(row.photo_file),
        // body_html 係審核時可以人手改嘅最終版本；未有就先由欄位生成
        body: row.body_html || buildBodyHtml(row),
    }));

    adoptionMedia.ensureDirs();
    const target = path.join(runtime.adoptionDataDir(), 'cats.json');
    const tmp = `${target}.tmp`;
    // 先寫暫存再 rename —— 避免前端喺寫入中途讀到半截 JSON
    await fs.promises.writeFile(tmp, JSON.stringify(cats), 'utf8');
    await fs.promises.rename(tmp, target);

    return cats.length;
}

module.exports = {
    buildBodyHtml,
    buildDisplayName,
    buildContactAnchor,
    nextCatNo,
    listApproved,
    rewriteLiveJson,
    esc,
    CAT_NO_START,
};
