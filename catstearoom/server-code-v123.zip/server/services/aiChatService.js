/**
 * aiChatService.js — 商家 AI chatroom 的 LLM 客戶端（Anthropic Messages API 格式）
 *
 * 對接 DeepSeek 的 Anthropic 相容端點（POST {AI_BASE_URL}/v1/messages）。
 * 只做兩件事：把對話送去模型、把串流回應逐段交回呼叫者。
 * 所有 DB / 權限 / 限流邏輯都在 merchantChatRoutes.js，呢個檔唔碰 DB。
 *
 * ⚠️ 三個必須遵守嘅約束（原因見 MD Files/MERCHANT_CHAT_GUIDE.md）：
 * 1. 唔可以逐個 chunk console.log — logger 係同步 appendFileSync，
 *    前例係 2026-09-13 一日寫 12GB 日誌塞爆磁碟。
 * 2. 唔可以喺呢個檔 print API key（CLAUDE.md 機密處理規則）。
 * 3. 一定要有 timeout + 支援外部 abort（客戶端斷線要即刻停 upstream，
 *    否則 request 會繼續燒額度）。
 */

// 端點同憑證：只喺伺服器讀，永遠唔會送去瀏覽器
const AI_BASE_URL = (process.env.AI_BASE_URL || 'https://api.deepseek.com').replace(/\/+$/, '');

// API key 有兩個來源，優先次序：
//   1. 資料庫 chat_platform_settings（主商家喺「商家管理」版面填入，唔使 SSH 改 .env）
//   2. 環境變數 AI_API_KEY（.env，部署時設定）
// DB 版本快取喺 module 記憶體，避免每次 request 都讀 DB；
// 由 route 層呼叫 setApiKey() 更新（見 merchantChatRoutes.refreshApiKeyFromDb）。
let dbApiKey = null;

function getApiKey() {
    return dbApiKey || process.env.AI_API_KEY || '';
}

/** 由 route 層呼叫：設定／清除 DB 來源嘅 key（傳 null = 清除，回落返 .env） */
function setApiKey(key) {
    dbApiKey = key ? String(key).trim() : null;
}

/** key 由邊度嚟（只回傳來源名稱，永遠唔會回傳 key 本身） */
function keySource() {
    if (dbApiKey) return 'database';
    if (process.env.AI_API_KEY) return 'env';
    return 'none';
}

/**
 * 任意一條 key 嘅遮蔽版本（例：••••••••3f2a）。
 * 只露出最後 4 個字元：足夠分辨係邊條 key，又唔會洩漏可用部分。
 */
function maskKey(rawKey) {
    const k = String(rawKey || '');
    if (!k) return null;
    if (k.length <= 8) return '••••••••';
    return `••••••••${k.slice(-4)}`;
}

/** 目前生效嘅 key 嘅遮蔽版本 */
function maskedKey() {
    return maskKey(getApiKey());
}
// 模型名。可能帶顯示用後綴（例：deepseek-flash[1m]），API 只認前段，所以剝走。
//
// ⚠️ 依 DeepSeek 官方文件（api-docs.deepseek.com/zh-cn/quick_start/pricing）：
//   有效名稱只有兩個 ——
//     deepseek-flash     (DeepSeek-V4.1-Flash，有圖像理解，快而便宜)
//     deepseek-v4-pro    (DeepSeek-V4-Pro-0813，較強，約 3.4 倍價錢)
//   舊名 deepseek-v4-flash 仍然可調用，但**對應模型已下線**，
//   請求會改由 DeepSeek-V4.1-Flash 提供服務。所以新設定一律用 deepseek-flash。
//
//   另外，傳入未支援嘅名（包括 claude-* 系列）會被後端靜默映射去 deepseek-flash
//   —— 寫 claude-sonnet-5 唔會得到 Claude，只會得到 DeepSeek。
const AI_MODEL = (process.env.AI_MODEL || 'deepseek-flash').replace(/\[.*\]$/, '').trim();
const AI_MAX_TOKENS = parseInt(process.env.AI_MAX_TOKENS || '2048', 10);

// 思考模式（DeepSeek 特有開關；Anthropic 官方冇 disabled 呢個值，所以刻意做成 opt-in）。
//   AI_THINKING=on  → 送 { thinking: { type: 'enabled' } }（目前採用：用戶要求開啟）
//   AI_THINKING=off → 送 { thinking: { type: 'disabled' } }
//   未設            → 完全唔送呢個欄位（保留供應商預設，換去真 Anthropic 都唔會出錯）
//
// 實測 deepseek-flash（2026-09-17）：
//   enabled  1880ms / 輸出 164 tokens   ← 較準，但慢同貴
//   disabled 1125ms / 輸出  24 tokens   ← 快約 40%、token 少約 85%
//
// ⚠️ 開思考時**思考內容會先消耗 max_tokens**，額度不夠正文就會變空。
//    所以開思考就一定要同時把 AI_MAX_TOKENS 調高（見 .env 範例嘅說明）。
const AI_THINKING_RAW = String(process.env.AI_THINKING || '').trim().toLowerCase();
const AI_THINKING = AI_THINKING_RAW === '' ? null : ['on', 'true', '1'].includes(AI_THINKING_RAW);

// 思考強度（DeepSeek 官方文件：Anthropic 格式嘅 output_config 只支援 effort）。
//   合法值：minimal / low / medium / high / xhigh / max / ultra
//   （官方映射：minimal→low、medium→high、xhigh→high、ultra→max）
// 留空 = 唔送呢個欄位，用供應商預設（實測係 high）。
//
// ⚠️ 為什麼需要呢個：實測開思考 + 預設 effort 時，思考長度可以爆到 2~8 萬字，
//    會（a）吃光 max_tokens 令正文變空，或（b）超過 AI_TIMEOUT_MS 被截斷。
//    設 effort=low 可以把思考壓到幾百字，仍然有思考但唔會失控。
const AI_THINKING_EFFORT_RAW = String(process.env.AI_THINKING_EFFORT || '').trim().toLowerCase();
const AI_EFFORT_VALUES = ['minimal', 'low', 'medium', 'high', 'xhigh', 'max', 'ultra'];
const AI_THINKING_EFFORT = AI_EFFORT_VALUES.includes(AI_THINKING_EFFORT_RAW) ? AI_THINKING_EFFORT_RAW : null;
if (AI_THINKING_EFFORT_RAW && !AI_THINKING_EFFORT) {
    console.warn(`[aiChat] AI_THINKING_EFFORT="${AI_THINKING_EFFORT_RAW}" 唔係合法值，已忽略。合法值：${AI_EFFORT_VALUES.join('/')}`);
}
// 整個回應嘅上限（含思考）。DeepSeek 思考較長，預設 2 分鐘
const AI_TIMEOUT_MS = parseInt(process.env.AI_TIMEOUT_MS || '120000', 10);
// 驗證金鑰用嘅逾時（短好多：只係送一個 token，正常一兩秒內返）
const VALIDATE_TIMEOUT_MS = parseInt(process.env.AI_VALIDATE_TIMEOUT_MS || '20000', 10);
const AI_ANTHROPIC_VERSION = '2023-06-01';

// 新對話嘅預設系統提示詞。**預設留空 = 完全唔加角色設定**，
// 令模型用自己原本嘅方式回答（2026-09-14 按用戶要求移除原本寫死嘅「咖啡店助理」角色）。
// 要加返：喺 .env 設 AI_CHAT_DEFAULT_SYSTEM_PROMPT，或逐個對話自己填。
const DEFAULT_SYSTEM_PROMPT = process.env.AI_CHAT_DEFAULT_SYSTEM_PROMPT || '';

/** 服務是否已設定好（未設定就唔應該畀商家送訊息） */
function isConfigured() {
    return !!(getApiKey() && AI_BASE_URL && AI_MODEL);
}

/** 未設定時畀用戶睇嘅中文錯誤（唔會透露任何設定值） */
function notConfiguredMessage() {
    return 'AI 服務尚未設定完成，請聯絡系統管理員。';
}

/**
 * 串流對話。
 *
 * @param {Object}   opts
 * @param {string}   [opts.apiKey]        指定用邊條 key（逐商家 key）；唔傳 = 用平台／.env
 * @param {string}   opts.system          系統提示詞（可空）
 * @param {Array}    opts.messages        [{ role: 'user'|'assistant', content: string }]
 * @param {Function} opts.onThinking      收到思考片段時呼叫 (text)
 * @param {Function} opts.onText          收到正文片段時呼叫 (text)
 * @param {AbortSignal} [opts.signal]     外部中止訊號（客戶端斷線）
 * @returns {Promise<{usage: Object, stopReason: string|null}>}
 */
async function streamChat({ apiKey: explicitKey, system, messages, onThinking, onText, signal }) {
    const apiKey = String(explicitKey || getApiKey() || '').trim();
    if (!apiKey || !AI_BASE_URL || !AI_MODEL) throw new Error(notConfiguredMessage());

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), AI_TIMEOUT_MS);

    // 外部中止（客戶端斷線）→ 連 upstream 一齊 abort
    let clientGone = false;
    const onExternalAbort = () => { clientGone = true; controller.abort(); };
    if (signal) {
        if (signal.aborted) onExternalAbort();
        else signal.addEventListener('abort', onExternalAbort, { once: true });
    }

    try {
        const res = await fetch(`${AI_BASE_URL}/v1/messages`, {
            method: 'POST',
            headers: {
                'content-type': 'application/json',
                'authorization': `Bearer ${apiKey}`,
                'anthropic-version': AI_ANTHROPIC_VERSION,
                'accept': 'text/event-stream'
            },
            body: JSON.stringify(Object.assign(
                {
                    model: AI_MODEL,
                    max_tokens: AI_MAX_TOKENS,
                    messages,
                    stream: true
                },
                system ? { system } : {},
                AI_THINKING === null ? {} : { thinking: { type: AI_THINKING ? 'enabled' : 'disabled' } },
                AI_THINKING_EFFORT ? { output_config: { effort: AI_THINKING_EFFORT } } : {}
            )),
            signal: controller.signal
        });

        if (!res.ok) {
            // 錯誤內容截短，避免把整頁 HTML / 內部訊息回灌
            const body = await res.text().catch(() => '');
            throw new Error(`AI 服務回應 ${res.status}${body ? `：${body.slice(0, 200)}` : ''}`);
        }
        if (!res.body) throw new Error('AI 服務沒有回傳內容');

        const result = await consumeStream(res.body, { onThinking, onText });
        return result;
    } catch (e) {
        if (e.name === 'AbortError') {
            if (clientGone) throw new Error('CLIENT_DISCONNECTED');
            throw new Error(`AI 服務無回應（超過 ${Math.round(AI_TIMEOUT_MS / 1000)} 秒）`);
        }
        throw e;
    } finally {
        clearTimeout(timer);
        if (signal) signal.removeEventListener('abort', onExternalAbort);
    }
}

/**
 * 解析 Anthropic SSE 串流。
 *
 * 事件格式（實測 DeepSeek 端點）：
 *   content_block_start  → content_block.type = 'thinking' | 'text'
 *   content_block_delta  → delta.type = 'thinking_delta' | 'text_delta'
 *   message_delta        → usage.output_tokens
 *   message_stop         → 結束
 *
 * @returns {Promise<{usage: Object, stopReason: string|null}>}
 */
async function consumeStream(body, { onThinking, onText }) {
    const reader = body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let stopReason = null;
    let usage = {};

    try {
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });

            // SSE 以空行分隔事件；逐行處理，最後一行可能未完整，留返落 buffer
            const lines = buffer.split('\n');
            buffer = lines.pop();

            for (const rawLine of lines) {
                const line = rawLine.trimEnd();
                if (!line.startsWith('data:')) continue;
                const payload = line.slice(5).trim();
                if (!payload) continue;

                let evt;
                try { evt = JSON.parse(payload); } catch (e) { continue; } // 容忍非 JSON 心跳

                if (evt.type === 'content_block_delta' && evt.delta) {
                    if (evt.delta.type === 'text_delta' && evt.delta.text) {
                        onText(evt.delta.text);
                    } else if (evt.delta.type === 'thinking_delta' && evt.delta.thinking) {
                        onThinking(evt.delta.thinking);
                    }
                } else if (evt.type === 'message_delta') {
                    if (evt.delta && evt.delta.stop_reason) stopReason = evt.delta.stop_reason;
                    if (evt.usage) usage = Object.assign(usage, evt.usage);
                } else if (evt.type === 'message_start' && evt.message && evt.message.usage) {
                    usage = Object.assign(usage, evt.message.usage);
                } else if (evt.type === 'error') {
                    const msg = (evt.error && evt.error.message) || 'AI 服務發生錯誤';
                    throw new Error(msg);
                }
            }
        }
    } finally {
        // 提早出錯 / 斷線都要放返 reader，唔好留住 upstream 連線
        try { reader.releaseLock(); } catch (e) { /* 已釋放 */ }
    }

    return { usage, stopReason };
}

/**
 * 用一條指定嘅 key 做一次最小呼叫，確認佢真係有效。
 * ⚠️ 純驗證：唔會改動目前使用中嘅 key，亦唔會 log 個 key。
 * 用途係「主商家喺介面貼 key」時，存之前先確認冇打錯字。
 *
 * @param {string} apiKey 待驗證嘅 key
 * @returns {Promise<{ok: boolean, error?: string}>}
 */
async function validateKey(apiKey) {
    const key = String(apiKey || '').trim();
    if (!key) return { ok: false, error: '請輸入 API 金鑰' };

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), VALIDATE_TIMEOUT_MS);
    try {
        const res = await fetch(`${AI_BASE_URL}/v1/messages`, {
            method: 'POST',
            headers: {
                'content-type': 'application/json',
                'authorization': `Bearer ${key}`,
                'anthropic-version': AI_ANTHROPIC_VERSION
            },
            body: JSON.stringify({
                model: AI_MODEL,
                max_tokens: 1,
                messages: [{ role: 'user', content: 'hi' }]
            }),
            signal: controller.signal
        });

        if (res.ok) return { ok: true };

        // 唔同狀態碼畀唔同嘅可行建議（唔好只拋一個 HTTP code 出嚟）
        let hint;
        if (res.status === 401 || res.status === 403) hint = '金鑰無效或已被拒絕';
        else if (res.status === 404) hint = '找不到端點，請確認 AI_BASE_URL 是否包含 /anthropic 路徑';
        else if (res.status === 429) hint = '金鑰有效但已達額度上限，請先處理額度';
        else if (res.status >= 500) hint = 'AI 服務暫時故障，請稍後再試';
        else hint = `AI 服務回應 ${res.status}`;

        const body = await res.text().catch(() => '');
        return { ok: false, error: `${hint}${body ? `：${body.slice(0, 160)}` : ''}` };
    } catch (e) {
        if (e.name === 'AbortError') return { ok: false, error: '驗證逾時，請檢查網絡後再試' };
        return { ok: false, error: `無法連接 AI 服務：${e.message}` };
    } finally {
        clearTimeout(timer);
    }
}

module.exports = {
    isConfigured,
    notConfiguredMessage,
    streamChat,
    validateKey,
    setApiKey,
    getApiKey,
    keySource,
    maskedKey,
    maskKey,
    defaultSystemPrompt: () => DEFAULT_SYSTEM_PROMPT,
    // 畀 route 做輸入驗證同錯誤訊息用
    maxTokens: AI_MAX_TOKENS,
    modelName: () => AI_MODEL,
    baseUrl: () => AI_BASE_URL
};
