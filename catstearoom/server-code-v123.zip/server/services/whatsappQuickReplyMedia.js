// ─────────────────────────────────────────────────────────────
// WhatsApp 快捷回覆 — 媒體附件儲存
//
// ⚠️⚠️ 呢個檔係「用戶內容唔落磁碟」鐵律嘅**唯一例外**。
//
// 程式庫原本嘅政策（見 database/db.js 嘅 wa_messages 註解）係媒體一律唔落碟，
// 因為 2026-09-13 生產機曾因暴量日誌一日寫 12GB 而塞爆磁碟（1 核 3.4GB 無 swap）。
//
// 負責人明確選擇將快捷回覆嘅附件存喺伺服器，所以呢個檔嘅**全部意義**就係
// 用三重機制取代原本嘅保護：
//   1. 每檔硬上限（QR_MEDIA_MAX_BYTES）
//   2. 每店硬配額（bytes + 檔案數），另加全域最後防線
//   3. 孤兒清理排程（每 6 小時，唔係每日 —— 事故正正係「一日寫爆」）
//
// 改動呢個檔之前請先讀 MD Files/ALIYUN_MONITORING_GUIDE.md。
// 移除任何一重機制都等於重演同一次事故。
// ─────────────────────────────────────────────────────────────
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const runtime = require('../config/runtime');
const { db } = require('../../database/db');

// ── 上限（一律 ≤ Meta 官方上限）──
// Meta：圖片 5MB、影片 16MB、文件 100MB。負責人選擇一律 5MB。
const MAX_BYTES = 5 * 1024 * 1024;
// base64 解碼前嘅快速檢查（base64 比原始位元組大約 4/3）
const MAX_BASE64_CHARS = Math.ceil(MAX_BYTES * 4 / 3) + 16;

// ── 配額 ──
// 兩個每店上限缺一不可：60 個檔案 × 5MB = 300MB > 100MB，
// 所以「位元組」同「檔案數」邊個先綁死視乎實際大小，兩者互補。
const QUOTA_BYTES_PER_STORE = 100 * 1024 * 1024;
const MAX_FILES_PER_STORE = 60;
const QUOTA_BYTES_GLOBAL = 1024 * 1024 * 1024;   // 最後防線，觸頂要大聲記錄

// ── 清理 ──
// ⚠️ 24 小時寬限期係「唔會誤刪啱啱上傳、商家仲未撳儲存嘅檔案」嘅唯一保障。
//    縮短之前請先諗清楚：商家揀完圖、打完字、猶豫幾個鐘先撳儲存，就會被刪。
const ORPHAN_GRACE_MS = 24 * 60 * 60 * 1000;
const SWEEP_INTERVAL_MS = 6 * 60 * 60 * 1000;
const SWEEP_BOOT_DELAY_MS = 2 * 60 * 1000;

// ── MIME 白名單 ──
// ⚠️ 永不接受 image/svg+xml（SVG 可以帶 <script>，等於 stored XSS）。
// kind 直接對應 Meta 嘅訊息 type。
const MIME_EXT = {
    'image/jpeg': '.jpg',
    'image/png': '.png',
    'video/mp4': '.mp4',
    'video/3gpp': '.3gp',
    'application/pdf': '.pdf',
};
const MIME_KIND = {
    'image/jpeg': 'image',
    'image/png': 'image',
    'video/mp4': 'video',
    'video/3gpp': 'video',
    'application/pdf': 'document',
};

function kindForMime(mime) { return MIME_KIND[mime] || null; }
function isAllowedMime(mime) { return Boolean(MIME_KIND[mime]); }

/**
 * 用魔術位元組確認內容同宣稱嘅 MIME 一致。
 * 防止「evil.html 改名做 .png 再宣稱 image/png」呢類偽裝。
 * 只做便宜嘅前綴檢查，唔做完整格式驗證（Meta 會再驗一次）。
 */
function contentMatchesMime(buf, mime) {
    if (!buf || buf.length < 4) return false;
    const b = buf;
    if (mime === 'image/jpeg') return b[0] === 0xFF && b[1] === 0xD8 && b[2] === 0xFF;
    if (mime === 'image/png') {
        return b.length >= 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4E && b[3] === 0x47
            && b[4] === 0x0D && b[5] === 0x0A && b[6] === 0x1A && b[7] === 0x0A;
    }
    if (mime === 'application/pdf') {
        return b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46;   // %PDF
    }
    if (mime === 'video/mp4' || mime === 'video/3gpp') {
        // ISO BMFF：bytes 4-7 = 'ftyp'
        return b.length >= 12 && b[4] === 0x66 && b[5] === 0x74 && b[6] === 0x79 && b[7] === 0x70;
    }
    return false;
}

// ── 目錄 ──

/** store 目錄名：只准安全字元（storeId 由 env 嚟，但仍然唔可以拼到路徑外） */
function storeDirName(storeId) {
    return 'store_' + String(storeId || 'store_1').replace(/[^\w.-]/g, '_');
}

function storeDir(storeId) {
    return path.join(runtime.waMediaDir(), storeDirName(storeId));
}

function ensureStoreDir(storeId) {
    const dir = storeDir(storeId);
    fs.mkdirSync(dir, { recursive: true });
    return dir;
}

/** 由 DB 列重建絕對路徑，並確認佢冇跳出媒體根目錄（防禦性） */
function absolutePath(row) {
    const root = path.resolve(runtime.waMediaDir());
    const full = path.resolve(storeDir(row.store_id), row.storage_name);
    if (!full.startsWith(root + path.sep)) return null;
    return full;
}

// ── DB 包裝（跟倉庫既有慣例）──
function dbRun(sql, params) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function (err) {
            if (err) return reject(err);
            resolve({ changes: this.changes });
        });
    });
}
function dbGet(sql, params) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => (err ? reject(err) : resolve(row)));
    });
}
function dbAll(sql, params) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => (err ? reject(err) : resolve(rows || [])));
    });
}

// ── 配額 ──

/** 目前用量（DB 為準；亦會回傳磁碟實際大小供診斷） */
async function usageForStore(storeId) {
    const row = await dbGet(
        `SELECT COALESCE(SUM(size_bytes), 0) AS bytes, COUNT(*) AS files
           FROM wa_quick_reply_media WHERE store_id = ?`,
        [storeId]
    );
    return { bytes: (row && row.bytes) || 0, files: (row && row.files) || 0 };
}

async function usageGlobal() {
    const row = await dbGet(
        `SELECT COALESCE(SUM(size_bytes), 0) AS bytes, COUNT(*) AS files FROM wa_quick_reply_media`
    );
    return { bytes: (row && row.bytes) || 0, files: (row && row.files) || 0 };
}

// ── 儲存 ──

/** 建立一個「已上傳、未綁定」嘅媒體記錄（quick_reply_id = NULL） */
async function saveMedia({ storeId, mime, filename, base64, employeeId }) {
    const m = String(mime || '').trim().toLowerCase();
    if (!isAllowedMime(m)) {
        const e = new Error('不支援這個檔案格式，請選擇 JPG／PNG 圖片、MP4／3GP 影片或 PDF 文件');
        e.definitelyNotSent = true;
        throw e;
    }

    const raw = String(base64 || '');
    if (!raw) {
        const e = new Error('檔案內容為空');
        e.definitelyNotSent = true;
        throw e;
    }
    // ⚠️ 先檢查 base64 長度才解碼 —— 避免為一個註定被拒嘅檔案配置記憶體
    if (raw.length > MAX_BASE64_CHARS) {
        const e = new Error('檔案過大（上限 5MB）');
        e.definitelyNotSent = true;
        throw e;
    }

    // 接受 data URL 或純 base64
    const comma = raw.indexOf(',');
    const b64 = comma >= 0 ? raw.slice(comma + 1) : raw;
    const buf = Buffer.from(b64, 'base64');
    if (!buf.length) {
        const e = new Error('檔案內容無法解讀');
        e.definitelyNotSent = true;
        throw e;
    }
    if (buf.length > MAX_BYTES) {
        const e = new Error('檔案過大（上限 5MB）');
        e.definitelyNotSent = true;
        throw e;
    }
    if (!contentMatchesMime(buf, m)) {
        const e = new Error('檔案內容與格式不符，請確認檔案沒有損壞或改過副檔名');
        e.definitelyNotSent = true;
        throw e;
    }

    // 配額：先檢查，寫入後再覆核一次（處理兩個並發上傳同時通過檢查嘅競態）
    const before = await usageForStore(storeId);
    if (before.files + 1 > MAX_FILES_PER_STORE) {
        const e = new Error(`附件數量已達上限（每間店 ${MAX_FILES_PER_STORE} 個），請先刪除不再使用的附件`);
        e.definitelyNotSent = true;
        throw e;
    }
    if (before.bytes + buf.length > QUOTA_BYTES_PER_STORE) {
        const e = new Error('附件儲存空間已滿（每間店上限 100MB），請先刪除不再使用的附件');
        e.definitelyNotSent = true;
        throw e;
    }
    const g = await usageGlobal();
    if (g.bytes + buf.length > QUOTA_BYTES_GLOBAL) {
        console.error('[wa-media] ⚠️ 全域配額已滿，拒絕上傳。請檢查 wa-media/ 用量。');
        const e = new Error('系統附件儲存空間已滿，請聯絡平台');
        e.definitelyNotSent = true;
        throw e;
    }

    // 寫檔
    const id = crypto.randomUUID();
    const storageName = id + MIME_EXT[m];
    const dir = ensureStoreDir(storeId);
    const full = path.join(dir, storageName);
    fs.writeFileSync(full, buf);

    const nowIso = new Date().toISOString();
    try {
        await dbRun(
            `INSERT INTO wa_quick_reply_media
               (id, store_id, quick_reply_id, kind, mime, filename, size_bytes, storage_name,
                created_by_employee_id, created_at, updated_at)
             VALUES (?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [id, storeId, kindForMime(m), m, String(filename || '').slice(0, 200) || null,
                buf.length, storageName, employeeId || null, nowIso, nowIso]
        );
    } catch (err) {
        // 寫 DB 失敗就要撤回檔案，唔可以留低無人引用嘅檔案
        try { fs.unlinkSync(full); } catch (_) { /* 已經冇咗 */ }
        throw err;
    }

    // 寫入後覆核配額（覆蓋並發競態）
    const after = await usageForStore(storeId);
    if (after.bytes > QUOTA_BYTES_PER_STORE || after.files > MAX_FILES_PER_STORE) {
        await deleteMediaById(id, storeId);
        const e = new Error('附件儲存空間已滿（每間店上限 100MB），請先刪除不再使用的附件');
        e.definitelyNotSent = true;
        throw e;
    }

    return { id, kind: kindForMime(m), mime: m, filename: filename || '', size: buf.length };
}

/** 只刪檔案（唔刪 DB 列），ENOENT 當成功 */
function unlinkQuiet(full) {
    if (!full) return false;
    try {
        fs.unlinkSync(full);
        return true;
    } catch (e) {
        if (e.code === 'ENOENT') return true;
        console.warn('[wa-media] 刪檔失敗:', e.message);
        return false;
    }
}

/** 刪除媒體（檔案 + DB 列），同時比對 store_id */
async function deleteMediaById(id, storeId) {
    const row = await dbGet(
        `SELECT * FROM wa_quick_reply_media WHERE id = ? AND store_id = ?`, [id, storeId]
    );
    if (!row) return false;
    unlinkQuiet(absolutePath(row));
    await dbRun(`DELETE FROM wa_quick_reply_media WHERE id = ? AND store_id = ?`, [id, storeId]);
    return true;
}

/** 綁定：把待綁定嘅媒體連去一條快捷回覆（同時驗證 store 同擁有權） */
async function bindToQuickReply(mediaId, quickReplyId, storeId) {
    const out = await dbRun(
        `UPDATE wa_quick_reply_media SET quick_reply_id = ?, updated_at = ?
          WHERE id = ? AND store_id = ?`,
        [quickReplyId, new Date().toISOString(), mediaId, storeId]
    );
    return out.changes > 0;
}

/** 取單一媒體列（租戶隔離） */
async function getMedia(id, storeId) {
    return dbGet(
        `SELECT * FROM wa_quick_reply_media WHERE id = ? AND store_id = ?`, [id, storeId]
    );
}

// ── 孤兒清理 ──

/**
 * 判定孤兒並刪除。
 *
 * 方向 A（DB 列 → 檔案）：
 *   列係孤兒 ⟺ (quick_reply_id IS NULL 且 created_at 超過寬限期)
 *              或 (quick_reply_id 已唔存在於 wa_quick_replies)
 *
 * 方向 B（檔案 → DB 列）：
 *   檔案係孤兒 ⟺ mtime 超過寬限期 且 冇任何列指向佢
 *   ⚠️ 嗰個寬限期就係「唔會誤刪啱啱上傳、仲未綁定嘅檔案」嘅保障。
 *
 * @returns {Promise<{deletedRows:number, deletedFiles:number, keptUnbound:number}>}
 */
async function sweepOrphans(nowMs) {
    const now = Number.isFinite(nowMs) ? nowMs : Date.now();
    const cutoffIso = new Date(now - ORPHAN_GRACE_MS).toISOString();
    let deletedRows = 0, deletedFiles = 0, keptUnbound = 0;

    // ── 方向 A ──
    const rows = await dbAll(`SELECT * FROM wa_quick_reply_media`);
    for (const row of rows) {
        let orphan = false;
        if (!row.quick_reply_id) {
            // 待綁定：只可以喺寬限期之後刪
            if (row.created_at && row.created_at < cutoffIso) orphan = true;
            else keptUnbound++;
        } else {
            const qr = await dbGet(`SELECT id FROM wa_quick_replies WHERE id = ?`, [row.quick_reply_id]);
            if (!qr) orphan = true;
        }
        if (!orphan) continue;

        try {
            // 先刪檔後刪列：若中途失敗，下次 sweep 會再試（列仲喺度）
            unlinkQuiet(absolutePath(row));
            await dbRun(`DELETE FROM wa_quick_reply_media WHERE id = ?`, [row.id]);
            deletedRows++;
        } catch (e) {
            console.warn('[wa-media-cleanup] 處理孤兒列失敗:', row.id, e.message);
        }
    }

    // ── 方向 B：磁碟上有但 DB 冇記錄嘅檔案（DB 還原後遺留、或落檔成功但寫列失敗）──
    const root = runtime.waMediaDir();
    if (!fs.existsSync(root)) return { deletedRows, deletedFiles, keptUnbound };

    const known = new Set(rows.map((r) => path.resolve(storeDir(r.store_id), r.storage_name)));
    for (const entry of fs.readdirSync(root)) {
        const dir = path.join(root, entry);
        let st;
        try { st = fs.statSync(dir); } catch (_) { continue; }
        if (!st.isDirectory()) continue;
        for (const f of fs.readdirSync(dir)) {
            const full = path.join(dir, f);
            if (known.has(path.resolve(full))) continue;
            try {
                const fst = fs.statSync(full);
                if (!fst.isFile()) continue;
                // ⚠️ 只刪超過寬限期嘅檔案
                if (now - fst.mtimeMs <= ORPHAN_GRACE_MS) continue;
                if (unlinkQuiet(full)) deletedFiles++;
            } catch (e) {
                console.warn('[wa-media-cleanup] 處理孤兒檔失敗:', full, e.message);
            }
        }
    }

    return { deletedRows, deletedFiles, keptUnbound };
}

/** 啟動清理排程（模仿 scheduleMidnightLogCleanup；唔可以用 setImmediate） */
function startWhatsappMediaCleanup() {
    let sweeping = false;
    const run = () => {
        if (sweeping) return;                 // 重入鎖：慢速掃描唔好同下個 tick 重疊
        sweeping = true;
        sweepOrphans()
            .then((r) => {
                if (r.deletedRows || r.deletedFiles) {
                    console.log(`[wa-media-cleanup] 已清除 ${r.deletedRows} 條孤兒記錄、${r.deletedFiles} 個孤兒檔（保留 ${r.keptUnbound} 個待綁定）`);
                }
            })
            .catch((e) => console.error('[wa-media-cleanup] 清理失敗:', e.message))
            .finally(() => { sweeping = false; });
    };

    setTimeout(() => {
        console.log('[wa-media-cleanup] 媒體孤兒清理排程已啟動');
        run();
        setInterval(run, SWEEP_INTERVAL_MS);
    }, SWEEP_BOOT_DELAY_MS);
}

module.exports = {
    MAX_BYTES,
    MAX_BASE64_CHARS,
    QUOTA_BYTES_PER_STORE,
    MAX_FILES_PER_STORE,
    QUOTA_BYTES_GLOBAL,
    ORPHAN_GRACE_MS,
    MIME_EXT,
    isAllowedMime,
    kindForMime,
    contentMatchesMime,
    storeDirName,
    storeDir,
    absolutePath,
    saveMedia,
    deleteMediaById,
    bindToQuickReply,
    getMedia,
    usageForStore,
    usageGlobal,
    sweepOrphans,
    startWhatsappMediaCleanup,
};
