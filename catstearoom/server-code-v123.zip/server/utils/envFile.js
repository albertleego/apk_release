/**
 * `.env` 檔案寫入工具
 *
 * 用途：保守地更新／新增 `.env` 內的 `KEY=VALUE` 行，**不觸碰檔案其餘內容**
 * （保留註解、空行、排列順序與既有格式）。
 *
 * 背景：原本 `server/index.js` 的 `writeEnvKey()` 只做 `KEY=${value}` 直插，
 * 值若含 `#`、空白或引號會損壞該行。KPay 設定界面會寫入
 * `KPAY_APP_SECRET`（官方規格 1–64 字元，可能含特殊符號），所以需要強化。
 *
 * ⚠️ dotenv 的解析規則（v17）直接決定了這裡的跳脫策略：
 *   - 值用雙引號包裹時，dotenv **只還原 `\n` 與 `\r`**，其他反斜線序列原樣保留
 *     → 所以 `\"` 這種寫法**無法還原成 `"`**，含雙引號的值不能安全地寫入
 *   - dotenv **不做變數展開**（未使用 dotenv-expand）
 *     → `$` 不需要跳脫（本專案的 `KPAY_APP_SECRET` 就含 `$$`，已實測可完整載入）
 *   - 未加引號的值會被 trim，且 `#` 之後視為註解
 *     → 含 `#` 或前後空白的值必須加雙引號
 */

const fs = require('fs');
const path = require('path');

// 合法的環境變數名稱
const KEY_RE = /^[A-Za-z_][A-Za-z0-9_]*$/;

// 不需引號即可安全寫入的字元集（不含空白、`#`、引號、反斜線）
const SAFE_VALUE_RE = /^[A-Za-z0-9_./:@+^$*,;=!?()[\]{}|~-]*$/;

/**
 * 將值編碼成可安全寫入 `.env` 的形式。
 * @throws {Error} 值含有無法安全往返的字元時
 */
function encodeValue(value) {
  const s = String(value === undefined || value === null ? '' : value);

  if (s.includes('\n') || s.includes('\r')) {
    throw new Error('值不可包含換行');
  }
  // dotenv 無法還原雙引號內的 \" ，含引號的值寫入後會與原值不符
  if (s.includes('"') || s.includes("'") || s.includes('`')) {
    throw new Error('值不可包含引號（dotenv 無法安全還原）');
  }
  if (s === '' || SAFE_VALUE_RE.test(s)) return s;

  // 其餘（含 `#`、空白、反斜線等）→ 雙引號包裹
  return `"${s.replace(/\\/g, '\\\\')}"`;
}

/**
 * 找出某個 key 在檔案中的行索引；找不到回 -1。
 * 只認行首（容許 `export ` 前綴與縮排），避免誤中註解內的字串。
 */
function findKeyLine(lines, key) {
  for (let i = 0; i < lines.length; i++) {
    const stripped = lines[i].replace(/^\s*(?:export\s+)?/, '');
    if (stripped.startsWith(`${key}=`)) return i;
  }
  return -1;
}

/**
 * 更新／新增多個 key。
 *
 * @param {string} envPath  .env 檔案路徑
 * @param {Object} patch    { KEY: value }；value 為 undefined 的項目會被略過
 * @param {Object} [opts]
 * @param {boolean} [opts.backup=true]  寫入前是否備份為 <env>.bak-kpay-<timestamp>
 * @returns {{ changed: string[], backupPath: string|null }}
 */
function writeEnvKeys(envPath, patch, opts = {}) {
  const { backup = true } = opts;

  const entries = Object.entries(patch || {}).filter(([, v]) => v !== undefined);
  if (entries.length === 0) return { changed: [], backupPath: null };

  for (const [key] of entries) {
    if (!KEY_RE.test(key)) throw new Error(`不合法的環境變數名稱: ${key}`);
  }

  let content = '';
  try {
    content = fs.readFileSync(envPath, 'utf8');
  } catch (e) {
    if (e.code !== 'ENOENT') throw e;
    content = '';
  }

  // 統一用 \n 處理，最後有需要才還原原檔案的換行風格
  const usesCRLF = content.includes('\r\n');
  const normalized = content.replace(/\r\n/g, '\n');
  const hadTrailingNewline = normalized.endsWith('\n');
  const lines = normalized.split('\n');
  if (hadTrailingNewline) lines.pop(); // 尾端空字串

  const changed = [];
  for (const [key, rawValue] of entries) {
    const line = `${key}=${encodeValue(rawValue)}`;
    const idx = findKeyLine(lines, key);
    if (idx === -1) {
      lines.push(line);
      changed.push(key);
      continue;
    }
    if (lines[idx] !== line) {
      lines[idx] = line;
      changed.push(key);
    }
  }

  if (changed.length === 0) return { changed: [], backupPath: null };

  const out = lines.join('\n') + '\n';

  let backupPath = null;
  if (backup && fs.existsSync(envPath)) {
    // 本地時間 YYYYMMDD_HHMMSS
    const d = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    const stamp = `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}`
      + `_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
    backupPath = `${envPath}.bak-kpay-${stamp}`;
    fs.copyFileSync(envPath, backupPath);
  }

  fs.writeFileSync(envPath, usesCRLF ? out.replace(/\n/g, '\r\n') : out, 'utf8');
  return { changed, backupPath };
}

/**
 * 讀取 `.env` 內某個 key 的「值是否有設定」（不讀出值本身，避免機密進入記憶體外的場合）。
 * @returns {boolean}
 */
function hasEnvKey(envPath, key) {
  let content = '';
  try {
    content = fs.readFileSync(envPath, 'utf8');
  } catch (_) {
    return false;
  }
  const lines = content.replace(/\r\n/g, '\n').split('\n');
  const idx = findKeyLine(lines, key);
  if (idx === -1) return false;
  const raw = lines[idx].replace(/^\s*(?:export\s+)?/, '').slice(key.length + 1).trim();
  // 空值或僅有空引號 → 視為未設定
  return raw !== '' && raw !== '""' && raw !== "''";
}

module.exports = { writeEnvKeys, hasEnvKey, encodeValue, findKeyLine };
