/**
 * 香港時間工具
 * 香港時間為 UTC+8，無夏令時
 */

/**
 * 獲取當前香港時間的 Date 對象
 * @returns {Date} 香港時間的 Date 對象
 */
function getHongKongTime() {
    const now = new Date();
    return convertToHongKongTime(now);
}

/**
 * 將任意 Date 對象轉換為香港時間
 * @param {Date} date - 原始 Date 對象（假設為 UTC 或本地時間）
 * @returns {Date} 香港時間的 Date 對象
 */
function convertToHongKongTime(date) {
    // 方法1：如果設置了時區環境變量，直接返回新 Date（使用本地方法）
    // 方法2：手動計算 UTC+8
    const utcTime = date.getTime() + (date.getTimezoneOffset() * 60000);
    const hongKongTime = new Date(utcTime + (8 * 60 * 60000));
    return hongKongTime;
}

/**
 * 獲取香港時間的日期字符串（YYYY-MM-DD）
 * @param {Date} [date] - 可選的 Date 對象，默認當前時間
 * @returns {string} YYYY-MM-DD 格式的日期字符串
 */
function getHongKongDateString(date = null) {
    const hkDate = date ? convertToHongKongTime(date) : getHongKongTime();
    const year = hkDate.getFullYear();
    const month = String(hkDate.getMonth() + 1).padStart(2, '0');
    const day = String(hkDate.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

/**
 * 獲取香港時間的時間字符串（HH:MM）
 * @param {Date} [date] - 可選的 Date 對象，默認當前時間
 * @returns {string} HH:MM 格式的時間字符串
 */
function getHongKongTimeString(date = null) {
    const hkDate = date ? convertToHongKongTime(date) : getHongKongTime();
    const hours = String(hkDate.getHours()).padStart(2, '0');
    const minutes = String(hkDate.getMinutes()).padStart(2, '0');
    return `${hours}:${minutes}`;
}

/**
 * 獲取香港時間的星期幾
 * 0 = 星期日, 1 = 星期一, ..., 6 = 星期六
 * @param {Date} [date] - 可選的 Date 對象，默認當前時間
 * @returns {number} 星期幾（0-6）
 */
function getHongKongDayOfWeek(date = null) {
    const hkDate = date ? convertToHongKongTime(date) : getHongKongTime();
    return hkDate.getDay();
}

/**
 * 檢查指定日期是否為香港時間的節假日（星期六、星期日）
 * @param {Date} [date] - 可選的 Date 對象，默認當前時間
 * @returns {boolean} 是否為節假日
 */
function isHongKongWeekend(date = null) {
    const dayOfWeek = getHongKongDayOfWeek(date);
    return dayOfWeek === 0 || dayOfWeek === 6; // 星期日或星期六
}

/**
 * 獲取完整的香港時間信息對象
 * @param {Date} [date] - 可選的 Date 對象，默認當前時間
 * @returns {Object} 包含香港時間各組件的對象
 */
function getHongKongTimeInfo(date = null) {
    const hkDate = date ? convertToHongKongTime(date) : getHongKongTime();
    return {
        date: hkDate,
        dateString: getHongKongDateString(hkDate),
        timeString: getHongKongTimeString(hkDate),
        dayOfWeek: getHongKongDayOfWeek(hkDate),
        isWeekend: isHongKongWeekend(hkDate),
        year: hkDate.getFullYear(),
        month: hkDate.getMonth() + 1,
        day: hkDate.getDate(),
        hours: hkDate.getHours(),
        minutes: hkDate.getMinutes(),
        seconds: hkDate.getSeconds()
    };
}

// ─────────────────────────────────────────────────────────────
// 營業時間判斷（WhatsApp 自動回覆用）
//
// ⚠️ 刻意**唔用**上面嘅 getHongKongTimeInfo()。嗰個函式會將一個已經轉換
//    過嘅 Date 再轉換一次（getHongKongTimeInfo → convertToHongKongTime →
//    getHongKongDateString → convertToHongKongTime）。喺 TZ 設為
//    Asia/Hong_Kong 嘅伺服器上，convertToHongKongTime 剛好係恆等函式，
//    所以睇唔出問題；一旦伺服器時區唔同就會偏移。
//
// 下面嘅實作改成：將瞬間加 8 小時後用 **UTC getter** 讀取。
// 香港冇夏令時，所以呢個做法完全精確，而且**完全唔受伺服器 TZ 影響**。
// ─────────────────────────────────────────────────────────────

/**
 * 由一個瞬間取出香港時間嘅星期同「由午夜起嘅分鐘數」。
 * @param {number} [atMs] 毫秒時間戳；預設現在
 * @returns {{dayOfWeek:number, minutes:number}} dayOfWeek 0=星期日
 */
function hongKongParts(atMs) {
    const ms = Number.isFinite(atMs) ? atMs : Date.now();
    const shifted = new Date(ms + 8 * 3600 * 1000);
    return {
        dayOfWeek: shifted.getUTCDay(),
        minutes: shifted.getUTCHours() * 60 + shifted.getUTCMinutes(),
    };
}

/**
 * 格式化為「HH:MM DD/MM/YYYY」（香港時間）。
 *
 * ⚠️ 同 hongKongParts 一樣用「加 8 小時後讀 UTC 欄位」嘅做法，
 *    唔靠伺服器嘅 TZ —— 生產機 TZ=Asia/Hong_Kong、開發機可能唔係。
 *
 * @param {number} atMs
 * @returns {string} 例如 "16:45 28/09/2026"
 */
function formatHongKongStamp(atMs) {
    const ms = Number.isFinite(atMs) ? atMs : Date.now();
    const d = new Date(ms + 8 * 3600 * 1000);
    const p2 = (n) => String(n).padStart(2, '0');
    return `${p2(d.getUTCHours())}:${p2(d.getUTCMinutes())} `
        + `${p2(d.getUTCDate())}/${p2(d.getUTCMonth() + 1)}/${d.getUTCFullYear()}`;
}

/**
 * 解析 "HH:MM" 或 "HH:MM:SS"（<input type="time"> 喺部分瀏覽器會回後者）。
 * @returns {number|null} 由午夜起嘅分鐘數；格式錯誤回 null
 */
function parseHm(s) {
    if (typeof s !== 'string') return null;
    const m = s.trim().match(/^(\d{1,2}):(\d{2})(?::\d{2})?$/);
    if (!m) return null;
    const h = parseInt(m[1], 10);
    const min = parseInt(m[2], 10);
    if (!Number.isFinite(h) || !Number.isFinite(min)) return null;
    if (h < 0 || h > 23 || min < 0 || min > 59) return null;
    return h * 60 + min;
}

/**
 * 判斷某個瞬間是否喺營業時間內。
 *
 * @param {object} schedule `{ days: [{day:0-6, closed:boolean, open:'HH:MM', close:'HH:MM'}, ...] }`
 * @param {number} [atMs] 毫秒時間戳；預設現在
 * @returns {boolean}
 *
 * 規則（逐條寫死，避免靠猜）：
 *   · open <  close → 在內 ⟺ t >= open && t < close（**close 為開區間**：
 *     18:00 收工代表 18:00 已經唔在內）
 *   · open >  close → 跨夜窗。當日：t >= open；跨夜部分由**翌日**接手
 *   · open === close → 當作休息（零長度）。⚠️ 唔好靠猜「00:00-00:00 = 24 小時」
 *   · 當日 closed → 當日窗口完全唔適用
 *   · 跨夜溢出：前一日開跨夜窗且 t < 前一日 close → 在內（前一日休息則不適用）
 *
 * ⚠️ Fail-safe 方向：**一律偏向「喺營業時間內」**。
 *    錯認「休息中」會令商家永遠測唔到佢主要嘅問候語（等於功能壞咗但睇唔出）；
 *    錯認「營業中」最多係半夜用咗在內問候語（無害）。
 *    所以設定缺失／格式錯誤一律當 24 小時營業。
 */
function isWithinBusinessHours(schedule, atMs) {
    const days = schedule && Array.isArray(schedule.days) ? schedule.days : null;
    // 設定無效 → 當 24 小時營業（fail-safe）
    if (!days || days.length !== 7) return true;

    const byDay = {};
    for (const d of days) {
        if (!d || !Number.isInteger(d.day) || d.day < 0 || d.day > 6) return true;
        const open = parseHm(d.open);
        const close = parseHm(d.close);
        if (!d.closed && (open === null || close === null)) return true;   // 格式錯 → 當 24 小時
        if (!d.closed && open === close) {
            // 零長度窗：當休息。我哋唔猜「00:00-00:00」係咩意思。
            byDay[d.day] = { closed: true, open, close };
        } else {
            byDay[d.day] = { closed: Boolean(d.closed), open, close };
        }
    }
    if (Object.keys(byDay).length !== 7) return true;

    const { dayOfWeek: d, minutes: t } = hongKongParts(atMs);
    const today = byDay[d];
    if (!today) return true;

    if (!today.closed) {
        if (today.open < today.close) {
            if (t >= today.open && t < today.close) return true;
        } else {
            // 跨夜：當日由 open 起
            if (t >= today.open) return true;
        }
    }

    // 跨夜溢出：前一日嘅窗延伸到今日凌晨
    const pd = (d + 6) % 7;
    const prev = byDay[pd];
    if (prev && !prev.closed && prev.open > prev.close && t < prev.close) return true;

    return false;
}

module.exports = {
    getHongKongTime,
    convertToHongKongTime,
    getHongKongDateString,
    getHongKongTimeString,
    getHongKongDayOfWeek,
    isHongKongWeekend,
    getHongKongTimeInfo,
    // 營業時間（自動回覆用）
    hongKongParts,
    formatHongKongStamp,
    parseHm,
    isWithinBusinessHours
};