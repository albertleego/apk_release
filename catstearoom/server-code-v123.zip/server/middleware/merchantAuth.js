/**
 * merchantAuth.js — Merchant 登入「第一道大門」（BACKEND 最外層額外閘）
 *
 * 概念：每個 merchant server（BACKEND，阿里雲）喺員工登入之外，多一層屬於商家
 * 自己嘅大門。過閘先載入頁面；頁面內部員工(officer/admin)登入完全照舊（純額外一層）。
 *
 * 機制：httpOnly cookie `merchant_token`（記住 ~30 日）對應 sessions 表一條
 * role='merchant' 嘅 session。merchantGate 只攔「已知 HTML 文件」GET，無有效
 * cookie 就 redirect 去 /merchant-login。EDGE（平板）唔 mount 呢個 gate（runtime flag off）。
 *
 * 唔郁 server/middleware/auth.js：員工 auth（Bearer token / requireAdmin / sliding TTL）
 * 完全唔受影響；merchant session 唔 sliding（固定 30 日，避免每次 page load 縮短）。
 *
 * ─────────────────────────────────────────────────────────────
 * ⚠️⚠️ 兩道閘：分工要分清楚（2026-09-28 加入）
 *
 *   第一道閘 = merchant cookie。**純粹係大門** —— 決定「呢部機用唔用得呢個
 *              系統」，**唔決定任何權限**。「商家」唔係一個身分。
 *   第二道閘 = 職員身分（req.actor）。**呢個才決定權限。**
 *              讀嘅係員工登入（/api/auth/login）設定嘅 `token` cookie ——
 *              同 group-booking 共用同一個登入（同 origin 自動送出 cookie）。
 *
 *   actor.role = 'admin'  → 可以改設定（模板／快捷／自動回覆／職員帳號）
 *   actor.role = 'officer'→ 可以回覆客人、改對話負責角色／狀態，但唔可以改設定
 *   actor = null          → 只可以讀；唔可以回覆
 *
 * ⚠️ 完全冇「商家」這個 actor。所以「因為商家仍登入中而誤用商家權限」
 *    呢一整類漏洞唔存在 —— 因為根本冇商家權限可言。
 *
 * ⚠️ 第二道閘**唔係硬邊界**：識 admin 密碼嘅人本來就登入得到（而且見下面
 *    GATED_FOLDER_ROOTS 嘅註解 —— 所有正式員工都知 merchant 帳密）。
 *    佢嘅價值係**問責**（睇得出訊息係邊個回）同**防誤觸**，唔係安全圍牆。
 *    唔好當佢係安全邊界嚟設計。
 * ─────────────────────────────────────────────────────────────
 */
const { db } = require('../../database/db');

const MERCHANT_COOKIE = 'merchant_token';
// Merchant session 有效期（小時）：預設 720 = 30 日（「記住 1 個月」）
const MERCHANT_SESSION_HOURS = parseInt(process.env.MERCHANT_SESSION_HOURS || '720', 10);

/**
 * 職員身分讀嘅 cookie 名。
 * ⚠️ 一定要用 `token` —— 呢個係 `authRoutes.js` 員工登入（/api/auth/login）已經
 *    設定嘅 cookie。用同一個名先可以做到「登入過 group-booking，入到收件匣
 *    就當已登入」。
 * ⚠️ 唔可以同 merchant 嘅 `merchant_token` 混淆：兩者係唔同嘅閘。
 */
const STAFF_COOKIE = 'token';

/**
 * 邊啲 role 可以做收件匣嘅操作者。
 * ⚠️ 刻意**唔包括 `'staff'`** —— 店舖平板本身登入嘅帳號就係 role='staff'。
 *    照收嘅話平板帳號會變成收件匣嘅操作者，反而商家入唔到。
 */
const INBOX_ACTOR_ROLES = ['admin', 'officer'];

// ── 極細 cookie header parser（repo 冇 cookie-parser，唔為咗一個 cookie 加 npm dep）──
function parseCookies(header) {
    const out = {};
    if (!header) return out;
    header.split(';').forEach((part) => {
        const idx = part.indexOf('=');
        if (idx === -1) return;
        const key = part.slice(0, idx).trim();
        let val = part.slice(idx + 1).trim();
        if (!key) return;
        try { val = decodeURIComponent(val); } catch (e) { /* 保留原值 */ }
        out[key] = val;
    });
    return out;
}

function getMerchantToken(req) {
    return parseCookies(req.headers.cookie)[MERCHANT_COOKIE] || null;
}

// DB 驗證：sessions JOIN employees，只認 role='merchant' + 未過期 + active
// cb(err, row) — row = { session_id, employee_id, username, full_name, role }
function validateMerchantToken(token, cb) {
    if (!token) return cb(null, null);
    db.get(
        `SELECT s.id AS session_id, e.id AS employee_id, e.username, e.full_name, e.role, e.is_active
           FROM sessions s JOIN employees e ON e.id = s.employee_id
          WHERE s.token = ? AND s.expires_at > ? AND e.role = 'merchant'`,
        [token, new Date().toISOString()],
        (err, row) => {
            if (err) return cb(err);
            if (!row || row.is_active !== 1) return cb(null, null);
            cb(null, row);
        }
    );
}

// ── Path classify（正表保護）：後台資料夾只放行「白名單靜態資源」 ──
//
// ⚠️ 2026-09-30 修正：原本嘅規則係「只有 .html 先閘，其餘全部放行」，
//    即係後台資料夾入面**任何非 .html 檔案都對外公開**。實測
//    /group-booking/confirm.html.bak.20260923-103715 回 HTTP 200 +
//    application/octet-stream，完全繞過商家閘（正常 confirm.html 係 302）。
//    備份檔、.py 原始碼、.sql、.zip 等等全部中招。
//    已改為白名單：唔喺 STATIC_ASSET_RE 名單上嘅路徑（包括冇副檔名、
//    多重副檔名如 .html.bak）一律當 'gate'。
//    影響：/group-booking/*.py（mark_daily_to_sheet.py 等）由公開變成要登入 ——
//    呢啲 script 係伺服器端 spawn 執行，唔會經 HTTP 讀取，所以冇影響。
const GATED_FOLDER_ROOTS = [
    '/entry-machine',
    '/cashier',
    '/vending-machine',
    '/exit-machine',
    '/group-booking',
    '/mc-report',
    '/merchant-account',
    // 商家專區（flag: ENABLE_MERCHANT_CHAT）。未登入 merchant 就轉去
    // /merchant-login?next=/merchant/；assets（.js/.css）照舊放行。
    // ⚠️ 唔會撞到 /merchant-login 同 /merchant-account：Express 掛載路徑要
    //    下一個字元係 '/' 或字串結尾，'-' 唔符合。
    '/merchant',
    // WhatsApp 收件匣（flag: ENABLE_WHATSAPP）。未登入 merchant 就轉去
    // /merchant-login?next=/whatsapp-inbox/；assets（.js/.css/icon.svg）照舊放行。
    '/whatsapp-inbox',
    // 員工考核（/staff-training）。所有正式員工都知 merchant 帳密，所以用同一道閘；
    // 未登入就轉去 /merchant-login?next=/staff-training/，assets（.js/.css）照舊放行。
    '/staff-training',
    // 領養申請審核後台（/adoption-admin）。未登入就轉去
    // /merchant-login?next=/adoption-admin/，assets 照舊放行。
    // ⚠️ 呢個只係大門；真正嘅權限判斷係 requireActor（見 adoptionRoutes.js）。
    '/adoption-admin'
];
// 白名單：後台資料夾底下可以唔登入就攞到嘅靜態資源副檔名。
// 呢個名單係對照所有 GATED_FOLDER_ROOTS 入面實際引用過嘅資源而定
// （.js / .css / .json / .svg / .png），其餘係同類資源嘅合理延伸。
// ⚠️ 唔好加 .html —— 頁面本身一定要閘。
const STATIC_ASSET_RE = /\.(?:js|mjs|css|json|webmanifest|svg|png|jpe?g|gif|webp|ico|bmp|woff2?|ttf|otf|eot|mp3|mp4|webm|wav|ogg)$/i;

function classifyPath(p) {
    // 單頁 entry
    if (p === '/' || p === '/admin-config') return 'gate';
    // 員工「顧客預約管理」都係後台 → 閘
    if (p === '/booking/manage.html') return 'gate';
    // 其餘 /booking/* = 客用（booking / waitinglist / mybooking / index）→ 唔閘
    if (p === '/booking' || p === '/booking/' || p.startsWith('/booking/')) return 'pass';
    // merchant-login 頁本身永遠唔 redirect（防 redirect 迴圈）
    if (p === '/merchant-login' || p.startsWith('/merchant-login/')) return 'pass';
    // 後台 folder roots：root 或 root/ → 閘；入面只有白名單靜態資源放行
    for (let i = 0; i < GATED_FOLDER_ROOTS.length; i++) {
        const r = GATED_FOLDER_ROOTS[i];
        if (p === r || p === r + '/') return 'gate';
        if (p.startsWith(r + '/')) return STATIC_ASSET_RE.test(p) ? 'pass' : 'gate';
    }
    return 'pass';
}

// redirect 目標 sanitize：只准同一 origin 相對路徑
function sanitizeNextUrl(raw) {
    if (!raw) return null;
    const u = String(raw).trim();
    if (u.length > 500) return null;
    // 必須單個 '/' 開頭（排除 '//host'、'https://...' 等 open redirect）
    if (!/^\/(?!\/)/.test(u)) return null;
    // 唔准 backslash / CRLF
    if (/[\\\r\n]/.test(u)) return null;
    return u;
}

function redirectToMerchantLogin(req, res) {
    const next = sanitizeNextUrl(req.originalUrl || req.url) || '/';
    return res.redirect('/merchant-login?next=' + encodeURIComponent(next));
}

function clearMerchantCookie(res) {
    res.clearCookie(MERCHANT_COOKIE, { path: '/', httpOnly: true, sameSite: 'lax' });
}

function setMerchantCookie(res, token) {
    // secure 用 env 控制（預設 false 先測到 http://localhost:3002；production https 開 true）
    res.cookie(MERCHANT_COOKIE, token, {
        // ⚠️ 明寫 path —— clearMerchantCookie 都明寫 '/'，兩邊一定要一致。
        //    之前一個寫一個靠 Express 預設值，靠「啱好一樣」，係地雷。
        path: '/',
        httpOnly: true,
        secure: process.env.MERCHANT_COOKIE_SECURE === 'true',
        sameSite: 'lax',
        maxAge: MERCHANT_SESSION_HOURS * 3600 * 1000 // ~30 日
    });
}

// ── Page gate middleware（只攔 HTML document GET）──
function merchantGate(req, res, next) {
    if (req.method !== 'GET') return next();
    if (classifyPath(req.path) !== 'gate') return next();

    const token = getMerchantToken(req);
    if (!token) return redirectToMerchantLogin(req, res);

    validateMerchantToken(token, (err, row) => {
        if (err || !row) {
            clearMerchantCookie(res);
            return redirectToMerchantLogin(req, res);
        }
        req.merchant = row; // { session_id, employee_id, username, full_name, role }
        next();
    });
}

// ── API middleware（讀 cookie，JSON 401）──
function requireMerchant(req, res, next) {
    // ⚠️ 冪等：可能喺 server/index.js 嘅資料夾層掛過一次，router 內部又再掛。
    //    已經驗過就唔好重複查 DB。
    if (req.merchant) return next();

    const token = getMerchantToken(req);
    if (!token) {
        // code 令前端分得出要彈「商家登入」定「職員登入」—— 混淆會造成登入迴圈
        return res.status(401).json({
            success: false, code: 'MERCHANT_REQUIRED', error: '未登入 merchant',
        });
    }
    validateMerchantToken(token, (err, row) => {
        if (err) {
            return res.status(500).json({ success: false, error: '驗證 merchant session 失敗' });
        }
        if (!row) {
            clearMerchantCookie(res);
            return res.status(401).json({
                success: false, code: 'MERCHANT_REQUIRED',
                error: 'merchant session 無效或已過期',
            });
        }
        req.merchant = row;
        next();
    });
}

/**
 * 輕量同源檢查（cookie 認證嘅端點唔應該只靠 sameSite=lax）。
 *
 * ⚠️ `sec-fetch-site` 係**全小寫** —— 寫 `req.headers['Sec-Fetch-Site']` 會永遠
 *    undefined，檢查就變成 no-op（靜默失效，唔會報錯）。所以集中喺呢度寫一次。
 * 舊瀏覽器冇呢個 header 時唔阻擋（避免影響可用性）。
 *
 * ⚠️ 由 WhatsApp 內開連結入嚟時，sec-fetch-site 會係 cross-site → 403。
 *    呢個係預期行為，唔係 bug。
 */
function requireSameOrigin(req, res, next) {
    const site = req.headers['sec-fetch-site'];
    if (site && site !== 'same-origin') {
        return res.status(403).json({ success: false, error: '拒絕跨站請求' });
    }
    next();
}

// ─────────────────────────────────────────────────────────────
// 第二道閘：職員身分（actor）
//
// ⚠️ 一定要掛喺**資料夾層**（server/index.js），唔好逐個 router 掛 ——
//    逐個掛嘅話，任何一條新路由漏掛就等於開咗一個洞。掛喺資料夾層
//    就冇「漏掛」呢回事。
// ─────────────────────────────────────────────────────────────

/**
 * 解析職員身分。**唔會**拒絕請求 —— 冇身分就 `req.actor = null`。
 *
 * 讀 `token` cookie（員工登入設定嘅），查 sessions JOIN employees。
 * 只有 role ∈ {admin, officer} 且未過期且 is_active=1 才算數。
 *
 * ⚠️ DB 出錯時當「冇身分」而唔係回 500：收件匣仍然睇得到（唯讀），
 *    唔會因為一次查詢失敗而整個介面白畫面。而「冇身分」已經係最保守嘅
 *    結果（唔可以回覆、唔可以改設定）。
 * ⚠️ session 過期一樣當「冇身分」，唔會 401 —— 否則同事嘅 session 過期會
 *    連累同機嘅人。代價係會靜默變回「未登入」，所以前端一定要把目前
 *    身分顯示得清楚。
 */
function resolveActor(req, res, next) {
    req.actor = null;
    const token = parseCookies(req.headers.cookie)[STAFF_COOKIE];
    if (!token) return next();

    db.get(
        `SELECT e.id AS employee_id, e.username, e.full_name, e.role, e.is_active
           FROM sessions s JOIN employees e ON e.id = s.employee_id
          WHERE s.token = ? AND s.expires_at > ?`,
        [token, new Date().toISOString()],
        (err, row) => {
            if (err) {
                console.error('[auth] 解析職員身分失敗:', err.message);
                return next();
            }
            if (row && row.is_active === 1 && INBOX_ACTOR_ROLES.indexOf(String(row.role)) !== -1) {
                req.actor = {
                    role: String(row.role),
                    employee_id: row.employee_id,
                    username: row.username,
                    name: row.full_name || row.username || '',
                };
            }
            next();
        }
    );
}

/**
 * 需要職員身分才可以做嘅事：回覆客人、改對話負責角色／狀態。
 *
 * ⚠️ 用 403 而唔係 401：第一道閘已經過咗，只係未登入職員身分。
 *    前端要靠 `code` 分得出應該彈「商家登入」定「職員登入」。
 */
function requireActor(req, res, next) {
    if (!req.actor) {
        return res.status(403).json({
            success: false, code: 'STAFF_REQUIRED',
            error: '請先登入職員身分（admin 或 officer）',
        });
    }
    next();
}

/**
 * 需要 admin 才可以做嘅事：**所有設定** —— 模板、快捷回覆、自動回覆、
 * 職員帳號管理。
 *
 * ⚠️ 商家帳號本身冇呢個權限 —— 「商家」只係第一道閘，唔係身分。
 */
function requireAdminActor(req, res, next) {
    if (!req.actor || req.actor.role !== 'admin') {
        return res.status(403).json({
            success: false, code: 'ADMIN_REQUIRED',
            error: '只有管理員（admin）可以修改設定',
        });
    }
    next();
}

module.exports = {
    MERCHANT_COOKIE,
    STAFF_COOKIE,
    INBOX_ACTOR_ROLES,
    MERCHANT_SESSION_HOURS,
    merchantSessionMs: () => MERCHANT_SESSION_HOURS * 3600 * 1000,
    parseCookies,
    getMerchantToken,
    validateMerchantToken,
    classifyPath,
    sanitizeNextUrl,
    merchantGate,
    requireMerchant,
    resolveActor,
    requireActor,
    requireAdminActor,
    requireSameOrigin,
    setMerchantCookie,
    clearMerchantCookie
};
