/**
 * 員工考核題庫（貓之茶房）
 *
 * 兩條軌：
 *   FT（全職）— 24 題，來源 Google Form「貓之茶房 - 全職員工培訓測驗」
 *   PT（兼職）— 15 題，來源 Google Form「貓之茶房 - 兼職員工培訓測驗」
 *
 * 答案：2026-09-24 由店主逐題核對確認（Google Form 公開資料不含答案，呢份係唯一來源）。
 *       PT 嘅 15 題經程式逐字比對，題目同選項同 FT 對應題完全相同，
 *       所以直接沿用同一批已確認答案，唔使重新確認。
 *
 * ⚠️ 呢個檔案含正確答案，只可以留喺伺服器端。
 *    對外 API（GET /api/staff-training/quiz）只會回傳題目，唔會回傳 answers。
 *
 * answers 用 0-based 索引指向同一題嘅 options 陣列。
 * 評分採「全對才算答對」：所選集合必須與 answers 完全相同（不多不少）。
 */

// 題目池：id 係穩定識別碼，兩條軌共用，避免同一條題目寫兩份而走樣
const QUESTION_POOL = [
    {
        id: 1,
        text: '小朋友出現較輕程度的不守規則 (例如奔跑, 較大聲說話), 應如何處理?',
        options: [
            '請小朋友離場',
            '提醒小朋友規則',
            '提醒家長跟隨小朋友',
            '提醒所有同事幫忙留意家長是否有跟隨小朋友'
        ],
        answers: [1, 2]
    },
    {
        id: 2,
        text: '冷氣關閉前需要做什麼, 以防止出現霉味',
        options: [
            '調到最凍開最少30分鐘',
            '調到風扇mode 開最少30分鐘',
            '直接按關機'
        ],
        answers: [1]
    },
    {
        id: 3,
        text: '小朋友無法控制 (例如持續奔跑或大叫, 粗魯對待貓貓, 入場前已表現不受控制), 應如何處理?',
        options: [
            '三次提醒後請客人離場',
            '提醒小朋友規則',
            '提醒家長跟隨小朋友',
            '提醒所有同事幫忙留意家長是否有跟隨小朋友'
        ],
        answers: [0, 1, 2, 3]
    },
    {
        id: 4,
        text: '小朋友提醒三次需要請離開的講法',
        options: [
            '1. 唔好意思, 我諗小朋友都係年紀比較細, 可能都需要請您們提早離場',
            '2. 呢邊收您首小時$58 (假日期$68) 就OK, 唔該哂',
            '2. 呢邊睇番你地坐左XX分鐘, 咁我們淨係收你地XX (每10分鐘$10) 就OK, 唔該哂'
        ],
        answers: [0, 2]
    },
    {
        id: 5,
        text: '什麼時間需要鏟貓屎',
        options: [
            '開舖時段',
            '剛開舖時',
            '2pm',
            '3pm',
            '4pm',
            '5pm',
            '6pm',
            '7pm',
            '8pm',
            '9pm',
            '10pm',
            '關舖前',
            '所有聞到異味的時間'
        ],
        answers: [0, 1, 3, 6, 9, 11, 12]
    },
    {
        // 27 個選項、20 個正確 —— 係原表設計，20 個要全中才算答對
        id: 6,
        text: '入場客人的說法: ',
        options: [
            '1. 請問有冇預約既?',
            '2. 請問之前有冇去過貓cafe?',
            '2. 請問之前有冇黎過我們cafe?',
            '(如沒有來過) 3. 我地呢邊收費係首小時58, 之後每小時38, 另外都有118無限時任坐 (閒日才講)',
            '(如果是午晚餐時間) 4. 提一提呢度無正餐呢, 有輕食同甜品的',
            '(如果是午晚餐時間) 4. 提一提呢度無野食, 得輕食同甜品',
            '5. 請問小朋友今年幾歲既?',
            '(如未滿11歲) 6. 咁小朋友同家長都一齊聽聽丫,',
            '(如未滿11歲) 7. 小朋友係場內需要跟住大人,',
            '(如未滿11歲) 8. 大人都請跟住同指導番小朋友,',
            '(如未滿11歲) 9. 場內要細聲d 講野,',
            '(如未滿11歲) 10. 摸貓貓要輕輕力咁摸, 唔好追住或者跟住貓貓黎摸喎,',
            '(如未滿11歲) 10. 小朋友場內唔好摸貓貓啦',
            '(如未滿11歲) 11. 小朋友唔可以用逗貓棒, 家長可以捉住小朋友隻手玩都得既',
            '(如未滿11歲) 12. 呢度會警告三次, 三次之後可能需要提早離場',
            '(如未滿11歲) 12. 呢度會提醒三次, 三次之後可能需要提早離場',
            '(如未滿11歲) 13. 提早離場的話就唔係一小時58, 而是入場時間計每10分鐘10蚊',
            '14. 呢度有隻貓貓戴黑色三角頸巾, 佢有d 公主/少爺脾氣, 建議唔好摸呢隻貓貓',
            '14. 呢度有隻貓貓戴黑色三角頸巾, 佢有d 公主/少爺脾氣, 建議行近呢隻貓貓',
            '15. 場內都請細聲d 講野',
            '15. 場內都請保持安靜',
            '16. 場內貓貓不可抱起',
            '16. 場內貓貓可以摸但不可抱起',
            '17. 入場之前可以先除一除鞋, 同埋個邊可以消毒, 拖鞋都可以隨時拎的,',
            '18. 自助水吧係呢個位置, 有免費茶水, 以及其他收費飲品同野食',
            '19. 場內設施都可Scan 番呢個QR code 睇番',
            '20) 個人物品可放呢個袋入面, 唔該哂'
        ],
        answers: [0, 2, 3, 4, 6, 7, 8, 9, 10, 11, 13, 15, 16, 17, 19, 22, 23, 24, 25, 26]
    },
    {
        id: 7,
        text: '碌地有什麼需要留意',
        options: [
            '所有可見的毛髮, 灰塵, 碎屑都需要碌走',
            '簡單快速碌明顯地方就可以',
            '需注意碌枱底及邊角位置'
        ],
        answers: [0, 2]
    },
    {
        id: 8,
        text: '開舖拖地時見到地上有屎尿的處理方式',
        options: [
            '只要便便不太大, 就用地拖直接拖走, 大件的就另外分開清潔',
            '所有屎尿都不可地拖拖走, 需要另外分開清潔'
        ],
        answers: [1]
    },
    {
        id: 9,
        text: '梳毛抺眼時聞到貓身上有臭味的處理方式',
        options: [
            '了解臭味來源, 留意屁股位置是否有屎沾住',
            '立刻用清潔劑幫貓貓全身清潔'
        ],
        answers: [0]
    },
    {
        id: 10,
        text: '見貓貓吵架的處理方式',
        options: [
            '身體擋在貓貓中間',
            '捉走其中一隻貓貓',
            '用墊或除塵碌擋住貓貓避免互視'
        ],
        answers: [2]
    },
    {
        id: 11,
        text: '若果必須用手控制情緒激動貓貓, 應採取以下那項措施',
        options: [
            '戴上防咬手套',
            '用腳驅趕貓貓',
            '用身體撲向貓貓控制'
        ],
        answers: [0]
    },
    {
        id: 12,
        text: '一枱超過幾人可以買多份貓零食',
        options: [
            '每2人可多一份',
            '每3人可多一份',
            '每4人可多一份',
            '每5人可多一份'
        ],
        answers: [3]
    },
    {
        id: 13,
        text: '以下那項是員工需要留意的事情',
        options: [
            '多幫助不同崗位',
            '友善的語氣',
            '主動幫忙同事',
            '留意客人需求 (例如見客人凍時提拱披肩或調低溫度)',
            '見到貓貓有眼屎或毛髮混亂時幫忙清楚處理'
        ],
        answers: [0, 1, 2, 3, 4]
    },
    {
        id: 14,
        text: '客人離場後, 該座位需處理什麼',
        options: [
            '抹枱',
            '泊齊桌椅',
            '更換座墊',
            '清走座墊上碎屑',
            '泊齊座墊',
            '碌走桌下及附近雜物碎屑',
            '桌下及附近拖地一次'
        ],
        answers: [0, 1, 3, 4, 5]
    },
    {
        id: 15,
        text: '遇到客人自備食物餵貓, 應如何處理',
        options: [
            '了解食物的成份, 無過敏成份就允許',
            '任何外來食物皆不可餵貓'
        ],
        answers: [1]
    },
    {
        id: 16,
        text: '遇到火災該如何處理',
        options: [
            '投擲藍色滅火瓶至火源處',
            '以防火毯撲滅火災'
        ],
        answers: [0]
    },
    {
        id: 17,
        text: '咖啡機需要做什麼維護',
        options: [
            '灰色沖粉器每天清潔一次',
            '灰色沖粉器每星期清潔一次',
            '每天檢查粉量及咖啡豆是否需要Refill, 粉量需最少粉盒的2/3高度',
            '每天檢查粉量及咖啡豆是否需要Refill, 粉量需最少粉盒的1/2高度',
            '每天檢查機內吸濕包是否需要更換, 咖啡機內部必須保持乾燥',
            '每天替換咖啡內吸濕包'
        ],
        answers: [0, 2, 4]
    },
    {
        id: 18,
        text: '以下那些是本店的防疫措施',
        options: [
            '以1:50 F10做日常清潔',
            '以1:125 F10做日常清潔',
            '去完獸醫後, 貓籠/袋需F10 噴洒消毒',
            '去完獸醫後, 貓籠/袋需銷毀',
            '非職員進入未打疫苗的貓房前, 需以F10 全身噴洒消毒, 並等待5分鐘後才入場',
            '非職員進入未打疫苗的貓房前, 需以F10 全身噴洒消毒, 並等待15分鐘後才入場'
        ],
        answers: [1, 2, 5]
    },
    {
        id: 19,
        text: '那個數額以上的獸醫檢查, 需要先得到Albert 同意',
        options: ['1000', '500', '200', '100'],
        answers: [1]
    },
    {
        id: 20,
        text: '對同事有不滿/意見, 應如何處理',
        options: [
            '嘗試溝通',
            '找Albert 幫忙解決',
            '在背後講同事閒話'
        ],
        answers: [0, 1]
    },
    {
        id: 21,
        text: '以下那種藥物, 需提醒診所不用開比我們',
        options: [
            'Doxy',
            '賴氨酸',
            'Famciclovir',
            '所有其他店內有的藥物/補充劑'
        ],
        answers: [0, 1, 2, 3]
    },
    {
        id: 22,
        text: '因工受傷睇醫生的話, 以下那種醫院是勞保覆蓋範圍',
        options: ['私家醫院', '公立醫院'],
        answers: [1]
    },
    {
        id: 23,
        text: '所有新貓入店前都必需做那項傳染病檢測',
        options: ['Cat Flu', 'Fiv/Felv', 'CPV', 'FPV', 'FIP'],
        answers: [1, 3]
    },
    {
        id: 24,
        text: '以下那些是 "保密" 訊息可透露的群體',
        options: [
            'Full Time',
            'Part Time',
            '前Full Time',
            '店長',
            '老闆親屬',
            '只有確認可知悉該保密訊息的群體才可透露'
        ],
        answers: [5]
    }
];

const PASS_PERCENTAGE = 80;

/**
 * 兩條軌。questionIds 指向 QUESTION_POOL 嘅 id，次序就係卷面題號。
 * FT：全 24 題。PT：兼職版 15 題（同 FT 對應題逐字相同）。
 * 要加減題目／改次序，只改呢度。
 */
const TRACKS = {
    FT: {
        label: '全職 FT',
        title: '貓之茶房 - 全職員工培訓測驗',
        passPercentage: PASS_PERCENTAGE,
        questionIds: [
            1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,
            13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24
        ]
    },
    PT: {
        label: '兼職 PT',
        title: '貓之茶房 - 兼職員工培訓測驗',
        passPercentage: PASS_PERCENTAGE,
        questionIds: [
            1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16
        ]
    }
};

const DEFAULT_TRACK = 'FT';

function isValidTrack(track) {
    return Object.prototype.hasOwnProperty.call(TRACKS, track);
}

/** 依卷面次序取出某條軌嘅題目（含答案，只供伺服器內部用） */
function questionsFor(track) {
    const t = isValidTrack(track) ? track : DEFAULT_TRACK;
    return TRACKS[t].questionIds.map(function (id) {
        return QUESTION_POOL.find(function (q) { return q.id === id; });
    });
}

/** 對外版本：剔走 answers，避免答案隨網頁原始碼外洩 */
function publicQuestions(track) {
    return questionsFor(track).map(function (q, index) {
        return {
            number: index + 1,
            text: q.text,
            options: q.options.slice()
        };
    });
}

function passPercentageFor(track) {
    const t = isValidTrack(track) ? track : DEFAULT_TRACK;
    return TRACKS[t].passPercentage;
}

/**
 * 評分：逐題比對所選索引集合與正確答案集合
 * @param {string} track - 'FT' | 'PT'
 * @param {Object} responses - { [題號(1-based)]: number[] }
 * @returns {{ track, total, correct, percentage, passed, wrongQuestionIds }}
 *          wrongQuestionIds 係卷面題號（即員工喺頁面見到嘅第幾題）
 */
function grade(track, responses) {
    const t = isValidTrack(track) ? track : DEFAULT_TRACK;
    const questions = questionsFor(t);
    const wrongQuestionIds = [];

    questions.forEach(function (q, index) {
        const number = index + 1;
        const picked = (responses && responses[number]) || [];
        const pickedSet = new Set(picked.map(Number));
        const answerSet = new Set(q.answers);

        const same = pickedSet.size === answerSet.size &&
            Array.from(answerSet).every(function (i) { return pickedSet.has(i); });

        if (!same) wrongQuestionIds.push(number);
    });

    const total = questions.length;
    const correct = total - wrongQuestionIds.length;
    const percentage = Math.round((correct / total) * 100);
    const passPercentage = TRACKS[t].passPercentage;

    return {
        track: t,
        total: total,
        correct: correct,
        percentage: percentage,
        passed: percentage >= passPercentage,
        wrongQuestionIds: wrongQuestionIds
    };
}

module.exports = {
    TRACKS: TRACKS,
    DEFAULT_TRACK: DEFAULT_TRACK,
    PASS_PERCENTAGE: PASS_PERCENTAGE,
    isValidTrack: isValidTrack,
    questionsFor: questionsFor,
    publicQuestions: publicQuestions,
    passPercentageFor: passPercentageFor,
    grade: grade
};
