// ─────────────────────────────────────────────────────────────
// RUNNING_MODE 正式化 config module（Phase 2）
// 同一份 codebase，用 RUNNING_MODE 決定環境角色：
//   BACKEND  = 阿里雲後台（開後台功能：group-booking / hot-fix admin / mc-report / 跨店）
//   EDGE     = 店舖平板（開營運功能；後台功能全部關）—— 預設
//
// 規則（安全原則：確保平板行為不變）：
// 1. 預設（RUNNING_MODE 冇 set 或 = EDGE）＝ 平板行為，所有 ENABLE_* flag 預設 OFF
// 2. 顯式 env 永遠蓋過 mode 預設（例：BACKEND 想關 group-booking → ENABLE_GROUP_BOOKING=off）
// 3. 加新 feature flag 只改呢個檔 + 對應 use 位置，code 唔會再散落 env 檢查
// ─────────────────────────────────────────────────────────────

const path = require('path');

const MODE = (process.env.RUNNING_MODE || 'EDGE').trim().toUpperCase();

// 每種 mode 預設開嘅 feature flags
const MODE_DEFAULTS = {
    BACKEND: {   // 阿里雲後台：開後台功能（對應 Aliyun 而家 .env 手動 set 嘅 flags）
        ENABLE_GROUP_BOOKING: true,      // 包場 / 預訂食物
        ENABLE_HOT_FIX_ADMIN: true,      // hot-fix admin toggle（直接讀寫本地 DB + file）
        // 每日香港時間 01:00 自動取消 HOT FIX（只在已勾選時才動作）。目的：商家用戶勾選
        // 後忘記取消，會令平板全日繞過 22:00-13:00 更新時段限制，在營業時間中途更新。
        // 跟 ENABLE_HOT_FIX_ADMIN 一樣 BACKEND 預設開（EDGE 平板不受影響）；個別環境想關
        // 可喺 .env set ENABLE_HOT_FIX_DAILY_RESET=off。
        ENABLE_HOT_FIX_DAILY_RESET: true,
        ENABLE_FEEDBACK_SEARCH: true,    // 神秘顧客 feedback 搜尋 + mc-report 頁
        ALLOW_CROSS_STORE_ADMIN: true,   // admin 跨分店加商品
        // Merchant 登入「第一道大門」：BACKEND 最外層額外閘。預設 OFF（CLAUDE.md：
        // 商家特定功能收 flag、預設 OFF）。想開嘅 merchant server 喺 .env set ENABLE_MERCHANT_GATE=on
        // （要 DB 先有 role='merchant' 帳，否則成個後台鎖死，所以唔可以 mode 預設 on）。
        ENABLE_MERCHANT_GATE: false,
        // 商家專區（/merchant/）：商家入口，目前係按 merchant 隔離嘅 AI 對話。
        // 預設 OFF — 因為佢會產生真實 API 費用，而且係對外開放嘅入口，
        // 必須逐個環境喺 .env 用 ENABLE_MERCHANT_CHAT=on 明確開啟。
        ENABLE_MERCHANT_CHAT: false,
        // WhatsApp Cloud API 官方對接（webhook 收客人訊息 + 網頁收件匣回覆客人）。
        // 預設 OFF — 開啟前必須先完成 Meta 端設定（系統用戶永久 token + webhook 訂閱
        // messages 欄位），否則 webhook 會靜默收不到任何訊息。詳見
        // MD Files/WHATSAPP_CLOUD_API_GUIDE.md。
        ENABLE_WHATSAPP: false,
        // 員工考核（/staff-training）：培訓內容同題庫係貓之茶房專屬（內容寫死喺
        // client/staff-training/，題庫喺 server/config/staffTrainingQuiz.js），
        // 所以收 flag、預設 OFF。要開嘅環境喺 .env set ENABLE_STAFF_TRAINING=on。
        ENABLE_STAFF_TRAINING: false,
        // 快捷回覆嘅媒體附件（圖／片／PDF）。
        // ⚠️ 呢個係「用戶內容唔落磁碟」鐵律嘅唯一例外，開啟前請先讀
        //    MD Files/ALIYUN_MONITORING_GUIDE.md 同 MD Files/WHATSAPP_CLOUD_API_GUIDE.md。
        //    預設 OFF：冇開嘅話上傳路由回 404，既有純文字快捷回覆完全不受影響。
        ENABLE_WHATSAPP_QUICK_REPLY_MEDIA: false,
        // WhatsApp 自動回覆（客服時間內外問候、關鍵字、無匹配時嘅後備）。
        // 預設 OFF — 呢個功能會自動用商家名義發訊息俾客人，必須逐個環境明確開啟。
        ENABLE_WHATSAPP_AUTO_REPLY: false,
        // 推播通知（客人新訊息 → 商家手機 App 彈通知，同 WhatsApp 一樣）。
        // 預設 OFF — 開啟前 .env 必須有 FCM_SERVICE_ACCOUNT_FILE 指向 service
        // account JSON，否則服務會靜默停用（唔會拋錯，入站訊息照樣運作）。
        ENABLE_WHATSAPP_PUSH: false,
    },
    EDGE: {      // 店舖平板：後台功能全部關（同而家行為完全一致）；merchant 閘亦唔會開
        ENABLE_GROUP_BOOKING: false,
        ENABLE_HOT_FIX_ADMIN: false,
        ENABLE_HOT_FIX_DAILY_RESET: false,
        ENABLE_FEEDBACK_SEARCH: false,
        ALLOW_CROSS_STORE_ADMIN: false,
        ENABLE_MERCHANT_GATE: false,
        ENABLE_MERCHANT_CHAT: false,
        ENABLE_WHATSAPP: false,
        ENABLE_STAFF_TRAINING: false,
        ENABLE_WHATSAPP_QUICK_REPLY_MEDIA: false,
        ENABLE_WHATSAPP_AUTO_REPLY: false,
        ENABLE_WHATSAPP_PUSH: false,
    },
};

const VALID_MODES = ['BACKEND', 'EDGE'];
const normalizedMode = VALID_MODES.includes(MODE) ? MODE : 'EDGE';

/**
 * 讀 feature flag：顯式 env（on / true / 1）蓋過 mode 預設；冇 set 用 mode 預設
 */
function isFlag(name) {
    const envVal = process.env[name];
    if (envVal !== undefined && envVal.trim() !== '') {
        return ['on', 'true', '1'].includes(envVal.trim().toLowerCase());
    }
    const modeDefault = MODE_DEFAULTS[normalizedMode] && MODE_DEFAULTS[normalizedMode][name];
    return !!modeDefault;
}

// 商家 → 對外 HTTPS domain（EDGE 更新代理來源）
// 優先序：RELEASE_BASE_URL（.env）> MERCHANT_DOMAINS[merchant] > DEFAULT_RELEASE_DOMAIN
// ⚠️ 商家域名屬「商家定制」：master 保持空表；商家條目喺 catstearoom（或該商家）branch 加。
const MERCHANT_DOMAINS = {
    catstearoom: 'https://catstearoom.dev',
};

// 通用版（master）自用 domain；商家 branch 可用自己嘅 DEFAULT_RELEASE_DOMAIN 覆蓋
const DEFAULT_RELEASE_DOMAIN = 'https://catstearoom.dev';

/**
 * 解析 release 代理來源 domain（EDGE 更新用）
 * @param {string} merchant 商家 slug（APK 更新請求已帶 ?merchant=）
 */
function releaseBaseUrl(merchant) {
    const env = (process.env.RELEASE_BASE_URL || '').trim();
    if (env) return env.replace(/\/+$/, '');
    const key = String(merchant || '').trim();
    const dom = MERCHANT_DOMAINS[key] || DEFAULT_RELEASE_DOMAIN;
    return dom ? String(dom).replace(/\/+$/, '') : '';
}

module.exports = {
    MODE: normalizedMode,
    isBackend: normalizedMode === 'BACKEND',
    isEdge: normalizedMode !== 'BACKEND',
    isFlag,
    releaseBaseUrl,
    // 常用 flag shortcut（保持 use 位置可讀）
    groupBooking: () => isFlag('ENABLE_GROUP_BOOKING'),
    hotFixAdmin: () => isFlag('ENABLE_HOT_FIX_ADMIN'),
    hotFixDailyReset: () => isFlag('ENABLE_HOT_FIX_DAILY_RESET'),
    // HOT FIX 每日自動重設時間（香港時間，0-23；預設 1 = 凌晨 01:00）。
    // 純設定值（唔係 feature flag）→ 唔入 MODE_DEFAULTS，同 merchantChatOwnerUsernames 同類。
    // 用途：staging 驗證時唔使真係等到凌晨。
    hotFixResetHour: () => {
        const h = parseInt(process.env.HOT_FIX_RESET_HOUR, 10);
        return Number.isInteger(h) && h >= 0 && h <= 23 ? h : 1;
    },
    feedbackSearch: () => isFlag('ENABLE_FEEDBACK_SEARCH'),
    crossStoreAdmin: () => isFlag('ALLOW_CROSS_STORE_ADMIN'),
    merchantGate: () => isFlag('ENABLE_MERCHANT_GATE'),
    merchantChat: () => isFlag('ENABLE_MERCHANT_CHAT'),
    whatsapp: () => isFlag('ENABLE_WHATSAPP'),
    whatsappQuickReplyMedia: () => isFlag('ENABLE_WHATSAPP_QUICK_REPLY_MEDIA'),
    whatsappAutoReply: () => isFlag('ENABLE_WHATSAPP_AUTO_REPLY'),
    whatsappPush: () => isFlag('ENABLE_WHATSAPP_PUSH'),

    // Meta App 嘅 App Secret。用嚟驗：
    //   1. WhatsApp webhook 嘅 X-Hub-Signature-256（既有）
    //   2. Meta 應用回調嘅 signed_request（Deauthorize / Data Deletion）
    // ⚠️ 呢個係 secret，只可以經 .env 提供，唔可以寫死喺 code。
    // 純設定值（唔係 feature flag）→ 唔入 MODE_DEFAULTS。
    whatsappAppSecret: () => (process.env.WHATSAPP_APP_SECRET || '').trim(),

    // Meta 應用回調要回俾 Meta 嘅公開網址前綴（例如 Data Deletion 嘅狀態頁）。
    // 留空 = 由請求嘅 Host 推導（nginx 有 proxy_set_header Host $host，所以準）。
    // 純設定值（唔係 feature flag）→ 唔入 MODE_DEFAULTS。
    metaAppBaseUrl: () => (process.env.META_APP_BASE_URL || '').trim(),
    staffTraining: () => isFlag('ENABLE_STAFF_TRAINING'),
    // Release 檔案目錄（僅 BACKEND 使用）：預設專案根 apk_release/，可用 APK_RELEASE_DIR 覆寫
    releaseBaseDir: () => process.env.APK_RELEASE_DIR || path.join(__dirname, '..', '..', 'apk_release'),
    // 「主 merchant」帳號清單（用逗號分隔）：只有呢啲帳號可以開啟／關閉其他商家嘅 chatroom。
    // 呢個係純設定值（唔係 feature flag），所以唔入 MODE_DEFAULTS；但一樣收喺 runtime.js，
    // 等唯一嘅 config 入口保持集中（CLAUDE.md 守則 2）。空 = 冇人有管理權。
    merchantChatOwnerUsernames: () => (process.env.MERCHANT_CHAT_OWNER_USERNAME || '')
        .split(',')
        .map((s) => s.trim().toLowerCase())
        .filter(Boolean),

    /**
     * 跨實例聚合：主商家喺「總控」實例嘅面板要管到其他實例嘅商家，靠呢個 peer 清單。
     * 格式：`標籤|baseUrl`，多個用逗號分隔。例：
     *   MERCHANT_CHAT_PEERS=catstearoom|http://127.0.0.1:3002
     * 留空 = 只管理自己呢個實例（預設行為，唔會打任何外部請求）。
     * ⚠️ 建議只填 127.0.0.1 或內網地址，唔好填公網位址。
     */
    merchantChatPeers: () => (process.env.MERCHANT_CHAT_PEERS || '')
        .split(',')
        .map((entry) => {
            const idx = entry.indexOf('|');
            if (idx === -1) return null;
            const label = entry.slice(0, idx).trim();
            const baseUrl = entry.slice(idx + 1).trim().replace(/\/+$/, '');
            if (!label || !baseUrl) return null;
            return { label, baseUrl };
        })
        .filter(Boolean),

    /** 實例之間呼叫用嘅共用密鑰（各實例要設同一個值；留空 = peer 端點停用） */
    merchantChatPeerKey: () => process.env.MERCHANT_CHAT_PEER_KEY || '',

    // WhatsApp 測試模式：on = 唔打真 Graph API，只記錄預備送出嘅 payload 並回傳合成 wamid。
    // 同 KPAY_MODE=mock 同一思路 —— 令整個收件匣 UX（送出泡泡、失敗顯示、24 小時窗）
    // 可以在零成本、零外部呼叫下完整測試。純設定值（唔係 feature flag）→ 唔入 MODE_DEFAULTS。
    whatsappDryRun: () => ['on', 'true', '1']
        .includes(String(process.env.WHATSAPP_DRY_RUN || '').trim().toLowerCase()),

    // 快捷回覆媒體附件嘅存放目錄（純設定值，唔係 feature flag → 唔入 MODE_DEFAULTS）。
    // 預設 repo 根嘅 wa-media/（已 gitignore）。若應用目錄喺系統碟而想用資料碟，
    // 喺 .env 設 WHATSAPP_MEDIA_DIR 指去大容量嘅磁碟區。
    waMediaDir: () => process.env.WHATSAPP_MEDIA_DIR || path.join(__dirname, '..', '..', 'wa-media'),

    // 領養申請嘅動態資料目錄（審核通過嘅貓 + 相片）。
    //
    // ⚠️ 為什麼一定要放喺 catstearoom.com 網站根目錄之外：
    //    /var/www/catstearoom-site/ 係 rsync --delete 嘅唯一目標，
    //    任何寫入該目錄嘅檔案，下次部署都會被刪走。
    //    呢個目錄係網站根目錄嘅**兄弟目錄**，再由 nginx 用
    //    `location ^~ /assets/data/live/` alias 指過去。
    //    （與影片放 /var/www/catstearoom-media 係同一個模式。）
    //
    // 預設值係 production 路徑；本機開發用 ADOPTION_DATA_DIR 覆寫。
    adoptionDataDir: () => process.env.ADOPTION_DATA_DIR || '/var/www/catstearoom-data',

    // 問候語「重新開場」嘅靜默時數。客人靜默超過呢個時數後再傳訊息，
    // 就當作新嘅一次接觸，問候會再發。
    //
    // ⚠️ 為什麼需要呢個：對話一旦建立就永遠唔會關閉（wa_conversations.status
    //    永遠係 'open'，全倉庫冇任何路徑會改佢）。所以如果只靠「新對話」判斷，
    //    問候語每位客人一生只會收到一次。
    // 預設 24 小時（同 WhatsApp 自己嘅 24 小時客服窗同一個概念）。
    // 純設定值（唔係 feature flag）→ 唔入 MODE_DEFAULTS。
    whatsappGreetingResetHours: () => {
        const h = parseInt(process.env.WHATSAPP_GREETING_RESET_HOURS, 10);
        return Number.isInteger(h) && h >= 0 && h <= 720 ? h : 24;
    },

    // 對話負責角色「自動退回機械人」嘅冷靜期（分鐘）。
    //
    // 語意：對話被指派俾人（handle_role 非 'bot'）之後，靜默超過呢個時間就
    //       自動當返機械人負責 —— 即係「同事停手 N 分鐘，機械人接返」。
    //       判斷喺 server/services/whatsappConversationState.js。
    //
    // ⚠️ 呢個同上面 whatsappGreetingResetHours 係**兩件完全唔同嘅事**，
    //    以前共用同一個值純粹係歷史巧合（一個係客人靜默幾耐當新接觸，
    //    一個係同事停手幾耐機械人接返）。
    //    24 小時對後者太長 —— 商家喺收件匣回一次，之後成日都測唔到／用唔到
    //    自動回覆，而且完全睇唔出原因（2026-09-28 實際踩過）。
    //
    // ⚠️ 設 0 = 關閉靜音（角色永遠即時退回機械人，等同上一個版本嘅
    //    「關閉人手靜音」）。但留意：0 會令**手動指派角色完全失效**。
    // 純設定值（唔係 feature flag）→ 唔入 MODE_DEFAULTS。
    whatsappHumanMuteMinutes: () => {
        const m = parseInt(process.env.WHATSAPP_HUMAN_MUTE_MINUTES, 10);
        // 上限 7 日：再長就同「永久靜音」冇分別，應該用 Solved 去收尾
        return Number.isInteger(m) && m >= 0 && m <= 10080 ? m : 30;
    },

    // FCM service account JSON 嘅路徑（firebase console → 專案設定 → 服務帳戶
    // → 產生新的私鑰）。**留空 = 推播停用**，服務會靜默略過，唔會拋錯。
    //
    // ⚠️ 呢個檔案含私鑰，必須放喺 repo 外（例：C:\auto_system\keys\），
    //    絕對唔可以 commit。呢個係純設定值（唔係 feature flag）→ 唔入 MODE_DEFAULTS。
    fcmServiceAccountFile: () => (process.env.FCM_SERVICE_ACCOUNT_FILE || '').trim(),
};
