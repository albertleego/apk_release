#!/usr/bin/env node
/**
 * KPay sales 診斷工具 —— 分辨「卡機太慢」定「卡機根本冇處理」
 *
 * 背景：kpayService.sales() 內建 10 秒 HTTP_TIMEOUT_MS，逾時就 AbortController.abort()。
 *   咁樣分唔清兩種情況：
 *     (A) 卡機只係慢，15 秒其實會回
 *     (B) 卡機完全冇回應
 *
 * 呢支 script 用**同一個** kpayService 簽名邏輯（getConfig / sign / buildSignatureContent /
 * signContent / genNonce / formatAmount），但自己發 HTTP request，逾時由參數控制。
 * 目的純粹係診斷 —— 唔會改 kpayService、唔會寫 DB、唔會經 /api/kpay route。
 *
 * 用法：
 *   node scripts/kpay-diag-sales.js                 # 預設 type=2（二維碼正掃），60 秒逾時
 *   node scripts/kpay-diag-sales.js --type 1        # 測卡類
 *   node scripts/kpay-diag-sales.js --timeout 120   # 逾時改 120 秒
 *   node scripts/kpay-diag-sales.js --no-sign       # 跳過 sign 直接用 cache（測第二次之後）
 */

const path = require('path');

const ROOT = path.resolve(__dirname, '..');
require('dotenv').config({ path: path.join(ROOT, '.env'), quiet: true });
process.env.KPAY_MODE = 'lan'; // 只覆寫本 process

const kpayService = require(path.join(ROOT, 'server', 'services', 'kpayService'));

const argv = process.argv.slice(2);
const getOpt = (name, fallback) => {
  const i = argv.indexOf('--' + name);
  return i !== -1 && argv[i + 1] ? argv[i + 1] : fallback;
};

const STORE_ID = 'default_store';
const PAYMENT_TYPE = parseInt(getOpt('type', '2'), 10);
const TIMEOUT_MS = parseInt(getOpt('timeout', '60'), 10) * 1000;
const AMOUNT = parseFloat(getOpt('amount', '1'));

function ts() {
  return new Date().toISOString().slice(11, 19);
}

(async () => {
  const cfg = await kpayService.getConfig(STORE_ID);

  console.log('═'.repeat(60));
  console.log(`  診斷目標：http://${cfg.kpos_ip}:${cfg.kpos_port}/v2/pos/sales`);
  console.log(`  paymentType=${PAYMENT_TYPE}  amount=$${AMOUNT}  逾時=${TIMEOUT_MS / 1000}s`);
  console.log('═'.repeat(60));

  // ── 步驟 1：簽到（同 kpayService.sales 內部一樣要先攞工作密鑰）──
  console.log(`[${ts()}] 簽到 sign()…`);
  const tSign = Date.now();
  const keys = await kpayService.sign(STORE_ID);
  console.log(`[${ts()}] ✓ 簽到完成（${Date.now() - tSign}ms，私鑰 ${keys.appPrivateKey.slice(0, 4)}…）`);

  // ── 步驟 2：砌出同 kpayService.sales() 一模一樣嘅 payload ──
  const outTradeNo = 'KPTDIAG' + Date.now();
  const payload = {
    outTradeNo,
    description: 'KPay 診斷單（非真實營運）',
    payAmount: kpayService.formatAmount(AMOUNT),
    tipsAmount: kpayService.formatAmount(0),
    paymentType: PAYMENT_TYPE,
    payCurrency: '344'
  };

  console.log('');
  console.log(`[${ts()}] outTradeNo = ${outTradeNo}`);
  console.log(`[${ts()}] payload    = ${JSON.stringify(payload)}`);

  // ── 步驟 3：簽名 header（複製 kpayService.authHeaders 嘅邏輯）──
  const reqPath = '/v2/pos/sales';
  const bodyStr = JSON.stringify(payload);
  const timestamp = Date.now();
  const nonceStr = kpayService.genNonce();
  const content = kpayService.buildSignatureContent('POST', reqPath, timestamp, nonceStr, bodyStr);
  const signature = kpayService.signContent(content, keys.appPrivateKey);
  const headers = {
    'Content-Type': 'application/json',
    appId: cfg.app_id,
    timestamp: String(timestamp),
    nonceStr,
    signature
  };

  // ── 步驟 4：發 request，逾時由參數控制（唔受 kpayService 10 秒限制）──
  const url = `http://${cfg.kpos_ip}:${cfg.kpos_port}${reqPath}`;
  console.log('');
  console.log(`[${ts()}] POST ${url}  （最多等 ${TIMEOUT_MS / 1000} 秒）`);

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  const t0 = Date.now();

  try {
    const res = await fetch(url, { method: 'POST', headers, body: bodyStr, signal: controller.signal });
    clearTimeout(timer);
    const elapsed = Date.now() - t0;
    const text = await res.text();

    console.log('');
    console.log('─'.repeat(60));
    console.log(`HTTP ${res.status}   耗時 ${elapsed}ms`);
    console.log(`回應內容：${text}`);
    console.log('─'.repeat(60));

    if (elapsed > 10000) {
      console.log(`→ 卡機其實會回，但要用 ${elapsed}ms（>10 秒）—— 屬情況 A：卡機太慢。`);
      console.log('  kpayService 嘅 10 秒逾時會誤判失敗，正式 pilot 前必須改善網路。');
    } else {
      console.log(`→ 卡機 ${elapsed}ms 就回咗。若 kpayService 仍然逾時，問題喺其他環節。`);
    }
  } catch (e) {
    clearTimeout(timer);
    const elapsed = Date.now() - t0;
    console.log('');
    console.log('─'.repeat(60));
    console.log(`✗ 失敗：${e.name} — ${e.message}（等了 ${elapsed}ms）`);
    console.log('─'.repeat(60));
    if (e.name === 'AbortError') {
      console.log(`→ 等足 ${TIMEOUT_MS / 1000} 秒都冇回應 —— 屬情況 B：卡機冇處理呢個請求。`);
      console.log('  兩個都係 POST 但 sign 成功、sales 無反應 → 問題喺 /v2/pos/sales 呢條路徑。');
      console.log('  可能：終端未開班／未完成初始化／permission 不足／需要額外參數。');
      console.log('  → 建議拎住呢個結果問 KPay 技術支援。');
    }
  }

  // 提醒：呢單係獨立發出嘅 request，kpayService 完全唔知，亦冇寫入任何紀錄
  console.log('');
  console.log(`備註：outTradeNo=${outTradeNo} 只喺卡機側存在（如果卡機真係收到）。`);
  console.log('      若卡機彈咗收款畫面，記得喺卡機度取消，或用 admin 密碼 void。');

  process.exit(0);
})();
