#!/usr/bin/env node
/**
 * KPay KPOS LAN 連線測試工具（獨立於 exit-machine）
 *
 * 目的：喺**唔影響運行中 server、唔碰客人資料**嘅前提下，逐階段驗證真卡機接駁。
 *
 * 點解要獨立一支：
 *   - `/api/kpay/pay` 一成功就會即刻結賬 + 開門，亦會寫 kpay_payments / transactions
 *   - 呢支 script **只**直接 call kpayService（sign / sales / query / close），
 *     **唔會**經任何 /api/kpay HTTP route，**唔會**寫 DB、唔會 emit socket event
 *
 * 安全設計：
 *   - `KPAY_MODE=lan` 只覆寫**本 process** 嘅環境變數，running server 完全唔受影響
 *   - 唔會改 .env、唔會改任何檔案
 *
 * 用法：
 *   node scripts/kpay-test.js sign                       # 測連通性 + credentials
 *   node scripts/kpay-test.js sales --type 1 --amount 1  # 開一單（卡機彈收款畫面）
 *   node scripts/kpay-test.js query --out-trade-no X     # 查狀態
 *   node scripts/kpay-test.js cancel --out-trade-no X    # 關閉未付款嘅單
 *   node scripts/kpay-test.js flow --type 1 --amount 1   # 一氣呵成：sign → sales → 輪詢 → 超時自動 close
 *
 * 加 --mock 可以用 mock 模式（唔使真機）驗證 script 本身；加 --with-callback 會帶 callbackUrl 開單。
 */

const path = require('path');
const net = require('net');

// ===== 載入 .env（同 server 一致：專案根目錄）=====
const ROOT = path.resolve(__dirname, '..');
require('dotenv').config({ path: path.join(ROOT, '.env'), quiet: true });

// ===== 參數解析 =====
const argv = process.argv.slice(2);
const command = argv.find((a) => !a.startsWith('--')) || 'flow';
const hasFlag = (name) => argv.includes('--' + name);
const getOpt = (name, fallback) => {
  const i = argv.indexOf('--' + name);
  return i !== -1 && argv[i + 1] ? argv[i + 1] : fallback;
};

const USE_MOCK = hasFlag('mock');
const WITH_CALLBACK = hasFlag('with-callback');

// ===== 關鍵：只覆寫本 process 嘅 mode，唔掂 running server =====
if (USE_MOCK) {
  process.env.KPAY_MODE = 'mock';
} else {
  process.env.KPAY_MODE = 'lan';
}

const kpayService = require(path.join(ROOT, 'server', 'services', 'kpayService'));

const STORE_ID = getOpt('store-id', 'default_store');
const POLL_INTERVAL_MS = 3000;

// ===== 小工具 =====
function mask(v) {
  if (!v) return '(空)';
  const s = String(v);
  return s.length <= 8 ? s[0] + '***' : s.slice(0, 4) + '***' + s.slice(-4);
}

function nowIso() {
  return new Date().toISOString().slice(11, 19);
}

function log(msg) {
  console.log(`[${nowIso()}] ${msg}`);
}

function newOutTradeNo() {
  // 同 kpayRoutes 同款格式，但用 KPT 前綴方便喺 KPOS 記錄度一眼認出測試單
  return 'KPT' + Date.now() + Math.random().toString(36).slice(2, 6).toUpperCase();
}

// ===== 前置檢查：TCP 通唔通得到 KPOS =====
// 唔做呢步嘅話，KPOS 唔到就要等 10 秒 timeout 先見到一個含糊嘅錯誤
function checkTcp(ip, port, timeoutMs = 5000) {
  return new Promise((resolve) => {
    const sock = new net.Socket();
    let done = false;
    const finish = (ok, reason) => {
      if (done) return;
      done = true;
      sock.destroy();
      resolve({ ok, reason });
    };
    sock.setTimeout(timeoutMs);
    sock.once('connect', () => finish(true));
    sock.once('timeout', () => finish(false, `${timeoutMs}ms 內無回應`));
    sock.once('error', (e) => finish(false, e.code || e.message));
    sock.connect(port, ip);
  });
}

// ===== 開場：印出實際生效嘅 config =====
async function printConfig() {
  const cfg = await kpayService.getConfig(STORE_ID);

  console.log('─'.repeat(64));
  log(`store_id      : ${STORE_ID}`);
  log(`mode（本process）: ${cfg.mode}${USE_MOCK ? '  [--mock]' : '  [強制 lan]'}`);
  log(`KPOS 位址     : http://${cfg.kpos_ip}:${cfg.kpos_port}`);
  log(`app_id        : ${cfg.app_id || '(未設定)'}`);
  log(`app_secret    : ${mask(cfg.app_secret)}`);
  log(`callback_url  : ${cfg.callback_url || '(未設定)'}`);
  console.log('─'.repeat(64));

  if (!USE_MOCK && (!cfg.app_id || !cfg.app_secret)) {
    console.error('✗ KPAY_APP_ID / KPAY_APP_SECRET 未設定，無法行 lan 模式');
    console.error('  → 填入 .env 再試（gitignored，唔好 commit）');
    process.exit(1);
  }
  return cfg;
}

// ===== 檢查 kpay_configs 表有冇 row（會靜默覆蓋 .env，見 KPAY_INTEGRATION_GUIDE §6）=====
async function checkKpayConfigsRow() {
  try {
    const row = await require(path.join(ROOT, 'database', 'db')).getKpayConfig(STORE_ID);
    if (row) {
      console.warn('');
      console.warn('⚠️  kpay_configs 表有 row！佢會靜默覆蓋 .env，而 schema 預設 mode=\'lan\'');
      console.warn('    → 上面印嘅 config 未必等於 .env。建議清走呢個 row（見指引 §6）');
      console.warn('');
    }
  } catch (e) {
    // 表唔存在 / 讀唔到都唔阻測試
    log(`（略過 kpay_configs 檢查: ${e.message}）`);
  }
}

// ===== 各階段 =====
async function stepSign() {
  log('階段 1：簽到 sign() → 測 credentials + KPOS 連通性');
  const keys = await kpayService.sign(STORE_ID);
  log('✓ 簽到成功');
  log(`  appPrivateKey    : ${mask(keys.appPrivateKey)}`);
  log(`  platformPublicKey: ${mask(keys.platformPublicKey)}`);
  return true;
}

async function stepSales(paymentType, amount) {
  const outTradeNo = getOpt('out-trade-no', newOutTradeNo());
  const cfg = await kpayService.getConfig(STORE_ID);
  const callbackUrl = WITH_CALLBACK ? cfg.callback_url : undefined;

  log(`階段 2：開單 sales()  outTradeNo=${outTradeNo}  amount=$${amount}  paymentType=${paymentType}`);
  if (callbackUrl) {
    log(`  （帶 callbackUrl=${callbackUrl}）`);
  } else {
    log('  （唔帶 callbackUrl —— 唔會觸發回調，靠 query() 查狀態）');
  }

  const result = await kpayService.sales({
    outTradeNo,
    amount,
    paymentType,
    callbackUrl,
    description: 'KPay 接駁測試單（非真實營運）',
    storeId: STORE_ID
  });

  log(`  KPOS 回應: ${JSON.stringify(result)}`);
  if (result && result.code === 11000) {
    log('✓ 已轉 KPOS 前台收款（11000）—— 去卡機完成付款');
  } else if (result && result.code === 10000) {
    log('✓ KPOS 回 10000');
  } else {
    log(`⚠️  非預期 code=${result && result.code}`);
  }
  return outTradeNo;
}

// 輪詢直到 payResult===2（成功）或逾時
async function stepPoll(outTradeNo, timeoutMs) {
  log(`階段 3：輪詢 query()，最多等 ${Math.round(timeoutMs / 1000)} 秒…`);
  const deadline = Date.now() + timeoutMs;

  while (Date.now() < deadline) {
    let qr;
    try {
      qr = await kpayService.query(outTradeNo, STORE_ID);
    } catch (e) {
      log(`  query 失敗: ${e.message}（繼續試）`);
      await sleep(POLL_INTERVAL_MS);
      continue;
    }

    const data = (qr && qr.data) || qr || {};
    const left = Math.round((deadline - Date.now()) / 1000);
    log(`  payResult=${data.payResult}  status=${data.status || '-'}  （剩 ${left}s）`);

    if (data.payResult === 2) {
      log('✓ 付款成功（payResult=2）');
      log(`  payMethod=${data.payMethod}  transactionNo=${data.transactionNo || '-'}`);
      return { ok: true, data };
    }
    if (data.payResult !== undefined && data.payResult !== 2 && data.payResult !== 1) {
      log(`✗ 付款未成功（payResult=${data.payResult}）`);
      return { ok: false, data };
    }
    await sleep(POLL_INTERVAL_MS);
  }

  log('⏱ 逾時：時間內未收到成功結果');
  return { ok: false, timeout: true };
}

async function stepClose(outTradeNo) {
  log(`階段 4：關閉 close()  outTradeNo=${outTradeNo}`);
  const result = await kpayService.close(outTradeNo, STORE_ID);
  log(`  KPOS 回應: ${JSON.stringify(result)}`);
  if (result && result.code === 10000) {
    log('✓ 已關閉');
  } else {
    log('⚠️  非預期回應（20010/20017 = close 時已成交/已關閉，屬正常競態）');
  }

  // close 完必須補一次 query —— 客人可能喺 close race window 已經俾咗錢
  log('  補一次 query 確認冇漏單…');
  try {
    const qr = await kpayService.query(outTradeNo, STORE_ID);
    const data = (qr && qr.data) || qr || {};
    if (data.payResult === 2) {
      log('  ⚠️⚠️ 客人其實已經付款成功！唔可以當取消處理');
    } else {
      log(`  ✓ 確認未付款（payResult=${data.payResult}）`);
    }
  } catch (e) {
    log(`  query 失敗: ${e.message}`);
  }
  return true;
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

// ===== 主流程 =====
async function main() {
  const cfg = await printConfig();
  await checkKpayConfigsRow();

  // mock 模式唔使 TCP 檢查
  if (!USE_MOCK) {
    log(`前置檢查：TCP 連 ${cfg.kpos_ip}:${cfg.kpos_port} …`);
    const tcp = await checkTcp(cfg.kpos_ip, cfg.kpos_port);
    if (!tcp.ok) {
      console.error(`✗ 連唔到 KPOS（${tcp.reason}）`);
      console.error('  → 檢查：卡機有冇開機、係唔係同一個 LAN/VLAN、IP 是否正確、防火牆');
      process.exit(1);
    }
    log('✓ TCP 通');
    console.log('─'.repeat(64));
  }

  const paymentType = parseInt(getOpt('type', '1'), 10);
  const amount = parseFloat(getOpt('amount', '1'));

  switch (command) {
    case 'sign':
      await stepSign();
      break;

    case 'sales': {
      await stepSign();
      const otn = await stepSales(paymentType, amount);
      console.log('');
      log(`開單成功，記低 outTradeNo：${otn}`);
      log(`查狀態：node scripts/kpay-test.js query --out-trade-no ${otn}`);
      log(`取消  ：node scripts/kpay-test.js cancel --out-trade-no ${otn}`);
      break;
    }

    case 'query':
      await stepPoll(getOpt('out-trade-no'), 5000);
      break;

    case 'cancel':
      await stepClose(getOpt('out-trade-no'));
      break;

    case 'flow':
    default: {
      await stepSign();
      console.log('─'.repeat(64));
      const otn = await stepSales(paymentType, amount);
      console.log('─'.repeat(64));
      const poll = await stepPoll(otn, kpayService.SALES_TIMEOUT_MS);
      console.log('─'.repeat(64));
      if (!poll.ok) await stepClose(otn);
      console.log('─'.repeat(64));
      log('流程完結。提醒：呢單**冇**寫入 kpay_payments，所以 KPOS 回調會俾 server 當「未知交易」拒收 ——');
      log('      回調驗簽同自動結賬要另外經運行中嘅 server 測（見指引 §9）。');
      break;
    }
  }
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error('');
    console.error('✗ 測試失敗：', e.message);
    process.exit(1);
  });
