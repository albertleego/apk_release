#!/usr/bin/env node
/**
 * KPay 卡機服務探測工具
 *
 * 用嚟喺調試卡機設定（例如 Kiosk 模式、LAN API 開關）時，快速確認
 * 「卡機到底有冇服務在監聽、喺邊個埠」——唔使每次都跑完整測試流程。
 *
 * 用法：
 *   node scripts/kpay-probe.js                 # 用 .env 嘅 KPAY_KPOS_IP
 *   node scripts/kpay-probe.js 192.168.3.167   # 指定 IP
 *
 * 讀法：
 *   OPEN     = 有服務在監聽（我哋要嘅結果）
 *   REFUSED  = 機器有回應，但該埠無服務
 *   TIMEOUT  = 封包被丟棄（可能係防火牆，或 WiFi 太慢等唔到）
 *
 * 注意：呢台機回應好慢（實測 TCP 建連要 ~2.9 秒），所以逾時設得比較寬鬆。
 */

const path = require('path');
const net = require('net');

const ROOT = path.resolve(__dirname, '..');
require('dotenv').config({ path: path.join(ROOT, '.env'), quiet: true });

const HOST = process.argv[2] || process.env.KPAY_KPOS_IP || '192.168.3.200';
const TIMEOUT_MS = 6000;

// 常見 POS / Android 終端服務埠
const PORTS = [
  18080, 18081, 18082, 18083, 18084, 18085, 18090, // KPay 預設埠及其鄰居
  7000, 7001, 7002, 3000, 5000,
  5555,          // Android ADB
  8000, 8080, 8443, 80, 443,
  9100, 22       // 列印 / SSH
];

function probe(port) {
  return new Promise((resolve) => {
    const sock = new net.Socket();
    let done = false;
    const t0 = Date.now();
    const finish = (state) => {
      if (done) return;
      done = true;
      sock.destroy();
      resolve({ port, state, ms: Date.now() - t0 });
    };
    sock.setTimeout(TIMEOUT_MS);
    sock.once('connect', () => finish('OPEN'));
    sock.once('timeout', () => finish('TIMEOUT'));
    sock.once('error', (e) => finish(e.code === 'ECONNREFUSED' ? 'REFUSED' : e.code || 'ERROR'));
    sock.connect(port, HOST);
  });
}

(async () => {
  console.log('═'.repeat(58));
  console.log(`  探測目標：${HOST}`);
  console.log(`  逾時設定：${TIMEOUT_MS}ms`);
  console.log('═'.repeat(58));

  const results = await Promise.all(PORTS.map(probe));

  const open = results.filter((r) => r.state === 'OPEN');
  const refused = results.filter((r) => r.state === 'REFUSED');
  const timedOut = results.filter((r) => r.state === 'TIMEOUT');

  console.log('');
  console.log('結果：');
  for (const r of results.sort((a, b) => a.port - b.port)) {
    const mark = { OPEN: '✓ 開放', REFUSED: '· 拒絕', TIMEOUT: '· 逾時' }[r.state] || '· ' + r.state;
    console.log(`  ${String(r.port).padStart(6)}  ${mark.padEnd(8)} ${r.ms}ms`);
  }

  console.log('');
  console.log('─'.repeat(58));
  if (open.length) {
    console.log(`✓ 有 ${open.length} 個埠開放：${open.map((r) => r.port).join(', ')}`);
    if (open.some((r) => r.port !== 18080)) {
      console.log('  ⚠️  18080 唔喺開放清單 —— 若 KPay 用其他埠，要改 .env 嘅 KPAY_KPOS_PORT');
    }
  } else if (refused.length) {
    console.log(`✗ 冇任何埠開放（${refused.length} 個主動拒絕 = 機器活著但無服務）`);
    console.log('  → LAN POS API 未啟動。去卡機設定搵「開放 API / LAN / POS Server」之類嘅開關，');
    console.log('    或向 KPay 技術支援查詢啟動方式同正確埠號。');
  } else {
    console.log('✗ 全部逾時 —— 封包被丟棄');
    console.log('  → 可能：IP 錯誤、唔同網段、防火牆、或 WiFi 訊號太差。先 ping 確認。');
  }

  if (refused.length > 0) {
    const times = refused.map((r) => r.ms);
    const avg = Math.round(times.reduce((a, b) => a + b, 0) / times.length);
    console.log('');
    console.log(`ℹ️  平均回應時間 ${avg}ms。同網段正常應 <5ms，偏高代表 WiFi 品質差 ——`);
    console.log('   付款流程有 10 秒逾時，建議改用有線網絡。');
  }
  console.log('─'.repeat(58));
})();
