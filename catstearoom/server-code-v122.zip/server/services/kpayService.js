/**
 * KPay 智能收款機（KPOS）LAN POS API client —— 路線 A
 *
 * 離場機真支付：本地 server 直接 call 店內 KPOS
 *   http://<kpos-ip>:18080/v2/pos/*
 * 實時桌號數據只留喺本地主機，唔上雲，所以用 LAN POS API（路線 A），唔用 Cloud API。
 * KPOS 必須同 server 喺同一 LAN/VLAN，MAC → 固定 IP（見 MD Files/KPAY_INTEGRATION_GUIDE.MD）。
 *
 * Mock 模式（KPAY_MODE=mock，預設）：
 *   所有操作本地模擬，sales() 3 秒後觸發模擬成功回調（行同一 idempotent callback handler），
 *   用嚟開發/測試離場機成條 UI 流程；攞到真 KPay credentials 同卡機先轉 lan。
 *
 * 簽名規則（SHA256withRSA，官方 POS API 對接）：
 *   POST/PUT content = `METHOD\n{path}\ntimestamp\nnonceStr\n{json body}\n`（每行以 \n 結尾）
 *   GET content = `METHOD\n{path}\ntimestamp\nnonceStr\n`（冇 body 行，4 行）
 *   → 用工作私鑰（appPrivateKey）sign → Base64 → header `signature`
 *   回調驗簽用 platformPublicKey（headers 帶 signature/timestamp/nonceStr，body 用原 byte）。
 *
 * 工作密鑰換領：POST /v2/pos/sign，headers **只有** timestamp + nonceStr（冇 signature header、冇 appId header），
 *   body `{appId, appSecret}`；code 10000 後 `data.platformPublicKey` / `data.appPrivateKey` 為 raw base64，
 *   Node crypto 用之前要包成 `-----BEGIN {TYPE} KEY-----` PEM。
 *
 * 參考文檔：https://docs-posserver.kpay-group.com/ （ID: kpay / PW: oL9r8mruJIU）
 */

const crypto = require('crypto');
const { getKpayConfig } = require('../../database/db');

// ===== 配置 =====
const DEFAULT_KPOS_PORT = 18080;
// KPOS 無回應 timeout。預設 10000（行為不變）；可用 KPAY_HTTP_TIMEOUT_MS 覆寫。
// 實測卡機 WiFi 每次新建連線要 ~2.7 秒，10 秒對慢網路偏緊。
const HTTP_TIMEOUT_MS = parseInt(process.env.KPAY_HTTP_TIMEOUT_MS || '10000', 10);
const SALES_TIMEOUT_MS = 65000; // KPOS 收款預設 65 秒超時（主動查詢時用）

// 工作密鑰快取（每分店一份；結算/過期後要重簽）
const keyCache = {}; // store_id -> { appPrivateKey, platformPublicKey }

// mock 回調 handler（由 kpayRoutes 註冊，避免 circular dependency）
let _mockCallbackHandler = null;

function setMockCallbackHandler(fn) {
  _mockCallbackHandler = fn;
}

// 32 位隨機 nonceStr（官方要求；避免重放）
const NONCE_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
function genNonce() {
  const bytes = crypto.randomBytes(32);
  let out = '';
  for (let i = 0; i < 32; i += 1) {
    out += NONCE_CHARS[bytes[i] % NONCE_CHARS.length];
  }
  return out;
}

// ===== 配置 =====
async function getConfig(storeId) {
  const row = await getKpayConfig(storeId);
  const cfg = {
    mode: (process.env.KPAY_MODE || 'mock'),          // mock | lan
    kpos_ip: process.env.KPAY_KPOS_IP || '192.168.3.200',
    kpos_port: parseInt(process.env.KPAY_KPOS_PORT || String(DEFAULT_KPOS_PORT), 10),
    app_id: process.env.KPAY_APP_ID || '',
    app_secret: process.env.KPAY_APP_SECRET || '',
    callback_url: process.env.KPAY_CALLBACK_URL || ''
  };
  // 分店 kpay_configs 覆寫 .env fallback（⚠️ 唔好 populate kpay_configs 表：schema 預設 mode='lan'，
  // 有 row 會 silent 覆蓋 .env —— 見 MD Files/KPAY_INTEGRATION_GUIDE.MD）
  if (row) {
    if (row.mode) cfg.mode = row.mode;
    if (row.kpos_ip) cfg.kpos_ip = row.kpos_ip;
    if (row.kpos_port) cfg.kpos_port = row.kpos_port;
    if (row.app_id) cfg.app_id = row.app_id;
    if (row.app_secret) cfg.app_secret = row.app_secret;
    if (row.callback_url) cfg.callback_url = row.callback_url;
  }
  return cfg;
}

// ===== 金額格式化：12 位零填充最小貨幣單位（$1.00 → "000000000100"）=====
function formatAmount(amount) {
  const cents = Math.round(Number(amount || 0) * 100);
  return String(cents).padStart(12, '0');
}

// ===== PEM helper：KPay 工作密鑰係 raw base64，Node crypto 要用之前包返 PEM =====
// raw / 已帶 armor / 帶換行 都支援（剝走現有 armor + 空白後再包）
function toPem(raw, type) {
  const body = String(raw || '')
    .replace(/-----BEGIN [A-Z ]*KEY-----/g, '')
    .replace(/-----END [A-Z ]*KEY-----/g, '')
    .replace(/\s+/g, '');
  return `-----BEGIN ${type} KEY-----\n${body}\n-----END ${type} KEY-----`;
}

// ===== 簽名 =====
// body 有先至加 body 行（GET / body 空 → 4 行）；每行以 \n 結尾（含最後一行）
function buildSignatureContent(method, path, timestamp, nonceStr, body) {
  const lines = [method, path, String(timestamp), String(nonceStr)];
  if (body !== undefined && body !== null && body !== '') lines.push(body);
  return lines.join('\n') + '\n';
}

function signContent(content, privateKey) {
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(content, 'utf8');
  return signer.sign(toPem(privateKey, 'PRIVATE'), 'base64');
}

function verifyContent(content, signature, publicKey) {
  try {
    const verifier = crypto.createVerify('RSA-SHA256');
    verifier.update(content, 'utf8');
    return verifier.verify(toPem(publicKey, 'PUBLIC'), signature, 'base64');
  } catch (e) {
    console.error('[kpay] 驗簽錯誤:', e.message);
    return false;
  }
}

// ===== HTTP（仿 aliyunProxyRoutes：global fetch + AbortController timeout）=====
async function httpPost(url, payload, headers) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), HTTP_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...headers },
      body: JSON.stringify(payload),
      signal: controller.signal
    });
    clearTimeout(timer);
    return await res.json();
  } catch (e) {
    clearTimeout(timer);
    if (e.name === 'AbortError') throw new Error(`KPOS 無回應（超過 ${HTTP_TIMEOUT_MS / 1000} 秒）`);
    throw e;
  }
}

async function httpGet(url, headers) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), HTTP_TIMEOUT_MS);
  try {
    const res = await fetch(url, { method: 'GET', headers, signal: controller.signal });
    clearTimeout(timer);
    return await res.json();
  } catch (e) {
    clearTimeout(timer);
    if (e.name === 'AbortError') throw new Error(`KPOS 無回應（超過 ${HTTP_TIMEOUT_MS / 1000} 秒）`);
    throw e;
  }
}

// ===== 簽名 header：timestamp + nonceStr 每次重新生成（防重放，retry 都要新簽）=====
function authHeaders(cfg, keys, method, path, body) {
  const timestamp = Date.now();
  const nonceStr = genNonce();
  const content = buildSignatureContent(method, path, timestamp, nonceStr, body);
  const signature = signContent(content, keys.appPrivateKey);
  return { appId: cfg.app_id, timestamp: String(timestamp), nonceStr, signature };
}

// ===== 40004（工作密鑰失效）→ 清 cache + 原樣重試一次（makeRequest 內部會重簽）=====
async function requestWithKeyRefresh(storeId, makeRequest) {
  let result = await makeRequest();
  if (result && result.code === 40004) {
    clearKeys(storeId);
    console.warn('[kpay] 工作密鑰失效（40004），重簽後重試一次');
    result = await makeRequest();
  }
  return result;
}

// ===== 簽到：換工作密鑰（appPrivateKey + platformPublicKey）=====
// 官方：POST /v2/pos/sign，headers 只有 timestamp + nonceStr（冇 signature header、冇 appId header）
async function sign(storeId) {
  const cfg = await getConfig(storeId);
  if (cfg.mode === 'mock') {
    return { appPrivateKey: 'mock-private-key', platformPublicKey: 'mock-public-key' };
  }
  if (keyCache[storeId]) return keyCache[storeId];
  if (!cfg.app_id || !cfg.app_secret) {
    throw new Error('KPay 未配置：缺少 appId/appSecret');
  }
  const timestamp = Date.now();
  const nonceStr = genNonce();
  const path = '/v2/pos/sign';
  const payload = { appId: cfg.app_id, appSecret: cfg.app_secret };

  const result = await httpPost(`http://${cfg.kpos_ip}:${cfg.kpos_port}${path}`, payload, {
    timestamp: String(timestamp),
    nonceStr
  });

  if (!result || result.code !== 10000) {
    throw new Error('KPay 簽到失敗: ' + JSON.stringify(result));
  }
  // keys 喺 result.data 下面（保平安 fallback 埋 top-level）
  const d = (result.data && typeof result.data === 'object') ? result.data : result;
  if (!d || !d.appPrivateKey || !d.platformPublicKey) {
    throw new Error('KPay 簽到缺少工作密鑰: ' + JSON.stringify(result));
  }
  keyCache[storeId] = {
    appPrivateKey: d.appPrivateKey,
    platformPublicKey: d.platformPublicKey
  };
  return keyCache[storeId];
}

function clearKeys(storeId) {
  delete keyCache[storeId];
}

// ===== 消費（KPOS 彈收款畫面）=====
// 回 code：10000 成功、11000 已轉前台收款（正常等待付款）、40001/40002/40004 認證/簽名/密鑰問題、50002 終端忙碌
async function sales({ outTradeNo, amount, paymentType, callbackUrl, description, storeId }) {
  const cfg = await getConfig(storeId);

  if (cfg.mode === 'mock') {
    // mock：3 秒後模擬成功回調（行同一 idempotent callback handler）
    console.log(`[kpay][mock] 模擬收款: outTradeNo=${outTradeNo}, amount=${amount}, paymentType=${paymentType}`);
    if (_mockCallbackHandler) {
      setTimeout(() => {
        _mockCallbackHandler({
          outTradeNO: outTradeNo,
          payAmount: formatAmount(amount),
          payResult: 2, // 成功
          payMethod: 0,
          transactionNo: 'MOCK-TXN-' + Date.now(),
          refNo: 'MOCK-REF-' + Date.now(),
          storeId
        }).catch(err => console.error('[kpay][mock] 模擬回調處理錯誤:', err));
      }, 3000);
    }
    return { code: 11000, data: { outTradeNo, status: 'PAYING' } };
  }

  const path = '/v2/pos/sales';
  const payload = {
    outTradeNo,
    description: description || '自動咖啡館離場結賬',
    payAmount: formatAmount(amount),
    tipsAmount: formatAmount(0),
    paymentType,
    payCurrency: '344' // HKD
  };
  // callbackUrl 有先至送（分店實際 callbackUrl 先係 signature 綁定嗰個 path）
  if (callbackUrl) payload.callbackUrl = callbackUrl;
  // 自助正掃（paymentType 2/8/6）唔使 memberCode / frontCamera / qrCodeContent（嗰啲係會員編號 / 反掃 / Kiosk 用）

  const makeRequest = async () => {
    const keys = await sign(storeId);
    const headers = authHeaders(cfg, keys, 'POST', path, JSON.stringify(payload));
    return httpPost(`http://${cfg.kpos_ip}:${cfg.kpos_port}${path}`, payload, headers);
  };
  return requestWithKeyRefresh(storeId, makeRequest);
}

// ===== 主動查詢（65 秒內收唔到回調要 query；KPay 上線測試強制要求）=====
async function query(outTradeNo, storeId) {
  const cfg = await getConfig(storeId);
  if (cfg.mode === 'mock') {
    return { code: 20011, data: { outTradeNo, status: 'PAYING' } };
  }
  const path = '/v2/pos/query?outTradeNo=' + encodeURIComponent(outTradeNo);

  const makeRequest = async () => {
    const keys = await sign(storeId);
    const headers = authHeaders(cfg, keys, 'GET', path, '');
    return httpGet(`http://${cfg.kpos_ip}:${cfg.kpos_port}${path}`, headers);
  };
  return requestWithKeyRefresh(storeId, makeRequest);
}

// ===== 關閉「進行中未付款」嘅銷售（取消取消單時用）=====
// POST /v2/pos/sales/close，body 淨 `{outTradeNo}`。
// 注意：/v2/pos/sales/cancel 係撤銷「已成交未結算」交易（要 originOutTradeNo），離場機取消唔用。
async function close(outTradeNo, storeId) {
  const cfg = await getConfig(storeId);
  if (cfg.mode === 'mock') {
    return { code: 10000, data: { outTradeNo } };
  }
  const path = '/v2/pos/sales/close';
  const payload = { outTradeNo };

  const makeRequest = async () => {
    const keys = await sign(storeId);
    const headers = authHeaders(cfg, keys, 'POST', path, JSON.stringify(payload));
    return httpPost(`http://${cfg.kpos_ip}:${cfg.kpos_port}${path}`, payload, headers);
  };
  return requestWithKeyRefresh(storeId, makeRequest);
}

// ===== 驗回調簽名（KPOS POST 過嚟，必須驗簽）=====
// mock 模式跳過驗簽；lan 模式用 platformPublicKey 驗「POST\n{callback_url path}\nts\nnonce\n{raw body}\n」。
// path 一定要用 cfg.callback_url 嘅實際 path（簽名綁死呢個 path，改咗就驗唔過）。
async function verifyCallback({ headers, body, rawBody, storeId }) {
  const cfg = await getConfig(storeId);
  if (cfg.mode === 'mock') return true;
  if (!cfg.callback_url) {
    // LAN 冇 callback_url = 冇嘢可驗，fail closed（唔好放唔可驗證嘅回調入嚟）
    console.error('[kpay] LAN 模式必須配置 KPAY_CALLBACK_URL 先可以驗回調簽名');
    return false;
  }
  let path = '/api/kpay/callback';
  try {
    path = new URL(cfg.callback_url).pathname;
  } catch (e) {
    console.warn('[kpay] KPAY_CALLBACK_URL 解析失敗，用預設 path 驗簽:', cfg.callback_url);
  }
  const keys = await sign(storeId);
  const { signature, timestamp, nonceStr } = headers;
  if (!signature || !timestamp || !nonceStr) return false;
  // body 行要用原 byte（rawBody）；冇 rawBody 先至 fallback re-stringify（脆弱，LAN 唔可信）
  let bodyLine = rawBody !== undefined && rawBody !== null ? rawBody.toString('utf8') : null;
  if (bodyLine === null) {
    console.warn('[kpay] 冇 raw body，用 JSON.stringify 重組驗簽（唔可靠）');
    bodyLine = JSON.stringify(body || {});
  }
  const content = buildSignatureContent('POST', path, timestamp, nonceStr, bodyLine);
  return verifyContent(content, signature, keys.platformPublicKey);
}

module.exports = {
  getConfig,
  formatAmount,
  toPem,
  buildSignatureContent,
  signContent,
  verifyContent,
  genNonce,
  sign,
  clearKeys,
  sales,
  query,
  close,
  verifyCallback,
  setMockCallbackHandler,
  SALES_TIMEOUT_MS
};
