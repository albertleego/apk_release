const express = require('express');
const router = express.Router();
const QRCode = require('qrcode');
const { v4: uuidv4 } = require('uuid');
const net = require('net');
const storeAwareMiddleware = require('../middleware/store-aware');
const RawPrinter = require('../printer-raw');
const Jimp = require('jimp');
const hongKongTime = require('../utils/hongKongTime');
const {
  getAvailableTables,
  createCustomer,
  assignTableToCustomer,
  getAvailableLockers,
  assignLockerToCustomer,
  checkMemberCard,
  addOrderItem,
  getValidHourProduct
} = require('../../database/db');

// 為所有路由添加分店上下文中間件
router.use(storeAwareMiddleware.initStoreContext);

// 健康檢查端點：檢查主機連線（打印機由 Android 端自行檢查）
router.get('/health', async (req, res) => {
  const result = { host: 'ok', printer: 'unknown' };
  res.json({ success: true, data: result });
});

/**
 * @route GET /api/entry/pricing
 * @desc 取得該分店的收費標準，含當前時段標記
 */
router.get('/pricing', async (req, res) => {
  try {
    const storeId = req.query.store_id || req.storeContext?.store_id || 'default_store';
    const db = require('../../database/db').db;

    // 取得香港目前時間資訊
    const now = new Date();
    const hkTime = hongKongTime.getHongKongTimeInfo(now);
    const currentTime = hkTime.timeString; // HH:MM
    const isWeekend = hkTime.isWeekend;

    // 查詢是否為自定義節假日
    const holidayRow = await new Promise((resolve) => {
      db.get('SELECT 1 FROM holidays WHERE date = ?', [hkTime.dateString], (err, row) => {
        resolve(err ? null : row);
      });
    });
    const isHoliday = isWeekend || !!holidayRow;

    // 查詢所有時段收費商品（首小時、次小時、全日通）
    const products = await new Promise((resolve, reject) => {
      db.all(
        `SELECT name, price, has_time_restriction,
                weekday_start_time, weekday_end_time,
                weekday_start_time_2, weekday_end_time_2,
                holiday_start_time, holiday_end_time,
                holiday_start_time_2, holiday_end_time_2
         FROM products
         WHERE category = '收費'
           AND has_time_restriction = 1
           AND is_available = 1
           AND store_id = ?
           AND (name LIKE '%首小時%' OR name LIKE '%次小時%' OR name LIKE '%全日通%')
         ORDER BY product_order ASC`,
        [storeId],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows || []);
        }
      );
    });

    // 按名稱分類組織
    const periodMap = {
      weekday: { id: 'weekday', label: '閒日', labelKey: 'pricingWeekday', items: [] },
      holiday_nonpeak: { id: 'holiday_nonpeak', label: '星期六日及公眾假期 - 2pm前 及 6pm後', labelKey: 'pricingHolidayNonpeak', items: [] },
      holiday_peak: { id: 'holiday_peak', label: '星期六日及公眾假期 - 2pm-6pm', labelKey: 'pricingHolidayPeak', items: [] }
    };

    products.forEach(p => {
      // 簡化名稱顯示
      let displayName = '';
      let periodId = null;

      if (p.name.includes('首小時')) displayName = '首小時';
      else if (p.name.includes('次小時')) displayName = '次小時';
      else if (p.name.includes('全日通')) displayName = '全日通';

      if (p.name.includes('閒日')) {
        periodId = 'weekday';
      } else if (p.name.includes('繁忙時段')) {
        periodId = 'holiday_peak';
      } else if (p.name.includes('非繁忙') || (p.name.includes('全日通') && p.name.includes('節假日'))) {
        periodId = 'holiday_nonpeak';
      }

      if (displayName && periodId && periodMap[periodId]) {
        periodMap[periodId].items.push({ name: displayName, price: p.price });
      }
    });

    // "全日通 - 節假日" 同時適用於非繁忙和繁忙時段
    const fullDayNonPeak = periodMap.holiday_nonpeak.items.find(i => i.name === '全日通');
    if (fullDayNonPeak && !periodMap.holiday_peak.items.find(i => i.name === '全日通')) {
      periodMap.holiday_peak.items.push({ ...fullDayNonPeak });
    }

    // 判斷當前時段
    let currentPeriod = 'weekday';
    if (isHoliday) {
      const currH = parseInt(currentTime.split(':')[0]);
      const currM = parseInt(currentTime.split(':')[1]);
      const currMinutes = currH * 60 + currM;
      const peakStart = 14 * 60;  // 14:00
      const peakEnd = 18 * 60;    // 18:00
      if (currMinutes >= peakStart && currMinutes < peakEnd) {
        currentPeriod = 'holiday_peak';
      } else {
        currentPeriod = 'holiday_nonpeak';
      }
    }

    // 組裝回應（保留陣列順序）
    const periods = Object.values(periodMap).map(p => ({
      ...p,
      isCurrent: p.id === currentPeriod
    }));

    res.json({
      success: true,
      data: {
        isHoliday,
        currentPeriod,
        periods
      }
    });

  } catch (error) {
    console.error('獲取收費標準錯誤:', error);
    res.status(500).json({
      success: false,
      error: '獲取收費標準失敗',
      message: error.message
    });
  }
});

// 入場處理 - 客人選擇人數
router.post('/entry', async (req, res) => {
  try {
    const { peopleCount, memberCardId, table_number, seating_type } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';

    console.log('入場處理請求:', {
      peopleCount,
      memberCardId,
      table_number,
      storeId,
      storeContext: req.storeContext,
      query: req.query,
      body: req.body,
      employee: req.employee ? { id: req.employee.id, role: req.employee.role, store_id: req.employee.store_id } : null
    });

    // 檢查會員卡（如果有提供）
    let isMember = false;
    if (memberCardId) {
      const member = await checkMemberCard(memberCardId);
      if (member) {
        isMember = true;
        // 會員跳過錄音播放
        console.log('會員入場，跳過錄音播放');
      }
    }

    // 先清理已結賬但桌位未釋放的客人
    const db = require('../../database/db').db;
    db.run(
      `UPDATE tables SET is_occupied = 0, current_customer_id = NULL
       WHERE current_customer_id IN (
         SELECT id FROM customers WHERE is_checked_out = 1
       )`,
      function(cleanupErr) {
        if (cleanupErr) {
          console.error('清理已結賬客人桌位錯誤:', cleanupErr);
        } else if (this.changes > 0) {
          console.log(`清理了 ${this.changes} 個已結賬客人的桌位`);
        }
      }
    );

    // 清理已結賬但儲物柜未釋放的客人（保持customer_id以便歷史查詢）
    db.run(
      `UPDATE lockers SET is_occupied = 0, closed_at = CURRENT_TIMESTAMP
       WHERE customer_id IN (
         SELECT id FROM customers WHERE is_checked_out = 1
       )`,
      function(cleanupLockerErr) {
        if (cleanupLockerErr) {
          console.error('清理已結賬客人儲物柜錯誤:', cleanupLockerErr);
        } else if (this.changes > 0) {
          console.log(`清理了 ${this.changes} 個已結賬客人的儲物柜`);
        }
      }
    );

    // 清理孤兒桌位（current_customer_id指向不存在的客人）
    db.run(
      `UPDATE tables SET is_occupied = 0, current_customer_id = NULL
       WHERE current_customer_id IS NOT NULL
       AND current_customer_id NOT IN (SELECT id FROM customers)`,
      function(orphanCleanupErr) {
        if (orphanCleanupErr) {
          console.error('清理孤兒桌位錯誤:', orphanCleanupErr);
        } else if (this.changes > 0) {
          console.log(`清理了 ${this.changes} 個孤兒桌位`);
        }
      }
    );

    // 清理孤兒儲物柜（customer_id指向不存在的客人）
    db.run(
      `UPDATE lockers SET is_occupied = 0, customer_id = NULL, closed_at = CURRENT_TIMESTAMP
       WHERE customer_id IS NOT NULL
       AND customer_id NOT IN (SELECT id FROM customers)`,
      function(orphanLockerCleanupErr) {
        if (orphanLockerCleanupErr) {
          console.error('清理孤兒儲物柜錯誤:', orphanLockerCleanupErr);
        } else if (this.changes > 0) {
          console.log(`清理了 ${this.changes} 個孤兒儲物柜`);
        }
      }
    );

    let selectedTable = null;
    const isNoTableMode = table_number === ''; // 空字符串表示無桌號模式

    // 檢查是否手動指定了桌號（非無桌號模式）
    if (table_number && !isNoTableMode) {
      console.log('嘗試使用手動指定桌號:', table_number);

      // 子桌號 (含小數點，如 A3.1) 不需檢查實體桌子
      const isSubTable = /^A\d+\.\d+$/i.test(String(table_number));
      if (isSubTable) {
        console.log('子桌號模式，跳過實體桌子檢查:', table_number);
        selectedTable = { table_number };
      } else {
        // 查詢指定的桌位是否存在且可用
        try {
          const db = require('../../database/db').db;
          const query = [
            'SELECT t.*',
            'FROM tables t',
            'WHERE t.table_number = ?',
            '  AND t.store_id = ?',
            '  AND t.is_occupied = 0',
            '  AND t.capacity >= ?'
          ].join('\n');

          const tableRow = await new Promise((resolve, reject) => {
            db.get(query, [table_number, storeId, peopleCount], (err, row) => {
              if (err) reject(err);
              else resolve(row);
            });
          });

          if (tableRow) {
            selectedTable = tableRow;
            console.log('手動指定桌號驗證成功:', {
              table_number: selectedTable.table_number,
              capacity: selectedTable.capacity,
              table_id: selectedTable.id
            });
          } else {
            console.log('手動指定桌號無效或不可用:', table_number);
            return res.status(400).json({
              error: '指定的桌號無效或不可用',
              debug: {
                table_number,
                storeId,
                peopleCount,
                message: '桌位可能不存在、已被佔用或容量不足'
              }
            });
          }
        } catch (error) {
          console.error('驗證手動指定桌號時發生錯誤:', error);
          return res.status(500).json({
            error: '驗證桌號時發生錯誤',
            message: error.message
          });
        }
      }
    }
    // 處理無桌號模式
    if (isNoTableMode) {
      console.log('無桌號模式，跳過桌位分配');
      selectedTable = { table_number: '' };
    } else if (!selectedTable) {
      // 如果沒有手動指定桌號，則自動尋找合適的桌位（僅在非無桌號模式下）
      console.log('沒有手動指定桌號，使用自動分配');
      const availableTables = await getAvailableTables(peopleCount, storeId);
      console.log('可用桌位查詢結果:', {
        peopleCount,
        availableTablesCount: availableTables.length,
        availableTables: availableTables.map(t => ({ table_number: t.table_number, capacity: t.capacity }))
      });

      if (availableTables.length === 0) {
        // 調試：檢查所有桌位狀態
        db.all('SELECT table_number, capacity, is_occupied, current_customer_id FROM tables ORDER BY table_number', (err, allTables) => {
          if (err) {
            console.error('檢查所有桌位錯誤:', err);
          } else {
            console.log('所有桌位狀態:', allTables);
            // 同時檢查customers表中是否有對應的客人
            db.all('SELECT id, table_number, is_checked_out FROM customers', (err2, customers) => {
              if (err2) console.error('檢查客人錯誤:', err2);
              else console.log('所有客人狀態:', customers);
            });
          }
        });

        return res.status(400).json({
          error: '暫時沒有合適的桌位，請稍後再試',
          debug: {
            peopleCount,
            message: `需要容量至少 ${peopleCount} 的桌位，但沒有找到空閒桌位`
          }
        });
      }

      // 選擇第一個合適的桌位
      selectedTable = availableTables[0];
      console.log('自動分配桌位:', { table_number: selectedTable.table_number, capacity: selectedTable.capacity });
    } // 結束 if (!selectedTable) 區塊

    // 創建客人記錄（包含分店信息）
    const customerData = {
      table_number: selectedTable.table_number,
      people_count: peopleCount,
      is_member: isMember ? 1 : 0,
      member_card_id: memberCardId || null,
      store_id: storeId,
      seating_type: seating_type || 'walk-in'
    };

    const customer = await createCustomer(customerData);

    // 分配桌位（僅在非無桌號模式下）
    if (!isNoTableMode && selectedTable.id) {
      await assignTableToCustomer(selectedTable.id, customer.id);
      console.log('已分配桌位:', selectedTable.table_number);
    } else {
      console.log('無桌號模式，跳過桌位分配');
    }

    // 分配儲物柜（根據人數） - 檢查分店是否使用儲物柜
    const assignedLockers = [];
    // 查詢分店是否使用儲物柜
    const storeConfig = await new Promise((resolve) => {
      const db = require('../../database/db').db;
      db.get(
        `SELECT * FROM stores WHERE id = ?`,
        [storeId],
        (err, row) => {
          if (err) {
            console.error('查詢分店儲物柜配置錯誤:', err);
            resolve({ use_lockers: 1 }); // 默認使用
          } else {
            // 確保 use_lockers 字段存在，如果不存在則默認為 1
            const useLockers = row && row.use_lockers !== undefined ? row.use_lockers : 1;
            resolve({ use_lockers: useLockers });
          }
        }
      );
    });

    if (storeConfig.use_lockers === 1) {
      const lockersNeeded = peopleCount; // 每1人一個儲物柜
      console.log('分配儲物柜:', { peopleCount, lockersNeeded });
      const availableLockers = await getAvailableLockers(lockersNeeded, storeId);
      console.log('可用儲物柜查詢結果:', {
        requested: lockersNeeded,
        found: availableLockers.length,
        lockers: availableLockers.map(l => ({ locker_number: l.locker_number, is_occupied: l.is_occupied, customer_id: l.customer_id }))
      });

      for (const locker of availableLockers) {
        await assignLockerToCustomer(locker.id, customer.id);
        assignedLockers.push(locker.locker_number);
      }
      console.log('已分配儲物柜:', assignedLockers);
    } else {
      console.log('分店設置為不使用儲物柜，跳過分配');
    }

    // 自動添加首小時商品（僅在非無桌號模式下）
    if (!isNoTableMode) {
      try {
        const now = new Date();
        const firstHourProduct = await getValidHourProduct('首小時', now, storeId);
        if (firstHourProduct) {
          await addOrderItem(customer.id, firstHourProduct.id, peopleCount, firstHourProduct.price);
          console.log(`已為客人 ${customer.id} 添加 ${peopleCount} 個首小時商品: ${firstHourProduct.name}`);
        } else {
          console.warn('未找到有效的首小時商品，跳過自動添加');
        }
      } catch (error) {
        console.error('添加首小時商品時發生錯誤:', error);
        // 不阻礙入場流程，僅記錄錯誤
      }
    } else {
      console.log('無桌號模式，跳過首小時商品添加');
    }

    // 生成QR Code數據
    const qrData = {
      customer_id: customer.id,
      qr_code: customer.qr_code,
      table_number: selectedTable.table_number,
      entry_time: new Date().toISOString()
    };

    // 生成QR Code圖片
    const qrCodeImage = await QRCode.toDataURL(JSON.stringify(qrData));

    // 準備小票數據
    const receiptData = {
      table_number: selectedTable.table_number,
      qr_code: customer.qr_code,
      people_count: peopleCount,
      entry_time: (() => { const d = new Date(); return `${d.getFullYear()}/${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getDate()).padStart(2,'0')} ${d.getHours()}:${String(d.getMinutes()).padStart(2,'0')}:${String(d.getSeconds()).padStart(2,'0')}`; })(),
      lockers: assignedLockers,
      is_member: isMember
    };

    // 觸發Socket事件通知收銀系統
    const io = req.app.get('io');
    io.emit('new-customer', {
      customer_id: customer.id,
      table_number: selectedTable.table_number,
      people_count: peopleCount,
      entry_time: new Date().toISOString(),
      qr_code: customer.qr_code
    });

    // 觸發設備控制事件
    io.emit('device-control', {
      device: 'lockers',
      action: 'open',
      locker_numbers: assignedLockers
    });

    // 如果不是會員，觸發錄音播放
    if (!isMember) {
      io.emit('device-control', {
        device: 'audio',
        action: 'play',
        message: 'welcome'
      });
    }

    // 觸發打印小票（Socket.IO 通知收銀系統）
    io.emit('print-receipt', receiptData);

    // 生成 ESC/POS 小票數據（Base64），由 Android APK 直接 USB 打印
    let receiptBase64 = null;
    try {
      const printResult = await printEntryReceipt(receiptData);
      if (printResult) {
        receiptBase64 = printResult.base64;
        console.log(`[entry] 小票數據生成成功: table ${receiptData.table_number}, ${Math.round(printResult.base64.length * 0.75)} bytes`);
      }
    } catch (err) {
      console.error('[entry-printer] 生成小票數據失敗:', err.message);
    }

    res.json({
      success: true,
      message: '入場處理成功',
      data: {
        customer_id: customer.id,
        table_number: selectedTable.table_number,
        qr_code: customer.qr_code,
        qr_code_image: qrCodeImage,
        people_count: peopleCount,
        lockers: assignedLockers,
        receipt_data: receiptData,
        receipt_base64: receiptBase64,
        skip_audio: isMember
      }
    });

  } catch (error) {
    console.error('入場處理錯誤:', error);
    res.status(500).json({
      error: '入場處理失敗',
      message: error.message
    });
  }
});

// NFC會員卡感應
router.post('/nfc-scan', async (req, res) => {
  try {
    const { cardId } = req.body;

    if (!cardId) {
      return res.status(400).json({ error: '請提供卡片ID' });
    }

    const member = await checkMemberCard(cardId);

    if (member) {
      // 會員卡有效
      res.json({
        success: true,
        is_member: true,
        member_info: {
          name: member.name,
          balance: member.balance,
          card_id: member.card_id
        },
        message: '會員卡驗證成功'
      });
    } else {
      // 非會員卡或無效卡
      res.json({
        success: false,
        is_member: false,
        message: '非會員卡或卡片無效'
      });
    }
  } catch (error) {
    console.error('NFC掃描錯誤:', error);
    res.status(500).json({
      error: 'NFC掃描處理失敗',
      message: error.message
    });
  }
});

// 獲取當前等待客人
router.get('/waiting', async (req, res) => {
  try {
    const storeId = req.storeContext?.store_id || 'default_store';
    // 從數據庫獲取最近入場的客人（分店過濾）
    const db = require('../../database/db').db;

    db.all(
      `SELECT c.*, t.table_number as actual_table
       FROM customers c
       LEFT JOIN tables t ON c.table_number = t.table_number
       WHERE c.is_checked_out = 0 AND c.store_id = ?
       ORDER BY c.entry_time DESC
       LIMIT 20`,
      [storeId],
      (err, rows) => {
        if (err) {
          throw err;
        }
        res.json({
          success: true,
          customers: rows
        });
      }
    );
  } catch (error) {
    console.error('獲取等待客人錯誤:', error);
    res.status(500).json({
      error: '獲取等待客人失敗',
      message: error.message
    });
  }
});

// 手動觸發儲物柜開啟
router.post('/open-locker', async (req, res) => {
  try {
    const { locker_number } = req.body;

    if (!locker_number) {
      return res.status(400).json({ error: '請提供儲物柜編號' });
    }

    const io = req.app.get('io');
    io.emit('device-control', {
      device: 'locker',
      action: 'open',
      locker_number: locker_number
    });

    res.json({
      success: true,
      message: `已發送開啟儲物柜 ${locker_number} 指令`
    });
  } catch (error) {
    console.error('開啟儲物柜錯誤:', error);
    res.status(500).json({
      error: '開啟儲物柜失敗',
      message: error.message
    });
  }
});

// 手動觸發小票打印
router.post('/print-receipt', async (req, res) => {
  try {
    const { table_number, qr_code, people_count } = req.body;

    const receiptData = {
      table_number: table_number || 'TEST',
      qr_code: qr_code || 'TEST-' + Date.now(),
      people_count: people_count || 1,
      entry_time: (() => { const d = new Date(); return `${d.getFullYear()}/${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getDate()).padStart(2,'0')} ${d.getHours()}:${String(d.getMinutes()).padStart(2,'0')}:${String(d.getSeconds()).padStart(2,'0')}`; })(),
      lockers: [1, 2, 3], // 測試用
      is_member: false
    };

    const io = req.app.get('io');
    io.emit('print-receipt', receiptData);

    res.json({
      success: true,
      message: '已發送打印小票指令',
      receipt_data: receiptData
    });
  } catch (error) {
    console.error('打印小票錯誤:', error);
    res.status(500).json({
      error: '打印小票失敗',
      message: error.message
    });
  }
});

// USB 打印機測試端點 (EM5827)
router.post('/test-printer', async (req, res) => {
  try {
    const { text } = req.body;
    const testText = text || `入場機器 USB 打印測試
自動咖啡館
${(() => { const d = new Date(); return `${d.getFullYear()}/${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getDate()).padStart(2,'0')} ${d.getHours()}:${String(d.getMinutes()).padStart(2,'0')}:${String(d.getSeconds()).padStart(2,'0')}`; })()}

測試打印機: KPOS_216 (EM5827)`;

    // 使用 UsbPrinter 發送測試打印
    const { UsbPrinter } = require('../usb-printer');
    const printer = new UsbPrinter({ printerName: 'KPOS_216' });

    printer.alignCenter();
    printer.setSize(2, 2);
    printer.println('=== 打印測試 ===');
    printer.setSize(1, 1);
    printer.println('');
    printer.alignLeft();
    printer.println(testText);
    printer.println('');
    printer.alignCenter();
    printer.println(new Date().toISOString());
    printer.newLine(3);
    printer.cut();

    await printer.execute();

    res.json({
      success: true,
      message: 'USB 測試打印成功',
      printer: 'KPOS_216 (EM5827)'
    });
  } catch (error) {
    console.error('USB 打印測試錯誤:', error);
    res.status(500).json({
      success: false,
      error: 'USB 打印測試失敗',
      message: error.message
    });
  }
});

// 調試用：獲取所有桌位狀態
router.get('/debug/tables', (req, res) => {
  try {
    const db = require('../../database/db').db;
    db.all(
      `SELECT t.*, c.qr_code, c.entry_time
       FROM tables t
       LEFT JOIN customers c ON t.current_customer_id = c.id
       ORDER BY t.table_number`,
      (err, rows) => {
        if (err) {
          console.error('獲取桌位狀態錯誤:', err);
          return res.status(500).json({ error: '獲取桌位狀態失敗', message: err.message });
        }

        // 獲取所有客人狀態
        db.all(
          `SELECT id, table_number, qr_code, entry_time, is_checked_out FROM customers ORDER BY entry_time DESC`,
          (err2, customers) => {
            if (err2) console.error('獲取客人錯誤:', err2);

            // 獲取所有儲物柜狀態
            db.all(
              `SELECT locker_number, is_occupied, customer_id, opened_at, closed_at FROM lockers ORDER BY locker_number`,
              (err3, lockers) => {
                if (err3) console.error('獲取儲物柜錯誤:', err3);

                res.json({
                  success: true,
                  tables: rows,
                  customers: customers || [],
                  lockers: lockers || [],
                  summary: {
                    total_tables: rows.length,
                    occupied_tables: rows.filter(t => t.is_occupied === 1).length,
                    available_tables: rows.filter(t => t.is_occupied === 0).length,
                    total_customers: customers ? customers.length : 0,
                    active_customers: customers ? customers.filter(c => c.is_checked_out === 0).length : 0,
                    total_lockers: lockers ? lockers.length : 0,
                    occupied_lockers: lockers ? lockers.filter(l => l.is_occupied === 1).length : 0,
                    available_lockers: lockers ? lockers.filter(l => l.is_occupied === 0).length : 0
                  }
                });
              }
            );
          }
        );
      }
    );
  } catch (error) {
    console.error('調試路由錯誤:', error);
    res.status(500).json({ error: '調試路由失敗', message: error.message });
  }
});

// 調試用：重置所有桌位狀態（測試用）
router.post('/debug/reset-tables', (req, res) => {
  try {
    const db = require('../../database/db').db;

    // 重置所有桌位為空閒
    db.run(`UPDATE tables SET is_occupied = 0, current_customer_id = NULL`, function(err) {
      if (err) {
        console.error('重置桌位錯誤:', err);
        return res.status(500).json({ error: '重置桌位失敗', message: err.message });
      }

      // 重置所有儲物柜
      db.run(`UPDATE lockers SET is_occupied = 0, customer_id = NULL, closed_at = NULL`, function(err2) {
        if (err2) console.error('重置儲物柜錯誤:', err2);

        res.json({
          success: true,
          message: `已重置 ${this.changes} 個桌位`,
          changes: this.changes
        });
      });
    });
  } catch (error) {
    console.error('重置桌位錯誤:', error);
    res.status(500).json({ error: '重置桌位失敗', message: error.message });
  }
});

/**
 * 生成入場小票 ESC/POS 數據（Base64 編碼），由 Android 端 USB 打印
 * @returns {{ base64: string, table_number: string } | null}
 */
async function printEntryReceipt(receiptData) {
    const RECEIPT_WIDTH = 48;

    try {
        const { table_number, entry_time, qr_code } = receiptData;

        // 計算顯示寬度（中文字元=2，英數字元=1）
        const displayWidth = (str) => [...str].reduce((w, c) => w + (c.charCodeAt(0) > 0x7f ? 2 : 1), 0);

        // 文字置中
        const center = (text, width = RECEIPT_WIDTH) => {
            const tw = displayWidth(text);
            const pad = Math.max(0, Math.floor((width - tw) / 2));
            return ' '.repeat(pad) + text + (width - tw - pad > 0 ? ' ' : '');
        };

        // 小票內容：桌號最上 → QR Code → 文字說明（文字用 ESC/POS 居中指令）
        let receipt = '';
        receipt += `$TABLE_NUMBER:${table_number}$\n`;
        receipt += `$QR_CODE:${qr_code}$\n`;
        receipt += `入場時間: ${entry_time}\n`;
        receipt += '二維碼用作離場結賬和購買貓零食, 請保存';

        const printer = new RawPrinter({
            ip_address: '0.0.0.0',
            port: 9100,
            encoding: 'GBK',
            timeout: 30000,
            printableWidth: 384  // 58mm紙 (203 DPI ≈ 384 dots)
        });

        // 逐行處理，偵測 QR Code / Table Number marker 並打印圖片
        const lines = receipt.split('\n');
        for (const line of lines) {
            const qrMatch = line.match(/^\$QR_CODE:(.+)\$$/);
            const tableNumMatch = line.match(/^\$TABLE_NUMBER:(.+)\$$/);
            if (qrMatch) {
                try {
                    const pngBuffer = await QRCode.toBuffer(qrMatch[1], {
                        type: 'png',
                        width: 250,  // 58mm紙 QR Code 縮小50%
                        margin: 1,
                        color: { dark: '#000000', light: '#ffffff' },
                        errorCorrectionLevel: 'M'
                    });
                    const base64 = pngBuffer.toString('base64');
                    await printer.printImageBase64(base64, 250);
                } catch (qrError) {
                    console.error('[entry-printer] QR Code生成失敗:', qrError.message);
                    printer.println(`[QR Error: ${qrError.message}]`);
                }
            } else if (tableNumMatch) {
                try {
                    // 只顯示桌號數字部分，移除字母前綴 (e.g. "A1" → "1")
                    const number = String(tableNumMatch[1]).replace(/[^0-9]/g, '') || tableNumMatch[1];
                    const fontPath = require('path').join(__dirname, '../../node_modules/@jimp/plugin-print/dist/fonts/open-sans/open-sans-128-black/open-sans-128-black.fnt');
                    const font = await Jimp.loadFont(fontPath);
                    const text = String(number);
                    const textWidth = Jimp.measureText(font, text);
                    const textHeight = Jimp.measureTextHeight(font, text, 500);
                    const canvasWidth = Math.max(textWidth + 40, 120);
                    const canvasHeight = textHeight + 20;
                    const pixelData = Buffer.alloc(canvasWidth * canvasHeight * 4, 255);
                    let image = new Jimp.Jimp({data: pixelData, width: canvasWidth, height: canvasHeight});
                    image.print({font, x: (canvasWidth - textWidth) / 2, y: 10, text});
                    const buf = await image.getBuffer('image/png');
                    const base64 = buf.toString('base64');
                    await printer.printImageBase64(base64, image.bitmap.width);
                    printer.newLine(2);
                } catch (imgError) {
                    console.error('[entry-printer] 桌號圖片生成失敗:', imgError.message);
                    printer.println(`[Table Number Error: ${imgError.message}]`);
                }
            } else {
                // 使用 ESC/POS 居中命令 (ESC a 1) 確保文字正確置中
                printer.alignCenter();
                printer.println(line);
                printer.alignLeft();
            }
        }

        printer.cut();

        // 加入 ESC/POS 前置指令（初始化 + GBK + 中文模式）
        const usbHeader = Buffer.from([
            0x1B, 0x40,       // ESC @ — 初始化
            0x1B, 0x74, 0x11, // ESC t 17 — GBK 編碼
            0x1C, 0x26        // FS & — 啟用中文模式
        ]);
        const fullData = Buffer.concat([usbHeader, printer.buffer]);
        printer.clear();

        return {
            base64: fullData.toString('base64'),
            table_number
        };
    } catch (error) {
        console.error('[entry-printer] 生成小票數據失敗:', error.message);
        return null;
    }
}

module.exports = router;