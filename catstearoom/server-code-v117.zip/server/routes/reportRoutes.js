const express = require('express');
const router = express.Router();
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');
const storeAwareMiddleware = require('../middleware/store-aware');
const { v4: uuidv4 } = require('uuid');

/**
 * @route GET /api/reports/daily
 * @desc 獲取日報表
 * @access Private/Staff
 */
router.get('/daily', authMiddleware.authenticate, storeAwareMiddleware.initStoreContext, storeAwareMiddleware.requireStoreAccess, authMiddleware.requireStaff, (req, res) => {
    try {
        const { date } = req.query;
        const targetDate = date ? new Date(date) : new Date();
        const dateStr = targetDate.toISOString().split('T')[0];
        const nextDate = new Date(targetDate);
        nextDate.setDate(nextDate.getDate() + 1);
        const nextDateStr = nextDate.toISOString().split('T')[0];

        // 獲取日營業額
        const revenueQuery = `
            SELECT
                COUNT(DISTINCT id) as unique_customers,
                COUNT(*) as total_transactions,
                SUM(total_amount) as total_revenue,
                AVG(total_amount) as average_order_value,
                MIN(total_amount) as min_order_value,
                MAX(total_amount) as max_order_value
            FROM customers
            WHERE DATE(entry_time) = ? AND is_checked_out = 1
        `;

        // 獲取商品銷售排行
        const productsQuery = `
            SELECT
                p.id,
                p.name,
                p.category,
                SUM(oi.quantity) as total_quantity,
                SUM(oi.quantity * oi.price_at_time) as total_revenue,
                COUNT(DISTINCT oi.customer_id) as order_count
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            JOIN customers c ON oi.customer_id = c.id
            WHERE DATE(c.entry_time) = ? AND c.is_checked_out = 1
            GROUP BY p.id
            ORDER BY total_quantity DESC
            LIMIT 10
        `;

        // 獲取時段分佈
        const hourlyQuery = `
            SELECT
                strftime('%H', entry_time) as hour,
                COUNT(*) as transaction_count,
                SUM(total_amount) as revenue,
                AVG(total_amount) as avg_order_value
            FROM customers
            WHERE DATE(entry_time) = ? AND is_checked_out = 1
            GROUP BY strftime('%H', entry_time)
            ORDER BY hour
        `;

        // 獲取員工銷售排行
        const employeesQuery = `
            SELECT
                e.id,
                e.username,
                e.full_name,
                COUNT(DISTINCT oi.customer_id) as transaction_count,
                SUM(oi.quantity * oi.price_at_time) as total_revenue,
                AVG(oi.quantity * oi.price_at_time) as avg_order_value
            FROM order_items oi
            JOIN employees e ON oi.employee_id = e.id
            JOIN customers c ON oi.customer_id = c.id
            WHERE DATE(c.entry_time) = ? AND c.is_checked_out = 1
            GROUP BY e.id
            ORDER BY total_revenue DESC
        `;

        // 並行執行所有查詢
        db.get(revenueQuery, [dateStr], (revenueErr, revenue) => {
            if (revenueErr) {
                console.error('查詢日營業額錯誤:', revenueErr);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: revenueErr.message
                });
            }

            db.all(productsQuery, [dateStr], (productsErr, topProducts) => {
                if (productsErr) {
                    console.error('查詢商品銷售錯誤:', productsErr);
                    // 繼續處理，不中斷
                }

                db.all(hourlyQuery, [dateStr], (hourlyErr, hourlyStats) => {
                    if (hourlyErr) {
                        console.error('查詢時段分佈錯誤:', hourlyErr);
                    }

                    db.all(employeesQuery, [dateStr], (employeesErr, employees) => {
                        if (employeesErr) {
                            console.error('查詢員工銷售錯誤:', employeesErr);
                        }

                        // 計算與前一天的比較
                        const prevDate = new Date(targetDate);
                        prevDate.setDate(prevDate.getDate() - 1);
                        const prevDateStr = prevDate.toISOString().split('T')[0];

                        db.get(
                            `SELECT SUM(total_amount) as prev_revenue FROM customers WHERE DATE(entry_time) = ? AND is_checked_out = 1`,
                            [prevDateStr],
                            (prevErr, prevRow) => {
                                if (prevErr) console.error('查詢前日數據錯誤:', prevErr);

                                const prevRevenue = prevRow?.prev_revenue || 0;
                                const revenueChange = prevRevenue > 0
                                    ? ((revenue.total_revenue || 0) - prevRevenue) / prevRevenue * 100
                                    : 0;

                                res.json({
                                    success: true,
                                    data: {
                                        date: dateStr,
                                        revenue: {
                                            ...revenue,
                                            previous_day_revenue: prevRevenue,
                                            revenue_change_percent: revenueChange
                                        },
                                        top_products: topProducts || [],
                                        hourly_distribution: hourlyStats || [],
                                        employee_performance: employees || [],
                                        summary: {
                                            report_generated_at: new Date().toISOString(),
                                            data_points: {
                                                revenue: revenue ? 1 : 0,
                                                products: topProducts ? topProducts.length : 0,
                                                hours: hourlyStats ? hourlyStats.length : 0,
                                                employees: employees ? employees.length : 0
                                            }
                                        }
                                    }
                                });
                            }
                        );
                    });
                });
            });
        });
    } catch (error) {
        console.error('生成日報表錯誤:', error);
        res.status(500).json({
            success: false,
            error: '生成日報表失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/reports/weekly
 * @desc 獲取週報表
 * @access Private/Staff
 */
router.get('/weekly', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { year, week } = req.query;

        // 計算週的開始和結束日期
        const now = new Date();
        const targetYear = year || now.getFullYear();
        const targetWeek = week || getWeekNumber(now);

        const weekDates = getWeekDates(targetYear, targetWeek);
        const startDate = weekDates.start.toISOString().split('T')[0];
        const endDate = weekDates.end.toISOString().split('T')[0];

        // 週營業額總計
        const revenueQuery = `
            SELECT
                DATE(entry_time) as date,
                COUNT(DISTINCT id) as unique_customers,
                COUNT(*) as total_transactions,
                SUM(total_amount) as total_revenue,
                AVG(total_amount) as average_order_value
            FROM customers
            WHERE DATE(entry_time) BETWEEN ? AND ? AND is_checked_out = 1
            GROUP BY DATE(entry_time)
            ORDER BY date
        `;

        // 週商品銷售排行
        const productsQuery = `
            SELECT
                p.id,
                p.name,
                p.category,
                SUM(oi.quantity) as total_quantity,
                SUM(oi.quantity * oi.price_at_time) as total_revenue,
                COUNT(DISTINCT oi.customer_id) as order_count,
                AVG(oi.quantity) as avg_quantity_per_order
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            JOIN customers c ON oi.customer_id = c.id
            WHERE DATE(c.entry_time) BETWEEN ? AND ? AND c.is_checked_out = 1
            GROUP BY p.id
            ORDER BY total_revenue DESC
            LIMIT 15
        `;

        // 週員工績效
        const employeesQuery = `
            SELECT
                e.id,
                e.username,
                e.full_name,
                COUNT(DISTINCT oi.customer_id) as transaction_count,
                SUM(oi.quantity * oi.price_at_time) as total_revenue,
                AVG(oi.quantity * oi.price_at_time) as avg_order_value,
                COUNT(DISTINCT DATE(c.entry_time)) as active_days
            FROM order_items oi
            JOIN employees e ON oi.employee_id = e.id
            JOIN customers c ON oi.customer_id = c.id
            WHERE DATE(c.entry_time) BETWEEN ? AND ? AND c.is_checked_out = 1
            GROUP BY e.id
            ORDER BY total_revenue DESC
        `;

        db.all(revenueQuery, [startDate, endDate], (revenueErr, dailyRevenue) => {
            if (revenueErr) {
                console.error('查詢週營業額錯誤:', revenueErr);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: revenueErr.message
                });
            }

            // 計算週總計
            const weekSummary = dailyRevenue.reduce((acc, day) => ({
                unique_customers: acc.unique_customers + (day.unique_customers || 0),
                total_transactions: acc.total_transactions + (day.total_transactions || 0),
                total_revenue: acc.total_revenue + (day.total_revenue || 0),
                days_count: acc.days_count + 1
            }), { unique_customers: 0, total_transactions: 0, total_revenue: 0, days_count: 0 });

            weekSummary.average_order_value = weekSummary.total_transactions > 0
                ? weekSummary.total_revenue / weekSummary.total_transactions
                : 0;
            weekSummary.average_daily_revenue = weekSummary.days_count > 0
                ? weekSummary.total_revenue / weekSummary.days_count
                : 0;

            db.all(productsQuery, [startDate, endDate], (productsErr, topProducts) => {
                if (productsErr) {
                    console.error('查詢週商品銷售錯誤:', productsErr);
                }

                db.all(employeesQuery, [startDate, endDate], (employeesErr, employees) => {
                    if (employeesErr) {
                        console.error('查詢週員工績效錯誤:', employeesErr);
                    }

                    // 獲取前一週數據比較
                    const prevWeekDates = getWeekDates(targetYear, targetWeek - 1);
                    const prevStartDate = prevWeekDates.start.toISOString().split('T')[0];
                    const prevEndDate = prevWeekDates.end.toISOString().split('T')[0];

                    db.get(
                        `SELECT SUM(total_amount) as prev_revenue FROM transactions WHERE DATE(created_at) BETWEEN ? AND ? AND status = 'completed'`,
                        [prevStartDate, prevEndDate],
                        (prevErr, prevRow) => {
                            if (prevErr) console.error('查詢前一週數據錯誤:', prevErr);

                            const prevRevenue = prevRow?.prev_revenue || 0;
                            const revenueChange = prevRevenue > 0
                                ? ((weekSummary.total_revenue || 0) - prevRevenue) / prevRevenue * 100
                                : 0;

                            res.json({
                                success: true,
                                data: {
                                    period: {
                                        year: targetYear,
                                        week: targetWeek,
                                        start_date: startDate,
                                        end_date: endDate,
                                        week_dates: dailyRevenue.map(d => d.date)
                                    },
                                    summary: weekSummary,
                                    daily_revenue: dailyRevenue,
                                    top_products: topProducts || [],
                                    employee_performance: employees || [],
                                    comparison: {
                                        previous_week_revenue: prevRevenue,
                                        revenue_change_percent: revenueChange,
                                        week_over_week_growth: revenueChange
                                    },
                                    metadata: {
                                        report_generated_at: new Date().toISOString(),
                                        report_type: 'weekly',
                                        data_range: `${startDate} 至 ${endDate}`
                                    }
                                }
                            });
                        }
                    );
                });
            });
        });
    } catch (error) {
        console.error('生成週報表錯誤:', error);
        res.status(500).json({
            success: false,
            error: '生成週報表失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/reports/monthly
 * @desc 獲取月報表
 * @access Private/Staff
 */
router.get('/monthly', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { year, month } = req.query;

        const now = new Date();
        const targetYear = year || now.getFullYear();
        const targetMonth = month || now.getMonth() + 1;

        const startDate = `${targetYear}-${String(targetMonth).padStart(2, '0')}-01`;
        const endDate = new Date(targetYear, targetMonth, 0).toISOString().split('T')[0];

        // 月營業額總計
        const revenueQuery = `
            SELECT
                DATE(entry_time) as date,
                COUNT(DISTINCT id) as unique_customers,
                COUNT(*) as total_transactions,
                SUM(total_amount) as total_revenue,
                AVG(total_amount) as average_order_value
            FROM customers
            WHERE DATE(entry_time) BETWEEN ? AND ? AND is_checked_out = 1
            GROUP BY DATE(entry_time)
            ORDER BY date
        `;

        // 月商品銷售排行
        const productsQuery = `
            SELECT
                p.id,
                p.name,
                p.category,
                SUM(oi.quantity) as total_quantity,
                SUM(oi.subtotal) as total_revenue,
                COUNT(DISTINCT oi.order_id) as order_count,
                (SUM(oi.subtotal) / ?) as revenue_per_day
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            JOIN transactions t ON oi.order_id = t.id
            WHERE DATE(t.created_at) BETWEEN ? AND ?
            GROUP BY p.id
            ORDER BY total_revenue DESC
            LIMIT 20
        `;

        // 月員工績效
        const employeesQuery = `
            SELECT
                e.id,
                e.username,
                e.full_name,
                COUNT(t.id) as transaction_count,
                SUM(t.total_amount) as total_revenue,
                AVG(t.total_amount) as avg_order_value,
                COUNT(DISTINCT DATE(t.created_at)) as active_days,
                (SUM(t.total_amount) / ?) as revenue_per_day
            FROM transactions t
            LEFT JOIN employees e ON t.employee_id = e.id
            WHERE DATE(t.created_at) BETWEEN ? AND ?
            GROUP BY e.id
            ORDER BY total_revenue DESC
        `;

        // 計算月份天數
        const daysInMonth = new Date(targetYear, targetMonth, 0).getDate();

        db.all(revenueQuery, [startDate, endDate], (revenueErr, dailyRevenue) => {
            if (revenueErr) {
                console.error('查詢月營業額錯誤:', revenueErr);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: revenueErr.message
                });
            }

            // 計算月總計
            const monthSummary = dailyRevenue.reduce((acc, day) => ({
                unique_customers: acc.unique_customers + (day.unique_customers || 0),
                total_transactions: acc.total_transactions + (day.total_transactions || 0),
                total_revenue: acc.total_revenue + (day.total_revenue || 0),
                days_count: acc.days_count + 1
            }), { unique_customers: 0, total_transactions: 0, total_revenue: 0, days_count: 0 });

            monthSummary.average_order_value = monthSummary.total_transactions > 0
                ? monthSummary.total_revenue / monthSummary.total_transactions
                : 0;
            monthSummary.average_daily_revenue = monthSummary.days_count > 0
                ? monthSummary.total_revenue / monthSummary.days_count
                : 0;
            monthSummary.average_daily_customers = monthSummary.days_count > 0
                ? monthSummary.unique_customers / monthSummary.days_count
                : 0;

            db.all(productsQuery, [daysInMonth, startDate, endDate], (productsErr, topProducts) => {
                if (productsErr) {
                    console.error('查詢月商品銷售錯誤:', productsErr);
                }

                db.all(employeesQuery, [daysInMonth, startDate, endDate], (employeesErr, employees) => {
                    if (employeesErr) {
                        console.error('查詢月員工績效錯誤:', employeesErr);
                    }

                    // 獲取前一個月數據比較
                    const prevMonthDate = new Date(targetYear, targetMonth - 2, 1);
                    const prevStartDate = prevMonthDate.toISOString().split('T')[0].substring(0, 7) + '-01';
                    const prevEndDate = new Date(targetYear, targetMonth - 1, 0).toISOString().split('T')[0];

                    db.get(
                        `SELECT SUM(total_amount) as prev_revenue FROM transactions WHERE DATE(created_at) BETWEEN ? AND ? AND status = 'completed'`,
                        [prevStartDate, prevEndDate],
                        (prevErr, prevRow) => {
                            if (prevErr) console.error('查詢前一個月數據錯誤:', prevErr);

                            const prevRevenue = prevRow?.prev_revenue || 0;
                            const revenueChange = prevRevenue > 0
                                ? ((monthSummary.total_revenue || 0) - prevRevenue) / prevRevenue * 100
                                : 0;

                            // 計算月度趨勢（按週）
                            const weeklyTrendQuery = `
                                SELECT
                                    strftime('%W', created_at) as week_number,
                                    COUNT(*) as transaction_count,
                                    SUM(total_amount) as weekly_revenue,
                                    AVG(total_amount) as avg_order_value
                                FROM transactions
                                WHERE DATE(created_at) BETWEEN ? AND ?                                GROUP BY strftime('%W', created_at)
                                ORDER BY week_number
                            `;

                            db.all(weeklyTrendQuery, [startDate, endDate], (trendErr, weeklyTrend) => {
                                if (trendErr) console.error('查詢月度趨勢錯誤:', trendErr);

                                res.json({
                                    success: true,
                                    data: {
                                        period: {
                                            year: targetYear,
                                            month: targetMonth,
                                            start_date: startDate,
                                            end_date: endDate,
                                            days_in_month: daysInMonth,
                                            business_days: monthSummary.days_count
                                        },
                                        summary: monthSummary,
                                        daily_revenue: dailyRevenue,
                                        top_products: topProducts || [],
                                        employee_performance: employees || [],
                                        weekly_trend: weeklyTrend || [],
                                        comparison: {
                                            previous_month_revenue: prevRevenue,
                                            revenue_change_percent: revenueChange,
                                            month_over_month_growth: revenueChange
                                        },
                                        metadata: {
                                            report_generated_at: new Date().toISOString(),
                                            report_type: 'monthly',
                                            data_range: `${startDate} 至 ${endDate}`
                                        }
                                    }
                                });
                            });
                        }
                    );
                });
            });
        });
    } catch (error) {
        console.error('生成月報表錯誤:', error);
        res.status(500).json({
            success: false,
            error: '生成月報表失敗',
            message: error.message
        });
    }
});

/**
 * @route POST /api/reports/custom
 * @desc 生成自定義報告
 * @access Private/Staff
 */
router.post('/custom', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const {
            report_type,
            start_date,
            end_date,
            metrics = ['revenue', 'transactions', 'customers'],
            view_type = 'summary',  // 'summary', 'products', 'hourly_customers'
            filters = {}
        } = req.body;

        const { employee } = req;

        if (!start_date || !end_date) {
            return res.status(400).json({
                success: false,
                error: '缺少必要字段',
                message: '請提供開始日期和結束日期'
            });
        }

        // 驗證日期格式
        const startDateObj = new Date(start_date);
        const endDateObj = new Date(end_date);

        if (isNaN(startDateObj.getTime()) || isNaN(endDateObj.getTime())) {
            return res.status(400).json({
                success: false,
                error: '無效的日期格式',
                message: '請提供有效的日期格式 (YYYY-MM-DD)'
            });
        }

        if (startDateObj > endDateObj) {
            return res.status(400).json({
                success: false,
                error: '無效的日期範圍',
                message: '開始日期不能晚於結束日期'
            });
        }

        // 限制查詢範圍（最大90天）
        const maxDays = 90;
        const daysDiff = Math.ceil((endDateObj - startDateObj) / (1000 * 60 * 60 * 24));
        if (daysDiff > maxDays) {
            return res.status(400).json({
                success: false,
                error: '日期範圍過大',
                message: `自定義報告最多支持 ${maxDays} 天的數據查詢`
            });
        }

        // 根據視圖類型處理不同的查詢邏輯
        if (view_type === 'products') {
            // 商品詳情視圖：返回商品銷售數據
            return handleProductsView(start_date, end_date, employee, req, res, filters);
        } else if (view_type === 'hourly_customers') {
            // 人數統計視圖：返回每小時結賬客人統計
            return handleHourlyCustomersView(start_date, end_date, employee, req, res, filters);
        } else if (view_type === 'checkout_receipts') {
            // 結賬單據視圖：返回所有結賬記錄
            return handleCheckoutReceiptsView(start_date, end_date, employee, req, res, filters);
        }

        // 默認：銷售總覽視圖（原有邏輯）
        // 基礎查詢 - 使用customers表，只查詢已結賬的客人
        // 使用香港時間（+8 hours），確保香港時區
        let baseQuery = `
            FROM customers c
            WHERE c.is_checked_out = 1 AND COALESCE(c.is_reversed, 0) = 0 AND strftime('%Y-%m-%d', c.checkout_time, '+8 hours') BETWEEN ? AND ?
        `;

        const queryParams = [start_date, end_date];

        // 應用篩選條件
        // 注意：customers表沒有employee_id和payment_method字段
        // if (filters.employee_id) {
        //     baseQuery += ` AND t.employee_id = ?`;
        //     queryParams.push(filters.employee_id);
        // }
        //
        // if (filters.payment_method) {
        //     baseQuery += ` AND t.payment_method = ?`;
        //     queryParams.push(filters.payment_method);
        // }

        // 分店篩選
        if (filters.store_id) {
            baseQuery += ` AND c.store_id = ?`;
            queryParams.push(filters.store_id);
        }

        if (filters.min_amount) {
            baseQuery += ` AND c.total_amount >= ?`;
            queryParams.push(filters.min_amount);
        }

        if (filters.max_amount) {
            baseQuery += ` AND c.total_amount <= ?`;
            queryParams.push(filters.max_amount);
        }

        // 根據請求的指標構建查詢
        const selectColumns = [];

        if (metrics.includes('revenue')) {
            selectColumns.push('SUM(c.total_amount) as total_revenue');
            selectColumns.push('AVG(c.total_amount) as avg_order_value');
            selectColumns.push('MIN(c.total_amount) as min_order_value');
            selectColumns.push('MAX(c.total_amount) as max_order_value');
        }

        if (metrics.includes('transactions')) {
            selectColumns.push('COUNT(c.id) as transaction_count');
            selectColumns.push('COUNT(DISTINCT strftime(\'%Y-%m-%d\', c.checkout_time, \'+8 hours\')) as business_days');
        }

        if (metrics.includes('customers')) {
            selectColumns.push('COALESCE(SUM(c.people_count), 0) as unique_customers');
        }

        // customers表沒有employee_id字段，所以跳過employees指標
        // if (metrics.includes('employees')) {
        //     selectColumns.push('COUNT(DISTINCT t.employee_id) as active_employees');
        // }

        if (selectColumns.length === 0) {
            return res.status(400).json({
                success: false,
                error: '無效的指標',
                message: '請至少選擇一個報告指標'
            });
        }

        const summaryQuery = `SELECT ${selectColumns.join(', ')} ${baseQuery}`;

        db.get(summaryQuery, queryParams, (summaryErr, summary) => {
            if (summaryErr) {
                console.error('查詢自定義報告摘要錯誤:', summaryErr);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: summaryErr.message
                });
            }

            // 獲取每日數據
            const dailyQuery = `
                SELECT
                    strftime('%Y-%m-%d', c.checkout_time, '+8 hours') as date,
                    COUNT(c.id) as transaction_count,
                    SUM(c.total_amount) as daily_revenue,
                    AVG(c.total_amount) as avg_order_value,
                    COALESCE(SUM(c.people_count), 0) as daily_customers
                ${baseQuery}
                GROUP BY strftime('%Y-%m-%d', c.checkout_time, '+8 hours')
                ORDER BY date
            `;

            db.all(dailyQuery, queryParams, (dailyErr, dailyData) => {
                if (dailyErr) {
                    console.error('查詢每日數據錯誤:', dailyErr);
                    // 繼續處理，不中斷
                }

                // 獲取商品銷售數據
                let productsData = [];
                if (metrics.includes('products')) {
                    const productsQuery = `
                        SELECT
                            p.id,
                            p.name,
                            p.category,
                            SUM(oi.quantity) as total_quantity,
                            SUM(oi.quantity * oi.price_at_time) as total_revenue,
                            COUNT(DISTINCT oi.customer_id) as order_count
                        FROM order_items oi
                        JOIN products p ON oi.product_id = p.id
                        JOIN customers c ON oi.customer_id = c.id
                        WHERE c.is_checked_out = 1 AND COALESCE(c.is_reversed, 0) = 0 AND strftime('%Y-%m-%d', c.checkout_time, '+8 hours') BETWEEN ? AND ?
                        GROUP BY p.id
                        ORDER BY total_revenue DESC
                        LIMIT 15
                    `;

                    db.all(productsQuery, [start_date, end_date], (productsErr, products) => {
                        if (productsErr) {
                            console.error('查詢商品銷售錯誤:', productsErr);
                        }
                        productsData = products || [];

                        sendResponse();
                    });
                } else {
                    sendResponse();
                }

                function sendResponse() {
                    // 創建報告記錄
                    const reportId = uuidv4();
                    const reportData = {
                        report_id: reportId,
                        report_type: report_type || 'custom',
                        generated_by: employee.id,
                        generation_date: new Date().toISOString(),
                        parameters: {
                            start_date,
                            end_date,
                            metrics,
                            filters
                        },
                        summary,
                        daily_data: dailyData || [],
                        products_data: productsData
                    };

                    // 保存報告到數據庫（可選）
                    const saveReportQuery = `
                        INSERT INTO reports (id, report_type, report_date, data, generated_by)
                        VALUES (?, ?, ?, ?, ?)
                    `;

                    db.run(
                        saveReportQuery,
                        [
                            reportId,
                            report_type || 'custom',
                            new Date().toISOString(),
                            JSON.stringify(reportData),
                            employee.id
                        ],
                        (saveErr) => {
                            if (saveErr) {
                                console.error('保存報告記錄錯誤:', saveErr);
                                // 繼續返回報告，不中斷
                            }

                            // 創建審計日誌
                            authMiddleware.createAuditLog(
                                employee.id,
                                'report_generated',
                                `生成自定義報告: ${report_type || 'custom'} (${start_date} 至 ${end_date})`,
                                req.ip || req.connection.remoteAddress
                            );

                            res.json({
                                success: true,
                                data: reportData,
                                metadata: {
                                    report_id: reportId,
                                    generated_at: new Date().toISOString(),
                                    data_points: {
                                        days: dailyData ? dailyData.length : 0,
                                        products: productsData.length,
                                        metrics_included: metrics.length
                                    }
                                }
                            });
                        }
                    );
                }
            });
        });
    } catch (error) {
        console.error('生成自定義報告錯誤:', error);
        res.status(500).json({
            success: false,
            error: '生成自定義報告失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/reports/history
 * @desc 獲取報告歷史記錄
 * @access Private/Staff
 */
router.get('/history', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const {
            report_type,
            generated_by,
            start_date,
            end_date,
            page = 1,
            limit = 20
        } = req.query;

        let query = `
            SELECT r.*,
                   e.username as generated_by_username,
                   e.full_name as generated_by_name
            FROM reports r
            LEFT JOIN employees e ON r.generated_by = e.id
            WHERE 1=1
        `;

        const params = [];

        if (report_type) {
            query += ` AND r.report_type = ?`;
            params.push(report_type);
        }

        if (generated_by) {
            query += ` AND r.generated_by = ?`;
            params.push(generated_by);
        }

        if (start_date) {
            query += ` AND r.report_date >= ?`;
            params.push(start_date);
        }

        if (end_date) {
            query += ` AND r.report_date <= ?`;
            params.push(end_date);
        }

        query += ` ORDER BY r.report_date DESC`;

        // 獲取總數（regex 跨行匹配；原先單行 replace 對多行 template 唔生效，
        // 令 countQuery 等於完整 SELECT → 空表時 countRow 為 undefined → countRow.total 拋 TypeError）
        const countQuery = query.replace(/SELECT[\s\S]*?FROM reports r/, 'SELECT COUNT(*) as total FROM reports r');

        db.get(countQuery, params, (countErr, countRow) => {
            if (countErr) {
                console.error('查詢報告歷史總數錯誤:', countErr);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: countErr.message
                });
            }

            const total = countRow.total || 0;
            const totalPages = Math.ceil(total / limit);
            const offset = (page - 1) * limit;

            // 添加分頁
            query += ` LIMIT ? OFFSET ?`;
            params.push(limit, offset);

            db.all(query, params, (err, reports) => {
                if (err) {
                    console.error('查詢報告歷史錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                // 解析報告數據
                const parsedReports = reports.map(report => ({
                    id: report.id,
                    report_type: report.report_type,
                    report_date: report.report_date,
                    generated_by: {
                        id: report.generated_by,
                        username: report.generated_by_username,
                        name: report.generated_by_name
                    },
                    data_preview: report.data ? JSON.parse(report.data) : null,
                    created_at: report.created_at
                }));

                res.json({
                    success: true,
                    data: {
                        reports: parsedReports,
                        pagination: {
                            total,
                            total_pages: totalPages,
                            current_page: parseInt(page),
                            page_size: parseInt(limit),
                            has_next: page < totalPages,
                            has_prev: page > 1
                        },
                        summary: {
                            total_reports: total,
                            report_types: reports.reduce((acc, report) => {
                                acc[report.report_type] = (acc[report.report_type] || 0) + 1;
                                return acc;
                            }, {})
                        }
                    }
                });
            });
        });
    } catch (error) {
        console.error('獲取報告歷史錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取報告歷史失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/reports/export/:id
 * @desc 導出報告數據（JSON格式）
 * @access Private/Staff
 */
router.get('/export/:id', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { id } = req.params;
        const { format = 'json' } = req.query;

        db.get(
            `SELECT * FROM reports WHERE id = ?`,
            [id],
            (err, report) => {
                if (err) {
                    console.error('查詢報告錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                if (!report) {
                    return res.status(404).json({
                        success: false,
                        error: '報告不存在',
                        message: '指定的報告不存在或已被刪除'
                    });
                }

                // 創建審計日誌
                const { employee } = req;
                authMiddleware.createAuditLog(
                    employee.id,
                    'report_exported',
                    `導出報告: ${report.report_type} (ID: ${id})`,
                    req.ip || req.connection.remoteAddress
                );

                if (format === 'json') {
                    res.json({
                        success: true,
                        data: report.data ? JSON.parse(report.data) : null,
                        metadata: {
                            report_id: report.id,
                            report_type: report.report_type,
                            generated_at: report.report_date,
                            exported_at: new Date().toISOString(),
                            format: 'json'
                        }
                    });
                } else {
                    res.status(400).json({
                        success: false,
                        error: '不支持的格式',
                        message: `目前僅支持 JSON 格式導出`
                    });
                }
            }
        );
    } catch (error) {
        console.error('導出報告錯誤:', error);
        res.status(500).json({
            success: false,
            error: '導出報告失敗',
            message: error.message
        });
    }
});

// 工具函數：獲取週數
function getWeekNumber(date) {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    const dayNum = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - dayNum);
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    return Math.ceil(((d - yearStart) / 86400000 + 1) / 7);
}

// 工具函數：獲取指定年週的開始和結束日期
function getWeekDates(year, week) {
    const simple = new Date(year, 0, 1 + (week - 1) * 7);
    const dayOfWeek = simple.getDay();
    const start = new Date(simple);
    start.setDate(simple.getDate() - (dayOfWeek <= 0 ? -6 : dayOfWeek - 1));
    const end = new Date(start);
    end.setDate(start.getDate() + 6);

    // 設置時間為當天開始和結束
    start.setHours(0, 0, 0, 0);
    end.setHours(23, 59, 59, 999);

    return { start, end };
}

// 處理商品詳情視圖
function handleProductsView(start_date, end_date, employee, req, res, filters = {}) {
    try {
        // 使用文件作用域已導入的模塊

        // 構建查詢條件和參數
        let whereConditions = `c.is_checked_out = 1
                AND COALESCE(c.is_reversed, 0) = 0
                AND strftime('%Y-%m-%d', c.checkout_time, '+8 hours') BETWEEN ? AND ?`;
        const queryParams = [start_date, end_date];

        // 分店篩選
        if (filters.store_id) {
            whereConditions += ` AND c.store_id = ?`;
            queryParams.push(filters.store_id);
        }

        // 查詢商品銷售數據
        // 構建子查詢條件（將c.替換為c2.）
        let subQueryWhereConditions = whereConditions.replace(/c\./g, 'c2.');

        const productsQuery = `
            SELECT
                p.id,
                p.name,
                p.category,
                p.price,
                SUM(oi.quantity) as total_quantity,
                SUM(oi.quantity * oi.price_at_time) as total_revenue,
                (
                    SELECT COALESCE(SUM(c2.people_count), 0)
                    FROM customers c2
                    WHERE c2.id IN (
                        SELECT DISTINCT oi2.customer_id
                        FROM order_items oi2
                        WHERE oi2.product_id = p.id
                    )
                    AND ${subQueryWhereConditions}
                ) as customer_count,
                COUNT(DISTINCT strftime('%Y-%m-%d', c.checkout_time, '+8 hours')) as days_sold
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            JOIN customers c ON oi.customer_id = c.id
            WHERE ${whereConditions}
            GROUP BY p.id
            ORDER BY total_quantity DESC
        `;

        // 查詢需要兩組參數：主查詢一組，子查詢一組
        const allQueryParams = queryParams.concat(queryParams);
        db.all(productsQuery, allQueryParams, (err, products) => {
            if (err) {
                console.error('查詢商品銷售數據錯誤:', err);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: err.message
                });
            }

            // 計算總計
            const totals = products.reduce((acc, product) => ({
                total_quantity: acc.total_quantity + (product.total_quantity || 0),
                total_revenue: acc.total_revenue + (product.total_revenue || 0),
                total_products: acc.total_products + 1
            }), { total_quantity: 0, total_revenue: 0, total_products: 0 });

            // 創建報告記錄
            const reportId = uuidv4();
            const reportData = {
                report_id: reportId,
                report_type: 'products_view',
                generated_by: employee.id,
                generation_date: new Date().toISOString(),
                parameters: {
                    start_date,
                    end_date,
                    view_type: 'products'
                },
                summary: totals,
                products: products || [],
                metadata: {
                    report_generated_at: new Date().toISOString(),
                    data_points: {
                        products: products.length,
                        days: Math.ceil((new Date(end_date) - new Date(start_date)) / (1000 * 60 * 60 * 24)) + 1
                    }
                }
            };

            // 保存報告到數據庫（可選）
            const saveReportQuery = `
                INSERT INTO reports (id, report_type, report_date, data, generated_by)
                VALUES (?, ?, ?, ?, ?)
            `;

            db.run(
                saveReportQuery,
                [
                    reportId,
                    'products_view',
                    new Date().toISOString(),
                    JSON.stringify(reportData),
                    employee.id
                ],
                (saveErr) => {
                    if (saveErr) console.error('保存報告記錄錯誤:', saveErr);

                    // 創建審計日誌
                    authMiddleware.createAuditLog(
                        employee.id,
                        'report_generated',
                        `生成商品詳情報告: ${start_date} 至 ${end_date}`,
                        req.ip || req.connection.remoteAddress
                    );

                    res.json({
                        success: true,
                        data: reportData,
                        metadata: {
                            report_id: reportId,
                            generated_at: new Date().toISOString(),
                            view_type: 'products'
                        }
                    });
                }
            );
        });
    } catch (error) {
        console.error('處理商品詳情視圖錯誤:', error);
        res.status(500).json({
            success: false,
            error: '生成商品詳情報告失敗',
            message: error.message
        });
    }
}

// 處理每小時客人統計視圖
function handleHourlyCustomersView(start_date, end_date, employee, req, res, filters = {}) {
    try {
        // 使用文件作用域已導入的模塊

        // 構建查詢條件和參數
        let whereConditions = `is_checked_out = 1
                AND COALESCE(is_reversed, 0) = 0
                AND strftime('%Y-%m-%d', checkout_time, '+8 hours') BETWEEN ? AND ?`;
        const queryParams = [start_date, end_date];

        // 分店篩選
        if (filters.store_id) {
            whereConditions += ` AND store_id = ?`;
            queryParams.push(filters.store_id);
        }

        // 查詢每小時結賬客人統計
        // 使用 '+8 hours' 將UTC時間轉換為香港時間 (UTC+8)
        const hourlyQuery = `
            SELECT
                strftime('%Y-%m-%d', checkout_time, '+8 hours') as date,
                strftime('%H', checkout_time, '+8 hours') as hour,
                SUM(people_count) as customer_count,
                SUM(total_amount) as total_revenue,
                AVG(total_amount) as avg_checkout
            FROM customers
            WHERE ${whereConditions}
            GROUP BY strftime('%Y-%m-%d', checkout_time, '+8 hours'), strftime('%H', checkout_time, '+8 hours')
            ORDER BY date, hour
        `;

        db.all(hourlyQuery, queryParams, (err, hourlyData) => {
            if (err) {
                console.error('查詢每小時客人統計錯誤:', err);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: err.message
                });
            }

            // 按日期分組，方便前端顯示
            const groupedByDate = {};
            hourlyData.forEach(record => {
                if (!groupedByDate[record.date]) {
                    groupedByDate[record.date] = [];
                }
                groupedByDate[record.date].push({
                    hour: record.hour,
                    customer_count: record.customer_count,
                    total_revenue: record.total_revenue,
                    avg_checkout: record.avg_checkout
                });
            });

            // 計算總計
            const totals = hourlyData.reduce((acc, record) => ({
                total_customers: acc.total_customers + (record.customer_count || 0),
                total_revenue: acc.total_revenue + (record.total_revenue || 0),
                hour_count: acc.hour_count + 1
            }), { total_customers: 0, total_revenue: 0, hour_count: 0 });

            // 創建報告記錄
            const reportId = uuidv4();
            const reportData = {
                report_id: reportId,
                report_type: 'hourly_customers_view',
                generated_by: employee.id,
                generation_date: new Date().toISOString(),
                parameters: {
                    start_date,
                    end_date,
                    view_type: 'hourly_customers'
                },
                summary: totals,
                hourly_data: hourlyData,
                grouped_by_date: groupedByDate,
                metadata: {
                    report_generated_at: new Date().toISOString(),
                    data_points: {
                        hours: hourlyData.length,
                        unique_dates: Object.keys(groupedByDate).length
                    }
                }
            };

            // 保存報告到數據庫（可選）
            const saveReportQuery = `
                INSERT INTO reports (id, report_type, report_date, data, generated_by)
                VALUES (?, ?, ?, ?, ?)
            `;

            db.run(
                saveReportQuery,
                [
                    reportId,
                    'hourly_customers_view',
                    new Date().toISOString(),
                    JSON.stringify(reportData),
                    employee.id
                ],
                (saveErr) => {
                    if (saveErr) console.error('保存報告記錄錯誤:', saveErr);

                    // 創建審計日誌
                    authMiddleware.createAuditLog(
                        employee.id,
                        'report_generated',
                        `生成每小時客人統計報告: ${start_date} 至 ${end_date}`,
                        req.ip || req.connection.remoteAddress
                    );

                    res.json({
                        success: true,
                        data: reportData,
                        metadata: {
                            report_id: reportId,
                            generated_at: new Date().toISOString(),
                            view_type: 'hourly_customers'
                        }
                    });
                }
            );
        });
    } catch (error) {
        console.error('處理每小時客人統計視圖錯誤:', error);
        res.status(500).json({
            success: false,
            error: '生成每小時客人統計報告失敗',
            message: error.message
        });
    }
}

// 處理結賬單據視圖
function handleCheckoutReceiptsView(start_date, end_date, employee, req, res, filters = {}) {
    try {
        // 構建查詢條件
        let whereConditions = `c.is_checked_out = 1
                AND COALESCE(c.is_reversed, 0) = 0
                AND strftime('%Y-%m-%d', c.checkout_time, '+8 hours') BETWEEN ? AND ?`;
        const queryParams = [start_date, end_date];

        // 分店篩選
        if (filters.store_id) {
            whereConditions += ` AND c.store_id = ?`;
            queryParams.push(filters.store_id);
        }

        // 查詢結賬單據（含商品列表）
        const query = `
            SELECT
                c.id,
                c.store_id,
                c.table_number,
                c.people_count,
                c.entry_time,
                c.checkout_time,
                c.total_amount,
                c.is_member,
                c.qr_code,
                COALESCE(c.lockers_used, '無') as lockers,
                COALESCE(c.is_reversed, 0) as is_reversed,
                c.reverse_employee_name,
                COALESCE((
                    SELECT GROUP_CONCAT(product_name, ', ')
                    FROM (
                        SELECT p.name || ' ×' || SUM(oi.quantity) as product_name
                        FROM order_items oi
                        JOIN products p ON oi.product_id = p.id
                        WHERE oi.customer_id = c.id
                        GROUP BY oi.product_id
                    )
                ), '無') as products,
                COALESCE((
                    SELECT GROUP_CONCAT(product_name, ', ')
                    FROM (
                        SELECT p.name || ' ×' || SUM(oi.quantity) as product_name
                        FROM order_items oi
                        JOIN products p ON oi.product_id = p.id
                        WHERE oi.customer_id = c.id AND COALESCE(oi.is_reversed, 0) = 1
                        GROUP BY oi.product_id
                    )
                ), '') as reversed_products
            FROM customers c
            WHERE ${whereConditions}
            ORDER BY c.checkout_time DESC
            LIMIT 500
        `;

        db.all(query, queryParams, (err, receipts) => {
            if (err) {
                console.error('查詢結賬單據錯誤:', err);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: err.message
                });
            }

            // 計算總計
            const totals = receipts.reduce((acc, r) => ({
                total_revenue: acc.total_revenue + (r.total_amount || 0),
                total_checkouts: acc.total_checkouts + 1,
                total_people: acc.total_people + (r.people_count || 0)
            }), { total_revenue: 0, total_checkouts: 0, total_people: 0 });

            // 創建報告記錄
            const reportId = uuidv4();
            const reportData = {
                report_id: reportId,
                report_type: 'checkout_receipts_view',
                generated_by: employee.id,
                generation_date: new Date().toISOString(),
                parameters: {
                    start_date,
                    end_date,
                    view_type: 'checkout_receipts'
                },
                summary: totals,
                checkout_receipts: receipts || [],
                metadata: {
                    report_generated_at: new Date().toISOString(),
                    data_points: {
                        receipts: receipts.length,
                        days: Math.ceil((new Date(end_date) - new Date(start_date)) / (1000 * 60 * 60 * 24)) + 1
                    }
                }
            };

            // 保存報告到數據庫
            const saveReportQuery = `
                INSERT INTO reports (id, report_type, report_date, data, generated_by)
                VALUES (?, ?, ?, ?, ?)
            `;

            db.run(
                saveReportQuery,
                [
                    reportId,
                    'checkout_receipts_view',
                    new Date().toISOString(),
                    JSON.stringify(reportData),
                    employee.id
                ],
                (saveErr) => {
                    if (saveErr) console.error('保存報告記錄錯誤:', saveErr);

                    authMiddleware.createAuditLog(
                        employee.id,
                        'report_generated',
                        `生成結賬單據報告: ${start_date} 至 ${end_date}`,
                        req.ip || req.connection.remoteAddress
                    );

                    res.json({
                        success: true,
                        data: reportData,
                        metadata: {
                            report_id: reportId,
                            generated_at: new Date().toISOString(),
                            view_type: 'checkout_receipts'
                        }
                    });
                }
            );
        });
    } catch (error) {
        console.error('處理結賬單據視圖錯誤:', error);
        res.status(500).json({
            success: false,
            error: '生成結賬單據報告失敗',
            message: error.message
        });
    }
}

module.exports = router;