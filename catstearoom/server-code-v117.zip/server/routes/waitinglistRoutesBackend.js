const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');
const { sendWhatsApp, makePhoneCall } = require('../services/twilioService');

// 阿里雲 forward helper：當本地搵唔到 record 時 proxy 去阿里雲
const ALIYUN_SERVER = (process.env.ALIYUN_SERVER || 'http://47.239.121.13:3000').replace(/\/$/, '');
const API_KEY = process.env.ALIYUN_API_KEY || process.env.MAIN_API_KEY || '';
const FETCH_TIMEOUT_MS = parseInt(process.env.ALIYUN_PROXY_TIMEOUT || '8000', 10);

function forwardToAliyun(method, endpoint, body) {
    const url = `${ALIYUN_SERVER}${endpoint}`;
    const opts = {
        method,
        headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY }
    };
    if (body) opts.body = JSON.stringify(body);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    opts.signal = controller.signal;
    return fetch(url, opts).then(r => {
        clearTimeout(timer);
        return r.json();
    }).catch(e => {
        clearTimeout(timer);
        throw e;
    });
}

// 只有香港電話先致電：非香港電話（+886/+86/+1 等）唔打 twilio 語音
function isHKPhone(phone) {
    const p = String(phone || '');
    const m = p.match(/^\+(\d{1,3})/);
    if (m) return m[1] === '852';
    return true; // 冇 + 前綴 → 當香港電話（852 預設）
}

/**
 * @route POST /api/waitinglist
 * @desc 新增候位（公開）
 * @access Public
 */
router.post('/', (req, res) => {
    try {
        const { id: explicitId, store_id, adults, children, phone, notes, lang } = req.body;

        if (!store_id) {
            return res.status(400).json({ success: false, error: '缺少必要欄位', message: '請選擇分店' });
        }

        const adultCount = parseInt(adults) || 2;
        const childCount = parseInt(children) || 0;

        // 員工新增候位（經本地 proxy 注入 _staff）豁免 12 人上限；一般候位維持 1-12 人限制
        const isStaffBooking = req.body._staff === true || req.body._staff === 'true';
        if (isStaffBooking) {
            if (adultCount < 1) {
                return res.status(400).json({ success: false, error: '人數超出範圍', message: '大人人數需為至少 1 人' });
            }
            if (childCount < 0) {
                return res.status(400).json({ success: false, error: '人數超出範圍', message: '小朋友人數不能為負數' });
            }
        } else {
            if (adultCount < 1 || adultCount > 12) {
                return res.status(400).json({ success: false, error: '人數超出範圍', message: '大人人數需為 1-12 人' });
            }
            if (childCount < 0 || childCount > 8) {
                return res.status(400).json({ success: false, error: '人數超出範圍', message: '小朋友人數需為 0-8 人' });
            }
        }

        // 檢查兒童陪同比例（員工新增候位豁免，一般候位維持）
        const CHILD_RATIO = { store_1:2, store_3:2, store_2:1, store_4:1 };
        const ratio = CHILD_RATIO[store_id] || 2;
        const needed = Math.ceil(childCount / ratio);
        if (!isStaffBooking && childCount > 0 && adultCount < needed) {
            const STORE_NAMES = { store_1:'荃灣店', store_2:'尖沙咀店', store_3:'旺角店', store_4:'銅鑼灣店' };
            return res.status(400).json({
                success: false, error: '人數比例不符合要求',
                message: (STORE_NAMES[store_id]||'') + '每 ' + ratio + ' 位小朋友需要 1 位大人陪同，' + childCount + '位小朋友最少需要 ' + needed + ' 位大人'
            });
        }

        const id = explicitId || uuidv4();
        const now = new Date();
        // 香港時間 (UTC+8)
        const hkOffset = 8 * 60 * 60 * 1000;
        const hkNow = new Date(now.getTime() + hkOffset);
        const hkISO = hkNow.toISOString().replace('Z', '');
        const refNumber = 'W' + now.getFullYear() + String(now.getMonth()+1).padStart(2,'0') + String(now.getDate()).padStart(2,'0') + '-' + id.slice(0,4).toUpperCase();

        // 如果同一電話已有 active 候位，先取消舊記錄
        var cancelOld = function(callback) {
            db.run(
                `UPDATE waitinglist SET status = 'cancelled', updated_at = ? WHERE phone = ? AND status IN ('waiting', 'contacted', 'confirmed')`,
                [hkISO, phone],
                function(cancelErr) {
                    if (cancelErr) console.error('取消舊候位錯誤:', cancelErr);
                    callback();
                }
            );
        };

        cancelOld(function() {
            db.run(
                `INSERT OR IGNORE INTO waitinglist (id, store_id, adults, children, phone, notes, lang, status, ref_number, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 'waiting', ?, ?)`,
                [id, store_id, adultCount, childCount, phone, notes || '', lang || 'zh-TW', refNumber, hkISO],
            function(err) {
                if (err) {
                    console.error('建立候位錯誤:', err);
                    return res.status(500).json({ success: false, error: '建立候位失敗', message: err.message });
                }

                res.status(201).json({
                    success: true,
                    message: '候位成功',
                    data: { id, ref: refNumber, store_id, adults: adultCount, children: childCount, total_people: adultCount + childCount, phone }
                });
            }
        );
        });
    } catch (error) {
        console.error('候位錯誤:', error);
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route GET /api/waitinglist
 * @desc 查詢候位列表（員工權限）
 * @access Private/Staff
 */
router.get('/', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { store_id, status, date } = req.query;
        let query = `SELECT * FROM waitinglist WHERE 1=1`;
        const params = [];

        if (store_id) { query += ` AND store_id = ?`; params.push(store_id); }
        if (status) { query += ` AND status = ?`; params.push(status); }
        if (date) { query += ` AND substr(created_at, 1, 10) = ?`; params.push(date); }

        query += ` ORDER BY created_at DESC`;

        db.all(query, params, (err, rows) => {
            if (err) {
                return res.status(500).json({ success: false, error: '查詢錯誤', message: err.message });
            }
            res.json({ success: true, data: rows || [] });
        });
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route PATCH /api/waitinglist/:id
 * @desc 更新候位狀態（員工權限）
 * @access Private/Staff
 */
router.patch('/:id', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { id } = req.params;
        const { status, table_number } = req.body;
        const validStatuses = ['waiting', 'contacted', 'confirmed', 'arrived', 'cancelled'];

        if (!validStatuses.includes(status)) {
            return res.status(400).json({ success: false, error: '狀態值無效' });
        }

        db.get(`SELECT * FROM waitinglist WHERE id = ?`, [id], (err, item) => {
            if (err) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });

            if (!item) return res.status(404).json({ success: false, error: '找不到該候位記錄' });
            const hkUpdated = new Date(Date.now() + 8*60*60*1000).toISOString().replace('Z', '');
            var setClause = "status = ?";
            var params = [status];
            if (table_number) { setClause += ", table_number = ?"; params.push(table_number); }
            setClause += ", updated_at = ?";
            params.push(hkUpdated, id);
            db.run(`UPDATE waitinglist SET ${setClause} WHERE id = ?`, params, function(updateErr) {
                if (updateErr) return res.status(500).json({ success: false, error: '更新失敗', message: updateErr.message });
                res.json({ success: true, message: `狀態已更新為 ${status}` });
            });
        });
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route POST /api/waitinglist/:id/notify
 * @desc 致電客人：WhatsApp + 語音通話
 * @access Private/Staff
 */
router.post('/:id/notify', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { id } = req.params;

        db.get(`SELECT * FROM waitinglist WHERE id = ?`, [id], async (err, item) => {
            if (err) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });

            // 本地冇記錄 → forward 去阿里雲
            if (!item) {
                try {
                    const result = await forwardToAliyun('POST', `/api/waitinglist/${id}/notify`, null);
                    if (result && result.success) {
                        db.run(`UPDATE aliyun_waitinglist_cache SET status = 'contacted', updated_at = ? WHERE id = ?`, [new Date(Date.now() + 8*60*60*1000).toISOString().replace('Z', ''), id]);
                        db.run(`INSERT OR REPLACE INTO waitinglist (id, store_id, adults, children, phone, notes, lang, status, ref_number, created_at, updated_at) SELECT id, store_id, adults, children, phone, notes, lang, 'contacted', ref_number, created_at, ? FROM aliyun_waitinglist_cache WHERE id = ?`, [new Date(Date.now() + 8*60*60*1000).toISOString().replace('Z', ''), id]);
                        return res.json(result);
                    }
                } catch (e) {
                    return res.status(502).json({ success: false, error: '無法連線阿里雲', message: e.message });
                }
            }

            const storeNames = { 'store_1': '荃灣店', 'store_2': '尖沙咀店', 'store_3': '旺角店', 'store_4': '銅鑼灣店' };
            const storeName = storeNames[item.store_id] || item.store_id;
            const lang = item.lang || 'zh-TW';

            // 標記為已聯絡
            db.run(`UPDATE waitinglist SET status = 'contacted', updated_at = ? WHERE id = ?`,
                [new Date(Date.now() + 8*60*60*1000).toISOString().replace('Z', ''), id]);

            // 並行發送 WhatsApp + 打電話（非香港電話唔致電）
            const shouldCall = isHKPhone(item.phone);
            const results = await Promise.allSettled([
                sendWhatsApp(item.phone, item.store_id, storeName, lang, item.id),
                shouldCall ? makePhoneCall(item.phone, item.store_id, storeName, lang) : Promise.resolve(false)
            ]);

            console.log(`通知結果 - WhatsApp: ${results[0].status}, 語音: ${shouldCall ? results[1].status : 'skip(非香港)'}`);

            res.json({
                success: true,
                message: '已致電客人',
                data: {
                    whatsapp: results[0].status === 'fulfilled',
                    phoneCall: shouldCall && results[1].status === 'fulfilled'
                }
            });
        });
    } catch (error) {
        console.error('致電錯誤:', error);
        res.status(500).json({ success: false, error: '致電失敗', message: error.message });
    }
});

/**
 * @route POST /api/waitinglist/:id/call
 * @desc 再致電（只打電話，唔 send WhatsApp）
 * @access Private/Staff
 */
router.post('/:id/call', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { id } = req.params;
        db.get(`SELECT * FROM waitinglist WHERE id = ?`, [id], async (err, item) => {
            if (err) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });

            // 本地冇記錄 → forward 去阿里雲
            if (!item) {
                try {
                    const result = await forwardToAliyun('POST', `/api/waitinglist/${id}/call`, null);
                    if (result && result.success) {
                        db.run(`UPDATE aliyun_waitinglist_cache SET status = 'contacted', updated_at = ? WHERE id = ?`, [new Date(Date.now() + 8*60*60*1000).toISOString().replace('Z', ''), id]);
                        db.run(`INSERT OR REPLACE INTO waitinglist (id, store_id, adults, children, phone, notes, lang, status, ref_number, created_at, updated_at) SELECT id, store_id, adults, children, phone, notes, lang, 'contacted', ref_number, created_at, ? FROM aliyun_waitinglist_cache WHERE id = ?`, [new Date(Date.now() + 8*60*60*1000).toISOString().replace('Z', ''), id]);
                        return res.json(result);
                    }
                } catch (e) {
                    return res.status(502).json({ success: false, error: '無法連線阿里雲', message: e.message });
                }
            }

            const storeNames = { 'store_1': '荃灣店', 'store_2': '尖沙咀店', 'store_3': '旺角店', 'store_4': '銅鑼灣店' };
            const storeName = storeNames[item.store_id] || item.store_id;
            const lang = item.lang || 'zh-TW';

            // 更新 updated_at 等 timer 重新計
            db.run(`UPDATE waitinglist SET updated_at = ? WHERE id = ?`,
                [new Date(Date.now() + 8*60*60*1000).toISOString().replace('Z', ''), id]);

            // 只打電話（非香港電話唔致電）
            let phoneCall = false;
            if (isHKPhone(item.phone)) {
                await makePhoneCall(item.phone, item.store_id, storeName, lang).catch(e => e);
                phoneCall = true;
            } else {
                console.log(`非香港電話，跳過語音致電: ${item.phone}`);
            }

            res.json({
                success: true,
                message: '已再次致電客人',
                data: { phoneCall }
            });
        });
    } catch (error) {
        console.error('再致電錯誤:', error);
        res.status(500).json({ success: false, error: '再致電失敗', message: error.message });
    }
});

module.exports = router;
