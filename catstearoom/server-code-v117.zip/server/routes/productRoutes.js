const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');
const hongKongTime = require('../utils/hongKongTime');
const storeAwareMiddleware = require('../middleware/store-aware');
const runtime = require('../config/runtime');

/**
 * 檢查商品是否符合時間限制
 * @param {Object} product - 商品對象
 * @param {Date} now - 當前時間
 * @returns {boolean} 是否符合時間限制
 */
function checkTimeRestriction(product, now, isCustomHoliday = false) {
    // 如果沒有啟用時間限制，則始終可用
    if (!product.has_time_restriction || product.has_time_restriction !== 1) {
        return true;
    }

    // 轉換為香港時間
    const hkNow = hongKongTime.convertToHongKongTime(now);
    const currentDay = hongKongTime.getHongKongDayOfWeek(hkNow); // 0=星期日, 1=星期一, ..., 6=星期六
    const currentTime = hongKongTime.getHongKongTimeString(hkNow); // HH:MM格式

    // 判斷是否為節假日（星期六日或自定義節假日）
    const isHoliday = (currentDay === 0 || currentDay === 6) || isCustomHoliday; // 星期日或星期六或自定義節假日

    if (isHoliday) {
        // 檢查節假日時間範圍
        const checkTimeRange = (startTime, endTime) => {
            if (!startTime || !endTime) return false;
            return startTime <= currentTime && currentTime <= endTime;
        };

        // 檢查第一段時間範圍
        if (checkTimeRange(product.holiday_start_time, product.holiday_end_time)) {
            return true;
        }
        // 檢查第二段時間範圍
        if (checkTimeRange(product.holiday_start_time_2, product.holiday_end_time_2)) {
            return true;
        }
        return false;
    } else {
        // 檢查閒日時間範圍
        const checkTimeRange = (startTime, endTime) => {
            if (!startTime || !endTime) return false;
            return startTime <= currentTime && currentTime <= endTime;
        };

        // 檢查第一段時間範圍
        if (checkTimeRange(product.weekday_start_time, product.weekday_end_time)) {
            return true;
        }
        // 檢查第二段時間範圍
        if (checkTimeRange(product.weekday_start_time_2, product.weekday_end_time_2)) {
            return true;
        }
        return false;
    }
}

// 注意：storeAwareMiddleware.initStoreContext 現在在每個路由中單獨添加，
// 以確保在 authMiddleware.authenticate 之後執行

/**
 * @route GET /api/products
 * @desc 獲取所有商品（支持篩選、搜索、分頁）
 * @access Private/Staff
 */
router.get('/', authMiddleware.authenticate, storeAwareMiddleware.initStoreContext, authMiddleware.requireStaff, async (req, res) => {
    try {
        const storeId = req.storeContext?.store_id || 'default_store';
        const {
            search,
            category,
            is_available,
            min_stock,
            max_stock,
            sort_by = 'product_order',
            sort_order = 'asc',
            page = 1,
            page_size = 20,
            ignore_time_restriction = 'false'
        } = req.query;

        let query = `SELECT
            id, name, description, price, stock, locker_number,
            is_available, category, min_stock, supplier, cost_price,
            last_restocked, track_inventory, product_order, store_id, created_at,
            has_time_restriction, weekday_start_time, weekday_end_time,
            holiday_start_time, holiday_end_time, weekday_start_time_2, weekday_end_time_2,
            holiday_start_time_2, holiday_end_time_2
            FROM products WHERE 1=1 AND store_id = ?`;
        const params = [];
        params.push(storeId);

        // 添加篩選條件
        if (search) {
            query += ` AND (name LIKE ? OR description LIKE ?)`;
            const searchTerm = `%${search}%`;
            params.push(searchTerm, searchTerm);
        }

        if (category) {
            query += ` AND category = ?`;
            params.push(category);
        }

        if (is_available !== undefined) {
            query += ` AND is_available = ?`;
            params.push(is_available === 'true' ? 1 : 0);
        }

        if (min_stock !== undefined) {
            query += ` AND stock >= ?`;
            params.push(parseInt(min_stock));
        }

        if (max_stock !== undefined) {
            query += ` AND stock <= ?`;
            params.push(parseInt(max_stock));
        }

        // 默認只返回可用的商品
        if (is_available === undefined) {
            query += ` AND is_available = 1`;
        }

        // 注意：時間過濾將在獲取數據後在內存中進行，以便添加 is_time_available 字段
        // 使用香港時間（UTC+8）
        const hkTimeInfo = hongKongTime.getHongKongTimeInfo();
        const now = hkTimeInfo.date;
        const currentDay = hkTimeInfo.dayOfWeek; // 0=星期日, 1=星期一, ..., 6=星期六
        const currentTime = hkTimeInfo.timeString; // HH:MM格式
        const currentDate = hkTimeInfo.dateString; // YYYY-MM-DD格式（香港日期）

        // 檢查是否為自定義節假日
        let isCustomHoliday = false;
        try {
            const holidayCheck = await new Promise((resolve, reject) => {
                db.get(
                    `SELECT id FROM holidays WHERE date = ?`,
                    [currentDate],
                    (err, row) => {
                        if (err) reject(err);
                        else resolve(!!row);
                    }
                );
            });
            isCustomHoliday = holidayCheck;
        } catch (error) {
            console.error('查詢節假日錯誤:', error);
            // 錯誤時不影響主要功能，繼續處理
        }

        const isHoliday = currentDay === 0 || currentDay === 6 || isCustomHoliday; // 星期日或星期六或自定義節假日

        console.log('時間過濾調試:');
        console.log('  當前時間:', currentTime, '星期:', currentDay, '日期:', currentDate);
        console.log('  是否周末:', currentDay === 0 || currentDay === 6);
        console.log('  是否自定義節假日:', isCustomHoliday);
        console.log('  是否節假日:', isHoliday);
        console.log('  忽略時間限制:', ignore_time_restriction);

        // 添加排序
        const validSortColumns = ['name', 'price', 'stock', 'category', 'created_at', 'product_order'];
        const sortColumn = validSortColumns.includes(sort_by) ? sort_by : 'product_order';
        const validSortOrders = ['asc', 'desc'];
        const order = validSortOrders.includes(sort_order.toLowerCase()) ? sort_order.toUpperCase() : 'ASC';

        // 構建排序子句：主要按指定列排序，次要按product_order和name排序以確保一致性
        let orderClause = `${sortColumn} ${order}`;
        if (sortColumn !== 'product_order') {
            orderClause += `, product_order ASC`;
        }
        if (sortColumn !== 'name') {
            orderClause += `, name ASC`;
        }

        query += ` ORDER BY ${orderClause}`;

        // 獲取總數（用於分頁）
        // 從主查詢構建計數查詢，移除ORDER BY和LIMIT部分
        // 首先移除SELECT部分，替換為COUNT(*)
        let countQuery = query;

        // 移除ORDER BY子句及其後面的所有內容
        const orderByIndex = countQuery.indexOf('ORDER BY');
        if (orderByIndex !== -1) {
            countQuery = countQuery.substring(0, orderByIndex);
        }

        // 移除LIMIT子句（如果ORDER BY已被移除，這裡可能還有LIMIT）
        const limitIndex = countQuery.indexOf('LIMIT');
        if (limitIndex !== -1) {
            countQuery = countQuery.substring(0, limitIndex);
        }

        // 現在將SELECT部分替換為COUNT(*)
        const selectIndex = countQuery.indexOf('SELECT');
        const fromIndex = countQuery.indexOf('FROM', selectIndex);
        if (selectIndex !== -1 && fromIndex !== -1) {
            countQuery = 'SELECT COUNT(*) as total ' + countQuery.substring(fromIndex);
        }

        console.log('=== GET /api/products 開始 ===');
        console.log('查詢參數:', { search, category, is_available, min_stock, max_stock, sort_by, sort_order, page, page_size });
        console.log('完整查詢語句:', query);
        console.log('查詢參數數組:', params);
        console.log('計數查詢語句:', countQuery);

        db.get(countQuery, params, (countErr, countResult) => {
            if (countErr) {
                console.error('計算商品總數錯誤:', countErr);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: countErr.message
                });
            }

            const total = countResult ? countResult.total : 0;
            const totalPages = Math.ceil(total / page_size);
            const offset = (page - 1) * page_size;

            console.log('查詢結果統計 - 總數:', total, '總頁數:', totalPages, '偏移量:', offset);

            // 添加分頁限制
            query += ` LIMIT ? OFFSET ?`;
            const paginatedParams = [...params, parseInt(page_size), parseInt(offset)];

            console.log('分頁查詢語句:', query);
            console.log('分頁參數數組:', paginatedParams);

            db.all(query, paginatedParams, (err, products) => {
                if (err) {
                    console.error('查詢商品列表錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                console.log('查詢返回的原始商品數量:', products.length);
                if (products.length > 0) {
                    console.log('前幾個商品:', products.slice(0, 3).map(p => ({ id: p.id, name: p.name, is_available: p.is_available, category: p.category })));
                    // 調試：如果商品數量少於50，打印所有商品ID和名稱
                    if (products.length < 50) {
                        console.log('所有商品列表:');
                        products.forEach(p => {
                            console.log(`  ID: ${p.id}, 名稱: "${p.name}", 分類: ${p.category}, 可用: ${p.is_available}, 價格: ${p.price}, 時間限制: ${p.has_time_restriction}`);
                        });
                    }
                }

                // 調試：打印有時間限制的商品
                const timeRestrictedProducts = products.filter(p => p.has_time_restriction === 1);
                if (timeRestrictedProducts.length > 0) {
                    console.log(`有時間限制的商品數量: ${timeRestrictedProducts.length}`);
                    timeRestrictedProducts.forEach(p => {
                        console.log(`商品 "${p.name}" (ID: ${p.id}) 時間限制:`);
                        console.log(`  has_time_restriction: ${p.has_time_restriction}`);
                        console.log(`  is_available: ${p.is_available}`);
                        console.log(`  節假日時間1: ${p.holiday_start_time} - ${p.holiday_end_time}`);
                        console.log(`  節假日時間2: ${p.holiday_start_time_2} - ${p.holiday_end_time_2}`);
                        console.log(`  閒日時間1: ${p.weekday_start_time} - ${p.weekday_end_time}`);
                        console.log(`  閒日時間2: ${p.weekday_start_time_2} - ${p.weekday_end_time_2}`);
                    });
                } else {
                    console.log('沒有找到有時間限制的商品');
                }

                // 為每個商品計算時間可用性
                const productsWithTimeAvailability = products.map(product => {
                    const is_time_available = checkTimeRestriction(product, now, isCustomHoliday);
                    return {
                        ...product,
                        is_time_available
                    };
                });

                // 根據 ignore_time_restriction 參數過濾商品
                let filteredProducts = productsWithTimeAvailability;
                if (ignore_time_restriction !== 'true') {
                    filteredProducts = productsWithTimeAvailability.filter(product => product.is_time_available);
                    console.log(`時間過濾: 從 ${productsWithTimeAvailability.length} 個商品過濾到 ${filteredProducts.length} 個`);
                } else {
                    console.log(`忽略時間限制: 顯示所有 ${productsWithTimeAvailability.length} 個商品`);
                }

                // 格式化數據（將數字轉換為布爾值）
                const formattedProducts = filteredProducts.map(product => ({
                    ...product,
                    is_available: product.is_available === 1,
                    locker_number: product.locker_number || null,
                    cost_price: product.cost_price || null,
                    last_restocked: product.last_restocked || null
                }));

                console.log('格式化後商品數量:', formattedProducts.length);

                console.log('=== GET /api/products 結束 ===');

                res.json({
                    success: true,
                    data: {
                        products: formattedProducts,
                        pagination: {
                            total,
                            total_pages: totalPages,
                            current_page: parseInt(page),
                            page_size: parseInt(page_size),
                            has_next: page < totalPages,
                            has_prev: page > 1
                        }
                    }
                });
            });
        });
    } catch (error) {
        console.error('獲取商品列表錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取商品列表失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/products/categories
 * @desc 獲取所有商品分類
 * @access Private/Staff
 */
router.get('/categories', authMiddleware.authenticate, storeAwareMiddleware.initStoreContext, authMiddleware.requireStaff, (req, res) => {
    try {
        const storeId = req.storeContext?.store_id || 'default_store';
        console.log('[商品分類API] storeId:', storeId, 'storeContext:', req.storeContext, 'employee:', req.employee?.id, req.employee?.store_id);
        db.all(
            `SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != '' AND store_id = ? ORDER BY category`,
            [storeId],
            (err, rows) => {
                if (err) {
                    console.error('查詢商品分類錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }
                console.log('[商品分類API] 查詢結果 rows:', rows, 'row count:', rows.length);

                const categories = rows.map(row => row.category).filter(cat => {
                    if (!cat || typeof cat !== 'string') return false;
                    const trimmed = cat.trim();
                    if (trimmed === '') return false;

                    // 過濾亂碼分類：移除包含亂碼字符或無效的分類
                    // 檢查是否包含常見的亂碼字符
                    if (trimmed.includes('�') || trimmed.includes('�') || trimmed.includes('�')) {
                        console.log('過濾亂碼分類:', cat);
                        return false;
                    }

                    // 檢查是否包含至少一個中文字符或英文字母
                    const hasValidChar = /[\u4e00-\u9fa5a-zA-Z]/.test(trimmed);
                    if (!hasValidChar) {
                        console.log('過濾無有效字符的分類:', cat);
                        return false;
                    }

                    return true;
                });
                console.log('[商品分類API] 過濾後 categories:', categories, 'count:', categories.length);

                res.json({
                    success: true,
                    data: {
                        categories: categories,
                        count: categories.length
                    }
                });
            }
        );
    } catch (error) {
        console.error('獲取商品分類錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取商品分類失敗',
            message: error.message
        });
    }
});

/**
 * @route POST /api/products
 * @desc 創建新商品
 * @access Private/Staff
 */
router.post('/', authMiddleware.authenticate, storeAwareMiddleware.initStoreContext, authMiddleware.requireStaff, async (req, res) => {
    try {
        // admin 可以喺 body 指定 store_id 跨分店加商品（阿里雲後台專用，經 ALLOW_CROSS_STORE_ADMIN 開）
        // 平板/預設環境冇開 flag，行為同以前一樣
        const storeId = (runtime.crossStoreAdmin() && req.body.store_id && req.storeContext?.is_admin)
            ? req.body.store_id
            : (req.storeContext?.store_id || 'default_store');
        const {
            id, // 可選的自定義ID
            name,
            description,
            price,
            stock = 0,
            locker_number,
            is_available = true,
            category = 'general',
            min_stock = 10,
            supplier,
            cost_price,
            track_inventory = 1,
            product_order = 0,
            has_time_restriction = false,
            weekday_start_time,
            weekday_end_time,
            holiday_start_time,
            holiday_end_time,
            weekday_start_time_2,
            weekday_end_time_2,
            holiday_start_time_2,
            holiday_end_time_2
        } = req.body;

        const ipAddress = req.ip || req.connection.remoteAddress;

        console.log('創建新商品:', { id, name, category, price });

        // 驗證必填字段
        if (!name || !price) {
            return res.status(400).json({
                success: false,
                error: '缺少必要字段',
                message: '請提供商品名稱和價格'
            });
        }

        // 驗證價格和庫存
        if (isNaN(price) || typeof price !== 'number') {
            return res.status(400).json({
                success: false,
                error: '無效的價格',
                message: '價格必須為有效的數字'
            });
        }

        if (stock < 0) {
            return res.status(400).json({
                success: false,
                error: '無效的庫存',
                message: '庫存不能為負數'
            });
        }

        if (min_stock < 0) {
            return res.status(400).json({
                success: false,
                error: '無效的最低庫存',
                message: '最低庫存不能為負數'
            });
        }

        if (cost_price && cost_price < 0) {
            return res.status(400).json({
                success: false,
                error: '無效的成本價',
                message: '成本價不能為負數'
            });
        }

        // 檢查自定義ID是否已被其他商品使用（如果提供了自定義ID）
        const checkCustomId = (callback) => {
            console.log('檢查自定義ID - 接收到的id:', id, '類型:', typeof id, '是否為空:', !id, '長度:', id ? id.length : 0);

            if (!id || id.trim().length === 0) {
                // 沒有自定義ID，直接回調
                console.log('沒有自定義ID或為空字符串，跳過檢查');
                return callback(null);
            }

            console.log('檢查數據庫中是否已存在ID:', id);
            db.get(
                `SELECT id, is_available FROM products WHERE id = ? AND store_id = ?`,
                [id, storeId],
                (idErr, existingProduct) => {
                    if (idErr) {
                        console.error('檢查自定義ID錯誤:', idErr);
                        return callback(idErr);
                    }

                    if (existingProduct) {
                        console.log('ID已存在:', existingProduct);
                        if (existingProduct.is_available === 1) {
                            return callback(new Error(`商品ID "${id}" 已被其他可用商品使用`));
                        }
                        // 商品存在但不可用 (is_available = 0)，允許重新啟用
                        console.log('商品存在但不可用，允許重新啟用');
                    }

                    // ID可用或可重新啟用
                    console.log('ID可用，未找到重複記錄或可重新啟用');
                    callback(null, existingProduct);
                }
            );
        };

        // 檢查儲物柜編號是否已被其他商品使用
        const checkLockerNumber = (callback) => {
            if (!locker_number) {
                // 沒有儲物柜編號，直接回調
                return callback(null);
            }

            db.get(
                `SELECT id FROM products WHERE locker_number = ? AND store_id = ?`,
                [locker_number, storeId],
                (lockerErr, existingProduct) => {
                    if (lockerErr) {
                        console.error('檢查儲物柜錯誤:', lockerErr);
                        return callback(lockerErr);
                    }

                    if (existingProduct) {
                        return callback(new Error(`儲物柜編號 ${locker_number} 已被其他商品使用`));
                    }

                    // 儲物柜可用
                    callback(null);
                }
            );
        };

        // 依序檢查ID和儲物柜
        checkCustomId((idErr, existingProduct) => {
            if (idErr) {
                return res.status(400).json({
                    success: false,
                    error: 'ID已被使用',
                    message: idErr.message
                });
            }

            checkLockerNumber((lockerErr) => {
                if (lockerErr) {
                    return res.status(400).json({
                        success: false,
                        error: '儲物柜已被使用',
                        message: lockerErr.message
                    });
                }

                // 都通過，創建或更新商品
                createProduct(existingProduct);
            });
        });

        async function createProduct(existingProduct) {
            // 創建商品記錄 - 使用自定義ID或生成新ID
            // 檢查id是否為有效字符串（非空、非undefined）
            const productId = (id && id.trim().length > 0) ? id.trim() : uuidv4();
            const now = new Date().toISOString();

            console.log('實際使用的商品ID:', productId, '原始id:', id, 'existingProduct:', existingProduct);

            if (existingProduct) {
                // 更新現有的軟刪除商品（重新啟用）
                console.log('重新啟用軟刪除的商品:', existingProduct.id);
                db.run(
                    `UPDATE products SET
                        name = ?, description = ?, price = ?, stock = ?, locker_number = ?,
                        is_available = 1, category = ?, min_stock = ?, supplier = ?, cost_price = ?,
                        last_restocked = ?, track_inventory = ?, product_order = ?,
                        has_time_restriction = ?, weekday_start_time = ?, weekday_end_time = ?,
                        holiday_start_time = ?, holiday_end_time = ?, weekday_start_time_2 = ?, weekday_end_time_2 = ?, holiday_start_time_2 = ?, holiday_end_time_2 = ?, created_at = ?
                    WHERE id = ?`,
                    [
                        name,
                        description || null,
                        price,
                        stock,
                        locker_number || null,
                        category,
                        min_stock,
                        supplier || null,
                        cost_price || null,
                        stock > 0 ? now : null, // 如果有初始庫存，設置補貨時間
                        track_inventory,
                        product_order,
                        has_time_restriction ? 1 : 0,
                        weekday_start_time || null,
                        weekday_end_time || null,
                        holiday_start_time || null,
                        holiday_end_time || null,
                        weekday_start_time_2 || null,
                        weekday_end_time_2 || null,
                        holiday_start_time_2 || null,
                        holiday_end_time_2 || null,
                        now,
                        productId
                    ],
                    function (updateErr) {
                        if (updateErr) {
                            console.error('更新商品錯誤:', updateErr);
                            return res.status(500).json({
                                success: false,
                                error: '服務器錯誤',
                                message: updateErr.message
                            });
                        }

                        // 創建審計日誌
                        authMiddleware.createAuditLog(req.employee.id, 'product_re-enable', `重新啟用商品: ${name} (${category})`, ipAddress);

                        // 獲取更新的商品信息
                        db.get(
                            `SELECT id, name, description, price, stock, locker_number,
                                    is_available, category, min_stock, supplier, cost_price,
                                    last_restocked, track_inventory, product_order,
                                    has_time_restriction, weekday_start_time, weekday_end_time,
                                    holiday_start_time, holiday_end_time, weekday_start_time_2, weekday_end_time_2, holiday_start_time_2, holiday_end_time_2, created_at
                             FROM products WHERE id = ?`,
                            [productId],
                            (selectErr, updatedProduct) => {
                                if (selectErr) {
                                    console.error('獲取更新商品錯誤:', selectErr);
                                }

                                // 格式化數據
                                const formattedProduct = updatedProduct ? {
                                    ...updatedProduct,
                                    is_available: updatedProduct.is_available === 1,
                                    locker_number: updatedProduct.locker_number || null,
                                    cost_price: updatedProduct.cost_price || null,
                                    last_restocked: updatedProduct.last_restocked || null
                                } : {
                                    id: productId,
                                    name,
                                    description,
                                    price,
                                    stock,
                                    locker_number,
                                    is_available: 1,
                                    category,
                                    min_stock,
                                    supplier,
                                    cost_price,
                                    last_restocked: stock > 0 ? now : null,
                                    has_time_restriction: has_time_restriction ? 1 : 0,
                                    weekday_start_time: weekday_start_time || null,
                                    weekday_end_time: weekday_end_time || null,
                                    holiday_start_time: holiday_start_time || null,
                                    holiday_end_time: holiday_end_time || null
                                };

                                res.status(200).json({
                                    success: true,
                                    message: '商品重新啟用成功',
                                    data: { product: formattedProduct }
                                });
                            }
                        );
                    }
                );
            } else {
                // 創建新商品
                db.run(
                    `INSERT INTO products (
                        id, name, description, price, stock, locker_number,
                        is_available, category, min_stock, supplier, cost_price,
                        last_restocked, track_inventory, product_order,
                        has_time_restriction, weekday_start_time, weekday_end_time,
                        holiday_start_time, holiday_end_time,
                        weekday_start_time_2, weekday_end_time_2,
                        holiday_start_time_2, holiday_end_time_2, created_at, store_id
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [
                        productId,
                        name,
                        description || null,
                        price,
                        stock,
                        locker_number || null,
                        is_available ? 1 : 0,
                        category,
                        min_stock,
                        supplier || null,
                        cost_price || null,
                        stock > 0 ? now : null, // 如果有初始庫存，設置補貨時間
                        track_inventory,
                        product_order,
                        has_time_restriction ? 1 : 0,
                        weekday_start_time || null,
                        weekday_end_time || null,
                        holiday_start_time || null,
                        holiday_end_time || null,
                        weekday_start_time_2 || null,
                        weekday_end_time_2 || null,
                        holiday_start_time_2 || null,
                        holiday_end_time_2 || null,
                        now,
                        storeId
                    ],
                    function (insertErr) {
                        if (insertErr) {
                            console.error('創建商品錯誤:', insertErr);
                            return res.status(500).json({
                                success: false,
                                error: '服務器錯誤',
                                message: insertErr.message
                            });
                        }

                        // 創建審計日誌
                        authMiddleware.createAuditLog(req.employee.id, 'product_create', `創建商品: ${name} (${category})`, ipAddress);

                        // 獲取創建的商品信息
                        db.get(
                            `SELECT id, name, description, price, stock, locker_number,
                                    is_available, category, min_stock, supplier, cost_price,
                                    last_restocked, track_inventory, product_order,
                                    has_time_restriction, weekday_start_time, weekday_end_time,
                                    holiday_start_time, holiday_end_time, weekday_start_time_2, weekday_end_time_2, holiday_start_time_2, holiday_end_time_2, created_at
                             FROM products WHERE id = ?`,
                            [productId],
                            (selectErr, newProduct) => {
                                if (selectErr) {
                                    console.error('獲取新商品錯誤:', selectErr);
                                }

                                // 格式化數據
                                const formattedProduct = newProduct ? {
                                    ...newProduct,
                                    is_available: newProduct.is_available === 1,
                                    locker_number: newProduct.locker_number || null,
                                    cost_price: newProduct.cost_price || null,
                                    last_restocked: newProduct.last_restocked || null
                                } : {
                                    id: productId,
                                    name,
                                    description,
                                    price,
                                    stock,
                                    locker_number,
                                    is_available,
                                    category,
                                    min_stock,
                                    supplier,
                                    cost_price,
                                    last_restocked: stock > 0 ? now : null,
                                    has_time_restriction: has_time_restriction ? 1 : 0,
                                    weekday_start_time: weekday_start_time || null,
                                    weekday_end_time: weekday_end_time || null,
                                    holiday_start_time: holiday_start_time || null,
                                    holiday_end_time: holiday_end_time || null
                                };

                                res.status(201).json({
                                    success: true,
                                    message: '商品創建成功',
                                    data: { product: formattedProduct }
                                });
                            }
                        );
                    }
                );
            }
        }
    } catch (error) {
        console.error('創建商品錯誤:', error);
        res.status(500).json({
            success: false,
            error: '創建商品失敗',
            message: error.message
        });
    }
});

/**
 * @route POST /api/products/batch
 * @desc 批量創建商品
 * @access Private/Admin
 */
router.post('/batch', authMiddleware.authenticate, storeAwareMiddleware.initStoreContext, authMiddleware.requireAdmin, async (req, res) => {
    try {
        const storeId = req.storeContext?.store_id || 'default_store';
        console.log('=== 批量上傳商品開始 ===');
        console.log('員工:', req.employee?.id, req.employee?.username);
        console.log('IP:', req.ip || req.connection.remoteAddress);
        console.log('分店:', storeId);

        const { products } = req.body;
        const ipAddress = req.ip || req.connection.remoteAddress;

        console.log('接收到的商品數量:', products?.length);
        if (products && Array.isArray(products)) {
            console.log('商品列表:', products.map(p => ({ name: p.name, id: p.id, category: p.category })));
        }

        if (!products || !Array.isArray(products) || products.length === 0) {
            console.log('錯誤: 無效的商品數據');
            return res.status(400).json({
                success: false,
                error: '無效的請求',
                message: '請提供有效的商品數組'
            });
        }

        if (products.length > 100) {
            return res.status(400).json({
                success: false,
                error: '數量過多',
                message: '一次最多批量上傳100個商品'
            });
        }

        // 驗證每個商品數據
        const productsToInsert = []; // 新商品
        const productsToUpdate = []; // 重新啟用的軟刪除商品
        const productsToSkip = [];   // 已存在且可用的商品，跳過
        const errors = [];

        // 使用Promise.all處理所有商品的檢查
        const checkPromises = products.map((product, index) => {
            return new Promise((resolve) => {
                // 調試：記錄特定商品
                if (product.name && product.name.includes('巴斯克芝士蛋糕')) {
                    console.log(`處理特定商品 "巴斯克芝士蛋糕":`, { index, id: product.id, category: product.category, price: product.price });
                }

                // 基本驗證
                if (!product.name || product.name.trim() === '') {
                    errors.push(`第${index + 1}個商品: 商品名稱不能為空`);
                    return resolve(null);
                }

                if (product.price === undefined || isNaN(product.price) || typeof product.price !== 'number') {
                    errors.push(`第${index + 1}個商品: 價格必須為有效的數字`);
                    return resolve(null);
                }

                // 處理自定義ID
                let productId = product.id;
                let existingProduct = null;

                if (!productId || productId.trim() === '') {
                    productId = uuidv4();
                    // 對於自動生成的ID，直接視為新商品
                    console.log(`商品 ${product.name} 使用自動生成ID: ${productId}`);

                    const validatedProduct = {
                        id: productId,
                        name: product.name.trim(),
                        description: product.description || '',
                        price: parseFloat(product.price),
                        stock: product.stock !== undefined ? parseInt(product.stock) : 0,
                        min_stock: product.min_stock !== undefined ? parseInt(product.min_stock) : 0,
                        category: product.category || '其他',
                        is_available: 1,
                        locker_number: product.locker_number || null,
                        supplier: product.supplier || '',
                        cost_price: product.cost_price ? parseFloat(product.cost_price) : null,
                        track_inventory: product.track_inventory !== undefined ? parseInt(product.track_inventory) : 0,
                        product_order: product.product_order !== undefined ? parseInt(product.product_order) : 0,
                        created_at: new Date().toISOString()
                    };

                    console.log(`商品 ${product.name} (ID: ${productId}) 被分類為需要插入的新商品（自動生成ID）`);
                    resolve({ product: validatedProduct, type: 'insert' });
                    return;
                } else {
                    // 檢查自定義ID是否已存在（無論是否可用）
                    console.log(`檢查自定義ID: ${productId}`);
                    if (product.name && product.name.includes('巴斯克芝士蛋糕')) {
                        console.log(`針對 "巴斯克芝士蛋糕" 檢查ID: ${productId}`);
                    }

                    // 使用db.get()檢查商品是否存在
                    db.get("SELECT id, name, is_available, price, category, stock, has_time_restriction, track_inventory FROM products WHERE id = ? AND store_id = ?", [productId, storeId], (err, row) => {
                        if (err) {
                            console.error(`檢查ID ${productId} 錯誤:`, err);
                            errors.push(`第${index + 1}個商品: 檢查ID時發生錯誤`);
                            return resolve(null);
                        }

                        existingProduct = row;
                        console.log(`檢查結果:`, existingProduct);
                        if (product.name && product.name.includes('巴斯克芝士蛋糕')) {
                            console.log(`"巴斯克芝士蛋糕" 檢查結果:`, existingProduct);
                            console.log(`"巴斯克芝士蛋糕" 檢查結果是否有id屬性:`, existingProduct && 'id' in existingProduct);
                        }

                        // 設置默認值
                        const validatedProduct = {
                            id: productId,
                            name: product.name.trim(),
                            description: product.description || '',
                            price: parseFloat(product.price),
                            stock: product.stock !== undefined ? parseInt(product.stock) : 0,
                            min_stock: product.min_stock !== undefined ? parseInt(product.min_stock) : 0,
                            category: product.category || '其他',
                            is_available: 1,
                            locker_number: product.locker_number || null,
                            supplier: product.supplier || '',
                            cost_price: product.cost_price ? parseFloat(product.cost_price) : null,
                            track_inventory: product.track_inventory !== undefined ? parseInt(product.track_inventory) : 0,
                            product_order: product.product_order !== undefined ? parseInt(product.product_order) : 0,
                            created_at: new Date().toISOString()
                        };

                        // 根據現有產品狀態分類
                        if (existingProduct && existingProduct.id) {
                            if (existingProduct.is_available === 1) {
                                // 商品已存在且可用，用新商品資料取代舊商品（更新所有欄位）
                                console.log(`UUID ${productId} 已存在且可用，將取代舊商品`);
                                console.log(`商品 ${product.name} (ID: ${productId}) 將更新所有欄位`);
                                console.log(`現有商品詳細信息:`, {
                                    id: existingProduct.id,
                                    name: existingProduct.name,
                                    is_available: existingProduct.is_available,
                                    price: existingProduct.price,
                                    category: existingProduct.category,
                                    stock: existingProduct.stock,
                                    has_time_restriction: existingProduct.has_time_restriction,
                                    track_inventory: existingProduct.track_inventory
                                });
                                resolve({ product: validatedProduct, type: 'update' });
                            } else {
                                // 商品存在但不可用 (is_available = 0)，允許重新啟用
                                console.log(`UUID ${productId} 存在但不可用，將重新啟用`);
                                console.log(`商品 ${product.name} (ID: ${productId}) 被分類為需要更新的軟刪除商品`);
                                resolve({ product: validatedProduct, type: 'update' });
                            }
                        } else {
                            // 商品不存在，是新商品
                            console.log(`UUID ${productId} 可用（全新商品）`);
                            console.log(`商品 ${product.name} (ID: ${productId}) 被分類為需要插入的新商品`);
                            resolve({ product: validatedProduct, type: 'insert' });
                        }
                    });
                }
            });
        });

        // 等待所有檢查完成
        try {
            const results = await Promise.all(checkPromises);

            // 將結果分類到相應的數組
            results.forEach(result => {
                if (!result) return; // 跳過錯誤的結果

                const { product, type } = result;
                if (type === 'insert') {
                    productsToInsert.push(product);
                } else if (type === 'update') {
                    productsToUpdate.push(product);
                } else if (type === 'skip') {
                    productsToSkip.push(product);
                }
            });

            console.log(`檢查完成: 插入 ${productsToInsert.length} 個, 更新 ${productsToUpdate.length} 個, 跳過 ${productsToSkip.length} 個`);
        } catch (error) {
            console.error('檢查商品時發生錯誤:', error);
            return res.status(500).json({
                success: false,
                error: '檢查商品失敗',
                message: error.message
            });
        }

        if (errors.length > 0) {
            return res.status(400).json({
                success: false,
                error: '驗證失敗',
                message: '部分商品數據無效',
                errors
            });
        }

        // 檢查是否有需要處理的商品（插入或更新）
        if (productsToInsert.length === 0 && productsToUpdate.length === 0) {
            // 所有商品都被跳過了（已存在且可用）
            if (productsToSkip.length > 0) {
                // 所有商品都已存在，返回成功響應
                console.log(`所有商品均已存在，跳過 ${productsToSkip.length} 個商品`);

                // 創建審計日誌
                try {
                    if (req.employee && req.employee.id) {
                        authMiddleware.createAuditLog(
                            req.employee.id,
                            'product_batch_skip',
                            `批量跳過 ${productsToSkip.length} 個已存在的商品`,
                            ipAddress
                        );
                    }
                } catch (auditLogError) {
                    console.error('創建審計日誌時發生錯誤（但不影響操作）:', auditLogError);
                }

                return res.json({
                    success: true,
                    message: `所有 ${productsToSkip.length} 個商品均已存在，已跳過`,
                    createdCount: 0,
                    updatedCount: 0,
                    skippedCount: productsToSkip.length,
                    insertedIds: [],
                    updatedIds: [],
                    skippedIds: productsToSkip.map(p => p.id)
                });
            } else {
                // 真正沒有有效商品
                return res.status(400).json({
                    success: false,
                    error: '無有效商品',
                    message: '沒有有效的商品數據可上傳'
                });
            }
        }

        // 開始事務
        console.log('開始資料庫事務');
        db.exec('BEGIN TRANSACTION');
        console.log('事務開始成功');

        try {
            const insertedIds = [];
            const updatedIds = [];

            // 處理INSERT（新商品）
            if (productsToInsert.length > 0) {
                console.log(`準備插入 ${productsToInsert.length} 個新商品`);

                // 使用 Promise 處理每個 INSERT 操作
                const insertPromises = productsToInsert.map((product, idx) => {
                    return new Promise((resolve, reject) => {
                        console.log(`插入第 ${idx + 1} 個商品: ${product.name} (ID: ${product.id})`);

                        // 調試：打印完整參數
                        console.log(`插入參數詳情:`);
                        console.log(`  id: ${product.id}`);
                        console.log(`  name: ${product.name}`);
                        console.log(`  description: ${product.description}`);
                        console.log(`  price: ${product.price}`);
                        console.log(`  stock: ${product.stock}`);
                        console.log(`  locker_number: ${product.locker_number}`);
                        console.log(`  is_available: ${product.is_available}`);
                        console.log(`  category: ${product.category}`);
                        console.log(`  min_stock: ${product.min_stock}`);
                        console.log(`  supplier: ${product.supplier}`);
                        console.log(`  cost_price: ${product.cost_price}`);
                        console.log(`  track_inventory: ${product.track_inventory}`);
                        console.log(`  product_order: ${product.product_order}`);
                        console.log(`  created_at: ${product.created_at}`);

                        const insertSql = `
                            INSERT INTO products (
                                id, name, description, price, stock, locker_number,
                                is_available, category, min_stock, supplier, cost_price,
                                last_restocked, track_inventory, product_order, created_at, store_id
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        `;
                        console.log(`執行INSERT SQL: ${insertSql.trim()}`);

                        db.run(
                            insertSql,
                            [
                                product.id,
                                product.name,
                                product.description,
                                product.price,
                                product.stock,
                                product.locker_number,
                                product.is_available,
                                product.category,
                                product.min_stock,
                                product.supplier,
                                product.cost_price,
                                null, // last_restocked
                                product.track_inventory,
                                product.product_order,
                                product.created_at,
                                storeId
                            ],
                            function (insertErr) {
                                // 調試：打印 this 上下文
                                console.log(`插入回調被調用, this 上下文:`, this);
                                console.log(`插入回調 this.changes:`, this ? this.changes : 'undefined');
                                console.log(`插入回調 this.lastID:`, this ? this.lastID : 'undefined');

                                if (insertErr) {
                                    console.error(`插入商品 ${product.name} 時發生錯誤:`, insertErr);
                                    return reject(insertErr);
                                }

                                console.log(`插入結果: changes=${this ? this.changes : 'undefined'}, lastID: ${this ? this.lastID : 'undefined'}`);
                                if (this && this.changes === 1) {
                                    insertedIds.push(product.id);
                                    console.log(`商品 ${product.name} 插入成功，ID 添加到 insertedIds`);
                                    resolve(true);
                                } else {
                                    console.warn(`商品 ${product.name} 插入失敗: this.changes = ${this ? this.changes : 'undefined'}`);
                                    reject(new Error(`插入商品失敗: ${product.name} (ID: ${product.id}) - 沒有行被影響`));
                                }
                            }
                        );
                    });
                });

                // 等待所有 INSERT 完成
                try {
                    await Promise.all(insertPromises);
                    console.log('所有商品插入完成');
                } catch (insertError) {
                    console.error('插入商品時發生錯誤:', insertError);
                    throw insertError; // 觸發事務回滾
                }
            } else {
                console.log('沒有新商品需要插入');
            }

            // 處理UPDATE（更新已存在的商品，含軟刪除重新啟用）
            if (productsToUpdate.length > 0) {
                console.log(`準備更新 ${productsToUpdate.length} 個已存在商品`);
                const updateStmt = db.prepare(`
                    UPDATE products SET
                        name = ?, description = ?, price = ?, stock = ?, locker_number = ?,
                        is_available = 1, category = ?, min_stock = ?, supplier = ?, cost_price = ?,
                        last_restocked = ?, track_inventory = ?, product_order = ?, created_at = ?
                    WHERE id = ?
                `);
                console.log('UPDATE語句準備完成');

                // 使用 Promise 處理每個 UPDATE 操作
                const updatePromises = productsToUpdate.map((product, idx) => {
                    return new Promise((resolve, reject) => {
                        console.log(`更新第 ${idx + 1} 個商品: ${product.name} (ID: ${product.id})`);

                        // 調試：打印完整參數
                        console.log(`更新參數詳情:`);
                        console.log(`  name: ${product.name}`);
                        console.log(`  description: ${product.description}`);
                        console.log(`  price: ${product.price}`);
                        console.log(`  stock: ${product.stock}`);
                        console.log(`  locker_number: ${product.locker_number}`);
                        console.log(`  category: ${product.category}`);
                        console.log(`  min_stock: ${product.min_stock}`);
                        console.log(`  supplier: ${product.supplier}`);
                        console.log(`  cost_price: ${product.cost_price}`);
                        console.log(`  track_inventory: ${product.track_inventory}`);
                        console.log(`  product_order: ${product.product_order}`);
                        console.log(`  created_at: ${product.created_at}`);
                        console.log(`  id: ${product.id}`);

                        // 使用 db.run() 而不是 stmt.run()，確保正確的異步處理
                        const updateSql = `UPDATE products SET
                                name = ?, description = ?, price = ?, stock = ?, locker_number = ?,
                                is_available = 1, category = ?, min_stock = ?, supplier = ?, cost_price = ?,
                                last_restocked = ?, track_inventory = ?, product_order = ?, created_at = ?
                            WHERE id = ? AND store_id = ?`;
                        console.log(`執行UPDATE SQL: ${updateSql}`);

                        db.run(
                            updateSql,
                            [
                                product.name,
                                product.description,
                                product.price,
                                product.stock,
                                product.locker_number,
                                product.category,
                                product.min_stock,
                                product.supplier,
                                product.cost_price,
                                null, // last_restocked
                                product.track_inventory,
                                product.product_order,
                                product.created_at,
                                product.id,
                                storeId
                            ],
                            function (updateErr) {
                                // 調試：打印 this 上下文
                                console.log(`更新回調被調用, this 上下文:`, this);
                                console.log(`更新回調 this.changes:`, this ? this.changes : 'undefined');
                                console.log(`更新回調 this.lastID:`, this ? this.lastID : 'undefined');

                                if (updateErr) {
                                    console.error(`更新商品 ${product.name} 時發生錯誤:`, updateErr);
                                    return reject(updateErr);
                                }

                                console.log(`更新結果: changes=${this ? this.changes : 'undefined'}, lastID: ${this ? this.lastID : 'undefined'}`);
                                if (this && this.changes === 1) {
                                    updatedIds.push(product.id);
                                    console.log(`商品 ${product.name} 更新成功，ID 添加到 updatedIds`);
                                    resolve(true);
                                } else {
                                    console.warn(`商品 ${product.name} 更新失敗: this.changes = ${this ? this.changes : 'undefined'}`);
                                    reject(new Error(`更新商品失敗: ${product.name} (ID: ${product.id}) - 沒有行被影響`));
                                }
                            }
                        );
                    });
                });

                // 等待所有 UPDATE 完成
                try {
                    await Promise.all(updatePromises);
                    console.log('所有商品更新完成');
                } catch (updateError) {
                    console.error('更新商品時發生錯誤:', updateError);
                    throw updateError; // 觸發事務回滾
                }

                // 不再需要 finalize，因為我們使用 db.run() 而不是 prepared statement
                console.log('所有商品更新完成');
            } else {
                console.log('沒有軟刪除商品需要更新');
            }

            // 提交事務
            console.log('準備提交事務');
            db.exec('COMMIT');
            console.log('事務提交成功');

            // 驗證：查詢所有處理過的商品ID，檢查是否成功儲存
            console.log('=== 開始驗證商品儲存 ===');
            try {
                const allProcessedIds = [...insertedIds, ...updatedIds];
                if (allProcessedIds.length > 0) {
                    const placeholders = allProcessedIds.map(() => '?').join(',');
                    const verifyQuery = `SELECT id, name, is_available, category FROM products WHERE id IN (${placeholders})`;
                    console.log('驗證查詢:', verifyQuery);
                    console.log('驗證參數:', allProcessedIds);

                    // 使用 db.all() 代替 prepare().all()
                    db.all(verifyQuery, allProcessedIds, (verifyErr, verifiedProducts) => {
                        if (verifyErr) {
                            console.error('驗證查詢錯誤:', verifyErr);
                            // 驗證錯誤不應該影響操作成功，只記錄日誌
                            console.log('驗證失敗，但操作仍然成功');
                        } else {
                            console.log('驗證結果:', verifiedProducts);

                            // 特別檢查"巴斯克芝士蛋糕"
                            const basqueCake = verifiedProducts.find(p => p.name && p.name.includes('巴斯克芝士蛋糕'));
                            if (basqueCake) {
                                console.log('巴斯克芝士蛋糕驗證:', basqueCake);
                            } else {
                                console.log('警告: 巴斯克芝士蛋糕不在驗證結果中');
                            }
                        }
                    });
                } else {
                    console.log('警告: 沒有處理任何商品ID');
                }
            } catch (verifyError) {
                // 驗證過程中的任何同步錯誤都只記錄日誌
                console.error('驗證過程中發生同步錯誤（不影響操作）:', verifyError);
            }
            console.log('=== 結束驗證商品儲存 ===');

            // 創建審計日誌
            const totalInserted = insertedIds.length;
            const totalUpdated = updatedIds.length;
            const skippedIds = productsToSkip.map(p => p.id);
            const totalSkipped = skippedIds.length;
            let auditMessage = '';

            // 構建審計消息（包含所有統計）
            const messageParts = [];
            if (totalInserted > 0) {
                messageParts.push(`新增 ${totalInserted} 個`);
            }
            if (totalUpdated > 0) {
                messageParts.push(`更新 ${totalUpdated} 個`);
            }
            if (totalSkipped > 0) {
                messageParts.push(`跳過 ${totalSkipped} 個`);
            }

            if (messageParts.length > 0) {
                auditMessage = `批量處理商品: ${messageParts.join('，')}`;
            } else {
                auditMessage = '批量處理商品（無變更）';
            }

            // 安全地創建審計日誌（防止錯誤導致服務器崩潰）
            try {
                if (req.employee && req.employee.id) {
                    authMiddleware.createAuditLog(
                        req.employee.id,
                        'product_batch_create',
                        auditMessage,
                        ipAddress
                    );
                } else {
                    console.warn('無法創建審計日誌: req.employee 不存在或無id');
                }
            } catch (auditLogError) {
                console.error('創建審計日誌時發生錯誤（但不影響操作）:', auditLogError);
            }

            console.log(`批量上傳完成，準備返回響應。插入: ${totalInserted}, 更新: ${totalUpdated}, 跳過: ${totalSkipped}`);

            // 構建響應消息
            let responseMessage;
            const processedCount = totalInserted + totalUpdated;
            if (processedCount > 0) {
                const parts = [];
                if (totalInserted > 0) parts.push(`新增 ${totalInserted} 個`);
                if (totalUpdated > 0) parts.push(`更新 ${totalUpdated} 個`);
                responseMessage = `成功處理 ${processedCount} 個商品 (${parts.join('，')})`;
                if (totalSkipped > 0) {
                    responseMessage += `，跳過 ${totalSkipped} 個已存在的商品`;
                }
            } else if (totalSkipped > 0) {
                responseMessage = `所有商品均已存在，跳過 ${totalSkipped} 個商品`;
            } else {
                responseMessage = '沒有商品需要處理';
            }

            res.json({
                success: true,
                message: responseMessage,
                createdCount: totalInserted,
                updatedCount: totalUpdated,
                skippedCount: totalSkipped,
                insertedIds,
                updatedIds,
                skippedIds
            });
            console.log('批量上傳響應已發送');
            console.log('=== 批量上傳商品結束 (成功) ===');

        } catch (dbError) {
            // 嘗試回滾事務（如果事務仍在進行中）
            try {
                db.exec('ROLLBACK');
                console.log('事務回滾成功');
            } catch (rollbackErr) {
                console.warn('回滾事務失敗（可能事務已提交或從未開始）:', rollbackErr.message);
            }
            console.error('批量新增商品錯誤:', dbError);
            throw dbError;
        }

    } catch (error) {
        console.error('批量新增商品錯誤:', error);
        res.status(500).json({
            success: false,
            error: '批量新增失敗',
            message: error.message
        });
        console.log('=== 批量上傳商品結束 (錯誤) ===');
    }
});

/**
 * @route PUT /api/products/:id
 * @desc 更新商品信息
 * @access Private/Staff
 */
router.put('/:id', authMiddleware.authenticate, storeAwareMiddleware.initStoreContext, authMiddleware.requireStaff, async (req, res) => {
    try {
        const storeId = req.storeContext?.store_id || 'default_store';
        const { id } = req.params;
        const {
            name,
            description,
            price,
            stock,
            locker_number,
            is_available,
            category,
            min_stock,
            supplier,
            cost_price,
            track_inventory,
            product_order,
            new_id, // 可選的新ID，用於更改商品ID
            has_time_restriction,
            weekday_start_time,
            weekday_end_time,
            holiday_start_time,
            holiday_end_time,
            weekday_start_time_2,
            weekday_end_time_2,
            holiday_start_time_2,
            holiday_end_time_2
        } = req.body;

        const ipAddress = req.ip || req.connection.remoteAddress;

        console.log('更新商品:', { id, name, category });

        // 檢查商品是否存在
        db.get(
            `SELECT id, name, locker_number FROM products WHERE id = ? AND store_id = ?`,
            [id, storeId],
            async (err, existingProduct) => {
                if (err) {
                    console.error('檢查商品錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                if (!existingProduct) {
                    return res.status(404).json({
                        success: false,
                        error: '商品不存在',
                        message: '找不到指定的商品'
                    });
                }

                // 檢查新ID是否已被其他商品使用（如果提供了新ID）
                const checkNewId = (callback) => {
                    if (!new_id || new_id === id) {
                        // 沒有新ID或新ID與當前ID相同，直接回調
                        return callback(null);
                    }

                    db.get(
                        `SELECT id FROM products WHERE id = ? AND is_available = 1 AND store_id = ?`,
                        [new_id, storeId],
                        (idErr, otherProduct) => {
                            if (idErr) {
                                console.error('檢查新ID錯誤:', idErr);
                                return callback(idErr);
                            }

                            if (otherProduct) {
                                return callback(new Error(`商品ID "${new_id}" 已被其他商品使用`));
                            }

                            // 新ID可用
                            callback(null);
                        }
                    );
                };

                // 檢查新儲物柜編號是否已被其他商品使用
                const checkLockerNumber = (callback) => {
                    if (locker_number === undefined || locker_number === existingProduct.locker_number) {
                        // 沒有新儲物柜編號或與當前相同，直接回調
                        return callback(null);
                    }

                    db.get(
                        `SELECT id FROM products WHERE locker_number = ? AND id != ? AND store_id = ?`,
                        [locker_number, id, storeId],
                        (lockerErr, otherProduct) => {
                            if (lockerErr) {
                                console.error('檢查儲物柜錯誤:', lockerErr);
                                return callback(lockerErr);
                            }

                            if (otherProduct) {
                                return callback(new Error(`儲物柜編號 ${locker_number} 已被其他商品使用`));
                            }

                            // 儲物柜可用
                            callback(null);
                        }
                    );
                };

                // 依序檢查新ID和儲物柜
                checkNewId((idErr) => {
                    if (idErr) {
                        return res.status(400).json({
                            success: false,
                            error: 'ID已被使用',
                            message: idErr.message
                        });
                    }

                    checkLockerNumber((lockerErr) => {
                        if (lockerErr) {
                            return res.status(400).json({
                                success: false,
                                error: '儲物柜已被使用',
                                message: lockerErr.message
                            });
                        }

                        // 都通過，繼續更新
                        updateProduct();
                    });
                });

                async function updateProduct() {
                    // 構建更新語句
                    const updates = [];
                    const params = [];

                    // 計算最終的商品ID（如果更新了ID則使用新ID，否則使用原ID）
                    const finalId = new_id && new_id !== id ? new_id : id;

                    // 如果提供了新ID，更新ID字段
                    if (new_id && new_id !== id) {
                        updates.push('id = ?');
                        params.push(new_id);
                    }

                    if (name !== undefined) {
                        updates.push('name = ?');
                        params.push(name);
                    }

                    if (description !== undefined) {
                        updates.push('description = ?');
                        params.push(description || null);
                    }

                    if (price !== undefined) {
                        if (isNaN(price) || typeof price !== 'number') {
                            return res.status(400).json({
                                success: false,
                                error: '無效的價格',
                                message: '價格必須為有效的數字'
                            });
                        }
                        updates.push('price = ?');
                        params.push(price);
                    }

                    if (stock !== undefined) {
                        if (stock < 0) {
                            return res.status(400).json({
                                success: false,
                                error: '無效的庫存',
                                message: '庫存不能為負數'
                            });
                        }
                        updates.push('stock = ?');
                        params.push(stock);

                        // 如果庫存增加，更新最後補貨時間
                        if (stock > (existingProduct.stock || 0)) {
                            updates.push('last_restocked = ?');
                            params.push(new Date().toISOString());
                        }
                    }

                    if (locker_number !== undefined) {
                        updates.push('locker_number = ?');
                        params.push(locker_number || null);
                    }

                    if (is_available !== undefined) {
                        updates.push('is_available = ?');
                        params.push(is_available ? 1 : 0);
                    }

                    if (category !== undefined) {
                        updates.push('category = ?');
                        params.push(category);
                    }

                    if (min_stock !== undefined) {
                        if (min_stock < 0) {
                            return res.status(400).json({
                                success: false,
                                error: '無效的最低庫存',
                                message: '最低庫存不能為負數'
                            });
                        }
                        updates.push('min_stock = ?');
                        params.push(min_stock);
                    }

                    if (supplier !== undefined) {
                        updates.push('supplier = ?');
                        params.push(supplier || null);
                    }

                    if (cost_price !== undefined) {
                        if (cost_price !== null && cost_price < 0) {
                            return res.status(400).json({
                                success: false,
                                error: '無效的成本價',
                                message: '成本價不能為負數'
                            });
                        }
                        updates.push('cost_price = ?');
                        params.push(cost_price || null);
                    }

                    if (track_inventory !== undefined) {
                        updates.push('track_inventory = ?');
                        params.push(track_inventory);
                    }

                    if (product_order !== undefined) {
                        updates.push('product_order = ?');
                        params.push(product_order);
                    }

                    if (has_time_restriction !== undefined) {
                        updates.push('has_time_restriction = ?');
                        params.push(has_time_restriction ? 1 : 0);
                    }

                    if (weekday_start_time !== undefined) {
                        updates.push('weekday_start_time = ?');
                        params.push(weekday_start_time || null);
                    }

                    if (weekday_end_time !== undefined) {
                        updates.push('weekday_end_time = ?');
                        params.push(weekday_end_time || null);
                    }

                    if (holiday_start_time !== undefined) {
                        updates.push('holiday_start_time = ?');
                        params.push(holiday_start_time || null);
                    }

                    if (holiday_end_time !== undefined) {
                        updates.push('holiday_end_time = ?');
                        params.push(holiday_end_time || null);
                    }

                    if (weekday_start_time_2 !== undefined) {
                        updates.push('weekday_start_time_2 = ?');
                        params.push(weekday_start_time_2 || null);
                    }

                    if (weekday_end_time_2 !== undefined) {
                        updates.push('weekday_end_time_2 = ?');
                        params.push(weekday_end_time_2 || null);
                    }

                    if (holiday_start_time_2 !== undefined) {
                        updates.push('holiday_start_time_2 = ?');
                        params.push(holiday_start_time_2 || null);
                    }

                    if (holiday_end_time_2 !== undefined) {
                        updates.push('holiday_end_time_2 = ?');
                        params.push(holiday_end_time_2 || null);
                    }

                    // 添加WHERE條件
                    params.push(id);
                    params.push(storeId);

                    if (updates.length === 0) {
                        return res.status(400).json({
                            success: false,
                            error: '無效的更新',
                            message: '沒有提供可更新的字段'
                        });
                    }

                    const updateQuery = `UPDATE products SET ${updates.join(', ')} WHERE id = ? AND store_id = ?`;

                    db.run(updateQuery, params, function (updateErr) {
                        if (updateErr) {
                            console.error('更新商品錯誤:', updateErr);
                            return res.status(500).json({
                                success: false,
                                error: '服務器錯誤',
                                message: updateErr.message
                            });
                        }

                        if (this.changes === 0) {
                            return res.status(404).json({
                                success: false,
                                error: '商品不存在',
                                message: '找不到指定的商品'
                            });
                        }

                        // 創建審計日誌
                        authMiddleware.createAuditLog(req.employee.id, 'product_update', `更新商品: ${existingProduct.name}`, ipAddress);

                        // 獲取更新後的商品信息
                        db.get(
                            `SELECT id, name, description, price, stock, locker_number,
                                    is_available, category, min_stock, supplier, cost_price,
                                    last_restocked, track_inventory, product_order,
                                    has_time_restriction, weekday_start_time, weekday_end_time,
                                    holiday_start_time, holiday_end_time, weekday_start_time_2, weekday_end_time_2, holiday_start_time_2, holiday_end_time_2, created_at
                             FROM products WHERE id = ?`,
                            [finalId],
                            (selectErr, updatedProduct) => {
                                if (selectErr) {
                                    console.error('獲取更新後商品錯誤:', selectErr);
                                }

                                // 格式化數據
                                const formattedProduct = updatedProduct ? {
                                    ...updatedProduct,
                                    is_available: updatedProduct.is_available === 1,
                                    locker_number: updatedProduct.locker_number || null,
                                    cost_price: updatedProduct.cost_price || null,
                                    last_restocked: updatedProduct.last_restocked || null
                                } : {
                                    id: finalId,
                                    name: name || existingProduct.name,
                                    description: description !== undefined ? description : existingProduct.description,
                                    price: price !== undefined ? price : existingProduct.price,
                                    stock: stock !== undefined ? stock : existingProduct.stock,
                                    locker_number: locker_number !== undefined ? locker_number : existingProduct.locker_number,
                                    is_available: is_available !== undefined ? is_available : existingProduct.is_available,
                                    category: category !== undefined ? category : existingProduct.category,
                                    min_stock: min_stock !== undefined ? min_stock : existingProduct.min_stock,
                                    supplier: supplier !== undefined ? supplier : existingProduct.supplier,
                                    cost_price: cost_price !== undefined ? cost_price : existingProduct.cost_price,
                                    track_inventory: track_inventory !== undefined ? track_inventory : existingProduct.track_inventory,
                                    product_order: product_order !== undefined ? product_order : existingProduct.product_order,
                                    has_time_restriction: has_time_restriction !== undefined ? (has_time_restriction ? 1 : 0) : (existingProduct.has_time_restriction || 0),
                                    weekday_start_time: weekday_start_time !== undefined ? weekday_start_time : existingProduct.weekday_start_time,
                                    weekday_end_time: weekday_end_time !== undefined ? weekday_end_time : existingProduct.weekday_end_time,
                                    holiday_start_time: holiday_start_time !== undefined ? holiday_start_time : existingProduct.holiday_start_time,
                                    holiday_end_time: holiday_end_time !== undefined ? holiday_end_time : existingProduct.holiday_end_time,
                                    weekday_start_time_2: weekday_start_time_2 !== undefined ? weekday_start_time_2 : existingProduct.weekday_start_time_2,
                                    weekday_end_time_2: weekday_end_time_2 !== undefined ? weekday_end_time_2 : existingProduct.weekday_end_time_2,
                                    holiday_start_time_2: holiday_start_time_2 !== undefined ? holiday_start_time_2 : existingProduct.holiday_start_time_2,
                                    holiday_end_time_2: holiday_end_time_2 !== undefined ? holiday_end_time_2 : existingProduct.holiday_end_time_2
                                };

                                res.json({
                                    success: true,
                                    message: '商品更新成功',
                                    data: { product: formattedProduct }
                                });
                            }
                        );
                    });
                }
            }
        );
    } catch (error) {
        console.error('更新商品錯誤:', error);
        res.status(500).json({
            success: false,
            error: '更新商品失敗',
            message: error.message
        });
    }
});

/**
 * @route DELETE /api/products/:id
 * @desc 刪除商品（僅管理員）
 * @access Private/Admin
 */
router.delete('/:id', authMiddleware.authenticate, storeAwareMiddleware.initStoreContext, authMiddleware.requireStaff, (req, res) => {
    try {
        const { id } = req.params;
        const ipAddress = req.ip || req.connection.remoteAddress;

        console.log('刪除商品:', { id });

        // 檢查商品是否存在
        db.get(
            `SELECT name, category FROM products WHERE id = ?`,
            [id],
            (err, product) => {
                if (err) {
                    console.error('檢查商品錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                if (!product) {
                    return res.status(404).json({
                        success: false,
                        error: '商品不存在',
                        message: '找不到指定的商品'
                    });
                }

                // 檢查商品是否有任何訂單記錄
                db.get(
                    `SELECT COUNT(*) as total_order_count FROM order_items WHERE product_id = ?`,
                    [id],
                    (orderErr, orderResult) => {
                        if (orderErr) {
                            console.error('檢查訂單錯誤:', orderErr);
                            return res.status(500).json({
                                success: false,
                                error: '服務器錯誤',
                                message: orderErr.message
                            });
                        }

                        const totalOrders = orderResult.total_order_count || 0;
                        const hasOrders = totalOrders > 0;

                        if (hasOrders) {
                            // 有訂單記錄（無論是否結賬），標記為不可用（軟刪除）
                            db.run(
                                `UPDATE products SET is_available = 0 WHERE id = ?`,
                                [id],
                                function (updateErr) {
                                    if (updateErr) {
                                        console.error('標記商品不可用錯誤:', updateErr);
                                        return res.status(500).json({
                                            success: false,
                                            error: '服務器錯誤',
                                            message: updateErr.message
                                        });
                                    }

                                    // 創建審計日誌
                                    authMiddleware.createAuditLog(req.employee.id, 'product_disable', `標記商品不可用: ${product.name} (${product.category}) - 因有訂單記錄，商品已停用`, ipAddress);

                                    res.json({
                                        success: true,
                                        message: '商品已停用（因有訂單記錄，無法完全刪除）',
                                        disabled: true
                                    });
                                }
                            );
                        } else {
                            // 沒有訂單，可以安全刪除
                            db.run(
                                `DELETE FROM products WHERE id = ?`,
                                [id],
                                function (deleteErr) {
                                    if (deleteErr) {
                                        console.error('刪除商品錯誤:', deleteErr);
                                        return res.status(500).json({
                                            success: false,
                                            error: '服務器錯誤',
                                            message: deleteErr.message
                                        });
                                    }

                                    if (this.changes === 0) {
                                        return res.status(404).json({
                                            success: false,
                                            error: '商品不存在',
                                            message: '找不到指定的商品'
                                        });
                                    }

                                    // 創建審計日誌
                                    authMiddleware.createAuditLog(req.employee.id, 'product_delete', `刪除商品: ${product.name} (${product.category})`, ipAddress);

                                    res.json({
                                        success: true,
                                        message: '商品刪除成功',
                                        deleted: true
                                    });
                                }
                            );
                        }
                    }
                );
            }
        );
    } catch (error) {
        console.error('刪除商品錯誤:', error);
        res.status(500).json({
            success: false,
            error: '刪除商品失敗',
            message: error.message
        });
    }
});


module.exports = router;