const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');

/**
 * @route POST /api/auth/login
 * @desc 員工登入
 * @access Public
 */
router.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const ipAddress = req.ip || req.connection.remoteAddress;

        console.log('登入嘗試:', { username, ipAddress });

        if (!username || !password) {
            return res.status(400).json({
                success: false,
                error: '缺少必要字段',
                message: '請提供用戶名和密碼'
            });
        }

        // 查找員工（不區分大小寫）
        db.get(
            `SELECT * FROM employees WHERE LOWER(username) = LOWER(?)`,
            [username],
            async (err, employee) => {
                if (err) {
                    console.error('查詢員工錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                if (!employee) {
                    // 創建審計日誌（登入失敗）
                    authMiddleware.createAuditLog(null, 'login_failed', `用戶名不存在: ${username}`, ipAddress);

                    return res.status(401).json({
                        success: false,
                        error: '登入失敗',
                        message: '用戶名或密碼不正確'
                    });
                }

                if (employee.is_active !== 1) {
                    authMiddleware.createAuditLog(employee.id, 'login_failed', '帳戶已停用', ipAddress);

                    return res.status(403).json({
                        success: false,
                        error: '帳戶已停用',
                        message: '您的帳戶已被停用，請聯繫管理員'
                    });
                }

                // 驗證密碼
                const isPasswordValid = await bcrypt.compare(password, employee.password_hash);
                if (!isPasswordValid) {
                    authMiddleware.createAuditLog(employee.id, 'login_failed', '密碼不正確', ipAddress);

                    return res.status(401).json({
                        success: false,
                        error: '登入失敗',
                        message: '用戶名或密碼不正確'
                    });
                }

                // 生成會話令牌
                const sessionId = uuidv4();
                const token = uuidv4(); // 使用UUID作為令牌
                const expiresAt = new Date(Date.now() + 8 * 60 * 60 * 1000); // 8小時後過期

                // 創建會話記錄
                db.run(
                    `INSERT INTO sessions (id, employee_id, token, ip_address, user_agent, expires_at)
                     VALUES (?, ?, ?, ?, ?, ?)`,
                    [
                        sessionId,
                        employee.id,
                        token,
                        ipAddress,
                        req.headers['user-agent'] || '',
                        expiresAt.toISOString()
                    ],
                    (sessionErr) => {
                        if (sessionErr) {
                            console.error('創建會話錯誤:', sessionErr);
                            return res.status(500).json({
                                success: false,
                                error: '服務器錯誤',
                                message: sessionErr.message
                            });
                        }

                        // 更新員工最後登入時間
                        db.run(
                            `UPDATE employees SET last_login = ? WHERE id = ?`,
                            [new Date().toISOString(), employee.id],
                            (updateErr) => {
                                if (updateErr) console.error('更新最後登入時間錯誤:', updateErr);
                            }
                        );

                        // 創建審計日誌（登入成功）
                        authMiddleware.createAuditLog(employee.id, 'login', '登入成功', ipAddress);

                        // 返回成功響應
                        // 設置HTTP Cookie
                        res.cookie('token', token, {
                            httpOnly: true,
                            secure: false, // 局域網使用HTTP，設為false
                            sameSite: 'lax',
                            maxAge: 24 * 60 * 60 * 1000 // 24小時
                            // 注意：不設置domain，讓瀏覽器根據當前訪問的域自動設置
                            // 這支持局域網IP訪問（如 http://192.168.1.100:3000）
                        });

                        res.json({
                            success: true,
                            message: '登入成功',
                            data: {
                                employee: {
                                    id: employee.id,
                                    username: employee.username,
                                    full_name: employee.full_name,
                                    role: employee.role,
                                    email: employee.email,
                                    phone: employee.phone,
                                    store_id: employee.store_id
                                },
                                token,
                                expires_at: expiresAt.toISOString()
                            }
                        });
                    }
                );
            }
        );
    } catch (error) {
        console.error('登入處理錯誤:', error);
        res.status(500).json({
            success: false,
            error: '登入處理失敗',
            message: error.message
        });
    }
});

/**
 * @route POST /api/auth/logout
 * @desc 員工登出
 * @access Private
 */
router.post('/logout', authMiddleware.authenticate, (req, res) => {
    try {
        const { token } = req.session;
        const { employee } = req;
        const ipAddress = req.ip || req.connection.remoteAddress;

        // 刪除會話記錄
        db.run(
            `DELETE FROM sessions WHERE token = ?`,
            [token],
            (err) => {
                if (err) {
                    console.error('刪除會話錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                // 創建審計日誌（登出）
                authMiddleware.createAuditLog(employee.id, 'logout', '登出成功', ipAddress);

                res.json({
                    success: true,
                    message: '登出成功'
                });
            }
        );
    } catch (error) {
        console.error('登出處理錯誤:', error);
        res.status(500).json({
            success: false,
            error: '登出處理失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/auth/me
 * @desc 獲取當前登入員工信息
 * @access Private
 */
router.get('/me', authMiddleware.authenticate, (req, res) => {
    try {
        const { employee } = req;

        db.get(
            `SELECT id, username, full_name, role, email, phone, is_active, last_login, created_at
             FROM employees WHERE id = ?`,
            [employee.id],
            (err, employeeData) => {
                if (err) {
                    console.error('查詢員工信息錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                if (!employeeData) {
                    return res.status(404).json({
                        success: false,
                        error: '員工不存在',
                        message: '員工信息不存在或已被刪除'
                    });
                }

                res.json({
                    success: true,
                    data: employeeData
                });
            }
        );
    } catch (error) {
        console.error('獲取員工信息錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取員工信息失敗',
            message: error.message
        });
    }
});

/**
 * @route POST /api/auth/refresh
 * @desc 刷新會話令牌
 * @access Private
 */
router.post('/refresh', authMiddleware.authenticate, (req, res) => {
    try {
        const { token } = req.session;
        const { employee } = req;
        const ipAddress = req.ip || req.connection.remoteAddress;

        // 生成新令牌
        const newToken = uuidv4();
        const expiresAt = new Date(Date.now() + 8 * 60 * 60 * 1000); // 8小時後過期

        // 更新會話記錄
        db.run(
            `UPDATE sessions SET token = ?, expires_at = ?, ip_address = ?, user_agent = ?
             WHERE token = ?`,
            [
                newToken,
                expiresAt.toISOString(),
                ipAddress,
                req.headers['user-agent'] || '',
                token
            ],
            (err) => {
                if (err) {
                    console.error('更新會話令牌錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                // 創建審計日誌（令牌刷新）
                authMiddleware.createAuditLog(employee.id, 'token_refresh', '會話令牌刷新', ipAddress);

                res.json({
                    success: true,
                    message: '令牌刷新成功',
                    data: {
                        token: newToken,
                        expires_at: expiresAt.toISOString()
                    }
                });
            }
        );
    } catch (error) {
        console.error('刷新令牌錯誤:', error);
        res.status(500).json({
            success: false,
            error: '刷新令牌失敗',
            message: error.message
        });
    }
});

/**
 * @route GET /api/auth/sessions
 * @desc 獲取當前員工的所有會話（可選功能）
 * @access Private
 */
router.get('/sessions', authMiddleware.authenticate, (req, res) => {
    try {
        const { employee } = req;

        db.all(
            `SELECT id, ip_address, user_agent, expires_at, created_at
             FROM sessions WHERE employee_id = ? ORDER BY created_at DESC`,
            [employee.id],
            (err, sessions) => {
                if (err) {
                    console.error('查詢會話列表錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                res.json({
                    success: true,
                    data: sessions
                });
            }
        );
    } catch (error) {
        console.error('獲取會話列表錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取會話列表失敗',
            message: error.message
        });
    }
});

/**
 * @route POST /api/auth/verify-password
 * @desc 驗證當前登入員工的密碼（用於敏感操作確認，如查看統計）
 * @access Private
 */
router.post('/verify-password', authMiddleware.authenticate, async (req, res) => {
    try {
        const { password } = req.body;
        const employeeId = req.employee.id;

        if (!password) {
            return res.status(400).json({
                success: false,
                error: '缺少密碼',
                message: '請提供密碼'
            });
        }

        // 從數據庫獲取員工密碼哈希
        db.get(
            `SELECT password_hash FROM employees WHERE id = ?`,
            [employeeId],
            async (err, employee) => {
                if (err) {
                    console.error('查詢員工密碼錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                if (!employee) {
                    return res.status(404).json({
                        success: false,
                        error: '員工不存在',
                        message: '員工信息不存在'
                    });
                }

                // 驗證密碼
                const isPasswordValid = await bcrypt.compare(password, employee.password_hash);
                if (!isPasswordValid) {
                    return res.status(401).json({
                        success: false,
                        error: '密碼不正確',
                        message: '密碼不正確'
                    });
                }

                res.json({
                    success: true,
                    message: '密碼驗證成功'
                });
            }
        );
    } catch (error) {
        console.error('密碼驗證錯誤:', error);
        res.status(500).json({
            success: false,
            error: '驗證失敗',
            message: error.message
        });
    }
});

module.exports = router;