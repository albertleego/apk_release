/**
 * KPay 卡機收款 Routes（離場機真支付，路線 A：LAN KPOS）
 *
 * POST /api/kpay/pay       啟動 KPOS 收款（pending）→ 前端輪詢 /status
 * POST /api/kpay/callback  KPOS 異步回調（callback-driven 結賬，收銀主機即時見已結賬）
 * GET  /api/kpay/status    查支付狀態（pending 超 65 秒會主動 query）
 * POST /api/kpay/cancel    撤銷進行中嘅支付
 *
 * 付款成功 → processKpayResult()：update kpay_payments → checkoutCustomer()
 *   → 插 transactions(payment_method) → emit checkout-complete / device-control allow-exit /
 *     print-exit-receipt（同 exitRoutes /checkout 形狀一致，收銀主機經 socket 即時更新）。
 */

const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const authMiddleware = require('../middleware/auth');
const storeAwareMiddleware = require('../middleware/store-aware');
const kpayService = require('../services/kpayService');
const dbOps = require('../../database/db');
const { db, checkoutCustomer, getCustomerById, getKpayConfig } = dbOps;
const {
  createKpayPayment,
  updateKpayPayment,
  getKpayPaymentByOutTradeNo,
  getKpayPaymentByCustomer
} = dbOps;

// 軟驗證（有 token 就延長 session，冇就放行）+ 分店上下文（向後兼容）
router.use(authMiddleware.softAuthenticate);
router.use(storeAwareMiddleware.initStoreContext);

// ===== 常數 =====
// 前端付款掣 → KPay paymentType
const PAYMENT_TYPE_MAP = { card: 1, wechat: 2, alipay: 2, fps: 8, payme: 6 };
// KPay payMethod → transactions.payment_method
const PAY_METHOD_MAP = {
  1: 'visa', 2: 'mastercard', 3: 'unionpay', 4: 'wechat', 5: 'alipay',
  6: 'amex', 7: 'diners', 8: 'jcb', 9: 'unionpay_qr', 12: 'payme', 14: 'fps'
};
// 非成功 payResult → 狀態
const FAIL_STATUS_MAP = { '-1': 'timeout', '3': 'failed', '4': 'failed', '5': 'cancelled', '6': 'cancelled' };

let ioInstance = null;

function normalizePaymentType(t) {
  if (typeof t === 'number') return t; // 直接 KPay paymentType
  return PAYMENT_TYPE_MAP[String(t || '').toLowerCase()] || null;
}

function mapPayMethod(payMethod) {
  return PAY_METHOD_MAP[payMethod] || 'kpay';
}

async function clearCheckoutPending(customerId) {
  await new Promise((resolve, reject) => {
    db.run(
      `UPDATE customers SET checkout_pending = 0, checkout_pending_at = NULL WHERE id = ?`,
      [customerId],
      (err) => (err ? reject(err) : resolve())
    );
  });
}

function emitCheckoutEvents(customer, payment) {
  if (!ioInstance) return;
  const payMethod = mapPayMethod(payment.pay_method);
  ioInstance.emit('checkout-complete', {
    customer_id: customer.id,
    table_number: customer.table_number,
    total_amount: payment.amount,
    checkout_time: new Date().toISOString(),
    exit_machine: true,
    payment_method: payMethod
  });
  // 通知門鎖系統允許離開（5 分鐘有效期）
  ioInstance.emit('device-control', {
    device: 'door-lock',
    action: 'allow-exit',
    qr_code: customer.qr_code,
    valid_until: Date.now() + 300000,
    customer_id: customer.id
  });
  // 觸發打印結賬小票
  ioInstance.emit('print-exit-receipt', {
    table_number: customer.table_number,
    qr_code: customer.qr_code,
    total_amount: payment.amount,
    checkout_time: new Date().toLocaleString('zh-TW'),
    transaction_id: payment.out_trade_no
  });
}

/**
 * 處理支付結果（回調 / 主動 query 共用；idempotent 由 call site 保證）
 * @param {Object} payment kpay_payments row
 * @param {Object} result  { payResult, payMethod, transactionNo, refNo, payAmount }
 */
async function processKpayResult(payment, result) {
  const customerId = payment.customer_id;

  if (result.payResult === 2) {
    // 金額校驗（payAmount 12 位零填充）
    const expected = kpayService.formatAmount(payment.amount);
    if (result.payAmount && result.payAmount !== expected) {
      console.error(`[kpay] 金額不符: 期望 ${expected}, 實收 ${result.payAmount}`);
      await updateKpayPayment(payment.out_trade_no, { status: 'failed' });
      await clearCheckoutPending(customerId);
      return { success: false, status: 'failed' };
    }

    await updateKpayPayment(payment.out_trade_no, {
      status: 'success',
      pay_method: result.payMethod || null,
      transaction_no: result.transactionNo || null,
      ref_no: result.refNo || null,
      paid_at: new Date().toISOString()
    });

    const customer = await getCustomerById(customerId);
    if (customer && !customer.is_checked_out) {
      await checkoutCustomer(customerId);
      // 添加交易記錄（payment_method 第一次由離場機填寫）
      db.run(
        `INSERT INTO transactions (id, customer_id, transaction_type, amount, description, payment_method)
         VALUES (?, ?, 'checkout', ?, ?, ?)`,
        [
          uuidv4(),
          customerId,
          payment.amount,
          `離場結賬(KPay ${payment.out_trade_no}) - 桌號 ${customer.table_number}`,
          mapPayMethod(result.payMethod)
        ],
        (err) => { if (err) console.error('[kpay] 添加交易記錄錯誤:', err); }
      );
      emitCheckoutEvents(customer, payment);
    } else {
      console.warn('[kpay] 客人已結賬或不存在，只記錄支付成功:', customerId);
    }
    return { success: true, status: 'success' };
  }

  // 失敗 / 超時 / 撤銷 / 取消
  const status = FAIL_STATUS_MAP[String(result.payResult)] || 'failed';
  await updateKpayPayment(payment.out_trade_no, { status });
  await clearCheckoutPending(customerId);
  return { success: false, status };
}

// ===== 啟動 KPOS 收款 =====
router.post('/pay', async (req, res) => {
  let outTradeNo = null;
  let customerId = null;
  try {
    const { customer_id, payment_type } = req.body;
    if (!customer_id) return res.status(400).json({ error: '請提供客人ID' });
    customerId = customer_id;

    const customer = await getCustomerById(customer_id);
    if (!customer) return res.status(404).json({ error: '客人不存在' });
    if (customer.is_checked_out) return res.status(400).json({ error: '客人已結賬' });

    const storeId = req.storeContext?.store_id || customer.store_id || 'default_store';

    // 已有進行中支付 → 直接回傳，前端恢復輪詢（避免重複開單）
    const latest = await getKpayPaymentByCustomer(customer_id);
    if (latest && latest.status === 'pending') {
      return res.json({ success: true, out_trade_no: latest.out_trade_no, amount: latest.amount, status: 'pending', resumed: true });
    }

    const paymentType = normalizePaymentType(payment_type);
    if (!paymentType) return res.status(400).json({ error: '無效的付款方式' });

    outTradeNo = 'EX' + Date.now() + Math.random().toString(36).slice(2, 6).toUpperCase();
    const amount = customer.total_amount || 0;

    await createKpayPayment({ customerId: customer_id, outTradeNo, amount, paymentType, storeId });

    // 凍結計費：付款期間 billing scheduler 唔好再加時段費
    await new Promise((resolve, reject) => {
      db.run(
        `UPDATE customers SET checkout_pending = 1, checkout_pending_at = ? WHERE id = ?`,
        [new Date().toISOString(), customer_id],
        (err) => (err ? reject(err) : resolve())
      );
    });

    const cfg = await kpayService.getConfig(storeId);
    const result = await kpayService.sales({
      outTradeNo,
      amount,
      paymentType,
      callbackUrl: cfg.callback_url,
      description: `離場結賬 - 桌號 ${customer.table_number}`,
      storeId
    });

    const code = result && (result.code !== undefined ? result.code : result.data?.code);
    // 10000 成功 / 11000 已轉前台收款 → 正常等待付款
    if (code === 10000 || code === 11000 || code === undefined) {
      return res.json({ success: true, out_trade_no: outTradeNo, amount, status: 'pending', mode: cfg.mode });
    }

    // 其他 error code → 標記失敗
    await updateKpayPayment(outTradeNo, { status: 'failed' });
    await clearCheckoutPending(customer_id);
    return res.status(500).json({ error: '啟動收款失敗', kpay_code: code, message: (result && result.message) || 'KPOS 拒絕收款' });
  } catch (error) {
    console.error('[kpay] 啟動支付錯誤:', error);
    // 清理殘留 pending（KPOS 連唔到等情況）
    if (outTradeNo) {
      await updateKpayPayment(outTradeNo, { status: 'failed' }).catch(() => {});
    }
    if (customerId) {
      await clearCheckoutPending(customerId).catch(() => {});
    }
    return res.status(500).json({ error: '啟動支付失敗', message: error.message });
  }
});

// ===== KPOS 異步回調（callback-driven 結賬；唔需要 auth）=====
router.post('/callback', async (req, res) => {
  try {
    const body = req.body || {};
    const outTradeNo = body.outTradeNO || body.out_trade_no;
    if (!outTradeNo) return res.status(400).json({ code: 40004, message: '缺少 outTradeNO' });

    const payment = await getKpayPaymentByOutTradeNo(outTradeNo);
    if (!payment) return res.status(404).json({ code: 40004, message: '未知交易' });

    const storeId = payment.store_id || 'default_store';

    // 驗簽（mock 跳過；lan 用 platformPublicKey）
    const verified = await kpayService.verifyCallback({ headers: req.headers, body, storeId });
    if (!verified) {
      console.warn('[kpay] 回調簽名無效:', outTradeNo);
      return res.status(401).json({ code: 40002, message: '簽名無效' });
    }

    // idempotent：已處理過直接 200（KPOS 會重試最多 3 次）
    if (payment.status === 'success') {
      return res.json({ code: 10000, message: '已處理' });
    }

    await processKpayResult(payment, {
      payResult: body.payResult,
      payMethod: body.payMethod,
      transactionNo: body.transactionNo,
      refNo: body.refNo,
      payAmount: body.payAmount
    });

    return res.json({ code: 10000, message: 'success' });
  } catch (error) {
    console.error('[kpay] 回調處理錯誤:', error);
    return res.status(500).json({ code: 50000, message: error.message });
  }
});

// ===== 查支付狀態 =====
router.get('/status', async (req, res) => {
  try {
    const customer_id = req.query.customer_id || req.body.customer_id;
    if (!customer_id) return res.status(400).json({ error: '請提供客人ID' });

    let payment = await getKpayPaymentByCustomer(customer_id);
    if (!payment) return res.json({ success: true, status: 'none', payment: null });

    // pending 超過 65 秒 → 主動查一次（KPay 上線測試強制要求）
    if (payment.status === 'pending') {
      const created = new Date(payment.created_at).getTime();
      if (Date.now() - created > kpayService.SALES_TIMEOUT_MS) {
        try {
          const qr = await kpayService.query(payment.out_trade_no, payment.store_id || 'default_store');
          const data = qr && (qr.data || qr);
          if (data && data.payResult === 2) {
            await processKpayResult(payment, {
              payResult: 2,
              payMethod: data.payMethod,
              transactionNo: data.transactionNo,
              refNo: data.refNo,
              payAmount: data.payAmount
            });
          } else if (data && data.payResult !== undefined && data.payResult !== 2) {
            await processKpayResult(payment, { payResult: data.payResult });
          }
        } catch (e) {
          console.warn('[kpay] 主動查詢失敗:', e.message);
        }
      }
    }

    const fresh = await getKpayPaymentByCustomer(customer_id);
    return res.json({ success: true, status: fresh ? fresh.status : 'none', payment: fresh });
  } catch (error) {
    console.error('[kpay] 查詢狀態錯誤:', error);
    return res.status(500).json({ error: '查詢支付狀態失敗', message: error.message });
  }
});

// ===== 取消進行中嘅支付 =====
router.post('/cancel', async (req, res) => {
  try {
    const { customer_id } = req.body;
    if (!customer_id) return res.status(400).json({ error: '請提供客人ID' });

    const payment = await getKpayPaymentByCustomer(customer_id);
    if (!payment) return res.status(404).json({ error: '沒有進行中的付款' });
    if (payment.status !== 'pending') {
      return res.json({ success: true, status: payment.status });
    }

    await kpayService.cancel(payment.out_trade_no, payment.out_trade_no, payment.store_id || 'default_store');
    await updateKpayPayment(payment.out_trade_no, { status: 'cancelled' });
    await clearCheckoutPending(customer_id);

    return res.json({ success: true, status: 'cancelled' });
  } catch (error) {
    console.error('[kpay] 取消支付錯誤:', error);
    return res.status(500).json({ error: '取消支付失敗', message: error.message });
  }
});

// ===== 初始化（由 server/index.js 喺 app.set('io') 後調用）=====
// 註冊 mock 回調 handler：mock 模式 sales() 3 秒後觸發，行同一 idempotent 邏輯
function init(io) {
  ioInstance = io;
  kpayService.setMockCallbackHandler(async (payload) => {
    const outTradeNo = payload.outTradeNO;
    const payment = await getKpayPaymentByOutTradeNo(outTradeNo);
    if (!payment || payment.status !== 'pending') return;
    await processKpayResult(payment, payload);
  });
}

router.init = init;
module.exports = router;
