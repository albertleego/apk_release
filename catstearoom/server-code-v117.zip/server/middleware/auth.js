const { db } = require('../../database/db');
const jwt = require('jsonwebtoken');

// Session 有效期（小時）：平板預設 8 小時；阿里雲後台可喺 .env 設 SESSION_TTL_HOURS=720（30 日）
const SESSION_TTL_MS = parseInt(process.env.SESSION_TTL_HOURS || '8', 10) * 60 * 60 * 1000;

/**
 * 身份驗證中間件
 */
const authMiddleware = {
    /**
     * 驗證JWT令牌或API密鑰
     */
    authenticate: (req, res, next) => {
        // 檢查API密鑰（優先於JWT令牌）
        const apiKey = req.headers['x-api-key'] || req.headers['X-API-Key'];
        if (apiKey) {
            // 寬限期 dual-key：ALIYUN_API_KEY（新）+ ALIYUN_API_KEY_OLD（退休中）都接受，
            // 俾平板 self-rollover 過渡期用；全部平板 rollover 完，移除 ALIYUN_API_KEY_OLD 即係退休舊 key
            const validKeys = [process.env.ALIYUN_API_KEY, process.env.API_KEY, process.env.ALIYUN_API_KEY_OLD].filter(Boolean);
            if (validKeys.includes(apiKey)) {
                console.log('authMiddleware: API密鑰驗證成功，路徑:', req.path, '方法:', req.method);
                // 設置一個虛擬員工對象用於同步請求
                req.employee = {
                    id: 'sync_user',
                    username: 'sync_user',
                    full_name: '數據同步用戶',
                    role: 'staff',
                    store_id: 'default_store'
                };
                req.session = {
                    id: 'api_key_session',
                    token: apiKey
                };
                return next();
            } else {
                console.log('authMiddleware: API密鑰驗證失敗，路徑:', req.path);
                return res.status(401).json({
                    success: false,
                    error: '無效的API密鑰',
                    message: '請提供有效的API密鑰'
                });
            }
        }

        // 從Header獲取JWT令牌
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({
                success: false,
                error: '未提供身份驗證令牌',
                message: '請先登入系統'
            });
        }

        const token = authHeader.replace('Bearer ', '');
        console.log('authMiddleware: 驗證令牌，令牌長度:', token.length, '令牌前綴:', token.substring(0, 8), '...', '路徑:', req.path, '方法:', req.method);

        // 先從數據庫會話表中驗證令牌
        db.get(
            `SELECT s.*, e.username, e.full_name, e.role, e.is_active, e.store_id
             FROM sessions s
             JOIN employees e ON s.employee_id = e.id
             WHERE s.token = ? AND s.expires_at > ?`,
            [token, new Date().toISOString()],
            (err, session) => {
                console.log('authMiddleware: 會話查詢結果，錯誤:', err, '會話存在:', !!session, '員工ID:', session?.employee_id, '角色:', session?.role);
                if (err) {
                    console.error('驗證會話錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                if (!session) {
                    console.log('authMiddleware: 會話不存在或已過期，令牌:', token.substring(0, 8) + '...', '當前時間:', new Date().toISOString());
                    return res.status(401).json({
                        success: false,
                        error: '無效或過期的令牌',
                        message: '請重新登入'
                    });
                }

                console.log('authMiddleware: 會話驗證成功，員工:', session.employee_id, '角色:', session.role, '分店:', session.store_id);
                if (session.is_active !== 1) {
                    return res.status(403).json({
                        success: false,
                        error: '帳戶已停用',
                        message: '您的帳戶已被停用，請聯繫管理員'
                    });
                }

                // 將員工信息附加到請求對象
                req.employee = {
                    id: session.employee_id,
                    username: session.username,
                    full_name: session.full_name,
                    role: session.role,
                    store_id: session.store_id
                };
                req.session = {
                    id: session.id,
                    token: session.token
                };

                // 更新會話最後活動時間（可選）
                db.run(
                    `UPDATE sessions SET expires_at = ? WHERE id = ?`,
                    [new Date(Date.now() + SESSION_TTL_MS).toISOString(), session.id],
                    (updateErr) => {
                        if (updateErr) console.error('更新會話時間錯誤:', updateErr);
                    }
                );

                next();
            }
        );
    },

    /**
     * 檢查是否為管理員
     */
    requireAdmin: (req, res, next) => {
        if (req.employee.role !== 'admin') {
            return res.status(403).json({
                success: false,
                error: '權限不足',
                message: '需要管理員權限才能執行此操作'
            });
        }
        next();
    },

    /**
     * 檢查是否為員工（包括管理員）
     */
    requireStaff: (req, res, next) => {
        if (!['admin', 'staff'].includes(req.employee.role)) {
            return res.status(403).json({
                success: false,
                error: '權限不足',
                message: '需要員工權限才能執行此操作'
            });
        }
        next();
    },

    /**
     * 軟驗證中間件：有 token 就驗證並延長 session，沒有/無效就放行
     * 用於收銀系統等需要自動續期但又不阻塞請求的路由
     */
    softAuthenticate: (req, res, next) => {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            req.employee = null;
            return next();
        }

        const token = authHeader.replace('Bearer ', '');
        db.get(
            `SELECT s.*, e.username, e.full_name, e.role, e.is_active, e.store_id
             FROM sessions s
             JOIN employees e ON s.employee_id = e.id
             WHERE s.token = ? AND s.expires_at > ?`,
            [token, new Date().toISOString()],
            (err, session) => {
                if (err || !session) {
                    req.employee = null;
                    return next();
                }

                if (session.is_active !== 1) {
                    req.employee = null;
                    return next();
                }

                req.employee = {
                    id: session.employee_id,
                    username: session.username,
                    full_name: session.full_name,
                    role: session.role,
                    store_id: session.store_id
                };

                // 延長 session 有效期
                db.run(
                    `UPDATE sessions SET expires_at = ? WHERE id = ?`,
                    [new Date(Date.now() + SESSION_TTL_MS).toISOString(), session.id],
                    (updateErr) => {
                        if (updateErr) console.error('更新會話時間錯誤:', updateErr);
                    }
                );

                next();
            }
        );
    },

    /**
     * 生成JWT令牌（可選，當前使用數據庫會話）
     */
    generateToken: (employeeId) => {
        const payload = {
            employeeId,
            timestamp: Date.now()
        };

        // 使用環境變量中的密鑰，如果沒有則使用默認密鑰（僅用於開發）
        const secret = process.env.JWT_SECRET || 'auto-cafe-system-secret-key';
        const expiresIn = '8h';

        return jwt.sign(payload, secret, { expiresIn });
    },

    /**
     * 驗證JWT令牌（可選，當前使用數據庫會話）
     */
    verifyToken: (token) => {
        try {
            const secret = process.env.JWT_SECRET || 'auto-cafe-system-secret-key';
            return jwt.verify(token, secret);
        } catch (error) {
            return null;
        }
    },

    /**
     * 創建審計日誌
     */
    createAuditLog: (employeeId, actionType, actionDetails, ipAddress, storeId = null) => {
        try {
            const logId = require('uuid').v4();
            // 確保 store_id 不為 NULL，使用默認值
            const finalStoreId = storeId || 'default_store';

            db.run(
                `INSERT INTO audit_logs (id, employee_id, action_type, action_details, ip_address, store_id)
                 VALUES (?, ?, ?, ?, ?, ?)`,
                [logId, employeeId, actionType, actionDetails || '', ipAddress || '', finalStoreId],
                (err) => {
                    if (err) {
                        console.error('創建審計日誌錯誤:', err);
                    }
                }
            );
        } catch (error) {
            console.error('創建審計日誌時發生異常（不影響操作）:', error);
        }
    }
};

module.exports = authMiddleware;