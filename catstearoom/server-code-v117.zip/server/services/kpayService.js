/**
 * KPay 智能收款機（KPOS）LAN POS API client —— 路線 A
 *
 * 離場機真支付：本地 server 直接 call 店內 KPOS
 *   http://<kpos-ip>:18080/v2/pos/*
 * 實時桌號數據只留喺本地主機，唔上雲，所以用 LAN POS API（路線 A），唔用 Cloud API。
 *
 * Mock 模式（KPAY_MODE=mock，預設）：
 *   所有操作本地模擬，sales() 3 秒後觸發模擬成功回調（行同一 idempotent callback handler），
 *   用嚟開發/測試離場機成條 UI 流程；攞到真 KPay credentials 同卡機先轉 lan。
 *
 * 簽名規則（SHA256withRSA）：
 *   5 行字串：`POST\n{path}\ntimestamp\nnonceStr\n{json body}\n`（每行以 \n 結尾）
 *   → 用工作私鑰 sign → Base64 → header `signature`
 *   回調驗簽用 platformPublicKey。
 *
 * 參考文檔：https://docs-posserver.kpay-group.com/ （ID: kpay / PW: oL9r8mruJIU）
 */

const crypto = require('crypto');
const { getKpayConfig } = require('../../database/db');

// ===== 配置 =====
const DEFAULT_KPOS_PORT = 18080;
const HTTP_TIMEOUT_MS = 10000; // KPOS 無回應 timeout
const SALES_TIMEOUT_MS = 65000; // KPOS 收款預設 65 秒超時（主動查詢時用）

// 工作密鑰快取（每分店一份；結算/過期後要重簽）
const keyCache = {}; // store_id -> { appPrivateKey, platformPublicKey }

// mock 回調 handler（由 kpayRoutes 註冊，避免 circular dependency）
let _mockCallbackHandler = null;

function setMockCallbackHandler(fn) {
  _mockCallbackHandler = fn;
}

function genNonce() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

// ===== 配置 =====
async function getConfig(storeId) {
  const row = await getKpayConfig(storeId);
  const cfg = {
    mode: (process.env.KPAY_MODE || 'mock'),          // mock | lan
    kpos_ip: process.env.KPAY_KPOS_IP || '192.168.3.200',
    kpos_port: parseInt(process.env.KPAY_KPOS_PORT || String(DEFAULT_KPOS_PORT), 10),
    app_id: process.env.KPAY_APP_ID || '',
    app_secret: process.env.KPAY_APP_SECRET || '',
    callback_url: process.env.KPAY_CALLBACK_URL || ''
  };
  // 分店 kpay_configs 覆寫 .env fallback
  if (row) {
    if (row.mode) cfg.mode = row.mode;
    if (row.kpos_ip) cfg.kpos_ip = row.kpos_ip;
    if (row.kpos_port) cfg.kpos_port = row.kpos_port;
    if (row.app_id) cfg.app_id = row.app_id;
    if (row.app_secret) cfg.app_secret = row.app_secret;
    if (row.callback_url) cfg.callback_url = row.callback_url;
  }
  return cfg;
}

// ===== 金額格式化：12 位零填充最小貨幣單位（$1.00 → "000000000100"）=====
function formatAmount(amount) {
  const cents = Math.round(Number(amount || 0) * 100);
  return String(cents).padStart(12, '0');
}

// ===== 簽名 =====
function buildSignatureContent(method, path, timestamp, nonceStr, body) {
  return `${method}\n${path}\n${timestamp}\n${nonceStr}\n${body}\n`;
}

function signContent(content, privateKey) {
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(content, 'utf8');
  return signer.sign(privateKey, 'base64');
}

function verifyContent(content, signature, publicKey) {
  try {
    const verifier = crypto.createVerify('RSA-SHA256');
    verifier.update(content, 'utf8');
    return verifier.verify(publicKey, signature, 'base64');
  } catch (e) {
    console.error('[kpay] 驗簽錯誤:', e.message);
    return false;
  }
}

// ===== HTTP（仿 aliyunProxyRoutes：global fetch + AbortController timeout）=====
async function httpPost(url, payload, headers) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), HTTP_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...headers },
      body: JSON.stringify(payload),
      signal: controller.signal
    });
    clearTimeout(timer);
    return await res.json();
  } catch (e) {
    clearTimeout(timer);
    if (e.name === 'AbortError') throw new Error(`KPOS 無回應（超過 ${HTTP_TIMEOUT_MS / 1000} 秒）`);
    throw e;
  }
}

async function httpGet(url, headers) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), HTTP_TIMEOUT_MS);
  try {
    const res = await fetch(url, { method: 'GET', headers, signal: controller.signal });
    clearTimeout(timer);
    return await res.json();
  } catch (e) {
    clearTimeout(timer);
    if (e.name === 'AbortError') throw new Error(`KPOS 無回應（超過 ${HTTP_TIMEOUT_MS / 1000} 秒）`);
    throw e;
  }
}

// ===== 簽到：換工作密鑰（appPrivateKey + platformPublicKey）=====
async function sign(storeId) {
  const cfg = await getConfig(storeId);
  if (cfg.mode === 'mock') {
    return { appPrivateKey: 'mock-private-key', platformPublicKey: 'mock-public-key' };
  }
  if (keyCache[storeId]) return keyCache[storeId];
  if (!cfg.app_id || !cfg.app_secret) {
    throw new Error('KPay 未配置：缺少 appId/appSecret');
  }
  const timestamp = Date.now();
  const nonceStr = genNonce();
  const path = '/v2/pos/sign';
  const payload = { appId: cfg.app_id, appSecret: cfg.app_secret, timestamp, nonceStr };
  const bodyStr = JSON.stringify(payload);
  const signature = signContent(buildSignatureContent('POST', path, timestamp, nonceStr, bodyStr), cfg.app_secret);

  const result = await httpPost(`http://${cfg.kpos_ip}:${cfg.kpos_port}${path}`, payload, {
    appId: cfg.app_id,
    timestamp: String(timestamp),
    nonceStr,
    signature
  });

  if (!result || !result.appPrivateKey || !result.platformPublicKey) {
    throw new Error('KPay 簽到失敗: ' + JSON.stringify(result));
  }
  keyCache[storeId] = {
    appPrivateKey: result.appPrivateKey,
    platformPublicKey: result.platformPublicKey
  };
  return keyCache[storeId];
}

function clearKeys(storeId) {
  delete keyCache[storeId];
}

// ===== 消費（KPOS 彈收款畫面）=====
// 回 code：10000 成功、11000 已轉前台收款（正常等待付款）、40001/40002/40004 認證/簽名/密鑰問題、50002 終端忙碌
async function sales({ outTradeNo, amount, paymentType, callbackUrl, description, storeId }) {
  const cfg = await getConfig(storeId);

  if (cfg.mode === 'mock') {
    // mock：3 秒後模擬成功回調（行同一 idempotent callback handler）
    console.log(`[kpay][mock] 模擬收款: outTradeNo=${outTradeNo}, amount=${amount}, paymentType=${paymentType}`);
    if (_mockCallbackHandler) {
      setTimeout(() => {
        _mockCallbackHandler({
          outTradeNO: outTradeNo,
          payAmount: formatAmount(amount),
          payResult: 2, // 成功
          payMethod: 0,
          transactionNo: 'MOCK-TXN-' + Date.now(),
          refNo: 'MOCK-REF-' + Date.now(),
          storeId
        }).catch(err => console.error('[kpay][mock] 模擬回調處理錯誤:', err));
      }, 3000);
    }
    return { code: 11000, data: { outTradeNo, status: 'PAYING' } };
  }

  const keys = await sign(storeId);
  const timestamp = Date.now();
  const nonceStr = genNonce();
  const path = '/v2/pos/sales';
  const payload = {
    outTradeNo,
    memberCode: cfg.app_id,
    description: description || '自動咖啡館離場結賬',
    payAmount: formatAmount(amount),
    tipsAmount: formatAmount(0),
    paymentType,
    payCurrency: '344', // HKD
    callbackUrl,
    includeReceipt: false,
    hideRetryButton: false,
    frontCamera: true,
    qrCodeContent: ''
  };
  const bodyStr = JSON.stringify(payload);
  const signature = signContent(buildSignatureContent('POST', path, timestamp, nonceStr, bodyStr), keys.appPrivateKey);

  return httpPost(`http://${cfg.kpos_ip}:${cfg.kpos_port}${path}`, payload, {
    appId: cfg.app_id,
    timestamp: String(timestamp),
    nonceStr,
    signature
  });
}

// ===== 主動查詢（65 秒內收唔到回調要 query；KPay 上線測試強制要求）=====
async function query(outTradeNo, storeId) {
  const cfg = await getConfig(storeId);
  if (cfg.mode === 'mock') {
    return { code: 20011, data: { outTradeNo, status: 'PAYING' } };
  }
  const keys = await sign(storeId);
  const timestamp = Date.now();
  const nonceStr = genNonce();
  const path = '/v2/pos/query?outTradeNo=' + encodeURIComponent(outTradeNo) + '&remote=true';
  const signature = signContent(buildSignatureContent('GET', path, timestamp, nonceStr, ''), keys.appPrivateKey);

  return httpGet(`http://${cfg.kpos_ip}:${cfg.kpos_port}${path}`, {
    appId: cfg.app_id,
    timestamp: String(timestamp),
    nonceStr,
    signature
  });
}

// ===== 撤銷/關閉（未結算先可以撤銷）=====
async function cancel(outTradeNo, originOutTradeNo, storeId) {
  const cfg = await getConfig(storeId);
  if (cfg.mode === 'mock') {
    return { code: 10000, data: { outTradeNo } };
  }
  const keys = await sign(storeId);
  const timestamp = Date.now();
  const nonceStr = genNonce();
  const path = '/v2/pos/sales/cancel';
  const payload = { outTradeNo, originOutTradeNo, nonceStr };
  const bodyStr = JSON.stringify(payload);
  const signature = signContent(buildSignatureContent('POST', path, timestamp, nonceStr, bodyStr), keys.appPrivateKey);

  return httpPost(`http://${cfg.kpos_ip}:${cfg.kpos_port}${path}`, payload, {
    appId: cfg.app_id,
    timestamp: String(timestamp),
    nonceStr,
    signature
  });
}

// ===== 驗回調簽名（KPOS POST 過嚟，必須驗簽）=====
// mock 模式跳過驗簽；lan 模式用 platformPublicKey 驗「POST\n/api/kpay/callback\nts\nnonce\n{body}\n」
async function verifyCallback({ headers, body, storeId }) {
  const cfg = await getConfig(storeId);
  if (cfg.mode === 'mock') return true;
  const keys = await sign(storeId);
  const { signature, timestamp, nonceStr } = headers;
  if (!signature || !timestamp || !nonceStr) return false;
  const content = buildSignatureContent('POST', '/api/kpay/callback', timestamp, nonceStr, JSON.stringify(body));
  return verifyContent(content, signature, keys.platformPublicKey);
}

module.exports = {
  getConfig,
  formatAmount,
  buildSignatureContent,
  signContent,
  verifyContent,
  sign,
  clearKeys,
  sales,
  query,
  cancel,
  verifyCallback,
  setMockCallbackHandler,
  SALES_TIMEOUT_MS
};
