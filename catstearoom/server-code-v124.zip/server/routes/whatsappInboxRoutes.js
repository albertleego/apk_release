// ─────────────────────────────────────────────────────────────
// WhatsApp Cloud API — 收件匣 API
//
// 掛喺 /api/whatsapp/admin（見 server/index.js）。全部經 requireMerchant
// （員工有商家帳號，httpOnly cookie merchant_token）。
//
// ⚠️ 安全鐵律：每個查詢都要用 id **加上** store_id 一併比對，唔可以只用 id。
//    收件匣目前雖然係單一商家，但一旦日後多分店／多號碼，改一改 URL 就會讀到別人嘅對話。
// ─────────────────────────────────────────────────────────────
'use strict';

const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const { Readable } = require('stream');
const { db } = require('../../database/db');
const runtime = require('../config/runtime');
const merchantAuth = require('../middleware/merchantAuth');
const whatsappService = require('../services/whatsappService');
const mediaSvc = require('../services/whatsappQuickReplyMedia');
const inbound = require('../services/whatsappInboundService');
const convState = require('../services/whatsappConversationState');
const hkTime = require('../utils/hongKongTime');

const router = express.Router();

const getStoreId = () => process.env.WHATSAPP_STORE_ID || 'store_1';
const MAX_TEXT_CHARS = parseInt(process.env.WHATSAPP_MAX_CHARS, 10) || 4096;
// ⚠️ Meta 對「媒體訊息」嘅 caption 上限係 1024 字（純文字訊息才係 4096）。
//    帶附件時用呢個上限，否則 Meta 會直接拒絕。
const CAPTION_MAX_WITH_MEDIA = 1024;

/** 純媒體訊息喺對話列表嘅預覽文字 */
function previewForKind(kind) {
    if (kind === 'image') return '[圖片]';
    if (kind === 'video') return '[影片]';
    if (kind === 'document') return '[文件]';
    return '[附件]';
}
const MESSAGE_PAGE = 200;

// ── sqlite3 callback → Promise（跟 merchantChatRoutes.js:41-58 既有慣例）──
function dbRun(sql, params) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function (err) {
            if (err) return reject(err);
            resolve({ changes: this.changes });
        });
    });
}
function dbGet(sql, params) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => (err ? reject(err) : resolve(row)));
    });
}
function dbAll(sql, params) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => (err ? reject(err) : resolve(rows || [])));
    });
}

// ⚠️ requireMerchant 同 resolveActor 已經喺 server/index.js 嘅**資料夾層**掛咗
//    （咁樣先唔會漏掛）。呢度再掛一次係防禦性冗餘 —— requireMerchant 係冪等嘅。
router.use(merchantAuth.requireMerchant);
router.use(merchantAuth.resolveActor);
router.use(merchantAuth.requireSameOrigin);

function fail(res, status, error, extra) {
    return res.status(status).json(Object.assign({ success: false, error }, extra || {}));
}

/** 由 req.actor（職員身分）拎一個人看得明嘅名（無就回空字串） */
function actorNameOf(req) {
    const a = (req && req.actor) || {};
    return String(a.name || a.username || '').trim();
}

/**
 * 目前操作者嘅角色 —— 寫入 `wa_messages.sender_role` 同 `wa_conversations.handle_role`。
 * ⚠️ 一定用 `req.actor`，唔可以用 `req.merchant.role` ——「商家」唔係身分，
 *    而且 `requireActor` 已經保證呢度一定有 actor。
 */
function actorRoleOf(req) {
    return String((req && req.actor && req.actor.role) || '');
}

/** 目前操作者嘅 employee id（寫入 sent_by_employee_id） */
function actorEmployeeIdOf(req) {
    return (req && req.actor && req.actor.employee_id) || null;
}

// ─────────────────────────────────────────────────────────────
// 角色轉換記錄：喺對話串加一行系統訊息（msg_type='system'，前端用灰字顯示）
//
// ⚠️ 只在角色**真正改變**時寫 —— 同一個人連續回覆唔應該每次都加一行。
// ⚠️ **唔可以**更新 last_message_at / last_message_preview：系統訊息唔係
//    「最新訊息」，否則對話清單嘅預覽會被 "assigned to…" 蓋過客人講嘅嘢。
//    亦唔郁 unread_count / is_read。
// ⚠️ `sortBeforeMs` = 呢一行要排喺邊個時間點**之前**。實際會用 sortBeforeMs - 1。
//    一定要由呼叫端指定，唔可以喺呢度用 Date.now() ——
//    訊息嘅 created_at（nowIso）係喺處理器**開頭**就捕獲嘅，等到呢度才
//    Date.now() 已經係之後，記錄就會排喺佢本應解釋嗰條訊息之後。
//      POST：傳緊接嗰條訊息嘅 created_at（令記錄排喺訊息前面）
//      PATCH：傳 Date.now() + 1（冇跟隨訊息，令佢排喺最後）
// ─────────────────────────────────────────────────────────────
async function logRoleChange(convId, waContactId, role, actorName, sortBeforeMs) {
    const when = hkTime.formatHongKongStamp(sortBeforeMs - 1);
    const label = convState.roleLabel(role);
    // bot 就唔需要「(bot)」呢個括號（佢本身就係角色名）
    const who = role === convState.HANDLE_BOT
        ? convState.HANDLE_BOT
        : (String(actorName || '').trim() ? `${String(actorName).trim()} (${label})` : label);
    const iso = new Date(sortBeforeMs - 1).toISOString();
    await dbRun(
        `INSERT INTO wa_messages
           (id, conversation_id, wa_contact_id, direction, msg_type, text_body,
            status, is_auto, sender_role, created_at, updated_at)
         VALUES (?, ?, ?, 'out', 'system', ?, NULL, 0, NULL, ?, ?)`,
        [crypto.randomUUID(), convId, waContactId, `assigned to ${who} at ${when}`, iso, iso]
    );
}

// ─────────────────────────────────────────────────────────────
// GET /me —— 前端 boot() 用嚟判斷登入狀態
// ─────────────────────────────────────────────────────────────
// ⚠️ 呢條**刻意唔加 requireActor** —— 前端就係靠佢知道「未登入職員身分」，
//    再彈相應嘅登入 popup。加咗就會變成登入迴圈（登入頁本身都拿唔到狀態）。
router.get('/me', (req, res) => {
    res.json({
        success: true,
        merchant: req.merchant,
        // 目前操作者：null = 未登入職員身分（唔可以回覆）
        actor: req.actor ? { role: req.actor.role, name: req.actor.name } : null,
        // 只有 admin 可以改設定。「商家」只係第一道閘，唔係身分。
        canManageSettings: Boolean(req.actor && req.actor.role === 'admin'),
        configured: whatsappService.isConfigured(),
        dryRun: runtime.whatsappDryRun(),
        notConfiguredMessage: whatsappService.isConfigured() ? null : whatsappService.notConfiguredMessage(),
    });
});

// ─────────────────────────────────────────────────────────────
// POST /staff-logout —— 登出職員身分（第二道閘）
//
// ⚠️ 一定要有呢條端點：員工登入嘅 `token` cookie 係 **httpOnly**，前端讀唔到，
//    所以呼叫唔到 `/api/auth/logout`（佢要 `Authorization: Bearer`）。
//    唯有由伺服器讀 cookie、刪 session、再清 cookie。
//
// ⚠️ 刻意**唔加 requireActor** —— 身分已經失效（或者根本冇登入）時更要登出得成。
// ⚠️ 清 cookie 嘅選項要同設定時一致（path 預設 '/', httpOnly, sameSite lax），
//    唔一致就清唔走。
// ─────────────────────────────────────────────────────────────
router.post('/staff-logout', (req, res) => {
    const token = merchantAuth.parseCookies(req.headers.cookie)[merchantAuth.STAFF_COOKIE];
    const finish = () => {
        res.clearCookie(merchantAuth.STAFF_COOKIE,
            { path: '/', httpOnly: true, sameSite: 'lax' });
        res.json({ success: true });
    };
    if (!token) return finish();
    db.run(`DELETE FROM sessions WHERE token = ?`, [token], (err) => {
        if (err) console.error('[whatsapp] 登出職員身分失敗:', err.message);
        finish();
    });
});

// ─────────────────────────────────────────────────────────────
// GET /conversations
// ─────────────────────────────────────────────────────────────
router.get('/conversations', merchantAuth.requireActor, async (req, res) => {
    try {
        const filter = req.query.filter === 'all' ? 'all' : 'open';
        let sql = `SELECT c.id, c.last_message_at, c.last_message_preview, c.unread_count,
                          c.window_expires_at, c.status,
                          c.handle_role, c.handle_at, c.handle_status,
                          ct.profile_name, ct.phone_e164
                     FROM wa_conversations c
                     JOIN wa_contacts ct ON ct.id = c.wa_contact_id
                    WHERE c.store_id = ?`;
        if (filter !== 'all') sql += ` AND c.status = 'open'`;
        sql += ` ORDER BY c.last_message_at DESC LIMIT 200`;

        const rows = await dbAll(sql, [getStoreId()]);
        const now = Date.now();
        const muteMs = runtime.whatsappHumanMuteMinutes() * 60 * 1000;

        res.json({
            success: true,
            conversations: rows.map((r) => ({
                id: r.id,
                name: r.profile_name || r.phone_e164 || '未知聯絡人',
                phone: r.phone_e164 || '',
                lastMessageAt: r.last_message_at,
                preview: r.last_message_preview || '',
                unread: r.unread_count || 0,
                windowExpiresAt: r.window_expires_at,
                windowOpen: inbound.windowState(r.window_expires_at, now).open,
                // 負責角色：effectiveRole 係「而家實際上邊個負責」（過咗冷靜期會
                // 自動退回 bot），handleRole 係資料庫入面嘅原值。
                handleRole: r.handle_role || convState.HANDLE_BOT,
                effectiveRole: convState.effectiveRole(r, now, muteMs),
                handleStatus: convState.normalizeStatus(r.handle_status),
                // 24 小時窗關咗而未完結 → expired（計算出嚟，唔係 DB 值）
                effectiveStatus: convState.effectiveStatus(r, now),
            })),
        });
    } catch (e) {
        console.error('[whatsapp] 讀取對話清單失敗:', e.message);
        fail(res, 500, '讀取對話清單失敗');
    }
});

/**
 * 送出範本訊息 —— 24 小時客服窗**外**唯一可以發送嘅方式。
 *
 * ⚠️ 刻意**跳過** 24 小時窗檢查：呢個功能嘅意義正正係窗口關閉之後仲可以
 *    跟進客人，而範本係 Meta 明確允許喺窗口外發送嘅。
 *
 * ⚠️ 一定要先向 Meta 查一次範本清單，確認存在、已批核，並攞返**官方 body
 *    文字**嚟儲存。唔可以用前端傳嚟嘅文字做紀錄 —— 咁對話串就會講大話，
 *    顯示嘅唔係客人真正收到嘅內容，而對話串係事後追查嘅依據。
 *
 * ⚠️ dry-run 下 Meta 查唔到範本，所以照用前端傳嚟嘅文字做顯示
 *    （反正唔會真送出），令整個 UX 喺未拿到憑證時都測得到。
 */
async function sendTemplateMessage(req, res, convId, tplReq) {
    const name = String(tplReq.name || '').trim();
    const language = String(tplReq.language || '').trim();
    const params = Array.isArray(tplReq.params)
        ? tplReq.params.map((p) => String(p == null ? '' : p))
        : [];
    if (!name || !language) return fail(res, 400, '請提供範本名稱與語言');

    const conv = await dbGet(
        `SELECT id, wa_contact_id, handle_status, solved_at, handle_role, handle_at
           FROM wa_conversations WHERE id = ? AND store_id = ?`,
        [convId, getStoreId()]
    );
    if (!conv) return fail(res, 404, '對話不存在');

    const contact = await dbGet(`SELECT id, wa_id FROM wa_contacts WHERE id = ?`, [conv.wa_contact_id]);
    if (!contact) return fail(res, 404, '客人記錄不存在');

    let tpl;
    try {
        const out = await whatsappService.listTemplates();
        if (out.dryRun) {
            tpl = {
                name: name, language: language, status: 'APPROVED',
                components: [{ type: 'BODY', text: String(tplReq.body || '') }],
            };
        } else {
            tpl = (out.data || []).filter((x) => x && x.name === name && x.language === language)[0];
            if (!tpl) return fail(res, 400, '找不到這個範本（名稱或語言不符）');
            const st = String(tpl.status || '').toUpperCase();
            if (st !== 'APPROVED') {
                return fail(res, 400, `範本未獲批核（目前狀態：${st || '未知'}），無法發送`);
            }
        }
    } catch (e) {
        return fail(res, 502, '無法讀取範本清單，請稍後再試');
    }

    const bodyText = whatsappService.templateBodyOf(tpl);
    const need = whatsappService.templateVarCount(bodyText);
    if (params.length !== need) {
        return fail(res, 400, need
            ? `這個範本需要 ${need} 個變數值（收到 ${params.length} 個）`
            : '這個範本不需要變數值');
    }

    const nowIso = new Date().toISOString();
    const messageId = crypto.randomUUID();
    const myRole = actorRoleOf(req);
    const wasSolved = convState.isSolved(conv);
    const prevEffRole = convState.effectiveRole(
        conv, Date.now(), runtime.whatsappHumanMuteMinutes() * 60 * 1000);

    await dbRun(
        `UPDATE wa_conversations
            SET last_message_at = ?, last_message_preview = ?, updated_at = ?,
                handle_role = ?, handle_at = ?, handle_status = ?, solved_at = ?
          WHERE id = ? AND store_id = ?`,
        [nowIso, whatsappService.renderTemplateBody(bodyText, params).slice(0, 120), nowIso,
            myRole, nowIso,
            wasSolved ? convState.STATUS_ACTIVE : convState.normalizeStatus(conv.handle_status),
            wasSolved ? null : (conv.solved_at || null),
            conv.id, getStoreId()]
    );
    if (myRole !== prevEffRole) {
        await logRoleChange(conv.id, conv.wa_contact_id, myRole, actorNameOf(req), Date.parse(nowIso));
    }

    await dbRun(
        `INSERT INTO wa_messages
           (id, conversation_id, wa_contact_id, direction, msg_type, text_body,
            status, sent_by_employee_id, sender_role, created_at, updated_at)
         VALUES (?, ?, ?, 'out', 'template', ?, 'queued', ?, ?, ?, ?)`,
        [messageId, conv.id, conv.wa_contact_id,
            whatsappService.renderTemplateBody(bodyText, params),
            actorEmployeeIdOf(req), myRole, nowIso, nowIso]
    );

    res.json({
        success: true,
        message: {
            id: messageId, direction: 'out', msg_type: 'template',
            text_body: whatsappService.renderTemplateBody(bodyText, params),
            caption: null, media_mime: null, media_filename: null,
            status: 'queued',
            sent_by_employee_id: actorEmployeeIdOf(req),
            sender_role: myRole, created_at: nowIso,
        },
    });

    setImmediate(async () => {
        try {
            const out = await whatsappService.sendTemplate(contact.wa_id,
                { name: name, language: language, bodyParams: params });
            await dbRun(
                `UPDATE wa_messages SET status = 'sent', wa_message_id = ?, updated_at = ? WHERE id = ?`,
                [out.dryRun ? null : out.messageId, new Date().toISOString(), messageId]
            );
        } catch (e) {
            const ambiguous = !e.definitelyNotSent && (Boolean(e.isTimeout) || !e.httpStatus);
            const status = ambiguous ? 'unknown' : 'failed';
            const title = ambiguous
                ? '發送狀態未知，請先確認客人是否已收到，再決定是否需要重試。'
                : whatsappService.describeError(e.apiCode);
            await dbRun(
                `UPDATE wa_messages SET status = ?, error_code = ?, error_title = ?, updated_at = ?
                  WHERE id = ?`,
                [status, e.apiCode || null, title, new Date().toISOString(), messageId]
            ).catch((err) => console.error('[whatsapp] 更新範本訊息狀態時出錯:', err.message));
            console.warn(`[whatsapp] 範本發送失敗 status=${status} code=${e.apiCode || '-'} msg=${e.message}`);
        }
    });
}

// ─────────────────────────────────────────────────────────────
// GET /conversations/:id/messages
// ─────────────────────────────────────────────────────────────
router.get('/conversations/:id/messages', merchantAuth.requireActor, async (req, res) => {
    try {
        const conv = await dbGet(
            `SELECT id, window_expires_at, last_inbound_at, handle_role, handle_at, handle_status, solved_at
               FROM wa_conversations WHERE id = ? AND store_id = ?`,
            [req.params.id, getStoreId()]
        );
        if (!conv) return fail(res, 404, '對話不存在');

        // created_at 就係訊息時間（入站 = WhatsApp 嘅 timestamp；出站 = 送出時間）
        //
        // ⚠️⚠️ 一定要用子查詢先取**最新** MESSAGE_PAGE 條，再正序排。
        //    直接寫 `ORDER BY created_at ASC LIMIT 200` 會取到**最舊**嘅 200 條 ——
        //    超過 200 條嘅對話，商家永遠睇唔到最新嘅訊息，而且畫面完全正常
        //    （只係靜靜少了結尾），極難察覺。
        //    ⚠️ rowid 一定要喺子查詢入面選出嚟（叫 _rid）—— 外層查詢係子查詢嘅
        //       結果集，直接寫 rowid 會話冇呢個欄位。用完喺 JS 度刪走。
        const rows = (await dbAll(
            `SELECT * FROM (
                SELECT rowid AS _rid, id, direction, msg_type, text_body, caption, media_id,
                       media_mime, media_filename, status, error_code, error_title,
                       sent_by_employee_id, sender_role, created_at
                  FROM wa_messages
                 WHERE conversation_id = ?
                 ORDER BY created_at DESC, rowid DESC
                 LIMIT ?
             ) ORDER BY created_at ASC, _rid ASC`,
            [conv.id, MESSAGE_PAGE]
        )).map((m) => { delete m._rid; return m; });

        const state = inbound.windowState(conv.window_expires_at);
        res.json({
            success: true,
            window: {
                open: state.open,
                known: state.known,
                expiresAt: conv.window_expires_at,
                remainingMs: state.remainingMs,
            },
            // 標題欄嘅負責角色／狀態跟呢個回應更新 —— 開住對話時每 5 秒輪詢
            // 就會自動刷新（唔使另外喺對話清單度撈）。
            conversation: {
                id: conv.id,
                handleRole: conv.handle_role || convState.HANDLE_BOT,
                effectiveRole: convState.effectiveRole(conv, Date.now(),
                    runtime.whatsappHumanMuteMinutes() * 60 * 1000),
                handleStatus: convState.normalizeStatus(conv.handle_status),
                effectiveStatus: convState.effectiveStatus(conv, Date.now()),
                solvedAt: conv.solved_at || null,
            },
            // 前端用伺服器時間做倒數基準（手機時鐘唔準會顯示錯窗口）
            serverNow: Date.now(),
            // ⚠️ 標籤只用 sender_role 一個來源（已由遷移回填歷史訊息），
            //    唔好另外用 is_auto 推導 —— 兩套機制講同一件事會漂移。
            messages: rows.map((m) => Object.assign({}, m, { senderRole: m.sender_role || null })),
        });
    } catch (e) {
        console.error('[whatsapp] 讀取訊息失敗:', e.message);
        fail(res, 500, '讀取訊息失敗');
    }
});

// ─────────────────────────────────────────────────────────────
// POST /conversations/:id/messages —— 回覆客人
// ─────────────────────────────────────────────────────────────
router.post('/conversations/:id/messages', merchantAuth.requireActor, async (req, res) => {
    try {
        const text = String((req.body && req.body.text) || '').trim();
        const mediaId = (req.body && req.body.mediaId) || null;
        const tplReq = (req.body && req.body.template) || null;

        // ── 範本訊息：24 小時窗外唯一可以發送嘅方式 ──
        // 行另一條路徑，刻意跳過下面嘅 24 小時窗檢查。
        if (tplReq) {
            if (mediaId) return fail(res, 400, '範本訊息不可附加檔案');
            return sendTemplateMessage(req, res, req.params.id, tplReq);
        }

        // ── 附件（可選）──
        let attachment = null;
        if (mediaId) {
            if (!runtime.whatsappQuickReplyMedia()) return fail(res, 400, '附件功能未開啟');
            const row = await mediaSvc.getMedia(mediaId, getStoreId());
            if (!row) return fail(res, 400, '附件不存在，請重新選擇快捷回覆');
            const full = mediaSvc.absolutePath(row);
            let buf = null;
            try { buf = full ? fs.readFileSync(full) : null; } catch (_) { buf = null; }
            // 檔案缺失要喺呢度就擋，唔好等背景發送時才失敗
            if (!buf || !buf.length) return fail(res, 400, '附件檔案不存在，請重新選擇快捷回覆');
            attachment = { row, buffer: buf };
        }

        // ⚠️ 空白文字 + 附件 = 合法（純媒體訊息，Meta 亦允許）。
        //    只有兩者都冇才擋。
        if (!text && !attachment) return fail(res, 400, '訊息不可為空');

        // ⚠️ 帶附件時上限由 4096 降為 1024（Meta 嘅 caption 限制）
        const cap = attachment ? CAPTION_MAX_WITH_MEDIA : MAX_TEXT_CHARS;
        if (text.length > cap) {
            return fail(res, 400, attachment
                ? `附有附件時，訊息上限為 ${cap} 字（目前 ${text.length} 字）`
                : `訊息過長（上限 ${cap} 字）`);
        }

        const conv = await dbGet(
            `SELECT id, wa_contact_id, window_expires_at, handle_status, solved_at,
                    handle_role, handle_at
               FROM wa_conversations WHERE id = ? AND store_id = ?`,
            [req.params.id, getStoreId()]
        );
        if (!conv) return fail(res, 404, '對話不存在');

        // ⚠️ 24 小時客服窗喺**伺服器端**強制，唔信前端。媒體訊息同文字訊息
        //    走同一道閘 —— 窗口外發媒體一樣會被 Meta 拒。
        const state = inbound.windowState(conv.window_expires_at);
        if (!state.open) {
            return fail(res, 409,
                '已超過 24 小時客服窗口，無法發送自由格式訊息。客人再次發送訊息後即可回覆。',
                { code: 'WINDOW_EXPIRED' });
        }

        const contact = await dbGet(`SELECT id, wa_id FROM wa_contacts WHERE id = ?`, [conv.wa_contact_id]);
        if (!contact) return fail(res, 404, '客人記錄不存在');

        const nowIso = new Date().toISOString();
        const messageId = crypto.randomUUID();
        const employeeId = actorEmployeeIdOf(req);
        const msgType = attachment ? attachment.row.kind : 'text';
        const myRole = actorRoleOf(req);
        const wasSolved = convState.isSolved(conv);
        // 出手之前「實際上邊個負責」—— 用嚟決定要唔要喺對話串加一行角色轉換記錄
        const prevEffRole = convState.effectiveRole(
            conv, Date.now(), runtime.whatsappHumanMuteMinutes() * 60 * 1000);

        // ⚠️⚠️ 順序：**先更新對話（負責角色／狀態），再落訊息**。
        //    反過來嘅話，訊息一旦送出而第二條語句失敗，就會出現
        //    「訊息已發俾客人、但機械人冇被靜音」——客人會同時收到機械人插嘴。
        //    先更新，最壞情況係過度靜音（睇得到、可以手動解除）。
        //
        // ⚠️ 唔可以用 BEGIN/COMMIT 夾埋兩句：所有請求共用同一條 sqlite3 連線，
        //    交易期間其他並行 webhook 事件嘅語句會一齊被 ROLLBACK（入站訊息消失）。
        //    倉庫既有做法係「單一原子 UPDATE + WHERE 條件」。
        // ⚠️⚠️ 「接手角色」用**有守衛嘅獨立 UPDATE**，唔可以同預覽／狀態夾埋
        //     一句無條件寫入。
        //
        //     原因：由上面 SELECT（line 447）到呢一句之間可以隔幾秒 ——
        //     SQLite 嘅 busy_timeout 係 30 秒，寫入可以延遲很久。
        //     無條件覆蓋嘅話，同事喺呢段時間用 PATCH 改成 bot 就會被呢一句
        //     蓋返做 admin，而 logRoleChange 照樣寫「assigned to …」——
        //     結果係「系統訊息話改咗、資料庫冇改到」，自動回覆永遠唔恢復。
        //     2026-09-30 實測撞到（改成 bot 之後傳「1」冇自動回覆）。
        //
        //     守衛「COALESCE(handle_role,'bot') = 讀取時嘅值」保證：
        //       讀取之後冇人改過 → 我接手（原行為不變）
        //       有人改過         → 放棄，尊重較新嘅變更
        const expectedRole = conv.handle_role || convState.HANDLE_BOT;
        const claim = await dbRun(
            `UPDATE wa_conversations
                SET handle_role = ?, handle_at = ?, updated_at = ?
              WHERE id = ? AND store_id = ? AND COALESCE(handle_role, 'bot') = ?`,
            [myRole, nowIso, nowIso, conv.id, getStoreId(), expectedRole]
        );
        const roleClaimed = claim.changes === 1;

        // 預覽同狀態**一定要**更新，唔受上面嘅守衛影響
        await dbRun(
            `UPDATE wa_conversations
                SET last_message_at = ?, last_message_preview = ?, updated_at = ?,
                    handle_status = ?, solved_at = ?
              WHERE id = ? AND store_id = ?`,
            [nowIso, (text || previewForKind(msgType)).slice(0, 120), nowIso,
                // 回覆一個已 Solved 嘅對話 = 佢又活起來
                wasSolved ? convState.STATUS_ACTIVE : convState.normalizeStatus(conv.handle_status),
                wasSolved ? null : (conv.solved_at || null),
                conv.id, getStoreId()]
        );

        // 角色有變（例如 bot → admin）就喺對話串加一行灰字記錄。
        // ⚠️ 一定要 roleClaimed —— 冇接手成功就唔可以寫「assigned to …」，
        //    否則會出現「系統訊息話改咗、但資料庫冇改」嘅假記錄，
        //    令人以為改咗而查唔出。
        // ⚠️ 排喺訊息之前寫，令佢喺對話串入面出現喺嗰條訊息之前。
        if (roleClaimed && myRole !== prevEffRole) {
            // 排喺即將寫入嗰條訊息之前 —— 用 nowIso（訊息嘅 created_at），
            // 唔可以用 Date.now()（嗰時已經係之後）。
            await logRoleChange(conv.id, conv.wa_contact_id, myRole, actorNameOf(req),
                Date.parse(nowIso));
        }
        if (!roleClaimed) {
            console.log(`[whatsapp] 回覆未接手角色（讀取後已被改動）對話=${conv.id.slice(0, 8)}`
                + ` 讀取時=${expectedRole} 我=${myRole}`);
        }

        // 先落庫、後發送 —— 即使發送失敗，訊息都唔會消失，用戶亦睇得到失敗原因。
        // 媒體訊息：文字放 caption（語意正確），text_body 留 NULL。
        await dbRun(
            `INSERT INTO wa_messages
               (id, conversation_id, wa_contact_id, direction, msg_type, text_body, caption,
                media_mime, media_filename, media_size,
                status, sent_by_employee_id, sender_role, created_at, updated_at)
             VALUES (?, ?, ?, 'out', ?, ?, ?, ?, ?, ?, 'queued', ?, ?, ?, ?)`,
            [messageId, conv.id, conv.wa_contact_id, msgType,
                attachment ? null : text,
                attachment ? text : null,
                attachment ? attachment.row.mime : null,
                attachment ? (attachment.row.filename || '') : null,
                attachment ? attachment.row.size_bytes : null,
                employeeId, myRole, nowIso, nowIso]
        );

        // 先回覆前端，發送喺背景做（Graph 可能慢，唔應該 block 用戶）
        res.json({
            success: true,
            message: {
                id: messageId,
                direction: 'out',
                msg_type: msgType,
                text_body: attachment ? null : text,
                caption: attachment ? text : null,
                media_mime: attachment ? attachment.row.mime : null,
                media_filename: attachment ? (attachment.row.filename || '') : null,
                status: 'queued',
                sent_by_employee_id: employeeId,
                sender_role: myRole,
                created_at: nowIso,
            },
        });

        setImmediate(async () => {
            try {
                const out = attachment
                    ? await whatsappService.sendMedia(contact.wa_id, {
                        buffer: attachment.buffer,
                        mime: attachment.row.mime,
                        filename: attachment.row.filename,
                        kind: attachment.row.kind,
                        caption: text,
                    })
                    : await whatsappService.sendText(contact.wa_id, text);
                await dbRun(
                    `UPDATE wa_messages SET status = 'sent', wa_message_id = ?, media_id = ?, updated_at = ? WHERE id = ?`,
                    // dry-run 嘅合成 id 唔入 wa_message_id / media_id（留 null），
                    // 免得同真 id 混在一起，亦唔會有狀態回調對得上。
                    // ⚠️ media_id 寫嘅係 **Meta 嘅 media id** —— 咁樣既有嘅
                    //    GET /media/:messageId 同前端 messageNode 完全唔使改，
                    //    送出後嘅附件就會喺對話串顯示（同入站媒體一致）。
                    [out.dryRun ? null : out.messageId,
                        out.metaMediaId || null,
                        new Date().toISOString(), messageId]
                );
            } catch (e) {
                // 模糊失敗（逾時／網絡中斷）：Graph messages 端點冇冪等鍵，
                // 重試有可能**重複發送**俾客人。所以標 unknown，由人手決定，唔自動重試。
                // 但「肯定冇送出」嘅錯誤要照標 failed —— 嗰種情況叫用戶去
                // 「確認客人有冇收到」係誤導。
                //
                // ⚠️ e.phase === 'upload'（上傳附件失敗）一定要當「肯定未送出」：
                //    第二段從未執行，訊息不可能已到客人手上。唔加呢個條件，
                //    上傳逾時會被誤判為 unknown。
                const ambiguous = !e.definitelyNotSent
                    && e.phase !== 'upload'
                    && (Boolean(e.isTimeout) || !e.httpStatus);
                const status = ambiguous ? 'unknown' : 'failed';
                const title = (e.phase === 'upload' && !e.apiCode)
                    ? '附件上傳失敗，請重試。'
                    : (ambiguous
                        ? '發送狀態未知，請先確認客人是否已收到，再決定是否需要重試。'
                        : whatsappService.describeError(e.apiCode));

                await dbRun(
                    `UPDATE wa_messages SET status = ?, error_code = ?, error_title = ?, updated_at = ?
                      WHERE id = ?`,
                    [status, e.apiCode || null, title, new Date().toISOString(), messageId]
                ).catch((err) => console.error('[whatsapp] 更新失敗狀態時出錯:', err.message));

                // 只記狀態，唔記 token 或訊息全文
                console.warn(`[whatsapp] 發送失敗 status=${status} phase=${e.phase || '-'} code=${e.apiCode || '-'} msg=${e.message}`);
            }
        });
    } catch (e) {
        console.error('[whatsapp] 發送訊息失敗:', e.message);
        fail(res, 500, '發送訊息失敗');
    }
});

// ─────────────────────────────────────────────────────────────
// PATCH /conversations/:id —— 改負責角色 / 訊息狀態
//
// ⚠️ 用 requireMerchant 而**唔係** requireMerchantOwner：呢個係對話層級嘅操作
//    （邊個跟、跟完未），唔係系統設定。officer 將來一樣要可以用。
//    merchantAuth.js 講「新增設定類端點要用 owner」係針對範本／快捷／自動回覆
//    嗰類會改動系統行為嘅設定 —— 呢個唔屬於嗰類。
// ─────────────────────────────────────────────────────────────
router.patch('/conversations/:id', merchantAuth.requireActor, async (req, res) => {
    try {
        const body = req.body || {};
        const hasRole = body.handleRole !== undefined;
        const hasStatus = body.handleStatus !== undefined;
        if (!hasRole && !hasStatus) return fail(res, 400, '請提供 handleRole 或 handleStatus');

        let role = null;
        if (hasRole) {
            role = String(body.handleRole || '').trim();
            if (!convState.HANDLE_ROLES.includes(role)) return fail(res, 400, '負責角色無效');
            // ⚠️ 任何職員身分（admin 或 officer）都可以指派任何負責角色 ——
            //    包括交返俾機械人，或者交俾另一個人（負責人 2026-09-29 指定）。
            //
            // ⚠️ 呢個係**指派邊個跟**，唔係冒認身分：訊息標籤（sender_role）
            //    係發送當時由 req.actor.role 寫入嘅，唔會因為指派而改變。
            //    （原本限制 officer 只可以指派自己，係當時過度保守。）
        }

        let status = null;
        if (hasStatus) {
            status = String(body.handleStatus || '').trim();
            // ⚠️ 'expired' 唔喺 STATUSES 入面 —— 佢係系統按 24 小時窗自動判定嘅，
            //    唔可以手動設定。訊息要講清楚，唔好只回一句「狀態無效」。
            if (status === convState.STATUS_EXPIRED) {
                return fail(res, 400, '「Expired」由系統按 24 小時窗口自動判定，不能手動設定');
            }
            if (!convState.STATUSES.includes(status)) return fail(res, 400, '訊息狀態無效');
        }

        const conv = await dbGet(
            `SELECT id, wa_contact_id, handle_role, handle_at, handle_status, solved_at, window_expires_at
               FROM wa_conversations WHERE id = ? AND store_id = ?`,
            [req.params.id, getStoreId()]
        );
        if (!conv) return fail(res, 404, '對話不存在');

        const nowIso = new Date().toISOString();
        const solved = status === convState.STATUS_SOLVED;
        const prevEffRole = convState.effectiveRole(
            conv, Date.now(), runtime.whatsappHumanMuteMinutes() * 60 * 1000);

        let nextRole, nextAt, nextStatus, nextSolvedAt;
        if (solved) {
            // Solved = 提早結束呢一次 session，同時機械人重新接手。
            // （若同時傳了 handleRole，Solved 會蓋過它 —— 結束就係結束。）
            nextRole = convState.HANDLE_BOT;
            nextAt = null;
            nextStatus = convState.STATUS_SOLVED;
            nextSolvedAt = nowIso;
        } else {
            nextRole = role !== null ? role : (conv.handle_role || convState.HANDLE_BOT);
            // ⚠️ 任何手動操作都刷新 handle_at（「我掂過呢個對話，我仲跟緊」）。
            //    唔刷新嘅話：同事揀 Pending 之後走開 40 分鐘，30 分鐘冷靜期
            //    一到機械人就會插嘴 —— 而 Pending 嘅意思正正係「我跟緊」。
            nextAt = nowIso;
            nextStatus = status !== null ? status : convState.normalizeStatus(conv.handle_status);
            nextSolvedAt = null;
        }

        if (solved) {
            // ⚠️⚠️ 清 session 欄位**只可以喺呢度做**（單一寫入者）。
            //    入訊路徑絕對唔可以清：同一則 webhook payload 嘅多個事件係
            //    並行處理，清 NULL 會抹掉第一條剛 claim 嘅 greeted_at，
            //    令第二條再 claim 成功 → 客人收到兩次問候語。
            await dbRun(
                `UPDATE wa_conversations
                    SET handle_role = ?, handle_at = NULL, handle_status = 'solved', solved_at = ?,
                        greeted_at = NULL, fallback_sent_at = NULL, auto_keywords_sent = NULL,
                        updated_at = ?
                  WHERE id = ? AND store_id = ?`,
                [nextRole, nextSolvedAt, nowIso, conv.id, getStoreId()]
            );
        } else {
            await dbRun(
                `UPDATE wa_conversations
                    SET handle_role = ?, handle_at = ?, handle_status = ?, solved_at = NULL, updated_at = ?
                  WHERE id = ? AND store_id = ?`,
                [nextRole, nextAt, nextStatus, nowIso, conv.id, getStoreId()]
            );
        }

        // 角色有變就喺對話串加一行灰字記錄。
        // PATCH 冇跟隨嘅訊息 → 傳 now+1 令記錄排喺最後。
        if (nextRole !== prevEffRole) {
            // ⚠️ 一定要寫日誌。2026-09-30 查「改成 bot 但自動回覆冇恢復」時，
            //    完全冇任何記錄講「邊個喺幾時改過角色」，只能靠翻 wa_messages
            //    嘅 system 行反推，而且反推唔到。加咗呢行就一次查得出。
            console.log(`[whatsapp] 角色變更 ${prevEffRole} → ${nextRole}`
                + `（PATCH 對話=${conv.id.slice(0, 8)} 操作者=${actorNameOf(req) || '?'}`
                + `${solved ? ' solved' : ''}）`);
            await logRoleChange(conv.id, conv.wa_contact_id, nextRole, actorNameOf(req),
                Date.now() + 1);
        }

        res.json({
            success: true,
            conversation: {
                id: conv.id,
                handleRole: nextRole,
                effectiveRole: convState.effectiveRole(
                    { handle_role: nextRole, handle_at: nextAt }, Date.now(),
                    runtime.whatsappHumanMuteMinutes() * 60 * 1000),
                handleStatus: nextStatus,
                // ⚠️ 一定要回傳計算後嘅狀態：若 24 小時窗已經關咗，即使商家啱啱
                //    揀咗 Active，實際顯示仍然係 Expired。冇呢個欄位前端就會
                //    停留在一個伺服器其實冇接受嘅值。
                effectiveStatus: convState.effectiveStatus(
                    { handle_status: nextStatus, window_expires_at: conv.window_expires_at }, Date.now()),
                solvedAt: nextSolvedAt,
            },
        });
    } catch (e) {
        console.error('[whatsapp] 更新對話狀態失敗:', e.message);
        fail(res, 500, '操作失敗');
    }
});

// ─────────────────────────────────────────────────────────────
// POST /conversations/:id/read —— 清除未讀
// ─────────────────────────────────────────────────────────────
router.post('/conversations/:id/read', merchantAuth.requireActor, async (req, res) => {
    try {
        const conv = await dbGet(
            `SELECT id FROM wa_conversations WHERE id = ? AND store_id = ?`,
            [req.params.id, getStoreId()]
        );
        if (!conv) return fail(res, 404, '對話不存在');

        const nowIso = new Date().toISOString();
        await dbRun(`UPDATE wa_conversations SET unread_count = 0, updated_at = ? WHERE id = ?`, [nowIso, conv.id]);
        await dbRun(`UPDATE wa_messages SET is_read = 1 WHERE conversation_id = ? AND direction = 'in'`, [conv.id]);

        res.json({ success: true });
    } catch (e) {
        console.error('[whatsapp] 清除未讀失敗:', e.message);
        fail(res, 500, '操作失敗');
    }
});

// ─────────────────────────────────────────────────────────────
// GET /media/:messageId —— 媒體代理
//
// 即時向 Graph 取並**串流**回瀏覽器，唔落磁碟。
// 生產機得 1 核 / 3.4GB 無 swap 而且曾經寫爆磁碟，媒體累積係最容易重演嘅風險。
// ─────────────────────────────────────────────────────────────
router.get('/media/:messageId', merchantAuth.requireActor, async (req, res) => {
    try {
        const row = await dbGet(
            `SELECT m.media_id, m.media_mime, m.media_filename
               FROM wa_messages m
               JOIN wa_conversations c ON c.id = m.conversation_id
              WHERE m.id = ? AND c.store_id = ?`,
            [req.params.messageId, getStoreId()]
        );
        if (!row || !row.media_id) return fail(res, 404, '找不到媒體檔案');

        let handle;
        try {
            handle = await whatsappService.openMediaStream(row.media_id);
        } catch (e) {
            if (e.tooLarge) return fail(res, 413, '檔案過大，無法顯示');
            console.warn('[whatsapp] 取得媒體失敗:', e.message);
            // Meta 嘅 media id 約 30 天後失效
            return fail(res, 502, '無法取得媒體檔案（可能已超過 WhatsApp 的保存期限）');
        }

        res.set('Content-Type', (handle.info && handle.info.mime_type) || row.media_mime || 'application/octet-stream');
        res.set('Cache-Control', 'private, max-age=300');
        if (row.media_filename) {
            const safeName = String(row.media_filename).replace(/[^\w.\-一-龥]/g, '_');
            res.set('Content-Disposition', `inline; filename="${safeName}"`);
        }

        res.on('close', handle.cleanup);
        Readable.fromWeb(handle.upstream.body).pipe(res);
    } catch (e) {
        console.error('[whatsapp] 媒體代理失敗:', e.message);
        if (!res.headersSent) fail(res, 500, '讀取媒體失敗');
    }
});

module.exports = router;
