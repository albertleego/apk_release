// ─────────────────────────────────────────────────────────────
// RUNNING_MODE 正式化 config module（Phase 2）
// 同一份 codebase，用 RUNNING_MODE 決定環境角色：
//   BACKEND  = 阿里雲後台（開後台功能：group-booking / hot-fix admin / mc-report / 跨店）
//   EDGE     = 店舖平板（開營運功能；後台功能全部關）—— 預設
//
// 規則（安全原則：確保平板行為不變）：
// 1. 預設（RUNNING_MODE 冇 set 或 = EDGE）＝ 平板行為，所有 ENABLE_* flag 預設 OFF
// 2. 顯式 env 永遠蓋過 mode 預設（例：BACKEND 想關 group-booking → ENABLE_GROUP_BOOKING=off）
// 3. 加新 feature flag 只改呢個檔 + 對應 use 位置，code 唔會再散落 env 檢查
// ─────────────────────────────────────────────────────────────

const path = require('path');

const MODE = (process.env.RUNNING_MODE || 'EDGE').trim().toUpperCase();

// 每種 mode 預設開嘅 feature flags
const MODE_DEFAULTS = {
    BACKEND: {   // 阿里雲後台：開後台功能（對應 Aliyun 而家 .env 手動 set 嘅 flags）
        ENABLE_GROUP_BOOKING: true,      // 包場 / 預訂食物
        ENABLE_HOT_FIX_ADMIN: true,      // hot-fix admin toggle（直接讀寫本地 DB + file）
        ENABLE_FEEDBACK_SEARCH: true,    // 神秘顧客 feedback 搜尋 + mc-report 頁
        ALLOW_CROSS_STORE_ADMIN: true,   // admin 跨分店加商品
        // Merchant 登入「第一道大門」：BACKEND 最外層額外閘。預設 OFF（CLAUDE.md：
        // 商家特定功能收 flag、預設 OFF）。想開嘅 merchant server 喺 .env set ENABLE_MERCHANT_GATE=on
        // （要 DB 先有 role='merchant' 帳，否則成個後台鎖死，所以唔可以 mode 預設 on）。
        ENABLE_MERCHANT_GATE: false,
    },
    EDGE: {      // 店舖平板：後台功能全部關（同而家行為完全一致）；merchant 閘亦唔會開
        ENABLE_GROUP_BOOKING: false,
        ENABLE_HOT_FIX_ADMIN: false,
        ENABLE_FEEDBACK_SEARCH: false,
        ALLOW_CROSS_STORE_ADMIN: false,
        ENABLE_MERCHANT_GATE: false,
    },
};

const VALID_MODES = ['BACKEND', 'EDGE'];
const normalizedMode = VALID_MODES.includes(MODE) ? MODE : 'EDGE';

/**
 * 讀 feature flag：顯式 env（on / true / 1）蓋過 mode 預設；冇 set 用 mode 預設
 */
function isFlag(name) {
    const envVal = process.env[name];
    if (envVal !== undefined && envVal.trim() !== '') {
        return ['on', 'true', '1'].includes(envVal.trim().toLowerCase());
    }
    const modeDefault = MODE_DEFAULTS[normalizedMode] && MODE_DEFAULTS[normalizedMode][name];
    return !!modeDefault;
}

// 商家 → 對外 HTTPS domain（EDGE 更新代理來源）
// 優先序：RELEASE_BASE_URL（.env）> MERCHANT_DOMAINS[merchant] > DEFAULT_RELEASE_DOMAIN
// ⚠️ 商家域名屬「商家定制」：master 保持空表；商家條目喺 catstearoom（或該商家）branch 加。
const MERCHANT_DOMAINS = {
    catstearoom: 'https://catstearoom.dev',
};

// 通用版（master）自用 domain；商家 branch 可用自己嘅 DEFAULT_RELEASE_DOMAIN 覆蓋
const DEFAULT_RELEASE_DOMAIN = 'https://catstearoom.dev';

/**
 * 解析 release 代理來源 domain（EDGE 更新用）
 * @param {string} merchant 商家 slug（APK 更新請求已帶 ?merchant=）
 */
function releaseBaseUrl(merchant) {
    const env = (process.env.RELEASE_BASE_URL || '').trim();
    if (env) return env.replace(/\/+$/, '');
    const key = String(merchant || '').trim();
    const dom = MERCHANT_DOMAINS[key] || DEFAULT_RELEASE_DOMAIN;
    return dom ? String(dom).replace(/\/+$/, '') : '';
}

module.exports = {
    MODE: normalizedMode,
    isBackend: normalizedMode === 'BACKEND',
    isEdge: normalizedMode !== 'BACKEND',
    isFlag,
    releaseBaseUrl,
    // 常用 flag shortcut（保持 use 位置可讀）
    groupBooking: () => isFlag('ENABLE_GROUP_BOOKING'),
    hotFixAdmin: () => isFlag('ENABLE_HOT_FIX_ADMIN'),
    feedbackSearch: () => isFlag('ENABLE_FEEDBACK_SEARCH'),
    crossStoreAdmin: () => isFlag('ALLOW_CROSS_STORE_ADMIN'),
    merchantGate: () => isFlag('ENABLE_MERCHANT_GATE'),
    // Release 檔案目錄（僅 BACKEND 使用）：預設專案根 apk_release/，可用 APK_RELEASE_DIR 覆寫
    releaseBaseDir: () => process.env.APK_RELEASE_DIR || path.join(__dirname, '..', '..', 'apk_release'),
};
