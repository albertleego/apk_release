// 設置香港時區 (UTC+8)
process.env.TZ = 'Asia/Hong_Kong';

// 加載環境變量（支援多個路徑：CWD、~/、專案根目錄）
const path = require('path');
require('dotenv').config();
require('dotenv').config({ path: path.resolve(__dirname, '..', '..', '.env') });
require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

// 重啟觸發：環境變量更新

// 初始化檔案 Logger（攔截 console.log/error 輸出到 logs/ 目錄）
const Logger = require('./utils/logger');
const logger = new Logger({
  storeName: process.env.STORE_NAME || process.env.STORE_ID || 'unknown'
});
Logger.setShared(logger); // 畀 store-aware middleware 動態切換分店 log

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const os = require('os');
const fs = require('fs');
const https = require('https');
const crypto = require('crypto');
const { createServer } = require('http');
const { Server } = require('socket.io');
const net = require('net');

// 全域異常處理
process.on('uncaughtException', (error) => {
    console.error('=== 未捕獲的異常 ===');
    console.error('錯誤:', error);
    console.error('堆疊:', error.stack);
    console.error('發生時間:', new Date().toISOString());
    console.error('=== 未捕獲的異常結束 ===');
    // 不退出進程，讓錯誤處理中間件處理
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('=== 未處理的 Promise 拒絕 ===');
    console.error('原因:', reason);
    console.error('Promise:', promise);
    console.error('發生時間:', new Date().toISOString());
    console.error('=== 未處理的 Promise 拒絕結束 ===');
});

// 優雅關閉：先 checkpoint WAL 再退出，避免資料遺失
function gracefulShutdown(signal) {
  console.log(`收到 ${signal} 信號，正在優雅關閉...`);
  const forceExit = setTimeout(() => {
    console.error('優雅關閉超時，強制退出');
    process.exit(1);
  }, 10000);

  try {
    db.db.run('PRAGMA wal_checkpoint(TRUNCATE)', (err) => {
      if (err) {
        console.error('WAL checkpoint 錯誤:', err.message);
      } else {
        console.log('WAL checkpoint 完成，資料已寫入主檔');
      }
      clearTimeout(forceExit);
      httpServer.close(() => {
        console.log('HTTP 伺服器已關閉');
        process.exit(0);
      });
    });
  } catch (error) {
    clearTimeout(forceExit);
    console.error('優雅關閉錯誤:', error);
    process.exit(1);
  }
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// 導入路由
const entryRoutes = require('./routes/entryRoutes');
const cashierRoutes = require('./routes/cashierRoutes');
const vendingRoutes = require('./routes/vendingRoutes');
const exitRoutes = require('./routes/exitRoutes');
const lockRoutes = require('./routes/lockRoutes');
const lockerRoutes = require('./routes/lockerRoutes');
const receiptRoutes = require('./routes/receiptRoutes');
const authRoutes = require('./routes/authRoutes');
const employeeRoutes = require('./routes/employeeRoutes');
const productRoutes = require('./routes/productRoutes');
const inventoryRoutes = require('./routes/inventoryRoutes');
const auditRoutes = require('./routes/auditRoutes');
const reportRoutes = require('./routes/reportRoutes');
const holidaysRoutes = require('./routes/holidaysRoutes');
const storeRoutes = require('./routes/storeRoutes');
// RUNNING_MODE 正式化 config（Phase 2）：BACKEND=阿里雲後台 / EDGE=店舖平板
const runtime = require('./config/runtime');

// ALIYUN_SERVER 遷移（EDGE 平板 :3000 → :3002）：趁 module load 最早期行（dotenv 已載入），
// 確保底下所有 module-scope 用 ALIYUN_SERVER 起嘅 const（例 HOT_FIX_SERVER）同 uploader 都攞到新址。
// 定義喺下面 writeEnvKey 附近（function declaration 會 hoist）。失敗唔阻啟動。catstearoom 專用，唔 sync master。
try { migrateAliyunServer(); } catch (e) { console.warn('[server-migrate] 遷移失敗（唔阻啟動）:', e.message); }

// Booking / Waitinglist 角色（D 類「阿里雲唯一源頭」）：
// BACKEND mode（阿里雲）→ 直接執行規則嘅權威版（bookingRoutesBackend / waitinglistRoutesBackend）
// EDGE mode（平板，預設）→ 維持而家嘅 relay 版（forward 去阿里雲執行）
const bookingRoutes = runtime.isBackend
    ? require('./routes/bookingRoutesBackend')
    : require('./routes/bookingRoutes');
const waitinglistRoutes = runtime.isBackend
    ? require('./routes/waitinglistRoutesBackend')
    : require('./routes/waitinglistRoutes');
const twilioRoutes = require('./routes/twilioRoutes');
const aliyunProxyRoutes = require('./routes/aliyunProxyRoutes');
const logRoutes = require('./routes/logUploadRoutes');
const kpayRoutes = require('./routes/kpayRoutes');

// 導入數據庫
const bookingConfigRoutes = require('./routes/bookingConfigRoutes');
const authMiddleware = require('./middleware/auth');
const db = require('../database/db');

// 導入結賬單據上傳服務
const BillUploadService = require('../bill-upload-service');

// 初始化應用
const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// 中間件
app.use(cors({
    origin: function(origin, callback) {
        // 允許的來源列表
        const allowedOrigins = [
            // 公網ECS服務器
            'http://47.239.121.13',

            // 其他允許來源（阿里雲後台域名等），用逗號分隔寫入 CORS_EXTRA_ORIGINS
            ...(process.env.CORS_EXTRA_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean),

            // 本地開發環境（支持多端口）
            /^http:\/\/(localhost|127\.0\.0\.1)(?::\d+)?$/,
            'http://localhost:3000',
            'http://127.0.0.1:3000',
            'http://localhost:3001',
            'http://127.0.0.1:3001',
            'http://localhost:3002',
            'http://127.0.0.1:3002',

            // 局域網IP段（動態匹配，支持任意端口）
            /^http:\/\/192\.168\.\d+\.\d+(?::\d+)?$/,    // 192.168.x.x
            /^http:\/\/10\.\d+\.\d+\.\d+(?::\d+)?$/,     // 10.x.x.x
            /^http:\/\/172\.(1[6-9]|2[0-9]|3[0-1])\.\d+\.\d+(?::\d+)?$/, // 172.16.x.x - 172.31.x.x

            // 允許不帶端口的本地訪問（如直接IP訪問）
            /^http:\/\/(localhost|127\.0\.0\.1)$/,
            /^http:\/\/192\.168\.\d+\.\d+$/,
            /^http:\/\/10\.\d+\.\d+\.\d+$/,
            /^http:\/\/172\.(1[6-9]|2[0-9]|3[0-1])\.\d+\.\d+$/
        ];

        // 如果沒有origin（例如：直接服務器訪問、Postman等工具）
        if (!origin) {
            return callback(null, true);
        }

        // 檢查origin是否在允許列表中
        const isAllowed = allowedOrigins.some(pattern => {
            if (typeof pattern === 'string') {
                return pattern === origin;
            } else if (pattern instanceof RegExp) {
                return pattern.test(origin);
            }
            return false;
        });

        if (isAllowed) {
            callback(null, true);
        } else {
            console.warn('CORS阻止的來源:', origin);
            callback(new Error('CORS不允許的來源'));
        }
    },
    credentials: true,
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
    exposedHeaders: ['Set-Cookie']
}));
// verify hook 儲低 raw body bytes（KPay 回調驗簽要用原 byte，唔可以 re-stringify parse 過嘅 object）
app.use(bodyParser.json({ limit: '50mb', verify: (req, res, buf) => { req.rawBody = buf; } }));
app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.static(path.join(__dirname, '../public')));

// 客戶端靜態文件服務
app.use('/entry-machine', express.static(path.join(__dirname, '../client/entry-machine')));

// 收銀 enhanced-cashier.js：注入 ALIYUN_API_KEY（同 admin-config.html __API_KEY__ 模式一致）
// 由 server .env 單一來源注入，唔使 deploy-time sed；cache 避免每次 request 讀大檔，換 key 後 pm2 restart 生效
let cachedEnhancedCashierJs = null;
app.get('/cashier/enhanced-cashier.js', (req, res) => {
    if (cachedEnhancedCashierJs === null) {
        const filePath = path.join(__dirname, '../client/cashier/enhanced-cashier.js');
        const content = fs.readFileSync(filePath, 'utf8');
        // 注入 ALIYUN_API_KEY（同 admin-config.html __API_KEY__ 模式一致）+ mode flag
        // mode flag：雲端（BACKEND）係數據源頭，client 見到 true 就唔做主數據同步 pull
        cachedEnhancedCashierJs = "window.__AUTO_CAFE_IS_BACKEND__ = " + (runtime.isBackend ? 'true' : 'false') + ";\n"
            + content.replace("ALIYUN_API_KEY = '__API_KEY__'", "ALIYUN_API_KEY = '" + (process.env.ALIYUN_API_KEY || '') + "'");
    }
    res.type('application/javascript').send(cachedEnhancedCashierJs);
});
app.use('/cashier', express.static(path.join(__dirname, '../client/cashier')));
app.use('/vending-machine', express.static(path.join(__dirname, '../client/vending-machine')));
app.use('/exit-machine', express.static(path.join(__dirname, '../client/exit-machine')));
app.use('/booking', express.static(path.join(__dirname, '../client/booking')));

// ─── Group Booking（包場 / 預訂食物）— 阿里雲後台專用，經 ENABLE_GROUP_BOOKING 開 ───
// 平板/預設環境冇開 flag，呢個 block 完全唔註冊，行為同以前一樣
if (runtime.groupBooking()) {
    app.use('/group-booking', express.static(path.join(__dirname, '../group_booking')));
    app.use('/api/booking-config', bookingConfigRoutes);
    app.get('/admin-config', (req, res) => {
        const filePath = path.join(__dirname, '../group_booking/admin-config.html');
        let html = fs.readFileSync(filePath, 'utf8');
        html = html.replace('__API_KEY__', process.env.ALIYUN_API_KEY || '');
        res.send(html);
    });

    // 包場紀錄 Mark Daily（公開，寫入分店 spreadsheet）
    app.post('/api/group-booking/mark-daily', (req, res) => {
        const { store_id, day, month, year, start_time, end_time, people, venue, phone, note } = req.body || {};
        if (!store_id || !day || !month || !year || !start_time || !end_time || !venue) {
            return res.status(400).json({ success: false, error: '缺少必要欄位' });
        }
        const payload = { store_id, day: String(day), month: String(month), year: String(year),
            start_time: String(start_time), end_time: String(end_time), people: String(people || ''),
            venue: String(venue), phone: String(phone || ''), note: String(note || '') };
        const payloadFile = '/tmp/mark_daily_payload.json';
        const scriptPath = path.join(__dirname, '../group_booking/mark_daily_to_sheet.py');
        try {
            fs.writeFileSync(payloadFile, JSON.stringify(payload), 'utf-8');
        } catch (e) {
            return res.status(500).json({ success: false, error: '寫入 payload 失敗: ' + e.message });
        }
        try {
            const stdout = require('child_process').execSync(`python3 "${scriptPath}" "${payloadFile}"`, { encoding: 'utf8', timeout: 30000 });
            let result;
            try {
                result = JSON.parse(stdout.trim());
            } catch (e) {
                return res.status(500).json({ success: false, error: '腳本輸出解析失敗: ' + stdout.substring(0, 300) });
            }
            if (result.success) return res.json(result);
            return res.json(result);
        } catch (e) {
            try {
                const errResult = JSON.parse((e.stdout || '').trim());
                if (errResult && typeof errResult.success === 'boolean') {
                    return res.json(errResult);
                }
            } catch (_) {}
            return res.status(500).json({ success: false, error: '執行腳本失敗: ' + ((e.stderr || e.message || '').toString().substring(0, 300)) });
        }
    });

    // 預訂食物 Mark 食物（公開，寫入「蛋糕預留」分頁）
    app.post('/api/group-booking/mark-food', (req, res) => {
        const { store_short, date, phone, rows } = req.body || {};
        if (!store_short || !date || !rows) {
            return res.status(400).json({ success: false, error: '缺少必要欄位' });
        }
        const payload = { store_short: String(store_short), date: String(date), phone: String(phone || ''), rows };
        const payloadFile = '/tmp/mark_food_payload.json';
        const scriptPath = path.join(__dirname, '../group_booking/mark_food_to_sheet.py');
        try {
            fs.writeFileSync(payloadFile, JSON.stringify(payload), 'utf-8');
        } catch (e) {
            return res.status(500).json({ success: false, error: '寫入 payload 失敗: ' + e.message });
        }
        try {
            const stdout = require('child_process').execSync(`python3 "${scriptPath}" "${payloadFile}"`, { encoding: 'utf8', timeout: 30000 });
            let result;
            try {
                result = JSON.parse(stdout.trim());
            } catch (e) {
                return res.status(500).json({ success: false, error: '腳本輸出解析失敗: ' + stdout.substring(0, 300) });
            }
            if (result.success) return res.json(result);
            return res.json(result);
        } catch (e) {
            try {
                const errResult = JSON.parse((e.stdout || '').trim());
                if (errResult && typeof errResult.success === 'boolean') {
                    return res.json(errResult);
                }
            } catch (_) {}
            return res.status(500).json({ success: false, error: '執行腳本失敗: ' + ((e.stderr || e.message || '').toString().substring(0, 300)) });
        }
    });
}

// ─── 神秘顧客 feedback 搜尋 + mc-report 頁（阿里雲後台專用，經 ENABLE_FEEDBACK_SEARCH 開）───
// 平板/預設環境冇開 flag，呢個 block 完全唔註冊，行為同以前一樣
if (runtime.feedbackSearch()) {
    app.use('/mc-report', express.static(path.join(__dirname, '../client/mc-report')));
    app.post('/api/feedback/search', authMiddleware.authenticate, authMiddleware.requireAdmin, (req, res) => {
        const phone = String((req.body && req.body.phone) || '').trim();
        if (!phone) {
            return res.status(400).json({ success: false, error: '請輸入電話號碼' });
        }
        if (!/^[0-9+\-()\s]{6,20}$/.test(phone)) {
            return res.status(400).json({ success: false, error: '電話號碼格式不正確' });
        }
        const { execFile } = require('child_process');
        // search_feedback.py 跟 merchant folder 走（<merchant>/scripts/），用 __dirname 相對定位，唔硬寫絕對路徑
        const feedbackScript = path.join(__dirname, '..', 'scripts', 'search_feedback.py');
        execFile('/usr/bin/python3',
            [feedbackScript, phone],
            { timeout: 30000, maxBuffer: 16 * 1024 * 1024 },
            (err, stdout, stderr) => {
                if (err) {
                    console.error('[feedback/search] 執行搜尋腳本錯誤:', String(stderr || err.message).substring(0, 400));
                    return res.status(500).json({ success: false, error: '搜尋失敗，請稍後再試', detail: String(stderr || err.message).substring(0, 300) });
                }
                try {
                    const data = JSON.parse(stdout);
                    if (data.error === 'empty_phone') {
                        return res.status(400).json({ success: false, error: '請輸入電話號碼' });
                    }
                    return res.json({
                        success: true,
                        count: data.count || 0,
                        results: data.results || [],
                        errors: data.errors || []
                    });
                } catch (e) {
                    console.error('[feedback/search] 解析腳本輸出失敗:', e.message);
                    return res.status(500).json({ success: false, error: '搜尋結果解析失敗' });
                }
            }
        );
    });
}

// ===== 更新鎖中間件（更新期間阻擋 API 請求）=====
app.use((req, res, next) => {
    // 唔 block update-related endpoints 自己
    if (req.path.startsWith('/api/update/') || req.path === '/api/update-status' || req.path === '/health' || req.path.startsWith('/api/kpay')) {
        return next();
    }
    // check .updating flag file
    if (fs.existsSync(UPDATE_FLAG_FILE)) {
        const stat = fs.statSync(UPDATE_FLAG_FILE);
        const age = Date.now() - stat.mtimeMs;
        // 超過 30 分鐘視為 crash residue，自動清除
        if (age > UPDATE_TIMEOUT_MS) {
            try {
                fs.unlinkSync(UPDATE_FLAG_FILE);
                if (fs.existsSync(BACKUP_DONE_FLAG)) fs.unlinkSync(BACKUP_DONE_FLAG);
                if (fs.existsSync(CP_DONE_FLAG)) fs.unlinkSync(CP_DONE_FLAG);
                logUpdate('更新鎖過期自動清除 (crash residue)', 'WARN');
            } catch (_) {}
            return next();
        }
        return res.status(503).json({
            success: false,
            error: '系統更新中',
            message: '更新期間將不能使用收銀系統，請稍後再試'
        });
    }
    next();
});

// ─── 公開節假日 daytype 查詢 ───
app.get('/api/holidays/public/batch', (req, res) => {
    const { year, month } = req.query;
    const y = parseInt(year) || new Date().getFullYear();
    // 撈成個 year 嘅 holidays rows（override = description 入面帶 "daytype=X" token）
    // 注意：strftime 回傳 TEXT，year 參數要 bind 做 string，bind int 會永遠唔等於（SQLite type ordering）
    db.db.all(
        `SELECT date, description FROM holidays WHERE strftime('%Y', date) = ? ORDER BY date ASC`,
        [String(y)],
        (err, rows) => {
            if (err) return res.status(500).json({ success: false, error: err.message });
            // 建立日期→daytype 對照（從 description 欄位中提取 "daytype=X"）
            const daytypeOverride = {};
            (rows || []).forEach(r => {
                const m = (r.description || '').match(/daytype=([A-Z])/);
                if (m) daytypeOverride[r.date] = m[1];
            });
            // Gate：該 year 一個 daytype override 都冇 → 唔自動 gen 全年，直接 error。
            // 年曆要「主動導入」先有 override；未導入年份報價/日曆要停，唔可以靜靜用每週 default。
            if (Object.keys(daytypeOverride).length === 0) {
                return res.status(422).json({
                    success: false,
                    error: 'DAYTYPE_YEAR_NOT_IMPORTED',
                    message: `${y} 年尚未導入節日/假日資料，請先導入該年`
                });
            }
            const daytypeMap = {};
            // 產生該年所有日期（month query param 只 filter output，gate 永遠睇成個 year）
            const startM = month ? parseInt(month) : 1;
            const endM = month ? parseInt(month) : 12;
            for (let m = startM; m <= endM; m++) {
                const daysInMonth = new Date(y, m, 0).getDate();
                for (let d = 1; d <= daysInMonth; d++) {
                    const ds = y + '-' + String(m).padStart(2,'0') + '-' + String(d).padStart(2,'0');
                    const dow = new Date(ds + 'T00:00+08:00').getDay();
                    let daytype = '';
                    if (daytypeOverride[ds]) daytype = daytypeOverride[ds];
                    else if (dow === 0) daytype = 'U';
                    else if (dow === 6) daytype = 'S';
                    else if (dow === 5) daytype = 'F';
                    daytypeMap[ds] = { daytype, is_holiday: (daytype === 'H' || daytype === 'S' || daytype === 'U' || daytype === 'B') ? 1 : 0 };
                }
            }
            res.json({ success: true, data: daytypeMap });
        }
    );
});

// ─── 公開：最後一個已導入 daytype override 嘅月份（booking 日曆 cap 用）───
app.get('/api/holidays/public/imported-max', (req, res) => {
    db.db.all(`SELECT date, description FROM holidays ORDER BY date ASC`, [], (err, rows) => {
        if (err) return res.status(500).json({ success: false, error: err.message });
        let maxDate = null;
        (rows || []).forEach(r => {
            if ((r.description || '').match(/daytype=([A-Z])/)) {
                if (!maxDate || r.date > maxDate) maxDate = r.date;
            }
        });
        res.json({
            success: true,
            data: {
                maxMonth: maxDate ? maxDate.slice(0, 7) : null
            }
        });
    });
});

// Socket.IO 連接處理
io.on('connection', (socket) => {
  console.log('客戶端連接:', socket.id);

  // 處理設備狀態更新
  socket.on('device-status', (data) => {
    // 廣播設備狀態給所有客戶端
    socket.broadcast.emit('device-update', data);
  });

  // 處理新客人通知
  socket.on('new-customer', (customerData) => {
    // 廣播新客人信息給收銀系統
    socket.broadcast.emit('customer-added', customerData);
  });

  // 處理結賬通知
  socket.on('checkout-complete', (tableData) => {
    // 廣結結賬信息給所有相關設備
    socket.broadcast.emit('table-checked-out', tableData);
  });

  socket.on('disconnect', () => {
    console.log('客戶端斷開:', socket.id);
  });
});

// 將io對象附加到app，方便路由使用
app.set('io', io);
// 初始化 KPay 路由（註冊 mock 回調 handler，用同一 io 對象）
kpayRoutes.init(io);

// 路由
app.use('/api/entry', entryRoutes);
app.use('/api/cashier', cashierRoutes);
app.use('/api/vending', vendingRoutes);
app.use('/api/exit', exitRoutes);
app.use('/api/kpay', kpayRoutes);
app.use('/api/lock', lockRoutes);
app.use('/api/locker', lockerRoutes);
app.use('/api/receipt', receiptRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/employees', employeeRoutes);
app.use('/api/products', productRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/audit-logs', auditRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/holidays', holidaysRoutes);
app.use('/api/stores', storeRoutes);
app.use('/api/sync', require('./routes/syncRoutes'));
app.use('/api', require('./routes/reverseCheckoutRoutes'));
app.use('/api/self-service', require('./routes/selfServiceRoutes'));
app.use('/api/booking', bookingRoutes);
app.use('/api/waitinglist', waitinglistRoutes);
app.use('/api/twilio', twilioRoutes);
app.use('/api/aliyun-proxy', aliyunProxyRoutes);
app.use('/api/logs', logRoutes);

// ----- 分店設定：快速入座（無需開枱 modal）-----
// 唯一源頭喺阿里雲：本地 GET 讀阿里雲，阿里雲 down 先 fallback 本地 JSON
const SKIP_TABLE_CONFIG_FILE = path.join(__dirname, '..', '.skip_table_arrive_config.json');
const SKIP_TABLE_ALIYUN_BASE = (process.env.ALIYUN_SERVER || 'http://47.239.121.13:3000').replace(/\/$/, '');
function readSkipTableConfig() {
    try { return JSON.parse(fs.readFileSync(SKIP_TABLE_CONFIG_FILE, 'utf8') || '{}'); } catch (_) { return {}; }
}
function writeSkipTableConfig(config) {
    fs.writeFileSync(SKIP_TABLE_CONFIG_FILE, JSON.stringify(config), 'utf8');
}

app.get('/api/stores/:storeId/skip-table-arrive', (req, res) => {
    const { storeId } = req.params;
    // BACKEND（阿里雲）自己就係唯一源頭：直接讀本地 config
    // 唔可以 fetch 自己（ALIYUN_SERVER = 自己 → 自我遞歸 + 每層等 5s timeout，實測 5.0s 先返）
    if (runtime.isBackend) {
        const config = readSkipTableConfig();
        return res.json({ success: true, skip_table_on_arrive: !!config[storeId], source: 'backend' });
    }
    // EDGE（平板）：讀阿里雲，阿里雲 down / 超時先 fallback 本地 JSON
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5000);
    fetch(`${SKIP_TABLE_ALIYUN_BASE}/api/stores/${encodeURIComponent(storeId)}/skip-table-arrive`, { signal: controller.signal })
        .then(r => r.json())
        .then(j => {
            clearTimeout(timer);
            res.json({ success: true, skip_table_on_arrive: !!(j && j.success && j.skip_table_on_arrive), source: 'aliyun' });
        })
        .catch(() => {
            clearTimeout(timer);
            const config = readSkipTableConfig();
            res.json({ success: true, skip_table_on_arrive: !!config[storeId], source: 'local' });
        });
});

app.post('/api/stores/:storeId/skip-table-arrive', (req, res) => {
    const { storeId } = req.params;
    const enabled = !!req.body.skip_table_on_arrive;
    const config = readSkipTableConfig();
    config[storeId] = enabled;
    writeSkipTableConfig(config);
    res.json({ success: true, skip_table_on_arrive: enabled });
});

// 客戶端界面路由
app.get('/entry-machine', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/entry-machine/index.html'));
});

app.get('/cashier', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/cashier/index.html'));
});

app.get('/vending-machine', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/vending-machine/index.html'));
});

app.get('/exit-machine', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/exit-machine/index.html'));
});

app.get('/booking', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/booking/index.html'));
});

// 多語言 booking URL redirect
app.get('/:lang/booking', (req, res) => {
  var validLangs = ['en', 'zh-TW', 'zh-CN'];
  if (validLangs.indexOf(req.params.lang) === -1) {
    res.redirect('/booking/');
  } else {
    res.redirect('/booking/?lang=' + req.params.lang);
  }
});

// 主頁面
app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="zh-TW">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>自動咖啡館系統 - 控制面板</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        h1 { color: #333; }
        .dashboard { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-top: 30px; }
        .card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .card h2 { margin-top: 0; color: #444; }
        .card a { display: inline-block; margin-top: 10px; padding: 10px 15px; background: #4CAF50; color: white; text-decoration: none; border-radius: 5px; }
        .card a:hover { background: #45a049; }
      </style>
    </head>
    <body>
      <h1>自動咖啡館系統 - 控制面板</h1>
      <div class="dashboard">
        <div class="card">
          <h2>入場機器</h2>
          <p>客人入場處理界面</p>
          <a href="/entry-machine" target="_blank">打開入場機器</a>
        </div>
        <div class="card">
          <h2>收銀系統</h2>
          <p>員工收銀管理界面</p>
          <a href="/cashier" target="_blank">打開收銀系統</a>
        </div>
        <div class="card">
          <h2>商品售賣機</h2>
          <p>客人購買商品界面</p>
          <a href="/vending-machine" target="_blank">打開售賣機</a>
        </div>
        <div class="card">
          <h2>離場機器</h2>
          <p>客人結賬離場界面</p>
          <a href="/exit-machine" target="_blank">打開離場機器</a>
        </div>
      </div>
    </body>
    </html>
  `);
});

// 健康檢查端點
// 優雅關閉端點：更新 server code 前先呼叫此端點，避免 WAL 損壞
app.post('/api/shutdown', (req, res) => {
  console.log('收到 shutdown 請求，準備優雅關閉...');
  res.json({ success: true, message: '伺服器正在關閉...' });
  // 延遲一點讓 response 送出去
  setTimeout(() => gracefulShutdown('API'), 500);
});

app.get('/health', (req, res) => {
  const homeDir = path.resolve(__dirname, '..');
  const ver = readLocalVersion(homeDir) || process.env.SERVER_VERSION || '18';
  res.json({
    status: 'healthy',
    server_version: String(ver),
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage()
  });
});

// 錯誤處理中間件
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: '伺服器錯誤', message: err.message });
});

// 第二小時自動收費檢查
function startSecondHourScheduler() {
  // 每1分鐘檢查一次
  setInterval(async () => {
    try {
      const now = new Date();

      // 結賬鎖定超時解鎖：鎖定超過5分鐘自動解除（防止店員關閉視窗後卡死計費）
      try {
        await new Promise((resolve, reject) => {
          db.db.run(
            `UPDATE customers SET checkout_pending = 0, checkout_pending_at = NULL
             WHERE checkout_pending = 1 AND checkout_pending_at IS NOT NULL
               AND julianday(checkout_pending_at) < julianday('now', '-5 minutes')`,
            (err) => { if (err) reject(err); else resolve(); }
          );
        });
      } catch (unlockErr) {
        console.error('結賬鎖定超時解鎖錯誤:', unlockErr.message);
      }

      // 查詢所有未結賬的客人（跳過結賬鎖定中的客人，避免確認視窗期間自動加單）
      const customers = await new Promise((resolve, reject) => {
        db.db.all(
          `SELECT c.id, c.people_count, c.entry_time, c.store_id
           FROM customers c
           WHERE c.is_checked_out = 0
             AND (c.checkout_pending IS NULL OR c.checkout_pending = 0)`,
          (err, rows) => {
            if (err) reject(err);
            else resolve(rows);
          }
        );
      });

      for (const customer of customers) {
        try {
          // 計算在場時間（分鐘）
          const entryTime = new Date(customer.entry_time);
          const timeInMinutes = Math.floor((now.getTime() - entryTime.getTime()) / (1000 * 60));

          // 計算應有的次小時商品數量（按時間段累計）
          // 規則：69分鐘內不收次小時，70分鐘起每60分鐘收一次次小時
          let requiredSecondHourCount = 0;
          if (timeInMinutes >= 70) {
            // 公式：floor((總分鐘數 - 70) / 60) + 1
            requiredSecondHourCount = Math.floor((timeInMinutes - 70) / 60) + 1;
          }

          // 檢查是否已經有全日通，如果有則完全跳過自動收費
          const hasDayPass = await new Promise((resolve, reject) => {
            db.db.get(
              `SELECT 1 FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.customer_id = ? AND p.name LIKE '%全日通%'`,
              [customer.id],
              (err, row) => {
                if (err) reject(err);
                else resolve(!!row);
              }
            );
          });

          if (hasDayPass) {
            console.log(`客人 ${customer.id} 已有全日通商品，跳過次小時商品處理`);
            continue;
          }

          // 計算有效時段人數（首小時數量 - 套票減免數量）
          const hourCounts = await new Promise((resolve, reject) => {
            db.db.get(
              `SELECT
                COALESCE(SUM(CASE WHEN p.name LIKE '%首小時%' THEN oi.quantity ELSE 0 END), 0) as first_hour_qty,
                COALESCE(SUM(CASE WHEN p.name LIKE '%套票減免%' THEN oi.quantity ELSE 0 END), 0) as discount_qty
               FROM order_items oi
               JOIN products p ON oi.product_id = p.id
               WHERE oi.customer_id = ?`,
              [customer.id],
              (err, row) => {
                if (err) reject(err);
                else resolve(row);
              }
            );
          });

          const effectiveCount = hourCounts.first_hour_qty - hourCounts.discount_qty;
          if (effectiveCount <= 0) {
            console.log(`客人 ${customer.id} 套票減免已覆蓋所有時段 (首小時=${hourCounts.first_hour_qty}, 套票減免=${hourCounts.discount_qty})`);
            continue;
          }

          if (requiredSecondHourCount > 0) {
            // 需要次小時商品，進行處理

            // 查詢現有的次小時商品數量
            const existingSecondHourCount = await new Promise((resolve, reject) => {
              db.db.get(
                `SELECT COUNT(*) as count
                 FROM order_items oi
                 JOIN products p ON oi.product_id = p.id
                 WHERE oi.customer_id = ?
                 AND p.name LIKE '%次小時%'`,
                [customer.id],
                (err, row) => {
                  if (err) reject(err);
                  else resolve(row ? row.count : 0);
                }
              );
            });

            // 計算需要添加的次小時商品數量
            const countToAdd = requiredSecondHourCount - existingSecondHourCount;
            if (countToAdd > 0) {
              // 需要添加次小時商品

              // 獲取當前有效的次小時商品
              const secondHourProduct = await db.getValidHourProduct('次小時', now, customer.store_id);
              if (secondHourProduct) {
                // 添加缺失的次小時商品（使用有效人數）
                await db.addOrderItem(customer.id, secondHourProduct.id, effectiveCount * countToAdd, secondHourProduct.price);
                console.log(`已為客人 ${customer.id} 添加 ${effectiveCount * countToAdd} 個次小時商品 (${countToAdd}小時): ${secondHourProduct.name}`);

                // 觸發 Socket 事件通知前端更新
                io.emit('order-updated', {
                  customer_id: customer.id,
                  product_name: secondHourProduct.name,
                  quantity: effectiveCount * countToAdd,
                  store_id: customer.store_id
                });
              }
            }

            // 檢查是否需要轉換為全日通
            try {
              // 檢查是否已經有全日通（再次確認，防止併發問題）
              const hasDayPassAgain = await new Promise((resolve, reject) => {
                db.db.get(
                  `SELECT 1 FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.customer_id = ? AND p.name LIKE '%全日通%'`,
                  [customer.id],
                  (err, row) => {
                    if (err) reject(err);
                    else resolve(!!row);
                  }
                );
              });

              if (!hasDayPassAgain) {
                // 查詢首小時單價和次小時總額
                const hourPriceData = await new Promise((resolve, reject) => {
                  db.db.get(
                    `SELECT
                      SUM(CASE WHEN p.name LIKE '%首小時%' THEN oi.quantity * oi.price_at_time ELSE 0 END) as first_hour_total,
                      SUM(CASE WHEN p.name LIKE '%首小時%' THEN oi.quantity ELSE 0 END) as first_hour_qty,
                      SUM(CASE WHEN p.name LIKE '%次小時%' THEN oi.quantity * oi.price_at_time ELSE 0 END) as second_hour_total
                     FROM order_items oi
                     JOIN products p ON oi.product_id = p.id
                     WHERE oi.customer_id = ?
                     AND (p.name LIKE '%首小時%' OR p.name LIKE '%次小時%')`,
                    [customer.id],
                    (err, row) => {
                      if (err) reject(err);
                      else resolve(row);
                    }
                  );
                });

                // 計算調整後的總價：次小時總額 + 有效人數 × 首小時單價
                const firstHourUnitPrice = hourPriceData.first_hour_qty > 0
                  ? hourPriceData.first_hour_total / hourPriceData.first_hour_qty
                  : 0;
                const adjustedTotalPrice = (hourPriceData.second_hour_total || 0) + (effectiveCount * firstHourUnitPrice);
                const perPersonPrice = effectiveCount > 0 ? adjustedTotalPrice / effectiveCount : 0;

                // 獲取當前有效的全日通商品
                const dayPassProduct = await db.getValidDayPassProduct(now, customer.store_id);
                if (dayPassProduct && perPersonPrice > dayPassProduct.price) {
                  // 移除所有首小時和次小時商品
                  const removalResult = await db.removeHourProducts(customer.id);
                  console.log(`已為客人 ${customer.id} 移除 ${removalResult.removedCount} 個時段商品，總金額 ${removalResult.totalAmount}`);

                  // 添加全日通商品（使用有效人數）
                  await db.addOrderItem(customer.id, dayPassProduct.id, effectiveCount, dayPassProduct.price);
                  console.log(`已為客人 ${customer.id} 添加全日通商品: ${dayPassProduct.name} x ${effectiveCount}`);

                  // 觸發 Socket 事件通知前端更新
                  io.emit('order-updated', {
                    customer_id: customer.id,
                    product_name: dayPassProduct.name,
                    quantity: effectiveCount,
                    store_id: customer.store_id
                  });
                }
              }
            } catch (error) {
              console.error(`為客人 ${customer.id} 檢查全日通時發生錯誤:`, error);
            }
          }
        } catch (error) {
          console.error(`為客人 ${customer.id} 處理次小時商品時發生錯誤:`, error);
        }
      }
    } catch (error) {
      console.error('第二小時檢查任務錯誤:', error);
    }
  }, 1 * 60 * 1000); // 1分鐘
}

/**
 * 入口打印機健康檢查 (192.168.3.120:9100)
 * 每30秒檢查一次，透過 socket.io 廣播狀態
 */
function startEntryPrinterHealthCheck(ioInstance) {
  const ENTRY_PRINTER_IP = '192.168.3.120';
  const ENTRY_PRINTER_PORT = 9100;

  function check() {
    const sock = new net.Socket();
    sock.setTimeout(5000);

    sock.on('connect', () => {
      sock.destroy();
      ioInstance.emit('device-update', { device: 'entry-printer', status: 'online' });
    });

    sock.on('error', () => {
      sock.destroy();
      ioInstance.emit('device-update', { device: 'entry-printer', status: 'offline' });
    });

    sock.on('timeout', () => {
      sock.destroy();
      ioInstance.emit('device-update', { device: 'entry-printer', status: 'offline' });
    });

    sock.connect(ENTRY_PRINTER_PORT, ENTRY_PRINTER_IP);
  }

  check();
  setInterval(check, 30000);
  console.log('[entry-printer] printer health check started (192.168.3.120:9100, every 30s)');
}

// 獲取本機IP地址
function getLocalIpAddresses() {
    const interfaces = os.networkInterfaces();
    const addresses = [];

    for (const interfaceName in interfaces) {
        for (const iface of interfaces[interfaceName]) {
            // 跳過IPv6和內部地址
            if (iface.family === 'IPv4' && !iface.internal) {
                addresses.push({
                    address: iface.address,
                    interface: interfaceName,
                    mac: iface.mac
                });
            }
        }
    }

    return addresses;
}

// ─── API key self-rollover（平板 EDGE 專用，只做一次）───
// 平板 .env 嘅 ALIYUN_API_KEY 若仍係 zip 內 .retired_key（舊 key），
// 用舊 key 問 production 攞新 key → 寫入 .env + 更新 process.env + 清 cashier 注入 cache
// → 之後永久用新 key，唔會再觸發。唔使 SSH 入平板（SSH tunnel 唔可靠）。
async function tryRolloverApiKey() {
    const homeDir = path.resolve(__dirname, '..');
    let retiredKey;
    try { retiredKey = fs.readFileSync(path.join(homeDir, '.retired_key'), 'utf8').trim(); } catch (_) { return; }
    if (!retiredKey) return;

    const currentKey = process.env.ALIYUN_API_KEY;
    if (!currentKey || currentKey !== retiredKey) return; // 已經係新 key，唔使 rollover

    const aliyunBase = (process.env.ALIYUN_SERVER || 'http://47.239.121.13:3000').replace(/\/$/, '');
    try {
        const resp = await fetch(`${aliyunBase}/api/sync/key-rollover`, {
            method: 'POST',
            headers: { 'X-API-Key': currentKey, 'Content-Type': 'application/json' },
            signal: AbortSignal.timeout(10000)
        });
        if (!resp.ok) { console.warn(`[key-rollover] production 回應 ${resp.status}，下次啟動再試`); return; }
        const data = await resp.json();
        if (data.success && data.rollover && data.api_key) {
            writeEnvKey(path.join(homeDir, '.env'), 'ALIYUN_API_KEY', data.api_key);
            process.env.ALIYUN_API_KEY = data.api_key;
            cachedEnhancedCashierJs = null; // 下個 request 用新 key 重新注入 enhanced-cashier.js
            try { fs.unlinkSync(path.join(homeDir, '.retired_key')); } catch (_) {} // rollover 完，清走標記
            console.log('[key-rollover] ✅ 已獲取新 API key 並寫入 .env（以後唔會再觸發）');
        }
    } catch (e) {
        console.warn(`[key-rollover] 失敗: ${e.message}，下次啟動再試`);
    }
}

// 保守地喺 .env 更新/新增一行 KEY=VALUE（唔會掂其他 config）
function writeEnvKey(envPath, key, value) {
    let content = '';
    try { content = fs.readFileSync(envPath, 'utf8'); } catch (_) {}
    const re = new RegExp(`^${key}=.*$`, 'm');
    if (re.test(content)) {
        content = content.replace(re, `${key}=${value}`);
    } else {
        content = content.replace(/\s*$/, '\n') + `${key}=${value}\n`;
    }
    fs.writeFileSync(envPath, content);
}

// ─── ALIYUN_SERVER 遷移（EDGE 平板專用，冪等）───
// 2026-09 folder-per-merchant 遷移：catstearoom 後台由 :3000 搬去 :3002。
// 舊平板 .env 若仍指 http://47.239.121.13:3000（而家 = master 通用版，key 唔啱會 sync 唔到），
// boot 時自動改做 http://47.239.121.13:3002（catstearoom 真後台）。唔使 SSH 入平板。
// 淨係喺「值完全等於舊址」先改（冪等：改完 .env，下次 boot 唔會再觸發）。
// BACKEND（阿里雲）唔會行——master 自己就係 :3000，郁咗會斷。
// ⚠️ catstearoom 專用（hardcode :3002）——唔好 sync 返 master 分支！
function migrateAliyunServer() {
    if (!runtime.isEdge) return; // BACKEND：master 自己就係 :3000，唔可以郁
    const OLD_URL = 'http://47.239.121.13:3000';
    const NEW_URL = 'http://47.239.121.13:3002';
    const homeDir = path.resolve(__dirname, '..');
    const cur = (process.env.ALIYUN_SERVER || '').replace(/\/$/, '');
    if (cur !== OLD_URL) return; // 已經新址／未設／其他地址 → no-op
    writeEnvKey(path.join(homeDir, '.env'), 'ALIYUN_SERVER', NEW_URL);
    process.env.ALIYUN_SERVER = NEW_URL;
    console.log(`[server-migrate] ✅ ALIYUN_SERVER 由 ${OLD_URL} 遷移至 ${NEW_URL}（.env 已更新，以後唔會再觸發）`);
}

// 啟動服務器
const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0'; // 監聽所有網絡接口

httpServer.listen({ port: PORT, host: HOST, reuseAddress: true }, () => {
    const localIpAddresses = getLocalIpAddresses();

    console.log('='.repeat(60));
    console.log(`自動咖啡館系統服務器已啟動`);
    console.log('='.repeat(60));

    console.log(`\n📡 服務器監聽: ${HOST}:${PORT}`);
    console.log(`🏠 本地訪問: http://localhost:${PORT}`);

    if (localIpAddresses.length > 0) {
        console.log('\n🌐 局域網訪問地址:');
        localIpAddresses.forEach((ipInfo, index) => {
            console.log(`   ${index + 1}. http://${ipInfo.address}:${PORT} (${ipInfo.interface})`);
        });
    } else {
        console.log('\n⚠️  未檢測到局域網IP地址，請檢查網絡連接');
    }

    console.log('\n🔗 系統界面:');
    console.log(`   • 控制面板: http://localhost:${PORT}`);
    console.log(`   • 入場機器: http://localhost:${PORT}/entry-machine`);
    console.log(`   • 收銀系統: http://localhost:${PORT}/cashier`);
    console.log(`   • 商品售賣機: http://localhost:${PORT}/vending-machine`);
    console.log(`   • 離場機器: http://localhost:${PORT}/exit-machine`);

    // 顯示局域網訪問URL（使用第一個檢測到的IP）
    if (localIpAddresses.length > 0) {
        const primaryIp = localIpAddresses[0].address;
        console.log(`\n🖥️  主服務器地址（供客戶端連接）: ${primaryIp}:${PORT}`);
        console.log(`   🔗 收銀系統: http://${primaryIp}:${PORT}/cashier`);
    }

    console.log('\n' + '='.repeat(60));

    startSecondHourScheduler();

    // 啟動入口打印機健康檢查
    startEntryPrinterHealthCheck(io);

    // 啟動員工名單同步排程（每天香港時間 3:00 AM 從 Google Sheet 同步）
    try {
        const employeeSheetSync = require('./utils/employeeSheetSync');
        employeeSheetSync.startEmployeeSyncSchedule();
        console.log('✅ 員工名單同步排程已啟動（每天 3:00 AM 香港時間）');
    } catch (error) {
        console.error('啟動員工名單同步排程失敗:', error);
    }

    // 啟動結賬單據自動上傳服務（僅在主機模式下）
    try {
        const hostRole = process.env.HOST_ROLE || 'master'; // master 或 client
        console.log('📋 主機角色檢查:', { HOST_ROLE: hostRole, STORE_ID: process.env.STORE_ID, ALIYUN_SERVER: process.env.ALIYUN_SERVER ? '已設置' : '未設置' });
        if (hostRole === 'master') {
            const uploadService = new BillUploadService();
            const started = uploadService.start();
            if (started) {
                console.log('✅ 結賬單據自動上傳服務已啟動（主機模式）');
            } else {
                console.error('✋ 結賬單據自動上傳服務未啟動（安全閘拒絕，請檢查 logs/ 內 [ERROR] 訊息）');
            }
        } else {
            console.log('⏭️  分機模式：跳過結賬單據自動上傳服務');
        }
    } catch (error) {
        console.error('❌ 啟動結賬單據上傳服務失敗:', error);
        console.log('⚠️  結賬單據上傳功能將不可用，請手動啟動 bill-upload-service.js');
    }

    // 啟動每日午夜日誌清除排程（香港時間 00:00）
    scheduleMidnightLogCleanup();

    // API key self-rollover（平板 EDGE 專用）：用舊 key 自動換新 key，唔使 SSH 入平板
    if (runtime.isEdge) {
        tryRolloverApiKey().catch(e => console.warn('[key-rollover] 啟動時 rollover 錯誤:', e.message));
    }

});

// ============================================================
// 每日午夜自動清除日誌
// ============================================================
function scheduleMidnightLogCleanup() {
    const now = new Date();
    const hkOffset = 8 * 60 * 60 * 1000; // UTC+8
    const hkNow = new Date(now.getTime() + hkOffset);

    const tomorrow = new Date(hkNow);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);

    const msUntilMidnight = tomorrow.getTime() - hkNow.getTime();

    setTimeout(() => {
        clearAllLogFiles();
        // 之後每 24 小時執行一次
        setInterval(clearAllLogFiles, 24 * 60 * 60 * 1000);
    }, msUntilMidnight);

    const hkMidnightStr = tomorrow.toISOString().substring(0, 10);
    console.log(`[log-cleanup] 每日午夜清除排程已啟動，下次清除: ${hkMidnightStr} 00:00 (香港時間)`);
}

function clearAllLogFiles() {
    const logDir = path.resolve(__dirname, '..', 'logs');
    if (!fs.existsSync(logDir)) return;

    const files = fs.readdirSync(logDir).filter(f => f.endsWith('.log'));
    let deleted = 0;
    for (const file of files) {
        try {
            fs.unlinkSync(path.join(logDir, file));
            deleted++;
        } catch (e) {
            console.error(`[log-cleanup] 清除日誌失敗: ${file}`, e.message);
        }
    }
    if (deleted > 0) {
        console.log(`[log-cleanup] ✅ 已清除 ${deleted} 個日誌檔案`);
    }
}

// ============================================================
// 伺服器自動更新機制（Self-Update）
// 定時檢查 GitHub 上的最新版本，自動下載、驗證、更新、重啟
//
// 使用 curl 取代 https.get()：Termux 的 curl 使用系統憑證，
// 而 Node.js 內建 https 在 Termux 上可能因憑證問題失敗
// ============================================================

const UPDATE_JSON_URL = 'https://raw.githubusercontent.com/albertleego/apk_release/main/latest-version.json';
// HOT FIX 查詢基址：跟 ALIYUN_SERVER 走（merchant 各自 backend），未設先 fallback 舊 production（向後兼容）
const HOT_FIX_SERVER = (process.env.ALIYUN_SERVER || 'http://47.239.121.13:3000').replace(/\/$/, '');
const UPDATE_LOG_PATH = path.join(__dirname, '..', 'logs', 'update.log');
const UPDATE_TIMEOUT_MS = 30 * 60 * 1000; // 30 分鐘更新超時
const HOME_DIR = path.resolve(__dirname, '..');
const UPDATE_FLAG_FILE = path.join(HOME_DIR, '.updating');
const HOT_FIX_STATE_FILE = path.join(HOME_DIR, '.hot_fix_enabled');
const BACKUP_DONE_FLAG = path.join(HOME_DIR, '.backup_done');
const CP_DONE_FLAG = path.join(HOME_DIR, '.cp_done');
let _isUpdating = false;
let _lastUpdateVer = 0;      // 本地版本（從 .server_version 讀取，更新時一併更新以正確暴露）
let _lastUpdateCheck = null; // 最後檢查時間
let _lastUpdateError = null; // 最後錯誤訊息

// 更新進度（供 /api/update-status 回報，前端顯示進度條/百分比/下載速度）
// phase: idle|downloading|verifying|backing_up|unpacking|installing|restarting|done|error
let _updateProgress = {
    phase: 'idle',
    downloaded: 0,
    total: 0,
    percent: 0,          // -1 = 未知
    speed: 0,            // bytes/sec
    message: ''
};

function setUpdateProgress(phase, msg) {
    _updateProgress.phase = phase;
    if (msg) _updateProgress.message = msg;
}

function resetUpdateProgress() {
    _updateProgress = { phase: 'idle', downloaded: 0, total: 0, percent: 0, speed: 0, message: '' };
}

// 確保 logs 目錄存在
try {
    const logDir = path.dirname(UPDATE_LOG_PATH);
    if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });
} catch (_) {}

// 專用更新日誌（獨立於 console，確保可追蹤）
// 用香港時間（UTC+8）：直接加 8 小時再格式化成 ISO，與 utils/logger.js 一致
function logUpdate(msg, level = 'INFO') {
    const ts = new Date(Date.now() + 8 * 3600000).toISOString().replace('T', ' ').substring(0, 19);
    const line = `[${ts}][${level}] ${msg}`;
    console.log(line);
    try { fs.appendFileSync(UPDATE_LOG_PATH, line + '\n'); } catch (_) {}
}

// 使用 fetch（優先）或 curl 抓 JSON
async function fetchJsonViaCurl(url) {
    // 先試 Node 內置 fetch (Node 18+)
    if (typeof fetch === 'function') {
        try {
            const ac = new AbortController();
            const timer = setTimeout(() => ac.abort(), 15000);
            const resp = await fetch(url, { signal: ac.signal });
            clearTimeout(timer);
            if (resp.ok) return await resp.json();
        } catch (_) {}
    }
    // 再用 https 模組
    try {
        return await new Promise((resolve, reject) => {
            const u = new URL(url);
            const mod = u.protocol === 'https:' ? require('https') : require('http');
            mod.get(url, { timeout: 15000 }, (res) => {
                let data = '';
                res.on('data', (chunk) => data += chunk);
                res.on('end', () => {
                    try { resolve(JSON.parse(data)); } catch (e) { reject(e); }
                });
            }).on('error', reject).on('timeout', function() { this.destroy(); reject(new Error('timeout')); });
        });
    } catch (_) {}
    // 最後用 curl（Termux 場合）
    const stdout = await execPromise(`curl -sL --connect-timeout 10 '${url}'`, { timeout: 30000 });
    if (!stdout) throw new Error('curl 回傳空內容');
    return JSON.parse(stdout);
}

// 使用 fetch（優先）或 curl 下載檔案
/** 串流下載檔案（支援 redirect），邊下載邊更新 _updateProgress（bytes/speed/percent）。
 *  用 Node http/https 模組取代 curl，令前端可以顯示即時進度。
 *  若 Node 下載失敗則回退用 curl（該情況冇進度，但至少能完成）。 */
function downloadFileWithProgress(url, dest) {
    return new Promise((resolve, reject) => {
        let redirects = 0;
        const attempt = (currentUrl) => {
            const mod = currentUrl.startsWith('https:') ? require('https') : require('http');
            const req = mod.get(currentUrl, { timeout: 15000 }, (res) => {
                const code = res.statusCode || 0;
                // 跟隨 redirect（最多 5 次）
                if (code >= 300 && code < 400 && res.headers.location && redirects < 5) {
                    redirects++;
                    res.resume();
                    const next = new URL(res.headers.location, currentUrl).toString();
                    return attempt(next);
                }
                if (code !== 200) {
                    res.resume();
                    return reject(new Error(`HTTP ${code} ${currentUrl}`));
                }
                const total = parseInt(res.headers['content-length'] || '0', 10);
                setUpdateProgress('downloading', '正在下載更新包');
                _updateProgress.downloaded = 0;
                _updateProgress.total = total;
                _updateProgress.percent = total > 0 ? 0 : -1;
                _updateProgress.speed = 0;

                const out = fs.createWriteStream(dest);
                let downloaded = 0;
                let lastTime = Date.now();
                let lastBytes = 0;
                res.on('data', (chunk) => {
                    downloaded += chunk.length;
                    const now = Date.now();
                    if (now - lastTime >= 400) {
                        _updateProgress.speed = (downloaded - lastBytes) * 1000.0 / (now - lastTime);
                        lastTime = now;
                        lastBytes = downloaded;
                    }
                    _updateProgress.downloaded = downloaded;
                    if (total > 0) _updateProgress.percent = Math.min(100, Math.floor(downloaded * 100 / total));
                });
                out.on('error', (err) => { res.destroy(); reject(err); });
                res.on('error', (err) => { out.destroy(); reject(err); });
                out.on('finish', () => {
                    _updateProgress.downloaded = downloaded;
                    _updateProgress.total = total;
                    _updateProgress.percent = total > 0 ? 100 : -1;
                    _updateProgress.speed = 0;
                    out.close();
                    resolve();
                });
                res.pipe(out);
            });
            req.on('error', reject);
            req.on('timeout', () => { req.destroy(); reject(new Error('下載連線逾時')); });
        };
        attempt(url);
    });
}

async function downloadFileViaCurl(url, dest) {
    // 優先：Node 串流下載（有進度）
    try {
        await downloadFileWithProgress(url, dest);
        if (!fs.existsSync(dest) || fs.statSync(dest).size === 0) {
            throw new Error(`下載失敗或檔案為空: ${url}`);
        }
        return;
    } catch (e) {
        logUpdate(`Node 下載失敗，改用 curl 重試: ${e.message}`, 'WARN');
        if (fs.existsSync(dest)) { try { fs.unlinkSync(dest); } catch (_) {} }
    }
    // 回退：curl（冇進度）
    setUpdateProgress('downloading', '正在下載更新包 (curl 重試中)');
    await execPromise(`curl -sL --connect-timeout 10 '${url}' -o '${dest}'`, { timeout: 180000 });
    if (!fs.existsSync(dest) || fs.statSync(dest).size === 0) {
        throw new Error(`下載失敗或檔案為空: ${url}`);
    }
}

// 工具函數：exec Promise 包裝（含 stdout/stderr 合併輸出）
function execPromise(cmd, opts = {}) {
    const { exec } = require('child_process');
    return new Promise((resolve, reject) => {
        exec(cmd, { timeout: 120000, ...opts }, (err, stdout, stderr) => {
            if (err) {
                const detail = (stdout || '') + (stderr || '');
                err.message += `\n[cmd] ${cmd}\n[output] ${detail.substring(0, 500)}`;
                reject(err);
            } else {
                resolve(stdout || '');
            }
        });
    });
}

// 讀取 .server_version
function readLocalVersion(homeDir) {
    const versionFile = path.join(homeDir, '.server_version');
    try {
        return parseInt(fs.readFileSync(versionFile, 'utf8').trim(), 10) || 0;
    } catch (_) {
        return 0;
    }
}

// 讀取本地 APK 版本
function readLocalApkVersion(homeDir) {
    const apkFile = path.join(homeDir, '.apk_version');
    try {
        const raw = fs.readFileSync(apkFile, 'utf8').trim();
        // 可能是數字或 "1.64" 格式
        return raw;
    } catch (_) {
        return '';
    }
}

// 核心：檢查並執行更新（支援從指定 URL 下載，用於手動推送）
async function checkSelfUpdate(reason = 'scheduled', overrideUrl = null, force = false, checkOnly = false) {
    if (_isUpdating) {
        logUpdate(`已有更新進行中，跳過 (${reason})`);
        return;
    }

    // 更新只由用戶手動觸發（主機設定「立即更新」force=true）；自動檢查已移除
    // 保留 00:00-08:00 時段限制作為防禦（只有非 force 呼叫先會受限制，現時冇呢類呼叫）
    const hkHour = (new Date().getUTCHours() + 8) % 24;
    const inUpdateWindow = hkHour >= 0 && hkHour < 8;

    _isUpdating = true;
    _lastUpdateError = null;
    resetUpdateProgress();
    setUpdateProgress('checking', '正在檢查新版本...');

    const homeDir = path.resolve(__dirname, '..');

    try {
        // 讀取本地版本
        _lastUpdateVer = readLocalVersion(homeDir);
        const localVer = _lastUpdateVer;

        // 從 GitHub 取得最新版本資訊
        logUpdate(`檢查更新 (local=${localVer}, reason=${reason})`);
        const jsonUrl = overrideUrl || UPDATE_JSON_URL;
        const remote = await fetchJsonViaCurl(jsonUrl);
        const remoteVer = remote.server_version;
        if (!remoteVer || remoteVer <= localVer) {
            logUpdate(`已是最新 (local=${localVer}, remote=${remoteVer})`);
            _lastUpdateCheck = new Date().toISOString();
            resetUpdateProgress();
            return;
        }

        logUpdate(`發現新版本 v${remoteVer} (目前 v${localVer})，來源: ${reason}`);

        if (checkOnly) {
            logUpdate('檢查模式：偵測到新版本，請到主機設定按「立即更新」');
            _lastUpdateCheck = new Date().toISOString();
            resetUpdateProgress();
            return;
        }

        if (!inUpdateWindow && !force) {
            logUpdate(`非更新時段 (HKT ${hkHour}:00)，請手動按「立即更新」更新`);
            _lastUpdateCheck = new Date().toISOString();
            return;
        }

        if (force) {
            logUpdate('強制更新模式，跳過時段限制');
        }

        // ─── flag file: 開始更新 ───
        fs.writeFileSync(UPDATE_FLAG_FILE, String(Date.now()));

        // 下載 server zip
        const zipUrl = remote.server_zip_url;
        const zipPath = path.join(homeDir, 'update.zip');
        logUpdate(`下載中: ${zipUrl}`);
        setUpdateProgress('downloading', '正在下載更新包');
        await downloadFileViaCurl(zipUrl, zipPath);
        logUpdate(`下載完成 (${fs.statSync(zipPath).size} bytes)`);

        // 驗證 MD5
        setUpdateProgress('verifying', '正在驗證檔案完整性...');
        const buf = fs.readFileSync(zipPath);
        const md5 = crypto.createHash('md5').update(buf).digest('hex');
        if (md5 !== remote.server_zip_md5) {
            throw new Error(`MD5 不符: 預期 ${remote.server_zip_md5}，實際 ${md5}`);
        }
        logUpdate('MD5 驗證通過');

        // 備份目前程式碼
        setUpdateProgress('backing_up', '正在備份目前版本...');
        const backupFile = path.join(homeDir, `backup-v${localVer}.tgz`);
        logUpdate(`備份中: ${backupFile}`);
        await execPromise(
            `tar czf '${backupFile}' --exclude='database/*.db*' server/ client/ database/ scripts/ package.json package-lock.json 2>/dev/null`,
            { cwd: homeDir }
        );
        logUpdate('備份完成');
        fs.writeFileSync(BACKUP_DONE_FLAG, String(Date.now())); // backup 完成

        // 解壓到暫存目錄
        const stagingDir = path.join(homeDir, '.staging');
        if (fs.existsSync(stagingDir)) fs.rmSync(stagingDir, { recursive: true });
        fs.mkdirSync(stagingDir);

        setUpdateProgress('unpacking', '正在解壓更新包...');
        logUpdate('解壓中...');
        await execPromise(
            `unzip -o '${zipPath}' -d '${stagingDir}' -x 'node_modules/*' 'database/*.db*' 'logs/*'`,
            { cwd: homeDir }
        );
        logUpdate('解壓完成，搬移檔案中...');

        // 搬移到 home 目錄（含隱藏檔）
        await execPromise(`cp -r '${stagingDir}'/. '${homeDir}'`);
        logUpdate('搬移完成');
        fs.writeFileSync(CP_DONE_FLAG, String(Date.now())); // cp 完成

        // 清理暫存
        fs.rmSync(stagingDir, { recursive: true });
        fs.unlinkSync(zipPath);
        logUpdate('暫存已清理');

        // npm install
        setUpdateProgress('installing', '正在安裝相依套件...');
        try {
            logUpdate('執行 npm install...');
            const npmOut = await execPromise('npm install --production 2>&1', { cwd: homeDir });
            logUpdate(`npm install 完成 (${npmOut.substring(0, 200)})`);
        } catch (e) {
            logUpdate(`npm install 警告: ${e.message}`, 'WARN');
        }

        // 清除 flag files
        try {
            if (fs.existsSync(UPDATE_FLAG_FILE)) fs.unlinkSync(UPDATE_FLAG_FILE);
            if (fs.existsSync(BACKUP_DONE_FLAG)) fs.unlinkSync(BACKUP_DONE_FLAG);
            if (fs.existsSync(CP_DONE_FLAG)) fs.unlinkSync(CP_DONE_FLAG);
        } catch (_) {}

        // 寫入新版本號
        fs.writeFileSync(path.join(homeDir, '.server_version'), String(remoteVer));
        _lastUpdateVer = remoteVer;
        _lastUpdateCheck = new Date().toISOString();
        logUpdate(`更新至 v${remoteVer} 完成，準備重啟...`);
        setUpdateProgress('restarting', '更新完成，正在重啟服務器...');

        // 重啟：cd 到上一層（~/.env 所在目錄），確保 dotenv 能找到 STORE_ID
        const userRoot = path.resolve(homeDir, '..');
        const serverEntry = path.join(homeDir, 'server/index.js');
        const restartCmd = `cd '${userRoot}' && nohup node '${serverEntry}' >> '${UPDATE_LOG_PATH}' 2>&1 &`;
        await execPromise(restartCmd);
        logUpdate('新實例已啟動，退出目前行程');
        process.exit(0);
    } catch (error) {
        _lastUpdateError = `${error.message}\n${error.stack}`;
        setUpdateProgress('error', '更新失敗');
        logUpdate(`更新失敗: ${error.message}`, 'ERROR');
        logUpdate(`完整錯誤: ${error.stack}`, 'ERROR');

        // 嘗試回滾
        try {
            if (reason === 'startup') {
                logUpdate('啟動時更新失敗，跳過回滾（保留當前資料庫）');
                return;
            }
            const files = fs.readdirSync(homeDir).filter(f => f.startsWith('backup-v') && f.endsWith('.tgz'));
            if (files.length > 0) {
                const latest = files.sort().pop();
                logUpdate(`嘗試回滾: ${latest}`);
                const dbBackupPath = path.join(homeDir, 'database/cafe.db.pre-rollback');
                try { fs.copyFileSync(path.join(homeDir, 'database/cafe.db'), dbBackupPath); } catch (e) {}
                await execPromise(`tar xzf '${path.join(homeDir, latest)}' --exclude='database/*.db*' -C '${homeDir}'`, { cwd: homeDir });
                logUpdate('回滾完成');
            }
        } catch (rbError) {
            logUpdate(`回滾也失敗: ${rbError.message}`, 'ERROR');
        }
    } finally {
        _isUpdating = false;
        // 清除 flag files
        try {
            if (fs.existsSync(UPDATE_FLAG_FILE)) fs.unlinkSync(UPDATE_FLAG_FILE);
            if (fs.existsSync(BACKUP_DONE_FLAG)) fs.unlinkSync(BACKUP_DONE_FLAG);
            if (fs.existsSync(CP_DONE_FLAG)) fs.unlinkSync(CP_DONE_FLAG);
        } catch (_) {}
    }
}

// 啟動後 10 秒：只檢查上次更新是否 crash（有 .updating + .backup_done 但冇 .cp_done）做回滾 recovery
// 唔再自動檢查新版本（更新只做手動「立即更新」）
setTimeout(() => {
    if (fs.existsSync(UPDATE_FLAG_FILE) && fs.existsSync(BACKUP_DONE_FLAG) && !fs.existsSync(CP_DONE_FLAG)) {
        logUpdate('偵測到上次更新未完成（cp 中斷），啟動回滾', 'WARN');
        try {
            const files = fs.readdirSync(HOME_DIR).filter(f => f.startsWith('backup-v') && f.endsWith('.tgz'));
            if (files.length > 0) {
                const latest = files.sort().pop();
                logUpdate(`回滾: ${latest}`);
                require('child_process').execSync(`tar xzf '${path.join(HOME_DIR, latest)}' --exclude='database/*.db*' -C '${HOME_DIR}'`, { cwd: HOME_DIR });
                logUpdate('回滾完成');
            }
        } catch (rbError) {
            logUpdate(`回滾也失敗: ${rbError.message}`, 'ERROR');
        }
        // 清除 flag files
        try {
            if (fs.existsSync(UPDATE_FLAG_FILE)) fs.unlinkSync(UPDATE_FLAG_FILE);
            if (fs.existsSync(BACKUP_DONE_FLAG)) fs.unlinkSync(BACKUP_DONE_FLAG);
            if (fs.existsSync(CP_DONE_FLAG)) fs.unlinkSync(CP_DONE_FLAG);
        } catch (_) {}
    }
}, 10000);

// APK 敲門 endpoint：開 app 時 APK 外殼打嚟，只檢查新版本（checkOnly，唔自動下載）
app.post('/api/check-update', (req, res) => {
    logUpdate('收到 APK 觸發檢查');
    checkSelfUpdate('apk-trigger', null, false, true);
    res.json({ status: 'ok', message: 'Update check queued' });
});

// ─── 新 API: 查詢版本和更新可用性（不下載）───
app.get('/api/update/check-available', async (req, res) => {
    try {
        const localVer = readLocalVersion(HOME_DIR);
        const hkHour = (new Date().getUTCHours() + 8) % 24;
        const inManualWindow = hkHour >= 22 || hkHour < 13;
        let remoteVer = 0;
        let hasUpdate = false;
        let remoteData = null;

        try {
            const remote = await fetchJsonViaCurl(UPDATE_JSON_URL);
            remoteVer = remote.server_version || 0;
            hasUpdate = remoteVer > localVer;
            remoteData = remote;
        } catch (fetchErr) {
            logUpdate(`check-available fetch 失敗: ${fetchErr.message}`, 'WARN');
        }

        // APK 版本
        const localApkVerStr = readLocalApkVersion(HOME_DIR);
        const remoteApkVer = remoteData ? (remoteData.version || '') : '';
        const apkHasUpdate = !!(remoteApkVer && localApkVerStr && remoteApkVer !== localApkVerStr);

        // 查阿里雲 HOT FIX 狀態（本地機房共用同一旗標）
        let hotFixEnabled = false;
        try {
            const hfResp = await fetch(`${HOT_FIX_SERVER}/api/update/hot-fix`, { signal: AbortSignal.timeout(3000) });
            if (hfResp.ok) {
                const hfData = await hfResp.json();
                hotFixEnabled = hfData.success && hfData.hot_fix_enabled === true;
            }
        } catch (_) {}

        res.json({
            success: true,
            data: {
                local_ver: localVer,
                remote_ver: remoteVer,
                has_update: hasUpdate,
                in_manual_window: inManualWindow,
                is_updating: _isUpdating || fs.existsSync(UPDATE_FLAG_FILE),
                manual_window_label: '22:00 - 13:00',
                hot_fix_enabled: hotFixEnabled,
                apk_local_ver: localApkVerStr || 'N/A',
                apk_remote_ver: remoteApkVer || 'N/A',
                apk_has_update: apkHasUpdate,
                remote_info: remoteData ? {
                    server_zip_url: remoteData.server_zip_url,
                    release_date: remoteData.release_date
                } : null,
                recent_log: (() => {
                    try {
                        if (fs.existsSync(UPDATE_LOG_PATH)) {
                            const c = fs.readFileSync(UPDATE_LOG_PATH, 'utf8');
                            return c.trim().split('\n').slice(-5).join('\n');
                        }
                    } catch (_) {}
                    return '';
                })()
            }
        });
    } catch (err) {
        res.json({ success: false, error: err.message });
    }
});

// ─── Hot Fix 狀態（RUNNING_MODE 角色分支）───
// BACKEND mode（阿里雲後台）→ 直接讀寫本地 DB + file（admin toggle）
// EDGE mode（平板，預設）→ proxy 去阿里雲讀取，平板本身唔設 toggle（同而家行為一致）
if (runtime.hotFixAdmin()) {
    app.get('/api/update/hot-fix', (req, res) => {
        db.db.get(`SELECT config_value FROM store_configs WHERE store_id = 'default_store' AND config_key = 'hot_fix_enabled'`, (err, row) => {
            if (err) return res.json({ success: true, hot_fix_enabled: false });
            res.json({ success: true, hot_fix_enabled: row && row.config_value === 'true' });
        });
    });

    app.post('/api/update/hot-fix', (req, res) => {
        const enabled = req.body && req.body.enabled === true;
        const val = enabled ? 'true' : 'false';
        // 同時寫 DB（持久） + 檔案（同步，供 check-available 讀取）
        db.db.run(
            `INSERT INTO store_configs (id, store_id, config_key, config_value, config_type, description)
             VALUES (?, 'default_store', 'hot_fix_enabled', ?, 'boolean', 'ENABLE HOT FIX 跳過更新時段限制')
             ON CONFLICT(store_id, config_key) DO UPDATE SET config_value = ?, updated_at = CURRENT_TIMESTAMP`,
            ['hot_fix_' + Date.now(), val, val],
            (err) => {
                if (err) return res.json({ success: false, error: err.message });
                try {
                    if (enabled) { fs.writeFileSync(HOT_FIX_STATE_FILE, '1'); }
                    else { if (fs.existsSync(HOT_FIX_STATE_FILE)) fs.unlinkSync(HOT_FIX_STATE_FILE); }
                } catch (_) {}
                logUpdate(`HOT FIX 已${enabled ? '啟用' : '停用'}（DB + File）`);
                res.json({ success: true, hot_fix_enabled: enabled });
            }
        );
    });
} else {
    // 平板：讀取 proxy 到阿里雲
    app.get('/api/update/hot-fix', async (req, res) => {
        try {
            const hfResp = await fetch(`${HOT_FIX_SERVER}/api/update/hot-fix`, { signal: AbortSignal.timeout(3000) });
            if (hfResp.ok) {
                const hfData = await hfResp.json();
                return res.json(hfData);
            }
        } catch (_) {}
        res.json({ success: false, hot_fix_enabled: false });
    });
}

// ─── 新 API: 手動觸發更新（用戶主動按「立即更新」，支援 hot fix bypass）───
app.post('/api/update/trigger', async (req, res) => {
    const hkHour = (new Date().getUTCHours() + 8) % 24;
    const inManualWindow = hkHour >= 22 || hkHour < 13;

    if (_isUpdating || fs.existsSync(UPDATE_FLAG_FILE)) {
        return res.json({ success: false, error: '已有更新進行中' });
    }

    // HOT FIX 狀態由阿里雲統一管理（本地經 /api/update/check-available 讀取，前端依狀態顯示「立即更新」）
    // 只要阿里雲已啟用 HOT FIX，手動更新即跳過時段限制（無需 body 再帶 hot_fix 旗標）
    let hotFixBypass = false;
    try {
        const hfResp = await fetch(`${HOT_FIX_SERVER}/api/update/hot-fix`, { signal: AbortSignal.timeout(3000) });
        if (hfResp.ok) {
            const hfData = await hfResp.json();
            hotFixBypass = hfData.success && hfData.hot_fix_enabled === true;
        }
    } catch (_) {}

    if (!inManualWindow && !hotFixBypass) {
        return res.json({ success: false, error: '請於香港時間 22:00 - 13:00 之間進行更新，或先喺阿里雲啟用 ENABLE HOT FIX' });
    }

    logUpdate('收到前端手動觸發更新' + (hotFixBypass ? ' (Hot Fix bypass)' : ''));
    // fire-and-forget but timeout enforced
    checkSelfUpdate('manual-trigger', null, true);

    res.json({ success: true, message: '更新已開始，需時約 1-20 分鐘' });
});

// ─── APK 回報版本（更新完成後由 APK 呼叫）───
app.post('/api/update/report-apk-version', (req, res) => {
    if (req.body && req.body.version) {
        const version = String(req.body.version).trim();
        try {
            fs.writeFileSync(path.join(HOME_DIR, '.apk_version'), version);
            logUpdate(`APK 版本更新為: ${version}`);
            res.json({ success: true, version });
        } catch (err) {
            res.json({ success: false, error: err.message });
        }
    } else {
        res.json({ success: false, error: '缺少 version 參數' });
    }
});

// 查詢更新狀態（增強版）
app.get('/api/update-status', (req, res) => {
    const currentVer = readLocalVersion(HOME_DIR);
    const updateLogExists = fs.existsSync(UPDATE_LOG_PATH);
    let recentLog = '';
    try {
        if (updateLogExists) {
            const content = fs.readFileSync(UPDATE_LOG_PATH, 'utf8');
            const lines = content.trim().split('\n');
            recentLog = lines.slice(-20).join('\n');
        }
    } catch (_) {}

    res.json({
        server_version: currentVer,
        is_updating: _isUpdating || fs.existsSync(UPDATE_FLAG_FILE),
        last_check: _lastUpdateCheck,
        last_error: _lastUpdateError,
        has_log: updateLogExists,
        recent_log: recentLog,
        progress: _updateProgress
    });
});

// ─── API: 讀取/設定 HOT FIX 狀態（僅阿里雲有此功能）───
// 本地版不需要此路由

module.exports = { app, io };