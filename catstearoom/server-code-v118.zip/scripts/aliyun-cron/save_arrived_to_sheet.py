#!/usr/bin/env python3
"""每日 9pm 執行（香港時間）
讀取阿里雲 DB 中今日 (status='arrived') 已入座狀態的 Booking 及 Waitinglist
記錄，寫入 Google Sheet "RawData" tab。
"""
import gspread, sqlite3, datetime, os, sys
from google.oauth2.service_account import Credentials
from datetime import timezone, timedelta

# ─── Config ───
# 路徑跟 merchant folder 走（scripts 部署喺 <merchant>/scripts/），唔硬寫絕對路徑
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)  # <merchant>
DB_PATH = os.environ.get('CAFE_DB_PATH', os.path.join(_ROOT, 'database', 'cafe.db'))
KEY_PATH = os.environ.get('SHEETS_KEY_PATH', os.path.join(_HERE, 'google-sheets-key.json'))
SHEET_ID = '1Pfe67SNwGZkcxGvX_tJ82U8_uZ-qnJlvqasspF4iyDo'
LOG_DIR = os.environ.get('CRON_LOG_DIR', os.path.join(_HERE, 'logs'))

# Store ID → display name mapping (mirrors the `stores` table)
STORE_NAMES = {
    'store_1': '荃灣',
    'store_2': '尖沙咀',
    'store_3': '旺角',
    'store_4': '銅鑼灣',
    'default_store': '總部',
    'test': '測試分店',
}

STATUS_LABELS = {
    'arrived': '已入座',
    'confirmed': '已預約',
    'cancelled': '已取消',
    'waiting': '候位中',
    'contacted': '已聯絡',
}

# ─── Helpers ───

def log(msg):
    os.makedirs(LOG_DIR, exist_ok=True)
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f'[{ts}] {msg}'
    print(line)
    with open(os.path.join(LOG_DIR, 'save_arrived.log'), 'a', encoding='utf-8') as f:
        f.write(line + '\n')

def get_today_str():
    """Return today's date as YYYY-MM-DD in HKT"""
    hk_tz = timezone(timedelta(hours=8))
    return datetime.datetime.now(hk_tz).strftime('%Y-%m-%d')

def get_store_name(store_id):
    return STORE_NAMES.get(store_id, store_id or '未知')

def get_status_label(status):
    return STATUS_LABELS.get(status, status or '未知')

def extract_time(dt_str, is_utc=True):
    """Extract HH:MM from a timestamp string.
    - bookings 表嘅時間係 UTC（is_utc=True，轉香港時間 +8）
    - waitinglist 表嘅時間係香港時間（is_utc=False，唔轉）"""
    if not dt_str:
        return ''
    try:
        dt = datetime.datetime.fromisoformat(dt_str.replace('Z', '+00:00'))
        if is_utc:
            # 如果冇時區標記，假定為 UTC，再轉香港時間
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=datetime.timezone.utc)
            hk_tz = datetime.timezone(datetime.timedelta(hours=8))
            dt = dt.astimezone(hk_tz)
        return dt.strftime('%H:%M')
    except:
        return dt_str[11:16] if len(dt_str) >= 16 else dt_str

# ─── Main ───

def main():
    today_str = get_today_str()
    log(f'=== 開始儲存 {today_str} 已入座資料 ===')

    # 1. Connect to local DB
    if not os.path.exists(DB_PATH):
        log(f'❌ DB 不存在: {DB_PATH}')
        return
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    # 2. Query arrived bookings (today)
    c.execute("""
        SELECT id, store_id, booking_date, booking_time, adults, children,
               phone, notes, status, table_number, lang, created_at, updated_at
        FROM bookings
        WHERE booking_date = ? AND status = 'arrived'
        ORDER BY booking_time ASC
    """, (today_str,))
    booking_rows = c.fetchall()
    log(f'  Bookings (arrived): {len(booking_rows)}')

    # 3. Query arrived waitinglist (today)
    c.execute("""
        SELECT id, store_id, adults, children, phone, notes, status,
               ref_number, table_number, lang, created_at, updated_at
        FROM waitinglist
        WHERE DATE(created_at) = ? AND status = 'arrived'
        ORDER BY created_at ASC
    """, (today_str,))
    waiting_rows = c.fetchall()
    log(f'  Waitinglist (arrived): {len(waiting_rows)}')

    conn.close()

    total = len(booking_rows) + len(waiting_rows)
    if total == 0:
        log('  ⚠️ 今日無任何已入座記錄')
    else:
        log(f'  合計 {total} 筆記錄')

    # 4. Connect to Google Sheets
    scope = [
        'https://spreadsheets.google.com/feeds',
        'https://www.googleapis.com/auth/drive',
        'https://www.googleapis.com/auth/spreadsheets',
    ]
    try:
        creds = Credentials.from_service_account_file(KEY_PATH, scopes=scope)
        client = gspread.authorize(creds)
    except Exception as e:
        log(f'❌ Google Sheets 認證失敗: {e}')
        return

    try:
        sh = client.open_by_key(SHEET_ID)
    except Exception as e:
        log(f'❌ 無法開啟 Spreadsheet: {e}')
        log('  請確認服務帳號已加為編輯者: auto-cafe-sheets@autocafe-sheets.iam.gserviceaccount.com')
        return

    # Ensure RawData sheet exists
    try:
        ws = sh.worksheet('RawData')
    except:
        ws = sh.add_worksheet(title='RawData', rows=1000, cols=13)
        log('  ✅ 已建立 RawData sheet')

    # 5. 標題行（確保存在）
    HEADERS = ['日期', '分店', '類型', '時間', '入座時間', '成人', '小童', '電話', '人數',
               '桌號', '備註', '狀態', '記錄ID']
    all_data = ws.get_all_values()
    if not all_data or all_data[0] != HEADERS:
        ws.update(values=[HEADERS], range_name='A1')
        log('  ✅ 已寫入標題行')

    # 6. 先清空 RawData 所有資料（保留標題行）
    ws.batch_clear(['A2:M1000'])
    log('  🧹 已清空 RawData 舊資料')

    # 7. Build today's data rows
    today_rows = []
    for row in booking_rows:
        people = row['adults'] + row['children']
        today_rows.append([
            today_str,
            get_store_name(row['store_id']),
            '預約',
            row['booking_time'] or '',
            extract_time(row['updated_at']),
            row['adults'] or 0,
            row['children'] or 0,
            row['phone'] or '',
            people,
            row['table_number'] or '',
            row['notes'] or '',
            get_status_label(row['status']),
            row['id'],
        ])

    for row in waiting_rows:
        adults = row['adults'] or 0
        children = row['children'] or 0
        people = adults + children
        today_rows.append([
            today_str,
            get_store_name(row['store_id']),
            '候位',
            extract_time(row['created_at'], is_utc=False),
            extract_time(row['updated_at'], is_utc=False),
            adults,
            children,
            row['phone'] or '',
            people,
            row['table_number'] or '',
            row['notes'] or '',
            get_status_label(row['status']),
            row['id'],
        ])

    # Sort by seated time, then by store
    today_rows.sort(key=lambda r: (r[4] or '', r[3] or '', r[1] or ''))

    # 8. Write all rows from Row 2 (after header)
    if today_rows:
        range_str = f'A2:M{1 + len(today_rows)}'
        ws.update(values=today_rows, range_name=range_str, value_input_option='USER_ENTERED')
        log(f'  ✅ 寫入 {len(today_rows)} 行 (Row 2-{1 + len(today_rows)})')
    else:
        log('  ⚠️ 今日無任何已入座記錄')

    log(f'=== {today_str} 完成 ===')

if __name__ == '__main__':
    main()
