// 收銀系統前端邏輯
class CashierSystem {
    // 翻譯字典 (只保留繁體中文)
    static translations = {
        'zh-TW': {
            // 收銀系統翻譯
            'title': '收銀系統',
            'statusConnected': '連線中',
            'groupsPresent': '組客人在場',
            'presentCustomersTitle': '在場客人',
            'emptyStateNoCustomers': '暫無客人在場',
            'refreshListBtn': '刷新列表',
            'totalCustomersStats': '總計: {total} 組客人',
            'todayStatsTitle': '今日統計',
            'todayRevenueLabel': '今日營業額',
            'todayCustomersLabel': '今日客數',
            'avgCheckoutLabel': '平均結賬',
            'checkoutsTodayLabel': '離場數',
            'entryExitRecordsTitle': '入場離場記錄',
            'tableHeaderTime': '時間',
            'tableHeaderTable': '桌號',
            'tableHeaderPeople': '人數',
            'tableHeaderStatus': '狀態',
            'emptyStateNoRecords': '暫無記錄',
            'refreshBtn': '刷新',
            'todayRecordsStats': '今日記錄: {count} 筆',
            'customerDetailTitle': '客人詳情',
            'emptyStateSelectCustomer': '請選擇一位客人查看詳情',
            'qrCodeTitle': 'QR Code',
            'loadingQRCode': '載入QR Code中...',
            'qrTableLabel': '桌號:',
            'qrEntryTimeLabel': '入場時間:',
            'qrLockerLabel': '入口儲物柜:',
            'qrCodeLabel': 'QR Code:',
            'reprintTicketBtn': '重新打印小票',
            'productSelectionTitle': '商品選購',
            'loadingProducts': '載入商品中...',
            'refreshProductsBtn': '刷新商品',
            'productCountStats': '{count} 個商品',
            'currentOrderTitle': '當前訂單',
            'emptyStateSelectCustomerFirst': '請先選擇客人',
            'orderItemCountLabel': '商品數量:',
            'orderTotalLabel': '總金額:',
            'checkoutBtn': '結賬',
            'addOrderBtn': '加單',
            'clearOrderBtn': '清空',
            'deviceControlTitle': '設備控制',
            'devicePrinter': '入口打印機',
            'statusLabel': '狀態:',
            'testBtn': '測試',
            'resetBtn': '重設',
            'deviceLocker': '入口儲物柜',
            'deviceDoorLock': '入口門鎖控制',
            'openDoorBtn': '開門',
            'closeDoorBtn': '關門',
            'deviceAudio': '入口音響',
            'stopBtn': '停止',
            'deviceNFC': '入口NFC讀卡器',
            'systemMessagesTitle': '系統訊息',
            'systemStartedMessage': '收銀系統已啟動',
            'clearMessagesBtn': '清空訊息',
            'footerCashierVersion': '收銀系統 v1.0',
            'footerSystemName': '自動咖啡館系統',
            'staffLabel': '員工:',
            'staffLoginBtn': '員工登入',
            'logoutBtn': '登出',
            'checkoutConfirmTitle': '結賬確認',
            'modalTableLabel': '桌號:',
            'modalPeopleLabel': '客人數:',
            'modalEntryTimeLabel': '入場時間:',
            'modalAmountLabel': '結賬金額:',
            'cancelBtn': '取消',
            'confirmCheckoutBtn': '確認結賬',
            // 新增翻譯
            'loginTitle': '員工登入',
            'loginUsernameLabel': '用戶名:',
            'loginPasswordLabel': '密碼:',
            'rememberMeLabel': '記住我',
            'loginBtn': '登入',
            'tabDashboard': '桌號管理',
            'tabProducts': '商品管理',
            'tabReports': '統計報告',
            'tabSettings': '帳戶設置',
            'tabReceiptManagement': '小票管理',
            // 小票管理翻譯
            'receiptTemplateListTitle': '小票模板列表',
            'addReceiptTemplateBtn': '新增模板',
            'refreshReceiptTemplatesBtn': '刷新列表',
            'receiptTemplateNameColumn': '模板名稱',
            'receiptTemplateStoreColumn': '適用分店',
            'receiptTemplateDefaultColumn': '默認模板',
            'receiptTemplateCreatedAtColumn': '創建時間',
            'actionsColumn': '操作',
            'receiptTemplateEditorTitle': '模板編輯器',
            'receiptTemplateNameLabel': '模板名稱:',
            'receiptTemplateStoreLabel': '適用分店:',
            'receiptTemplateIsDefaultLabel': '設為默認模板',
            'receiptTemplateHeaderSettingsTitle': '小票頭部設置',
            'receiptCompanyNameLabel': '公司名稱:',
            'receiptStoreNameLabel': '分店名稱:',
            'receiptHeaderTextLabel': '頭部文本:',
            'receiptTemplateContentSettingsTitle': '內容設置',
            'receiptShowQrCodeLabel': '顯示QR碼:',
            'receiptShowLockerInfoLabel': '顯示儲物柜信息:',
            'receiptFontSizeLabel': '字體大小:',
            'receiptTemplateFooterSettingsTitle': '底部設置',
            'receiptFooterTextLabel': '底部文本:',
            'receiptContactInfoLabel': '聯繫信息:',
            'saveReceiptTemplateBtn': '保存模板',
            'receiptPreviewTitle': '預覽',
            'refreshPreviewBtn': '刷新預覽',
            'testPrintBtn': '測試打印',
            // 商品管理翻譯
            'addProductBtn': '新增商品',
            'batchAddProductsBtn': '批量新增商品',
            'exportProductsBtn': '匯出商品',
            'editProductTitle': '編輯商品',
            'addProductTitle': '新增商品',
            'noProductsFound': '找不到符合條件的商品',
            'editBtn': '編輯',
            'deleteBtn': '刪除',
            'searchLabel': '搜尋:',
            'categoryLabel': '類別:',
            'stockFilterLabel': '庫存狀態:',
            'productName': '商品名稱',
            'productCategory': '類別',
            'productPrice': '價格',
            'productStock': '庫存',
            'productMinStock': '最低庫存',
            'productActions': '操作',
            'totalProducts': '總商品數:',
            'prevPage': '上一頁',
            'nextPage': '下一頁',
            'productNameLabel': '商品名稱:',
            'productDescriptionLabel': '描述:',
            'productPriceLabel': '價格:',
            'productStockLabel': '庫存:',
            'productMinStockLabel': '最低庫存:',
            'productCategoryLabel': '類別:',
            'productUUIDLabel': '商品UUID:',
            'productUUIDHelp': '自定義商品唯一識別碼，必須是唯一的',
            'saveProductBtn': '保存商品',
            // 批量上傳翻譯
            'batchUploadTitle': '批量新增商品',
            'csvFileLabel': 'CSV檔案:',
            'csvFormatHelp': 'CSV格式：第一列商品名稱，第二列分類，第三列UUID，第四列價格，第五列順序（數字越小排序越前，庫存預設為"不計庫存"）',
            'csvPreviewLabel': 'CSV預覽:',
            'noFileSelected': '未選擇檔案',
            'uploadSummaryLabel': '上傳摘要:',
            'noDataToUpload': '無數據可上傳',
            'uploadCSVBtn': '上傳CSV',
            // 刪除桌號翻譯
            'deleteTableConfirmTitle': '刪除桌號確認',
            'deleteTableWarning': '確定要刪除此桌號嗎？此操作無法還原。',
            'confirmDeleteTableBtn': '確認刪除',
            // 購物車翻譯
            'cartTitle': '購物車',
            'cartTotalItems': '商品數量:',
            'cartTotalAmount': '總金額:',
            'cartCheckoutBtn': '結賬',
            'cartSuspendBtn': '掛單',
            'cartClearBtn': '清空',
            'addTableBtn': '新增桌號',
            'clearAllCustomersBtn': '清空所有桌號',
            // 商品時效翻譯
            'productTimeRestrictionLabel': '商品時效',
            'productTimeRestrictionHelp': '啟用後商品只在指定時間段顯示',
            'productWeekdayStartLabel': '閒日開始時間:',
            'productWeekdayStartHelp': '格式: HH:MM (如14:00)',
            'productWeekdayEndLabel': '閒日結束時間:',
            'productWeekdayEndHelp': '格式: HH:MM (如19:00)',
            'productHolidayStartLabel': '節假日開始時間:',
            'productHolidayStartHelp': '格式: HH:MM (如14:00)',
            'productHolidayEndLabel': '節假日結束時間:',
            'productHolidayEndHelp': '格式: HH:MM (如19:00)',
            'productTimeRestrictionNote': '注意: 閒日指節假日以外的日期，節假日默認包含星期六日，可在帳戶設置中管理其他節假日。',
            'emptyStateCart': '購物車是空的',
            // 分店管理翻譯
            'tabStoreManagement': '分店管理',
            'storeNameLabel': '分店名稱:',
            'storeCodeLabel': '分店代碼:',
            'storeAddressLabel': '地址:',
            'storePhoneLabel': '電話:',
            'storeEmailLabel': '電子郵件:',
            'storeOpeningHoursLabel': '營業時間:',
            'storeStatusLabel': '狀態:',
            'storeDescriptionLabel': '描述:',
            'storeSettingsLabel': '系統設定 (JSON):',
            'addStoreBtn': '新增分店',
            'saveStoreBtn': '保存分店資料',
            'cancelStoreBtn': '取消',
            'editStoreBtn': '編輯',
            'deleteStoreBtn': '刪除',
            'refreshStoresBtn': '刷新列表',
            'storeListTitle': '分店列表',
            'storeFormTitle': '分店資料',
            'noStoresFound': '沒有分店數據',
            'confirmDeleteStore': '確定要刪除此分店嗎？此操作無法還原。',
            'storeCreatedSuccess': '分店創建成功',
            'storeUpdatedSuccess': '分店更新成功',
            'storeDeletedSuccess': '分店刪除成功',
            'storeSettingsHelp': '分店特定設定，JSON格式',
            'storeDescriptionPlaceholder': '分店簡介',
            // 打印機配置翻譯
            'printerTypeLabel': '打印機類型:',
            'printerTypeEpson': 'EPSON ESC/POS',
            'printerTypeStar': 'STAR',
            'printerConfigManagement': '打印機配置',
            'selectSavedConfig': '選擇保存的配置...',
            'testSelectedConfig': '測試',
            'enterConfigName': '輸入配置名稱以保存',
            'saveConfigBtn': '保存',
            'setDefaultConfigBtn': '默認',
            'deleteConfigBtn': '刪除',
            'saveCurrentConfig': '保存當前設置為配置',
            'setAsDefaultConfig': '設為默認配置',
            'deleteSelectedConfig': '刪除選中配置',
            'scanBtn': '掃描',
            'connectBtn': '連接',
            'disconnectBtn': '斷開'
        }
    };

    // 解析入場時間字符串，支援兩種格式：
    // 1. ISO 字符串 (UTC) 例如 "2026-03-24T07:31:00.000Z"
    // 2. 本地時間字符串 "YYYY-MM-DD HH:MM:SS"
    parseEntryTime(entryTimeString) {
        if (!entryTimeString) return new Date();

        // 檢查是否為 ISO 格式 (包含 'T' 或結尾有 'Z')
        if (entryTimeString.includes('T') || entryTimeString.endsWith('Z')) {
            // ISO 格式，直接解析為 UTC
            return new Date(entryTimeString);
        } else {
            // SQLite 格式 "YYYY-MM-DD HH:MM:SS"（SQLite CURRENT_TIMESTAMP 回傳 UTC，無時區資訊）
            // 使用 Date.UTC() 確保不受瀏覽器本地時區影響
            const [datePart, timePart] = entryTimeString.split(' ');
            const [year, month, day] = datePart.split('-').map(Number);
            const [hours, minutes, seconds] = timePart.split(':').map(Number);
            return new Date(Date.UTC(year, month - 1, day, hours, minutes, seconds));
        }
    }

    constructor() {
        this.socket = null;
        this.customers = [];
        this.products = [];
        this.selectedCustomer = null;
        this.currentOrderItems = [];
        this.staffName = '未登入';
        this.totalCustomersCount = 0;
        this.todayRecordsCount = 0;
        this.productCount = 0;
        this.selectedStoreId = ''; // 當前選擇的分店ID，空字符串表示"全部"
        this.accessibleStores = []; // 可訪問的分店列表
        this.receiptPrinterConnectionType = null; // 當前小票機連接類型
        this.hasAttemptedPrinterReconnect = false; // 標記是否已經嘗試過自動重連小票機
        this.printerReconnectAttempts = 0; // 重連嘗試次數
        this.printerReconnectMaxAttempts = 3; // 最大重連嘗試次數
        this.printerReconnectTimer = null; // 重連定時器
        this.printerConnectionTimeout = 2000; // 連接超時時間（2秒）
        this._snackRefreshTimer = null; // 可售零食刷新定時器
        this._snackCustomerData = null; // 可售零食計算用客人數據
        this.init();
    }

    async init() {
        // 連接Socket.IO
        this.connectSocket();

        // 綁定事件監聽器
        this.bindEvents();

        // 設定繁體中文介面
        this.translatePage('zh-TW');

        // 加載可訪問的分店列表（先加載以設置默認分店）
        await this.loadAccessibleStores();

        // 載入初始數據（在分店選擇器設置後）
        this.loadCustomers();
        this.loadProducts();
        this.loadTodayStats();
        this.loadEntryRecords();
        this.loadDeviceStatus();

        // 初始化打印機配置管理（异步但不阻塞）
        this.initPrinterConfigManagement().catch(err => console.error('打印机初始化失败:', err));

        // 初始化系統訊息
        this.addMessage('收銀系統啟動完成', 'info');

        // 修復：確保連接按鈕在初始化時是可用的
        const connectBtn = document.getElementById('connect-receipt-printer-btn');
        if (connectBtn) {
            console.log('初始化完成，檢查連接按鈕狀態:', {
                disabled: connectBtn.disabled,
                classList: connectBtn.classList.toString(),
                style: window.getComputedStyle(connectBtn).opacity
            });
            // 強制啟用連接按鈕（無論是否已連接，允許更改IP重新連接）
            if (connectBtn.disabled) {
                console.log('連接按鈕被禁用，強制啟用（允許更改IP重新連接）');
                connectBtn.disabled = false;
            }
        }

        // 添加頁面可見性事件監聽器，在頁面重新顯示時重新連接小票機
        // 使用防抖動機制避免頻繁重連
        let visibilityTimeout = null;
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) {
                console.log('頁面重新顯示，檢查是否需要重連小票機...');

                // 清除之前的定時器
                if (visibilityTimeout) {
                    clearTimeout(visibilityTimeout);
                }

                // 檢查小票機當前狀態，如果不是已連接狀態才嘗試重連
                const statusElement = document.getElementById('receipt-printer-status');
                if (statusElement && statusElement.textContent.includes('已連接')) {
                    console.log('小票機已是連接狀態，跳過重連');
                    return;
                }

                // 延遲執行，確保頁面完全加載且避免頻繁重連
                visibilityTimeout = setTimeout(async () => {
                    // 只加載配置，不自動連接（避免重複嘗試）
                    await this.loadPrinterConfigs(false);
                }, 1000);
            }
        });
    }

    connectSocket() {
        this.socket = io();

        this.socket.on('connect', () => {
            this.updateStatus('online');
            this.addMessage('已連線到伺服器', 'success');
        });

        this.socket.on('disconnect', () => {
            this.updateStatus('offline');
            this.addMessage('與伺服器斷開連線', 'error');
        });

        this.socket.on('customer-added', (data) => {
            this.addMessage(`新客人入場: 桌號 ${data.table_number}, ${data.people_count}位`, 'info');
            this.loadCustomers();
            this.loadTodayStats();
        });

        this.socket.on('order-updated', (data) => {
            if (this.selectedCustomer && this.selectedCustomer.id === data.customer_id) {
                this.addMessage(`已添加商品: ${data.product_name} x${data.quantity}`, 'success');
                this.loadCustomerDetail(this.selectedCustomer.id);
            }
            // 刷新在場客人列表（因為訂單金額變更）
            this.loadCustomers();
        });

        this.socket.on('checkout-complete', (data) => {
            this.addMessage(`桌號 ${data.table_number} 已結賬, 金額: $${data.total_amount}`, 'success');
            this.loadCustomers();
            this.loadTodayStats();
            this.clearSelectedCustomer();
        });

        this.socket.on('customer-deleted', (data) => {
            this.addMessage(`桌號 ${data.table_number} 已刪除`, 'info');
            if (this.selectedCustomer && this.selectedCustomer.id === data.customer_id) {
                this.clearSelectedCustomer();
            }
            this.loadCustomers();
            this.loadTodayStats();
        });

        // 設備狀態更新
        this.socket.on('device-update', (data) => {
            this.updateDeviceStatus(data);
        });

        // 新客人入場時更新入場紀錄
        this.socket.on('new-customer', (data) => {
            this.loadEntryRecords();
        });
    }

    bindEvents() {
        console.log('bindEvents called');
        // 刷新按鈕 - 添加null檢查
        const refreshCustomersBtn = document.getElementById('refresh-customers-btn');
        if (refreshCustomersBtn) refreshCustomersBtn.addEventListener('click', () => this.loadCustomers());

        const refreshProductsBtn = document.getElementById('refresh-products-btn');
        if (refreshProductsBtn) refreshProductsBtn.addEventListener('click', () => this.loadProducts());

        const cashierRefreshEntriesBtn = document.getElementById('cashier-refresh-entries-btn');
        if (cashierRefreshEntriesBtn) cashierRefreshEntriesBtn.addEventListener('click', () => this.loadEntryRecords());

        // 結賬按鈕
        const checkoutBtn = document.getElementById('checkout-btn');
        if (checkoutBtn) checkoutBtn.addEventListener('click', () => this.showCheckoutModal());

        // 換桌按鈕
        const changeTableBtn = document.getElementById('change-table-btn');
        if (changeTableBtn) changeTableBtn.addEventListener('click', () => this.changeTable());

        // 模態框換桌按鈕
        const modalChangeTableBtn = document.getElementById('modal-change-table-btn');
        if (modalChangeTableBtn) modalChangeTableBtn.addEventListener('click', () => this.changeTable());

        const deleteTableBtn = document.getElementById('delete-table-btn');
        if (deleteTableBtn) deleteTableBtn.addEventListener('click', () => this.showDeleteTableModal());

        // QR Code重新打印
        const reprintQrBtn = document.getElementById('reprint-qr-btn');
        if (reprintQrBtn) reprintQrBtn.addEventListener('click', () => this.reprintQRCode());

        // 系統訊息控制
        const clearMessagesBtn = document.getElementById('clear-messages-btn');
        if (clearMessagesBtn) clearMessagesBtn.addEventListener('click', () => this.clearMessages());

        // 員工登入/登出
        const staffLoginBtn = document.getElementById('staff-login-btn');
        if (staffLoginBtn) staffLoginBtn.addEventListener('click', () => this.staffLogin());

        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) logoutBtn.addEventListener('click', () => this.logout());

        // 分店選擇器
        const storeSelector = document.getElementById('store-selector');
        if (storeSelector) {
            storeSelector.addEventListener('change', (e) => {
                this.handleStoreChange(e.target.value);
            });
        }

        // 結賬模態框
        const cancelCheckoutBtn = document.getElementById('cancel-checkout-btn');
        if (cancelCheckoutBtn) cancelCheckoutBtn.addEventListener('click', () => this.hideCheckoutModal());

        const confirmCheckoutBtn = document.getElementById('confirm-checkout-btn');
        if (confirmCheckoutBtn) confirmCheckoutBtn.addEventListener('click', () => this.confirmCheckout());

        // 刪除桌號模態框
        const cancelDeleteTableBtn = document.getElementById('cancel-delete-table-btn');
        if (cancelDeleteTableBtn) cancelDeleteTableBtn.addEventListener('click', () => this.hideDeleteTableModal());
        const confirmDeleteTableBtn = document.getElementById('confirm-delete-table-btn');
        if (confirmDeleteTableBtn) confirmDeleteTableBtn.addEventListener('click', () => this.confirmDeleteTable());

        // 設備控制按鈕
        const printerTestBtn = document.getElementById('printer-test-btn');
        if (printerTestBtn) printerTestBtn.addEventListener('click', () => this.testPrinter());

        const printerResetBtn = document.getElementById('printer-reset-btn');
        if (printerResetBtn) printerResetBtn.addEventListener('click', () => this.resetPrinter());

        const lockerTestBtn = document.getElementById('locker-test-btn');
        if (lockerTestBtn) lockerTestBtn.addEventListener('click', () => this.testLocker());

        const lockerResetBtn = document.getElementById('locker-reset-btn');
        if (lockerResetBtn) lockerResetBtn.addEventListener('click', () => this.resetLocker());

        const doorlockOpenBtn = document.getElementById('doorlock-open-btn');
        if (doorlockOpenBtn) doorlockOpenBtn.addEventListener('click', () => this.openDoorLock());

        const doorlockCloseBtn = document.getElementById('doorlock-close-btn');
        if (doorlockCloseBtn) doorlockCloseBtn.addEventListener('click', () => this.closeDoorLock());

        const audioTestBtn = document.getElementById('audio-test-btn');
        if (audioTestBtn) audioTestBtn.addEventListener('click', () => this.testAudio());

        const audioStopBtn = document.getElementById('audio-stop-btn');
        if (audioStopBtn) audioStopBtn.addEventListener('click', () => this.stopAudio());

        const nfcTestBtn = document.getElementById('nfc-test-btn');
        if (nfcTestBtn) nfcTestBtn.addEventListener('click', () => this.testNFC());

        const nfcResetBtn = document.getElementById('nfc-reset-btn');
        if (nfcResetBtn) nfcResetBtn.addEventListener('click', () => this.resetNFC());

        // 小票機連接按鈕
        const connectReceiptPrinterBtn = document.getElementById('connect-receipt-printer-btn');
        if (connectReceiptPrinterBtn) {
            // 先移除現有的事件監聽器，防止重複綁定
            connectReceiptPrinterBtn.replaceWith(connectReceiptPrinterBtn.cloneNode(true));
            const newConnectBtn = document.getElementById('connect-receipt-printer-btn');
            newConnectBtn.addEventListener('click', () => {
                console.log('連接小票機按鈕被點擊，時間戳:', new Date().toISOString());
                this.connectReceiptPrinter();
            });
        }

        const disconnectReceiptPrinterBtn = document.getElementById('disconnect-receipt-printer-btn');
        if (disconnectReceiptPrinterBtn) {
            // 先移除現有的事件監聽器，防止重複綁定
            disconnectReceiptPrinterBtn.replaceWith(disconnectReceiptPrinterBtn.cloneNode(true));
            const newDisconnectBtn = document.getElementById('disconnect-receipt-printer-btn');
            newDisconnectBtn.addEventListener('click', () => {
                console.log('斷開小票機按鈕被點擊，時間戳:', new Date().toISOString());
                this.disconnectReceiptPrinter();
            });
        }

        const testReceiptPrinterBtn = document.getElementById('test-receipt-printer-btn');
        if (testReceiptPrinterBtn) testReceiptPrinterBtn.addEventListener('click', () => this.testReceiptPrinter());

        const scanBluetoothBtn = document.getElementById('scan-bluetooth-btn');
        if (scanBluetoothBtn) scanBluetoothBtn.addEventListener('click', () => {
            console.log('Scan Bluetooth button clicked');
            this.scanBluetoothDevices();
        });

        // 連接類型切換事件
        const connectionRadios = document.querySelectorAll('input[name="receipt-printer-connection"]');
        console.log(`找到 ${connectionRadios.length} 個連接類型單選按鈕`);
        connectionRadios.forEach((radio, index) => {
            console.log(`單選按鈕 ${index}: value=${radio.value}, checked=${radio.checked}`);
            radio.addEventListener('change', (e) => {
                console.log(`連接類型變更: ${e.target.value}`);
                this.handleConnectionTypeChange(e.target.value);
            });
        });

        // 藍牙模式切換事件
        const bluetoothModeRadios = document.querySelectorAll('input[name="bluetooth-mode"]');
        console.log(`找到 ${bluetoothModeRadios.length} 個藍牙模式單選按鈕`);
        bluetoothModeRadios.forEach((radio, index) => {
            console.log(`藍牙模式按鈕 ${index}: value=${radio.value}, checked=${radio.checked}`);
            radio.addEventListener('change', (e) => {
                console.log(`藍牙模式變更: ${e.target.value}`);
                this.handleBluetoothModeChange(e.target.value);
            });
        });

        // 設置標籤導航
        this.setupTabNavigation();

        // 主機IP設定按鈕
        const saveMasterIpBtn = document.getElementById('save-master-ip-btn');
        if (saveMasterIpBtn) saveMasterIpBtn.addEventListener('click', () => this.saveMasterIp());

        const applyMasterIpBtn = document.getElementById('apply-master-ip-btn');
        if (applyMasterIpBtn) applyMasterIpBtn.addEventListener('click', () => this.applyMasterIp());

        const detectMasterIpBtn = document.getElementById('detect-master-ip-btn');
        if (detectMasterIpBtn) detectMasterIpBtn.addEventListener('click', () => this.detectMasterIp());

        // 初始化主機IP設定
        this.initMasterIpSettings();

        // 設置分店管理事件
        this.setupStoreManagementEvents();
    }

    /**
     * 設置標籤導航
     */
    setupTabNavigation() {
        const tabButtons = document.querySelectorAll('.tab-button');
        if (!tabButtons.length) return;

        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                const tabId = button.getAttribute('data-tab');
                this.switchTab(tabId);
            });
        });
    }

    /**
     * 切換標籤
     */
    switchTab(tabId) {
        // 隱藏所有標籤內容
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.add('hidden');
        });

        // 移除所有標籤按鈕的active類
        document.querySelectorAll('.tab-button').forEach(button => {
            button.classList.remove('active');
        });

        // 顯示選中的標籤內容
        const tabContent = document.getElementById(`tab-${tabId}`);
        if (tabContent) {
            tabContent.classList.remove('hidden');
        }

        // 添加active類到當前標籤按鈕
        const activeButton = document.querySelector(`.tab-button[data-tab="${tabId}"]`);
        if (activeButton) {
            activeButton.classList.add('active');
        }

        // 根據標籤加載數據
        switch (tabId) {
            case 'store-management':
                this.loadStores();
                break;
            case 'products':
                this.loadProducts();
                break;
            case 'dashboard':
                this.loadCustomers();
                this.loadEntryRecords();
                break;
            case 'reports':
                // 未來可以加載報告數據
                break;
            // 其他標籤可以添加對應的數據加載
        }
    }

    translatePage(lang) {
        const translations = CashierSystem.translations[lang];
        if (!translations) {
            console.warn(`No translations found for language: ${lang}`);
            return;
        }

        // 更新所有帶有 data-i18n 屬性的元素
        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n');
            if (translations[key]) {
                // 處理帶有佔位符的翻譯
                let text = translations[key];

                // 替換動態內容佔位符
                if (key === 'totalCustomersStats') {
                    text = text.replace('{total}', this.totalCustomersCount);
                }
                if (key === 'todayRecordsStats') {
                    text = text.replace('{count}', this.todayRecordsCount);
                }
                if (key === 'productCountStats') {
                    text = text.replace('{count}', this.productCount);
                }

                element.textContent = text;
            }
        });

        // 更新 HTML lang 屬性
        document.documentElement.lang = lang;

    }

    updateTotalCustomersStats(count) {
        this.totalCustomersCount = count;
        this.updateTranslatedElement('total-customers-stats', 'totalCustomersStats', {total: count});
    }

    updateTodayRecordsStats(count) {
        this.todayRecordsCount = count;
        this.updateTranslatedElement('today-records-stats', 'todayRecordsStats', {count: count});
    }

    updateProductCountStats(count) {
        this.productCount = count;
        this.updateTranslatedElement('product-count', 'productCountStats', {count: count});
    }

    updateTranslatedElement(elementId, translationKey, placeholders) {
        const translations = CashierSystem.translations['zh-TW'];
        if (!translations) return;
        let text = translations[translationKey];
        if (!text) return;
        Object.keys(placeholders).forEach(key => {
            text = text.replace(`{${key}}`, placeholders[key]);
        });
        const element = document.getElementById(elementId);
        if (element) {
            element.textContent = text;
        }
    }


    updateStatus(status) {
        const statusBar = document.querySelector('.status-bar .status');
        if (status === 'online') {
            statusBar.classList.add('online');
            statusBar.innerHTML = '<i class="fas fa-wifi"></i><span>連線中</span>';
        } else {
            statusBar.classList.remove('online');
            statusBar.innerHTML = '<i class="fas fa-wifi"></i><span>離線中</span>';
        }
    }

    async loadCustomers() {
        try {
            // 構建查詢參數
            const params = new URLSearchParams();
            if (this.selectedStoreId) {
                params.append('store_id', this.selectedStoreId);
            }

            const url = `/api/cashier/customers${params.toString() ? '?' + params.toString() : ''}`;
            const response = await fetch(url);
            const result = await response.json();

            if (result.success) {
                this.customers = result.customers;
                this.displayCustomers();
                this.updateCustomerCount();
            }
        } catch (error) {
            this.addMessage('載入客人列表失敗: ' + error.message, 'error');
        }
    }

    displayCustomers() {
        const customerList = document.getElementById('customer-list');

        if (this.customers.length === 0) {
            customerList.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-users"></i>
                    <p>暫無客人在場</p>
                </div>
            `;
            return;
        }

        customerList.innerHTML = '';

        this.customers.forEach(customer => {
            const customerEl = document.createElement('div');
            customerEl.className = `customer-item ${this.selectedCustomer?.id === customer.id ? 'active' : ''}`;
            customerEl.dataset.customerId = customer.id;

            const entryTime = this.parseEntryTime(customer.entry_time).toLocaleTimeString('zh-TW', {
                hour: '2-digit',
                minute: '2-digit'
            });

            customerEl.innerHTML = `
                <div class="customer-info">
                    <div class="customer-table">桌號 ${customer.table_number}</div>
                    <div class="customer-meta">
                        <span>${customer.people_count}位</span>
                        <span>${entryTime}入場</span>
                    </div>
                </div>
                <div class="customer-amount">$${customer.total_amount || 0}</div>
            `;

            customerEl.addEventListener('click', () => this.selectCustomer(customer.id));

            customerList.appendChild(customerEl);
        });
    }

    updateCustomerCount() {
        const activeCount = this.customers.length;
        document.getElementById('active-customers').textContent = activeCount;
        this.updateTotalCustomersStats(activeCount);
    }

    async selectCustomer(customerId) {
        console.log('[DEBUG] selectCustomer called with customerId:', customerId);
        this.selectedCustomer = this.customers.find(c => c.id === customerId);
        console.log('[DEBUG] Selected customer:', this.selectedCustomer);
        this.displayCustomers();
        await this.loadCustomerDetail(customerId);
        await this.loadCustomerQRCode(customerId); // 載入QR Code
        await this.loadOrderItems(customerId);
        this.updateOrderButtons();
    }

    async loadCustomerDetail(customerId) {
        try {
            // 構建查詢參數
            const params = new URLSearchParams();
            if (this.selectedStoreId) {
                params.append('store_id', this.selectedStoreId);
            }

            const url = `/api/cashier/customer/${customerId}${params.toString() ? '?' + params.toString() : ''}`;
            console.log('[DEBUG] loadCustomerDetail fetching URL:', url);
            const response = await fetch(url);
            const result = await response.json();
            console.log('[DEBUG] loadCustomerDetail result:', result);

            if (result.success) {
                console.log('[DEBUG] loadCustomerDetail calling displayCustomerDetail');
                this.displayCustomerDetail(result.customer);
            } else {
                console.log('[DEBUG] loadCustomerDetail API error:', result.error);
            }
        } catch (error) {
            console.error('[DEBUG] loadCustomerDetail error:', error);
            this.addMessage('載入客人詳情失敗: ' + error.message, 'error');
        }
    }

    displayCustomerDetail(customer) {
        console.log('[DEBUG] displayCustomerDetail called with customer:', customer);
        const customerInfo = document.getElementById('customer-info');
        const emptyState = document.getElementById('customer-empty-state');

        console.log('[DEBUG] customerInfo element:', customerInfo);
        console.log('[DEBUG] emptyState element:', emptyState);

        if (!customerInfo || !emptyState) {
            console.error('[DEBUG] customerInfo or emptyState not found!');
            return;
        }

        const entryTime = this.parseEntryTime(customer.entry_time).toLocaleString('zh-TW', {
            hour: '2-digit',
            minute: '2-digit'
        });

        // 計算可售零食
        const snackInfo = this.calculateAvailableSnacks(customer);
        const snackClass = snackInfo.available > 0 ? 'snacks-available' : 'snacks-empty';
        const nextRefresh = snackInfo.nextRefresh
            ? snackInfo.nextRefresh.toLocaleTimeString('zh-TW', { hour: '2-digit', minute: '2-digit' })
            : '--:--';

        console.log('[DEBUG] Setting customerInfo HTML');
        customerInfo.innerHTML = `
            <div class="detail-info">
                <div class="detail-row">
                    <span class="detail-label">桌號:</span>
                    <span class="detail-value">${customer.table_number}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">客人數:</span>
                    <span class="detail-value">${customer.people_count}位</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">入場時間:</span>
                    <span class="detail-value">${entryTime}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">儲物柜:</span>
                    <span class="detail-value">${customer.lockers?.length > 0 ? customer.lockers.join(', ') : (customer.lockers_used ? customer.lockers_used : '無')}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">可售零食:</span>
                    <span class="detail-value ${snackClass} available-snacks-count">
                        ${snackInfo.available}份
                        <span class="snack-refresh-hint">下次刷新 ${nextRefresh}</span>
                    </span>
                </div>
                <div class="detail-row total">
                    <span class="detail-label">當前消費:</span>
                    <span class="detail-value">$${customer.total_amount || 0}</span>
                </div>
            </div>
        `;

        // 儲存客人數據供定時刷新可售零食
        this._snackCustomerData = {
            people_count: customer.people_count,
            entry_time: customer.entry_time
        };
        this.startSnackRefreshTimer();

        // 顯示客人詳情區
        console.log('[DEBUG] Before class manipulation:');
        console.log('[DEBUG] emptyState.classList:', emptyState.classList);
        console.log('[DEBUG] customerInfo.classList:', customerInfo.classList);

        emptyState.classList.add('hidden');
        customerInfo.classList.remove('hidden');

        console.log('[DEBUG] After class manipulation:');
        console.log('[DEBUG] emptyState.classList:', emptyState.classList);
        console.log('[DEBUG] customerInfo.classList:', customerInfo.classList);
        console.log('[DEBUG] emptyState display style:', window.getComputedStyle(emptyState).display);
        console.log('[DEBUG] customerInfo display style:', window.getComputedStyle(customerInfo).display);

    }

    calculateAvailableSnacks(customer) {
        const peopleCount = parseInt(customer.people_count) || 0;
        if (peopleCount === 0) {
            return { available: 0, nextRefresh: null };
        }

        // 每4人可售一份，1-4人=1份，5-8人=2份...（上限即為此數，不隨時間累積）
        const baseQuota = Math.ceil(peopleCount / 4);

        // 入場時間起計經過的小時數
        const entryDate = this.parseEntryTime(customer.entry_time);
        const now = new Date();
        const elapsedMs = now - entryDate;
        const elapsedHours = Math.floor(elapsedMs / (60 * 60 * 1000));

        // 當前60分鐘時段的起始時間
        const currentWindowStart = new Date(entryDate.getTime() + elapsedHours * 60 * 60 * 1000);

        // 已點的貓零食總數（只計算當前時段內的）
        const orderItems = customer.order_items || this.currentOrderItems || [];
        const catSnacksInWindow = orderItems
            .filter(item => {
                if (item.category !== '貓零食') return false;
                // 如果有購買時間，只計入當前時段
                if (item.purchased_at) {
                    const purchasedTime = this.parseEntryTime(item.purchased_at);
                    return purchasedTime >= currentWindowStart;
                }
                return true; // 無時間資訊則全部計入
            })
            .reduce((sum, item) => sum + (item.quantity || 0), 0);

        const available = Math.max(0, baseQuota - catSnacksInWindow);

        // 計算下次刷新時間（入場時間 + (已過小時數+1) × 60分鐘）
        const nextRefresh = new Date(entryDate.getTime() + (elapsedHours + 1) * 60 * 60 * 1000);

        return { available, nextRefresh };
    }

    updateAvailableSnacksDisplay() {
        if (!this._snackCustomerData) return;
        const snackInfo = this.calculateAvailableSnacks(this._snackCustomerData);
        const els = document.querySelectorAll('.available-snacks-count');
        if (els.length === 0) return;

        const snackClass = snackInfo.available > 0 ? 'snacks-available' : 'snacks-empty';
        const nextRefresh = snackInfo.nextRefresh
            ? snackInfo.nextRefresh.toLocaleTimeString('zh-TW', { hour: '2-digit', minute: '2-digit' })
            : '--:--';
        const html = `${snackInfo.available}份<span class="snack-refresh-hint">下次刷新 ${nextRefresh}</span>`;

        els.forEach(el => {
            el.className = `detail-value ${snackClass} available-snacks-count`;
            el.innerHTML = html;
        });
    }

    startSnackRefreshTimer() {
        this.stopSnackRefreshTimer();
        this._snackRefreshTimer = setInterval(() => {
            this.updateAvailableSnacksDisplay();
        }, 30000); // 每30秒檢查一次
    }

    stopSnackRefreshTimer() {
        if (this._snackRefreshTimer) {
            clearInterval(this._snackRefreshTimer);
            this._snackRefreshTimer = null;
        }
    }

    async changeTable(customer) {
        // 如果沒有傳入customer參數，使用當前選中的顧客
        if (!customer && this.selectedCustomer) {
            customer = this.selectedCustomer;
        }
        if (!customer) {
            this.addMessage('請先選擇一位客人', 'error');
            return;
        }

        // 提示輸入新桌號
        const newTableInput = prompt('請輸入新桌號 (例如: 3 或 A3):', '');
        if (newTableInput === null || newTableInput.trim() === '') {
            this.addMessage('換桌操作已取消', 'info');
            return;
        }

        const newTableNumber = newTableInput.trim();

        // 提取當前桌號的前綴和數字
        const currentTable = customer.table_number;
        let prefix = '';
        let numberPart = '';

        // 如果桌號以字母開頭，則將第一個字母作為前綴
        if (currentTable.match(/^[A-Za-z]/)) {
            prefix = currentTable.charAt(0).toUpperCase();
            numberPart = currentTable.substring(1);
        } else {
            numberPart = currentTable;
        }

        // 確定新桌號
        let finalTableNumber = newTableNumber;
        // 如果用戶只輸入數字，則添加前綴
        if (/^\d+$/.test(newTableNumber) && prefix) {
            finalTableNumber = prefix + newTableNumber;
        }
        // 轉換為大寫以保持一致性
        finalTableNumber = finalTableNumber.toUpperCase();

        // 檢查是否與當前桌號相同
        if (finalTableNumber === currentTable.toUpperCase()) {
            this.addMessage('新桌號與當前桌號相同，請輸入不同的桌號', 'warning');
            return;
        }

        // 檢查新桌號是否已存在 (排除當前顧客)
        const isTableExists = this.customers.some(c =>
            c.id !== customer.id && c.table_number === finalTableNumber
        );

        if (isTableExists) {
            this.addMessage(`桌號 ${finalTableNumber} 已存在，請選擇其他桌號`, 'error');
            return;
        }

        // 調用 API 更新桌號
        try {
            this.addMessage(`正在更新桌號為 ${finalTableNumber}...`, 'info');
            const response = await fetch('/api/cashier/update-table', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    customer_id: customer.id,
                    table_number: finalTableNumber
                })
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage(`桌號已更新: ${currentTable} → ${finalTableNumber}`, 'success');
                // 刷新客人列表和詳情
                await this.loadCustomers();
                // 重新選擇當前顧客以更新詳情
                await this.selectCustomer(customer.id);
            } else {
                this.addMessage(`更新桌號失敗: ${result.error}`, 'error');
            }
        } catch (error) {
            this.addMessage(`更新桌號失敗: ${error.message}`, 'error');
        }
    }

    async loadProducts() {
        try {
            console.log('loadProducts: 正在調用 /api/cashier/products');
            const response = await fetch('/api/cashier/products');
            const result = await response.json();

            console.log('loadProducts: API響應:', {
                success: result.success,
                productsCount: result.products ? result.products.length : 0,
                productsSample: result.products ? result.products.slice(0, 5).map(p => ({id: p.id, name: p.name})) : '無'
            });

            if (result.success) {
                this.products = result.products;
                console.log(`loadProducts: 設置了 ${this.products.length} 個商品到 this.products`);
                this.displayProducts();
            } else {
                console.error('loadProducts: API返回失敗:', result);
            }
        } catch (error) {
            console.error('loadProducts: 錯誤:', error);
            this.addMessage('載入商品列表失敗: ' + error.message, 'error');
        }
    }

    displayProducts() {
        const productGrid = document.getElementById('product-grid');

        // 如果商品網格不存在（例如，商品選購格子已被移除），則直接返回
        if (!productGrid) {
            console.log('product-grid element not found, skipping displayProducts');
            return;
        }

        if (this.products.length === 0) {
            productGrid.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-box-open"></i>
                    <p>暫無商品資料</p>
                </div>
            `;
            return;
        }

        productGrid.innerHTML = '';
        this.updateProductCountStats(this.products.length);

        this.products.forEach(product => {
            const productEl = document.createElement('div');
            productEl.className = `product-item ${product.stock <= 0 ? 'out-of-stock' : ''}`;
            productEl.dataset.productId = product.id;
            productEl.dataset.productName = product.name;
            productEl.dataset.productPrice = product.price;
            productEl.dataset.productStock = product.stock;

            productEl.innerHTML = `
                <div class="product-name">${product.name}</div>
                <div class="product-price">$${product.price}</div>
                <div class="product-stock">庫存: ${product.stock}</div>
            `;

            if (product.stock > 0) {
                productEl.addEventListener('click', () => this.addProductToOrder(product.id));
            }

            productGrid.appendChild(productEl);
        });
    }

    async addProductToOrder(productId) {
        if (!this.selectedCustomer) {
            this.addMessage('請先選擇客人', 'warning');
            return;
        }

        const product = this.products.find(p => p.id === productId);
        if (!product) {
            this.addMessage('商品不存在', 'error');
            return;
        }

        if (product.stock <= 0) {
            this.addMessage('商品庫存不足', 'warning');
            return;
        }

        try {
            const response = await fetch('/api/cashier/add-order-item', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    customer_id: this.selectedCustomer.id,
                    product_id: productId,
                    quantity: 1
                })
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage(`已添加 ${product.name} x1`, 'success');
                this.loadCustomerDetail(this.selectedCustomer.id);
                this.loadOrderItems(this.selectedCustomer.id);
                this.loadProducts(); // 刷新庫存
            } else {
                this.addMessage('添加商品失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('添加商品失敗: ' + error.message, 'error');
        }
    }

    async loadOrderItems(customerId) {
        try {
            // 構建查詢參數
            const params = new URLSearchParams();
            if (this.selectedStoreId) {
                params.append('store_id', this.selectedStoreId);
            }

            const url = `/api/cashier/customer/${customerId}${params.toString() ? '?' + params.toString() : ''}`;
            console.log('[DEBUG] loadOrderItems fetching URL:', url);
            const response = await fetch(url);
            const result = await response.json();
            console.log('[DEBUG] loadOrderItems result:', result);

            if (result.success) {
                this.currentOrderItems = result.customer.order_items || [];
                console.log('[DEBUG] loadOrderItems currentOrderItems:', this.currentOrderItems);
                this.displayOrderItems();
                this.updateOrderSummary();
                this.updateAvailableSnacksDisplay();
            } else {
                console.log('[DEBUG] loadOrderItems API error:', result.error);
                this.currentOrderItems = [];
                this.displayOrderItems();
                this.updateOrderSummary();
                this.updateAvailableSnacksDisplay();
            }
        } catch (error) {
            console.error('[DEBUG] loadOrderItems error:', error);
            this.currentOrderItems = [];
            this.displayOrderItems();
            this.updateOrderSummary();
        } finally {
            this.updateOrderButtons();
        }
    }

    displayOrderItems() {
        const orderItems = document.getElementById('order-items');

        if (this.currentOrderItems.length === 0) {
            orderItems.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-receipt"></i>
                    <p>暫無訂單項目</p>
                </div>
            `;
            return;
        }

        orderItems.innerHTML = '';

        this.currentOrderItems.forEach(item => {
            const itemEl = document.createElement('div');
            itemEl.className = 'order-item';

            // 判斷是否為貓零食分類，顯示加入時間
            let nameHtml = `<span class="order-item-name">${item.product_name || '商品'}</span>`;
            if (item.category === '貓零食' && item.purchased_at) {
                const timeStr = new Date(item.purchased_at + 'Z').toLocaleTimeString('zh-HK', {
                    hour: '2-digit', minute: '2-digit', hour12: false,
                    timeZone: 'Asia/Hong_Kong'
                });
                nameHtml += `<span class="order-item-add-time">${timeStr}</span>`;
            }

            itemEl.innerHTML = `
                ${nameHtml}
                <span class="order-item-unit-price">$${item.price_at_time}</span>
                <span class="order-item-qty">x${item.quantity}</span>
                <span class="order-item-price">$${item.price_at_time * item.quantity}</span>
                <button class="order-item-remove" data-order-item-id="${item.id}">
                    <i class="fas fa-times"></i>
                </button>
            `;

            // 添加刪除事件
            const removeBtn = itemEl.querySelector('.order-item-remove');
            removeBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.removeOrderItem(item.id);
            });

            orderItems.appendChild(itemEl);
        });
    }

    async removeOrderItem(orderItemId) {
        if (!confirm('確定要移除這個項目嗎？')) {
            return;
        }

        try {
            // 構建查詢參數
            const params = new URLSearchParams();
            if (this.selectedStoreId) {
                params.append('store_id', this.selectedStoreId);
            }

            const url = `/api/cashier/order-item/${orderItemId}${params.toString() ? '?' + params.toString() : ''}`;
            const response = await fetch(url, {
                method: 'DELETE'
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage('已移除訂單項目', 'success');
                if (this.selectedCustomer) {
                    this.loadCustomerDetail(this.selectedCustomer.id);
                    this.loadOrderItems(this.selectedCustomer.id);
                    this.loadProducts(); // 刷新庫存
                    this.loadCustomers(); // 刷新在場客人列表
                }
            } else {
                this.addMessage('移除項目失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('移除項目失敗: ' + error.message, 'error');
        }
    }

    updateOrderSummary() {
        const itemCount = this.currentOrderItems.reduce((sum, item) => sum + item.quantity, 0);
        const orderTotal = this.currentOrderItems.reduce((sum, item) => sum + (item.price_at_time * item.quantity), 0);

        document.getElementById('item-count').textContent = itemCount;
        document.getElementById('order-total').textContent = `$${orderTotal.toFixed(2)}`;
    }

    updateOrderButtons() {
        const hasCustomer = !!this.selectedCustomer;
        const hasItems = this.currentOrderItems.length > 0;

        document.getElementById('checkout-btn').disabled = !hasCustomer || !hasItems;
        document.getElementById('change-table-btn').disabled = !hasCustomer;
        document.getElementById('delete-table-btn').disabled = !hasCustomer;

        // 更新模態框按鈕
        const modalCheckoutBtn = document.getElementById('modal-checkout-btn');
        const modalChangeTableBtn = document.getElementById('modal-change-table-btn');
        const modalDeleteTableBtn = document.getElementById('modal-delete-table-btn');

        if (modalCheckoutBtn) modalCheckoutBtn.disabled = !hasCustomer || !hasItems;
        if (modalChangeTableBtn) modalChangeTableBtn.disabled = !hasCustomer;
        if (modalDeleteTableBtn) modalDeleteTableBtn.disabled = !hasCustomer;
    }


    clearOrder() {
        if (!this.selectedCustomer || this.currentOrderItems.length === 0) {
            return;
        }

        if (!confirm('確定要清空當前訂單嗎？這將移除所有已添加的商品。')) {
            return;
        }

        // 構建查詢參數
        const params = new URLSearchParams();
        if (this.selectedStoreId) {
            params.append('store_id', this.selectedStoreId);
        }
        const queryString = params.toString() ? '?' + params.toString() : '';

        // 逐一刪除所有訂單項目
        const deletePromises = this.currentOrderItems.map(item =>
            fetch(`/api/cashier/order-item/${item.id}${queryString}`, { method: 'DELETE' })
        );

        Promise.all(deletePromises)
            .then(() => {
                this.addMessage('訂單已清空', 'success');
                this.loadCustomerDetail(this.selectedCustomer.id);
                this.loadOrderItems(this.selectedCustomer.id);
                this.loadProducts();
                this.loadCustomers();
            })
            .catch(error => {
                this.addMessage('清空訂單失敗: ' + error.message, 'error');
            });
    }

    showCheckoutModal() {
        if (!this.selectedCustomer) {
            return;
        }

        // 更新模態框內容
        document.getElementById('checkout-table').textContent = this.selectedCustomer.table_number;
        document.getElementById('checkout-people').textContent = `${this.selectedCustomer.people_count}位`;

        const entryTime = this.parseEntryTime(this.selectedCustomer.entry_time).toLocaleString('zh-TW', {
            hour: '2-digit',
            minute: '2-digit'
        });
        document.getElementById('checkout-entry-time').textContent = entryTime;

        const totalAmount = this.currentOrderItems.reduce((sum, item) => sum + (item.price_at_time * item.quantity), 0);
        document.getElementById('checkout-amount').textContent = `$${totalAmount.toFixed(2)}`;

        // 顯示模態框
        document.getElementById('checkout-modal').classList.remove('hidden');
    }

    hideCheckoutModal() {
        document.getElementById('checkout-modal').classList.add('hidden');
    }

    async confirmCheckout() {
        if (!this.selectedCustomer) {
            return;
        }

        const paymentMethod = "cash";

        try {
            const response = await fetch('/api/cashier/checkout', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    customer_id: this.selectedCustomer.id,
                    payment_method: paymentMethod
                })
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage(`結賬成功: 桌號 ${result.table_number}, 金額: $${result.total_amount}`, 'success');
                this.hideCheckoutModal();
                this.clearSelectedCustomer();
                this.loadCustomers();
                this.loadTodayStats();
            } else {
                this.addMessage('結賬失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('結賬失敗: ' + error.message, 'error');
        }
    }

    showDeleteTableModal() {
        if (!this.selectedCustomer) {
            return;
        }

        // 更新模態框內容
        document.getElementById('delete-table-number').textContent = this.selectedCustomer.table_number;
        document.getElementById('delete-table-people').textContent = `${this.selectedCustomer.people_count}位`;

        const entryTime = this.parseEntryTime(this.selectedCustomer.entry_time).toLocaleString('zh-TW', {
            hour: '2-digit',
            minute: '2-digit'
        });
        document.getElementById('delete-table-entry-time').textContent = entryTime;

        // 顯示模態框
        document.getElementById('delete-table-modal').classList.remove('hidden');
    }

    hideDeleteTableModal() {
        document.getElementById('delete-table-modal').classList.add('hidden');
    }

    async confirmDeleteTable() {
        if (!this.selectedCustomer) {
            return;
        }

        try {
            // 構建查詢參數
            const params = new URLSearchParams();
            if (this.selectedStoreId) {
                params.append('store_id', this.selectedStoreId);
            }

            const url = `/api/cashier/customer/${this.selectedCustomer.id}${params.toString() ? '?' + params.toString() : ''}`;
            const response = await fetch(url, {
                method: 'DELETE'
            });
            const result = await response.json();

            if (result.success) {
                this.addMessage(`已刪除桌號 ${this.selectedCustomer.table_number}`, 'success');
                this.hideDeleteTableModal();
                this.clearSelectedCustomer();
                this.loadCustomers();
                this.loadTodayStats();
            } else {
                this.addMessage('刪除桌號失敗: ' + result.error, 'error');
                this.hideDeleteTableModal(); // 即使失敗也隱藏模態框
            }
        } catch (error) {
            this.addMessage('刪除桌號失敗: ' + error.message, 'error');
            this.hideDeleteTableModal(); // 即使出錯也隱藏模態框
        }
    }

    async loadTodayStats() {
        try {
            // 構建查詢參數
            const params = new URLSearchParams();
            if (this.selectedStoreId) {
                params.append('store_id', this.selectedStoreId);
            }

            const url = `/api/cashier/stats/today${params.toString() ? '?' + params.toString() : ''}`;
            const response = await fetch(url);
            const result = await response.json();

            if (result.success) {
                const stats = result.stats;
                document.getElementById('today-revenue').textContent = `$${stats.total_revenue || 0}`;
                // 今日客數改為總人數
                document.getElementById('today-customers').textContent = stats.total_people || 0;
                // 隱藏平均結賬和離場數格子（隱藏整個.stat-item）
                const avgCheckoutEl = document.getElementById('avg-checkout');
                const checkoutsTodayEl = document.getElementById('checkouts-today');
                if (avgCheckoutEl && avgCheckoutEl.parentElement) {
                    avgCheckoutEl.parentElement.style.display = 'none';
                }
                if (checkoutsTodayEl && checkoutsTodayEl.parentElement) {
                    checkoutsTodayEl.parentElement.style.display = 'none';
                }
            }
        } catch (error) {
            console.error('載入今日統計失敗:', error);
        }
    }

    addMessage(text, type = 'info') {
        const messageLog = document.getElementById('message-log');
        const now = new Date();
        const timeString = now.toLocaleTimeString('zh-TW', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });

        const messageEl = document.createElement('div');
        messageEl.className = `message ${type}`;
        messageEl.innerHTML = `
            <i class="fas fa-${this.getMessageIcon(type)}"></i>
            <span>${text}</span>
            <span class="time">${timeString}</span>
        `;

        messageLog.appendChild(messageEl);
        messageLog.scrollTop = messageLog.scrollHeight;

        // 限制訊息數量
        const messages = messageLog.querySelectorAll('.message');
        if (messages.length > 50) {
            messages[0].remove();
        }
    }

    getMessageIcon(type) {
        switch(type) {
            case 'success': return 'check-circle';
            case 'warning': return 'exclamation-triangle';
            case 'error': return 'times-circle';
            default: return 'info-circle';
        }
    }

    clearMessages() {
        document.getElementById('message-log').innerHTML = '';
        this.addMessage('訊息記錄已清空', 'info');
    }

    // 系統控制功能（簡化實現）
    manualEntry() {
        this.addMessage('手動新增客人功能開發中', 'info');
    }

    viewReports() {
        this.addMessage('查看報表功能開發中', 'info');
    }

    manageProducts() {
        this.addMessage('管理商品功能開發中', 'info');
    }

    systemSettings() {
        this.addMessage('系統設定功能開發中', 'info');
    }

    staffLogin() {
        const staffName = prompt('請輸入員工姓名:');
        if (staffName) {
            this.staffName = staffName;
            document.getElementById('staff-name').textContent = staffName;
            this.addMessage(`員工 ${staffName} 已登入`, 'success');
        }
    }

    logout() {
        this.staffName = '未登入';
        document.getElementById('staff-name').textContent = '未登入';
        this.addMessage('員工已登出', 'info');
    }

    // 入場紀錄相關方法
    async loadEntryRecords() {
        try {
            // 構建查詢參數
            const params = new URLSearchParams();
            if (this.selectedStoreId) {
                params.append('store_id', this.selectedStoreId);
            }

            const url = `/api/cashier/entry-records${params.toString() ? '?' + params.toString() : ''}`;
            const response = await fetch(url);
            const result = await response.json();

            if (result.success) {
                this.displayEntryRecords(result.entries);
                this.updateTodayRecordsStats(result.today_count || 0);
            }
        } catch (error) {
            this.addMessage('載入入場紀錄失敗: ' + error.message, 'error');
        }
    }

    displayEntryRecords(entries) {
        const entriesList = document.getElementById('cashier-entries-list');

        if (!entries || entries.length === 0) {
            entriesList.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-clock"></i>
                    <p>暫無入場記錄</p>
                </div>
            `;
            return;
        }

        entriesList.innerHTML = '';

        entries.forEach(entry => {
            const entryEl = document.createElement('div');
            entryEl.className = 'entry-item';

            const entryTime = this.parseEntryTime(entry.entry_time).toLocaleTimeString('zh-TW', {
                hour: '2-digit',
                minute: '2-digit'
            });

            entryEl.innerHTML = `
                <span>${entryTime}</span>
                <span>${entry.table_number}</span>
                <span>${entry.people_count}位</span>
                <span class="status-${entry.status}">${entry.status === 'active' ? '在場' : '已離場'}</span>
            `;

            entriesList.appendChild(entryEl);
        });
    }

    // 設備控制相關方法
    async loadDeviceStatus() {
        try {
            const response = await fetch('/api/cashier/device-status');
            const result = await response.json();

            if (result.success) {
                this.updateDeviceStatus(result.devices);
            }
        } catch (error) {
            this.addMessage('載入設備狀態失敗: ' + error.message, 'error');
        }
    }

    updateDeviceStatus(devices) {
        if (devices.printer) {
            document.getElementById('printer-status').textContent = devices.printer.status === 'online' ? '就緒' : '離線';
            document.getElementById('printer-status').className = `status-value ${devices.printer.status}`;
        }
        if (devices.locker) {
            document.getElementById('locker-status').textContent = devices.locker.status === 'online' ? '就緒' : '離線';
            document.getElementById('locker-status').className = `status-value ${devices.locker.status}`;
        }
        if (devices.doorlock) {
            document.getElementById('doorlock-status').textContent = devices.doorlock.status === 'online' ? '就緒' : '離線';
            document.getElementById('doorlock-status').className = `status-value ${devices.doorlock.status}`;
        }
        if (devices.audio) {
            document.getElementById('audio-status').textContent = devices.audio.status === 'online' ? '就緒' : '離線';
            document.getElementById('audio-status').className = `status-value ${devices.audio.status}`;
        }
        if (devices.nfc) {
            document.getElementById('nfc-status').textContent = devices.nfc.status === 'online' ? '就緒' : '離線';
            document.getElementById('nfc-status').className = `status-value ${devices.nfc.status}`;
        }
        if (devices.receipt_printer) {
            const statusElement = document.getElementById('receipt-printer-status');
            if (statusElement) {
                if (devices.receipt_printer.status === 'connected') {
                    statusElement.textContent = '已連接';
                    statusElement.className = 'status-value online';
                    this.enableReceiptPrinterControls(true);
                } else {
                    statusElement.textContent = '未連接';
                    statusElement.className = 'status-value offline';
                    this.enableReceiptPrinterControls(false);
                }
            }
        }
    }

    // 設備控制操作
    async testPrinter() {
        try {
            const response = await fetch('/api/cashier/test-printer', { method: 'POST' });
            const result = await response.json();
            if (result.success) {
                this.addMessage('打印機測試成功', 'success');
            } else {
                this.addMessage('打印機測試失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('打印機測試失敗: ' + error.message, 'error');
        }
    }

    async resetPrinter() {
        try {
            const response = await fetch('/api/cashier/reset-printer', { method: 'POST' });
            const result = await response.json();
            if (result.success) {
                this.addMessage('打印機已重設', 'success');
            } else {
                this.addMessage('打印機重設失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('打印機重設失敗: ' + error.message, 'error');
        }
    }

    async testLocker() {
        try {
            const response = await fetch('/api/cashier/test-locker', { method: 'POST' });
            const result = await response.json();
            if (result.success) {
                this.addMessage('儲物柜測試成功', 'success');
            } else {
                this.addMessage('儲物柜測試失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('儲物柜測試失敗: ' + error.message, 'error');
        }
    }

    async resetLocker() {
        try {
            const response = await fetch('/api/cashier/reset-locker', { method: 'POST' });
            const result = await response.json();
            if (result.success) {
                this.addMessage('儲物柜已重設', 'success');
            } else {
                this.addMessage('儲物柜重設失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('儲物柜重設失敗: ' + error.message, 'error');
        }
    }

    async openDoorLock() {
        try {
            const response = await fetch('/api/cashier/open-doorlock', { method: 'POST' });
            const result = await response.json();
            if (result.success) {
                this.addMessage('門鎖已開啟', 'success');
            } else {
                this.addMessage('門鎖開啟失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('門鎖開啟失敗: ' + error.message, 'error');
        }
    }

    async closeDoorLock() {
        try {
            const response = await fetch('/api/cashier/close-doorlock', { method: 'POST' });
            const result = await response.json();
            if (result.success) {
                this.addMessage('門鎖已關閉', 'success');
            } else {
                this.addMessage('門鎖關閉失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('門鎖關閉失敗: ' + error.message, 'error');
        }
    }

    async testAudio() {
        try {
            const response = await fetch('/api/cashier/test-audio', { method: 'POST' });
            const result = await response.json();
            if (result.success) {
                this.addMessage('音響測試成功', 'success');
            } else {
                this.addMessage('音響測試失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('音響測試失敗: ' + error.message, 'error');
        }
    }

    async stopAudio() {
        try {
            const response = await fetch('/api/cashier/stop-audio', { method: 'POST' });
            const result = await response.json();
            if (result.success) {
                this.addMessage('音響已停止', 'success');
            } else {
                this.addMessage('音響停止失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('音響停止失敗: ' + error.message, 'error');
        }
    }

    async testNFC() {
        try {
            const response = await fetch('/api/cashier/test-nfc', { method: 'POST' });
            const result = await response.json();
            if (result.success) {
                this.addMessage('NFC讀卡器測試成功', 'success');
            } else {
                this.addMessage('NFC讀卡器測試失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('NFC讀卡器測試失敗: ' + error.message, 'error');
        }
    }

    async resetNFC() {
        try {
            const response = await fetch('/api/cashier/reset-nfc', { method: 'POST' });
            const result = await response.json();
            if (result.success) {
                this.addMessage('NFC讀卡器已重設', 'success');
            } else {
                this.addMessage('NFC讀卡器重設失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('NFC讀卡器重設失敗: ' + error.message, 'error');
        }
    }

    // 小票機連接相關方法
    handleConnectionTypeChange(connectionType) {
        console.log('handleConnectionTypeChange called:', connectionType);
        const wifiSettings = document.querySelector('.wifi-settings');
        let bluetoothSettings = document.getElementById('receipt-printer-bluetooth-section');
        if (!bluetoothSettings) {
            console.warn('Bluetooth settings not found by ID, trying by class...');
            bluetoothSettings = document.querySelector('.bluetooth-settings');
        }
        console.log('wifiSettings:', wifiSettings, 'bluetoothSettings:', bluetoothSettings);

        if (!wifiSettings) console.error('wifiSettings element not found!');
        if (!bluetoothSettings) console.error('bluetoothSettings element not found!');

        if (connectionType === 'wifi') {
            console.log('Switching to WiFi mode');
            if (wifiSettings) {
                wifiSettings.classList.remove('hidden');
                console.log('WiFi settings visible, has hidden class?', wifiSettings.classList.contains('hidden'));
            }
            if (bluetoothSettings) {
                bluetoothSettings.classList.add('hidden');
                console.log('Bluetooth settings hidden');
            }
        } else {
            console.log('Switching to Bluetooth mode');
            if (wifiSettings) {
                wifiSettings.classList.add('hidden');
                console.log('WiFi settings hidden');
            }
            if (bluetoothSettings) {
                console.log('Bluetooth settings before removing hidden:', bluetoothSettings.classList.contains('hidden'));
                bluetoothSettings.classList.remove('hidden');
                console.log('Bluetooth settings after removing hidden:', bluetoothSettings.classList.contains('hidden'));
                console.log('Bluetooth settings display style:', window.getComputedStyle(bluetoothSettings).display);
            } else {
                console.error('Cannot show bluetooth settings: element not found');
            }
            // 根據當前藍牙模式決定是否掃描
            const bluetoothModeRadio = document.querySelector('input[name="bluetooth-mode"]:checked');
            if (bluetoothModeRadio && bluetoothModeRadio.value === 'scan') {
                console.log('Bluetooth mode is scan, auto-scanning devices');
                this.scanBluetoothDevices();
            } else {
                console.log('Bluetooth mode is manual or no mode selected, skipping auto-scan');
            }

            // 當切換到藍牙模式時，啟用連接按鈕（即使小票機已連接，也允許使用藍牙重新連接）
            const connectBtn = document.getElementById('connect-receipt-printer-btn');
            if (connectBtn && connectBtn.disabled) {
                console.log('連接按鈕在藍牙模式下被禁用，強制啟用以允許重新連接');
                connectBtn.disabled = false;
            }
        }

        // 通用修復：無論切換到哪種模式，如果小票機狀態不是"已連接"，都啟用連接按鈕
        const statusElement = document.getElementById('receipt-printer-status');
        if (statusElement && statusElement.textContent !== '已連接') {
            const connectBtn = document.getElementById('connect-receipt-printer-btn');
            if (connectBtn && connectBtn.disabled) {
                console.log(`小票機狀態為"${statusElement.textContent}"，啟用連接按鈕`);
                connectBtn.disabled = false;
            }
        }
    }

    // 處理藍牙模式切換
    handleBluetoothModeChange(mode) {
        console.log('handleBluetoothModeChange called:', mode);
        const scanMode = document.querySelector('.bluetooth-scan-mode');
        const manualMode = document.querySelector('.bluetooth-manual-mode');

        console.log('scanMode:', scanMode, 'manualMode:', manualMode);

        if (mode === 'scan') {
            console.log('Switching to scan mode');
            if (scanMode) {
                scanMode.classList.remove('hidden');
                console.log('Scan mode visible');
            }
            if (manualMode) {
                manualMode.classList.add('hidden');
                console.log('Manual mode hidden');
            }
            // 自動觸發掃描
            this.scanBluetoothDevices();
        } else {
            console.log('Switching to manual mode');
            if (scanMode) {
                scanMode.classList.add('hidden');
                console.log('Scan mode hidden');
            }
            if (manualMode) {
                manualMode.classList.remove('hidden');
                console.log('Manual mode visible');
            }
        }
    }

    async scanBluetoothDevices() {
        console.log('scanBluetoothDevices called');

        // 檢查當前是否在掃描模式
        const bluetoothModeRadio = document.querySelector('input[name="bluetooth-mode"]:checked');
        if (bluetoothModeRadio && bluetoothModeRadio.value !== 'scan') {
            console.log('Not in scan mode, skipping scan');
            return;
        }

        try {
            this.addMessage('正在掃描藍牙設備...', 'info');
            console.log('Sending request to /api/cashier/scan-bluetooth');
            const response = await fetch('/api/cashier/scan-bluetooth', { method: 'POST' });
            console.log('Response status:', response.status, response.statusText);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const result = await response.json();
            console.log('Scan bluetooth response:', result);

            if (result.success) {
                // 確保藍牙設置部分可見
                let btSettings = document.getElementById('receipt-printer-bluetooth-section');
                if (!btSettings) {
                    console.warn('Bluetooth settings not found by ID, trying by class...');
                    btSettings = document.querySelector('.bluetooth-settings');
                }

                console.log('Bluetooth settings element:', btSettings);
                if (!btSettings) {
                    console.error('ERROR: Bluetooth settings element not found by ID or class!');
                } else {
                    console.log('Bluetooth settings classes:', btSettings.className);
                    console.log('Bluetooth settings has hidden class?', btSettings.classList.contains('hidden'));
                    console.log('Bluetooth settings parent visibility:', btSettings.parentElement ? btSettings.parentElement.className : 'no parent');

                    if (btSettings.classList.contains('hidden')) {
                        console.log('Bluetooth settings was hidden, removing hidden class');
                        btSettings.classList.remove('hidden');
                        console.log('After removal, has hidden class?', btSettings.classList.contains('hidden'));
                    } else {
                        console.log('Bluetooth settings already visible');
                    }
                    console.log('Computed display style:', window.getComputedStyle(btSettings).display);
                }

                const select = document.getElementById('receipt-printer-bluetooth-devices');
                console.log('Bluetooth select element found?', !!select);
                if (select) {
                    console.log('Current select options count:', select.options.length);
                    select.innerHTML = '<option value="">選擇藍牙設備...</option>';
                    console.log('Cleared select, new options count:', select.options.length);

                    if (result.devices && result.devices.length > 0) {
                        console.log(`Found ${result.devices.length} bluetooth devices`);
                        result.devices.forEach(device => {
                            const option = document.createElement('option');
                            option.value = device.address;
                            option.textContent = `${device.name} (${device.address})`;
                            select.appendChild(option);
                        });
                        console.log('After adding devices, options count:', select.options.length);
                        this.addMessage(`找到 ${result.devices.length} 個藍牙設備`, 'success');

                        // 如果有設備，自動選擇第一個
                        if (select.options.length > 1) {
                            select.selectedIndex = 1;
                            console.log('Auto-selected first device:', select.options[1].text);
                        }
                    } else {
                        console.log('No bluetooth devices found');
                        this.addMessage('未找到藍牙設備', 'warning');
                    }
                } else {
                    console.error('Element receipt-printer-bluetooth-devices not found!');
                    this.addMessage('藍牙設備選擇器未找到，請刷新頁面', 'error');
                }
            } else {
                console.error('Bluetooth scan failed:', result.error);
                this.addMessage('掃描藍牙設備失敗: ' + result.error, 'error');
            }
        } catch (error) {
            console.error('Bluetooth scan error:', error);
            this.addMessage('掃描藍牙設備失敗: ' + error.message, 'error');
        }
    }


    async disconnectReceiptPrinter() {
        try {
            this.addMessage('正在斷開小票機連接...', 'info');
            const response = await fetch('/api/cashier/disconnect-receipt-printer', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ connectionType: this.receiptPrinterConnectionType })
            });
            const result = await response.json();

            if (result.success) {
                this.updateReceiptPrinterStatus('未連接');
                this.addMessage('小票機已斷開連接', 'success');
                this.enableReceiptPrinterControls(false);
                this.receiptPrinterConnectionType = null; // 清除連接類型
            } else {
                this.addMessage('斷開小票機連接失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('斷開小票機連接失敗: ' + error.message, 'error');
        }
    }


    updateReceiptPrinterStatus(status) {
        const statusElement = document.getElementById('receipt-printer-status');
        if (statusElement) {
            statusElement.textContent = status;
            statusElement.className = `status-value ${status === '已連接' ? 'online' : 'offline'}`;
        }
    }

    enableReceiptPrinterControls(isConnected) {
        const connectBtn = document.getElementById('connect-receipt-printer-btn');
        const disconnectBtn = document.getElementById('disconnect-receipt-printer-btn');
        const testBtn = document.getElementById('test-receipt-printer-btn');

        console.log('enableReceiptPrinterControls called:', {
            isConnected,
            connectBtnExists: !!connectBtn,
            disconnectBtnExists: !!disconnectBtn,
            testBtnExists: !!testBtn,
            currentConnectBtnDisabled: connectBtn ? connectBtn.disabled : 'N/A'
        });

        if (connectBtn) {
            // 連接按鈕永遠啟用，允許用戶更改IP重新連接
            connectBtn.disabled = false;
            console.log('設置連接按鈕 disabled = false (永遠啟用)');
        }
        if (disconnectBtn) disconnectBtn.disabled = !isConnected;
        if (testBtn) testBtn.disabled = !isConnected;
    }

    // QR Code相關方法
    async loadCustomerQRCode(customerId) {
        try {
            // 構建查詢參數
            const params = new URLSearchParams();
            if (this.selectedStoreId) {
                params.append('store_id', this.selectedStoreId);
            }

            const url = `/api/cashier/customer/${customerId}/qr-code${params.toString() ? '?' + params.toString() : ''}`;
            const response = await fetch(url);
            const result = await response.json();

            if (result.success) {
                this.displayCustomerQRCode(result.qr_data);
                document.getElementById('customer-qr-table').textContent = result.table_number || '--';
                document.getElementById('customer-qr-entry-time').textContent = result.entry_time || '--';
                document.getElementById('customer-qr-lockers').textContent = result.lockers || '--';
                document.getElementById('customer-qr-text').textContent = result.qr_code || '--';

                // 顯示QR Code區
                document.getElementById('customer-qr-section').classList.remove('hidden');
                document.getElementById('reprint-qr-btn').disabled = false;
            }
        } catch (error) {
            this.addMessage('載入QR Code失敗: ' + error.message, 'error');
        }
    }

    displayCustomerQRCode(qrData) {
        const canvas = document.getElementById('customer-qr-canvas');
        const placeholder = document.getElementById('customer-qr-placeholder');

        if (!canvas || !placeholder) return;

        if (qrData.startsWith('data:image')) {
            // 如果是base64圖片
            const img = new Image();
            img.onload = () => {
                console.log('QR Code圖片加載成功');
                const ctx = canvas.getContext('2d');
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

                // 隱藏placeholder，顯示canvas
                placeholder.classList.add('hidden');
                placeholder.style.display = 'none';
                canvas.classList.remove('hidden');
                canvas.style.display = '';

                console.log('Placeholder hidden:', placeholder.classList.contains('hidden'));
                console.log('Canvas hidden:', canvas.classList.contains('hidden'));
            };
            img.onerror = (error) => {
                console.error('QR Code圖片加載失敗:', error);
                console.error('圖片數據前100字符:', qrData.substring(0, 100));
                // 回退到文本顯示
                const ctx = canvas.getContext('2d');
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                displayTextFallback(qrData, canvas, ctx);
                placeholder.classList.add('hidden');
                canvas.classList.remove('hidden');
            };
            img.src = qrData;
        } else {
            // 如果是文本，使用QRCode庫生成QR Code
            placeholder.classList.add('hidden');
            canvas.classList.remove('hidden');

            // 清除畫布
            const ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            // 檢查QRCode庫是否可用
            if (typeof QRCode !== 'undefined') {
                try {
                    // 使用QRCode庫生成QR Code到canvas
                    QRCode.toCanvas(canvas, qrData, {
                        width: canvas.width,
                        height: canvas.height,
                        margin: 1,
                        colorDark: '#000000',
                        colorLight: '#ffffff',
                        correctLevel: QRCode.CorrectLevel.H
                    }, function(error) {
                        if (error) {
                            console.error('QR Code生成錯誤:', error);
                            // 生成失敗時顯示文本
                            displayTextFallback(qrData, canvas, ctx);
                        }
                    });
                } catch (error) {
                    console.error('QR Code生成異常:', error);
                    displayTextFallback(qrData, canvas, ctx);
                }
            } else {
                // QRCode庫不可用，顯示文本
                displayTextFallback(qrData, canvas, ctx);
            }
        }

        // 文本回退顯示函數
        function displayTextFallback(qrData, canvas, ctx) {
            ctx.fillStyle = '#000';
            ctx.font = '14px Arial';
            ctx.textAlign = 'center';
            ctx.fillText(qrData.substring(0, 20) || '無QR Code資料', canvas.width / 2, canvas.height / 2);
            ctx.fillText(qrData.substring(20, 40) || '', canvas.width / 2, canvas.height / 2 + 20);
        }
    }

    async reprintQRCode() {
        if (!this.selectedCustomer) {
            this.addMessage('請先選擇客人', 'warning');
            return;
        }

        try {
            // 構建查詢參數
            const params = new URLSearchParams();
            if (this.selectedStoreId) {
                params.append('store_id', this.selectedStoreId);
            }

            const url = `/api/cashier/customer/${this.selectedCustomer.id}/reprint-qr${params.toString() ? '?' + params.toString() : ''}`;
            const response = await fetch(url, {
                method: 'POST'
            });
            const result = await response.json();

            if (result.success) {
                this.addMessage('QR Code小票已重新打印', 'success');
            } else {
                this.addMessage('重新打印失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('重新打印失敗: ' + error.message, 'error');
        }
    }


    clearSelectedCustomer() {
        this.selectedCustomer = null;
        this.currentOrderItems = [];
        this.stopSnackRefreshTimer();
        this._snackCustomerData = null;
        this.displayCustomers();

        // 隱藏客人詳情區，顯示空狀態
        const emptyState = document.getElementById('customer-empty-state');
        const customerInfo = document.getElementById('customer-info');
        if (emptyState) emptyState.classList.remove('hidden');
        if (customerInfo) customerInfo.classList.add('hidden');

        // 隱藏QR Code區
        document.getElementById('customer-qr-section').classList.add('hidden');
        document.getElementById('reprint-qr-btn').disabled = true;

        // 清空訂單項目顯示
        document.getElementById('order-items').innerHTML = `
            <div class="empty-state">
                <i class="fas fa-receipt"></i>
                <p>請先選擇客人</p>
            </div>
        `;

        this.updateOrderSummary();
        this.updateOrderButtons();
    }

    // ============ 分店管理功能 ============

    /**
     * 加載分店列表
     */
    async loadStores() {
        try {
            console.log('loadStores: 開始加載分店列表...');
            const response = await fetch('/api/stores');
            console.log('loadStores: API響應狀態:', response.status, response.statusText);
            const result = await response.json();
            console.log('loadStores: API響應數據:', result);

            if (result.success) {
                console.log('loadStores: 成功，分店數量:', result.data?.length || 0);
                this.displayStores(result.data);
            } else {
                console.error('加載分店失敗:', result.error);
                this.addMessage('加載分店失敗: ' + result.error, 'error');
            }
        } catch (error) {
            console.error('加載分店時發生錯誤:', error);
            this.addMessage('加載分店時發生錯誤: ' + error.message, 'error');
        }
    }

    /**
     * 顯示分店列表
     */
    displayStores(stores) {
        console.log('displayStores: 開始顯示分店，數量:', stores?.length || 0);
        console.log('displayStores: 分店數據:', stores);
        const tableBody = document.getElementById('store-table-body');
        if (!tableBody) {
            console.error('displayStores: 找不到表格元素 #store-table-body');
            return;
        }

        if (!stores || stores.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="8" class="empty-table-message">沒有分店數據</td>
                </tr>
            `;
            return;
        }

        let html = '';
        stores.forEach(store => {
            // 根據狀態設置標籤
            let statusBadge = '';
            if (store.status === 'active') {
                statusBadge = '<span class="status-badge status-active">營運中</span>';
            } else if (store.status === 'maintenance') {
                statusBadge = '<span class="status-badge status-maintenance">維護中</span>';
            } else {
                statusBadge = '<span class="status-badge status-closed">已關閉</span>';
            }

            // 格式化創建時間
            const createdAt = store.created_at ? new Date(store.created_at).toLocaleString('zh-TW') : '-';

            html += `
                <tr data-store-id="${store.id}">
                    <td>${store.id}</td>
                    <td>${store.store_name || store.name || '-'}</td>
                    <td>${store.store_code || store.code || '-'}</td>
                    <td>${store.address || '-'}</td>
                    <td>${store.phone || '-'}</td>
                    <td>${statusBadge}</td>
                    <td>${createdAt}</td>
                    <td class="store-actions">
                        <button class="btn-small edit-store-btn" data-store-id="${store.id}" title="編輯">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn-small delete-store-btn" data-store-id="${store.id}" title="刪除">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        });

        tableBody.innerHTML = html;

        // 綁定編輯和刪除按鈕事件
        this.bindStoreActionButtons();
    }

    /**
     * 綁定分店操作按鈕事件
     */
    bindStoreActionButtons() {
        // 編輯按鈕
        document.querySelectorAll('.edit-store-btn').forEach(button => {
            button.addEventListener('click', async (e) => {
                e.stopPropagation();
                const storeId = button.getAttribute('data-store-id');
                await this.loadStoreForEdit(storeId);
            });
        });

        // 刪除按鈕
        document.querySelectorAll('.delete-store-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                e.stopPropagation();
                const storeId = button.getAttribute('data-store-id');
                this.confirmDeleteStore(storeId);
            });
        });
    }

    /**
     * 加載分店資料用於編輯
     */
    async loadStoreForEdit(storeId) {
        try {
            console.log('loadStoreForEdit: 加載分店資料，storeId:', storeId);
            // 構建headers，包含可選的身份驗證令牌
            const headers = {};

            // 如果存在currentToken，添加Authorization header
            if (this.currentToken) {
                headers['Authorization'] = `Bearer ${this.currentToken}`;
            }

            const response = await fetch(`/api/stores/${storeId}`, {
                headers: headers
            });
            console.log('loadStoreForEdit: API響應狀態:', response.status, response.statusText);
            const result = await response.json();
            console.log('loadStoreForEdit: API響應數據:', result);

            if (result.success) {
                console.log('loadStoreForEdit: 成功，分店資料:', result.data);
                this.populateStoreForm(result.data);
            } else {
                console.error('加載分店資料失敗:', result.error);
                this.addMessage('加載分店資料失敗: ' + result.error, 'error');
            }
        } catch (error) {
            console.error('加載分店資料時發生錯誤:', error);
            this.addMessage('加載分店資料時發生錯誤: ' + error.message, 'error');
        }
    }

    /**
     * 填充分店表單
     */
    populateStoreForm(store) {
        const form = document.getElementById('store-form');
        if (!form) return;

        // 填充表單字段（映射API字段名到表單字段名）
        document.getElementById('store-id').value = store.id || '';
        document.getElementById('store-name').value = store.store_name || store.name || '';
        document.getElementById('store-code').value = store.store_code || store.code || '';
        document.getElementById('store-address').value = store.address || '';
        document.getElementById('store-phone').value = store.phone || '';
        document.getElementById('store-email').value = store.email || '';
        document.getElementById('store-opening-hours').value = store.opening_hours || '';
        document.getElementById('store-status').value = store.status || 'active';
        document.getElementById('store-description').value = store.description || '';

        // 處理JSON設定
        let settings = store.settings || '{"timezone": "Asia/Hong_Kong", "currency": "HKD"}';
        if (typeof settings === 'string') {
            document.getElementById('store-settings').value = settings;
        } else {
            document.getElementById('store-settings').value = JSON.stringify(settings, null, 2);
        }

        // 更新表單標題
        document.querySelector('.store-form-section h3').innerHTML = '<i class="fas fa-edit"></i> 編輯分店資料';

        // 滾動到表單區域
        document.querySelector('.store-form-section').scrollIntoView({ behavior: 'smooth' });
    }

    /**
     * 清空分店表單
     */
    clearStoreForm() {
        const form = document.getElementById('store-form');
        if (!form) return;

        form.reset();
        document.getElementById('store-id').value = '';
        document.getElementById('store-settings').value = '{"timezone": "Asia/Hong_Kong", "currency": "HKD"}';

        // 更新表單標題
        document.querySelector('.store-form-section h3').innerHTML = '<i class="fas fa-edit"></i> 分店資料';
    }

    /**
     * 保存分店
     */
    async saveStore(event) {
        event.preventDefault();

        const form = document.getElementById('store-form');
        if (!form) return;

        const storeId = document.getElementById('store-id').value;
        const isEdit = !!storeId;

        // 收集表單數據（映射到API字段名）
        const storeData = {
            store_name: document.getElementById('store-name').value,
            store_code: document.getElementById('store-code').value,
            address: document.getElementById('store-address').value,
            phone: document.getElementById('store-phone').value,
            email: document.getElementById('store-email').value,
            opening_hours: document.getElementById('store-opening-hours').value,
            status: document.getElementById('store-status').value,
            description: document.getElementById('store-description').value
        };

        // 處理JSON設定
        try {
            const settingsText = document.getElementById('store-settings').value;
            if (settingsText.trim()) {
                storeData.settings = JSON.parse(settingsText);
            }
        } catch (error) {
            this.addMessage('JSON設定格式錯誤，請檢查格式', 'error');
            return;
        }

        // 驗證必填字段
        if (!storeData.store_name || !storeData.store_code) {
            this.addMessage('請填寫分店名稱和分店代碼', 'error');
            return;
        }

        try {
            const url = isEdit ? `/api/stores/${storeId}` : '/api/stores';
            const method = isEdit ? 'PUT' : 'POST';

            // 構建headers，包含可選的身份驗證令牌
            const headers = {
                'Content-Type': 'application/json'
            };

            // 如果存在currentToken，添加Authorization header
            if (this.currentToken) {
                headers['Authorization'] = `Bearer ${this.currentToken}`;
            }

            const response = await fetch(url, {
                method: method,
                headers: headers,
                body: JSON.stringify(storeData)
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage(isEdit ? '分店更新成功' : '分店創建成功', 'success');
                this.clearStoreForm();
                await this.loadStores(); // 重新加載列表
            } else {
                this.addMessage((isEdit ? '分店更新失敗' : '分店創建失敗') + ': ' + result.error, 'error');
            }
        } catch (error) {
            console.error('保存分店時發生錯誤:', error);
            this.addMessage('保存分店時發生錯誤: ' + error.message, 'error');
        }
    }

    /**
     * 確認刪除分店
     */
    confirmDeleteStore(storeId) {
        if (!confirm('確定要刪除此分店嗎？此操作無法還原。')) {
            return;
        }

        this.deleteStore(storeId);
    }

    /**
     * 刪除分店
     */
    async deleteStore(storeId) {
        try {
            // 構建headers，包含可選的身份驗證令牌
            const headers = {};

            // 如果存在currentToken，添加Authorization header
            if (this.currentToken) {
                headers['Authorization'] = `Bearer ${this.currentToken}`;
            }

            const response = await fetch(`/api/stores/${storeId}`, {
                method: 'DELETE',
                headers: headers
            });

            const result = await response.json();

            if (result.success) {
                this.addMessage('分店刪除成功', 'success');
                await this.loadStores(); // 重新加載列表

                // 如果正在編輯這個分店，清空表單
                const currentStoreId = document.getElementById('store-id').value;
                if (currentStoreId === storeId) {
                    this.clearStoreForm();
                }
            } else {
                this.addMessage('分店刪除失敗: ' + result.error, 'error');
            }
        } catch (error) {
            console.error('刪除分店時發生錯誤:', error);
            this.addMessage('刪除分店時發生錯誤: ' + error.message, 'error');
        }
    }

    /**
     * 設置分店管理事件
     */
    setupStoreManagementEvents() {
        // 分店表單提交事件
        const storeForm = document.getElementById('store-form');
        if (storeForm) {
            storeForm.addEventListener('submit', (e) => this.saveStore(e));
        }

        // 取消按鈕
        const cancelBtn = document.getElementById('cancel-store-btn');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => this.clearStoreForm());
        }

        // 新增分店按鈕
        const addStoreBtn = document.getElementById('add-store-btn');
        if (addStoreBtn) {
            addStoreBtn.addEventListener('click', () => {
                this.clearStoreForm();
                document.querySelector('.store-form-section').scrollIntoView({ behavior: 'smooth' });
            });
        }

        // 刷新分店列表按鈕
        const refreshBtn = document.getElementById('refresh-stores-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.loadStores());
        }

        // 小票機分店選擇器變化事件
        const receiptPrinterStoreSelector = document.getElementById('receipt-printer-store-select');
        if (receiptPrinterStoreSelector) {
            receiptPrinterStoreSelector.addEventListener('change', (e) => {
                const selectedStoreId = e.target.value;
                if (selectedStoreId) {
                    // 只加載該分店的打印機配置，不改變主分店選擇
                    this.loadPrinterConfigs(selectedStoreId);
                }
            });
        }
    }

    /**
     * 加載可訪問的分店列表
     */
    async loadAccessibleStores() {
        try {
            const response = await fetch('/api/stores');
            const result = await response.json();

            if (result.success) {
                this.accessibleStores = result.data || [];

                // 從本地存儲恢復選擇的分店
                const savedStoreId = localStorage.getItem('selected_store_id');
                if (savedStoreId && this.accessibleStores.some(store => store.id === savedStoreId)) {
                    this.selectedStoreId = savedStoreId;
                    console.log(`從本地存儲恢復分店選擇: ${savedStoreId}`);
                }

                // 設置默認選擇的分店（如果還沒有選擇或選擇的分店不在列表中）
                if (this.accessibleStores.length > 0) {
                    const hasValidSelection = this.selectedStoreId &&
                        this.accessibleStores.some(store => store.id === this.selectedStoreId);
                    if (!hasValidSelection) {
                        // 選擇第一個分店作為默認
                        this.selectedStoreId = this.accessibleStores[0].id;
                        console.log(`設置默認分店選擇: ${this.selectedStoreId}`);
                    }
                }

                this.updateStoreSelector();

                // 顯示分店選擇器（如果有可訪問的分店）
                const storeSelectorContainer = document.getElementById('store-selector-container');
                if (storeSelectorContainer && this.accessibleStores.length > 0) {
                    storeSelectorContainer.classList.remove('hidden');
                }
            }
        } catch (error) {
            console.error('加載分店列表失敗:', error);
            // 靜默失敗，不影響主要功能
        }
    }

    /**
     * 更新分店選擇器UI
     */
    updateStoreSelector() {
        const storeSelector = document.getElementById('store-selector');
        const receiptPrinterStoreSelector = document.getElementById('receipt-printer-store-select');

        if (!storeSelector && !receiptPrinterStoreSelector) return;

        // 保存當前選擇的值
        const currentValue = storeSelector ? storeSelector.value : '';
        const currentReceiptPrinterValue = receiptPrinterStoreSelector ? receiptPrinterStoreSelector.value : '';

        // 清空選項（移除"全部"選項）
        if (storeSelector) storeSelector.innerHTML = '';
        if (receiptPrinterStoreSelector) receiptPrinterStoreSelector.innerHTML = '<option value="">選擇分店...</option>';

        // 如果沒有可訪問的分店，顯示提示
        if (!this.accessibleStores || this.accessibleStores.length === 0) {
            if (storeSelector) {
                const option = document.createElement('option');
                option.value = '';
                option.textContent = '無可用分店';
                option.disabled = true;
                storeSelector.appendChild(option);
                storeSelector.disabled = true;
            }
            if (receiptPrinterStoreSelector) {
                receiptPrinterStoreSelector.disabled = true;
            }
            return;
        } else {
            if (storeSelector) storeSelector.disabled = false;
            if (receiptPrinterStoreSelector) receiptPrinterStoreSelector.disabled = false;
        }

        // 添加分店選項
        this.accessibleStores.forEach(store => {
            const optionText = `${store.store_name || store.name} (${store.store_code || store.code})`;
            if (storeSelector) {
                const option = document.createElement('option');
                option.value = store.id;
                option.textContent = optionText;
                storeSelector.appendChild(option);
            }
            if (receiptPrinterStoreSelector) {
                const option = document.createElement('option');
                option.value = store.id;
                option.textContent = optionText;
                receiptPrinterStoreSelector.appendChild(option);
            }
        });

        // 確定要選擇的值
        let valueToSelect = currentValue;

        // 如果當前值為空或不存在於可訪問分店中，選擇第一個分店
        if (!valueToSelect || !this.accessibleStores.some(store => store.id === valueToSelect)) {
            valueToSelect = this.accessibleStores[0]?.id || '';
        }

        // 設置選擇的值
        if (valueToSelect) {
            if (storeSelector) {
                storeSelector.value = valueToSelect;
                // 如果選擇的值與當前selectedStoreId不同，觸發變更事件
                if (valueToSelect !== this.selectedStoreId) {
                    this.selectedStoreId = valueToSelect;
                    // 使用setTimeout避免在渲染過程中觸發事件循環問題
                    setTimeout(() => {
                        this.handleStoreChange(valueToSelect);
                    }, 0);
                }
            }
            if (receiptPrinterStoreSelector) {
                receiptPrinterStoreSelector.value = valueToSelect;
            }
        }
    }

    /**
     * 處理分店選擇變化
     */
    handleStoreChange(storeId) {
        this.selectedStoreId = storeId;

        // 保存選擇的分店到本地存儲
        if (storeId) {
            localStorage.setItem('selected_store_id', storeId);
        } else {
            localStorage.removeItem('selected_store_id');
        }

        // 重新加載客人列表（使用新的分店過濾）
        this.loadCustomers();

        // 重新加載今日統計
        this.loadTodayStats();

        // 重新加載入場離場記錄
        this.loadEntryRecords();

        // 重新加載打印機配置
        this.loadPrinterConfigs();

        // 顯示選擇的分店信息
        if (storeId) {
            const selectedStore = this.accessibleStores.find(store => store.id === storeId);
            if (selectedStore) {
                this.addMessage(`已切換到分店: ${selectedStore.store_name || selectedStore.name}`, 'info');
            }
        } else {
            // 理論上不會發生，因為已移除"全部"選項，但保留處理以防萬一
            this.addMessage('未選擇分店', 'warning');
        }
    }

    // ==================== 打印機配置管理方法 ====================

    /**
     * 加載打印機配置列表
     * @param {string} storeId - 可選的分店ID，如果不提供則使用當前選擇的分店
     * @param {boolean} shouldAutoConnect - 是否嘗試自動連接默認配置，默認true
     */
    async loadPrinterConfigs(storeId, shouldAutoConnect = true) {
        try {
            const targetStoreId = storeId || this.selectedStoreId;

            // 構建查詢參數，包含目標分店ID
            const params = new URLSearchParams();
            if (targetStoreId) {
                params.append('store_id', targetStoreId);
            }

            const url = `/api/cashier/printer-configs${params.toString() ? '?' + params.toString() : ''}`;
            const response = await fetch(url);
            const result = await response.json();
            if (result.success) {
                this.printerConfigs = result.data || [];
                this.updatePrinterConfigUI();
                console.log(`加載了 ${this.printerConfigs.length} 個打印機配置 (分店: ${targetStoreId})`);

                // 如果有配置且需要自動連接，嘗試自動連接默認配置
                // 延遲連接避免系統無響應
                // 只有在未嘗試過自動重連且沒有正在進行的重連嘗試時才進行自動連接
                if (shouldAutoConnect && !this.hasAttemptedPrinterReconnect && this.printerReconnectAttempts === 0) {
                    setTimeout(async () => {
                        await this.autoConnectDefaultPrinter(targetStoreId);
                    }, 1000);
                }
            } else {
                this.addMessage('加載打印機配置失敗: ' + (result.error || '未知錯誤'), 'error');
            }
        } catch (error) {
            console.error('加載打印機配置失敗:', error);
            // 不顯示錯誤消息，避免干擾用戶
        }
    }

    /**
     * 自動連接默認打印機配置
     * @param {string} storeId - 分店ID
     * @param {AbortSignal} signal - 可選的取消信號
     * @param {boolean} isRetry - 是否為重試嘗試
     */
    async autoConnectDefaultPrinter(storeId, signal = null, isRetry = false) {
        let timeoutId = null;
        try {
            // 清除現有的重連定時器
            if (this.printerReconnectTimer) {
                clearTimeout(this.printerReconnectTimer);
                this.printerReconnectTimer = null;
            }

            // 檢查是否有默認配置
            const defaultConfig = this.printerConfigs.find(config => config.is_default === 1);
            if (!defaultConfig) {
                console.log(`分店 ${storeId} 沒有默認打印機配置，跳過自動連接`);
                return;
            }

            // 檢查是否已經是連接狀態
            const statusElement = document.getElementById('receipt-printer-status');
            if (statusElement && statusElement.textContent.includes('已連接')) {
                console.log(`分店 ${storeId} 的打印機已經是連接狀態`);
                // 重置重連計數器，因為已經連接成功
                this.printerReconnectAttempts = 0;
                return;
            }

            console.log(`嘗試自動連接分店 ${storeId} 的默認打印機: ${defaultConfig.printer_name} (${isRetry ? '重試' : '首次'}嘗試, 第${this.printerReconnectAttempts + 1}次)`);

            // 使用配置進行連接
            const requestBody = {
                connectionType: defaultConfig.connection_type,
                printerType: defaultConfig.printer_type,
                storeId: storeId
            };

            if (defaultConfig.connection_type === 'wifi') {
                requestBody.ipAddress = defaultConfig.ip_address;
                requestBody.port = defaultConfig.port;
            } else {
                requestBody.bluetoothAddress = defaultConfig.bluetooth_address;
            }

            // 創建AbortController用於超時
            const abortController = new AbortController();
            timeoutId = setTimeout(() => {
                abortController.abort();
                console.log(`打印機連接超時（${this.printerConnectionTimeout}ms）`);
            }, this.printerConnectionTimeout);

            // 構建fetch選項
            const fetchOptions = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(requestBody),
                signal: abortController.signal
            };

            // 如果提供了外部signal且已中止，則中止abortController
            if (signal && signal.aborted) {
                abortController.abort();
            }

            const response = await fetch('/api/cashier/connect-receipt-printer', fetchOptions);
            clearTimeout(timeoutId);
            timeoutId = null;

            const result = await response.json();
            if (result.success) {
                console.log(`自動連接打印機成功: ${defaultConfig.printer_name}`);
                this.updateReceiptPrinterStatus('已連接');
                this.enableReceiptPrinterControls(true);

                // 設置已嘗試自動重連標記
                this.hasAttemptedPrinterReconnect = true;
                // 重置重連計數器
                this.printerReconnectAttempts = 0;

                // 更新打印機配置字段，確保模板編輯器可以讀取
                if (defaultConfig.connection_type === 'wifi') {
                    const ipField = document.getElementById('receipt-printer-ip');
                    const portField = document.getElementById('receipt-printer-port');
                    const typeField = document.getElementById('receipt-printer-type');
                    const connectionRadio = document.querySelector('input[name="receipt-printer-connection"][value="wifi"]');

                    if (ipField && defaultConfig.ip_address) ipField.value = defaultConfig.ip_address;
                    if (portField && defaultConfig.port) portField.value = defaultConfig.port;
                    if (typeField && defaultConfig.printer_type) typeField.value = defaultConfig.printer_type;
                    if (connectionRadio) connectionRadio.checked = true;

                    console.log(`更新打印機字段: IP=${defaultConfig.ip_address}, Port=${defaultConfig.port}, Type=${defaultConfig.printer_type}`);
                }
                // 注意：藍牙連接的字段更新可能需要額外處理，但模板編輯器目前只支持WiFi測試打印
            } else {
                console.warn(`自動連接打印機失敗: ${result.error || '未知錯誤'}`);
                // 增加重連嘗試次數
                this.printerReconnectAttempts++;

                // 檢查是否超過最大嘗試次數
                if (this.printerReconnectAttempts < this.printerReconnectMaxAttempts) {
                    console.log(`將在3分鐘後嘗試第${this.printerReconnectAttempts + 1}次重連`);
                    this.printerReconnectTimer = setTimeout(() => {
                        this.autoConnectDefaultPrinter(storeId, null, true);
                    }, 3 * 60 * 1000); // 3分鐘
                } else {
                    console.log(`已達到最大重連嘗試次數（${this.printerReconnectMaxAttempts}次），停止自動重連，等待頁面刷新`);
                }
            }
        } catch (error) {
            // 清除超時定時器（如果仍在運行）
            if (timeoutId) {
                clearTimeout(timeoutId);
                timeoutId = null;
            }

            // 檢查是否是AbortError（請求被取消）
            if (error.name === 'AbortError') {
                console.log('打印機連接請求已被取消或超時');
                // 超時也視為失敗，進行重試邏輯
                this.printerReconnectAttempts++;
                if (this.printerReconnectAttempts < this.printerReconnectMaxAttempts) {
                    console.log(`連接超時，將在3分鐘後嘗試第${this.printerReconnectAttempts + 1}次重連`);
                    this.printerReconnectTimer = setTimeout(() => {
                        this.autoConnectDefaultPrinter(storeId, null, true);
                    }, 3 * 60 * 1000);
                } else {
                    console.log(`已達到最大重連嘗試次數（${this.printerReconnectMaxAttempts}次），停止自動重連`);
                }
                return;
            }
            console.error('自動連接打印機錯誤:', error);
        }
    }

    /**
     * 保存打印機配置
     */
    async savePrinterConfig(config) {
        try {
            const response = await fetch('/api/cashier/printer-configs', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(config)
            });
            const result = await response.json();
            if (result.success) {
                this.addMessage(`打印機配置 "${config.printer_name}" 保存成功`, 'success');
                await this.loadPrinterConfigs(); // 重新加載列表
                return result.data;
            } else {
                this.addMessage('保存失敗: ' + (result.error || '未知錯誤'), 'error');
                return null;
            }
        } catch (error) {
            this.addMessage('保存打印機配置失敗: ' + error.message, 'error');
            return null;
        }
    }

    /**
     * 更新打印機配置UI
     */
    updatePrinterConfigUI() {
        const configSelect = document.getElementById('printer-config-select');
        if (!configSelect) return;

        // 保存當前選擇的值
        const currentValue = configSelect.value;

        // 清空選項
        configSelect.innerHTML = '<option value="">選擇保存的配置...</option>';

        // 添加配置選項
        if (this.printerConfigs && this.printerConfigs.length > 0) {
            this.printerConfigs.forEach(config => {
                const option = document.createElement('option');
                option.value = config.id;
                option.textContent = `${config.printer_name} (${config.connection_type === 'wifi' ? `${config.ip_address}:${config.port}` : config.bluetooth_address})${config.is_default ? ' ★' : ''}`;
                option.dataset.config = JSON.stringify(config);
                configSelect.appendChild(option);
            });
        }

        // 恢復之前的選擇（如果存在）
        if (currentValue && this.printerConfigs.some(config => config.id === currentValue)) {
            configSelect.value = currentValue;
        }

        // 更新配置名稱輸入框的提示
        const configNameInput = document.getElementById('printer-config-name');
        if (configNameInput) {
            const selectedOption = configSelect.options[configSelect.selectedIndex];
            if (selectedOption && selectedOption.value) {
                configNameInput.value = '';
                configNameInput.placeholder = '修改名稱（可選）';
            } else {
                configNameInput.placeholder = '輸入配置名稱以保存';
            }
        }
    }

    /**
     * 加載選中的打印機配置到表單
     */
    loadSelectedPrinterConfig() {
        const configSelect = document.getElementById('printer-config-select');
        if (!configSelect || !configSelect.value) return;

        try {
            const selectedOption = configSelect.options[configSelect.selectedIndex];
            const config = JSON.parse(selectedOption.dataset.config);

            // 更新WiFi/藍牙選擇
            const wifiRadio = document.querySelector('input[name="receipt-printer-connection"][value="wifi"]');
            const bluetoothRadio = document.querySelector('input[name="receipt-printer-connection"][value="bluetooth"]');

            if (config.connection_type === 'wifi') {
                if (wifiRadio) wifiRadio.checked = true;
                document.getElementById('receipt-printer-ip').value = config.ip_address || '';
                document.getElementById('receipt-printer-port').value = config.port || '9100';

                // 隱藏藍牙設備選擇
                const bluetoothSection = document.getElementById('receipt-printer-bluetooth-section');
                if (bluetoothSection) bluetoothSection.classList.add('hidden');
            } else if (config.connection_type === 'bluetooth') {
                if (bluetoothRadio) bluetoothRadio.checked = true;
                // 觸發連接類型切換以顯示藍牙設置
                this.handleConnectionTypeChange('bluetooth');

                // 檢查藍牙地址是否在掃描設備列表中
                const deviceSelect = document.getElementById('receipt-printer-bluetooth-devices');
                let deviceFound = false;
                if (deviceSelect && config.bluetooth_address) {
                    for (let i = 0; i < deviceSelect.options.length; i++) {
                        if (deviceSelect.options[i].value === config.bluetooth_address) {
                            deviceSelect.selectedIndex = i;
                            deviceFound = true;
                            break;
                        }
                    }
                }

                // 根據是否找到設備設置藍牙模式
                const scanModeRadio = document.querySelector('input[name="bluetooth-mode"][value="scan"]');
                const manualModeRadio = document.querySelector('input[name="bluetooth-mode"][value="manual"]');

                if (deviceFound) {
                    // 設備在列表中，使用掃描模式
                    if (scanModeRadio) scanModeRadio.checked = true;
                    this.handleBluetoothModeChange('scan');
                } else {
                    // 設備不在列表中，使用手動模式並填充地址
                    if (manualModeRadio) manualModeRadio.checked = true;
                    this.handleBluetoothModeChange('manual');
                    const addressInput = document.getElementById('receipt-printer-bluetooth-address');
                    if (addressInput && config.bluetooth_address) {
                        addressInput.value = config.bluetooth_address;
                    }
                }
            }

            // 更新打印機類型
            const printerTypeSelect = document.getElementById('receipt-printer-type');
            if (printerTypeSelect) {
                printerTypeSelect.value = config.printer_type || 'epson';
            }

            // 更新配置名稱輸入框
            const configNameInput = document.getElementById('printer-config-name');
            if (configNameInput) {
                configNameInput.value = config.printer_name;
                configNameInput.placeholder = '修改名稱（可選）';
            }

            this.addMessage(`已加載配置: ${config.printer_name}`, 'info');
        } catch (error) {
            console.error('加載打印機配置錯誤:', error);
        }
    }

    /**
     * 刪除選中的打印機配置
     */
    async deleteSelectedPrinterConfig() {
        const configSelect = document.getElementById('printer-config-select');
        if (!configSelect || !configSelect.value) {
            this.addMessage('請先選擇一個配置', 'error');
            return;
        }

        const configId = configSelect.value;
        const selectedOption = configSelect.options[configSelect.selectedIndex];
        const configName = selectedOption.textContent;

        if (!confirm(`確定要刪除打印機配置 "${configName}" 嗎？`)) {
            return;
        }

        try {
            const response = await fetch(`/api/cashier/printer-configs/${configId}`, {
                method: 'DELETE'
            });
            const result = await response.json();
            if (result.success) {
                this.addMessage(`打印機配置 "${configName}" 已刪除`, 'success');
                await this.loadPrinterConfigs();

                // 清除表單
                const configNameInput = document.getElementById('printer-config-name');
                if (configNameInput) {
                    configNameInput.value = '';
                    configNameInput.placeholder = '輸入配置名稱以保存';
                }
            } else {
                this.addMessage('刪除失敗: ' + (result.error || '未知錯誤'), 'error');
            }
        } catch (error) {
            this.addMessage('刪除打印機配置失敗: ' + error.message, 'error');
        }
    }

    /**
     * 將選中的配置設為默認
     */
    async setDefaultPrinterConfig() {
        const configSelect = document.getElementById('printer-config-select');
        if (!configSelect || !configSelect.value) {
            this.addMessage('請先選擇一個配置', 'error');
            return;
        }

        const configId = configSelect.value;
        try {
            const response = await fetch(`/api/cashier/printer-configs/${configId}/set-default`, {
                method: 'POST'
            });
            const result = await response.json();
            if (result.success) {
                this.addMessage('已設為默認打印機配置', 'success');
                await this.loadPrinterConfigs();
            } else {
                this.addMessage('設置失敗: ' + (result.error || '未知錯誤'), 'error');
            }
        } catch (error) {
            this.addMessage('設置默認配置失敗: ' + error.message, 'error');
        }
    }

    /**
     * 測試選中的打印機配置
     */
    async testSelectedPrinterConfig() {
        const configSelect = document.getElementById('printer-config-select');
        if (!configSelect || !configSelect.value) {
            this.addMessage('請先選擇一個配置', 'error');
            return;
        }

        const configId = configSelect.value;
        try {
            this.addMessage('正在測試打印機連接...', 'info');
            const response = await fetch(`/api/cashier/printer-configs/${configId}/test-connection`, {
                method: 'POST'
            });
            const result = await response.json();
            if (result.success) {
                this.addMessage('打印機連接測試成功', 'success');
            } else {
                this.addMessage('連接測試失敗: ' + (result.error || '未知錯誤'), 'error');
            }
        } catch (error) {
            this.addMessage('測試打印機連接失敗: ' + error.message, 'error');
        }
    }

    /**
     * 修改連接小票機方法，支持配置保存
     */
    async connectReceiptPrinter() {
        // 防止重複點擊
        if (this._connectingReceiptPrinter) {
            console.log('連接小票機操作正在執行中，跳過本次請求，當前標誌:', this._connectingReceiptPrinter, '時間:', new Date().toISOString());
            console.trace('調用堆棧');
            return;
        }

        console.log('開始連接小票機，設置標誌為true，時間:', new Date().toISOString());
        this._connectingReceiptPrinter = true;
        const connectionType = document.querySelector('input[name="receipt-printer-connection"]:checked').value;
        this.receiptPrinterConnectionType = connectionType; // 保存連接類型

        // 獲取配置名稱
        const configNameInput = document.getElementById('printer-config-name');
        const configName = configNameInput ? configNameInput.value.trim() : '';

        // 確定目標分店ID：優先使用小票機分店選擇器，否則使用主分店選擇器
        const receiptPrinterStoreSelector = document.getElementById('receipt-printer-store-select');
        const targetStoreId = receiptPrinterStoreSelector && receiptPrinterStoreSelector.value ?
                              receiptPrinterStoreSelector.value : this.selectedStoreId;

        try {
            if (connectionType === 'wifi') {
                const ip = document.getElementById('receipt-printer-ip').value.trim();
                const port = document.getElementById('receipt-printer-port').value.trim();
                const printerType = document.getElementById('receipt-printer-type') ? document.getElementById('receipt-printer-type').value : 'epson';

                if (!ip) {
                    this.addMessage('請輸入IP地址', 'error');
                    return;
                }

                this.addMessage('正在連接WiFi小票機...', 'info');
                const requestBody = {
                    connectionType: 'wifi',
                    ipAddress: ip,
                    port: parseInt(port) || 9100,
                    printerType: printerType,
                    storeId: targetStoreId
                };

                // 如果有配置名稱，添加到請求
                if (configName) {
                    requestBody.configName = configName;
                }

                const response = await fetch('/api/cashier/connect-receipt-printer', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(requestBody)
                });
                const result = await response.json();

                if (result.success) {
                    this.updateReceiptPrinterStatus('已連接');
                    this.addMessage('小票機連接成功' + (configName ? `，配置 "${configName}" 已保存` : ''), 'success');
                    this.enableReceiptPrinterControls(true);

                    // 確保打印機字段已更新，方便模板編輯器讀取
                    const ipField = document.getElementById('receipt-printer-ip');
                    const portField = document.getElementById('receipt-printer-port');
                    const typeField = document.getElementById('receipt-printer-type');
                    const connectionRadio = document.querySelector('input[name="receipt-printer-connection"][value="wifi"]');

                    if (ipField && ip) ipField.value = ip;
                    if (portField && port) portField.value = port;
                    if (typeField && printerType) typeField.value = printerType;
                    if (connectionRadio) connectionRadio.checked = true;

                    console.log(`手動連接後更新字段: IP=${ip}, Port=${port}, Type=${printerType}`);

                    // 重新加載配置列表
                    if (configName) {
                        await this.loadPrinterConfigs();
                    }
                } else {
                    this.addMessage('小票機連接失敗: ' + result.error, 'error');
                }
            } else {
                // 藍牙連接
                const printerType = document.getElementById('receipt-printer-type') ? document.getElementById('receipt-printer-type').value : 'epson';
                let deviceAddress = '';

                // 檢查藍牙模式
                const bluetoothModeRadio = document.querySelector('input[name="bluetooth-mode"]:checked');
                const bluetoothMode = bluetoothModeRadio ? bluetoothModeRadio.value : 'scan';

                console.log('Bluetooth mode:', bluetoothMode);

                if (bluetoothMode === 'scan') {
                    // 掃描模式：從下拉框獲取設備地址
                    const deviceSelect = document.getElementById('receipt-printer-bluetooth-devices');
                    deviceAddress = deviceSelect ? deviceSelect.value.trim() : '';

                    if (!deviceAddress) {
                        this.addMessage('請選擇藍牙設備', 'error');
                        return;
                    }
                } else {
                    // 手動模式：從輸入框獲取設備地址
                    const addressInput = document.getElementById('receipt-printer-bluetooth-address');
                    deviceAddress = addressInput ? addressInput.value.trim() : '';

                    if (!deviceAddress) {
                        this.addMessage('請輸入藍牙地址', 'error');
                        return;
                    }

                    // 驗證藍牙地址格式 (簡單驗證)
                    const btAddressRegex = /^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$/;
                    if (!btAddressRegex.test(deviceAddress)) {
                        this.addMessage('請輸入有效的藍牙地址格式 (例如: 00:11:22:33:44:55)', 'error');
                        return;
                    }
                }

                console.log('Connecting to bluetooth device:', deviceAddress);
                this.addMessage('正在連接藍牙小票機...', 'info');
                const requestBody = {
                    connectionType: 'bluetooth',
                    bluetoothAddress: deviceAddress,
                    printerType: printerType,
                    storeId: targetStoreId
                };

                // 如果有配置名稱，添加到請求
                if (configName) {
                    requestBody.configName = configName;
                }

                const response = await fetch('/api/cashier/connect-receipt-printer', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(requestBody)
                });

                if (!response.ok) {
                    let errorText = await response.text();
                    console.error('服務器錯誤響應:', response.status, errorText);
                    try {
                        const errorResult = JSON.parse(errorText);
                        this.addMessage(`藍牙小票機連接失敗 (${response.status}): ${errorResult.error || errorResult.message || errorText}`, 'error');
                    } catch {
                        this.addMessage(`藍牙小票機連接失敗 (${response.status}): ${errorText}`, 'error');
                    }
                    return;
                }

                const result = await response.json();

                if (result.success) {
                    this.updateReceiptPrinterStatus('已連接');
                    this.addMessage('藍牙小票機連接成功' + (configName ? `，配置 "${configName}" 已保存` : ''), 'success');
                    this.enableReceiptPrinterControls(true);

                    // 重新加載配置列表
                    if (configName) {
                        await this.loadPrinterConfigs();
                    }
                } else {
                    this.addMessage('藍牙小票機連接失敗: ' + result.error, 'error');
                }
            }
        } catch (error) {
            this.addMessage('連接小票機失敗: ' + error.message, 'error');
        } finally {
            console.log('連接小票機操作完成，重置標誌為false，時間:', new Date().toISOString());
            this._connectingReceiptPrinter = false;
        }
    }

    /**
     * 修改測試小票機方法，支持從配置加載
     */
    async testReceiptPrinter() {
        try {
            const connectionType = this.receiptPrinterConnectionType;
            if (!connectionType) {
                this.addMessage('請先連接小票機', 'error');
                return;
            }

            // 確定目標分店ID：優先使用小票機分店選擇器，否則使用主分店選擇器
            const receiptPrinterStoreSelector = document.getElementById('receipt-printer-store-select');
            const targetStoreId = receiptPrinterStoreSelector && receiptPrinterStoreSelector.value ?
                                  receiptPrinterStoreSelector.value : this.selectedStoreId;

            // 檢查是否有選中的配置
            const configSelect = document.getElementById('printer-config-select');
            let requestBody = { connectionType: connectionType };

            if (configSelect && configSelect.value) {
                // 使用選中的配置進行測試
                const selectedOption = configSelect.options[configSelect.selectedIndex];
                const config = JSON.parse(selectedOption.dataset.config);

                requestBody = {
                    connectionType: config.connection_type,
                    ipAddress: config.ip_address,
                    port: config.port,
                    bluetoothAddress: config.bluetooth_address,
                    printerType: config.printer_type,
                    storeId: targetStoreId
                };

                this.addMessage(`正在測試配置 "${config.printer_name}"...`, 'info');
            } else {
                // 使用當前表單中的設置
                if (connectionType === 'wifi') {
                    const ip = document.getElementById('receipt-printer-ip').value.trim();
                    const port = document.getElementById('receipt-printer-port').value.trim();
                    const printerType = document.getElementById('receipt-printer-type') ? document.getElementById('receipt-printer-type').value : 'epson';

                    if (!ip) {
                        this.addMessage('請輸入IP地址', 'error');
                        return;
                    }

                    requestBody.ipAddress = ip;
                    requestBody.port = parseInt(port) || 9100;
                    requestBody.printerType = printerType;
                } else {
                    const deviceSelect = document.getElementById('receipt-printer-bluetooth-devices');
                    const deviceAddress = deviceSelect.value;
                    const printerType = document.getElementById('receipt-printer-type') ? document.getElementById('receipt-printer-type').value : 'epson';

                    if (!deviceAddress) {
                        this.addMessage('請選擇藍牙設備', 'error');
                        return;
                    }

                    requestBody.bluetoothAddress = deviceAddress;
                    requestBody.printerType = printerType;
                }

                requestBody.storeId = targetStoreId;
                this.addMessage('正在測試小票機打印...', 'info');
            }

            const response = await fetch('/api/cashier/test-receipt-printer', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(requestBody)
            });
            const result = await response.json();

            if (result.success) {
                this.addMessage('小票機測試成功', 'success');
            } else {
                this.addMessage('小票機測試失敗: ' + result.error, 'error');
            }
        } catch (error) {
            this.addMessage('小票機測試失敗: ' + error.message, 'error');
        }
    }

    /**
     * 初始化打印機配置管理
     */
    async initPrinterConfigManagement() {
        this.setupPrinterConfigEvents();
        await this.loadPrinterConfigs();
    }

    /**
     * 設置打印機配置事件監聽器
     */
    setupPrinterConfigEvents() {
        // 配置選擇變化事件
        const configSelect = document.getElementById('printer-config-select');
        if (configSelect) {
            configSelect.addEventListener('change', () => this.loadSelectedPrinterConfig());
        }

        // 保存配置按鈕
        const saveConfigBtn = document.getElementById('save-printer-config-btn');
        if (saveConfigBtn) {
            saveConfigBtn.addEventListener('click', async () => {
                const connectionType = document.querySelector('input[name="receipt-printer-connection"]:checked');
                if (!connectionType) {
                    this.addMessage('請先選擇連接類型', 'error');
                    return;
                }

                const configNameInput = document.getElementById('printer-config-name');
                const configName = configNameInput ? configNameInput.value.trim() : '';
                if (!configName) {
                    this.addMessage('請輸入配置名稱', 'error');
                    return;
                }

                const printerType = document.getElementById('receipt-printer-type') ? document.getElementById('receipt-printer-type').value : 'epson';

                // 確定目標分店ID：優先使用小票機分店選擇器，否則使用主分店選擇器
                const receiptPrinterStoreSelector = document.getElementById('receipt-printer-store-select');
                const targetStoreId = receiptPrinterStoreSelector && receiptPrinterStoreSelector.value ?
                                      receiptPrinterStoreSelector.value : this.selectedStoreId;

                const config = {
                    printer_name: configName,
                    connection_type: connectionType.value,
                    printer_type: printerType,
                    storeId: targetStoreId
                };

                if (connectionType.value === 'wifi') {
                    const ip = document.getElementById('receipt-printer-ip').value.trim();
                    const port = document.getElementById('receipt-printer-port').value.trim();

                    if (!ip) {
                        this.addMessage('請輸入IP地址', 'error');
                        return;
                    }

                    config.ip_address = ip;
                    config.port = parseInt(port) || 9100;
                } else {
                    const deviceSelect = document.getElementById('receipt-printer-bluetooth-devices');
                    const deviceAddress = deviceSelect ? deviceSelect.value : '';

                    if (!deviceAddress) {
                        this.addMessage('請選擇藍牙設備', 'error');
                        return;
                    }

                    config.bluetooth_address = deviceAddress;
                }

                await this.savePrinterConfig(config);
            });
        }

        // 設為默認按鈕
        const setDefaultBtn = document.getElementById('set-default-printer-config-btn');
        if (setDefaultBtn) {
            setDefaultBtn.addEventListener('click', () => this.setDefaultPrinterConfig());
        }

        // 刪除配置按鈕
        const deleteConfigBtn = document.getElementById('delete-printer-config-btn');
        if (deleteConfigBtn) {
            deleteConfigBtn.addEventListener('click', () => this.deleteSelectedPrinterConfig());
        }

        // 測試配置按鈕
        const testConfigBtn = document.getElementById('test-printer-config-btn');
        if (testConfigBtn) {
            testConfigBtn.addEventListener('click', () => this.testSelectedPrinterConfig());
        }
    }

    /**
     * 初始化主機IP設定
     */
    initMasterIpSettings() {
        try {
            // 讀取保存的主服務器IP
            const savedMasterIp = localStorage.getItem('masterServerIp');
            const currentUrl = window.location.href;
            const currentHost = window.location.host;

            // 更新UI
            const masterIpInput = document.getElementById('master-server-ip');
            const currentUrlInput = document.getElementById('current-url');
            const hostModeElement = document.getElementById('host-mode');

            if (masterIpInput && savedMasterIp) {
                masterIpInput.value = savedMasterIp;
            }

            if (currentUrlInput) {
                currentUrlInput.value = currentUrl;
            }

            // 檢測當前模式
            const isLocalhost = currentHost.includes('localhost') || currentHost.includes('127.0.0.1') || currentHost === '';
            const isMasterServer = isLocalhost || !savedMasterIp || currentUrl.includes(savedMasterIp);

            if (hostModeElement) {
                if (isMasterServer) {
                    hostModeElement.textContent = '主服務器模式';
                    hostModeElement.className = 'status-value online';
                    if (masterIpInput) {
                        masterIpInput.value = currentHost || 'localhost:3000';
                        masterIpInput.disabled = true;
                    }
                } else {
                    hostModeElement.textContent = '客戶端模式';
                    hostModeElement.className = 'status-value offline';
                    if (masterIpInput) {
                        masterIpInput.disabled = false;
                    }
                }
            }

            // 檢查是否需要重定向到主服務器
            this.checkAndRedirectToMaster();

        } catch (error) {
            console.error('初始化主機IP設定錯誤:', error);
        }
    }

    /**
     * 保存主服務器IP
     */
    saveMasterIp() {
        try {
            const masterIpInput = document.getElementById('master-server-ip');
            if (!masterIpInput) {
                this.addMessage('找不到IP輸入框', 'error');
                return;
            }

            let masterIp = masterIpInput.value.trim();
            if (!masterIp) {
                this.addMessage('請輸入主服務器IP', 'error');
                return;
            }

            // 規範化IP格式
            masterIp = this.normalizeMasterIp(masterIp);

            // 保存到localStorage
            localStorage.setItem('masterServerIp', masterIp);

            // 更新當前URL顯示
            const currentUrlInput = document.getElementById('current-url');
            if (currentUrlInput) {
                currentUrlInput.value = window.location.href;
            }

            // 更新模式顯示
            const hostModeElement = document.getElementById('host-mode');
            if (hostModeElement) {
                const currentHost = window.location.host;
                const isLocalhost = currentHost.includes('localhost') || currentHost.includes('127.0.0.1') || currentHost === '';

                if (isLocalhost || window.location.href.includes(masterIp)) {
                    hostModeElement.textContent = '主服務器模式';
                    hostModeElement.className = 'status-value online';
                } else {
                    hostModeElement.textContent = '客戶端模式';
                    hostModeElement.className = 'status-value offline';
                }
            }

            this.addMessage(`主服務器IP已保存: ${masterIp}`, 'success');

        } catch (error) {
            console.error('保存主服務器IP錯誤:', error);
            this.addMessage('保存失敗: ' + error.message, 'error');
        }
    }

    /**
     * 應用主服務器IP (重定向)
     */
    applyMasterIp() {
        try {
            const savedMasterIp = localStorage.getItem('masterServerIp');
            if (!savedMasterIp) {
                this.addMessage('請先保存主服務器IP', 'error');
                return;
            }

            const currentUrl = window.location.href;
            const targetUrl = this.buildMasterUrl(savedMasterIp);

            if (currentUrl.includes(targetUrl) || currentUrl.includes(savedMasterIp)) {
                this.addMessage('當前已經連接到主服務器', 'info');
                return;
            }

            const confirmRedirect = confirm(`將重定向到主服務器:\n${targetUrl}\n\n是否繼續？`);
            if (confirmRedirect) {
                window.location.href = targetUrl;
            }

        } catch (error) {
            console.error('應用主服務器IP錯誤:', error);
            this.addMessage('應用失敗: ' + error.message, 'error');
        }
    }

    /**
     * 自動檢測主服務器
     */
    async detectMasterIp() {
        try {
            this.addMessage('正在檢測主服務器...', 'info');

            // 常見的本地IP段
            const commonSubnets = ['192.168.1', '192.168.0', '192.168.3', '10.0.0', '172.16.0'];
            const port = 3000;
            const timeout = 1000; // 1秒超時
            const detectedServers = [];

            // 嘗試檢測本地網絡中的服務器
            // 注意：由於瀏覽器安全限制，我們只能嘗試有限的檢測方法
            // 這裡使用簡單的ping方法（通過Image對象）

            // 方法1: 嘗試常見的本地IP
            for (const subnet of commonSubnets) {
                for (let i = 1; i <= 10; i++) {
                    const ip = `${subnet}.${i}:${port}`;
                    const url = `http://${ip}/health`;

                    try {
                        // 使用fetch嘗試連接健康檢查端點
                        const response = await fetch(url, { mode: 'no-cors', method: 'HEAD' });
                        // no-cors模式下response是opaque，無法讀取狀態，但能發送請求
                        detectedServers.push(ip);
                        this.addMessage(`發現可能的服務器: ${ip}`, 'info');
                    } catch (error) {
                        // 忽略錯誤，繼續嘗試下一個IP
                    }
                }
            }

            // 方法2: 嘗試從URL猜測（如果當前是客戶端模式）
            const currentUrl = window.location.href;
            if (currentUrl.includes('http://')) {
                const urlObj = new URL(currentUrl);
                const currentIp = urlObj.host;

                // 如果是IP地址，嘗試同一子網的其他IP
                if (currentIp.match(/^\d+\.\d+\.\d+\.\d+$/)) {
                    const ipParts = currentIp.split('.');
                    const subnet = ipParts.slice(0, 3).join('.');

                    for (let i = 1; i <= 10; i++) {
                        if (i.toString() === ipParts[3]) continue; // 跳過自己

                        const ip = `${subnet}.${i}:${port}`;
                        const url = `http://${ip}/health`;

                        try {
                            await fetch(url, { mode: 'no-cors', method: 'HEAD' });
                            detectedServers.push(ip);
                            this.addMessage(`發現可能的服務器: ${ip}`, 'info');
                        } catch (error) {
                            // 忽略錯誤
                        }
                    }
                }
            }

            if (detectedServers.length > 0) {
                // 選擇第一個檢測到的服務器
                const detectedIp = detectedServers[0];
                const masterIpInput = document.getElementById('master-server-ip');
                if (masterIpInput) {
                    masterIpInput.value = detectedIp;
                    this.addMessage(`已自動檢測到主服務器: ${detectedIp}`, 'success');
                }
            } else {
                this.addMessage('未檢測到主服務器，請手動輸入', 'warning');
            }

        } catch (error) {
            console.error('檢測主服務器錯誤:', error);
            this.addMessage('檢測失敗: ' + error.message, 'error');
        }
    }

    /**
     * 檢查並重定向到主服務器
     */
    async checkAndRedirectToMaster() {
        try {
            // 只有客戶端模式才需要重定向
            const savedMasterIp = localStorage.getItem('masterServerIp');
            if (!savedMasterIp) return;

            const currentUrl = window.location.href;
            const currentHost = window.location.host;

            // 如果是localhost或127.0.0.1，可能是主服務器，不重定向
            const isLocalhost = currentHost.includes('localhost') || currentHost.includes('127.0.0.1') || currentHost === '';
            if (isLocalhost) return;

            // 如果當前URL已經包含保存的主服務器IP，不重定向
            if (currentUrl.includes(savedMasterIp)) return;

            // 檢查是否應該重定向（例如：客戶端訪問了錯誤的地址）
            const targetUrl = this.buildMasterUrl(savedMasterIp);

            // 構建健康檢查URL
            let healthUrl;
            try {
                const urlObj = new URL(targetUrl);
                urlObj.pathname = '/health';
                healthUrl = urlObj.toString();
            } catch (error) {
                console.error('構建健康檢查URL錯誤:', error);
                // 回退到簡單替換
                healthUrl = targetUrl.replace('/cashier', '/health').replace('//health', '/health');
            }

            // 先檢查主服務器是否在線
            this.addMessage(`正在檢查主服務器狀態: ${savedMasterIp}`, 'info');

            let isServerOnline = false;
            try {
                // 使用no-cors模式繞過CORS限制，只能檢測服務器是否響應
                await fetch(healthUrl, {
                    method: 'GET',
                    mode: 'no-cors',
                    cache: 'no-cache'
                });
                // 如果沒有拋出異常，認為服務器在線
                isServerOnline = true;
            } catch (error) {
                console.log('主服務器健康檢查失敗:', error);
            }

            if (!isServerOnline) {
                this.addMessage(`主服務器 ${savedMasterIp} 無法連接，請檢查網絡或服務器狀態`, 'error');
                return;
            }

            // 延遲重定向，讓用戶有機會看到界面
            this.addMessage(`主服務器在線，將在2秒後重定向到: ${savedMasterIp}`, 'info');

            setTimeout(() => {
                window.location.href = targetUrl;
            }, 2000);

        } catch (error) {
            console.error('檢查重定向錯誤:', error);
        }
    }

    /**
     * 規範化主服務器IP輸入
     * 移除協議前綴，確保有端口
     */
    normalizeMasterIp(ip) {
        if (!ip || typeof ip !== 'string') return ip;

        let normalized = ip.trim();

        // 移除協議前綴
        normalized = normalized.replace(/^https?:\/\//, '');

        // 移除路徑部分（如果有）
        const slashIndex = normalized.indexOf('/');
        if (slashIndex !== -1) {
            normalized = normalized.substring(0, slashIndex);
        }

        // 確保有端口
        if (!normalized.includes(':')) {
            normalized += ':3000';
        } else {
            // 驗證端口格式
            const parts = normalized.split(':');
            if (parts.length > 1) {
                const port = parts[parts.length - 1];
                if (!/^\d+$/.test(port)) {
                    // 端口不是數字，使用默認端口
                    normalized = parts.slice(0, -1).join(':') + ':3000';
                }
            }
        }

        return normalized;
    }

    /**
     * 構建主服務器URL
     */
    buildMasterUrl(masterIp) {
        // 確保有協議前綴
        let url = masterIp.trim();
        if (!url.startsWith('http://') && !url.startsWith('https://')) {
            url = `http://${url}`;
        }

        // 確保有路徑
        if (!url.includes('/cashier')) {
            url = `${url}/cashier`;
        }

        return url;
    }

    /**
     * 初始化分店管理
     */
    async initStoreManagement() {
        this.setupStoreManagementEvents();
        await this.loadStores();
    }
}

// 初始化應用
document.addEventListener('DOMContentLoaded', () => {
    // 如果已經加載了EnhancedCashierSystem，則不創建基礎CashierSystem實例
    if (window.cashierSystem && window.cashierSystem.constructor.name === 'EnhancedCashierSystem') {
        console.log('EnhancedCashierSystem已加載，跳過基礎CashierSystem初始化');
        return;
    }
    // 如果已經有現金系統實例，跳過初始化
    if (window.cashierSystem) {
        console.log('cashierSystem 實例已存在，跳過初始化');
        return;
    }
    window.cashierSystem = new CashierSystem();
});