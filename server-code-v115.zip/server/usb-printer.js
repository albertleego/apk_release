// USB 打印機模塊 — 透過 Windows Print API (winspool.drv) 發送 RAW ESC/POS 數據
// 配合 EM5827 (KPOS_216) 等 USB 熱敏小票機使用
// 底層使用 PowerShell Add-Type 呼叫 Win32 OpenPrinter / WritePrinter

const { execFile } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');
const iconv = require('iconv-lite');

/**
 * 將原始 ESC/POS Buffer 發送到 Windows USB 印表機
 * @param {Buffer} data - ESC/POS 指令緩衝區
 * @param {string} printerName - Windows 印表機名稱 (預設 KPOS_216)
 * @returns {Promise<{success: boolean, bytes: number}>}
 */
function sendRawToPrinter(data, printerName = 'KPOS_216') {
    return new Promise((resolve, reject) => {
        if (!data || data.length === 0) {
            return reject(new Error('打印數據為空'));
        }

        // 寫入暫存檔案
        const tmpFile = path.join(os.tmpdir(), `escpos_${Date.now()}_${Math.random().toString(36).slice(2,6)}.bin`);
        const psFile = path.join(os.tmpdir(), `print_${Date.now()}_${Math.random().toString(36).slice(2,6)}.ps1`);

        try {
            fs.writeFileSync(tmpFile, data);
        } catch (err) {
            return reject(new Error(`寫入暫存檔失敗: ${err.message}`));
        }

        // PowerShell 腳本：使用 Win32 Print API 發送 RAW 數據
        const psScript = `$data = [System.IO.File]::ReadAllBytes('${tmpFile.replace(/\\/g, '\\\\')}')
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class WinPrinter {
    [DllImport("winspool.drv", CharSet=CharSet.Unicode, SetLastError=true)]
    static extern bool OpenPrinter(string pPrinterName, out IntPtr phPrinter, IntPtr pDefault);
    [DllImport("winspool.drv", SetLastError=true)]
    static extern bool ClosePrinter(IntPtr hPrinter);
    [DllImport("winspool.drv", SetLastError=true)]
    static extern bool StartDocPrinter(IntPtr hPrinter, int level, ref DOC_INFO_1 pDocInfo);
    [DllImport("winspool.drv", SetLastError=true)]
    static extern bool EndDocPrinter(IntPtr hPrinter);
    [DllImport("winspool.drv", SetLastError=true)]
    static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, int dwCount, out int dwWritten);
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
    struct DOC_INFO_1 { public string pDocName; public string pOutputFile; public string pDataType; }
    public static string Send(string printerName, byte[] data) {
        IntPtr hPrinter = IntPtr.Zero;
        if (!OpenPrinter(printerName, out hPrinter, IntPtr.Zero))
            return "FAILED_Open:" + Marshal.GetLastWin32Error();
        try {
            DOC_INFO_1 d = new DOC_INFO_1() { pDocName="AutoCafe", pDataType="RAW" };
            if (!StartDocPrinter(hPrinter, 1, ref d))
                return "FAILED_StartDoc:" + Marshal.GetLastWin32Error();
            IntPtr p = Marshal.AllocHGlobal(data.Length);
            try {
                Marshal.Copy(data, 0, p, data.Length);
                int w = 0;
                if (!WritePrinter(hPrinter, p, data.Length, out w))
                    return "FAILED_Write:" + Marshal.GetLastWin32Error();
            } finally { Marshal.FreeHGlobal(p); }
            EndDocPrinter(hPrinter);
            return "OK:" + data.Length;
        } finally { ClosePrinter(hPrinter); }
    }
}
"@
try {
    $result = [WinPrinter]::Send('${printerName}', $data)
    Write-Host $result
} catch {
    Write-Host "EXCEPTION:$_"
}`;

        try {
            fs.writeFileSync(psFile, psScript, 'utf8');
        } catch (err) {
            try { fs.unlinkSync(tmpFile); } catch(e) {}
            return reject(new Error(`寫入 PowerShell 腳本失敗: ${err.message}`));
        }

        execFile('powershell.exe', [
            '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', psFile
        ], { timeout: 30000, maxBuffer: 1024 }, (err, stdout, stderr) => {
            // 清理暫存檔
            try { fs.unlinkSync(tmpFile); } catch(e) {}
            try { fs.unlinkSync(psFile); } catch(e) {}

            if (err) {
                return reject(new Error(`PowerShell 執行錯誤: ${err.message}`));
            }

            const result = (stdout || '').trim();
            console.log(`[usb-printer] PowerShell output: ${result}`);

            if (result.startsWith('OK:')) {
                const bytes = parseInt(result.split(':')[1], 10);
                resolve({ success: true, bytes });
            } else if (result.startsWith('FAILED_Open:')) {
                const code = parseInt(result.split(':')[1], 10);
                if (code === 1801) {
                    reject(new Error(`印表機「${printerName}」不存在 — 請先安裝驅動`));
                } else if (code === 1804) {
                    reject(new Error(`印表機「${printerName}」無法接收 RAW 數據 — 驅動問題`));
                } else {
                    reject(new Error(`開啟印表機失敗 (error ${code})`));
                }
            } else if (result.startsWith('FAILED_StartDoc:')) {
                reject(new Error(`StartDoc 失敗 — 請檢查印表機狀態 (error ${result.split(':')[1]})`));
            } else if (result.startsWith('EXCEPTION:')) {
                reject(new Error(`PowerShell 異常: ${result.substring(10)}`));
            } else {
                reject(new Error(`印表機回應異常: ${result}`));
            }
        });
    });
}

/**
 * 檢查 Windows USB 印表機是否連線
 * 雙重確認：(1) 印表機佇列正常 (2) USB 裝置 port 有實體連線
 * @param {string} printerName - Windows 印表機名稱
 * @returns {Promise<boolean>}
 */
function checkPrinterOnline(printerName = 'KPOS_216') {
    return new Promise((resolve) => {
        execFile('powershell.exe', [
            '-NoProfile', '-Command',
            `$p = Get-Printer -Name '${printerName}' -ErrorAction SilentlyContinue; if (!$p) { Write-Host 'NO_PRINTER'; return }; $portOk = if ($p.PortName -match 'USB|COM|LPT') { if (Get-WmiObject Win32_PnPEntity | Where-Object { $_.Name -match 'SUPERRISC|S31|KPOS' }) { 'OK' } else { 'NO_USB' } } else { 'OK' }; Write-Host ('STATUS:' + $p.PrinterStatus + ',WORKOFFLINE:' + ($p.WorkOffline -eq $true) + ',PORT:' + $portOk + ',PORTNAME:' + $p.PortName)`
        ], { timeout: 5000 }, (err, stdout) => {
            if (err || !stdout.trim()) {
                console.log(`[checkPrinterOnline] 指令失敗: ${err ? err.message : 'no output'}`);
                return resolve(false);
            }
            const raw = stdout.trim().replace(/\r?\n/g, '');
            console.log(`[checkPrinterOnline] ${printerName}: ${raw}`);

            if (raw === 'NO_PRINTER') return resolve(false);

            const m = raw.match(/STATUS:(\d+),WORKOFFLINE:(true|false),PORT:(\w+),PORTNAME:(.+)/);
            if (!m) {
                console.log(`[checkPrinterOnline] 無法解析輸出: ${raw}`);
                return resolve(false);
            }
            const statusOk = m[1] === '0';
            const workOffline = m[2] === 'true';
            const portOk = m[3] === 'OK';
            resolve(statusOk && !workOffline && portOk);
        });
    });
}

/**
 * EM5827 專用 — 使用 USB 打印入場小票
 * 包裝 printEntryReceipt 所需的完整 ESC/POS 構建 + 打印
 * 與 RawPrinter API 相容，但 execute() 改用 USB
 */
class UsbPrinter {
    constructor(config = {}) {
        this.printerName = config.printerName || 'KPOS_216';
        this.encoding = config.encoding || 'GBK';
        this.timeout = config.timeout || 30000;
        this.buffer = Buffer.alloc(0);
    }

    print(text) {
        const enc = this.encoding.toLowerCase();
        const buf = (enc === 'gbk' || enc === 'gb2312' || enc === 'gb18030')
            ? iconv.encode(text + '\r\n', this.encoding)
            : Buffer.from(text + '\r\n', this.encoding);
        this.buffer = Buffer.concat([this.buffer, buf]);
        return this;
    }

    println(text) {
        return this.print(text);
    }

    alignCenter() {
        this.buffer = Buffer.concat([this.buffer, Buffer.from([0x1B, 0x61, 0x01])]);
        return this;
    }

    alignLeft() {
        this.buffer = Buffer.concat([this.buffer, Buffer.from([0x1B, 0x61, 0x00])]);
        return this;
    }

    alignRight() {
        this.buffer = Buffer.concat([this.buffer, Buffer.from([0x1B, 0x61, 0x02])]);
        return this;
    }

    boldOn() {
        this.buffer = Buffer.concat([this.buffer, Buffer.from([0x1B, 0x45, 0x01])]);
        return this;
    }

    boldOff() {
        this.buffer = Buffer.concat([this.buffer, Buffer.from([0x1B, 0x45, 0x00])]);
        return this;
    }

    setSize(width = 1, height = 1) {
        const s = (Math.max(1, Math.min(8, width)) - 1) | ((Math.max(1, Math.min(8, height)) - 1) << 4);
        this.buffer = Buffer.concat([this.buffer, Buffer.from([0x1D, 0x21, s])]);
        return this;
    }

    newLine(count = 1) {
        for (let i = 0; i < count; i++) {
            this.buffer = Buffer.concat([this.buffer, Buffer.from('\r\n', 'ascii')]);
        }
        return this;
    }

    cut(mode = 0) {
        this.buffer = Buffer.concat([this.buffer, Buffer.from(mode === 0 ? [0x1D, 0x56, 0x00] : [0x1D, 0x56, 0x01])]);
        return this;
    }

    clear() {
        this.buffer = Buffer.alloc(0);
        return this;
    }

    /**
     * 執行 USB 打印（取代 RawPrinter.execute 的 TCP 方式）
     */
    async execute() {
        if (this.buffer.length === 0) {
            console.warn('[usb-printer] 緩衝區為空，跳過打印');
            return true;
        }

        // 前置：初始化 + GBK 編碼設定 + 中文模式
        const header = Buffer.from([
            0x1B, 0x40,       // ESC @ — 初始化
            0x1B, 0x74, 0x11, // ESC t 17 — 設定 GBK 編碼
            0x1C, 0x26        // FS & — 啟用中文模式
        ]);

        const fullData = Buffer.concat([header, this.buffer]);
        console.log(`[usb-printer] 發送 ${fullData.length} bytes 到 Windows 印表機「${this.printerName}」`);

        const result = await sendRawToPrinter(fullData, this.printerName);
        this.clear();
        return result.success;
    }
}

module.exports = { UsbPrinter, sendRawToPrinter, checkPrinterOnline };
