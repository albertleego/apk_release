const express = require('express');
const router = express.Router();
const storeAwareMiddleware = require('../middleware/store-aware');
const { getCustomerByQRCode, checkoutCustomer } = require('../../database/db');

// 為所有路由添加分店上下文中間件
router.use(storeAwareMiddleware.initStoreContext);

// QR Code掃描驗證（離場結賬）
router.post('/scan', async (req, res) => {
  try {
    const { qr_code } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';

    if (!qr_code) {
      return res.status(400).json({ error: '請提供QR Code' });
    }

    // 解析QR Code數據
    let qrData;
    try {
      qrData = JSON.parse(qr_code);
    } catch (e) {
      qrData = { qr_code: qr_code };
    }

    const qrCodeValue = qrData.qr_code || qr_code;

    // 查找客人（分店過濾）
    const customer = await getCustomerByQRCode(qrCodeValue, storeId);

    if (!customer) {
      return res.status(404).json({
        error: 'QR Code無效或客人已結賬',
        valid: false,
        can_exit: false
      });
    }

    // 檢查是否已結賬
    if (customer.is_checked_out) {
      return res.json({
        success: true,
        valid: true,
        checked_out: true,
        can_exit: true,
        message: '客人已結賬，可以離場',
        customer: {
          table_number: customer.table_number,
          checkout_time: customer.checkout_time,
          total_amount: customer.total_amount
        }
      });
    }

    // 獲取客人詳細訂單信息
    const db = require('../../database/db').db;
    const orderItems = await new Promise((resolve, reject) => {
      db.all(
        `SELECT oi.*, p.name as product_name
         FROM order_items oi
         LEFT JOIN products p ON oi.product_id = p.id
         WHERE oi.customer_id = ? AND COALESCE(oi.is_reversed, 0) = 0
         ORDER BY oi.purchased_at ASC`,
        [customer.id],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });

    // 計算總金額（含立減/折扣優惠）
    const totalAmount = orderItems.reduce((sum, item) => {
      const basePrice = item.price_at_time || 0;
      const flatDisc = item.flat_discount || 0;
      const pctDisc = item.percent_discount || 0;
      let effPrice = basePrice - flatDisc;
      if (pctDisc > 0) effPrice = effPrice * (100 - pctDisc) / 100;
      const effective = basePrice >= 0 ? Math.max(0, effPrice) : effPrice;
      return sum + Math.round(effective * item.quantity * 100) / 100;
    }, 0);

    // 更新數據庫中的總金額（如果不同步）
    if (Math.abs(totalAmount - customer.total_amount) > 0.01) {
      db.run(
        `UPDATE customers SET total_amount = ? WHERE id = ?`,
        [totalAmount, customer.id]
      );
    }

    res.json({
      success: true,
      valid: true,
      checked_out: false,
      can_exit: false, // 需要先結賬才能離場
      message: 'QR Code驗證成功，請結賬後離場',
      customer: {
        id: customer.id,
        table_number: customer.table_number,
        people_count: customer.people_count,
        entry_time: customer.entry_time,
        total_amount: totalAmount,
        qr_code: customer.qr_code
      },
      order_items: orderItems,
      summary: {
        total_items: orderItems.reduce((sum, item) => sum + item.quantity, 0),
        total_amount: totalAmount,
        item_count: orderItems.length
      }
    });

  } catch (error) {
    console.error('離場掃描錯誤:', error);
    res.status(500).json({
      error: '離場掃描失敗',
      message: error.message
    });
  }
});

// 執行結賬
router.post('/checkout', async (req, res) => {
  try {
    const { customer_id } = req.body;

    if (!customer_id) {
      return res.status(400).json({ error: '請提供客人ID' });
    }

    // 檢查客人是否存在且未結賬
    const customer = await new Promise((resolve, reject) => {
      const db = require('../../database/db').db;
      db.get(
        `SELECT * FROM customers WHERE id = ? AND is_checked_out = 0`,
        [customer_id],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!customer) {
      return res.status(404).json({ error: '客人不存在或已結賬' });
    }

    // 執行結賬
    await checkoutCustomer(customer_id);

    // 添加交易記錄
    const transactionId = require('uuid').v4();
    const db = require('../../database/db').db;
    db.run(
      `INSERT INTO transactions (id, customer_id, transaction_type, amount, description)
       VALUES (?, ?, ?, ?, ?)`,
      [
        transactionId,
        customer_id,
        'checkout',
        customer.total_amount,
        `離場結賬 - 桌號 ${customer.table_number}`
      ],
      (err) => {
        if (err) console.error('添加交易記錄錯誤:', err);
      }
    );

    // 觸發Socket事件
    const io = req.app.get('io');
    io.emit('checkout-complete', {
      customer_id: customer_id,
      table_number: customer.table_number,
      total_amount: customer.total_amount,
      checkout_time: new Date().toISOString(),
      exit_machine: true
    });

    // 通知門鎖系統允許離開（5分鐘有效期）
    io.emit('device-control', {
      device: 'door-lock',
      action: 'allow-exit',
      qr_code: customer.qr_code,
      valid_until: Date.now() + 300000, // 5分鐘
      customer_id: customer_id
    });

    // 觸發打印結賬小票
    const receiptData = {
      table_number: customer.table_number,
      qr_code: customer.qr_code,
      total_amount: customer.total_amount,
      checkout_time: new Date().toLocaleString('zh-TW'),
      transaction_id: transactionId
    };

    io.emit('print-exit-receipt', receiptData);

    res.json({
      success: true,
      message: '結賬成功，可以離場',
      customer_id: customer_id,
      table_number: customer.table_number,
      total_amount: customer.total_amount,
      checkout_time: new Date().toISOString(),
      exit_valid_until: Date.now() + 300000,
      receipt_data: receiptData
    });

  } catch (error) {
    console.error('結賬錯誤:', error);
    res.status(500).json({
      error: '結賬失敗',
      message: error.message
    });
  }
});

// 門鎖QR Code驗證（離場時）
router.post('/door-scan', async (req, res) => {
  try {
    const { qr_code } = req.body;

    if (!qr_code) {
      return res.status(400).json({ error: '請提供QR Code' });
    }

    // 解析QR Code數據
    let qrData;
    try {
      qrData = JSON.parse(qr_code);
    } catch (e) {
      qrData = { qr_code: qr_code };
    }

    const qrCodeValue = qrData.qr_code || qr_code;

    // 查找客人
    const db = require('../../database/db').db;
    const customer = await new Promise((resolve, reject) => {
      db.get(
        `SELECT * FROM customers WHERE qr_code = ?`,
        [qrCodeValue],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!customer) {
      return res.json({
        success: false,
        valid: false,
        door_open: false,
        message: '無效的QR Code'
      });
    }

    // 檢查是否已結賬
    if (!customer.is_checked_out) {
      return res.json({
        success: false,
        valid: true,
        checked_out: false,
        door_open: false,
        message: '請先結賬後再離場',
        customer: {
          table_number: customer.table_number,
          total_amount: customer.total_amount
        }
      });
    }

    // 檢查結賬時間是否在有效期內（5分鐘內）
    const checkoutTime = new Date(customer.checkout_time).getTime();
    const currentTime = Date.now();
    const timeSinceCheckout = currentTime - checkoutTime;

    if (timeSinceCheckout > 300000) { // 5分鐘
      return res.json({
        success: false,
        valid: true,
        checked_out: true,
        door_open: false,
        message: '結賬已過期，請重新結賬',
        customer: {
          table_number: customer.table_number,
          checkout_time: customer.checkout_time,
          minutes_ago: Math.floor(timeSinceCheckout / 60000)
        }
      });
    }

    // 可以開門
    const io = req.app.get('io');
    io.emit('device-control', {
      device: 'door-lock',
      action: 'open',
      qr_code: qrCodeValue,
      customer_id: customer.id
    });

    res.json({
      success: true,
      valid: true,
      checked_out: true,
      door_open: true,
      message: '驗證成功，門鎖已開啟',
      customer: {
        table_number: customer.table_number,
        checkout_time: customer.checkout_time,
        total_amount: customer.total_amount
      },
      door_status: {
        open: true,
        duration: 10000 // 門鎖開啟10秒
      }
    });

  } catch (error) {
    console.error('門鎖掃描錯誤:', error);
    res.status(500).json({
      error: '門鎖掃描失敗',
      message: error.message
    });
  }
});

// 獲取今日離場統計
router.get('/stats/today', (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];

    const db = require('../../database/db').db;
    db.all(
      `SELECT
        COUNT(*) as total_checkouts,
        SUM(total_amount) as total_revenue,
        AVG(total_amount) as avg_checkout,
        MIN(checkout_time) as first_checkout,
        MAX(checkout_time) as last_checkout
       FROM customers
       WHERE DATE(checkout_time) = ? AND is_checked_out = 1`,
      [today],
      (err, stats) => {
        if (err) {
          console.error('獲取離場統計錯誤:', err);
          return res.status(500).json({ error: '獲取統計失敗', message: err.message });
        }

        res.json({
          success: true,
          date: today,
          stats: stats[0] || {
            total_checkouts: 0,
            total_revenue: 0,
            avg_checkout: 0,
            first_checkout: null,
            last_checkout: null
          }
        });
      }
    );
  } catch (error) {
    console.error('獲取離場統計錯誤:', error);
    res.status(500).json({
      error: '獲取離場統計失敗',
      message: error.message
    });
  }
});

// 測試門鎖開啟（測試用）
router.post('/test-door-open', (req, res) => {
  try {
    const io = req.app.get('io');
    io.emit('device-control', {
      device: 'door-lock',
      action: 'open',
      test_mode: true,
      duration: 5000
    });

    res.json({
      success: true,
      message: '已發送開啟門鎖指令（測試模式）'
    });
  } catch (error) {
    console.error('測試門鎖開啟錯誤:', error);
    res.status(500).json({
      error: '測試門鎖開啟失敗',
      message: error.message
    });
  }
});

module.exports = router;