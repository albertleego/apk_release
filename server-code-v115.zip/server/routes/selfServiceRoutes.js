const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../../database/db');

// 使用環境變量中的分店ID
const STORE_ID = process.env.STORE_ID || 'default_store';

/**
 * @route GET /api/self-service/product/:code
 * @desc  依 QR Code 內容查詢商品（先比對 id，再比對 name）
 */
router.get('/product/:code', (req, res) => {
    try {
        const code = req.params.code.trim();
        if (!code) {
            return res.status(400).json({
                success: false,
                error: '缺少商品代碼'
            });
        }

        // 先比對 id（精確匹配）
        db.get(
            `SELECT id, name, description, price, stock, is_available, category, track_inventory
             FROM products WHERE id = ? AND is_available = 1`,
            [code],
            (err, product) => {
                if (err) {
                    console.error('查詢商品錯誤:', err);
                    return res.status(500).json({
                        success: false,
                        error: '服務器錯誤',
                        message: err.message
                    });
                }

                if (product) {
                    return res.json({
                        success: true,
                        data: {
                            id: product.id,
                            name: product.name,
                            description: product.description || '',
                            price: product.price,
                            stock: product.stock,
                            category: product.category || 'general',
                            track_inventory: product.track_inventory === 1
                        }
                    });
                }

                // 沒找到 → 再比對 name（模糊匹配）
                db.get(
                    `SELECT id, name, description, price, stock, is_available, category, track_inventory
                     FROM products WHERE name LIKE ? AND is_available = 1`,
                    [`%${code}%`],
                    (err2, productByName) => {
                        if (err2) {
                            console.error('查詢商品錯誤:', err2);
                            return res.status(500).json({
                                success: false,
                                error: '服務器錯誤',
                                message: err2.message
                            });
                        }

                        if (productByName) {
                            return res.json({
                                success: true,
                                data: {
                                    id: productByName.id,
                                    name: productByName.name,
                                    description: productByName.description || '',
                                    price: productByName.price,
                                    stock: productByName.stock,
                                    category: productByName.category || 'general',
                                    track_inventory: productByName.track_inventory === 1
                                }
                            });
                        }

                        // 完全找不到
                        res.status(404).json({
                            success: false,
                            error: '找不到此商品',
                            code: code
                        });
                    }
                );
            }
        );
    } catch (error) {
        console.error('獲取商品錯誤:', error);
        res.status(500).json({
            success: false,
            error: '服務器錯誤',
            message: error.message
        });
    }
});

/**
 * @route POST /api/self-service/order
 * @desc  送出自助收銀訂單
 * Body: {
 *   items: [{ product_id, quantity, price_at_time }],
 *   payment_method: "visa" | "master" | "alipay" | "wechat" | "octopus",
 *   total_amount: number
 * }
 */
router.post('/order', (req, res) => {
    try {
        const { items, payment_method, total_amount } = req.body;

        // 驗證
        if (!items || !Array.isArray(items) || items.length === 0) {
            return res.status(400).json({
                success: false,
                error: '請提供商品清單'
            });
        }

        if (!payment_method) {
            return res.status(400).json({
                success: false,
                error: '請選擇付款方式'
            });
        }

        const validMethods = ['visa', 'master', 'alipay', 'wechat', 'octopus'];
        if (!validMethods.includes(payment_method)) {
            return res.status(400).json({
                success: false,
                error: '無效的付款方式'
            });
        }

        // 建立臨時顧客記錄（自助收銀專用）
        const customerId = uuidv4();
        const orderId = uuidv4(); // 訂單編號（用於 qr_code / 小票號碼）
        const now = new Date().toISOString();

        // 驗證庫存
        const stockChecks = items.map(item => {
            return new Promise((resolve, reject) => {
                if (!item.product_id || !item.quantity || item.quantity <= 0) {
                    return reject(new Error('無效的商品項目'));
                }
                db.get(
                    `SELECT id, name, price, stock, track_inventory FROM products WHERE id = ? AND is_available = 1`,
                    [item.product_id],
                    (err, product) => {
                        if (err) return reject(err);
                        if (!product) return reject(new Error(`找不到商品: ${item.product_id}`));

                        // 如果有追蹤庫存，檢查是否足夠
                        if (product.track_inventory === 1 && product.stock < item.quantity) {
                            return reject(new Error(`${product.name} 庫存不足 (庫存: ${product.stock}, 需要: ${item.quantity})`));
                        }
                        resolve({ product, item });
                    }
                );
            });
        });

        Promise.all(stockChecks)
            .then((validatedItems) => {
                // 計算總金額
                const calculatedTotal = validatedItems.reduce((sum, vi) => {
                    return sum + (vi.product.price * vi.item.quantity);
                }, 0);

                // 如果有傳入 total_amount 就比對，否則用算出來的
                const finalTotal = total_amount || calculatedTotal;

                // 開始交易
                db.serialize(() => {
                    // 1. 建立顧客記錄（含 store_id，確保上傳阿里雲時歸入正確分店）
                    db.run(
                        `INSERT INTO customers (id, table_number, qr_code, people_count, entry_time, checkout_time, total_amount, is_checked_out, store_id)
                         VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)`,
                        [customerId, 'SS', orderId, 1, now, now, finalTotal, STORE_ID],
                        function(err) {
                            if (err) {
                                console.error('建立顧客記錄錯誤:', err);
                                return res.status(500).json({
                                    success: false,
                                    error: '建立訂單失敗',
                                    message: err.message
                                });
                            }

                            // 2. 插入訂單項目
                            let completedItems = 0;
                            let hasError = false;

                            validatedItems.forEach((vi, index) => {
                                const orderItemId = uuidv4();
                                db.run(
                                    `INSERT INTO order_items (id, customer_id, product_id, quantity, price_at_time, purchased_at)
                                     VALUES (?, ?, ?, ?, ?, ?)`,
                                    [orderItemId, customerId, vi.product.id, vi.item.quantity, vi.product.price, now],
                                    function(insertErr) {
                                        if (insertErr && !hasError) {
                                            hasError = true;
                                            return res.status(500).json({
                                                success: false,
                                                error: '寫入訂單失敗',
                                                message: insertErr.message
                                            });
                                        }

                                        // 3. 更新庫存（如果有追蹤庫存）
                                        if (!hasError && vi.product.track_inventory === 1) {
                                            db.run(
                                                `UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?`,
                                                [vi.item.quantity, vi.product.id, vi.item.quantity],
                                                function(stockErr) {
                                                    if (stockErr) {
                                                        console.error('更新庫存錯誤:', stockErr);
                                                    }
                                                }
                                            );
                                        }

                                        completedItems++;
                                        if (completedItems === validatedItems.length && !hasError) {
                                            // 4. 記錄交易
                                            const transactionId = uuidv4();
                                            db.run(
                                                `INSERT INTO transactions (id, customer_id, transaction_type, amount, description, payment_method)
                                                 VALUES (?, ?, 'checkout', ?, ?, ?)`,
                                                [transactionId, customerId, finalTotal,
                                                 `自助收銀 #${orderId.substring(0, 8)}`, payment_method],
                                                function(txErr) {
                                                    if (txErr) {
                                                        console.error('記錄交易錯誤:', txErr);
                                                    }

                                                    // 5. 回傳成功
                                                    res.json({
                                                        success: true,
                                                        message: '付款成功',
                                                        data: {
                                                            order_id: orderId.substring(0, 8).toUpperCase(),
                                                            customer_id: customerId,
                                                            total_amount: finalTotal,
                                                            payment_method: payment_method,
                                                            items_count: validatedItems.length,
                                                            items: validatedItems.map(vi => ({
                                                                name: vi.product.name,
                                                                quantity: vi.item.quantity,
                                                                price: vi.product.price,
                                                                subtotal: vi.product.price * vi.item.quantity
                                                            })),
                                                            completed_at: now
                                                        }
                                                    });
                                                }
                                            );
                                        }
                                    }
                                );
                            });
                        }
                    );
                });
            })
            .catch(error => {
                res.status(400).json({
                    success: false,
                    error: error.message
                });
            });

    } catch (error) {
        console.error('提交訂單錯誤:', error);
        res.status(500).json({
            success: false,
            error: '服務器錯誤',
            message: error.message
        });
    }
});

/**
 * @route GET /api/self-service/products
 * @desc  取得所有可購買商品（同收銀系統 /api/cashier/products 模式）
 *        回傳格式一致：{ success, products }
 *        過濾條件：is_available=1 AND (stock>0 OR track_inventory=0)
 *        依分店 STORE_ID 過濾
 */
router.get('/products', (req, res) => {
    try {
        // 同收銀系統，只列出有庫存且可購買的商品
        let sql = `SELECT id, name, description, price, stock, is_available, category, track_inventory
                   FROM products
                   WHERE is_available = 1 AND (stock > 0 OR track_inventory = 0)`;
        let params = [];

        // 依分店過濾（同收銀系統的 buildStoreWhereClause）
        if (STORE_ID) {
            sql += ` AND store_id = ?`;
            params.push(STORE_ID);
        }

        sql += ` ORDER BY category, name`;

        db.all(sql, params, (err, products) => {
            if (err) {
                console.error('查詢商品清單錯誤:', err);
                return res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: err.message
                });
            }

            // 回傳格式同 /api/cashier/products：{ success, products }
            res.json({
                success: true,
                products: products
            });
        });
    } catch (error) {
        console.error('獲取商品清單錯誤:', error);
        res.status(500).json({
            success: false,
            error: '服務器錯誤',
            message: error.message
        });
    }
});

module.exports = router;
