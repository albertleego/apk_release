const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');

// 阿里雲唯一源頭：所有寫入/讀取都同步 forward 去阿里雲執行，阿里雲回覆原封轉發。
// 本地 DB 只係唯讀 cache/mirror，喺阿里雲確認之後先 best-effort 更新（失敗只 log，唔影響回覆）。
const ALIYUN_SERVER = (process.env.ALIYUN_SERVER || 'http://47.239.121.13:3000').replace(/\/$/, '');
const API_KEY = process.env.ALIYUN_API_KEY || process.env.MAIN_API_KEY || '';
const FETCH_TIMEOUT_MS = parseInt(process.env.ALIYUN_PROXY_TIMEOUT || '8000', 10);

/**
 * 同步 forward 去阿里雲，返回 { status, body }（要原封轉發 status code）。
 * 網絡失敗 / 逾時 → throw { code: 'ALIYUN_UNREACHABLE' }。
 */
function relayToAliyun(method, endpoint, body) {
    const url = `${ALIYUN_SERVER}${endpoint}`;
    const opts = { method, headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY } };
    if (body && typeof body === 'object') opts.body = JSON.stringify(body);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    opts.signal = controller.signal;
    return fetch(url, opts).then(async (r) => {
        clearTimeout(timer);
        let json = null;
        try { json = await r.json(); } catch (e) { json = { success: false, error: `HTTP ${r.status}` }; }
        return { status: r.status, body: json };
    }).catch((e) => {
        clearTimeout(timer);
        const err = new Error('無法連線阿里雲：' + (e.message || ''));
        err.code = 'ALIYUN_UNREACHABLE';
        throw err;
    });
}

function aliyunUnreachable(message) {
    return { success: false, error: 'ALIYUN_UNREACHABLE', message: message || '無法連線阿里雲，操作未完成。請檢查網絡後重試。' };
}

// ==================== 本地 mirror helpers（best-effort，絕唔影響回覆） ====================

function mirrorWaitinglistUpsert(aliyunResponse, reqBody) {
    try {
        const d = (aliyunResponse && aliyunResponse.data) || {};
        const id = d.id || (reqBody && reqBody.id);
        if (!id) return;
        const store_id = d.store_id || reqBody.store_id;
        const adults = d.adults != null ? d.adults : (reqBody.adults != null ? reqBody.adults : 0);
        const children = d.children != null ? d.children : (reqBody.children != null ? reqBody.children : 0);
        const phone = d.phone != null ? d.phone : (reqBody.phone != null ? reqBody.phone : '');
        const notes = (reqBody && reqBody.notes) || '';
        const lang = (reqBody && reqBody.lang) || 'zh-TW';
        const ref = d.ref || d.ref_number || null;
        db.run(
            `INSERT OR REPLACE INTO waitinglist (id, store_id, adults, children, phone, notes, lang, status, ref_number, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, 'waiting', ?, datetime('now', '+8 hours'), datetime('now', '+8 hours'))`,
            [id, store_id, adults, children, phone, notes, lang, ref],
            function (err) { if (err) console.error('mirror waitinglist upsert failed:', err.message); }
        );
    } catch (e) { console.error('mirror waitinglist upsert error:', e.message); }
}

function mirrorWaitinglistUpdate(id, fields) {
    try {
        const sets = [];
        const params = [];
        const valid = { status: 1, table_number: 1 };
        Object.keys(fields || {}).forEach(function (k) {
            if (valid[k]) { sets.push(`${k} = ?`); params.push(fields[k]); }
        });
        if (!sets.length) return;
        sets.push(`updated_at = datetime('now', '+8 hours')`);
        params.push(id);
        db.run(`UPDATE waitinglist SET ${sets.join(', ')} WHERE id = ?`, params, function (err) {
            if (err) console.error('mirror waitinglist update failed:', err.message);
        });
    } catch (e) { console.error('mirror waitinglist update error:', e.message); }
}

function mirrorWaitinglistList(rows) {
    try {
        if (!Array.isArray(rows)) return;
        rows.forEach(function (r) {
            if (!r || !r.id) return;
            const created_at = r.created_at || `datetime('now', '+8 hours')`;
            db.run(
                `INSERT OR REPLACE INTO waitinglist (id, store_id, adults, children, phone, notes, lang, status, ref_number, table_number, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now', '+8 hours'))`,
                [r.id, r.store_id, r.adults, r.children, r.phone, r.notes, r.lang, r.status, r.ref_number, r.table_number, created_at],
                function (err) { if (err) console.error('mirror waitinglist list failed:', err.message); }
            );
        });
    } catch (e) { console.error('mirror waitinglist list error:', e.message); }
}

/**
 * @route POST /api/waitinglist
 * @desc 新增候位（公開）— 由阿里雲執行（含同 phone 舊候位取消、ref number 生成）
 * @access Public
 */
router.post('/', async (req, res) => {
    try {
        const { store_id, adults, children, phone, notes, lang } = req.body;
        if (!store_id) {
            return res.status(400).json({ success: false, error: '缺少必要欄位', message: '請選擇分店' });
        }
        // 本地生成 id，當 explicitId forward 去阿里雲（冪等：重試唔會重複）
        const id = uuidv4();
        let result;
        try {
            result = await relayToAliyun('POST', '/api/waitinglist', { id, store_id, adults, children, phone, notes, lang });
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            return res.status(503).json(aliyunUnreachable('無法連線阿里雲，候位未建立。請檢查網絡後重試。'));
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            mirrorWaitinglistUpsert(result.body, req.body);
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

router.get('/', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const { store_id, status, date } = req.query;
        const qs = new URLSearchParams();
        if (store_id) qs.set('store_id', store_id);
        if (status) qs.set('status', status);
        if (date) qs.set('date', date);
        let result;
        try {
            result = await relayToAliyun('GET', `/api/waitinglist?${qs.toString()}`);
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            // 阿里雲 down → 讀本地 mirror
            return readLocalWaitinglist(res, req.query);
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            mirrorWaitinglistList(result.body.data);
            return res.json(result.body);
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

function readLocalWaitinglist(res, query) {
    const { store_id, status, date } = query;
    let q = `SELECT * FROM waitinglist WHERE 1=1`;
    const params = [];
    if (store_id) { q += ` AND store_id = ?`; params.push(store_id); }
    if (status) { q += ` AND status = ?`; params.push(status); }
    if (date) { q += ` AND substr(created_at, 1, 10) = ?`; params.push(date); }
    q += ` ORDER BY created_at DESC`;
    db.all(q, params, (err, rows) => {
        if (err) return res.status(500).json({ success: false, error: '查詢錯誤', message: err.message });
        res.json({ success: true, data: rows || [], source: 'offline-cache', warning: '阿里雲無法連線，顯示離線資料' });
    });
}

/**
 * @route PATCH /api/waitinglist/:id
 * @desc 更新候位狀態（員工權限）— 由阿里雲執行
 * @access Private/Staff
 */
router.patch('/:id', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const { id } = req.params;
        const { status, table_number } = req.body;
        const validStatuses = ['waiting', 'contacted', 'confirmed', 'arrived', 'cancelled'];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({ success: false, error: '狀態值無效' });
        }
        const body = { status };
        if (table_number) body.table_number = table_number;
        let result;
        try {
            result = await relayToAliyun('PATCH', `/api/waitinglist/${id}`, body);
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            return res.status(503).json(aliyunUnreachable('無法連線阿里雲，操作未完成。請檢查網絡後重試。'));
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            mirrorWaitinglistUpdate(id, body);
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route POST /api/waitinglist/:id/notify
 * @desc 致電客人：WhatsApp + 語音通話 — 由阿里雲執行（isHKPhone 規則喺阿里雲）
 * @access Private/Staff
 */
router.post('/:id/notify', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const { id } = req.params;
        let result;
        try {
            result = await relayToAliyun('POST', `/api/waitinglist/${id}/notify`, null);
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            return res.status(503).json(aliyunUnreachable('無法連線阿里雲，通知未完成。請檢查網絡後重試。'));
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            mirrorWaitinglistUpdate(id, { status: 'contacted' });
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        console.error('致電錯誤:', error);
        res.status(500).json({ success: false, error: '致電失敗', message: error.message });
    }
});

/**
 * @route POST /api/waitinglist/:id/call
 * @desc 再致電（只打電話，唔 send WhatsApp）— 由阿里雲執行
 * @access Private/Staff
 */
router.post('/:id/call', authMiddleware.authenticate, authMiddleware.requireStaff, async (req, res) => {
    try {
        const { id } = req.params;
        let result;
        try {
            result = await relayToAliyun('POST', `/api/waitinglist/${id}/call`, null);
        } catch (e) {
            if (e.code !== 'ALIYUN_UNREACHABLE') throw e;
            return res.status(503).json(aliyunUnreachable('無法連線阿里雲，致電未完成。請檢查網絡後重試。'));
        }
        if (result.status >= 200 && result.status < 300 && result.body && result.body.success) {
            mirrorWaitinglistUpdate(id, { status: 'contacted' });
        }
        return res.status(result.status).json(result.body);
    } catch (error) {
        console.error('再致電錯誤:', error);
        res.status(500).json({ success: false, error: '再致電失敗', message: error.message });
    }
});

module.exports = router;
