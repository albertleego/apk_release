/**
 * 自動咖啡館系統 - 檔案 Logger
 *
 * 攔截 console.log/error/warn 輸出到每日 Log 檔案
 * 檔案格式: logs/{STORE_NAME}_{YYYY-MM-DD}.log
 * 同時保留原終端機輸出
 */
const fs = require('fs');
const path = require('path');

class Logger {
  constructor(options = {}) {
    this.storeName = options.storeName || process.env.STORE_NAME || 'unknown';
    this.logDir = options.logDir || path.join(__dirname, '../../logs');

    // 確保 logs 目錄存在
    if (!fs.existsSync(this.logDir)) {
      fs.mkdirSync(this.logDir, { recursive: true });
    }

    // 保存原始的 console 方法
    this._originalConsole = {
      log: console.log.bind(console),
      info: console.info.bind(console),
      warn: console.warn.bind(console),
      error: console.error.bind(console),
      debug: console.debug.bind(console),
    };

    // 開始攔截
    this._overrideConsole();

    this._originalConsole.log(`[Logger] 已初始化: ${this.storeName}, 日誌目錄: ${this.logDir}`);
  }

  // 取得香港時間 (UTC+8)
  _hkNow() {
    const now = new Date();
    return new Date(now.getTime() + 8 * 3600000);
  }

  _hkDateStr() {
    return this._hkNow().toISOString().substring(0, 10); // YYYY-MM-DD
  }

  _hkTimeStr() {
    return this._hkNow().toISOString().substring(11, 19); // HH:MM:SS
  }

  _logFilePath() {
    return path.join(this.logDir, `${this.storeName}_${this._hkDateStr()}.log`);
  }

  _writeToFile(level, args) {
    const timestamp = `${this._hkDateStr()} ${this._hkTimeStr()}`;
    const message = args
      .map(a => (typeof a === 'string' ? a : a instanceof Error ? `${a.message}\n${a.stack}` : JSON.stringify(a)))
      .join(' ');
    const line = `[${timestamp}][${level}][${this.storeName}] ${message}`;

    try {
      fs.appendFileSync(this._logFilePath(), line + '\n');
    } catch (e) {
      this._originalConsole.error(`[Logger] 寫入檔案失敗:`, e.message);
    }

    return line;
  }

  _overrideConsole() {
    const self = this;

    console.log = function (...args) {
      const line = self._writeToFile('INFO', args);
      self._originalConsole.log(line);
    };

    console.info = function (...args) {
      const line = self._writeToFile('INFO', args);
      self._originalConsole.info(line);
    };

    console.warn = function (...args) {
      const line = self._writeToFile('WARN', args);
      self._originalConsole.warn(line);
    };

    console.error = function (...args) {
      const line = self._writeToFile('ERROR', args);
      self._originalConsole.error(line);
    };

    console.debug = function (...args) {
      const line = self._writeToFile('DEBUG', args);
      self._originalConsole.debug(line);
    };
  }

  /**
   * 動態切換分店（log 檔案名 + [store] tag 跟登入員工所屬分店）
   * 由 store-aware middleware 喺 resolve 到員工分店時呼叫。
   * @param {string} storeName 分店 ID（如 store_4）
   */
  setStore(storeName) {
    if (storeName && storeName !== this.storeName) {
      this._originalConsole.log(`[Logger] 切換分店: ${this.storeName} → ${storeName}`);
      this.storeName = storeName;
    }
  }

  /** 目前 log 使用嘅分店 */
  getStore() {
    return this.storeName;
  }

  /** 取得目前日期所有 log 檔案 */
  getTodayLogFiles() {
    if (!fs.existsSync(this.logDir)) return [];
    return fs.readdirSync(this.logDir)
      .filter(f => f.startsWith(this.storeName) && f.endsWith('.log'))
      .map(f => path.join(this.logDir, f));
  }

  /** 取得所有 log 檔案（不限日期） */
  getAllLogFiles() {
    if (!fs.existsSync(this.logDir)) return [];
    return fs.readdirSync(this.logDir)
      .filter(f => f.endsWith('.log'))
      .map(f => path.join(this.logDir, f));
  }

  /** 取得 logs 目錄路徑 */
  getLogDir() {
    return this.logDir;
  }
}

// 共用 instance（由 server/index.js new 之後 set 入嚟，畀 store-aware middleware / logUploadRoutes 攞）
let _sharedInstance = null;
Logger.setShared = function (instance) {
  _sharedInstance = instance;
};
Logger.getShared = function () {
  return _sharedInstance;
};

module.exports = Logger;
