const { db } = require('../../database/db');
const Logger = require('../utils/logger');

/**
 * 切換 log 到員工登入嘅分店（log 檔案名 + [store] tag 跟登入員工所屬分店）
 * 未有 shared logger 或冇分店 ID 時唔郁（保留 env 預設）
 */
function switchLogStore(storeId) {
    if (!storeId) return;
    const logger = Logger.getShared();
    if (logger) logger.setStore(storeId);
}

/**
 * 分店感知中間件
 * 提供分店隔離和管理員跨店訪問支持
 */
const storeAwareMiddleware = {
    /**
     * 中間件：初始化分店上下文
     * 可以在authMiddleware之後使用，如果沒有身份驗證則使用默認分店
     */
    initStoreContext: (req, res, next) => {
        console.log('[store-aware] initStoreContext called, path:', req.path, 'query:', req.query, 'body:', req.body);
        // 從員工信息獲取store_id（如果可用）
        const employeeStoreId = req.employee?.store_id || null;
        const employeeRole = req.employee?.role || null;
        const employeeId = req.employee?.id || null;
        console.log('[store-aware] employee:', {
            id: employeeId,
            role: employeeRole,
            store_id: employeeStoreId,
            hasEmployee: !!req.employee
        });

        // 檢查查詢參數中是否有分店ID（支持管理員指定或公開API使用）
        let targetStoreId = null;
        if (req.query.store_id) {
            // 如果提供了store_id查詢參數，使用它（需要驗證分店是否存在）
            targetStoreId = req.query.store_id;
            console.log('[store-aware] 使用查詢參數store_id:', targetStoreId);
        } else if (req.body && req.body.store_id) {
            // 檢查請求體中是否有store_id
            targetStoreId = req.body.store_id;
            console.log('[store-aware] 使用請求體store_id:', targetStoreId);
        } else if (employeeStoreId) {
            // 員工只能使用自己的分店，管理員默認使用自己的分店（如果沒有指定）
            targetStoreId = employeeStoreId;
            console.log('[store-aware] 使用員工store_id:', targetStoreId);
        } else {
            // 沒有員工信息或未分配分店，不設置分店ID（根據需求：未登入時不應下載商品）
            targetStoreId = null;
            console.log('[store-aware] 未登入，不設置分店ID（targetStoreId=null）');
        }

        // 驗證分店ID的有效性（如果提供了）
        if (targetStoreId) {
            db.get(
                `SELECT id, store_code, store_name, is_active FROM stores WHERE id = ?`,
                [targetStoreId],
                (err, store) => {
                    if (err) {
                        console.error('驗證分店錯誤:', err);
                        return res.status(500).json({
                            success: false,
                            error: '服務器錯誤',
                            message: err.message
                        });
                    }

                    if (!store) {
                        // 分店不存在，使用默認分店作為後備
                        console.warn(`分店 ${targetStoreId} 不存在，使用默認分店`);
                        targetStoreId = 'default_store';

                        db.get(
                            `SELECT id, store_code, store_name, is_active FROM stores WHERE id = ?`,
                            ['default_store'],
                            (err2, defaultStore) => {
                                if (err2 || !defaultStore) {
                                    // 連默認分店都不存在，創建一個
                                    console.warn('默認分店不存在，創建一個...');
                                    const storeId = 'default_store';
                                    db.run(
                                        `INSERT INTO stores (id, store_code, store_name, address, timezone, is_active)
                                         VALUES (?, ?, ?, ?, ?, ?)`,
                                        [storeId, 'DEFAULT', '默認分店', '香港', 'Asia/Hong_Kong', 1],
                                        (insertErr) => {
                                            if (insertErr) {
                                                console.error('創建默認分店錯誤:', insertErr);
                                            }
                                            // 設置分店上下文
                                            req.storeContext = {
                                                store_id: storeId,
                                                store_code: 'DEFAULT',
                                                store_name: '默認分店',
                                                is_admin: employeeRole === 'admin',
                                                can_access_all_stores: employeeRole === 'admin'
                                            };
                                            switchLogStore(storeId);
                                            next();
                                        }
                                    );
                                } else {
                                    // 設置分店上下文
                                    req.storeContext = {
                                        store_id: defaultStore.id,
                                        store_code: defaultStore.store_code,
                                        store_name: defaultStore.store_name,
                                        is_admin: employeeRole === 'admin',
                                        can_access_all_stores: employeeRole === 'admin'
                                    };
                                    switchLogStore(defaultStore.id);
                                    next();
                                }
                            }
                        );
                        return;
                    }

                    if (store.is_active !== 1) {
                        return res.status(400).json({
                            success: false,
                            error: '分店已停用',
                            message: '指定的分店已停用'
                        });
                    }

                    // 設置分店上下文
                    console.log('[store-aware] 設置storeContext:', {
                        store_id: targetStoreId,
                        store_code: store.store_code,
                        store_name: store.store_name,
                        is_admin: employeeRole === 'admin',
                        can_access_all_stores: employeeRole === 'admin',
                        employee_id: employeeId,
                        employee_role: employeeRole
                    });
                    req.storeContext = {
                        store_id: targetStoreId,
                        store_code: store.store_code,
                        store_name: store.store_name,
                        is_admin: employeeRole === 'admin',
                        can_access_all_stores: employeeRole === 'admin'
                    };

                    switchLogStore(targetStoreId);
                    next();
                }
            );
        } else {
            // 沒有分店ID（可能是總部管理員或員工未分配分店）
            // 總部管理員可以訪問所有分店
            const isHeadquartersAdmin = employeeRole === 'admin' && !employeeStoreId;

            console.log('[store-aware] 沒有分店ID情況，設置storeContext:', {
                store_id: null,
                employee_id: employeeId,
                employee_role: employeeRole,
                employee_store_id: employeeStoreId,
                is_headquarters_admin: isHeadquartersAdmin
            });

            req.storeContext = {
                store_id: null,
                store_code: null,
                store_name: null,
                is_admin: employeeRole === 'admin',
                can_access_all_stores: isHeadquartersAdmin
            };

            next();
        }
    },

    /**
     * 構建分店過濾的WHERE子句
     * @param {Object} options 選項
     * @param {string} options.tableAlias 表別名（可選）
     * @param {boolean} options.includeNull 是否包含store_id為NULL的記錄（默認false）
     * @returns {Object} { whereClause, params }
     */
    buildStoreWhereClause: (req, options = {}) => {
        const { tableAlias = '', includeNull = false } = options;
        const context = req.storeContext;

        if (!context) {
            throw new Error('storeContext未初始化，請先使用initStoreContext中間件');
        }

        let whereClause = '';
        let params = [];

        if (context.store_id) {
            // 指定了特定分店ID，無論是否可以訪問所有分店，都過濾到該分店
            whereClause = `${tableAlias}store_id = ?`;
            params = [context.store_id];
        } else if (context.can_access_all_stores) {
            // 可以訪問所有分店：管理員
            if (includeNull) {
                // 包括store_id為NULL的記錄（總部數據）
                whereClause = '';
            } else {
                // 只包括有分店的記錄
                whereClause = `${tableAlias}store_id IS NOT NULL`;
            }
        } else {
            // 沒有分店權限（異常情況）
            whereClause = '1=0'; // 不返回任何記錄
        }

        return { whereClause, params };
    },

    /**
     * 檢查員工是否有權訪問指定分店
     * @param {string} employeeId 員工ID
     * @param {string} storeId 分店ID
     * @returns {Promise<boolean>} 是否有權訪問
     */
    checkStoreAccess: (employeeId, storeId) => {
        return new Promise((resolve, reject) => {
            db.get(
                `SELECT e.role, e.store_id, s.is_active
                 FROM employees e
                 LEFT JOIN stores s ON e.store_id = s.id
                 WHERE e.id = ?`,
                [employeeId],
                (err, employee) => {
                    if (err) {
                        reject(err);
                        return;
                    }

                    if (!employee) {
                        resolve(false);
                        return;
                    }

                    // 管理員可以訪問所有分店
                    if (employee.role === 'admin') {
                        // 如果是總部管理員（store_id為NULL），可以訪問所有分店
                        if (!employee.store_id) {
                            resolve(true);
                            return;
                        }

                        // 分店管理員：只能訪問自己分店
                        resolve(employee.store_id === storeId);
                        return;
                    }

                    // 員工：只能訪問自己分店
                    resolve(employee.store_id === storeId);
                }
            );
        });
    },

    /**
     * 獲取員工可訪問的分店列表
     * @param {string} employeeId 員工ID
     * @returns {Promise<Array>} 分店列表
     */
    getAccessibleStores: (employeeId) => {
        return new Promise((resolve, reject) => {
            db.get(
                `SELECT e.role, e.store_id
                 FROM employees e
                 WHERE e.id = ?`,
                [employeeId],
                (err, employee) => {
                    if (err) {
                        reject(err);
                        return;
                    }

                    if (!employee) {
                        resolve([]);
                        return;
                    }

                    if (employee.role === 'admin' && !employee.store_id) {
                        // 總部管理員：可以訪問所有分店
                        db.all(
                            `SELECT id, store_code, store_name, address, phone, timezone, is_active
                             FROM stores
                             WHERE is_active = 1
                             ORDER BY store_code`,
                            (err, stores) => {
                                if (err) {
                                    reject(err);
                                } else {
                                    resolve(stores);
                                }
                            }
                        );
                    } else {
                        // 分店管理員或員工：只能訪問自己分店
                        const storeId = employee.store_id;
                        if (!storeId) {
                            resolve([]);
                            return;
                        }

                        db.all(
                            `SELECT id, store_code, store_name, address, phone, timezone, is_active
                             FROM stores
                             WHERE id = ? AND is_active = 1`,
                            [storeId],
                            (err, stores) => {
                                if (err) {
                                    reject(err);
                                } else {
                                    resolve(stores);
                                }
                            }
                        );
                    }
                }
            );
        });
    },

    /**
     * 中間件：要求分店訪問權限
     * 檢查員工是否有權訪問當前請求的分店
     */
    requireStoreAccess: (req, res, next) => {
        const employeeId = req.employee?.id;
        const storeId = req.storeContext?.store_id;

        if (!employeeId) {
            return res.status(401).json({
                success: false,
                error: '未授權',
                message: '請先登入系統'
            });
        }

        // 總部管理員可以訪問所有分店
        if (req.storeContext?.can_access_all_stores) {
            next();
            return;
        }

        // 檢查分店訪問權限
        storeAwareMiddleware.checkStoreAccess(employeeId, storeId)
            .then(hasAccess => {
                if (hasAccess) {
                    next();
                } else {
                    res.status(403).json({
                        success: false,
                        error: '分店訪問權限不足',
                        message: '您沒有權限訪問此分店的數據'
                    });
                }
            })
            .catch(error => {
                console.error('檢查分店訪問權限錯誤:', error);
                res.status(500).json({
                    success: false,
                    error: '服務器錯誤',
                    message: error.message
                });
            });
    },

    /**
     * 中間件：要求管理員權限（可選分店）
     * 總部管理員可以訪問所有分店，分店管理員只能訪問自己分店
     */
    requireAdminOrStoreAdmin: (req, res, next) => {
        const employeeRole = req.employee?.role;
        const employeeStoreId = req.employee?.store_id;
        const targetStoreId = req.storeContext?.store_id;

        if (employeeRole !== 'admin') {
            return res.status(403).json({
                success: false,
                error: '權限不足',
                message: '需要管理員權限才能執行此操作'
            });
        }

        // 總部管理員可以訪問所有分店
        if (!employeeStoreId) {
            next();
            return;
        }

        // 分店管理員只能訪問自己分店
        if (employeeStoreId === targetStoreId) {
            next();
        } else {
            res.status(403).json({
                success: false,
                error: '分店權限不足',
                message: '您只能管理自己分店的數據'
            });
        }
    }
};

module.exports = storeAwareMiddleware;