const twilio = require('twilio');

// 語音 TwiML Bin (預錄語音)
const VOICE_BINS = {
    'zh-TW': 'EH04387a8d8f04419570c9a353c31b0074',
    'zh-CN': 'EHa7415a49d2cd8247b20cbfb240b33437',
    'en': 'EH7e617bf47f3354ae452dc32161f3e6ce'
};

// WhatsApp Content Template SID (共用，所有分店用同一個)
const WHATSAPP_TEMPLATES = {
    'store_1': 'HXc5023abf40704dcf3b7b893ac6ff3807',
    'store_2': 'HXc5023abf40704dcf3b7b893ac6ff3807',
    'store_3': 'HXc5023abf40704dcf3b7b893ac6ff3807',
    'store_4': 'HXc5023abf40704dcf3b7b893ac6ff3807'
};

// 預約確認 WhatsApp Content Template SID（共用，所有分店用同一個）
// 雙語 Template (繁中 + English)
// Variables:
//   {{1}} storeName (中)    {{6}} dateEn
//   {{2}} dateCn             {{7}} timeEn (same as {{3}})
//   {{3}} time               {{8}} peopleEn
//   {{4}} peopleCn           {{9}} bookingId (URL)
//   {{5}} storeNameEn
// Buttons:
//   更改預約 → https://catstearoom.dev/booking/mybooking.html?id={{9}}
//   取消預約 → https://catstearoom.dev/booking/mybooking.html?id={{9}}&action=cancel
const BOOKING_CONFIRM_TEMPLATES = {
    'store_1': 'HX79774f70284d6e8e2a987556e7f64ae2',
    'store_2': 'HX79774f70284d6e8e2a987556e7f64ae2',
    'store_3': 'HX79774f70284d6e8e2a987556e7f64ae2',
    'store_4': 'HX79774f70284d6e8e2a987556e7f64ae2'
};

const STORE_NAMES_EN = {
    'store_1': 'Tsuen Wan Store',
    'store_2': 'Tsim Sha Tsui Store',
    'store_3': 'Mong Kok Store',
    'store_4': 'Causeway Bay Store'
};

const MONTHS_CN = ['一','二','三','四','五','六','七','八','九','十','十一','十二'];
const DAYS_CN = ['日','一','二','三','四','五','六'];
const MONTHS_EN = ['January','February','March','April','May','June','July','August','September','October','November','December'];

/**
 * Format YYYY-MM-DD → 2026年7月21日 (二)
 */
function formatDateCn(dateStr) {
    if (!dateStr) return '-';
    const parts = dateStr.split('-');
    if (parts.length !== 3) return dateStr;
    const d = new Date(parseInt(parts[0]), parseInt(parts[1])-1, parseInt(parts[2]));
    return parseInt(parts[0]) + '年' + parseInt(parts[1]) + '月' + parseInt(parts[2]) + '日 (' + DAYS_CN[d.getDay()] + ')';
}

/**
 * Format YYYY-MM-DD → 21 July 2026
 */
function formatDateEn(dateStr) {
    if (!dateStr) return '-';
    const parts = dateStr.split('-');
    if (parts.length !== 3) return dateStr;
    return parseInt(parts[2]) + ' ' + MONTHS_EN[parseInt(parts[1])-1] + ' ' + parts[0];
}

/**
 * 發送 WhatsApp 預約確認訊息（用 Content Template）
 */
async function sendBookingConfirmation(phone, storeId, storeName, bookingDate, bookingTime, adults, children, bookingId, lang) {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const from = process.env.TWILIO_WHATSAPP_FROM;

    if (!accountSid || !from) {
        console.log('Twilio 未配置，跳過預約確認 WhatsApp 發送');
        return false;
    }

    // 支援不同國碼：phone 可能為 +852XXXXXXX 或 +886XXXXXXX 等格式
    const rawPhone = phone.replace(/[^0-9]/g, '');
    // 判斷國碼：如果 phone 有 + 前綴，提取國碼（只 capture 1-3 位數）
    const countryMatch = phone.match(/^\+(\d{1,3})/);
    const countryCode = countryMatch ? countryMatch[1] : '852';
    const to = `whatsapp:+${countryCode}${rawPhone.replace(/^852/, '')}`;
    const fromWhatsApp = `whatsapp:${from}`;
    const templateSid = BOOKING_CONFIRM_TEMPLATES[storeId];

    if (!templateSid) {
        console.log(`找不到分店 ${storeId} 的預約確認 WhatsApp template`);
        return false;
    }

    try {
        const totalPeople = (adults || 0) + (children || 0);

        // 繁中格式
        const peopleCn = children > 0
            ? totalPeople + ' 人（大人 ' + adults + ' · 小朋友 ' + children + '）'
            : totalPeople + ' 人';

        // 英文格式
        const storeNameEn = STORE_NAMES_EN[storeId] || storeName;
        const dateEn = formatDateEn(bookingDate);
        const dateCn = formatDateCn(bookingDate);
        let peopleEn = totalPeople + ' pax';
        if (children > 0) {
            peopleEn += ' (' + (adults||0) + ' Adult' + (adults!==1?'s':'') + ' · ' + children + ' Child' + (children>1?'ren':'') + ')';
        }

        const client = twilio(accountSid, authToken);
        await client.messages.create({
            from: fromWhatsApp,
            to: to,
            contentSid: templateSid,
            contentVariables: JSON.stringify({
                "1": storeName,
                "2": dateCn,
                "3": bookingTime,
                "4": peopleCn,
                "5": storeNameEn,
                "6": dateEn,
                "7": bookingTime,
                "8": peopleEn,
                "9": bookingId + '&lang=' + (lang || 'zh-TW')
            })
        });
        console.log(`預約確認 WhatsApp 已發送至 ${to} (template: ${templateSid})`);
        return true;
    } catch (error) {
        console.error('預約確認 WhatsApp 發送失敗:', error.message);
        return false;
    }
}

/**
 * 發送 WhatsApp 訊息通知客人有位（用 Content Template）
 */
async function sendWhatsApp(phone, storeId, storeName, lang, waitinglistId) {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const from = process.env.TWILIO_WHATSAPP_FROM;

    if (!accountSid || !from) {
        console.log('Twilio 未配置，跳過 WhatsApp 發送');
        return false;
    }

    const rawPhone = phone.replace(/[^0-9]/g, '');
    // 支援不同國碼（只 capture 1-3 位數）
    const countryMatch = phone.match(/^\+(\d{1,3})/);
    const countryCode = countryMatch ? countryMatch[1] : '852';
    const to = `whatsapp:+${countryCode}${rawPhone.replace(/^852/, '')}`;
    const fromWhatsApp = `whatsapp:${from}`;
    const templateSid = WHATSAPP_TEMPLATES[storeId];

    if (!templateSid) {
        console.log(`找不到分店 ${storeId} 的 WhatsApp template`);
        return false;
    }

    try {
        const client = twilio(accountSid, authToken);
        const vars = { "1": (waitinglistId || '') + '&lang=' + (lang || 'zh-TW') };
        await client.messages.create({
            from: fromWhatsApp,
            to: to,
            contentSid: templateSid,
            contentVariables: JSON.stringify(vars)
        });
        console.log(`WhatsApp 已發送至 ${to} (template: ${templateSid})`);
        return true;
    } catch (error) {
        console.error('WhatsApp 發送失敗:', error.message);
        return false;
    }
}

/**
 * 打電話並播放 TwiML Bin 預錄語音
 */
async function makePhoneCall(phone, storeId, storeName, lang) {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const from = process.env.TWILIO_PHONE_FROM;

    if (!accountSid || !from) {
        console.log('Twilio 電話未配置，跳過語音通話');
        return false;
    }

    const rawPhone = phone.replace(/[^0-9]/g, '');
    // 支援不同國碼（只 capture 1-3 位數）
    const countryMatch = phone.match(/^\+(\d{1,3})/);
    const countryCode = countryMatch ? countryMatch[1] : '852';
    const to = `+${countryCode}${rawPhone.replace(/^852/, '')}`;
    const binSid = VOICE_BINS[lang] || VOICE_BINS['zh-TW'];
    const twimlUrl = `https://handler.twilio.com/twiml/${binSid}`;

    try {
        const client = twilio(accountSid, authToken);
        const call = await client.calls.create({
            from: from,
            to: to,
            url: twimlUrl
        });
        console.log(`語音通話已發出至 ${to}，Call SID: ${call.sid}`);
        return true;
    } catch (error) {
        console.error('語音通話失敗:', error.message);
        return false;
    }
}

module.exports = { sendWhatsApp, makePhoneCall, sendBookingConfirmation };
