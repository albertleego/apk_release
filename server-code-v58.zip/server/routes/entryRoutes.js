const express = require('express');
const router = express.Router();
const QRCode = require('qrcode');
const { v4: uuidv4 } = require('uuid');
const net = require('net');
const storeAwareMiddleware = require('../middleware/store-aware');
const RawPrinter = require('../printer-raw');
const {
  getAvailableTables,
  createCustomer,
  assignTableToCustomer,
  getAvailableLockers,
  assignLockerToCustomer,
  checkMemberCard,
  addOrderItem,
  getValidHourProduct
} = require('../../database/db');

// 為所有路由添加分店上下文中間件
router.use(storeAwareMiddleware.initStoreContext);

// 健康檢查端點：檢查主機連線 + 入口打印機連線
router.get('/health', async (req, res) => {
  const result = { host: 'ok', printer: 'unknown' };

  // 檢查入口打印機 (192.168.3.120:9100)
  try {
    const printerOk = await new Promise((resolve) => {
      const sock = new net.Socket();
      sock.setTimeout(3000);
      sock.on('connect', () => { sock.destroy(); resolve(true); });
      sock.on('error', () => { sock.destroy(); resolve(false); });
      sock.on('timeout', () => { sock.destroy(); resolve(false); });
      sock.connect(9100, '192.168.3.120');
    });
    result.printer = printerOk ? 'ok' : 'fail';
  } catch (e) {
    result.printer = 'fail';
  }

  res.json({ success: true, data: result });
});

// 入場處理 - 客人選擇人數
router.post('/entry', async (req, res) => {
  try {
    const { peopleCount, memberCardId, table_number } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';

    console.log('入場處理請求:', {
      peopleCount,
      memberCardId,
      table_number,
      storeId,
      storeContext: req.storeContext,
      query: req.query,
      body: req.body,
      employee: req.employee ? { id: req.employee.id, role: req.employee.role, store_id: req.employee.store_id } : null
    });

    // 檢查會員卡（如果有提供）
    let isMember = false;
    if (memberCardId) {
      const member = await checkMemberCard(memberCardId);
      if (member) {
        isMember = true;
        // 會員跳過錄音播放
        console.log('會員入場，跳過錄音播放');
      }
    }

    // 先清理已結賬但桌位未釋放的客人
    const db = require('../../database/db').db;
    db.run(
      `UPDATE tables SET is_occupied = 0, current_customer_id = NULL
       WHERE current_customer_id IN (
         SELECT id FROM customers WHERE is_checked_out = 1
       )`,
      function(cleanupErr) {
        if (cleanupErr) {
          console.error('清理已結賬客人桌位錯誤:', cleanupErr);
        } else if (this.changes > 0) {
          console.log(`清理了 ${this.changes} 個已結賬客人的桌位`);
        }
      }
    );

    // 清理已結賬但儲物柜未釋放的客人（保持customer_id以便歷史查詢）
    db.run(
      `UPDATE lockers SET is_occupied = 0, closed_at = CURRENT_TIMESTAMP
       WHERE customer_id IN (
         SELECT id FROM customers WHERE is_checked_out = 1
       )`,
      function(cleanupLockerErr) {
        if (cleanupLockerErr) {
          console.error('清理已結賬客人儲物柜錯誤:', cleanupLockerErr);
        } else if (this.changes > 0) {
          console.log(`清理了 ${this.changes} 個已結賬客人的儲物柜`);
        }
      }
    );

    // 清理孤兒桌位（current_customer_id指向不存在的客人）
    db.run(
      `UPDATE tables SET is_occupied = 0, current_customer_id = NULL
       WHERE current_customer_id IS NOT NULL
       AND current_customer_id NOT IN (SELECT id FROM customers)`,
      function(orphanCleanupErr) {
        if (orphanCleanupErr) {
          console.error('清理孤兒桌位錯誤:', orphanCleanupErr);
        } else if (this.changes > 0) {
          console.log(`清理了 ${this.changes} 個孤兒桌位`);
        }
      }
    );

    // 清理孤兒儲物柜（customer_id指向不存在的客人）
    db.run(
      `UPDATE lockers SET is_occupied = 0, customer_id = NULL, closed_at = CURRENT_TIMESTAMP
       WHERE customer_id IS NOT NULL
       AND customer_id NOT IN (SELECT id FROM customers)`,
      function(orphanLockerCleanupErr) {
        if (orphanLockerCleanupErr) {
          console.error('清理孤兒儲物柜錯誤:', orphanLockerCleanupErr);
        } else if (this.changes > 0) {
          console.log(`清理了 ${this.changes} 個孤兒儲物柜`);
        }
      }
    );

    let selectedTable = null;
    const isNoTableMode = table_number === ''; // 空字符串表示無桌號模式

    // 檢查是否手動指定了桌號（非無桌號模式）
    if (table_number && !isNoTableMode) {
      console.log('嘗試使用手動指定桌號:', table_number);

      // 查詢指定的桌位是否存在且可用
      try {
        const db = require('../../database/db').db;
        const query = `
          SELECT t.*
          FROM tables t
          WHERE t.table_number = ?
            AND t.store_id = ?
            AND t.is_occupied = 0
            AND t.capacity >= ?
        `;

        const tableRow = await new Promise((resolve, reject) => {
          db.get(query, [table_number, storeId, peopleCount], (err, row) => {
            if (err) reject(err);
            else resolve(row);
          });
        });

        if (tableRow) {
          selectedTable = tableRow;
          console.log('手動指定桌號驗證成功:', {
            table_number: selectedTable.table_number,
            capacity: selectedTable.capacity,
            table_id: selectedTable.id
          });
        } else {
          console.log('手動指定桌號無效或不可用:', table_number);
          // 返回錯誤，而不是回退到自動分配
          return res.status(400).json({
            error: '指定的桌號無效或不可用',
            debug: {
              table_number,
              storeId,
              peopleCount,
              message: '桌位可能不存在、已被佔用或容量不足'
            }
          });
        }
      } catch (error) {
        console.error('驗證手動指定桌號時發生錯誤:', error);
        return res.status(500).json({
          error: '驗證桌號時發生錯誤',
          message: error.message
        });
      }
    }

    // 處理無桌號模式
    if (isNoTableMode) {
      console.log('無桌號模式，跳過桌位分配');
      selectedTable = { table_number: '' };
    } else if (!selectedTable) {
      // 如果沒有手動指定桌號，則自動尋找合適的桌位（僅在非無桌號模式下）
      console.log('沒有手動指定桌號，使用自動分配');
      const availableTables = await getAvailableTables(peopleCount, storeId);
      console.log('可用桌位查詢結果:', {
        peopleCount,
        availableTablesCount: availableTables.length,
        availableTables: availableTables.map(t => ({ table_number: t.table_number, capacity: t.capacity }))
      });

      if (availableTables.length === 0) {
        // 調試：檢查所有桌位狀態
        db.all('SELECT table_number, capacity, is_occupied, current_customer_id FROM tables ORDER BY table_number', (err, allTables) => {
          if (err) {
            console.error('檢查所有桌位錯誤:', err);
          } else {
            console.log('所有桌位狀態:', allTables);
            // 同時檢查customers表中是否有對應的客人
            db.all('SELECT id, table_number, is_checked_out FROM customers', (err2, customers) => {
              if (err2) console.error('檢查客人錯誤:', err2);
              else console.log('所有客人狀態:', customers);
            });
          }
        });

        return res.status(400).json({
          error: '暫時沒有合適的桌位，請稍後再試',
          debug: {
            peopleCount,
            message: `需要容量至少 ${peopleCount} 的桌位，但沒有找到空閒桌位`
          }
        });
      }

      // 選擇第一個合適的桌位
      selectedTable = availableTables[0];
      console.log('自動分配桌位:', { table_number: selectedTable.table_number, capacity: selectedTable.capacity });
    } // 結束 if (!selectedTable) 區塊

    // 創建客人記錄（包含分店信息）
    const customerData = {
      table_number: selectedTable.table_number,
      people_count: peopleCount,
      is_member: isMember ? 1 : 0,
      member_card_id: memberCardId || null,
      store_id: storeId
    };

    const customer = await createCustomer(customerData);

    // 分配桌位（僅在非無桌號模式下）
    if (!isNoTableMode && selectedTable.id) {
      await assignTableToCustomer(selectedTable.id, customer.id);
      console.log('已分配桌位:', selectedTable.table_number);
    } else {
      console.log('無桌號模式，跳過桌位分配');
    }

    // 分配儲物柜（根據人數） - 檢查分店是否使用儲物柜
    const assignedLockers = [];
    // 查詢分店是否使用儲物柜
    const storeConfig = await new Promise((resolve) => {
      const db = require('../../database/db').db;
      db.get(
        `SELECT * FROM stores WHERE id = ?`,
        [storeId],
        (err, row) => {
          if (err) {
            console.error('查詢分店儲物柜配置錯誤:', err);
            resolve({ use_lockers: 1 }); // 默認使用
          } else {
            // 確保 use_lockers 字段存在，如果不存在則默認為 1
            const useLockers = row && row.use_lockers !== undefined ? row.use_lockers : 1;
            resolve({ use_lockers: useLockers });
          }
        }
      );
    });

    if (storeConfig.use_lockers === 1) {
      const lockersNeeded = peopleCount; // 每1人一個儲物柜
      console.log('分配儲物柜:', { peopleCount, lockersNeeded });
      const availableLockers = await getAvailableLockers(lockersNeeded, storeId);
      console.log('可用儲物柜查詢結果:', {
        requested: lockersNeeded,
        found: availableLockers.length,
        lockers: availableLockers.map(l => ({ locker_number: l.locker_number, is_occupied: l.is_occupied, customer_id: l.customer_id }))
      });

      for (const locker of availableLockers) {
        await assignLockerToCustomer(locker.id, customer.id);
        assignedLockers.push(locker.locker_number);
      }
      console.log('已分配儲物柜:', assignedLockers);
    } else {
      console.log('分店設置為不使用儲物柜，跳過分配');
    }

    // 自動添加首小時商品（僅在非無桌號模式下）
    if (!isNoTableMode) {
      try {
        const now = new Date();
        const firstHourProduct = await getValidHourProduct('首小時', now, storeId);
        if (firstHourProduct) {
          await addOrderItem(customer.id, firstHourProduct.id, peopleCount, firstHourProduct.price);
          console.log(`已為客人 ${customer.id} 添加 ${peopleCount} 個首小時商品: ${firstHourProduct.name}`);
        } else {
          console.warn('未找到有效的首小時商品，跳過自動添加');
        }
      } catch (error) {
        console.error('添加首小時商品時發生錯誤:', error);
        // 不阻礙入場流程，僅記錄錯誤
      }
    } else {
      console.log('無桌號模式，跳過首小時商品添加');
    }

    // 生成QR Code數據
    const qrData = {
      customer_id: customer.id,
      qr_code: customer.qr_code,
      table_number: selectedTable.table_number,
      entry_time: new Date().toISOString()
    };

    // 生成QR Code圖片
    const qrCodeImage = await QRCode.toDataURL(JSON.stringify(qrData));

    // 準備小票數據
    const receiptData = {
      table_number: selectedTable.table_number,
      qr_code: customer.qr_code,
      people_count: peopleCount,
      entry_time: new Date().toLocaleString('zh-TW'),
      lockers: assignedLockers,
      is_member: isMember
    };

    // 觸發Socket事件通知收銀系統
    const io = req.app.get('io');
    io.emit('new-customer', {
      customer_id: customer.id,
      table_number: selectedTable.table_number,
      people_count: peopleCount,
      entry_time: new Date().toISOString(),
      qr_code: customer.qr_code
    });

    // 觸發設備控制事件
    io.emit('device-control', {
      device: 'lockers',
      action: 'open',
      locker_numbers: assignedLockers
    });

    // 如果不是會員，觸發錄音播放
    if (!isMember) {
      io.emit('device-control', {
        device: 'audio',
        action: 'play',
        message: 'welcome'
      });
    }

    // 觸發打印小票
    io.emit('print-receipt', receiptData);

    // 實體打印入場小票到入口打印機 (192.168.3.120)，使用QR Code圖片格式
    printEntryReceipt(receiptData).catch(err => {
        console.error('[entry-printer] 打印失敗:', err.message);
    });

    res.json({
      success: true,
      message: '入場處理成功',
      data: {
        customer_id: customer.id,
        table_number: selectedTable.table_number,
        qr_code: customer.qr_code,
        qr_code_image: qrCodeImage,
        people_count: peopleCount,
        lockers: assignedLockers,
        receipt_data: receiptData,
        skip_audio: isMember
      }
    });

  } catch (error) {
    console.error('入場處理錯誤:', error);
    res.status(500).json({
      error: '入場處理失敗',
      message: error.message
    });
  }
});

// NFC會員卡感應
router.post('/nfc-scan', async (req, res) => {
  try {
    const { cardId } = req.body;

    if (!cardId) {
      return res.status(400).json({ error: '請提供卡片ID' });
    }

    const member = await checkMemberCard(cardId);

    if (member) {
      // 會員卡有效
      res.json({
        success: true,
        is_member: true,
        member_info: {
          name: member.name,
          balance: member.balance,
          card_id: member.card_id
        },
        message: '會員卡驗證成功'
      });
    } else {
      // 非會員卡或無效卡
      res.json({
        success: false,
        is_member: false,
        message: '非會員卡或卡片無效'
      });
    }
  } catch (error) {
    console.error('NFC掃描錯誤:', error);
    res.status(500).json({
      error: 'NFC掃描處理失敗',
      message: error.message
    });
  }
});

// 獲取當前等待客人
router.get('/waiting', async (req, res) => {
  try {
    const storeId = req.storeContext?.store_id || 'default_store';
    // 從數據庫獲取最近入場的客人（分店過濾）
    const db = require('../../database/db').db;

    db.all(
      `SELECT c.*, t.table_number as actual_table
       FROM customers c
       LEFT JOIN tables t ON c.table_number = t.table_number
       WHERE c.is_checked_out = 0 AND c.store_id = ?
       ORDER BY c.entry_time DESC
       LIMIT 20`,
      [storeId],
      (err, rows) => {
        if (err) {
          throw err;
        }
        res.json({
          success: true,
          customers: rows
        });
      }
    );
  } catch (error) {
    console.error('獲取等待客人錯誤:', error);
    res.status(500).json({
      error: '獲取等待客人失敗',
      message: error.message
    });
  }
});

// 手動觸發儲物柜開啟
router.post('/open-locker', async (req, res) => {
  try {
    const { locker_number } = req.body;

    if (!locker_number) {
      return res.status(400).json({ error: '請提供儲物柜編號' });
    }

    const io = req.app.get('io');
    io.emit('device-control', {
      device: 'locker',
      action: 'open',
      locker_number: locker_number
    });

    res.json({
      success: true,
      message: `已發送開啟儲物柜 ${locker_number} 指令`
    });
  } catch (error) {
    console.error('開啟儲物柜錯誤:', error);
    res.status(500).json({
      error: '開啟儲物柜失敗',
      message: error.message
    });
  }
});

// 手動觸發小票打印
router.post('/print-receipt', async (req, res) => {
  try {
    const { table_number, qr_code, people_count } = req.body;

    const receiptData = {
      table_number: table_number || 'TEST',
      qr_code: qr_code || 'TEST-' + Date.now(),
      people_count: people_count || 1,
      entry_time: new Date().toLocaleString('zh-TW'),
      lockers: [1, 2, 3], // 測試用
      is_member: false
    };

    const io = req.app.get('io');
    io.emit('print-receipt', receiptData);

    res.json({
      success: true,
      message: '已發送打印小票指令',
      receipt_data: receiptData
    });
  } catch (error) {
    console.error('打印小票錯誤:', error);
    res.status(500).json({
      error: '打印小票失敗',
      message: error.message
    });
  }
});

// 調試用：獲取所有桌位狀態
router.get('/debug/tables', (req, res) => {
  try {
    const db = require('../../database/db').db;
    db.all(
      `SELECT t.*, c.qr_code, c.entry_time
       FROM tables t
       LEFT JOIN customers c ON t.current_customer_id = c.id
       ORDER BY t.table_number`,
      (err, rows) => {
        if (err) {
          console.error('獲取桌位狀態錯誤:', err);
          return res.status(500).json({ error: '獲取桌位狀態失敗', message: err.message });
        }

        // 獲取所有客人狀態
        db.all(
          `SELECT id, table_number, qr_code, entry_time, is_checked_out FROM customers ORDER BY entry_time DESC`,
          (err2, customers) => {
            if (err2) console.error('獲取客人錯誤:', err2);

            // 獲取所有儲物柜狀態
            db.all(
              `SELECT locker_number, is_occupied, customer_id, opened_at, closed_at FROM lockers ORDER BY locker_number`,
              (err3, lockers) => {
                if (err3) console.error('獲取儲物柜錯誤:', err3);

                res.json({
                  success: true,
                  tables: rows,
                  customers: customers || [],
                  lockers: lockers || [],
                  summary: {
                    total_tables: rows.length,
                    occupied_tables: rows.filter(t => t.is_occupied === 1).length,
                    available_tables: rows.filter(t => t.is_occupied === 0).length,
                    total_customers: customers ? customers.length : 0,
                    active_customers: customers ? customers.filter(c => c.is_checked_out === 0).length : 0,
                    total_lockers: lockers ? lockers.length : 0,
                    occupied_lockers: lockers ? lockers.filter(l => l.is_occupied === 1).length : 0,
                    available_lockers: lockers ? lockers.filter(l => l.is_occupied === 0).length : 0
                  }
                });
              }
            );
          }
        );
      }
    );
  } catch (error) {
    console.error('調試路由錯誤:', error);
    res.status(500).json({ error: '調試路由失敗', message: error.message });
  }
});

// 調試用：重置所有桌位狀態（測試用）
router.post('/debug/reset-tables', (req, res) => {
  try {
    const db = require('../../database/db').db;

    // 重置所有桌位為空閒
    db.run(`UPDATE tables SET is_occupied = 0, current_customer_id = NULL`, function(err) {
      if (err) {
        console.error('重置桌位錯誤:', err);
        return res.status(500).json({ error: '重置桌位失敗', message: err.message });
      }

      // 重置所有儲物柜
      db.run(`UPDATE lockers SET is_occupied = 0, customer_id = NULL, closed_at = NULL`, function(err2) {
        if (err2) console.error('重置儲物柜錯誤:', err2);

        res.json({
          success: true,
          message: `已重置 ${this.changes} 個桌位`,
          changes: this.changes
        });
      });
    });
  } catch (error) {
    console.error('重置桌位錯誤:', error);
    res.status(500).json({ error: '重置桌位失敗', message: error.message });
  }
});

/**
 * 打印入場小票到入口打印機 (192.168.3.120)
 * 使用與「重新打印QR Code」相同的格式（含實際QR Code圖片）
 * 非同步 fire-and-forget，不阻礙入場流程
 */
async function printEntryReceipt(receiptData) {
    const ENTRY_PRINTER_IP = '192.168.3.120';
    const ENTRY_PRINTER_PORT = 9100;
    const RECEIPT_WIDTH = 48;

    try {
        const { table_number, entry_time, qr_code } = receiptData;

        // 計算顯示寬度（中文字元=2，英數字元=1）
        const displayWidth = (str) => [...str].reduce((w, c) => w + (c.charCodeAt(0) > 0x7f ? 2 : 1), 0);

        // 文字置中
        const center = (text, width = RECEIPT_WIDTH) => {
            const tw = displayWidth(text);
            const pad = Math.max(0, Math.floor((width - tw) / 2));
            return ' '.repeat(pad) + text + (width - tw - pad > 0 ? ' ' : '');
        };

        // 生成小票內容（與 reprint-qr 格式一致）
        let receipt = '';
        receipt += '='.repeat(RECEIPT_WIDTH) + '\n';
        receipt += `桌號: ${table_number}\n`;
        receipt += `入場時間: ${entry_time}\n`;
        receipt += '-'.repeat(RECEIPT_WIDTH) + '\n';
        receipt += '\n';
        receipt += center('二維碼用作離場結賬和購買貓零食, 請保存') + '\n';
        receipt += '\n';
        receipt += `$QR_CODE:${qr_code}$\n`;
        receipt += '-'.repeat(RECEIPT_WIDTH) + '\n';
        receipt += '='.repeat(RECEIPT_WIDTH) + '\n';

        const printer = new RawPrinter({
            ip_address: ENTRY_PRINTER_IP,
            port: ENTRY_PRINTER_PORT,
            encoding: 'GBK',
            timeout: 30000,
            printableWidth: 576
        });

        // 逐行處理，偵測 QR Code marker 並打印圖片
        const lines = receipt.split('\n');
        for (const line of lines) {
            const qrMatch = line.match(/^\$QR_CODE:(.+)\$$/);
            if (qrMatch) {
                try {
                    const pngBuffer = await QRCode.toBuffer(qrMatch[1], {
                        type: 'png',
                        width: 500,
                        margin: 1,
                        color: { dark: '#000000', light: '#ffffff' },
                        errorCorrectionLevel: 'M'
                    });
                    const base64 = pngBuffer.toString('base64');
                    printer.newLine(2);
                    await printer.printImageBase64(base64, 500);
                    printer.newLine(2);
                } catch (qrError) {
                    console.error('[entry-printer] QR Code生成失敗:', qrError.message);
                    printer.println(`[QR Error: ${qrError.message}]`);
                }
            } else {
                printer.println(line);
            }
        }

        printer.cut();
        const success = await printer.execute();
        console.log(`[entry-printer] entry receipt printed: table ${table_number}, success: ${success}`);
    } catch (error) {
        console.error('[entry-printer] 打印失敗:', error.message);
    }
}

module.exports = router;