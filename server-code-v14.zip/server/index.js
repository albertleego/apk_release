// 設置香港時區 (UTC+8)
process.env.TZ = 'Asia/Hong_Kong';

// 加載環境變量
require('dotenv').config();

// 重啟觸發：環境變量更新

// 初始化檔案 Logger（攔截 console.log/error 輸出到 logs/ 目錄）
const Logger = require('./utils/logger');
const logger = new Logger({
  storeName: process.env.STORE_NAME || process.env.STORE_ID || 'unknown'
});

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const os = require('os');
const { createServer } = require('http');
const { Server } = require('socket.io');

// 全域異常處理
process.on('uncaughtException', (error) => {
    console.error('=== 未捕獲的異常 ===');
    console.error('錯誤:', error);
    console.error('堆疊:', error.stack);
    console.error('發生時間:', new Date().toISOString());
    console.error('=== 未捕獲的異常結束 ===');
    // 不退出進程，讓錯誤處理中間件處理
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('=== 未處理的 Promise 拒絕 ===');
    console.error('原因:', reason);
    console.error('Promise:', promise);
    console.error('發生時間:', new Date().toISOString());
    console.error('=== 未處理的 Promise 拒絕結束 ===');
});

// 導入路由
const entryRoutes = require('./routes/entryRoutes');
const cashierRoutes = require('./routes/cashierRoutes');
const vendingRoutes = require('./routes/vendingRoutes');
const exitRoutes = require('./routes/exitRoutes');
const lockRoutes = require('./routes/lockRoutes');
const lockerRoutes = require('./routes/lockerRoutes');
const receiptRoutes = require('./routes/receiptRoutes');
const authRoutes = require('./routes/authRoutes');
const employeeRoutes = require('./routes/employeeRoutes');
const productRoutes = require('./routes/productRoutes');
const inventoryRoutes = require('./routes/inventoryRoutes');
const auditRoutes = require('./routes/auditRoutes');
const reportRoutes = require('./routes/reportRoutes');
const holidaysRoutes = require('./routes/holidaysRoutes');
const storeRoutes = require('./routes/storeRoutes');

// 導入數據庫
const db = require('../database/db');

// 導入結賬單據上傳服務
const BillUploadService = require('../bill-upload-service');

// 初始化應用
const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// 中間件
app.use(cors({
    origin: function(origin, callback) {
        // 允許的來源列表
        const allowedOrigins = [
            // 公網ECS服務器
            'http://47.239.121.13',

            // 本地開發環境（支持多端口）
            /^http:\/\/(localhost|127\.0\.0\.1)(?::\d+)?$/,
            'http://localhost:3000',
            'http://127.0.0.1:3000',
            'http://localhost:3001',
            'http://127.0.0.1:3001',
            'http://localhost:3002',
            'http://127.0.0.1:3002',

            // 局域網IP段（動態匹配，支持任意端口）
            /^http:\/\/192\.168\.\d+\.\d+(?::\d+)?$/,    // 192.168.x.x
            /^http:\/\/10\.\d+\.\d+\.\d+(?::\d+)?$/,     // 10.x.x.x
            /^http:\/\/172\.(1[6-9]|2[0-9]|3[0-1])\.\d+\.\d+(?::\d+)?$/, // 172.16.x.x - 172.31.x.x

            // 允許不帶端口的本地訪問（如直接IP訪問）
            /^http:\/\/(localhost|127\.0\.0\.1)$/,
            /^http:\/\/192\.168\.\d+\.\d+$/,
            /^http:\/\/10\.\d+\.\d+\.\d+$/,
            /^http:\/\/172\.(1[6-9]|2[0-9]|3[0-1])\.\d+\.\d+$/
        ];

        // 如果沒有origin（例如：直接服務器訪問、Postman等工具）
        if (!origin) {
            return callback(null, true);
        }

        // 檢查origin是否在允許列表中
        const isAllowed = allowedOrigins.some(pattern => {
            if (typeof pattern === 'string') {
                return pattern === origin;
            } else if (pattern instanceof RegExp) {
                return pattern.test(origin);
            }
            return false;
        });

        if (isAllowed) {
            callback(null, true);
        } else {
            console.warn('CORS阻止的來源:', origin);
            callback(new Error('CORS不允許的來源'));
        }
    },
    credentials: true,
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
    exposedHeaders: ['Set-Cookie']
}));
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.static(path.join(__dirname, '../public')));

// 客戶端靜態文件服務
app.use('/entry-machine', express.static(path.join(__dirname, '../client/entry-machine')));
app.use('/cashier', express.static(path.join(__dirname, '../client/cashier')));
app.use('/vending-machine', express.static(path.join(__dirname, '../client/vending-machine')));
app.use('/exit-machine', express.static(path.join(__dirname, '../client/exit-machine')));

// Socket.IO 連接處理
io.on('connection', (socket) => {
  console.log('客戶端連接:', socket.id);

  // 處理設備狀態更新
  socket.on('device-status', (data) => {
    // 廣播設備狀態給所有客戶端
    socket.broadcast.emit('device-update', data);
  });

  // 處理新客人通知
  socket.on('new-customer', (customerData) => {
    // 廣播新客人信息給收銀系統
    socket.broadcast.emit('customer-added', customerData);
  });

  // 處理結賬通知
  socket.on('checkout-complete', (tableData) => {
    // 廣結結賬信息給所有相關設備
    socket.broadcast.emit('table-checked-out', tableData);
  });

  socket.on('disconnect', () => {
    console.log('客戶端斷開:', socket.id);
  });
});

// 將io對象附加到app，方便路由使用
app.set('io', io);

// 路由
app.use('/api/entry', entryRoutes);
app.use('/api/cashier', cashierRoutes);
app.use('/api/vending', vendingRoutes);
app.use('/api/exit', exitRoutes);
app.use('/api/lock', lockRoutes);
app.use('/api/locker', lockerRoutes);
app.use('/api/receipt', receiptRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/employees', employeeRoutes);
app.use('/api/products', productRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/audit-logs', auditRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/holidays', holidaysRoutes);
app.use('/api/stores', storeRoutes);
app.use('/api/sync', require('./routes/syncRoutes'));
app.use('/api', require('./routes/reverseCheckoutRoutes'));

// 客戶端界面路由
app.get('/entry-machine', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/entry-machine/index.html'));
});

app.get('/cashier', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/cashier/index.html'));
});

app.get('/vending-machine', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/vending-machine/index.html'));
});

app.get('/exit-machine', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/exit-machine/index.html'));
});

// 主頁面
app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="zh-TW">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>自動咖啡館系統 - 控制面板</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        h1 { color: #333; }
        .dashboard { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-top: 30px; }
        .card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .card h2 { margin-top: 0; color: #444; }
        .card a { display: inline-block; margin-top: 10px; padding: 10px 15px; background: #4CAF50; color: white; text-decoration: none; border-radius: 5px; }
        .card a:hover { background: #45a049; }
      </style>
    </head>
    <body>
      <h1>自動咖啡館系統 - 控制面板</h1>
      <div class="dashboard">
        <div class="card">
          <h2>入場機器</h2>
          <p>客人入場處理界面</p>
          <a href="/entry-machine" target="_blank">打開入場機器</a>
        </div>
        <div class="card">
          <h2>收銀系統</h2>
          <p>員工收銀管理界面</p>
          <a href="/cashier" target="_blank">打開收銀系統</a>
        </div>
        <div class="card">
          <h2>商品售賣機</h2>
          <p>客人購買商品界面</p>
          <a href="/vending-machine" target="_blank">打開售賣機</a>
        </div>
        <div class="card">
          <h2>離場機器</h2>
          <p>客人結賬離場界面</p>
          <a href="/exit-machine" target="_blank">打開離場機器</a>
        </div>
      </div>
    </body>
    </html>
  `);
});

// 健康檢查端點
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage()
  });
});

// 錯誤處理中間件
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: '伺服器錯誤', message: err.message });
});

// 第二小時自動收費檢查
function startSecondHourScheduler() {
  // 每5分鐘檢查一次
  setInterval(async () => {
    try {
      const now = new Date();

      // 查詢所有未結賬的客人
      const customers = await new Promise((resolve, reject) => {
        db.db.all(
          `SELECT c.id, c.people_count, c.entry_time, c.store_id
           FROM customers c
           WHERE c.is_checked_out = 0`,
          (err, rows) => {
            if (err) reject(err);
            else resolve(rows);
          }
        );
      });

      for (const customer of customers) {
        try {
          // 計算在場時間（分鐘）
          const entryTime = new Date(customer.entry_time);
          const timeInMinutes = Math.floor((now.getTime() - entryTime.getTime()) / (1000 * 60));

          // 計算應有的次小時商品數量（按時間段累計）
          // 規則：69分鐘內不收次小時，70分鐘起每60分鐘收一次次小時
          let requiredSecondHourCount = 0;
          if (timeInMinutes >= 70) {
            // 公式：floor((總分鐘數 - 70) / 60) + 1
            requiredSecondHourCount = Math.floor((timeInMinutes - 70) / 60) + 1;
          }

          // 檢查是否已經有全日通商品，如果有則不添加次小時商品
          const hasDayPass = await new Promise((resolve, reject) => {
            db.db.get(
              `SELECT 1 FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.customer_id = ? AND p.name LIKE '%全日通%'`,
              [customer.id],
              (err, row) => {
                if (err) reject(err);
                else resolve(!!row);
              }
            );
          });

          if (hasDayPass) {
            console.log(`客人 ${customer.id} 已有全日通商品，跳過次小時商品處理`);
            // 移除已存在的首小時和次小時商品
            try {
                const removalResult = await db.removeHourProducts(customer.id);
                if (removalResult.removedCount > 0) {
                    console.log(`已為客人 ${customer.id} 移除 ${removalResult.removedCount} 個時段商品，總金額 ${removalResult.totalAmount}`);
                }
            } catch (error) {
                console.error(`移除客人 ${customer.id} 的時段商品時發生錯誤:`, error);
            }
            continue;
          }

          if (requiredSecondHourCount > 0) {
            // 需要次小時商品，進行處理

            // 查詢現有的次小時商品數量
            const existingSecondHourCount = await new Promise((resolve, reject) => {
              db.db.get(
                `SELECT COUNT(*) as count
                 FROM order_items oi
                 JOIN products p ON oi.product_id = p.id
                 WHERE oi.customer_id = ?
                 AND p.name LIKE '%次小時%'`,
                [customer.id],
                (err, row) => {
                  if (err) reject(err);
                  else resolve(row ? row.count : 0);
                }
              );
            });

            // 計算需要添加的次小時商品數量
            const countToAdd = requiredSecondHourCount - existingSecondHourCount;
            if (countToAdd > 0) {
              // 需要添加次小時商品

              // 獲取當前有效的次小時商品
              const secondHourProduct = await db.getValidHourProduct('次小時', now, customer.store_id);
              if (secondHourProduct) {
                // 添加缺失的次小時商品
                await db.addOrderItem(customer.id, secondHourProduct.id, customer.people_count * countToAdd, secondHourProduct.price);
                console.log(`已為客人 ${customer.id} 添加 ${customer.people_count * countToAdd} 個次小時商品 (${countToAdd}小時): ${secondHourProduct.name}`);
              }
            }

            // 檢查是否需要轉換為全日通
            try {
              // 檢查是否已經有全日通商品
              const hasDayPass = await new Promise((resolve, reject) => {
                db.db.get(
                  `SELECT 1 FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.customer_id = ? AND p.name LIKE '%全日通%'`,
                  [customer.id],
                  (err, row) => {
                    if (err) reject(err);
                    else resolve(!!row);
                  }
                );
              });

              if (!hasDayPass) {
                // 計算人均首小時+次小時價格
                const hourProductsPrice = await db.getHourProductsTotalPrice(customer.id);
                const perPersonPrice = hourProductsPrice.perPersonPrice;

                // 獲取當前有效的全日通商品
                const dayPassProduct = await db.getValidDayPassProduct(now, customer.store_id);
                if (dayPassProduct && perPersonPrice > dayPassProduct.price) {
                  // 移除所有首小時和次小時商品
                  const removalResult = await db.removeHourProducts(customer.id);
                  console.log(`已為客人 ${customer.id} 移除 ${removalResult.removedCount} 個時段商品，總金額 ${removalResult.totalAmount}`);

                  // 添加全日通商品
                  await db.addOrderItem(customer.id, dayPassProduct.id, customer.people_count, dayPassProduct.price);
                  console.log(`已為客人 ${customer.id} 添加全日通商品: ${dayPassProduct.name} x ${customer.people_count}`);
                }
              }
            } catch (error) {
              console.error(`為客人 ${customer.id} 檢查全日通時發生錯誤:`, error);
            }
          }
        } catch (error) {
          console.error(`為客人 ${customer.id} 處理次小時商品時發生錯誤:`, error);
        }
      }
    } catch (error) {
      console.error('第二小時檢查任務錯誤:', error);
    }
  }, 5 * 60 * 1000); // 5分鐘
}

// 獲取本機IP地址
function getLocalIpAddresses() {
    const interfaces = os.networkInterfaces();
    const addresses = [];

    for (const interfaceName in interfaces) {
        for (const iface of interfaces[interfaceName]) {
            // 跳過IPv6和內部地址
            if (iface.family === 'IPv4' && !iface.internal) {
                addresses.push({
                    address: iface.address,
                    interface: interfaceName,
                    mac: iface.mac
                });
            }
        }
    }

    return addresses;
}

// 啟動服務器
const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0'; // 監聽所有網絡接口

httpServer.listen({ port: PORT, host: HOST, reuseAddress: true }, () => {
    const localIpAddresses = getLocalIpAddresses();

    console.log('='.repeat(60));
    console.log(`自動咖啡館系統服務器已啟動`);
    console.log('='.repeat(60));

    console.log(`\n📡 服務器監聽: ${HOST}:${PORT}`);
    console.log(`🏠 本地訪問: http://localhost:${PORT}`);

    if (localIpAddresses.length > 0) {
        console.log('\n🌐 局域網訪問地址:');
        localIpAddresses.forEach((ipInfo, index) => {
            console.log(`   ${index + 1}. http://${ipInfo.address}:${PORT} (${ipInfo.interface})`);
        });
    } else {
        console.log('\n⚠️  未檢測到局域網IP地址，請檢查網絡連接');
    }

    console.log('\n🔗 系統界面:');
    console.log(`   • 控制面板: http://localhost:${PORT}`);
    console.log(`   • 入場機器: http://localhost:${PORT}/entry-machine`);
    console.log(`   • 收銀系統: http://localhost:${PORT}/cashier`);
    console.log(`   • 商品售賣機: http://localhost:${PORT}/vending-machine`);
    console.log(`   • 離場機器: http://localhost:${PORT}/exit-machine`);

    // 顯示局域網訪問URL（使用第一個檢測到的IP）
    if (localIpAddresses.length > 0) {
        const primaryIp = localIpAddresses[0].address;
        console.log(`\n🖥️  主服務器地址（供客戶端連接）: ${primaryIp}:${PORT}`);
        console.log(`   🔗 收銀系統: http://${primaryIp}:${PORT}/cashier`);
    }

    console.log('\n' + '='.repeat(60));

    startSecondHourScheduler();

    // 啟動員工名單同步排程（每天香港時間 3:00 AM 從 Google Sheet 同步）
    try {
        const employeeSheetSync = require('./utils/employeeSheetSync');
        employeeSheetSync.startEmployeeSyncSchedule();
        console.log('✅ 員工名單同步排程已啟動（每天 3:00 AM 香港時間）');
    } catch (error) {
        console.error('啟動員工名單同步排程失敗:', error);
    }

    // 啟動結賬單據自動上傳服務（僅在主機模式下）
    try {
        const hostRole = process.env.HOST_ROLE || 'master'; // master 或 client
        console.log('📋 主機角色檢查:', { HOST_ROLE: hostRole, STORE_ID: process.env.STORE_ID, ALIYUN_SERVER: process.env.ALIYUN_SERVER ? '已設置' : '未設置' });
        if (hostRole === 'master') {
            const uploadService = new BillUploadService();
            uploadService.start();
            console.log('✅ 結賬單據自動上傳服務已啟動（主機模式）');
        } else {
            console.log('⏭️  分機模式：跳過結賬單據自動上傳服務');
        }
    } catch (error) {
        console.error('❌ 啟動結賬單據上傳服務失敗:', error);
        console.log('⚠️  結賬單據上傳功能將不可用，請手動啟動 bill-upload-service.js');
    }

});

// Server self-update endpoint — called by Android app to trigger server code update.
// Uses Node.js child_process to run curl/unzip/npm inside Termux's own process,
// bypassing the com.termux.permission.RUN_COMMAND restriction entirely.
app.post('/api/trigger-update', (req, res) => {
    const { serverZipUrl, serverVersion } = req.body;
    if (!serverZipUrl || !serverVersion) {
        return res.status(400).json({ error: 'Missing required parameters' });
    }

    console.log(`[trigger-update] Starting server update to version ${serverVersion}`);

    // Acknowledge immediately, before async work
    res.json({ status: 'ok', message: `Update to version ${serverVersion} started` });

    const { exec } = require('child_process');
    const homeDir = process.env.HOME || '/data/data/com.termux/files/home';

    const updateCmd = [
        `export PATH=$PATH:/data/data/com.termux/files/usr/bin`,
        `cd "${homeDir}"`,
        `cp database/cafe.db database/cafe.db.bak 2>/dev/null`,
        `curl -sL -o update.zip '${serverZipUrl.replace(/'/g, "'\\''")}'`,
        `unzip -o update.zip -x 'node_modules/*' 'database/*.db*' 'logs/*'`,
        `rm -f update.zip`,
        `npm install --production --ignore-scripts 2>/dev/null`,
        `echo '${serverVersion}' > .server_version`
    ].join(' && ');

    exec(updateCmd, { timeout: 120000 }, (error, stdout, stderr) => {
        if (error) {
            console.error(`[trigger-update] Failed: ${error.message}`);
            return;
        }
        console.log(`[trigger-update] Completed (v${serverVersion}), restarting...`);
        // Start new server instance before exiting — orphaned child process survives
        // the parent exit, so the new server keeps running in Termux
        const restartCmd = `cd "${homeDir}" && nohup node server/index.js >/dev/null 2>&1 &`;
        exec(restartCmd, () => process.exit(0));
    });
});

module.exports = { app, io };