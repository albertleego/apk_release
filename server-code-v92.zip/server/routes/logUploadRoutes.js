/**
 * 日誌上傳 Route
 *
 * 作用：
 *   將本地 logs/ 目錄下嘅日誌檔案一個一個上傳到阿里雲，方便遠端除錯。
 *   每個檔案獨立 POST，避免單次 payload 過大。
 *   上傳成功後自動清除本地日誌，避免長期囤積。
 *
 * 觸發：
 *   收銀系統 → 主機設定 tab → 「一鍵上傳日誌」按鈕
 */

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const os = require('os');

const LOG_DIR = path.resolve(__dirname, '../..', 'logs');
const ALIYUN_SERVER = (process.env.ALIYUN_SERVER || 'http://47.239.121.13:3000').replace(/\/$/, '');
const API_KEY = process.env.ALIYUN_API_KEY || process.env.MAIN_API_KEY || '';
const PER_FILE_TIMEOUT_MS = 120000; // 每個檔案最多 120 秒（大檔案需要耐啲）
const MAX_SINGLE_FILE_MB = 200;     // 超過 200MB 嘅檔案跳過（唔正常）

// ============================================================
// POST /api/logs/upload-to-aliyun
// 逐個讀取本地日誌 → 逐個 POST 阿里雲 → 逐個清除
// ============================================================
router.post('/upload-to-aliyun', async (req, res) => {
    const startTime = Date.now();
    console.log('[log-upload] 開始上傳日誌到阿里雲...');

    try {
        // 1. 確保 logs 目錄存在
        if (!fs.existsSync(LOG_DIR)) {
            return res.json({ success: true, message: '日誌目錄不存在，沒有檔案需要上傳', files: [] });
        }

        // 2. 掃描所有 .log 檔案（按日期排序，最新嘅最後上傳）
        const logFiles = fs.readdirSync(LOG_DIR)
            .filter(f => f.endsWith('.log'))
            .filter(f => f !== 'node-debug.log') // 排除舊版殘留
            .sort();

        if (logFiles.length === 0) {
            return res.json({ success: true, message: '沒有日誌檔案需要上傳', files: [] });
        }

        // 3. 逐個檔案上傳
        const url = `${ALIYUN_SERVER}/api/logs/collect`;
        const source = process.env.STORE_NAME || process.env.STORE_ID || 'unknown';
        const hostname = os.hostname();
        const uploadedAt = new Date().toISOString();

        const results = [];
        let totalSize = 0;
        let totalUploaded = 0;
        let totalDeleted = 0;
        let totalSkipped = 0;

        for (const fileName of logFiles) {
            const filePath = path.join(LOG_DIR, fileName);
            let stat;
            try { stat = fs.statSync(filePath); } catch (_) { continue; }
            if (!stat.isFile() || stat.size === 0) continue;

            // 檢查單檔大小
            if (stat.size > MAX_SINGLE_FILE_MB * 1024 * 1024) {
                console.warn(`[log-upload] ⚠️ 跳過超大檔案 ${fileName} (${(stat.size / 1024 / 1024).toFixed(0)}MB)`);
                results.push({ name: fileName, status: 'skipped', reason: `超過 ${MAX_SINGLE_FILE_MB}MB` });
                totalSkipped++;
                continue;
            }

            // 讀取檔案內容
            let content;
            try {
                content = fs.readFileSync(filePath, 'utf-8');
            } catch (e) {
                console.warn(`[log-upload] ⚠️ 讀取 ${fileName} 失敗: ${e.message}`);
                results.push({ name: fileName, status: 'error', reason: `讀取失敗: ${e.message}` });
                continue;
            }

            // POST 去阿里雲（單個檔案）
            const payload = {
                files: [{ name: fileName, content }],
                source,
                uploadedAt,
                hostname
            };

            try {
                const controller = new AbortController();
                const timer = setTimeout(() => controller.abort(), PER_FILE_TIMEOUT_MS);

                console.log(`[log-upload] 上傳中... ${fileName} (${(stat.size / 1024).toFixed(0)}KB)`);

                const response = await fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'x-api-key': API_KEY
                    },
                    body: JSON.stringify(payload),
                    signal: controller.signal
                });
                clearTimeout(timer);

                if (!response.ok) {
                    const errBody = await response.text().catch(() => '');
                    throw new Error(`阿里雲 ${response.status}: ${errBody.slice(0, 100)}`);
                }

                await response.json();

                // ✅ 上傳成功 → 刪除本地檔案
                try {
                    fs.unlinkSync(filePath);
                    totalDeleted++;
                } catch (e) {
                    console.warn(`[log-upload] ⚠️ 刪除 ${fileName} 失敗: ${e.message}`);
                }

                totalUploaded++;
                totalSize += stat.size;
                results.push({ name: fileName, status: 'uploaded', size: stat.size });

            } catch (e) {
                console.error(`[log-upload] ❌ ${fileName} 上傳失敗: ${e.message}`);
                results.push({ name: fileName, status: 'error', reason: e.message });
            }
        }

        // 4. Report
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
        console.log(`[log-upload] ✅ 完成 (${elapsed}s): 上傳 ${totalUploaded} 個, 刪除 ${totalDeleted} 個, 跳過 ${totalSkipped} 個`);

        res.json({
            success: true,
            message: `已上傳 ${totalUploaded} 個日誌檔，本地已清除 ${totalDeleted} 個${totalSkipped > 0 ? `，${totalSkipped} 個跳過` : ''}`,
            detail: {
                total: logFiles.length,
                uploaded: totalUploaded,
                deleted: totalDeleted,
                skipped: totalSkipped,
                totalSize,
                elapsed: `${elapsed}s`,
                files: results
            }
        });

    } catch (error) {
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
        console.error(`[log-upload] ❌ 上傳失敗 (${elapsed}s):`, error.message);

        let statusCode = 500;
        let userMessage = error.message;
        if (error.name === 'AbortError') {
            statusCode = 504;
            userMessage = '連接阿里雲超時，請檢查網絡';
        } else if (error.message.includes('ECONNREFUSED') || error.message.includes('ENOTFOUND')) {
            statusCode = 502;
            userMessage = '無法連接阿里雲伺服器，請檢查網絡';
        }

        res.status(statusCode).json({ success: false, error: userMessage });
    }
});

module.exports = router;
