// 原始ESC/POS打印機模塊 (用於佳博 GP-D801等打印機)
const net = require('net');
const iconv = require('iconv-lite');
const Jimp = require('jimp');

/**
 * 原始ESC/POS打印機類
 */
class RawPrinter {
    constructor(config) {
        this.ip = config.ip_address || config.ip;
        this.port = config.port || 9100;
        this.encoding = config.encoding || 'ascii';
        this.timeout = config.timeout || 30000;
        this.buffer = Buffer.alloc(0);
        this.printableWidth = config.printableWidth || 384;
    }

    /**
     * 添加文本到緩衝區
     * @param {string} text - 要打印的文本
     * @returns {RawPrinter} this
     */
    print(text) {
        let buffer;
        const enc = this.encoding.toLowerCase();
        if (enc === 'gbk' || enc === 'gb2312' || enc === 'gb18030') {
            // 使用iconv-lite將文本轉換為GBK編碼
            buffer = iconv.encode(text + '\r\n', this.encoding);
        } else {
            // 使用Node.js內置編碼
            buffer = Buffer.from(text + '\r\n', this.encoding);
        }
        const beforeLength = this.buffer.length;
        this.buffer = Buffer.concat([this.buffer, buffer]);
        console.log(`print: "${text.substring(0, 30)}${text.length > 30 ? '...' : ''}" (${text.length} chars) -> 緩衝區 ${beforeLength} -> ${this.buffer.length} 字節 (+${buffer.length})`);
        return this;
    }

    /**
     * 添加一行文本
     * @param {string} text - 文本
     * @returns {RawPrinter} this
     */
    println(text) {
        return this.print(text);
    }

    /**
     * 居中對齊
     * @returns {RawPrinter} this
     */
    alignCenter() {
        console.log('RawPrinter.alignCenter called');
        this.buffer = Buffer.concat([this.buffer, Buffer.from([0x1B, 0x61, 0x01])]);
        return this;
    }

    /**
     * 左對齊
     * @returns {RawPrinter} this
     */
    alignLeft() {
        const beforeLength = this.buffer.length;
        this.buffer = Buffer.concat([this.buffer, Buffer.from([0x1B, 0x61, 0x00])]);
        console.log(`alignLeft: 緩衝區 ${beforeLength} -> ${this.buffer.length} 字節 (+${this.buffer.length - beforeLength})`);
        return this;
    }

    /**
     * 右對齊
     * @returns {RawPrinter} this
     */
    alignRight() {
        this.buffer = Buffer.concat([this.buffer, Buffer.from([0x1B, 0x61, 0x02])]);
        return this;
    }

    /**
     * 設置絕對打印位置（從左邊界算起）
     * @param {number} dots - 點數距離（0-65535）
     * @returns {RawPrinter} this
     */
    setAbsolutePosition(dots) {
        const lowByte = dots & 0xFF;
        const highByte = (dots >> 8) & 0xFF;
        console.log(`setAbsolutePosition: dots=${dots} (${dots} points), lowByte=0x${lowByte.toString(16).padStart(2, '0')}, highByte=0x${highByte.toString(16).padStart(2, '0')}, command=ESC $ (0x1B 0x24 ${lowByte.toString(16).padStart(2, '0')} ${highByte.toString(16).padStart(2, '0')})`);
        console.log(`  Printable width: ${this.printableWidth} points, requested position: ${dots} points`);
        this.buffer = Buffer.concat([this.buffer, Buffer.from([0x1B, 0x24, lowByte, highByte])]);
        return this;
    }

    /**
     * 設置字體大小
     * @param {number} width - 寬度倍數 (1-8)
     * @param {number} height - 高度倍數 (1-8)
     * @returns {RawPrinter} this
     */
    setSize(width = 1, height = 1) {
        if (width < 1 || width > 8 || height < 1 || height > 8) {
            console.warn(`字體大小參數無效: width=${width}, height=${height}`);
            return this;
        }
        const size = (width - 1) | ((height - 1) << 4);
        this.buffer = Buffer.concat([this.buffer, Buffer.from([0x1D, 0x21, size])]);
        return this;
    }

    /**
     * 開啟強調模式（加粗）
     * @returns {RawPrinter} this
     */
    boldOn() {
        this.buffer = Buffer.concat([this.buffer, Buffer.from([0x1B, 0x45, 0x01])]);
        return this;
    }

    /**
     * 關閉強調模式
     * @returns {RawPrinter} this
     */
    boldOff() {
        this.buffer = Buffer.concat([this.buffer, Buffer.from([0x1B, 0x45, 0x00])]);
        return this;
    }

    /**
     * 添加換行
     * @param {number} count - 換行數量
     * @returns {RawPrinter} this
     */
    newLine(count = 1) {
        const beforeLength = this.buffer.length;
        for (let i = 0; i < count; i++) {
            this.buffer = Buffer.concat([this.buffer, Buffer.from('\r\n', 'ascii')]);
        }
        console.log(`newLine(${count}): 緩衝區 ${beforeLength} -> ${this.buffer.length} 字節 (+${this.buffer.length - beforeLength})`);
        return this;
    }

    /**
     * 切紙
     * @param {number} mode - 0=全切, 1=部分切
     * @returns {RawPrinter} this
     */
    cut(mode = 0) {
        if (mode === 0) {
            // 全切紙 GS V 0
            this.buffer = Buffer.concat([this.buffer, Buffer.from([0x1D, 0x56, 0x00])]);
        } else {
            // 部分切紙 GS V 1
            this.buffer = Buffer.concat([this.buffer, Buffer.from([0x1D, 0x56, 0x01])]);
        }
        return this;
    }

    /**
     * 打印Base64圖片
     * @param {string} base64Data - Base64編碼的圖片數據（支持PNG、JPEG等）
     * @param {number} maxWidth - 最大寬度（像素），默認為48像素
     * @returns {Promise<RawPrinter>} this
     */
    async printImageBase64(base64Data, maxWidth = 48) {
        try {
            console.log('開始處理LOGO圖片...');
            console.log('maxWidth:', maxWidth, 'printableWidth:', this.printableWidth);
            // 確保maxWidth不超過可打印寬度
            const effectiveMaxWidth = Math.min(maxWidth, this.printableWidth);
            if (maxWidth > this.printableWidth) {
                console.log(`警告: maxWidth ${maxWidth} 超過可打印寬度 ${this.printableWidth}, 調整為 ${effectiveMaxWidth}`);
            }
            // 移除Base64前綴（如果存在）
            const base64Str = base64Data.replace(/^data:image\/\w+;base64,/, '');
            console.log(`Base64數據長度: ${base64Str.length} 字符`);

            // 檢查Jimp對象
            console.log('Jimp對象類型:', typeof Jimp);
            console.log('Jimp對象鍵:', Object.keys(Jimp).slice(0, 10));

            // 讀取圖片 - 嘗試不同的調用方式
            let image;
            if (Jimp.read && typeof Jimp.read === 'function') {
                console.log('使用 Jimp.read');
                image = await Jimp.read(Buffer.from(base64Str, 'base64'));
            } else if (Jimp.default && Jimp.default.read) {
                console.log('使用 Jimp.default.read');
                image = await Jimp.default.read(Buffer.from(base64Str, 'base64'));
            } else if (Jimp.Jimp && Jimp.Jimp.read) {
                console.log('使用 Jimp.Jimp.read');
                image = await Jimp.Jimp.read(Buffer.from(base64Str, 'base64'));
            } else {
                console.log('Jimp對象:', Jimp);
                throw new Error('無法找到Jimp.read方法');
            }
            console.log(`圖片原始尺寸: ${image.bitmap.width}x${image.bitmap.height}`);

            // 檢查可用的調整大小選項
            console.log('Jimp.Jimp.AUTO:', Jimp.Jimp ? Jimp.Jimp.AUTO : '未定義');
            console.log('Jimp.ResizeStrategy:', Jimp.ResizeStrategy ? Object.keys(Jimp.ResizeStrategy) : '未定義');

            // 調整大小，保持寬高比
            // 手動計算高度以保持寬高比
            const originalWidth = image.bitmap.width;
            const originalHeight = image.bitmap.height;
            const newHeight = Math.round(originalHeight * effectiveMaxWidth / originalWidth);
            console.log(`原始尺寸: ${originalWidth}x${originalHeight}, 調整後: ${effectiveMaxWidth}x${newHeight}`);

            // 使用明確的高度進行調整大小
            // 嘗試不同的調用方式
            try {
                // 方式1: 新對象參數格式 (Jimp 1.6.1)
                image.resize({ w: effectiveMaxWidth, h: newHeight });
                console.log('調整大小成功（使用 {w, h} 對象參數）');
            } catch (resizeError1) {
                console.log('{w, h} 對象參數失敗，嘗試帶模式:', resizeError1.message);
                try {
                    // 方式2: 帶模式參數
                    const mode = Jimp.ResizeStrategy ? Jimp.ResizeStrategy.BILINEAR : undefined;
                    image.resize({ w: effectiveMaxWidth, h: newHeight, mode: mode });
                    console.log('調整大小成功（帶模式參數）');
                } catch (resizeError2) {
                    console.log('帶模式參數失敗，嘗試舊格式:', resizeError2.message);
                    try {
                        // 方式3: 舊對象參數格式 (兼容舊版本)
                        image.resize({ width: effectiveMaxWidth, height: newHeight });
                        console.log('調整大小成功（使用舊 {width, height} 格式）');
                    } catch (resizeError3) {
                        console.log('所有對象參數失敗，嘗試傳統參數:', resizeError3.message);
                        try {
                            // 方式4: 傳統參數 (非常舊版本)
                            image.resize(effectiveMaxWidth, newHeight);
                            console.log('調整大小成功（使用傳統參數）');
                        } catch (resizeError4) {
                            console.log('所有調整大小方法都失敗，使用原始尺寸:', resizeError4.message);
                        }
                    }
                }
            }

            // 轉換為單色（黑白）
            image.greyscale();
            image.contrast(1); // 增強對比度
            // 獲取像素數據
            const width = image.bitmap.width;
            const height = image.bitmap.height;

            console.log(`圖片調整後尺寸: ${width}x${height}像素, 最大寬度: ${maxWidth}`);

            // 計算居中位置（支援外部alignCenter和內部絕對定位）
            const leftMargin = Math.max(0, Math.floor((this.printableWidth - width) / 2));
            console.log(`可打印寬度: ${this.printableWidth}, 圖片寬度: ${width}, 左邊距: ${leftMargin}`);
            this.setAbsolutePosition(leftMargin);

            // ESC/POS點陣圖命令：GS v 0
            // 計算寬度和高度字節
            const widthBytes = Math.ceil(width / 8);
            const totalBytes = widthBytes * height;

            console.log(`寬度字節數: ${widthBytes}, 總數據字節數: ${totalBytes}`);

            // 創建數據緩衝區
            const dataBuffer = Buffer.alloc(totalBytes);
            dataBuffer.fill(0);

            // 將像素轉換為點陣圖數據（1位像素，0=白色/不打印，1=黑色/打印）
            let blackPixels = 0;
            for (let y = 0; y < height; y++) {
                for (let x = 0; x < width; x++) {
                    const pixel = Jimp.intToRGBA(image.getPixelColor(x, y));
                    // 簡單閾值：如果亮度低於128，則視為黑色
                    const brightness = (pixel.r + pixel.g + pixel.b) / 3;
                    if (brightness < 128) {
                        blackPixels++;
                        const byteIndex = Math.floor(x / 8);
                        const bitIndex = 7 - (x % 8); // ESC/POS使用最高位優先
                        const bufferIndex = y * widthBytes + byteIndex;
                        dataBuffer[bufferIndex] |= (1 << bitIndex);
                    }
                }
            }

            console.log(`黑色像素數量: ${blackPixels}, 總像素: ${width * height}`);

            // 將GS v 0分拆為多個8-row chunk，每chunk獨立定位，解決GP-D801僅首行置中的問題
            const chunkSize = 8;
            const chunks = Math.ceil(height / chunkSize);
            let totalCmdBytes = 0;
            for (let chunk = 0; chunk < chunks; chunk++) {
                const chunkStart = chunk * chunkSize;
                const chunkHeight = Math.min(chunkSize, height - chunkStart);
                this.setAbsolutePosition(leftMargin);

                // 提取該chunk的點陣數據（保持橫向row格式，無需轉置）
                const chunkData = Buffer.alloc(widthBytes * chunkHeight);
                for (let r = 0; r < chunkHeight; r++) {
                    const srcStart = (chunkStart + r) * widthBytes;
                    dataBuffer.copy(chunkData, r * widthBytes, srcStart, srcStart + widthBytes);
                }

                // GS v 0 m=0（正常密度）
                const chunkCmd = Buffer.from([
                    0x1D, 0x76, 0x30, // GS v 0
                    0x00, // m=0（正常密度，203 DPI）
                    widthBytes & 0xFF, // xL
                    (widthBytes >> 8) & 0xFF, // xH
                    chunkHeight & 0xFF, // yL
                    (chunkHeight >> 8) & 0xFF // yH
                ]);

                this.buffer = Buffer.concat([this.buffer, chunkCmd, chunkData]);
                totalCmdBytes += chunkCmd.length + chunkData.length;
            }

            this.setAbsolutePosition(0);

            console.log(`圖片打印命令已添加: ${width}x${height}像素, ${chunks} chunks × GS v 0, 總命令字節: ${totalCmdBytes}`);
            return this;
        } catch (error) {
            console.error('處理圖片失敗:', error.message);
            console.error(error.stack);
            // 失敗時不影響後續打印
            return this;
        }
    }

    /**
     * 打印QR Code二維碼（ESC/POS命令）
     * @param {string} data - QR Code內容
     * @param {number} moduleSize - 模塊大小（點數），默認6
     * @param {string} errorCorrection - 糾錯級別 L/M/Q/H，默認M
     * @returns {RawPrinter} this
     */
    printQRCode(data, moduleSize = 6, errorCorrection = 'M') {
        const text = String(data);
        const ecMap = { L: 48, M: 49, Q: 50, H: 51 };
        const ec = ecMap[errorCorrection] || 49;

        // 將數據轉換為GBK緩衝區計算實際長度
        const dataBuf = iconv.encode(text, this.encoding);
        const dataLen = dataBuf.length;

        // 1. 設置QR Code模型為Model 2
        this.buffer = Buffer.concat([this.buffer, Buffer.from([
            0x1D, 0x28, 0x6B, 0x04, 0x00, 0x31, 0x41, 0x32, 0x00
        ])]);

        // 2. 設置模塊大小
        this.buffer = Buffer.concat([this.buffer, Buffer.from([
            0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x43, moduleSize
        ])]);

        // 3. 設置糾錯級別
        this.buffer = Buffer.concat([this.buffer, Buffer.from([
            0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x45, ec
        ])]);

        // 4. 存儲QR Code數據（pL = (dataLen + 3) & 0xFF, pH = (dataLen + 3) >> 8 & 0xFF）
        const pL = (dataLen + 3) & 0xFF;
        const pH = ((dataLen + 3) >> 8) & 0xFF;
        this.buffer = Buffer.concat([
            this.buffer,
            Buffer.from([0x1D, 0x28, 0x6B, pL, pH, 0x31, 0x50, 0x30]),
            dataBuf
        ]);

        // 5. 打印QR Code
        this.buffer = Buffer.concat([this.buffer, Buffer.from([
            0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x51, 0x30
        ])]);

        // 打印後換行
        this.buffer = Buffer.concat([this.buffer, Buffer.from('\r\n', 'ascii')]);

        return this;
    }

    /**
     * 清空緩衝區
     * @returns {RawPrinter} this
     */
    clear() {
        console.log(`clear() called: 緩衝區 ${this.buffer.length} 字節 -> 0 字節`);
        this.buffer = Buffer.alloc(0);
        return this;
    }

    /**
     * 執行打印（發送到打印機）
     * @returns {Promise<boolean>} 成功返回true
     */
    async execute() {
        console.log(`execute() called: buffer長度=${this.buffer.length}, ip=${this.ip}:${this.port}`);
        if (this.buffer.length === 0) {
            console.warn('打印緩衝區為空，跳過打印');
            return true;
        }

        return new Promise((resolve, reject) => {
            const client = new net.Socket();
            client.setTimeout(this.timeout);

            client.on('connect', () => {
                console.log(`原始打印連接成功: ${this.ip}:${this.port}`);

                // 發送初始化命令 ESC @
                const initCmd = Buffer.from([0x1B, 0x40]);
                client.write(initCmd);

                // 設置字符編碼為GBK (ESC t 17)
                // 0x1B = ESC, 0x74 = 't', 0x11 = 17 (GBK)
                const charsetCmd = Buffer.from([0x1B, 0x74, 0x11]);
                client.write(charsetCmd);

                // 啟用中文模式 (FS &)
                // 0x1C = FS, 0x26 = '&'
                const chineseModeCmd = Buffer.from([0x1C, 0x26]);
                client.write(chineseModeCmd);

                // 調試：打印緩衝區內容
                console.log(`執行打印: buffer長度=${this.buffer.length}字節`);
                if (this.buffer.length > 0) {
                    console.log(`緩衝區前100字節十六進制: ${this.buffer.slice(0, 100).toString('hex')}`);
                } else {
                    console.warn('警告: 打印緩衝區為空，沒有數據可發送');
                }

                // 發送緩衝區數據
                client.write(this.buffer, (err) => {
                    if (err) {
                        client.destroy();
                        reject(new Error(`發送數據失敗: ${err.message}`));
                    } else {
                        console.log(`發送 ${this.buffer.length} 字節到打印機`);

                        // 等待一點時間確保數據發送完成
                        setTimeout(() => {
                            client.destroy();
                            resolve(true);
                        }, 500);
                    }
                });
            });

            client.on('error', (err) => {
                reject(new Error(`打印機連接錯誤: ${err.message}`));
            });

            client.on('timeout', () => {
                client.destroy();
                reject(new Error('打印機連接超時'));
            });

            client.on('close', () => {
                // 連接關閉，清理緩衝區
                this.clear();
            });

            // 連接打印機
            client.connect(this.port, this.ip);
        });
    }

    /**
     * 直接打印文本（簡單接口）
     * @param {string} text - 要打印的文本
     * @param {Object} config - 打印機配置 {ip_address, port}
     * @returns {Promise<boolean>} 成功返回true
     */
    static async printText(text, config) {
        const printer = new RawPrinter(config);
        printer.println(text);
        return printer.execute();
    }

    /**
     * 打印多行文本
     * @param {string[]} lines - 文本行數組
     * @param {Object} config - 打印機配置
     * @returns {Promise<boolean>} 成功返回true
     */
    static async printLines(lines, config) {
        const printer = new RawPrinter(config);
        lines.forEach(line => printer.println(line));
        return printer.execute();
    }
}

module.exports = RawPrinter;