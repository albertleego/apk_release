// 入場機器前端邏輯
class EntryMachine {
    constructor() {
        this.socket = null;
        this.peopleCount = 1;
        this.selectedPeopleCount = 1; // 用於人數選擇卡片
        this.memberCardId = null;
        this.memberInfo = null;
        this.currentQRCode = null;
        this.recentEntries = [];
        this.visitorType = null; // 'first-time' or 'returning'
        this.currentLanguage = 'zh-TW';
        this.returnTimer = null; // 20秒返回計時器
        this.eventsBound = false; // 防止事件重複綁定
        this.isProcessing = false; // 防止重複提交
        this.init();
    }

    // 翻譯字典
    static translations = {
        'zh-TW': {
            'firstTimeQuestion': '請問您是第一次來嗎',
            'firstTimeYes': '是的\n我第一次來',
            'firstTimeNo': '不是\n我之前來過',
            'rulesVideoTitle': '店內規則說明影片',
            'rulesVideoLoading': '正在載入規則影片...',
            'skipVideoBtn': '跳過影片',
            'continueAfterVideoBtn': '影片觀看完畢，繼續',
            'selectPeopleTitle': '選擇客人人數',
            'confirmPeopleBtn': '確認人數',
            'entryGuidanceTitle': '入場指引',
            'entryGuidanceText': '請提取小票\n存放鞋子後\n門口掃小票二維碼\n即可入場',
            'restartProcessBtn': '新客入座',
            'fullSeatTitle': '目前已經滿座',
            'fullSeatMessage': '請掃以下二維碼登記候位\n有位置後會優先致電和whatsapp 您',
            'fullSeatCloseBtn': '關閉'
        },
        'zh-CN': {
            'firstTimeQuestion': '请问您是第一次来吗',
            'firstTimeYes': '是的\n我第一次来',
            'firstTimeNo': '不是\n我之前来过',
            'rulesVideoTitle': '店内规则说明视频',
            'rulesVideoLoading': '正在加载规则视频...',
            'skipVideoBtn': '跳过视频',
            'continueAfterVideoBtn': '视频观看完毕，继续',
            'selectPeopleTitle': '选择客人人数',
            'confirmPeopleBtn': '确认人数',
            'entryGuidanceTitle': '入场指引',
            'entryGuidanceText': '请提取小票\n存放鞋子后\n门口扫小票二维码\n即可入场',
            'restartProcessBtn': '新客入座',
            'fullSeatTitle': '目前已经满座',
            'fullSeatMessage': '请扫以下二维码登记候位\n有位置后会优先致电和whatsapp 您',
            'fullSeatCloseBtn': '关闭'
        },
        'en': {
            'firstTimeQuestion': 'Is this your first visit?',
            'firstTimeYes': 'Yes\nthis is my first time',
            'firstTimeNo': 'No\nI have been here before',
            'rulesVideoTitle': 'Store Rules Video',
            'rulesVideoLoading': 'Loading rules video...',
            'skipVideoBtn': 'Skip Video',
            'continueAfterVideoBtn': 'Continue after video',
            'selectPeopleTitle': 'Select Number of Guests',
            'confirmPeopleBtn': 'Confirm',
            'entryGuidanceTitle': 'Entry Guidance',
            'entryGuidanceText': 'Please collect receipt\nAfter storing shoes\nScan receipt QR code at entrance\nThen enter',
            'restartProcessBtn': 'New Entry',
            'fullSeatTitle': 'Currently Full',
            'fullSeatMessage': 'Please scan the QR code below to join the waiting list\nWe will prioritize calling and WhatsApp you when seats become available',
            'fullSeatCloseBtn': 'Close'
        }
    };

    // 解析入場時間字符串，支援兩種格式：
    // 1. ISO 字符串 (UTC) 例如 "2026-03-24T07:31:00.000Z"
    // 2. 本地時間字符串 "YYYY-MM-DD HH:MM:SS"
    parseEntryTime(entryTimeString) {
        if (!entryTimeString) return new Date();

        // 檢查是否為 ISO 格式 (包含 'T' 或結尾有 'Z')
        if (entryTimeString.includes('T') || entryTimeString.endsWith('Z')) {
            // ISO 格式，直接解析為 UTC
            return new Date(entryTimeString);
        } else {
            // 本地時間格式 "YYYY-MM-DD HH:MM:SS"
            // 手動解析並創建本地時間 Date 物件
            const [datePart, timePart] = entryTimeString.split(' ');
            const [year, month, day] = datePart.split('-').map(Number);
            const [hours, minutes, seconds] = timePart.split(':').map(Number);
            return new Date(year, month - 1, day, hours, minutes, seconds);
        }
    }

    applyTranslations(lang) {
        const translations = EntryMachine.translations[lang];
        if (!translations) return;

        // 更新所有帶有 data-i18n 屬性的元素
        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n');
            if (translations[key]) {
                // 特殊處理包含換行符的文本
                if (translations[key].includes('\n')) {
                    // 使用 innerHTML 並將換行符轉換為 <br>
                    element.innerHTML = translations[key].replace(/\n/g, '<br>');
                } else {
                    element.textContent = translations[key];
                }
            }
        });

        // 更新所有帶有 data-i18n-placeholder 屬性的輸入框
        document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
            const key = element.getAttribute('data-i18n-placeholder');
            if (translations[key]) {
                element.placeholder = translations[key];
            }
        });
    }

    async init() {
        // 初始化時間顯示
        this.updateTime();
        setInterval(() => this.updateTime(), 1000);

        // 連接Socket.IO
        this.connectSocket();

        // 綁定事件監聽器
        this.bindEvents();

        // 應用初始翻譯
        this.applyTranslations(this.currentLanguage);

        // 載入今日統計
        this.loadTodayStats();

        // 載入最近的入場記錄
        this.loadRecentEntries();

        // 初始化系統訊息
        this.addMessage('系統啟動完成', 'info');

        // 初始化人數選擇卡片狀態
        this.setSelectedPeopleCount(1);

        // 初始化會員 QR Code 掃描
        this.initMemberQRReader();
    }

    connectSocket() {
        this.socket = io();

        this.socket.on('connect', () => {
            this.updateStatus('online');
            this.addMessage('已連線到伺服器', 'success');
        });

        this.socket.on('disconnect', () => {
            this.updateStatus('offline');
            this.addMessage('與伺服器斷開連線', 'error');
        });

        this.socket.on('new-customer', (data) => {
            this.addMessage(`新客人入場: 桌號 ${data.table_number}, ${data.people_count}位`, 'info');
            this.loadRecentEntries();
            this.loadTodayStats();
        });

        this.socket.on('device-update', (data) => {
            this.addMessage(`設備更新: ${data.device} - ${data.status}`, 'info');
            this.updateDeviceStatus(data);
        });

        this.socket.on('print-receipt', (data) => {
            this.addMessage(`小票打印完成: 桌號 ${data.table_number}`, 'success');
        });

        this.socket.on('lockers-opened', (data) => {
            this.addMessage(`儲物柜已開啟: ${data.locker_numbers.join(', ')}`, 'success');
        });
    }

    bindEvents() {
        // 防止重複綁定事件
        if (this.eventsBound) {
            console.log('事件已綁定，跳過重複綁定');
            return;
        }

        this.eventsBound = true;

        // 語言選擇
        document.querySelectorAll('.language-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const lang = e.target.dataset.lang;
                this.setLanguage(lang);
            });
        });

        // 訪客類型選擇
        const firstTimeBtn = document.getElementById('first-time-btn');
        const returningBtn = document.getElementById('returning-btn');

        if (firstTimeBtn) {
            console.log('Found first-time-btn element');
            firstTimeBtn.addEventListener('click', (e) => {
                console.log('First-time button click event fired');
                e.stopPropagation();
                this.handleFirstTimeVisitor();
            });
        } else {
            console.error('First-time button element not found');
        }

        if (returningBtn) {
            console.log('Found returning-btn element');
            returningBtn.addEventListener('click', (e) => {
                console.log('Returning button click event fired');
                e.stopPropagation();
                this.handleReturningVisitor();
            });
        } else {
            console.error('Returning button element not found');
        }

        // 人數選擇卡片事件
        const decreaseSelectionBtn = document.getElementById('decrease-selection-btn');
        const increaseSelectionBtn = document.getElementById('increase-selection-btn');
        const confirmPeopleBtn = document.getElementById('confirm-people-btn');

        if (decreaseSelectionBtn) decreaseSelectionBtn.addEventListener('click', () => this.adjustSelectedPeopleCount(-1));
        if (increaseSelectionBtn) increaseSelectionBtn.addEventListener('click', () => this.adjustSelectedPeopleCount(1));
        if (confirmPeopleBtn) confirmPeopleBtn.addEventListener('click', async () => {
            try {
                await this.confirmPeopleCount();
            } catch (error) {
                console.error('確認人數時發生錯誤:', error);
                this.addMessage('確認人數時發生錯誤: ' + error.message, 'error');
            }
        });

        // 人數選擇卡片中的快速選擇按鈕
        document.querySelectorAll('#people-count-card .btn-people').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const button = e.currentTarget;
                const count = parseInt(button.dataset.count);
                this.setSelectedPeopleCount(count);

                // 更新按鈕狀態
                document.querySelectorAll('#people-count-card .btn-people').forEach(b => b.classList.remove('active'));
                button.classList.add('active');
            });
        });

        // 影片控制
        const skipVideoBtn = document.getElementById('skip-video-btn');
        const continueAfterVideoBtn = document.getElementById('continue-after-video-btn');
        if (skipVideoBtn) skipVideoBtn.addEventListener('click', () => this.skipVideo());
        if (continueAfterVideoBtn) continueAfterVideoBtn.addEventListener('click', () => this.continueAfterVideo());

        // 人數控制
        const decreaseBtn = document.getElementById('decrease-btn');
        const increaseBtn = document.getElementById('increase-btn');
        if (decreaseBtn) decreaseBtn.addEventListener('click', () => this.adjustPeopleCount(-1));
        if (increaseBtn) increaseBtn.addEventListener('click', () => this.adjustPeopleCount(1));

        // 入場面板中的人數快速選擇按鈕
        document.querySelectorAll('#entry-panel .btn-people').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const button = e.currentTarget;
                const count = parseInt(button.dataset.count);
                this.setPeopleCount(count);

                // 更新按鈕狀態
                document.querySelectorAll('#entry-panel .btn-people').forEach(b => b.classList.remove('active'));
                button.classList.add('active');
            });
        });

        // 處理入場
        const processEntryBtn = document.getElementById('process-entry-btn');
        if (processEntryBtn) processEntryBtn.addEventListener('click', () => this.processEntry());

        // 測試按鈕
        const testPrintBtn = document.getElementById('test-print-btn');
        const testLockerBtn = document.getElementById('test-locker-btn');
        if (testPrintBtn) testPrintBtn.addEventListener('click', () => this.testPrint());
        if (testLockerBtn) testLockerBtn.addEventListener('click', () => this.testLocker());

        // 設備控制
        const printerTestBtn = document.getElementById('printer-test-btn');
        const printerResetBtn = document.getElementById('printer-reset-btn');
        const lockerTestBtn = document.getElementById('locker-test-btn');
        const lockerResetBtn = document.getElementById('locker-reset-btn');
        const audioTestBtn = document.getElementById('audio-test-btn');
        const audioStopBtn = document.getElementById('audio-stop-btn');
        if (printerTestBtn) printerTestBtn.addEventListener('click', () => this.testPrinter());
        if (printerResetBtn) printerResetBtn.addEventListener('click', () => this.resetPrinter());
        if (lockerTestBtn) lockerTestBtn.addEventListener('click', () => this.testLockerSystem());
        if (lockerResetBtn) lockerResetBtn.addEventListener('click', () => this.resetLockerSystem());
        if (audioTestBtn) audioTestBtn.addEventListener('click', () => this.testAudio());
        if (audioStopBtn) audioStopBtn.addEventListener('click', () => this.stopAudio());

        // 刷新記錄
        const refreshEntriesBtn = document.getElementById('refresh-entries-btn');
        if (refreshEntriesBtn) refreshEntriesBtn.addEventListener('click', () => this.loadRecentEntries());

        // 複製QR Code
        const copyQrBtn = document.getElementById('copy-qr-btn');
        if (copyQrBtn) copyQrBtn.addEventListener('click', () => this.copyQRCode());

        // 系統訊息控制已移除

        // 系統控制
        const systemCheckBtn = document.getElementById('system-check-btn');
        const emergencyStopBtn = document.getElementById('emergency-stop-btn');
        if (systemCheckBtn) systemCheckBtn.addEventListener('click', () => this.systemCheck());
        if (emergencyStopBtn) emergencyStopBtn.addEventListener('click', () => this.emergencyStop());

        // 處理模態框
        const cancelProcessBtn = document.getElementById('cancel-process-btn');
        if (cancelProcessBtn) cancelProcessBtn.addEventListener('click', () => this.cancelProcessing());

        // 滿座提示模態框
        const closeFullSeatBtn = document.getElementById('close-full-seat-btn');
        if (closeFullSeatBtn) closeFullSeatBtn.addEventListener('click', () => this.hideFullSeatModal());
    }

    setLanguage(lang) {
        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        // 更新語言按鈕狀態
        document.querySelectorAll('.language-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.lang === lang) {
                btn.classList.add('active');
            }
        });
        this.currentLanguage = lang;
        this.applyTranslations(lang);
        this.addMessage(`語言已切換為: ${lang}`, 'info');

        // 如果當前顯示入場指引頁面，重新生成內容以更新翻譯
        const videoSection = document.getElementById('video-section');
        if (videoSection && !videoSection.classList.contains('hidden')) {
            const titleElement = videoSection.querySelector('h2 span');
            if (titleElement && titleElement.getAttribute('data-i18n') === 'entryGuidanceTitle') {
                // 重新生成入場指引內容
                this.updateVideoSectionToEntryGuidance();
            }
        }
    }

    handleFirstTimeVisitor() {
        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        console.log('First time visitor button clicked');
        this.visitorType = 'first-time';
        this.addMessage('歡迎新客人！請選擇人數', 'info');

        // 隱藏訪客選擇卡片，顯示人數選擇卡片
        document.getElementById('visitor-type-card').classList.add('hidden');
        document.getElementById('people-count-card').classList.remove('hidden');
    }

    handleReturningVisitor() {
        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        console.log('Returning visitor button clicked');
        this.visitorType = 'returning';
        this.addMessage('歡迎回來！請選擇人數', 'info');

        // 隱藏訪客選擇卡片，顯示人數選擇卡片
        document.getElementById('visitor-type-card').classList.add('hidden');
        document.getElementById('people-count-card').classList.remove('hidden');
    }

    startVideoPlayback() {
        this.addMessage('開始播放規則影片...', 'info');

        // 禁用繼續按鈕直到影片完成
        document.getElementById('continue-after-video-btn').disabled = true;

        // 更新影片佔位符顯示
        const videoPlaceholder = document.querySelector('.video-placeholder');
        if (videoPlaceholder) {
            videoPlaceholder.innerHTML = `
                <i class="fas fa-play-circle fa-spin"></i>
                <p>規則影片播放中... (3秒)</p>
            `;
        }

        // 模擬影片播放
        setTimeout(() => {
            this.addMessage('規則影片播放完成', 'success');
            // 更新影片佔位符
            if (videoPlaceholder) {
                videoPlaceholder.innerHTML = `
                    <i class="fas fa-check-circle"></i>
                    <p>規則影片播放完成</p>
                `;
            }
            // 啟用繼續按鈕
            document.getElementById('continue-after-video-btn').disabled = false;
        }, 3000); // 3秒模擬影片長度
    }

    skipVideo() {
        // 取消返回計時器
        this.cancelReturnTimer();

        this.addMessage('已跳過規則影片', 'warning');
        // 直接顯示入場面板
        document.getElementById('video-section').classList.add('hidden');
        document.getElementById('entry-panel').classList.remove('hidden');

        // 重置影片佔位符（為下一次做準備）
        const videoPlaceholder = document.querySelector('.video-placeholder');
        if (videoPlaceholder) {
            videoPlaceholder.innerHTML = `
                <i class="fas fa-play-circle"></i>
                <p data-i18n="rulesVideoLoading"></p>
            `;
            // 重新應用翻譯
            this.applyTranslations(this.currentLanguage);
        }
    }

    async continueAfterVideo() {
        // 取消返回計時器
        this.cancelReturnTimer();

        this.addMessage('規則影片觀看完畢，開始入場處理', 'success');

        // 禁用繼續按鈕防止重複點擊
        const continueBtn = document.getElementById('continue-after-video-btn');
        if (continueBtn) continueBtn.disabled = true;

        try {
            // 執行入場處理流程
            console.log('continueAfterVideo: calling processEntry with skipDuplicateCheck=true');
            await this.processEntry(true);

            // 入場處理完成後，更新影片區域為入場指引
            this.updateVideoSectionToEntryGuidance();

        } catch (error) {
            this.addMessage('入場處理失敗: ' + error.message, 'error');
            // 重新啟用繼續按鈕以便重試
            if (continueBtn) continueBtn.disabled = false;
        }
    }

    updateVideoSectionToEntryGuidance() {
        const videoSection = document.getElementById('video-section');
        if (!videoSection) return;

        // 確保視頻區域可見，隱藏入場面板
        videoSection.classList.remove('hidden');
        document.getElementById('entry-panel').classList.add('hidden');

        // 更新標題
        const titleElement = videoSection.querySelector('h2 span');
        if (titleElement) {
            titleElement.setAttribute('data-i18n', 'entryGuidanceTitle');
        }

        // 更新內容區域
        const videoContainer = videoSection.querySelector('.video-container');
        if (videoContainer) {
            videoContainer.innerHTML = `
                <div class="video-placeholder">
                    <i class="fas fa-clipboard-check"></i>
                    <p data-i18n="entryGuidanceText">請提取小票<br>存放鞋子後<br>門口掃小票二維碼<br>即可入場</p>
                </div>
                <div class="video-controls" style="justify-content: center; margin-top: 30px;">
                    <button class="btn-primary btn-lg" id="restart-process-btn">
                        <i class="fas fa-redo"></i> <span data-i18n="restartProcessBtn">新客入座</span>
                    </button>
                </div>
            `;
        }

        // 應用翻譯
        this.applyTranslations(this.currentLanguage);

        // 綁定重新開始按鈕事件
        const restartBtn = document.getElementById('restart-process-btn');
        if (restartBtn) {
            restartBtn.addEventListener('click', () => this.restartProcess());
        }

        this.addMessage('入場指引已顯示', 'info');

        // 設置20秒後自動返回初始頁面
        this.startReturnTimer();
    }

    restartProcess() {
        // 取消現有計時器
        this.cancelReturnTimer();

        this.addMessage('重新開始入場流程', 'info');

        // 隱藏所有卡片，只顯示初始訪客類型選擇
        document.getElementById('video-section').classList.add('hidden');
        document.getElementById('people-count-card').classList.add('hidden');
        document.getElementById('entry-panel').classList.add('hidden');
        document.getElementById('visitor-type-card').classList.remove('hidden');

        // 重置影片區域內容
        const videoSection = document.getElementById('video-section');
        if (videoSection) {
            const videoContainer = videoSection.querySelector('.video-container');
            if (videoContainer) {
                videoContainer.innerHTML = `
                    <div class="video-placeholder">
                        <i class="fas fa-play-circle"></i>
                        <p data-i18n="rulesVideoLoading">正在載入規則影片...</p>
                    </div>
                    <div class="video-controls hidden-skip">
                        <button class="btn-secondary" id="skip-video-btn">
                            <i class="fas fa-forward"></i> <span data-i18n="skipVideoBtn">跳過影片</span>
                        </button>
                        <button class="btn-primary" id="continue-after-video-btn" disabled>
                            <i class="fas fa-check-circle"></i> <span data-i18n="continueAfterVideoBtn">影片觀看完畢，繼續</span>
                        </button>
                    </div>
                `;
            }
        }

        // 重置狀態
        this.selectedPeopleCount = 1;
        this.peopleCount = 1;
        this.visitorType = null;

        // 重新應用翻譯
        this.applyTranslations(this.currentLanguage);

        // 綁定影片控制按鈕（因為HTML已重新生成）
        const skipVideoBtn = document.getElementById('skip-video-btn');
        const continueAfterVideoBtn = document.getElementById('continue-after-video-btn');
        if (skipVideoBtn) skipVideoBtn.addEventListener('click', () => this.skipVideo());
        if (continueAfterVideoBtn) continueAfterVideoBtn.addEventListener('click', () => this.continueAfterVideo());
    }

    // 啟動20秒返回初始頁面計時器
    startReturnTimer() {
        // 先取消現有計時器
        this.cancelReturnTimer();

        this.returnTimer = setTimeout(() => {
            this.addMessage('20秒未操作，自動返回初始頁面', 'info');
            this.restartProcess();
        }, 20000); // 20秒
    }

    // 取消返回計時器
    cancelReturnTimer() {
        if (this.returnTimer) {
            clearTimeout(this.returnTimer);
            this.returnTimer = null;
        }
    }

    updateTime() {
        const now = new Date();
        const timeString = now.toLocaleTimeString('zh-TW');
        const dateString = now.toLocaleDateString('zh-TW', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        });

        document.getElementById('current-time').textContent = timeString;
        document.getElementById('last-update').textContent = `最後更新: ${dateString} ${timeString}`;
    }

    updateStatus(status) {
        const statusBar = document.querySelector('.status-bar .status');
        if (status === 'online') {
            statusBar.classList.add('online');
            statusBar.innerHTML = '<i class="fas fa-wifi"></i><span>連線中</span>';
        } else {
            statusBar.classList.remove('online');
            statusBar.innerHTML = '<i class="fas fa-wifi"></i><span>離線中</span>';
        }
    }

    updateDeviceStatus(data) {
        // 根據設備類型更新狀態顯示
        switch(data.device) {
            case 'printer':
                const printerStatus = document.getElementById('printer-status');
                printerStatus.innerHTML = `<i class="fas fa-print"></i><span>${data.status === 'online' ? '就緒' : '離線'}</span>`;
                break;
            case 'locker':
                const lockerStatus = document.getElementById('locker-status');
                lockerStatus.innerHTML = `<i class="fas fa-door-closed"></i><span>${data.status === 'online' ? '就緒' : '離線'}</span>`;
                break;
        }
    }

    adjustPeopleCount(change) {
        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        let newCount = this.peopleCount + change;

        if (newCount < 1) newCount = 1;
        if (newCount > 10) newCount = 10;

        this.setPeopleCount(newCount);
    }

    setPeopleCount(count) {
        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        this.peopleCount = count;
        document.getElementById('people-count').textContent = count;

        // 更新按鈕狀態
        document.getElementById('decrease-btn').disabled = count <= 1;
        document.getElementById('increase-btn').disabled = count >= 10;
    }

    adjustSelectedPeopleCount(change) {
        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        let newCount = this.selectedPeopleCount + change;

        if (newCount < 1) newCount = 1;
        if (newCount > 10) newCount = 10;

        this.setSelectedPeopleCount(newCount);
    }

    setSelectedPeopleCount(count) {
        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        console.log(`setSelectedPeopleCount called: count=${count}, previous selectedPeopleCount=${this.selectedPeopleCount}`);
        this.selectedPeopleCount = count;
        const countElement = document.getElementById('people-count-selection');
        if (countElement) {
            countElement.textContent = count;
        }

        // 更新按鈕狀態
        const decreaseSelectionBtn = document.getElementById('decrease-selection-btn');
        const increaseSelectionBtn = document.getElementById('increase-selection-btn');
        if (decreaseSelectionBtn) decreaseSelectionBtn.disabled = count <= 1;
        if (increaseSelectionBtn) increaseSelectionBtn.disabled = count >= 10;

        // 更新快速選擇按鈕狀態
        document.querySelectorAll('#people-count-card .btn-people').forEach(btn => {
            const btnCount = parseInt(btn.dataset.count);
            btn.classList.toggle('active', btnCount === count);
        });
    }

    async confirmPeopleCount() {
        // 防止重複執行
        if (this.isProcessing) {
            this.addMessage('正在處理中，請稍候...', 'warning');
            console.log('confirmPeopleCount: already processing, returning early');
            return;
        }

        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        this.isProcessing = true;
        console.log('confirmPeopleCount: isProcessing set to true, visitorType=', this.visitorType, 'selectedPeopleCount=', this.selectedPeopleCount, 'peopleCount=', this.peopleCount);

        try {
            // 將選擇的人數應用到入場面板
            this.peopleCount = this.selectedPeopleCount;
            document.getElementById('people-count').textContent = this.peopleCount;

            console.log(`confirmPeopleCount: peopleCount set to ${this.peopleCount} from selectedPeopleCount ${this.selectedPeopleCount}`);
            this.addMessage(`已選擇 ${this.selectedPeopleCount} 位客人`, 'info');

            if (this.visitorType === 'first-time') {
                // 第一次來的客人：顯示影片區域
                document.getElementById('people-count-card').classList.add('hidden');
                document.getElementById('video-section').classList.remove('hidden');

                // 開始播放影片
                this.startVideoPlayback();
            } else {
                // 之前來過的客人：跳過影片，直接開始入場處理
                document.getElementById('people-count-card').classList.add('hidden');

                // 直接開始入場處理流程
                console.log('confirmPeopleCount: calling processEntry with skipDuplicateCheck=true');
                try {
                    await this.processEntry(true);

                    // 處理成功後，顯示入場指引
                    this.updateVideoSectionToEntryGuidance();
                } catch (error) {
                    this.addMessage('入場處理失敗: ' + error.message, 'error');
                    // 如果處理失敗，顯示入場面板讓用戶重試
                    document.getElementById('entry-panel').classList.remove('hidden');
                }
            }
        } catch (error) {
            // 處理頂層錯誤
            this.addMessage('確認人數時發生錯誤: ' + error.message, 'error');
        } finally {
            this.isProcessing = false; // 重置處理標誌
        }
    }

    initMemberQRReader() {
        const qrInput = document.getElementById('member-qr-input');
        if (!qrInput) return;

        // 自動對焦輸入框
        const focusInput = () => {
            setTimeout(() => qrInput.focus(), 300);
        };
        focusInput();

        // 點擊讀取區也對焦輸入框
        const reader = document.getElementById('member-reader');
        if (reader) {
            reader.addEventListener('click', focusInput);
        }

        // QR Scanner 掃完後會輸入文字 + Enter
        let scanTimeout = null;
        qrInput.addEventListener('keydown', async (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                const cardId = qrInput.value.trim();
                qrInput.value = '';
                if (cardId) {
                    await this.lookupMemberCard(cardId);
                }
                // 重新對焦以便下次掃描
                setTimeout(() => qrInput.focus(), 100);
            } else {
                // 有按鍵輸入時取消返回計時器（用戶正在操作）
                this.cancelReturnTimer();
                // 清除超時，重新計時（掃描器連續輸入時不觸發）
                if (scanTimeout) clearTimeout(scanTimeout);
            }
        });
    }

    async lookupMemberCard(cardId) {
        this.addMessage(`正在查詢會員 QR Code...`, 'info');
        this.cancelReturnTimer();

        try {
            const response = await fetch('/api/entry/nfc-scan', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ cardId })
            });

            const result = await response.json();

            if (result.success && result.is_member) {
                this.memberCardId = cardId;
                this.memberInfo = result.member_info;
                this.showMemberInfo(result.member_info);
                this.addMessage(`會員驗證成功: ${result.member_info.name}`, 'success');
            } else {
                this.memberCardId = null;
                this.memberInfo = null;
                this.hideMemberInfo();
                this.addMessage('非會員 QR Code 或卡片無效', 'warning');
            }
        } catch (error) {
            this.memberCardId = null;
            this.memberInfo = null;
            this.hideMemberInfo();
            this.addMessage('會員查詢失敗: ' + error.message, 'error');
        }
    }

    showMemberInfo(memberInfo) {
        document.getElementById('member-name').textContent = memberInfo.name || '未提供';
        document.getElementById('member-balance').textContent = '$' + memberInfo.balance.toFixed(2);
        document.getElementById('member-info').classList.remove('hidden');
    }

    hideMemberInfo() {
        document.getElementById('member-info').classList.add('hidden');
    }

    async processEntry(skipDuplicateCheck = false) {
        console.log('processEntry called:', {
            skipDuplicateCheck,
            isProcessing: this.isProcessing,
            peopleCount: this.peopleCount,
            memberCardId: this.memberCardId
        });

        // 防止重複提交
        if (!skipDuplicateCheck && this.isProcessing) {
            console.log('processEntry: duplicate check prevented execution');
            this.addMessage('正在處理入場，請稍候...', 'warning');
            return;
        }

        // 取消返回計時器（用戶正在操作）
        this.cancelReturnTimer();

        this.isProcessing = true;

        // 顯示處理模態框
        this.showProcessingModal();

        try {
            // 步驟1: 驗證輸入
            this.updateProgress(1, 20, '驗證輸入...');

            // 驗證人數
            if (typeof this.peopleCount !== 'number' || this.peopleCount < 1 || this.peopleCount > 10) {
                throw new Error(`無效的人數: ${this.peopleCount}。請選擇 1-10 位客人。`);
            }

            await this.delay(500);

            // 步驟2: 發送入場請求
            this.updateProgress(2, 40, '分配桌位...');
            console.log('processEntry: making API request with peopleCount=', this.peopleCount, 'memberCardId=', this.memberCardId);
            const response = await fetch('/api/entry/entry', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    peopleCount: this.peopleCount,
                    memberCardId: this.memberCardId
                })
            });

            if (!response.ok) {
                // 嘗試獲取更詳細的錯誤訊息
                let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
                try {
                    const errorData = await response.json();
                    if (errorData.error) {
                        errorMessage = errorData.error;
                        if (errorData.message) {
                            errorMessage += ` - ${errorData.message}`;
                        }
                    }
                } catch (e) {
                    // 忽略JSON解析錯誤，使用默認錯誤訊息
                }

                // 檢查是否為滿座錯誤
                if (errorMessage.includes('暫時沒有合適的桌位，請稍後再試')) {
                    this.hideProcessingModal();
                    this.isProcessing = false; // 重置處理標誌
                    this.showFullSeatModal();
                    return; // 退出處理流程
                }

                console.log('processEntry: API request failed:', errorMessage);
                throw new Error(errorMessage);
            }

            console.log('processEntry: API request successful, status:', response.status);
            const result = await response.json();
            console.log('processEntry: API response:', result);

            // 步驟3: 分配儲物柜
            this.updateProgress(3, 60, '分配儲物柜...');
            await this.delay(1000);

            // 步驟4: 生成QR Code
            this.updateProgress(4, 80, '生成QR Code...');
            await this.delay(500);

            // 步驟5: 打印小票
            this.updateProgress(5, 100, '打印小票...');

            // 顯示結果
            await this.showResult(result);

            // 等待模態框關閉（延遲一下讓用戶看到完成狀態）
            await new Promise(resolve => {
                setTimeout(() => {
                    this.hideProcessingModal();
                    this.addMessage(`入場處理完成: 桌號 ${result.data.table_number}`, 'success');
                    resolve();
                }, 1500);
            });

        } catch (error) {
            this.addMessage('入場處理失敗: ' + error.message, 'error');
            this.hideProcessingModal();
            throw error; // 重新拋出錯誤以便外層處理
        } finally {
            this.isProcessing = false; // 確保處理標誌被重置
        }
    }

    showProcessingModal() {
        document.getElementById('processing-modal').classList.remove('hidden');
        // 重置進度條
        this.updateProgress(1, 20, '準備開始處理...');
    }

    hideProcessingModal() {
        document.getElementById('processing-modal').classList.add('hidden');
    }

    showFullSeatModal() {
        document.getElementById('full-seat-modal').classList.remove('hidden');
    }

    hideFullSeatModal() {
        document.getElementById('full-seat-modal').classList.add('hidden');
    }

    updateProgress(step, percent, text) {
        // 更新進度條
        document.getElementById('progress-fill').style.width = percent + '%';
        document.getElementById('progress-text').textContent = text;

        // 更新步驟狀態
        document.querySelectorAll('.step').forEach((stepEl, index) => {
            if (index + 1 < step) {
                stepEl.classList.add('completed');
                stepEl.classList.remove('active');
                stepEl.innerHTML = '<i class="fas fa-check-circle"></i><span>' + stepEl.querySelector('span').textContent + '</span>';
            } else if (index + 1 === step) {
                stepEl.classList.add('active');
                stepEl.classList.remove('completed');
                stepEl.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>' + stepEl.querySelector('span').textContent + '</span>';
            } else {
                stepEl.classList.remove('active', 'completed');
                stepEl.innerHTML = '<i class="fas fa-circle"></i><span>' + stepEl.querySelector('span').textContent + '</span>';
            }
        });
    }

    async showResult(result) {
        if (!result.success) {
            this.addMessage('入場處理失敗: ' + result.error, 'error');
            return;
        }

        const data = result.data;

        // 保存QR Code資料（即使不顯示也保存）
        this.currentQRCode = data.qr_code;

        // 只有在入場面板可見時才顯示QR Code
        const entryPanel = document.getElementById('entry-panel');
        if (entryPanel && !entryPanel.classList.contains('hidden')) {
            this.displayQRCode(data.qr_code_image || data.qr_code);

            // 更新QR Code信息（如果元素存在）
            const qrTableNumber = document.getElementById('qr-table-number');
            const qrEntryTime = document.getElementById('qr-entry-time');
            const qrLockers = document.getElementById('qr-lockers');
            const qrCodeText = document.getElementById('qr-code-text');
            const copyQrBtn = document.getElementById('copy-qr-btn');

            if (qrTableNumber) qrTableNumber.textContent = data.table_number;
            if (qrEntryTime) qrEntryTime.textContent = new Date().toLocaleString('zh-TW');
            if (qrLockers) qrLockers.textContent = data.lockers.join(', ') || '無';
            if (qrCodeText) qrCodeText.textContent = data.qr_code;
            if (copyQrBtn) copyQrBtn.disabled = false;
        }

        // 播放音效（如果是會員則跳過）
        if (!data.skip_audio) {
            this.playWelcomeAudio();
        }

        // 添加到入場記錄
        this.addToRecentEntries(data);
    }

    displayQRCode(qrData) {
        const canvas = document.getElementById('qr-canvas');
        const placeholder = document.getElementById('qr-placeholder');

        if (!canvas || !placeholder) {
            console.log('QR Code顯示元素不存在，跳過顯示');
            return;
        }

        if (qrData.startsWith('data:image')) {
            // 如果是base64圖片
            const img = new Image();
            img.onload = () => {
                const ctx = canvas.getContext('2d');
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                placeholder.classList.add('hidden');
                canvas.classList.remove('hidden');
            };
            img.src = qrData;
        } else {
            // 如果是文本，使用簡單的QR Code生成（簡化版）
            placeholder.classList.add('hidden');
            canvas.classList.remove('hidden');

            const ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#000';
            ctx.font = '14px Arial';
            ctx.textAlign = 'center';
            ctx.fillText(qrData.substring(0, 20), canvas.width / 2, canvas.height / 2);
            ctx.fillText(qrData.substring(20, 40) || '', canvas.width / 2, canvas.height / 2 + 20);
        }
    }

    async loadTodayStats() {
        try {
            const response = await fetch('/api/entry/waiting');
            const result = await response.json();

            if (result.success) {
                const todayCount = result.customers.filter(c => {
                    const entryDate = this.parseEntryTime(c.entry_time).toDateString();
                    const today = new Date().toDateString();
                    return entryDate === today;
                }).length;

                const todayCountElement = document.getElementById('today-count');
                if (todayCountElement) {
                    todayCountElement.textContent = todayCount;
                }
            }
        } catch (error) {
            console.error('載入今日統計失敗:', error);
        }
    }

    async loadRecentEntries() {
        try {
            const response = await fetch('/api/entry/waiting');
            const result = await response.json();

            if (result.success) {
                this.recentEntries = result.customers;
                this.displayRecentEntries();
            }
        } catch (error) {
            console.error('載入入場記錄失敗:', error);
        }
    }

    displayRecentEntries() {
        const entriesList = document.getElementById('entries-list');

        // 如果元素不存在，直接返回
        if (!entriesList) {
            return;
        }

        if (this.recentEntries.length === 0) {
            entriesList.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-clock"></i>
                    <p>暫無入場記錄</p>
                </div>
            `;
            return;
        }

        entriesList.innerHTML = '';

        this.recentEntries.slice(0, 10).forEach(entry => {
            const entryTime = this.parseEntryTime(entry.entry_time).toLocaleTimeString('zh-TW', {
                hour: '2-digit',
                minute: '2-digit'
            });

            const status = entry.is_checked_out ? '已離場' : '在場中';
            const statusClass = entry.is_checked_out ? 'status-checked-out' : 'status-active';

            const entryEl = document.createElement('div');
            entryEl.className = 'entry-item';
            entryEl.innerHTML = `
                <span>${entryTime}</span>
                <span>${entry.table_number || entry.actual_table}</span>
                <span>${entry.people_count}位</span>
                <span class="${statusClass}">${status}</span>
            `;

            entriesList.appendChild(entryEl);
        });
    }

    addToRecentEntries(data) {
        const entry = {
            table_number: data.table_number,
            people_count: data.people_count,
            entry_time: new Date().toISOString(),
            is_checked_out: false
        };

        this.recentEntries.unshift(entry);
        if (this.recentEntries.length > 10) {
            this.recentEntries = this.recentEntries.slice(0, 10);
        }

        this.displayRecentEntries();
        this.loadTodayStats();
    }

    addMessage(text, type = 'info') {
        // 系統訊息頁面已移除，改為控制台輸出
        const now = new Date();
        const timeString = now.toLocaleTimeString('zh-TW', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });

        const logPrefix = `[${timeString}]`;
        const styledPrefix = `%c${logPrefix}`;
        const style = this.getConsoleStyle(type);

        // 輸出到控制台
        console.log(`${styledPrefix} ${text}`, style);
    }

    getConsoleStyle(type) {
        const styles = {
            'info': 'color: #3498db; font-weight: bold',
            'success': 'color: #27ae60; font-weight: bold',
            'warning': 'color: #f39c12; font-weight: bold',
            'error': 'color: #e74c3c; font-weight: bold'
        };
        return styles[type] || styles.info;
    }



    async copyQRCode() {
        if (!this.currentQRCode) {
            this.addMessage('請先生成QR Code', 'warning');
            return;
        }

        try {
            await navigator.clipboard.writeText(this.currentQRCode);
            this.addMessage('QR Code已複製到剪貼板', 'success');
        } catch (error) {
            this.addMessage('複製失敗: ' + error.message, 'error');
        }
    }

    // 測試功能
    async testPrint() {
        try {
            const response = await fetch('/api/entry/print-receipt', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    table_number: 'TEST',
                    qr_code: 'TEST-' + Date.now(),
                    people_count: this.peopleCount
                })
            });

            const result = await response.json();
            this.addMessage('測試打印指令已發送', 'info');
        } catch (error) {
            this.addMessage('測試打印失敗: ' + error.message, 'error');
        }
    }

    async testLocker() {
        try {
            const response = await fetch('/api/entry/open-locker', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    locker_number: Math.floor(Math.random() * 10) + 1
                })
            });

            const result = await response.json();
            this.addMessage('測試儲物柜指令已發送', 'info');
        } catch (error) {
            this.addMessage('測試儲物柜失敗: ' + error.message, 'error');
        }
    }

    async testPrinter() {
        try {
            const response = await fetch('/api/receipt/test-print', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    text: '測試打印 - 自動咖啡館系統\n' + new Date().toLocaleString('zh-TW')
                })
            });

            const result = await response.json();
            this.addMessage('打印機測試指令已發送', 'info');
        } catch (error) {
            this.addMessage('打印機測試失敗: ' + error.message, 'error');
        }
    }

    resetPrinter() {
        this.addMessage('打印機重置指令已發送', 'warning');
        // 實際環境中會發送硬件重置指令
    }

    testLockerSystem() {
        this.addMessage('儲物柜系統測試指令已發送', 'info');
        // 實際環境中會測試所有儲物柜
    }

    resetLockerSystem() {
        this.addMessage('儲物柜系統重置指令已發送', 'warning');
        // 實際環境中會重置儲物柜控制器
    }

    testAudio() {
        this.addMessage('播放歡迎音效', 'info');
        this.playWelcomeAudio();
    }

    stopAudio() {
        this.addMessage('停止音效播放', 'info');
        // 實際環境中會停止音頻播放
    }

    testMemberScan() {
        this.addMessage('會員 QR Code 掃描器測試中...', 'info');
        setTimeout(() => {
            this.addMessage('✓ QR Code 掃描器就緒', 'success');
        }, 500);
    }

    resetMemberReader() {
        this.addMessage('會員掃描器已重置', 'warning');
        this.hideMemberInfo();
        this.memberCardId = null;
        this.memberInfo = null;
        const qrInput = document.getElementById('member-qr-input');
        if (qrInput) {
            qrInput.value = '';
            qrInput.focus();
        }
    }

    playWelcomeAudio() {
        // 實際環境中會播放音頻文件
        this.addMessage('播放歡迎錄音', 'info');

        // 模擬音頻播放
        try {
            const AudioContextClass = window.AudioContext || window.webkitAudioContext;
            if (!AudioContextClass) {
                throw new Error('Web Audio API not supported');
            }
            const audioContext = new AudioContextClass();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();

            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);

            oscillator.frequency.value = 440;
            oscillator.type = 'sine';

            gainNode.gain.setValueAtTime(0, audioContext.currentTime);
            gainNode.gain.linearRampToValueAtTime(0.1, audioContext.currentTime + 0.1);
            gainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + 0.5);

            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.5);

            this.addMessage('歡迎錄音播放完成', 'success');
        } catch (error) {
            this.addMessage('音頻播放模擬失敗: ' + error.message, 'warning');
        }
    }

    systemCheck() {
        this.addMessage('開始系統檢查...', 'info');

        // 模擬系統檢查
        setTimeout(() => {
            this.addMessage('✓ 伺服器連線正常', 'success');
        }, 500);

        setTimeout(() => {
            this.addMessage('✓ 數據庫連線正常', 'success');
        }, 1000);

        setTimeout(() => {
            this.addMessage('✓ 設備連線檢查完成', 'success');
        }, 1500);

        setTimeout(() => {
            this.addMessage('系統檢查完成，所有功能正常', 'success');
        }, 2000);
    }

    emergencyStop() {
        if (confirm('確定要執行緊急停止嗎？這會中斷所有正在進行的操作。')) {
            this.addMessage('執行緊急停止程序...', 'error');

            // 實際環境中會停止所有設備和進程
            setTimeout(() => {
                this.addMessage('系統已緊急停止', 'error');
            }, 1000);
        }
    }

    cancelProcessing() {
        this.hideProcessingModal();
        this.addMessage('入場處理已取消', 'warning');
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// 初始化應用
document.addEventListener('DOMContentLoaded', () => {
    window.entryMachine = new EntryMachine();
});

// 添加一些CSS樣式到文檔中
const style = document.createElement('style');
style.textContent = `
    .status-active { color: #4CAF50; font-weight: 600; }
    .status-checked-out { color: #6c757d; }
`;
document.head.appendChild(style);