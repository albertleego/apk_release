#!/data/data/com.termux/files/usr/bin/bash
# 自動咖啡館系統 - 服務器啟動腳本
# 用法: bash start_server.sh

cd /data/data/com.termux/files/home

# 建立前台通知（需要安裝 Termux:API App 才有用，失敗則跳過）
if command -v termux-notification &> /dev/null; then
    termux-notification \
      --id cafe_server \
      --title "☕ 自動咖啡館系統" \
      --content "服務器正在監聽 :3000" \
      --priority high \
      --ongoing 2>/dev/null || true
fi

# 取得 CPU WakeLock，防止 Android 休眠時 CPU 停止運轉
echo "取得 WakeLock..."
termux-wake-lock cafe

# 設定離開時清除通知和 WakeLock
cleanup() {
    echo "清除通知和 WakeLock..."
    termux-notification-remove cafe_server 2>/dev/null
    termux-wake-lock 2>/dev/null  # 不帶參數 = 釋放
    exit 0
}
trap cleanup SIGINT SIGTERM

# 啟動服務器
echo "啟動服務器中... (使用 Ctrl+C 停止)"
echo "============================================================"
node server/index.js

# 服務器正常退出時也清理
cleanup
