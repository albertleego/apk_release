// 商品售賣機前端邏輯
class VendingMachine {
    // 翻譯字典
    static translations = {
        'zh-TW': {
            'scanPromptTitle': '購買零食請掃小票二維碼',
            'scanPromptMessage': '請使用掃描器掃描桌號QR Code',
            'scanManualPlaceholder': '或手動輸入QR Code',
            'scanManualBtn': '驗證',
            'startScanBtn': '開始掃描',
            'customerInfoTitle': '客人信息',
            'scanFirstMessage': '請先掃描QR Code',
            'productSelectionTitle': '商品選購',
            'categoryFilterLabel': '分類:',
            'categoryAll': '全部商品',
            'categoryDrink': '飲品',
            'categoryFood': '食品',
            'categoryDessert': '甜點',
            'sortFilterLabel': '排序:',
            'sortName': '名稱',
            'sortPriceLow': '價格低到高',
            'sortPriceHigh': '價格高到低',
            'sortPopular': '熱門商品',
            'loadProductsAfterScan': '請先掃描QR Code載入商品',
            'refreshProductsBtn': '刷新商品',
            'purchaseBtn': '購買',
            'productCountUnit': '個商品',
            'statusOnline': '連線中',
            'statusOffline': '離線中',
            'deviceStatusNormal': '設備狀態: 正常',
            'deviceStatusOffline': '設備狀態: 離線',
            'deviceStatusEmergencyStop': '設備狀態: 緊急停止',
            'noProductsAvailable': '暫無商品資料',
            'hotSelling': '熱賣',
            'noMatchingProducts': '沒有符合條件的商品',
            'stockLabel': '庫存:',
            'tableNumberLabel': '桌號:',
            'peopleCountLabel': '客人數:'
        },
        'zh-CN': {
            'scanPromptTitle': '购买零食请扫小票二维码',
            'scanPromptMessage': '请使用扫描器扫描桌号QR Code',
            'scanManualPlaceholder': '或手动输入QR Code',
            'scanManualBtn': '验证',
            'startScanBtn': '开始扫描',
            'customerInfoTitle': '客人信息',
            'scanFirstMessage': '请先扫描QR Code',
            'productSelectionTitle': '商品选购',
            'categoryFilterLabel': '分类:',
            'categoryAll': '全部商品',
            'categoryDrink': '饮品',
            'categoryFood': '食品',
            'categoryDessert': '甜点',
            'sortFilterLabel': '排序:',
            'sortName': '名称',
            'sortPriceLow': '价格低到高',
            'sortPriceHigh': '价格高到低',
            'sortPopular': '热门商品',
            'loadProductsAfterScan': '请先扫描QR Code加载商品',
            'refreshProductsBtn': '刷新商品',
            'purchaseBtn': '购买',
            'productCountUnit': '个商品',
            'statusOnline': '连线中',
            'statusOffline': '离线中',
            'deviceStatusNormal': '设备状态: 正常',
            'deviceStatusOffline': '设备状态: 离线',
            'deviceStatusEmergencyStop': '设备状态: 紧急停止',
            'noProductsAvailable': '暂无商品资料',
            'hotSelling': '热卖',
            'noMatchingProducts': '没有符合条件的商品',
            'stockLabel': '库存:',
            'tableNumberLabel': '桌号:',
            'peopleCountLabel': '客人数:'
        },
        'en': {
            'scanPromptTitle': 'Please scan receipt QR code to purchase snacks',
            'scanPromptMessage': 'Please use scanner to scan table QR Code',
            'scanManualPlaceholder': 'Or manually enter QR Code',
            'scanManualBtn': 'Verify',
            'startScanBtn': 'Start Scan',
            'customerInfoTitle': 'Customer Info',
            'scanFirstMessage': 'Please scan QR Code first',
            'productSelectionTitle': 'Product Selection',
            'categoryFilterLabel': 'Category:',
            'categoryAll': 'All Products',
            'categoryDrink': 'Drinks',
            'categoryFood': 'Food',
            'categoryDessert': 'Desserts',
            'sortFilterLabel': 'Sort:',
            'sortName': 'Name',
            'sortPriceLow': 'Price Low to High',
            'sortPriceHigh': 'Price High to Low',
            'sortPopular': 'Popular',
            'loadProductsAfterScan': 'Please scan QR Code to load products',
            'refreshProductsBtn': 'Refresh Products',
            'purchaseBtn': 'Purchase',
            'productCountUnit': 'products',
            'statusOnline': 'Online',
            'statusOffline': 'Offline',
            'deviceStatusNormal': 'Device Status: Normal',
            'deviceStatusOffline': 'Device Status: Offline',
            'deviceStatusEmergencyStop': 'Device Status: Emergency Stop',
            'noProductsAvailable': 'No products available',
            'hotSelling': 'Hot',
            'noMatchingProducts': 'No matching products',
            'stockLabel': 'Stock:',
            'tableNumberLabel': 'Table:',
            'peopleCountLabel': 'People:'
        }
    };

    constructor() {
        this.socket = null;
        this.customer = null;
        this.products = [];
        this.cartItems = [];
        this.currentQRCode = null;
        this.currentLanguage = 'zh-TW';
        this.init();
    }

    applyTranslations(lang) {
        const translations = VendingMachine.translations[lang];
        if (!translations) return;

        // 更新所有帶有 data-i18n 屬性的元素
        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n');
            if (translations[key]) {
                element.textContent = translations[key];
            }
        });

        // 更新所有帶有 data-i18n-placeholder 屬性的輸入框
        document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
            const key = element.getAttribute('data-i18n-placeholder');
            if (translations[key]) {
                element.placeholder = translations[key];
            }
        });
    }

    loadLanguagePreference() {
        const savedLang = localStorage.getItem('vending-machine-language');
        if (savedLang && VendingMachine.translations[savedLang]) {
            return savedLang;
        }
        return 'zh-TW';
    }

    setLanguage(lang) {
        // 更新語言按鈕狀態
        document.querySelectorAll('.language-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.lang === lang) {
                btn.classList.add('active');
            }
        });
        this.currentLanguage = lang;
        localStorage.setItem('vending-machine-language', lang);
        this.applyTranslations(lang);
        this.showMessage(`語言已切換為: ${lang}`, 'info');
    }

    async init() {
        // 初始化時間顯示
        this.updateTime();
        setInterval(() => this.updateTime(), 1000);

        // 連接Socket.IO
        this.connectSocket();

        // 綁定事件監聽器
        this.bindEvents();

        // 初始化語言
        this.currentLanguage = this.loadLanguagePreference();
        this.setLanguage(this.currentLanguage);

        // 初始化系統訊息
        console.log('商品售賣機啟動完成');
    }

    connectSocket() {
        this.socket = io();

        this.socket.on('connect', () => {
            this.updateStatus('online');
        });

        this.socket.on('disconnect', () => {
            this.updateStatus('offline');
        });

        this.socket.on('vending-purchase', (data) => {
            if (this.customer && this.customer.id === data.customer_id) {
                this.showLockerOpen(data.locker_number, data.product_name);
            }
        });
    }

    bindEvents() {
        // 語言選擇按鈕
        document.querySelectorAll('.language-btn').forEach(btn => {
            btn.addEventListener('click', () => this.setLanguage(btn.dataset.lang));
        });

        // QR Code掃描
        document.getElementById('start-scan-btn').addEventListener('click', () => this.startQRScan());
        document.getElementById('manual-qr-btn').addEventListener('click', () => this.manualQRScan());

        // 商品過濾器
        document.getElementById('category-filter').addEventListener('change', () => this.filterProducts());
        document.getElementById('sort-filter').addEventListener('change', () => this.sortProducts());

        // 商品控制
        document.getElementById('refresh-products-btn').addEventListener('click', () => this.loadProducts());
        document.getElementById('purchase-btn').addEventListener('click', () => this.showPurchaseModal());

        // 購買模態框
        document.getElementById('cancel-purchase-btn').addEventListener('click', () => this.hidePurchaseModal());
        document.getElementById('confirm-purchase-btn').addEventListener('click', () => this.confirmPurchase());
        document.getElementById('close-success-btn').addEventListener('click', () => this.hidePurchaseModal());

        // 系統控制
        document.getElementById('device-test-btn').addEventListener('click', () => this.deviceTest());
        document.getElementById('emergency-stop-btn').addEventListener('click', () => this.emergencyStop());
    }

    updateTime() {
        const now = new Date();
        // 根據當前語言選擇地區格式
        const localeMap = {
            'zh-TW': 'zh-TW',
            'zh-CN': 'zh-CN',
            'en': 'en-US'
        };
        const locale = localeMap[this.currentLanguage] || 'zh-TW';
        const timeString = now.toLocaleTimeString(locale);
        document.getElementById('current-time').textContent = timeString;
    }

    updateStatus(status) {
        const translations = VendingMachine.translations[this.currentLanguage];
        const statusBar = document.querySelector('.status-bar .status');
        if (status === 'online') {
            statusBar.classList.add('online');
            statusBar.innerHTML = `<i class="fas fa-wifi"></i><span>${translations.statusOnline}</span>`;
            document.getElementById('device-status').textContent = translations.deviceStatusNormal;
        } else {
            statusBar.classList.remove('online');
            statusBar.innerHTML = `<i class="fas fa-wifi"></i><span>${translations.statusOffline}</span>`;
            document.getElementById('device-status').textContent = translations.deviceStatusOffline;
        }
    }

    startQRScan() {
        // 模擬QR Code掃描過程
        // 生成測試QR Code
        const testQRCode = JSON.stringify({
            qr_code: 'CAFE-' + Date.now() + '-TEST',
            table_number: 'A' + (Math.floor(Math.random() * 10) + 1),
            customer_id: 'customer-test-' + Date.now()
        });

        this.processQRCode(testQRCode);
    }

    manualQRScan() {
        const qrInput = document.getElementById('manual-qr-input').value.trim();
        if (!qrInput) {
            alert('請輸入QR Code');
            return;
        }

        this.processQRCode(qrInput);
    }

    async processQRCode(qrCode) {
        try {
            const response = await fetch('/api/vending/scan', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ qr_code: qrCode })
            });

            const result = await response.json();

            if (result.success && result.valid) {
                this.customer = result.customer;
                this.currentQRCode = qrCode;
                this.displayCustomerInfo();
                this.loadProducts();
                this.updatePurchaseButton();
                this.showMessage('QR Code驗證成功', 'success');
            } else {
                this.clearCustomer();
                this.showMessage(result.error || 'QR Code無效', 'error');
            }
        } catch (error) {
            this.clearCustomer();
            this.showMessage('QR Code驗證失敗: ' + error.message, 'error');
        }
    }

    displayCustomerInfo() {
        const translations = VendingMachine.translations[this.currentLanguage];
        const customerInfo = document.getElementById('customer-info');

        customerInfo.innerHTML = `
            <div class="customer-detail">
                <div class="detail-row">
                    <span class="detail-label">${translations.tableNumberLabel}</span>
                    <span class="detail-value">${this.customer.table_number}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">${translations.peopleCountLabel}</span>
                    <span class="detail-value">${this.customer.people_count}</span>
                </div>
            </div>
        `;

        // 切換卡片顯示：隱藏掃描提示卡片，顯示客人信息與商品選購面板
        document.getElementById('scan-prompt-card').classList.add('hidden');
        document.getElementById('bottom-panels').classList.remove('hidden');
    }

    clearCustomer() {
        const translations = VendingMachine.translations[this.currentLanguage];
        this.customer = null;
        this.products = [];
        this.cartItems = [];

        document.getElementById('customer-info').innerHTML = `
            <div class="empty-state">
                <i class="fas fa-user-circle"></i>
                <p>${translations.scanFirstMessage}</p>
            </div>
        `;

        document.getElementById('product-grid').innerHTML = `
            <div class="empty-state">
                <i class="fas fa-box-open"></i>
                <p>${translations.loadProductsAfterScan}</p>
            </div>
        `;

        // 切換卡片顯示：顯示掃描提示卡片，隱藏客人信息與商品選購面板
        document.getElementById('scan-prompt-card').classList.remove('hidden');
        document.getElementById('bottom-panels').classList.add('hidden');

        this.updateProductCount();
        this.updatePurchaseButton();
    }

    async loadProducts() {
        if (!this.customer) {
            return;
        }

        try {
            const response = await fetch('/api/vending/scan', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ qr_code: this.currentQRCode })
            });

            const result = await response.json();

            if (result.success && result.valid) {
                this.products = result.products;
                this.displayProducts();
                this.updateProductCount();
            }
        } catch (error) {
            console.error('載入商品失敗:', error);
        }
    }

    displayProducts() {
        const translations = VendingMachine.translations[this.currentLanguage];
        const productGrid = document.getElementById('product-grid');

        if (this.products.length === 0) {
            productGrid.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-box-open"></i>
                    <p>${translations.noProductsAvailable}</p>
                </div>
            `;
            return;
        }

        productGrid.innerHTML = '';

        this.products.forEach(product => {
            const productEl = document.createElement('div');
            productEl.className = `product-item ${product.stock <= 0 ? 'out-of-stock' : ''}`;
            productEl.dataset.productId = product.id;
            productEl.dataset.productName = product.name;
            productEl.dataset.productPrice = product.price;
            productEl.dataset.productStock = product.stock;
            productEl.dataset.lockerNumber = product.locker_number;

            // 獲取當前商品在購物車中的數量
            const cartItem = this.cartItems.find(item => item.id === product.id);
            const currentQuantity = cartItem ? cartItem.quantity : 0;

            // 添加熱門商品標籤
            const isPopular = product.stock < 10;
            const badge = isPopular ? `<div class="badge">${translations.hotSelling}</div>` : '';

            productEl.innerHTML = `
                ${badge}
                <div class="product-name">${product.name}</div>
                <div class="product-price">$${product.price}</div>
                <div class="product-stock">${translations.stockLabel} ${product.stock}</div>
                <div class="product-action">
                    <div class="quantity-controls">
                        <button class="btn-quantity btn-decrease" ${currentQuantity <= 0 ? 'disabled' : ''} data-product-id="${product.id}">
                            <i class="fas fa-minus"></i>
                        </button>
                        <span class="quantity-display">${currentQuantity}</span>
                        <button class="btn-quantity btn-increase" ${product.stock <= 0 || currentQuantity >= product.stock ? 'disabled' : ''} data-product-id="${product.id}">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                </div>
            `;

            // 為按鈕添加事件監聽器
            const decreaseBtn = productEl.querySelector('.btn-decrease');
            const increaseBtn = productEl.querySelector('.btn-increase');

            if (product.stock > 0) {
                decreaseBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.adjustQuantity(product, -1);
                });

                increaseBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.adjustQuantity(product, 1);
                });
            }

            productGrid.appendChild(productEl);
        });
    }

    filterProducts() {
        const category = document.getElementById('category-filter').value;
        const sort = document.getElementById('sort-filter').value;

        let filteredProducts = [...this.products];

        // 分類過濾（簡化實現）
        if (category !== 'all') {
            // 這裡可以根據實際商品分類進行過濾
            filteredProducts = filteredProducts.filter(product =>
                product.name.includes(category === 'drink' ? '咖啡' :
                                     category === 'food' ? '蛋糕' :
                                     category === 'dessert' ? '甜點' : '')
            );
        }

        // 排序
        switch(sort) {
            case 'price-low':
                filteredProducts.sort((a, b) => a.price - b.price);
                break;
            case 'price-high':
                filteredProducts.sort((a, b) => b.price - a.price);
                break;
            case 'name':
                filteredProducts.sort((a, b) => a.name.localeCompare(b.name, 'zh-TW'));
                break;
            case 'popular':
                filteredProducts.sort((a, b) => (b.stock < 10 ? 1 : 0) - (a.stock < 10 ? 1 : 0));
                break;
        }

        // 重新顯示過濾後的商品
        this.displayFilteredProducts(filteredProducts);
    }

    displayFilteredProducts(products) {
        const translations = VendingMachine.translations[this.currentLanguage];
        const productGrid = document.getElementById('product-grid');

        if (products.length === 0) {
            productGrid.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-box-open"></i>
                    <p>${translations.noMatchingProducts}</p>
                </div>
            `;
            return;
        }

        productGrid.innerHTML = '';

        products.forEach(product => {
            const productEl = document.createElement('div');
            productEl.className = `product-item ${product.stock <= 0 ? 'out-of-stock' : ''}`;
            productEl.dataset.productId = product.id;
            productEl.dataset.productName = product.name;
            productEl.dataset.productPrice = product.price;
            productEl.dataset.productStock = product.stock;
            productEl.dataset.lockerNumber = product.locker_number;

            // 獲取當前商品在購物車中的數量
            const cartItem = this.cartItems.find(item => item.id === product.id);
            const currentQuantity = cartItem ? cartItem.quantity : 0;

            const isPopular = product.stock < 10;
            const badge = isPopular ? `<div class="badge">${translations.hotSelling}</div>` : '';

            productEl.innerHTML = `
                ${badge}
                <div class="product-name">${product.name}</div>
                <div class="product-price">$${product.price}</div>
                <div class="product-stock">${translations.stockLabel} ${product.stock}</div>
                <div class="product-action">
                    <div class="quantity-controls">
                        <button class="btn-quantity btn-decrease" ${currentQuantity <= 0 ? 'disabled' : ''} data-product-id="${product.id}">
                            <i class="fas fa-minus"></i>
                        </button>
                        <span class="quantity-display">${currentQuantity}</span>
                        <button class="btn-quantity btn-increase" ${product.stock <= 0 || currentQuantity >= product.stock ? 'disabled' : ''} data-product-id="${product.id}">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                </div>
            `;

            // 為按鈕添加事件監聽器
            const decreaseBtn = productEl.querySelector('.btn-decrease');
            const increaseBtn = productEl.querySelector('.btn-increase');

            if (product.stock > 0) {
                decreaseBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.adjustQuantity(product, -1);
                });

                increaseBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.adjustQuantity(product, 1);
                });
            }

            productGrid.appendChild(productEl);
        });
    }

    sortProducts() {
        this.filterProducts(); // 重用過濾邏輯
    }

    adjustQuantity(product, delta) {
        if (!this.customer) {
            this.showMessage('請先掃描QR Code', 'warning');
            return;
        }

        if (product.stock <= 0) {
            this.showMessage('商品庫存不足', 'warning');
            return;
        }

        // 檢查購物車是否已有此商品
        const existingItem = this.cartItems.find(item => item.id === product.id);

        if (delta > 0) { // 增加數量
            if (product.stock <= 0) {
                this.showMessage('商品庫存不足', 'warning');
                return;
            }

            // 檢查是否超過庫存
            const currentQuantity = existingItem ? existingItem.quantity : 0;
            if (currentQuantity >= product.stock) {
                this.showMessage('已達到最大庫存量', 'warning');
                return;
            }

            if (existingItem) {
                existingItem.quantity += delta;
            } else {
                this.cartItems.push({
                    id: product.id,
                    name: product.name,
                    price: product.price,
                    quantity: delta,
                    locker_number: product.locker_number
                });
            }

            this.showMessage(`已增加 ${product.name} 數量`, 'success');
        } else if (delta < 0) { // 減少數量
            if (!existingItem || existingItem.quantity <= 0) {
                return;
            }

            existingItem.quantity += delta; // delta為負數

            // 如果數量變為0或以下，從購物車移除
            if (existingItem.quantity <= 0) {
                const index = this.cartItems.indexOf(existingItem);
                this.cartItems.splice(index, 1);
                this.showMessage(`已移除 ${product.name}`, 'info');
            } else {
                this.showMessage(`已減少 ${product.name} 數量`, 'info');
            }
        }

        // 更新購買按鈕狀態
        this.updatePurchaseButton();

        // 重新顯示商品以更新數量顯示
        this.displayProducts();
    }





    updateProductCount() {
        const availableCount = this.products.filter(p => p.stock > 0).length;
        document.getElementById('available-products').textContent = availableCount;
        document.getElementById('product-count').textContent = `${this.products.length} 個商品`;
    }

    updatePurchaseButton() {
        const hasCustomer = !!this.customer;
        const hasCartItems = this.cartItems.length > 0;
        const purchaseBtn = document.getElementById('purchase-btn');
        if (purchaseBtn) {
            purchaseBtn.disabled = !hasCustomer || !hasCartItems;
        }
    }

    showPurchaseModal() {
        if (!this.customer || this.cartItems.length === 0) {
            return;
        }

        // 重置模態框顯示狀態
        document.getElementById('purchase-confirmation-info').classList.remove('hidden');
        document.getElementById('locker-info-section').classList.remove('hidden');
        document.getElementById('purchase-success-message').classList.add('hidden');
        document.querySelector('.modal-footer').classList.remove('hidden');

        // 更新模態框內容
        document.getElementById('purchase-table').textContent = this.customer.table_number;

        const itemNames = this.cartItems.map(item => `${item.name} x${item.quantity}`).join(', ');
        document.getElementById('purchase-items').textContent = itemNames;

        const totalAmount = this.cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        document.getElementById('purchase-amount').textContent = `$${totalAmount.toFixed(2)}`;

        // 顯示將要開啟的儲物柜
        const lockers = this.cartItems.map(item => item.locker_number).filter((v, i, a) => a.indexOf(v) === i);
        document.getElementById('locker-display').innerHTML = `
            <div class="locker-light"></div>
            <span>儲物柜 ${lockers.join(', ')} 即將開啟</span>
        `;

        // 顯示模態框
        document.getElementById('purchase-modal').classList.remove('hidden');
    }

    hidePurchaseModal() {
        document.getElementById('purchase-modal').classList.add('hidden');
    }

    async confirmPurchase() {
        if (!this.customer || this.cartItems.length === 0) {
            return;
        }

        try {
            // 逐一購買每個商品
            const purchasePromises = this.cartItems.map(item =>
                fetch('/api/vending/purchase', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        customer_id: this.customer.id,
                        product_id: item.id,
                        quantity: item.quantity
                    })
                })
            );

            const responses = await Promise.all(purchasePromises);
            const results = await Promise.all(responses.map(r => r.json()));

            // 檢查所有購買是否成功
            const allSuccess = results.every(r => r.success);

            if (allSuccess) {
                this.showMessage('購買成功！儲物柜已開啟', 'success');

                // 顯示成功訊息
                const successLockerNumbers = [...new Set(this.cartItems.map(item => item.locker_number))];
                document.getElementById('success-locker-number').textContent = successLockerNumbers.join(', ');

                // 切換模態框顯示：隱藏購買資訊，顯示成功訊息
                document.getElementById('purchase-confirmation-info').classList.add('hidden');
                document.getElementById('locker-info-section').classList.add('hidden');
                document.getElementById('purchase-success-message').classList.remove('hidden');
                document.querySelector('.modal-footer').classList.add('hidden');

                // 更新商品庫存
                this.loadProducts();

                // 清空購物車
                this.cartItems = [];
                this.updatePurchaseButton();
            } else {
                this.showMessage('部分商品購買失敗', 'error');
            }

        } catch (error) {
            this.showMessage('購買失敗: ' + error.message, 'error');
        }
    }

    showLockerOpen(lockerNumber, productName) {
        this.showMessage(`儲物柜 ${lockerNumber} 已開啟，請取走 ${productName}`, 'success');

        // 顯示儲物柜開啟通知
        const notification = document.createElement('div');
        notification.className = 'locker-notification';
        notification.innerHTML = `
            <i class="fas fa-door-open"></i>
            <span>儲物柜 ${lockerNumber} 已開啟</span>
            <p>請取走 ${productName}</p>
        `;

        document.body.appendChild(notification);

        // 5秒後移除通知
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }

    showMessage(text, type = 'info') {
        // 簡單的訊息顯示
        console.log(`${type}: ${text}`);

        // 可以擴展為更完整的訊息系統
        const messageTypes = {
            'info': { color: '#3498db', icon: 'info-circle' },
            'success': { color: '#4CAF50', icon: 'check-circle' },
            'warning': { color: '#f39c12', icon: 'exclamation-triangle' },
            'error': { color: '#e74c3c', icon: 'times-circle' }
        };

        const msgType = messageTypes[type] || messageTypes.info;

        // 顯示在控制台或擴展為UI通知
        if (type === 'error') {
            console.error(text);
        } else if (type === 'warning') {
            console.warn(text);
        } else {
            console.log(text);
        }
    }

    deviceTest() {
        this.showMessage('開始設備測試...', 'info');

        // 模擬設備測試
        setTimeout(() => {
            this.showMessage('✓ 儲物柜系統測試完成', 'success');
        }, 1000);

        setTimeout(() => {
            this.showMessage('✓ QR Code掃描器測試完成', 'success');
        }, 2000);

        setTimeout(() => {
            this.showMessage('✓ 網絡連接測試完成', 'success');
        }, 3000);

        setTimeout(() => {
            this.showMessage('設備測試完成，所有功能正常', 'success');
        }, 4000);
    }

    emergencyStop() {
        const translations = VendingMachine.translations[this.currentLanguage];
        if (confirm('確定要執行緊急停止嗎？這會中斷所有正在進行的操作。')) {
            this.showMessage('執行緊急停止程序...', 'error');

            // 清空所有狀態
            this.clearCustomer();

            // 顯示停止狀態
            document.getElementById('device-status').textContent = translations.deviceStatusEmergencyStop;

            setTimeout(() => {
                this.showMessage('系統已緊急停止', 'error');
            }, 1000);
        }
    }
}

// 初始化應用
document.addEventListener('DOMContentLoaded', () => {
    window.vendingMachine = new VendingMachine();
});