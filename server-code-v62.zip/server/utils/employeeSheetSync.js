/**
 * 員工名單同步模組
 *
 * 每天香港時間 3:00 AM 從 Google Sheet 取得各分店員工名單
 * Google Sheet: https://docs.google.com/spreadsheets/d/1olCjDfHp6tG6KwcoI_kjeYoHnFbHaEv9j2eANe7juag/edit
 * 分頁: "今日各店員工"
 *
 * 格式:
 *   Row 1: 分店名稱 (store_1, store_2, ...)
 *   Row 2: 員工人數
 *   Row 3+: 員工名字
 */

const axios = require('axios');
const { db } = require('../../database/db');
const { v4: uuidv4 } = require('uuid');

const SPREADSHEET_ID = '1olCjDfHp6tG6KwcoI_kjeYoHnFbHaEv9j2eANe7juag';
const SHEET_NAME = '今日各店員工';
const CSV_URL = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/gviz/tq?tqx=out:csv&sheet=${encodeURIComponent(SHEET_NAME)}`;

/**
 * 從 Google Sheet 取得 CSV 資料並解析
 */
async function fetchEmployeeSheet() {
  console.log(`[EmployeeSheetSync] 開始取得 Google Sheet 員工資料...`);
  console.log(`[EmployeeSheetSync] URL: ${CSV_URL}`);

  const response = await axios.get(CSV_URL, {
    timeout: 30000,
    responseType: 'text'
  });

  const csvData = response.data;
  console.log(`[EmployeeSheetSync] 收到 CSV 資料 (${csvData.length} bytes)`);

  return parseEmployeeCSV(csvData);
}

/**
 * 解析 CSV 格式的員工資料
 * Row 1: 分店名稱 (headers)
 * Row 2: 各分店員工人數
 * Row 3+: 員工名字 (每列垂直排列)
 */
function parseEmployeeCSV(csvText) {
  // 處理 CSV，支援引號包圍的欄位
  const lines = [];
  let currentLine = [];
  let currentField = '';
  let inQuotes = false;

  for (let i = 0; i < csvText.length; i++) {
    const char = csvText[i];
    const nextChar = csvText[i + 1];

    if (inQuotes) {
      if (char === '"' && nextChar === '"') {
        currentField += '"';
        i++;
      } else if (char === '"') {
        inQuotes = false;
      } else {
        currentField += char;
      }
    } else {
      if (char === '"') {
        inQuotes = true;
      } else if (char === ',') {
        currentLine.push(currentField.trim());
        currentField = '';
      } else if (char === '\n' || (char === '\r' && nextChar === '\n')) {
        if (char === '\r') i++; // skip \n after \r
        currentLine.push(currentField.trim());
        lines.push(currentLine);
        currentLine = [];
        currentField = '';
      } else if (char === '\r') {
        currentLine.push(currentField.trim());
        lines.push(currentLine);
        currentLine = [];
        currentField = '';
      } else {
        currentField += char;
      }
    }
  }
  // 最後一行
  if (currentField.trim() || currentLine.length > 0) {
    currentLine.push(currentField.trim());
    lines.push(currentLine);
  }

  if (lines.length < 3) {
    console.error(`[EmployeeSheetSync] CSV 行數不足: ${lines.length} (需要至少 3 行)`);
    return [];
  }

  const headers = lines[0]; // Row 1: 分店名稱
  const counts = lines[1];  // Row 2: 員工人數

  console.log(`[EmployeeSheetSync] 找到 ${headers.length} 個分店欄位`);
  console.log(`[EmployeeSheetSync] 分店名稱: ${JSON.stringify(headers)}`);
  console.log(`[EmployeeSheetSync] 員工人數: ${JSON.stringify(counts)}`);

  const result = [];

  for (let col = 0; col < headers.length; col++) {
    const storeName = (headers[col] || '').trim();
    const employeeCount = parseInt(counts[col]) || 0;

    if (!storeName || employeeCount <= 0) continue;

    // 取得該分店的員工名字 (從 Row 3 開始)
    const employees = [];
    for (let row = 2; row < 2 + employeeCount && row < lines.length; row++) {
      const name = (lines[row][col] || '').trim();
      if (name) {
        employees.push(name);
      }
    }

    console.log(`[EmployeeSheetSync] 分店 "${storeName}": ${employees.length} 位員工`);

    // 嘗試將 sheet 中的分店名稱對應到系統中的 store_id
    // 先查詢 stores 表，比對 store_name 或 store_code
    result.push({
      storeIdentifier: storeName,
      employees
    });
  }

  return result;
}

/**
 * 將員工資料存入資料庫
 */
async function saveEmployeesToDB(storeEmployeeData) {
  console.log(`[EmployeeSheetSync] 儲存員工資料到資料庫...`);

  // 獲取系統中的所有分店列表
  const stores = await new Promise((resolve, reject) => {
    db.all('SELECT id, store_name, store_code FROM stores WHERE is_active = 1', (err, rows) => {
      if (err) reject(err);
      else resolve(rows || []);
    });
  });

  console.log(`[EmployeeSheetSync] 系統分店: ${JSON.stringify(stores.map(s => ({ id: s.id, name: s.store_name, code: s.store_code })))}`);

  let totalSaved = 0;

  for (const item of storeEmployeeData) {
    // 嘗試匹配分店
    const identifier = item.storeIdentifier.toLowerCase().replace(/[\s_-]/g, '');

    // 先嘗試完全匹配 store_name 或 store_code
    let matchedStore = stores.find(s =>
      s.store_name.replace(/[\s_-]/g, '').toLowerCase() === identifier ||
      (s.store_code || '').replace(/[\s_-]/g, '').toLowerCase() === identifier ||
      s.id.replace(/[\s_-]/g, '').toLowerCase() === identifier
    );

    // 如果沒有完全匹配，嘗試部分匹配
    if (!matchedStore) {
      matchedStore = stores.find(s =>
        s.store_name.toLowerCase().includes(item.storeIdentifier.toLowerCase()) ||
        item.storeIdentifier.toLowerCase().includes(s.store_name.toLowerCase()) ||
        s.id.includes(item.storeIdentifier)
      );
    }

    if (!matchedStore) {
      console.warn(`[EmployeeSheetSync] 找不到對應分店: "${item.storeIdentifier}"，使用原名稱作為 store_id 嘗試`);
    }

    const storeId = matchedStore ? matchedStore.id : item.storeIdentifier;

    // 刪除該分店舊的員工資料
    await new Promise((resolve, reject) => {
      db.run('DELETE FROM store_checkout_staff WHERE store_id = ?', [storeId], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    // 插入新的員工資料
    for (const name of item.employees) {
      await new Promise((resolve, reject) => {
        const id = uuidv4();
        db.run(
          'INSERT INTO store_checkout_staff (id, store_id, staff_name) VALUES (?, ?, ?)',
          [id, storeId, name],
          (err) => {
            if (err) reject(err);
            else resolve();
          }
        );
      });
      totalSaved++;
    }

    const matchedName = matchedStore ? `${matchedStore.store_name} (${matchedStore.id})` : item.storeIdentifier;
    console.log(`[EmployeeSheetSync] ${matchedName}: 已儲存 ${item.employees.length} 位員工`);
  }

  console.log(`[EmployeeSheetSync] 總共儲存 ${totalSaved} 位員工到 ${storeEmployeeData.length} 個分店`);
  return totalSaved;
}

/**
 * 執行一次完整的員工資料同步
 */
async function syncEmployeeSheet() {
  try {
    console.log(`\n========== 員工名單同步開始 ==========`);
    console.log(`時間: ${new Date().toLocaleString('zh-TW', { timeZone: 'Asia/Hong_Kong' })}`);

    const storeData = await fetchEmployeeSheet();

    if (storeData.length === 0) {
      console.warn(`[EmployeeSheetSync] 沒有取得任何員工資料，跳過儲存`);
      return { success: false, count: 0, message: '沒有取得員工資料' };
    }

    const totalSaved = await saveEmployeesToDB(storeData);

    console.log(`[EmployeeSheetSync] 同步完成，共 ${totalSaved} 位員工`);
    console.log(`========== 員工名單同步結束 ==========\n`);

    return { success: true, count: totalSaved };
  } catch (error) {
    console.error(`[EmployeeSheetSync] 同步失敗:`, error.message);
    if (error.response) {
      console.error(`[EmployeeSheetSync] HTTP ${error.response.status}: ${error.response.statusText}`);
    }
    return { success: false, count: 0, message: error.message };
  }
}

/**
 * 計算下次 3:00 AM 香港時間的延遲（毫秒）
 * 注意：server/index.js 已設置 process.env.TZ = 'Asia/Hong_Kong'
 * 所以 new Date() 直接在 HK 時區操作即可
 */
function getNextSyncDelay() {
  const now = new Date();
  const target = new Date(now);

  // 今天的 3:00 AM (setHours 在 TZ=HK 環境中操作 HK 時間)
  target.setHours(3, 0, 0, 0);

  // 如果已經過了今天的 3:00 AM，設定為明天的
  if (now >= target) {
    target.setDate(target.getDate() + 1);
  }

  const delay = target.getTime() - now.getTime();

  console.log(`[EmployeeSheetSync] 下次同步時間: ${target.toLocaleString('zh-TW', { timeZone: 'Asia/Hong_Kong' })}`);
  console.log(`[EmployeeSheetSync] 距離現在: ${Math.round(delay / 1000 / 60)} 分鐘`);

  return delay;
}

/**
 * 啟動週期性同步排程
 * 每天香港時間 3:00 AM 執行一次
 */
function startEmployeeSyncSchedule() {
  console.log(`\n[EmployeeSheetSync] 初始化員工名單同步排程...`);
  console.log(`[EmployeeSheetSync] 目標: 每天香港時間 3:00 AM`);

  // 排程函數：執行一次後排程下一次
  function scheduleNext() {
    const delay = getNextSyncDelay();

    setTimeout(async () => {
      console.log(`[EmployeeSheetSync] 排程觸發：開始同步員工名單`);
      await syncEmployeeSheet();
      scheduleNext();  // 排程下一次
    }, delay);
  }

  // 啟動時先執行一次（用於測試/啟動時立即同步）
  // 然後排程下一次 3:00 AM
  console.log(`[EmployeeSheetSync] 啟動時先執行一次同步...`);

  const initialDelay = 5000; // 啟動後 5 秒執行第一次
  setTimeout(async () => {
    await syncEmployeeSheet();
    scheduleNext();  // 排程下一次 3:00 AM
  }, initialDelay);
}

module.exports = {
  syncEmployeeSheet,
  startEmployeeSyncSchedule
};
