const EventEmitter = require('events');
const path = require('path');
const fs = require('fs').promises;

/**
 * 同步服務管理器
 * 支持兩種模式：
 * 1. 服務器模式：中央服務器，接收和分發各分店的同步請求
 * 2. 客戶端模式：分店本地，定期與中央服務器同步數據
 */
class SyncManager extends EventEmitter {
    constructor(config = {}) {
        super();

        this.config = {
            mode: config.mode || 'server', // 'server' 或 'client'
            storeId: config.storeId || 'default_store',
            syncInterval: config.syncInterval || 30000, // 同步間隔（毫秒）
            apiEndpoint: config.apiEndpoint || 'http://localhost:3000/api/sync',
            localDbPath: config.localDbPath || './database/cafe.db',
            ...config
        };

        this.isRunning = false;
        this.syncTimer = null;
        this.lastSyncTime = null;
        this.syncStats = {
            totalSyncs: 0,
            successfulSyncs: 0,
            failedSyncs: 0,
            lastError: null
        };

        // 註冊的表配置
        this.registeredTables = {};

        // 衝突解決器
        this.conflictResolver = null;

        console.log(`SyncManager 初始化: 模式=${this.config.mode}, 分店=${this.config.storeId}`);
    }

    /**
     * 註冊要同步的表
     * @param {string} tableName 表名
     * @param {Object} config 表配置
     */
    registerTable(tableName, config = {}) {
        const defaultConfig = {
            primaryKey: 'id',
            timestampField: 'updated_at',
            createTimestampField: 'created_at',
            conflictResolution: 'last_write_wins', // 衝突解決策略
            syncDirection: 'bidirectional', // 同步方向: upload_only, download_only, bidirectional
            excludeFields: [], // 不同步的字段
            transform: null, // 數據轉換函數
            ...config
        };

        this.registeredTables[tableName] = defaultConfig;
        console.log(`已註冊表 ${tableName} 用於同步`);

        return this;
    }

    /**
     * 設置衝突解決器
     * @param {Object} resolver 衝突解決器實例
     */
    setConflictResolver(resolver) {
        this.conflictResolver = resolver;
        return this;
    }

    /**
     * 啟動同步服務
     */
    async start() {
        if (this.isRunning) {
            console.warn('同步服務已在運行中');
            return;
        }

        console.log('啟動同步服務...');

        try {
            // 初始化同步狀態
            await this.initializeSyncState();

            // 根據模式執行不同初始化
            if (this.config.mode === 'client') {
                await this.initializeClientMode();
            } else {
                await this.initializeServerMode();
            }

            this.isRunning = true;

            // 啟動定時同步（僅客戶端模式）
            if (this.config.mode === 'client') {
                this.startPeriodicSync();
            }

            this.emit('started', { mode: this.config.mode, storeId: this.config.storeId });
            console.log('同步服務啟動成功');

        } catch (error) {
            console.error('啟動同步服務失敗:', error);
            this.emit('error', error);
            throw error;
        }
    }

    /**
     * 停止同步服務
     */
    stop() {
        if (!this.isRunning) {
            return;
        }

        console.log('停止同步服務...');

        // 清除定時器
        if (this.syncTimer) {
            clearInterval(this.syncTimer);
            this.syncTimer = null;
        }

        this.isRunning = false;
        this.emit('stopped');
        console.log('同步服務已停止');
    }

    /**
     * 初始化同步狀態
     */
    async initializeSyncState() {
        console.log('初始化同步狀態...');

        // 創建同步狀態表（如果不存在）
        // 這會在數據庫初始化時完成，這裡只是確保

        // 檢查最後同步時間
        this.lastSyncTime = await this.getLastSyncTime();
        console.log(`最後同步時間: ${this.lastSyncTime || '從未同步過'}`);
    }

    /**
     * 初始化客戶端模式
     */
    async initializeClientMode() {
        console.log('初始化客戶端模式...');

        // 驗證本地數據庫連接
        await this.verifyLocalDatabase();

        // 註冊默認表
        this.registerDefaultTables();

        // 立即執行一次同步（可選）
        // await this.syncNow();
    }

    /**
     * 初始化服務器模式
     */
    async initializeServerMode() {
        console.log('初始化服務器模式...');

        // 服務器模式不需要定時同步
        // 只需準備好接收客戶端請求
        console.log('服務器模式就緒，等待客戶端同步請求');
    }

    /**
     * 驗證本地數據庫連接
     */
    async verifyLocalDatabase() {
        // 這裡應該檢查數據庫文件是否存在，表結構是否正確
        // 簡單實現：檢查文件是否存在
        try {
            await fs.access(this.config.localDbPath);
            console.log(`本地數據庫文件存在: ${this.config.localDbPath}`);
        } catch (error) {
            console.warn(`本地數據庫文件不存在: ${this.config.localDbPath}`);
            // 可以嘗試創建數據庫文件
        }
    }

    /**
     * 註冊默認表（根據業務需求）
     */
    registerDefaultTables() {
        // 客戶相關表
        this.registerTable('customers', {
            conflictResolution: 'client_wins', // 客戶數據以本地為準
            syncDirection: 'bidirectional'
        });

        // 商品相關表
        this.registerTable('products', {
            conflictResolution: 'server_wins', // 商品信息以服務器為準
            syncDirection: 'bidirectional'
        });

        // 訂單相關表
        this.registerTable('order_items', {
            conflictResolution: 'merge', // 訂單數據合併
            syncDirection: 'upload_only' // 訂單只上傳，不下載
        });

        // 交易記錄
        this.registerTable('transactions', {
            conflictResolution: 'client_wins',
            syncDirection: 'upload_only'
        });

        console.log(`已註冊 ${Object.keys(this.registeredTables).length} 個默認表`);
    }

    /**
     * 啟動定時同步
     */
    startPeriodicSync() {
        console.log(`啟動定時同步，間隔: ${this.config.syncInterval}ms`);

        this.syncTimer = setInterval(async () => {
            try {
                await this.syncNow();
            } catch (error) {
                console.error('定時同步失敗:', error);
                this.syncStats.failedSyncs++;
                this.syncStats.lastError = error.message;
                this.emit('syncError', error);
            }
        }, this.config.syncInterval);

        // 第一次同步延遲5秒開始
        setTimeout(async () => {
            try {
                await this.syncNow();
            } catch (error) {
                console.error('首次同步失敗:', error);
            }
        }, 5000);
    }

    /**
     * 立即執行同步
     */
    async syncNow() {
        if (!this.isRunning) {
            throw new Error('同步服務未啟動');
        }

        console.log('開始同步...');
        this.emit('syncStarted', { timestamp: new Date() });

        const startTime = Date.now();
        let success = false;

        try {
            // 1. 檢測本地變更
            const localChanges = await this.detectLocalChanges();

            // 2. 上傳變更到服務器
            if (localChanges.length > 0) {
                await this.uploadChanges(localChanges);
            }

            // 3. 從服務器下載變更
            const remoteChanges = await this.downloadChanges();

            // 4. 應用遠程變更到本地
            if (remoteChanges.length > 0) {
                await this.applyRemoteChanges(remoteChanges);
            }

            // 5. 更新同步狀態
            await this.updateSyncState();

            success = true;
            this.syncStats.successfulSyncs++;

            const duration = Date.now() - startTime;
            console.log(`同步完成: 上傳${localChanges.length}條，下載${remoteChanges.length}條，耗時${duration}ms`);
            this.emit('syncCompleted', {
                timestamp: new Date(),
                duration,
                uploaded: localChanges.length,
                downloaded: remoteChanges.length,
                success: true
            });

        } catch (error) {
            console.error('同步失敗:', error);
            this.syncStats.failedSyncs++;
            this.syncStats.lastError = error.message;
            this.emit('syncError', error);
            throw error;
        } finally {
            this.syncStats.totalSyncs++;
            this.lastSyncTime = new Date();
        }

        return success;
    }

    /**
     * 檢測本地變更
     */
    async detectLocalChanges() {
        console.log('檢測本地變更...');

        // 這裡應該實現具體的變更檢測邏輯
        // 簡化實現：返回空數組
        return [];
    }

    /**
     * 上傳變更到服務器
     */
    async uploadChanges(changes) {
        console.log(`上傳 ${changes.length} 條變更到服務器...`);

        // 這裡應該實現上傳邏輯
        // 簡化實現
        // 實際應該發送HTTP請求到中央服務器

        return { success: true, uploaded: changes.length };
    }

    /**
     * 從服務器下載變更
     */
    async downloadChanges() {
        console.log('從服務器下載變更...');

        // 這裡應該實現下載邏輯
        // 簡化實現：返回空數組
        return [];
    }

    /**
     * 應用遠程變更到本地
     */
    async applyRemoteChanges(changes) {
        console.log(`應用 ${changes.length} 條遠程變更到本地...`);

        // 這裡應該實現應用變更邏輯
        // 需要處理衝突

        return { success: true, applied: changes.length };
    }

    /**
     * 更新同步狀態
     */
    async updateSyncState() {
        // 更新最後同步時間等狀態信息
        // 簡化實現
    }

    /**
     * 獲取最後同步時間
     */
    async getLastSyncTime() {
        // 從數據庫或文件中讀取最後同步時間
        // 簡化實現
        return null;
    }

    /**
     * 獲取同步統計信息
     */
    getStats() {
        return {
            ...this.syncStats,
            isRunning: this.isRunning,
            lastSyncTime: this.lastSyncTime,
            nextSyncTime: this.syncTimer ? new Date(Date.now() + this.config.syncInterval) : null,
            registeredTables: Object.keys(this.registeredTables)
        };
    }

    /**
     * 手動觸發同步（用於測試或特殊情況）
     */
    async triggerSync() {
        console.log('手動觸發同步...');
        return await this.syncNow();
    }
}

module.exports = SyncManager;