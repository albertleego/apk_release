const express = require('express');
const router = express.Router();
const ThermalPrinter = require('node-thermal-printer').printer;
const PrinterTypes = require('node-thermal-printer').types;
const storeAwareMiddleware = require('../middleware/store-aware');
const authMiddleware = require('../middleware/auth');
const { db } = require('../../database/db');
const { v4: uuidv4 } = require('uuid');
const QRCode = require('qrcode');
const RawPrinter = require('../printer-raw');

// 打印機系統配置
const PRINTER_CONFIG = {
  // 基本配置
  DEVICE_ID: 'receipt-printer-001',
  DEFAULT_TYPE: 'epson',
  MAX_PRINT_QUEUE: 10,
  PRINT_TIMEOUT_MS: 30000,
  HEARTBEAT_INTERVAL_MS: 30000,

  // 紙張監控
  PAPER_WARNING_THRESHOLD: 20, // 低紙張警告閾值（模擬）
  PAPER_CRITICAL_THRESHOLD: 10, // 紙張嚴重不足閾值

  // 健康檢查閾值
  HEALTH_WARNING_THRESHOLD: 80, // 健康分數警告閾值
  HEALTH_CRITICAL_THRESHOLD: 60, // 健康分數嚴重閾值

  // 錯誤率
  MAX_ERROR_RATE: 0.1, // 最大允許錯誤率（10%）

  // 打印機類型支持
  SUPPORTED_TYPES: ['epson', 'star', 'zebra', 'custom'],

  // 事件保留
  MAX_EVENTS_RETAINED: 100
};

// 錯誤模擬配置
const ERROR_SIMULATION = {
  enabled: false,
  paper_jam: false,
  no_paper: false,
  overheating: false,
  communication_error: false,
  print_quality_poor: false,
  error_rate: 0 // 0-1 錯誤率
};

// 為所有路由添加分店上下文中間件
router.use(storeAwareMiddleware.initStoreContext);

// 小票模板查找函數：優先找 store_id 匹配的模板，找不到才用全局默認
async function findReceiptTemplate(storeId) {
  // 第1步：找分店專用模板（不問 is_default）
  const storeTemplate = await new Promise((resolve) => {
    db.get(
      `SELECT config FROM receipt_templates
       WHERE store_id = ?
       ORDER BY is_default DESC, created_at DESC
       LIMIT 1`,
      [storeId],
      (err, template) => {
        if (err) { console.error('查詢小票模板錯誤:', err); resolve(null); return; }
        if (!template || !template.config) { resolve(null); return; }
        try {
          const config = typeof template.config === 'string' ? JSON.parse(template.config) : template.config;
          console.log(`找到分店 ${storeId} 的專用小票模板:`, config.store_name || config.template_name || '(未命名)');
          resolve(config);
        } catch (e) { console.error('解析模板配置JSON錯誤:', e); resolve(null); }
      }
    );
  });
  if (storeTemplate) return storeTemplate;

  // 第2步：沒有分店專用模板，回退到全局默認
  console.log(`分店 ${storeId} 無專用模板，查找全局默認模板`);
  const defaultTemplate = await new Promise((resolve) => {
    db.get(
      `SELECT config FROM receipt_templates
       WHERE is_default = 1
       ORDER BY created_at DESC
       LIMIT 1`,
      [],
      (err, template) => {
        if (err) { console.error('查詢默認小票模板錯誤:', err); resolve(null); return; }
        if (!template || !template.config) { resolve(null); return; }
        try {
          const config = typeof template.config === 'string' ? JSON.parse(template.config) : template.config;
          console.log('使用全局默認小票模板:', config.store_name || '(未命名)');
          resolve(config);
        } catch (e) { console.error('解析默認模板配置JSON錯誤:', e); resolve(null); }
      }
    );
  });
  return defaultTemplate;
}

// 小票寬度（字符數）
const RECEIPT_WIDTH = 48;

/**
 * 計算字符串在熱敏打印機上的顯示寬度（中文字符=2，英文字符=1）
 * @param {string} str - 要計算寬度的字符串
 * @returns {number} 顯示寬度
 */
function getDisplayWidth(str) {
  if (!str) return 0;
  let width = 0;
  for (let i = 0; i < str.length; i++) {
    const charCode = str.charCodeAt(i);
    // 中文字符範圍判斷（簡化版）
    if (charCode >= 0x4e00 && charCode <= 0x9fff) {
      width += 2; // 中文字符
    } else if (charCode >= 0x3040 && charCode <= 0x30ff) {
      width += 2; // 日文字符
    } else if (charCode >= 0xac00 && charCode <= 0xd7af) {
      width += 2; // 韓文字符
    } else {
      width += 1; // 英文字符、數字、標點
    }
  }
  return width;
}

/**
 * 將文本置中於小票寬度（支持多行文本，以 \n 分隔）
 * @param {string} text - 要置中的文本
 * @param {number} width - 小票寬度（默認為48）
 * @returns {string} 置中後的文本
 */
function centerText(text, width = RECEIPT_WIDTH) {
  if (!text || text.trim().length === 0) return '';

  // 將 \n 轉義序列替換為實際換行符，同時保留原有的換行符
  const normalizedText = text.replace(/\\n/g, '\n');

  // 按換行符分割文本
  const lines = normalizedText.split('\n');
  const centeredLines = lines.map(line => {
    const trimmedLine = line.trim();
    // 空行保持為空行
    if (trimmedLine.length === 0) {
      console.log(`centerText: 空行，保留空行`);
      return '';
    }
    const textWidth = getDisplayWidth(trimmedLine);
    const padding = Math.max(0, Math.floor((width - textWidth) / 2));
    const result = ' '.repeat(padding) + trimmedLine;
    console.log(`centerText: line="${trimmedLine}", textWidth=${textWidth}, padding=${padding}, result="${result}"`);
    return result;
  });

  return centeredLines.join('\n');
}

/**
 * 生成默認小票模板配置
 * @returns {Object} 默認模板配置
 */
function getDefaultReceiptConfig() {
  return {
    company_name: '自動咖啡館系統',
    store_name: '',
    header_text: '入場小票',
    footer_text: '感謝光臨',
    contact_info: '',
    show_qr_code: true,
    show_locker_info: true,
    font_size: 'normal',
    show_logo: false,
    logo_position: 'top-center',
    logo_width: 100
  };
}

// 事件日誌系統
const eventLog = [];
const logPrinterEvent = (eventType, details, severity = 'info') => {
  const event = {
    id: require('uuid').v4(),
    timestamp: new Date().toISOString(),
    event_type: eventType,
    device_id: printerStatus.device_id,
    severity: severity,
    details: details,
    resolved: false
  };

  eventLog.push(event);

  // 保持事件數量在限制內
  if (eventLog.length > PRINTER_CONFIG.MAX_EVENTS_RETAINED) {
    eventLog.shift();
  }

  // 觸發Socket事件
  try {
    const serverModule = require('../server');
    if (serverModule && serverModule.io) {
      serverModule.io.emit('printer-event', event);
    }
  } catch (error) {
    // Socket不可用，繼續
  }

  console.log(`打印機事件 [${severity}]: ${eventType}`, details);
  return event;
};

// 小票打印機狀態
let printerStatus = {
  device_id: PRINTER_CONFIG.DEVICE_ID,
  status: 'offline',
  last_seen: null,
  type: PRINTER_CONFIG.DEFAULT_TYPE,
  paper_available: true,
  last_print: null,
  paper_level: 100, // 紙張水平（百分比）
  temperature: 35, // 溫度（攝氏度）
  print_count: 0, // 總打印次數
  error_count: 0, // 錯誤計數
  maintenance_mode: false, // 維護模式
  health_score: 100, // 健康分數（0-100）
  print_queue: [], // 打印隊列
  last_error: null, // 最後錯誤
  warnings: [] // 警告列表
};

// 打印機連接管理器
class PrinterConnectionManager {
  constructor() {
    this.connections = new Map(); // storeId -> printer connection
    this.configCache = new Map(); // storeId -> printer config
  }

  async getConnection(storeId) {
    if (this.connections.has(storeId)) {
      const conn = this.connections.get(storeId);
      if (conn.status === 'connected') return conn;
    }

    // 加載配置並創建連接
    const config = await this.loadPrinterConfig(storeId);
    if (!config) throw new Error(`未找到分店 ${storeId} 的打印機配置`);

    const connection = await this.createConnection(config);
    this.connections.set(storeId, connection);
    return connection;
  }

  async loadPrinterConfig(storeId) {
    // 從數據庫加載默認打印機配置
    return new Promise((resolve) => {
      const db = require('../../database/db').db;
      db.get(
        `SELECT * FROM printer_configs
         WHERE store_id = ? AND is_default = 1
         LIMIT 1`,
        [storeId],
        (err, config) => {
          if (err) {
            console.error('加載打印機配置錯誤:', err);
            resolve(null);
          } else if (config) {
            resolve(config);
          } else {
            // 如果沒有配置，返回默認配置（僅用於測試）
            console.log(`未找到分店 ${storeId} 的打印機配置，使用默認配置`);
            resolve({
              id: 'default-printer',
              store_id: storeId,
              printer_name: '佳博 GP-D801 (默認)',
              connection_type: 'wifi',
              ip_address: '192.168.3.100',
              port: 9100,
              printer_type: 'epson',
              is_default: 1
            });
          }
        }
      );
    });
  }

  async createConnection(config) {
    try {
      const printerType = config.printer_type === 'star'
        ? PrinterTypes.STAR
        : PrinterTypes.EPSON;

      // 使用RawPrinter代替ThermalPrinter，確保中文編碼支援
      const printer = new RawPrinter({
        ip_address: config.ip_address,
        port: config.port,
        encoding: 'GBK',
        timeout: 30000,
        printableWidth: 576
      });

      // 測試連接
      printer.alignCenter();
      printer.println('連接測試');
      printer.cut();
      const success = await printer.execute();

      return {
        printer,
        config,
        status: success ? 'connected' : 'error',
        lastTest: new Date().toISOString()
      };
    } catch (error) {
      return {
        printer: null,
        config,
        status: 'error',
        error: error.message,
        lastTest: new Date().toISOString()
      };
    }
  }

  // 檢查連接狀態
  checkConnection(storeId) {
    const connection = this.connections.get(storeId);
    if (!connection) return { status: 'not_initialized' };
    return connection;
  }

  // 關閉連接
  closeConnection(storeId) {
    if (this.connections.has(storeId)) {
      const conn = this.connections.get(storeId);
      // 注意：node-thermal-printer沒有顯式的close方法
      this.connections.delete(storeId);
      return true;
    }
    return false;
  }
}

const printerManager = new PrinterConnectionManager();

// 初始化打印機（模擬）
let printer = null;

// 打印隊列管理
const printQueue = {
  jobs: [],
  addJob: (job) => {
    if (printQueue.jobs.length >= PRINTER_CONFIG.MAX_PRINT_QUEUE) {
      throw new Error('打印隊列已滿');
    }
    job.id = require('uuid').v4();
    job.created_at = new Date().toISOString();
    job.status = 'queued';
    printQueue.jobs.push(job);
    logPrinterEvent('job_queued', { job_id: job.id, type: job.type }, 'info');
    return job;
  },
  processNext: async () => {
    if (printQueue.jobs.length === 0) return null;
    const job = printQueue.jobs[0];
    job.status = 'processing';
    job.started_at = new Date().toISOString();

    try {
      // 真實打印處理
      await realPrintJob(job);
      job.status = 'completed';
      job.completed_at = new Date().toISOString();
      printQueue.jobs.shift(); // 移除完成的作業
      logPrinterEvent('job_completed', { job_id: job.id, type: job.type }, 'success');
      return job;
    } catch (error) {
      job.status = 'failed';
      job.error = error.message;
      job.completed_at = new Date().toISOString();
      printQueue.jobs.shift(); // 移除失敗的作業
      logPrinterEvent('job_failed', { job_id: job.id, type: job.type, error: error.message }, 'error');
      throw error;
    }
  },
  clear: () => {
    const cleared = printQueue.jobs.length;
    printQueue.jobs = [];
    logPrinterEvent('queue_cleared', { cleared_count: cleared }, 'warning');
    return cleared;
  },
  getStats: () => {
    return {
      total: printQueue.jobs.length,
      queued: printQueue.jobs.filter(j => j.status === 'queued').length,
      processing: printQueue.jobs.filter(j => j.status === 'processing').length,
      completed_today: printerStatus.print_count
    };
  }
};

// 模擬打印作業
async function simulatePrintJob(job) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // 檢查錯誤模擬
      if (ERROR_SIMULATION.enabled) {
        const rand = Math.random();
        if (ERROR_SIMULATION.error_rate > 0 && rand < ERROR_SIMULATION.error_rate) {
          return reject(new Error('模擬打印錯誤：隨機錯誤發生'));
        }
        if (ERROR_SIMULATION.paper_jam) {
          return reject(new Error('模擬打印錯誤：紙張卡住'));
        }
        if (ERROR_SIMULATION.no_paper) {
          return reject(new Error('模擬打印錯誤：紙張不足'));
        }
        if (ERROR_SIMULATION.overheating) {
          return reject(new Error('模擬打印錯誤：打印機過熱'));
        }
        if (ERROR_SIMULATION.communication_error) {
          return reject(new Error('模擬打印錯誤：通訊錯誤'));
        }
        if (ERROR_SIMULATION.print_quality_poor) {
          logPrinterEvent('print_quality_warning', { job_id: job.id }, 'warning');
        }
      }

      // 模擬成功打印
      printerStatus.print_count++;
      printerStatus.last_print = new Date().toISOString();

      // 減少紙張水平（每次打印減少1%）
      printerStatus.paper_level = Math.max(0, printerStatus.paper_level - 1);

      // 輕微增加溫度
      printerStatus.temperature += 0.5;

      resolve();
    }, 1000); // 模擬1秒打印時間
  });
}

// 真實打印作業
async function realPrintJob(job) {
  const storeId = job.store_id || 'default_store';

  let connection;
  try {
    // 獲取打印機連接
    connection = await printerManager.getConnection(storeId);
    if (connection.status !== 'connected') {
      throw new Error(`打印機連接失敗: ${connection.error || '未知錯誤'}`);
    }

    // 創建新的RawPrinter實例，避免舊實例的緩衝區問題
    const printer = new RawPrinter({
      ip_address: connection.config.ip_address,
      port: connection.config.port,
      encoding: 'GBK',
      timeout: 30000,
      printableWidth: 576
    });

    // 清空緩衝區
    printer.clear();

    // 打印LOGO（如果配置啟用）
    if (job.template_config && job.template_config.show_logo === true &&
        job.template_config.logo_base64 && job.template_config.logo_base64.length > 0) {
      try {
        console.log('打印LOGO，寬度:', job.template_config.logo_width || 100);
        await printer.printImageBase64(
          job.template_config.logo_base64,
          job.template_config.logo_width || 100
        );
        console.log('LOGO打印完成');
        // LOGO後添加換行符
        printer.newLine();
      } catch (logoError) {
        console.error('LOGO打印失敗，繼續打印文本:', logoError.message);
        // 繼續打印文本，不中斷
      }
    }

    const lines = job.content.split('\n');
    for (const line of lines) {
      // 檢測QR Code標記 $QR_CODE:data$
      const qrMatch = line.match(/^\$QR_CODE:(.+)\$$/);
      if (qrMatch) {
        try {
          // 使用qrcode生成PNG圖片（高像素確保大尺寸）
          const pngBuffer = await QRCode.toBuffer(qrMatch[1], {
            type: 'png',
            width: 500,
            margin: 1,
            color: { dark: '#000000', light: '#ffffff' },
            errorCorrectionLevel: 'M'
          });
          const base64 = pngBuffer.toString('base64');
          printer.newLine(2);
          await printer.printImageBase64(base64, 500);
          printer.newLine(2);
        } catch (qrError) {
          console.error('QR Code生成失敗:', qrError.message);
          printer.println('[QR Error: ' + qrError.message + ']');
        }
      } else {
        printer.println(line);
      }
    }

    printer.cut();

    // 執行打印
    const success = await printer.execute();
    if (!success) throw new Error('打印執行返回失敗');

    // 更新狀態
    printerStatus.print_count++;
    printerStatus.last_print = new Date().toISOString();
    printerStatus.paper_level = Math.max(0, printerStatus.paper_level - 1);
    printerStatus.temperature += 0.5;

    // 記錄成功事件
    logPrinterEvent('real_print_success', {
      job_id: job.id,
      type: job.type,
      table_number: job.table_number,
      store_id: storeId
    }, 'success');

    return success;
  } catch (error) {
    printerStatus.error_count++;

    // 嘗試原始打印作為備份
    let rawPrintSuccess = false;
    if (connection && connection.config) {
      try {
        console.log('ThermalPrinter失敗，嘗試原始ESC/POS打印...');
        const rawPrinter = new RawPrinter(connection.config);

        // 打印LOGO（如果配置啟用）
        if (job.template_config && job.template_config.show_logo === true &&
            job.template_config.logo_base64 && job.template_config.logo_base64.length > 0) {
          try {
            console.log('原始打印: 打印LOGO，寬度:', job.template_config.logo_width || 100);
            await rawPrinter.printImageBase64(
              job.template_config.logo_base64,
              job.template_config.logo_width || 100
            );
            console.log('原始打印: LOGO打印完成');
          } catch (logoError) {
            console.error('原始打印: LOGO打印失敗，繼續打印文本:', logoError.message);
            // 繼續打印文本，不中斷
          }
        }

        const lines = job.content.split('\n');
        for (const line of lines) {
          // 檢測QR Code標記 $QR_CODE:data$
          const qrMatch = line.match(/^\$QR_CODE:(.+)\$$/);
          if (qrMatch) {
            try {
              // 使用qrcode生成PNG圖片
              const pngBuffer = await QRCode.toBuffer(qrMatch[1], {
                type: 'png',
                width: 500,
                margin: 1,
                color: { dark: '#000000', light: '#ffffff' },
                errorCorrectionLevel: 'M'
              });
              const base64 = pngBuffer.toString('base64');
              rawPrinter.newLine(2);
              await rawPrinter.printImageBase64(base64, 500);
              rawPrinter.newLine(2);
            } catch (qrError) {
              console.error('QR Code生成失敗:', qrError.message);
              rawPrinter.println('[QR Error: ' + qrError.message + ']');
            }
          } else {
            rawPrinter.println(line);
          }
        }

        rawPrinter.cut();
        rawPrintSuccess = await rawPrinter.execute();

        if (rawPrintSuccess) {
          console.log('原始打印成功！');
          // 更新狀態
          printerStatus.print_count++;
          printerStatus.last_print = new Date().toISOString();
          printerStatus.paper_level = Math.max(0, printerStatus.paper_level - 1);
          printerStatus.temperature += 0.5;

          // 記錄成功事件
          logPrinterEvent('real_print_success', {
            job_id: job.id,
            type: job.type,
            table_number: job.table_number,
            store_id: storeId,
            fallback: 'raw_printer'
          }, 'success');

          return true;
        }
      } catch (rawError) {
        console.log('原始打印也失敗:', rawError.message);
        // 繼續使用原始錯誤
      }
    }

    // 記錄失敗事件
    logPrinterEvent('real_print_failed', {
      job_id: job.id,
      type: job.type,
      error: error.message,
      store_id: storeId,
      fallback_attempted: !!connection
    }, 'error');

    throw error;
  }
}

// 健康檢查函數
function checkPrinterHealth() {
  const issues = [];
  const warnings = [];

  // 檢查紙張水平
  if (printerStatus.paper_level <= PRINTER_CONFIG.PAPER_CRITICAL_THRESHOLD) {
    issues.push({
      type: 'paper_critical',
      message: `紙張嚴重不足 (${printerStatus.paper_level}%)`,
      severity: 'critical'
    });
  } else if (printerStatus.paper_level <= PRINTER_CONFIG.PAPER_WARNING_THRESHOLD) {
    warnings.push({
      type: 'paper_low',
      message: `紙張水平低 (${printerStatus.paper_level}%)`,
      severity: 'warning'
    });
  }

  // 檢查溫度
  if (printerStatus.temperature > 60) {
    issues.push({
      type: 'overheating',
      message: `打印機過熱 (${printerStatus.temperature}°C)`,
      severity: 'critical'
    });
  } else if (printerStatus.temperature > 50) {
    warnings.push({
      type: 'temperature_warning',
      message: `打印機溫度偏高 (${printerStatus.temperature}°C)`,
      severity: 'warning'
    });
  }

  // 檢查錯誤率
  const totalOperations = printerStatus.print_count + printerStatus.error_count;
  const errorRate = totalOperations > 0 ? printerStatus.error_count / totalOperations : 0;
  if (errorRate > PRINTER_CONFIG.MAX_ERROR_RATE) {
    issues.push({
      type: 'high_error_rate',
      message: `錯誤率過高 (${(errorRate * 100).toFixed(1)}%)`,
      severity: 'critical'
    });
  }

  // 檢查離線狀態
  if (printerStatus.status === 'offline') {
    issues.push({
      type: 'offline',
      message: '打印機離線',
      severity: 'critical'
    });
  }

  // 檢查最後通訊時間
  if (printerStatus.last_seen) {
    const lastSeenAge = Math.floor((new Date() - new Date(printerStatus.last_seen)) / 1000);
    if (lastSeenAge > PRINTER_CONFIG.HEARTBEAT_INTERVAL_MS * 3 / 1000) {
      issues.push({
        type: 'heartbeat_missing',
        message: `心跳丟失 (${lastSeenAge}秒)`,
        severity: 'critical'
      });
    }
  }

  return { issues, warnings };
}

// 計算健康分數
function calculateHealthScore() {
  const healthFactors = [];

  // 紙張水平分數 (30%)
  const paperScore = Math.min(100, (printerStatus.paper_level / 100) * 100);
  healthFactors.push(paperScore * 0.3);

  // 溫度分數 (20%)
  const tempScore = printerStatus.temperature <= 40 ? 100 :
                   printerStatus.temperature <= 50 ? 80 :
                   printerStatus.temperature <= 60 ? 60 : 30;
  healthFactors.push(tempScore * 0.2);

  // 錯誤率分數 (25%)
  const totalOperations = printerStatus.print_count + printerStatus.error_count;
  const errorRate = totalOperations > 0 ? printerStatus.error_count / totalOperations : 0;
  const errorScore = errorRate <= 0.05 ? 100 :
                    errorRate <= 0.1 ? 80 :
                    errorRate <= 0.2 ? 60 : 30;
  healthFactors.push(errorScore * 0.25);

  // 連接狀態分數 (25%)
  const connectionScore = printerStatus.status === 'online' ? 100 : 30;
  healthFactors.push(connectionScore * 0.25);

  // 計算總分
  const totalScore = healthFactors.reduce((sum, score) => sum + score, 0);
  return Math.round(totalScore);
}

// 獲取錯誤訊息
function getErrorMessage(error) {
  const errorMap = {
    '紙張卡住': '請檢查打印機紙張路徑',
    '紙張不足': '請添加紙張',
    '打印機過熱': '請讓打印機冷卻後再試',
    '通訊錯誤': '請檢查USB連接或網絡連接',
    '打印隊列已滿': '請等待當前打印完成'
  };

  for (const [key, message] of Object.entries(errorMap)) {
    if (error.includes(key)) {
      return message;
    }
  }

  return '請檢查打印機狀態並重試';
}

// 打印機設備註冊/心跳
// 打印機設備註冊/心跳
router.post('/heartbeat', (req, res) => {
  try {
    const { device_id, status, paper_available, printer_type, paper_level, temperature } = req.body;
    const storeId = req.storeContext?.store_id || 'default_store';

    // 更新打印機狀態
    printerStatus = {
      ...printerStatus,
      device_id: device_id || printerStatus.device_id,
      status: status || 'online',
      last_seen: new Date().toISOString(),
      paper_available: paper_available !== undefined ? paper_available : printerStatus.paper_available,
      type: printer_type || printerStatus.type,
      paper_level: paper_level !== undefined ? paper_level : printerStatus.paper_level,
      temperature: temperature !== undefined ? temperature : printerStatus.temperature
    };

    // 更新健康分數
    printerStatus.health_score = calculateHealthScore();

    // 檢查健康狀況
    const { issues, warnings } = checkPrinterHealth();
    printerStatus.warnings = warnings.map(w => w.message);

    // 記錄心跳事件
    logPrinterEvent('heartbeat', {
      device_id: printerStatus.device_id,
      status: printerStatus.status,
      paper_level: printerStatus.paper_level,
      temperature: printerStatus.temperature,
      health_score: printerStatus.health_score,
      issues_count: issues.length,
      warnings_count: warnings.length
    }, 'info');

    // 如果有嚴重問題，記錄錯誤事件
    if (issues.some(issue => issue.severity === 'critical')) {
      issues.filter(issue => issue.severity === 'critical').forEach(issue => {
        logPrinterEvent('critical_issue', issue, 'error');
      });
    }

    // 更新數據庫中的設備狀態
    const db = require('../../database/db').db;
    db.run(
      `INSERT OR REPLACE INTO devices (id, device_type, device_id, status, last_seen, health_score, paper_level, temperature, store_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        require('uuid').v4(),
        'printer',
        printerStatus.device_id,
        printerStatus.status,
        printerStatus.last_seen,
        printerStatus.health_score,
        printerStatus.paper_level,
        printerStatus.temperature,
        storeId
      ],
      (err) => {
        if (err) console.error('更新設備狀態錯誤:', err);
      }
    );

    res.json({
      success: true,
      message: '打印機心跳接收成功',
      status: printerStatus,
      health: {
        score: printerStatus.health_score,
        issues: issues,
        warnings: warnings
      },
      queue_stats: printQueue.getStats()
    });
  } catch (error) {
    console.error('打印機心跳錯誤:', error);
    logPrinterEvent('heartbeat_error', { error: error.message }, 'error');
    res.status(500).json({
      error: '打印機心跳處理失敗',
      message: error.message,
      user_message: getErrorMessage(error.message)
    });
  }
});

// 打印入場小票
router.post('/print-entry', async (req, res) => {
  try {
    const {
      table_number,
      qr_code,
      people_count,
      entry_time,
      lockers,
      is_member
    } = req.body;

    if (!table_number || !qr_code) {
      return res.status(400).json({ error: '請提供桌號和QR Code' });
    }

    // 檢查打印機狀態
    if (printerStatus.status !== 'online') {
      return res.status(503).json({
        error: '打印機離線',
        message: '打印機目前離線，無法打印',
        user_message: '打印機離線，請檢查連接'
      });
    }

    if (printerStatus.maintenance_mode) {
      return res.status(503).json({
        error: '打印機維護中',
        message: '打印機處於維護模式',
        user_message: '打印機維護中，請稍後再試'
      });
    }

    // 獲取當前分店ID
    const storeId = req.storeContext?.store_id || 'default_store';

    // 查找小票模板：優先分店專用，找不到才用全局默認
    let templateConfig = null;
    try {
      templateConfig = await findReceiptTemplate(storeId);
    } catch (err) {
      console.error('獲取模板配置錯誤:', err);
    }

    // 生成小票內容
    const receiptContent = generateEntryReceipt({
      table_number,
      qr_code,
      people_count: people_count || 1,
      entry_time: entry_time || new Date().toLocaleString('zh-TW'),
      lockers: lockers || [],
      is_member: is_member || false
    }, templateConfig);

    // 創建打印作業
    const printJob = {
      type: 'entry',
      table_number,
      qr_code,
      content: receiptContent,
      created_by: req.ip || 'unknown'
    };

    try {
      // 添加到打印隊列
      const queuedJob = printQueue.addJob(printJob);

      // 記錄打印事件
      logPrinterEvent('print_queued', {
        job_id: queuedJob.id,
        type: 'entry',
        table_number,
        queue_position: printQueue.jobs.length
      }, 'info');

      // 立即處理打印作業（模擬）
      const result = await printQueue.processNext();

      // 觸發Socket事件通知打印
      const io = req.app.get('io');
      io.emit('receipt-printed', {
        type: 'entry',
        table_number: table_number,
        qr_code: qr_code,
        timestamp: printerStatus.last_print,
        receipt_content: receiptContent,
        job_id: queuedJob.id
      });

      // 記錄成功事件
      logPrinterEvent('print_success', {
        job_id: queuedJob.id,
        type: 'entry',
        table_number,
        print_count: printerStatus.print_count
      }, 'success');

      res.json({
        success: true,
        message: '入場小票打印成功',
        receipt: {
          table_number: table_number,
          qr_code: qr_code,
          printed_at: printerStatus.last_print,
          job_id: queuedJob.id,
          content_preview: receiptContent.substring(0, 200) + '...',
          queue_stats: printQueue.getStats()
        },
        health: {
          score: printerStatus.health_score,
          paper_level: printerStatus.paper_level,
          temperature: printerStatus.temperature
        }
      });
    } catch (queueError) {
      // 隊列錯誤
      printerStatus.error_count++;
      logPrinterEvent('print_failed', {
        error: queueError.message,
        table_number,
        type: 'entry'
      }, 'error');

      res.status(500).json({
        error: '打印隊列錯誤',
        message: queueError.message,
        user_message: getErrorMessage(queueError.message),
        queue_stats: printQueue.getStats()
      });
    }
  } catch (error) {
    console.error('打印入場小票錯誤:', error);
    logPrinterEvent('print_error', {
      error: error.message,
      endpoint: 'print-entry'
    }, 'error');
    res.status(500).json({
      error: '打印入場小票失敗',
      message: error.message,
      user_message: getErrorMessage(error.message)
    });
  }
});

// 打印結賬小票
router.post('/print-checkout', async (req, res) => {
  try {
    const {
      table_number,
      qr_code,
      total_amount,
      checkout_time,
      order_items,
      transaction_id
    } = req.body;

    if (!table_number || !total_amount) {
      return res.status(400).json({ error: '請提供桌號和總金額' });
    }

    // 檢查打印機狀態
    if (printerStatus.status !== 'online') {
      return res.status(503).json({
        error: '打印機離線',
        message: '打印機目前離線，無法打印',
        user_message: '打印機離線，請檢查連接'
      });
    }

    if (printerStatus.maintenance_mode) {
      return res.status(503).json({
        error: '打印機維護中',
        message: '打印機處於維護模式',
        user_message: '打印機維護中，請稍後再試'
      });
    }

    // 獲取當前分店ID
    const storeId = req.storeContext?.store_id || 'default_store';

    // 查找小票模板：優先分店專用，找不到才用全局默認
    let templateConfig = null;
    try {
      templateConfig = await findReceiptTemplate(storeId);
    } catch (err) {
      console.error('獲取模板配置錯誤:', err);
    }

    // 生成小票內容
    const receiptContent = generateCheckoutReceipt({
      table_number,
      qr_code: qr_code || `TABLE-${table_number}`,
      total_amount,
      checkout_time: checkout_time || new Date().toLocaleString('zh-TW'),
      order_items: order_items || [],
      transaction_id: transaction_id || require('uuid').v4().substring(0, 8).toUpperCase()
    }, templateConfig);

    // 創建打印作業
    const printJob = {
      type: 'checkout',
      table_number,
      qr_code: qr_code || `TABLE-${table_number}`,
      total_amount,
      content: receiptContent,
      created_by: req.ip || 'unknown'
    };

    try {
      // 添加到打印隊列
      const queuedJob = printQueue.addJob(printJob);

      // 記錄打印事件
      logPrinterEvent('print_queued', {
        job_id: queuedJob.id,
        type: 'checkout',
        table_number,
        total_amount,
        queue_position: printQueue.jobs.length
      }, 'info');

      // 立即處理打印作業（模擬）
      const result = await printQueue.processNext();

      // 觸發Socket事件
      const io = req.app.get('io');
      io.emit('receipt-printed', {
        type: 'checkout',
        table_number: table_number,
        total_amount: total_amount,
        timestamp: printerStatus.last_print,
        receipt_content: receiptContent,
        job_id: queuedJob.id
      });

      // 記錄成功事件
      logPrinterEvent('print_success', {
        job_id: queuedJob.id,
        type: 'checkout',
        table_number,
        total_amount,
        print_count: printerStatus.print_count
      }, 'success');

      res.json({
        success: true,
        message: '結賬小票打印成功',
        receipt: {
          table_number: table_number,
          total_amount: total_amount,
          printed_at: printerStatus.last_print,
          job_id: queuedJob.id,
          content_preview: receiptContent.substring(0, 200) + '...',
          queue_stats: printQueue.getStats()
        },
        health: {
          score: printerStatus.health_score,
          paper_level: printerStatus.paper_level,
          temperature: printerStatus.temperature
        }
      });
    } catch (queueError) {
      // 隊列錯誤
      printerStatus.error_count++;
      logPrinterEvent('print_failed', {
        error: queueError.message,
        table_number,
        type: 'checkout',
        total_amount
      }, 'error');

      res.status(500).json({
        error: '打印隊列錯誤',
        message: queueError.message,
        user_message: getErrorMessage(queueError.message),
        queue_stats: printQueue.getStats()
      });
    }
  } catch (error) {
    console.error('打印結賬小票錯誤:', error);
    logPrinterEvent('print_error', {
      error: error.message,
      endpoint: 'print-checkout'
    }, 'error');
    res.status(500).json({
      error: '打印結賬小票失敗',
      message: error.message,
      user_message: getErrorMessage(error.message)
    });
  }
});

// 獲取打印機狀態
router.get('/status', (req, res) => {
  try {
    const { details = 'basic' } = req.query; // basic, health, full, diagnostics

    // 更新健康分數
    printerStatus.health_score = calculateHealthScore();

    // 檢查健康狀況
    const { issues, warnings } = checkPrinterHealth();
    printerStatus.warnings = warnings.map(w => w.message);

    // 基本狀態響應
    const basicStatus = {
      success: true,
      device_id: printerStatus.device_id,
      status: printerStatus.status,
      type: printerStatus.type,
      can_print: printerStatus.status === 'online' && printerStatus.paper_available && !printerStatus.maintenance_mode,
      maintenance_mode: printerStatus.maintenance_mode,
      last_seen: printerStatus.last_seen,
      last_seen_age: printerStatus.last_seen
        ? Math.floor((new Date() - new Date(printerStatus.last_seen)) / 1000)
        : null,
      last_print: printerStatus.last_print,
      last_print_age: printerStatus.last_print
        ? Math.floor((new Date() - new Date(printerStatus.last_print)) / 1000)
        : null
    };

    // 健康狀態響應
    const healthStatus = {
      ...basicStatus,
      health: {
        score: printerStatus.health_score,
        level: printerStatus.health_score >= PRINTER_CONFIG.HEALTH_WARNING_THRESHOLD ? 'healthy' :
               printerStatus.health_score >= PRINTER_CONFIG.HEALTH_CRITICAL_THRESHOLD ? 'warning' : 'critical',
        paper_level: printerStatus.paper_level,
        temperature: printerStatus.temperature,
        print_count: printerStatus.print_count,
        error_count: printerStatus.error_count,
        error_rate: printerStatus.print_count + printerStatus.error_count > 0
          ? printerStatus.error_count / (printerStatus.print_count + printerStatus.error_count)
          : 0,
        issues: issues,
        warnings: warnings
      },
      paper_status: {
        available: printerStatus.paper_available,
        level: printerStatus.paper_level,
        warning: printerStatus.paper_level <= PRINTER_CONFIG.PAPER_WARNING_THRESHOLD,
        critical: printerStatus.paper_level <= PRINTER_CONFIG.PAPER_CRITICAL_THRESHOLD
      }
    };

    // 完整狀態響應
    const fullStatus = {
      ...healthStatus,
      configuration: {
        device_id: PRINTER_CONFIG.DEVICE_ID,
        max_queue: PRINTER_CONFIG.MAX_PRINT_QUEUE,
        print_timeout: PRINTER_CONFIG.PRINT_TIMEOUT_MS,
        heartbeat_interval: PRINTER_CONFIG.HEARTBEAT_INTERVAL_MS,
        supported_types: PRINTER_CONFIG.SUPPORTED_TYPES
      },
      queue_stats: printQueue.getStats(),
      recent_events: eventLog.slice(-10), // 最近10個事件
      error_simulation: ERROR_SIMULATION
    };

    // 診斷狀態響應
    const diagnosticStatus = {
      ...fullStatus,
      system_info: {
        node_version: process.version,
        platform: process.platform,
        uptime: process.uptime(),
        memory: process.memoryUsage()
      },
      database_status: 'connected', // 簡化，實際應檢查數據庫連接
      socket_status: 'connected', // 簡化
      all_config: PRINTER_CONFIG,
      all_events_count: eventLog.length,
      print_jobs_history: printQueue.jobs.slice(-20) // 最近20個作業
    };

    // 根據請求的詳細程度返回相應的數據
    let response;
    switch (details) {
      case 'health':
        response = healthStatus;
        break;
      case 'full':
        response = fullStatus;
        break;
      case 'diagnostics':
        response = diagnosticStatus;
        break;
      case 'basic':
      default:
        response = basicStatus;
        break;
    }

    // 記錄狀態查詢事件
    logPrinterEvent('status_query', {
      details_level: details,
      health_score: printerStatus.health_score,
      issues_count: issues.length
    }, 'info');

    res.json(response);
  } catch (error) {
    console.error('獲取打印機狀態錯誤:', error);
    logPrinterEvent('status_error', { error: error.message }, 'error');
    res.status(500).json({
      error: '獲取打印機狀態失敗',
      message: error.message,
      user_message: getErrorMessage(error.message)
    });
  }
});

// 配置管理端點
router.get('/config', (req, res) => {
  try {
    res.json({
      success: true,
      config: PRINTER_CONFIG,
      error_simulation: ERROR_SIMULATION,
      printer_status: {
        device_id: printerStatus.device_id,
        status: printerStatus.status,
        type: printerStatus.type,
        maintenance_mode: printerStatus.maintenance_mode
      }
    });
  } catch (error) {
    console.error('獲取配置錯誤:', error);
    logPrinterEvent('config_error', { error: error.message }, 'error');
    res.status(500).json({
      error: '獲取配置失敗',
      message: error.message
    });
  }
});

router.post('/config/update', (req, res) => {
  try {
    const { config, error_simulation } = req.body;
    let updated = [];

    // 更新配置
    if (config) {
      for (const [key, value] of Object.entries(config)) {
        if (PRINTER_CONFIG.hasOwnProperty(key) && typeof value === typeof PRINTER_CONFIG[key]) {
          PRINTER_CONFIG[key] = value;
          updated.push(`config.${key}`);
        }
      }
    }

    // 更新錯誤模擬配置
    if (error_simulation) {
      for (const [key, value] of Object.entries(error_simulation)) {
        if (ERROR_SIMULATION.hasOwnProperty(key) && typeof value === typeof ERROR_SIMULATION[key]) {
          ERROR_SIMULATION[key] = value;
          updated.push(`error_simulation.${key}`);
        }
      }
    }

    logPrinterEvent('config_updated', { updated }, 'info');

    res.json({
      success: true,
      message: updated.length > 0 ? '配置更新成功' : '無配置變更',
      updated,
      config: PRINTER_CONFIG,
      error_simulation: ERROR_SIMULATION
    });
  } catch (error) {
    console.error('更新配置錯誤:', error);
    logPrinterEvent('config_update_error', { error: error.message }, 'error');
    res.status(500).json({
      error: '更新配置失敗',
      message: error.message
    });
  }
});

// 錯誤模擬控制
router.post('/error-simulation', (req, res) => {
  try {
    const { enabled, paper_jam, no_paper, overheating, communication_error, print_quality_poor, error_rate } = req.body;

    if (enabled !== undefined) ERROR_SIMULATION.enabled = enabled;
    if (paper_jam !== undefined) ERROR_SIMULATION.paper_jam = paper_jam;
    if (no_paper !== undefined) ERROR_SIMULATION.no_paper = no_paper;
    if (overheating !== undefined) ERROR_SIMULATION.overheating = overheating;
    if (communication_error !== undefined) ERROR_SIMULATION.communication_error = communication_error;
    if (print_quality_poor !== undefined) ERROR_SIMULATION.print_quality_poor = print_quality_poor;
    if (error_rate !== undefined) ERROR_SIMULATION.error_rate = Math.max(0, Math.min(1, error_rate));

    logPrinterEvent('error_simulation_updated', { ...ERROR_SIMULATION }, 'warning');

    res.json({
      success: true,
      message: '錯誤模擬配置已更新',
      error_simulation: ERROR_SIMULATION
    });
  } catch (error) {
    console.error('更新錯誤模擬配置錯誤:', error);
    logPrinterEvent('error_simulation_error', { error: error.message }, 'error');
    res.status(500).json({
      error: '更新錯誤模擬配置失敗',
      message: error.message
    });
  }
});

// 維護模式控制
router.post('/maintenance-mode', (req, res) => {
  try {
    const { enabled, reason } = req.body;
    const previousMode = printerStatus.maintenance_mode;

    printerStatus.maintenance_mode = enabled !== undefined ? enabled : !printerStatus.maintenance_mode;

    logPrinterEvent('maintenance_mode_changed', {
      from: previousMode,
      to: printerStatus.maintenance_mode,
      reason: reason || '手動切換'
    }, 'warning');

    res.json({
      success: true,
      message: `維護模式已${printerStatus.maintenance_mode ? '開啟' : '關閉'}`,
      maintenance_mode: printerStatus.maintenance_mode,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('切換維護模式錯誤:', error);
    logPrinterEvent('maintenance_mode_error', { error: error.message }, 'error');
    res.status(500).json({
      error: '切換維護模式失敗',
      message: error.message
    });
  }
});

// 事件日誌查詢
router.get('/events', (req, res) => {
  try {
    const { limit = 50, severity, event_type, resolved } = req.query;
    let filteredEvents = [...eventLog];

    if (severity) {
      filteredEvents = filteredEvents.filter(event => event.severity === severity);
    }
    if (event_type) {
      filteredEvents = filteredEvents.filter(event => event.event_type === event_type);
    }
    if (resolved !== undefined) {
      const resolvedBool = resolved === 'true';
      filteredEvents = filteredEvents.filter(event => event.resolved === resolvedBool);
    }

    // 限制返回數量
    filteredEvents = filteredEvents.slice(0, parseInt(limit));

    res.json({
      success: true,
      total_events: eventLog.length,
      filtered_count: filteredEvents.length,
      events: filteredEvents
    });
  } catch (error) {
    console.error('查詢事件日誌錯誤:', error);
    logPrinterEvent('events_query_error', { error: error.message }, 'error');
    res.status(500).json({
      error: '查詢事件日誌失敗',
      message: error.message
    });
  }
});

// 標記事件為已解決
router.post('/events/:eventId/resolve', (req, res) => {
  try {
    const { eventId } = req.params;
    const event = eventLog.find(e => e.id === eventId);

    if (!event) {
      return res.status(404).json({
        error: '事件未找到',
        message: `事件ID ${eventId} 不存在`
      });
    }

    event.resolved = true;
    event.resolved_at = new Date().toISOString();
    event.resolved_by = req.ip || 'unknown';

    logPrinterEvent('event_resolved', { event_id: eventId, event_type: event.event_type }, 'info');

    res.json({
      success: true,
      message: '事件已標記為已解決',
      event
    });
  } catch (error) {
    console.error('標記事件解決錯誤:', error);
    logPrinterEvent('event_resolve_error', { error: error.message }, 'error');
    res.status(500).json({
      error: '標記事件解決失敗',
      message: error.message
    });
  }
});

// 打印隊列管理
router.get('/queue', (req, res) => {
  try {
    res.json({
      success: true,
      ...printQueue.getStats(),
      jobs: printQueue.jobs,
      max_queue: PRINTER_CONFIG.MAX_PRINT_QUEUE
    });
  } catch (error) {
    console.error('獲取打印隊列錯誤:', error);
    logPrinterEvent('queue_query_error', { error: error.message }, 'error');
    res.status(500).json({
      error: '獲取打印隊列失敗',
      message: error.message
    });
  }
});

router.post('/queue/clear', (req, res) => {
  try {
    const { reason } = req.body;
    const clearedCount = printQueue.clear();

    logPrinterEvent('queue_cleared', { cleared_count: clearedCount, reason: reason || '手動清除' }, 'warning');

    res.json({
      success: true,
      message: `打印隊列已清除，移除了 ${clearedCount} 個作業`,
      cleared_count: clearedCount
    });
  } catch (error) {
    console.error('清除打印隊列錯誤:', error);
    logPrinterEvent('queue_clear_error', { error: error.message }, 'error');
    res.status(500).json({
      error: '清除打印隊列失敗',
      message: error.message
    });
  }
});

// 紙張補充
router.post('/paper-refill', (req, res) => {
  try {
    const { amount = 100 } = req.body;
    const previousLevel = printerStatus.paper_level;

    printerStatus.paper_level = Math.min(100, Math.max(0, parseInt(amount)));
    printerStatus.paper_available = printerStatus.paper_level > 0;

    logPrinterEvent('paper_refilled', {
      from: previousLevel,
      to: printerStatus.paper_level,
      amount: amount
    }, 'info');

    res.json({
      success: true,
      message: `紙張已補充至 ${printerStatus.paper_level}%`,
      paper_level: printerStatus.paper_level,
      paper_available: printerStatus.paper_available,
      previous_level: previousLevel
    });
  } catch (error) {
    console.error('補充紙張錯誤:', error);
    logPrinterEvent('paper_refill_error', { error: error.message }, 'error');
    res.status(500).json({
      error: '補充紙張失敗',
      message: error.message
    });
  }
});

// 緊急重置打印機
router.post('/emergency-reset', (req, res) => {
  try {
    const { reason } = req.body;

    // 保存重置前的狀態
    const previousStatus = { ...printerStatus };

    // 重置打印機狀態
    printerStatus.status = 'offline';
    printerStatus.maintenance_mode = true;
    printerStatus.last_error = '緊急重置執行';
    printerStatus.warnings = ['打印機已緊急重置'];

    // 清除打印隊列
    const clearedJobs = printQueue.clear();

    // 記錄重置事件
    logPrinterEvent('emergency_reset', {
      reason: reason || '手動觸發',
      previous_status: previousStatus.status,
      cleared_jobs: clearedJobs
    }, 'error');

    res.json({
      success: true,
      message: '打印機已緊急重置',
      reset_at: new Date().toISOString(),
      cleared_jobs: clearedJobs,
      new_status: printerStatus
    });
  } catch (error) {
    console.error('緊急重置錯誤:', error);
    logPrinterEvent('emergency_reset_error', { error: error.message }, 'error');
    res.status(500).json({
      error: '緊急重置失敗',
      message: error.message
    });
  }
});

// 測試打印
router.post('/test-print', async (req, res) => {
  try {
    const { text, test_type = 'simple' } = req.body;
    const testText = text || '這是測試打印內容\n自動咖啡館系統\n' + new Date().toLocaleString('zh-TW');

    // 檢查打印機狀態
    if (printerStatus.status !== 'online') {
      return res.status(503).json({
        error: '打印機離線',
        message: '打印機目前離線，無法進行測試打印',
        user_message: '打印機離線，請檢查連接'
      });
    }

    if (printerStatus.maintenance_mode) {
      return res.status(503).json({
        error: '打印機維護中',
        message: '打印機處於維護模式',
        user_message: '打印機維護中，請稍後再試'
      });
    }

    // 創建測試打印作業
    const printJob = {
      type: 'test',
      test_type: test_type,
      content: testText,
      created_by: req.ip || 'unknown'
    };

    try {
      // 添加到打印隊列
      const queuedJob = printQueue.addJob(printJob);

      // 記錄測試事件
      logPrinterEvent('test_print_queued', {
        job_id: queuedJob.id,
        test_type: test_type,
        queue_position: printQueue.jobs.length
      }, 'info');

      // 立即處理打印作業（模擬）
      const result = await printQueue.processNext();

      // 觸發Socket事件
      const io = req.app.get('io');
      io.emit('receipt-printed', {
        type: 'test',
        text: testText,
        timestamp: printerStatus.last_print,
        job_id: queuedJob.id,
        test_type: test_type
      });

      // 記錄成功事件
      logPrinterEvent('test_print_success', {
        job_id: queuedJob.id,
        test_type: test_type,
        print_count: printerStatus.print_count
      }, 'success');

      res.json({
        success: true,
        message: '測試打印成功',
        text: testText,
        printed_at: printerStatus.last_print,
        job_id: queuedJob.id,
        queue_stats: printQueue.getStats(),
        health: {
          score: printerStatus.health_score,
          paper_level: printerStatus.paper_level,
          temperature: printerStatus.temperature
        }
      });
    } catch (queueError) {
      // 隊列錯誤
      printerStatus.error_count++;
      logPrinterEvent('test_print_failed', {
        error: queueError.message,
        test_type: test_type
      }, 'error');

      res.status(500).json({
        error: '測試打印隊列錯誤',
        message: queueError.message,
        user_message: getErrorMessage(queueError.message),
        queue_stats: printQueue.getStats()
      });
    }
  } catch (error) {
    console.error('測試打印錯誤:', error);
    logPrinterEvent('test_print_error', {
      error: error.message,
      endpoint: 'test-print'
    }, 'error');
    res.status(500).json({
      error: '測試打印失敗',
      message: error.message,
      user_message: getErrorMessage(error.message)
    });
  }
});

// 生成入場小票內容
function generateEntryReceipt(data, templateConfig = null) {
  const {
    table_number,
    qr_code,
    people_count,
    entry_time,
    lockers,
    is_member
  } = data;

  // 合併模板配置與默認配置
  const defaultConfig = getDefaultReceiptConfig();
  const config = templateConfig ? { ...defaultConfig, ...templateConfig } : defaultConfig;

  // 根據模板配置確定header_text（入場小票）
  const headerText = config.header_text || '入場小票';

  let receipt = '';

  // 頂部裝飾線
  receipt += '='.repeat(RECEIPT_WIDTH) + '\n';

  // 公司名稱（置中）
  if (config.company_name && config.company_name.trim()) {
    receipt += centerText(config.company_name) + '\n';
  }

  // 分店名稱（置中）
  if (config.store_name && config.store_name.trim()) {
    receipt += centerText(config.store_name) + '\n';
  }

  // 第二條裝飾線
  receipt += '='.repeat(RECEIPT_WIDTH) + '\n';

  // 小票標題（置中）
  receipt += centerText(headerText) + '\n';

  // 分隔線
  receipt += '-'.repeat(RECEIPT_WIDTH) + '\n';

  // 桌號信息
  receipt += `桌號: ${table_number}\n`;
  receipt += `人數: ${people_count} 位\n`;
  receipt += `入場時間: ${entry_time}\n`;
  receipt += '-'.repeat(RECEIPT_WIDTH) + '\n';

  // QR Code（根據配置決定是否顯示）
  if (config.show_qr_code !== false) {
    receipt += `QR Code: ${qr_code}\n`;
  }

  // 儲物柜信息（根據配置決定是否顯示）
  if (config.show_locker_info !== false && lockers && lockers.length > 0) {
    receipt += `儲物柜: ${lockers.join(', ')}\n`;
  }

  if (is_member) {
    receipt += '會員: 是\n';
  }

  receipt += '-'.repeat(RECEIPT_WIDTH) + '\n';

  // 注意事項（可以使用配置的header_text或footer_text？）
  // 暫時保持固定內容
  receipt += '注意事項:\n';
  receipt += '1. 請妥善保管此小票\n';
  receipt += '2. 憑此小票QR Code入場\n';
  receipt += '3. 儲物柜使用後請關好門\n';
  receipt += '4. 結賬時請出示此小票\n';

  // 底部裝飾線
  receipt += '='.repeat(RECEIPT_WIDTH) + '\n';

  // 底部文本（置中）
  if (config.footer_text && config.footer_text.trim()) {
    receipt += centerText(config.footer_text) + '\n';
  }

  // 聯繫信息（置中）
  if (config.contact_info && config.contact_info.trim()) {
    receipt += centerText(config.contact_info) + '\n';
  }

  // 最後一條裝飾線
  receipt += '='.repeat(RECEIPT_WIDTH) + '\n';

  return receipt;
}

// 生成結賬小票內容
function generateCheckoutReceipt(data, templateConfig = null) {
  const {
    table_number,
    qr_code,
    total_amount,
    checkout_time,
    order_items,
    transaction_id
  } = data;

  // 合併模板配置與默認配置
  const defaultConfig = getDefaultReceiptConfig();
  const config = templateConfig ? { ...defaultConfig, ...templateConfig } : defaultConfig;

  // 根據模板配置確定header_text（結賬小票）
  const headerText = config.header_text || '結賬小票';

  let receipt = '';

  // 頂部裝飾線
  receipt += '='.repeat(RECEIPT_WIDTH) + '\n';

  // 公司名稱（置中）
  if (config.company_name && config.company_name.trim()) {
    receipt += centerText(config.company_name) + '\n';
  }

  // 分店名稱（置中）
  if (config.store_name && config.store_name.trim()) {
    receipt += centerText(config.store_name) + '\n';
  }

  // 第二條裝飾線
  receipt += '='.repeat(RECEIPT_WIDTH) + '\n';

  // 小票標題（置中）
  receipt += centerText(headerText) + '\n';

  // 分隔線
  receipt += '-'.repeat(RECEIPT_WIDTH) + '\n';

  // 桌號信息
  receipt += `桌號: ${table_number}\n`;
  receipt += `結賬時間: ${checkout_time}\n`;
  receipt += '-'.repeat(RECEIPT_WIDTH) + '\n';

  // 購買項目
  if (order_items && order_items.length > 0) {
    receipt += '\n\n購買項目:\n';
    order_items.forEach((item) => {
      const itemTotal = item.quantity * item.price_at_time;
      receipt += `${item.product_name || '商品'} $${item.price_at_time} x${item.quantity}  = $${itemTotal}\n`;
    });
    receipt += '-'.repeat(RECEIPT_WIDTH) + '\n';
  }

  // 總金額
  receipt += `總金額: $${total_amount}\n`;
  receipt += '-'.repeat(RECEIPT_WIDTH) + '\n';

  // QR Code（根據配置決定是否顯示）
  if (config.show_qr_code !== false) {
    receipt += `QR Code: ${qr_code}\n`;
    receipt += '-'.repeat(RECEIPT_WIDTH) + '\n';
  }

  // 離場說明
  //receipt += '離場說明:\n';
  //receipt += '1. 請在5分鐘內離場\n';
  //receipt += '2. 在門鎖掃描QR Code離場\n';
  //receipt += '3. 歡迎再次光臨\n';

  // 底部裝飾線
  receipt += '='.repeat(RECEIPT_WIDTH) + '\n';

  // 底部文本（置中）
  if (config.footer_text && config.footer_text.trim()) {
    receipt += centerText(config.footer_text) + '\n';
  }

  // 聯繫信息（置中）
  if (config.contact_info && config.contact_info.trim()) {
    receipt += centerText(config.contact_info) + '\n';
  }

  // 最後一條裝飾線
  receipt += '='.repeat(RECEIPT_WIDTH) + '\n';

  return receipt;
}

// ==================== 小票模板管理API ====================

/**
 * @route GET /api/receipt/templates
 * @desc 獲取小票模板列表
 * @access Private/Admin
 */
router.get('/templates', authMiddleware.authenticate, (req, res) => {
  try {
    const employeeRole = req.employee?.role;
    const employeeStoreId = req.employee?.store_id;

    // 檢查權限 - 只有管理員可以訪問模板管理
    if (employeeRole !== 'admin') {
      return res.status(403).json({
        success: false,
        error: '權限不足',
        message: '只有管理員可以訪問小票模板管理'
      });
    }

    // 構建查詢條件
    let query = `
      SELECT rt.*,
             s.store_name,
             s.store_code,
             e.full_name as created_by_name
      FROM receipt_templates rt
      LEFT JOIN stores s ON rt.store_id = s.id
      LEFT JOIN employees e ON rt.created_by = e.id
      WHERE 1=1
    `;
    const params = [];

    // 如果員工有指定分店，只返回該分店的模板或通用模板
    if (employeeStoreId) {
      query += ` AND (rt.store_id = ? OR rt.store_id IS NULL)`;
      params.push(employeeStoreId);
    }

    query += ` ORDER BY rt.is_default DESC, rt.created_at DESC`;

    db.all(query, params, (err, templates) => {
      if (err) {
        console.error('查詢小票模板錯誤:', err);
        return res.status(500).json({
          success: false,
          error: '查詢失敗',
          message: err.message
        });
      }

      res.json({
        success: true,
        data: templates
      });
    });
  } catch (error) {
    console.error('獲取小票模板列表錯誤:', error);
    res.status(500).json({
      success: false,
      error: '服務器錯誤',
      message: error.message
    });
  }
});

/**
 * @route GET /api/receipt/templates/:id
 * @desc 獲取單個小票模板
 * @access Private/Admin
 */
router.get('/templates/:id', authMiddleware.authenticate, (req, res) => {
  try {
    const { id } = req.params;
    const employeeRole = req.employee?.role;

    if (employeeRole !== 'admin') {
      return res.status(403).json({
        success: false,
        error: '權限不足',
        message: '只有管理員可以查看小票模板'
      });
    }

    const query = `
      SELECT rt.*,
             s.store_name,
             s.store_code,
             e.full_name as created_by_name
      FROM receipt_templates rt
      LEFT JOIN stores s ON rt.store_id = s.id
      LEFT JOIN employees e ON rt.created_by = e.id
      WHERE rt.id = ?
    `;

    db.get(query, [id], (err, template) => {
      if (err) {
        console.error('查詢小票模板錯誤:', err);
        return res.status(500).json({
          success: false,
          error: '查詢失敗',
          message: err.message
        });
      }

      if (!template) {
        return res.status(404).json({
          success: false,
          error: '模板不存在',
          message: '指定的小票模板不存在'
        });
      }

      res.json({
        success: true,
        data: template
      });
    });
  } catch (error) {
    console.error('獲取小票模板錯誤:', error);
    res.status(500).json({
      success: false,
      error: '服務器錯誤',
      message: error.message
    });
  }
});

/**
 * @route POST /api/receipt/templates
 * @desc 創建小票模板
 * @access Private/Admin
 */
router.post('/templates', authMiddleware.authenticate, (req, res) => {
  try {
    const employeeRole = req.employee?.role;
    const employeeId = req.employee?.id;

    if (employeeRole !== 'admin') {
      return res.status(403).json({
        success: false,
        error: '權限不足',
        message: '只有管理員可以創建小票模板'
      });
    }

    const {
      template_name,
      store_id,
      is_default,
      config
    } = req.body;

    // 驗證必要字段
    if (!template_name || !config) {
      return res.status(400).json({
        success: false,
        error: '參數錯誤',
        message: '模板名稱和配置為必填項'
      });
    }

    // 如果設為默認模板，先取消其他默認模板
    if (is_default) {
      let resetQuery = `UPDATE receipt_templates SET is_default = 0`;
      const resetParams = [];

      if (store_id) {
        resetQuery += ` WHERE store_id = ?`;
        resetParams.push(store_id);
      } else {
        resetQuery += ` WHERE store_id IS NULL`;
      }

      db.run(resetQuery, resetParams, (err) => {
        if (err) {
          console.error('重置默認模板錯誤:', err);
        }
      });
    }

    const id = uuidv4();
    const query = `
      INSERT INTO receipt_templates
        (id, template_name, store_id, is_default, config, created_by, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    `;

    const params = [
      id,
      template_name,
      store_id || null,
      is_default ? 1 : 0,
      typeof config === 'string' ? config : JSON.stringify(config),
      employeeId
    ];

    db.run(query, params, function(err) {
      if (err) {
        console.error('創建小票模板錯誤:', err);
        return res.status(500).json({
          success: false,
          error: '創建失敗',
          message: err.message
        });
      }

      res.status(201).json({
        success: true,
        data: {
          id,
          template_name,
          store_id: store_id || null,
          is_default: is_default ? 1 : 0,
          config: typeof config === 'string' ? JSON.parse(config) : config
        },
        message: '小票模板創建成功'
      });
    });
  } catch (error) {
    console.error('創建小票模板錯誤:', error);
    res.status(500).json({
      success: false,
      error: '服務器錯誤',
      message: error.message
    });
  }
});

/**
 * @route PUT /api/receipt/templates/:id
 * @desc 更新小票模板
 * @access Private/Admin
 */
router.put('/templates/:id', authMiddleware.authenticate, (req, res) => {
  try {
    const { id } = req.params;
    const employeeRole = req.employee?.role;

    if (employeeRole !== 'admin') {
      return res.status(403).json({
        success: false,
        error: '權限不足',
        message: '只有管理員可以更新小票模板'
      });
    }

    const {
      template_name,
      store_id,
      is_default,
      config
    } = req.body;

    // 檢查模板是否存在
    db.get('SELECT store_id FROM receipt_templates WHERE id = ?', [id], (err, existing) => {
      if (err) {
        console.error('檢查模板錯誤:', err);
        return res.status(500).json({
          success: false,
          error: '檢查失敗',
          message: err.message
        });
      }

      if (!existing) {
        return res.status(404).json({
          success: false,
          error: '模板不存在',
          message: '指定的小票模板不存在'
        });
      }

      // 如果設為默認模板，先取消其他默認模板
      if (is_default) {
        let resetQuery = `UPDATE receipt_templates SET is_default = 0 WHERE id != ?`;
        const resetParams = [id];

        // 確定要重置的store_id條件
        let targetStoreId;
        if (store_id !== undefined && store_id !== null) {
          targetStoreId = store_id;
        } else {
          targetStoreId = existing.store_id;
        }

        // 構建store_id條件
        if (targetStoreId === null) {
          resetQuery += ` AND store_id IS NULL`;
        } else {
          resetQuery += ` AND store_id = ?`;
          resetParams.push(targetStoreId);
        }

        db.run(resetQuery, resetParams, (err) => {
          if (err) {
            console.error('重置默認模板錯誤:', err);
          }
        });
      }

      // 構建更新語句
      const updates = [];
      const params = [];

      if (template_name !== undefined) {
        updates.push('template_name = ?');
        params.push(template_name);
      }

      if (store_id !== undefined) {
        updates.push('store_id = ?');
        params.push(store_id || null);
      }

      if (is_default !== undefined) {
        updates.push('is_default = ?');
        params.push(is_default ? 1 : 0);
      }

      if (config !== undefined) {
        updates.push('config = ?');
        params.push(typeof config === 'string' ? config : JSON.stringify(config));
      }

      updates.push('updated_at = datetime("now")');

      if (updates.length === 0) {
        return res.status(400).json({
          success: false,
          error: '參數錯誤',
          message: '沒有提供更新字段'
        });
      }

      params.push(id);

      const query = `UPDATE receipt_templates SET ${updates.join(', ')} WHERE id = ?`;

      db.run(query, params, function(err) {
        if (err) {
          console.error('更新小票模板錯誤:', err);
          return res.status(500).json({
            success: false,
            error: '更新失敗',
            message: err.message
          });
        }

        if (this.changes === 0) {
          return res.status(404).json({
            success: false,
            error: '模板不存在',
            message: '指定的小票模板不存在'
          });
        }

        res.json({
          success: true,
          data: {
            id,
            template_name,
            store_id: store_id || null,
            is_default: is_default ? 1 : 0,
            config: config ? (typeof config === 'string' ? JSON.parse(config) : config) : undefined
          },
          message: '小票模板更新成功'
        });
      });
    });
  } catch (error) {
    console.error('更新小票模板錯誤:', error);
    res.status(500).json({
      success: false,
      error: '服務器錯誤',
      message: error.message
    });
  }
});

/**
 * @route DELETE /api/receipt/templates/:id
 * @desc 刪除小票模板
 * @access Private/Admin
 */
router.delete('/templates/:id', authMiddleware.authenticate, (req, res) => {
  try {
    const { id } = req.params;
    const employeeRole = req.employee?.role;

    if (employeeRole !== 'admin') {
      return res.status(403).json({
        success: false,
        error: '權限不足',
        message: '只有管理員可以刪除小票模板'
      });
    }

    // 檢查模板是否存在
    db.get('SELECT is_default FROM receipt_templates WHERE id = ?', [id], (err, template) => {
      if (err) {
        console.error('檢查模板錯誤:', err);
        return res.status(500).json({
          success: false,
          error: '檢查失敗',
          message: err.message
        });
      }

      if (!template) {
        return res.status(404).json({
          success: false,
          error: '模板不存在',
          message: '指定的小票模板不存在'
        });
      }

      // 禁止刪除默認模板
      if (template.is_default) {
        return res.status(400).json({
          success: false,
          error: '禁止操作',
          message: '不能刪除默認模板'
        });
      }

      db.run('DELETE FROM receipt_templates WHERE id = ?', [id], function(err) {
        if (err) {
          console.error('刪除小票模板錯誤:', err);
          return res.status(500).json({
            success: false,
            error: '刪除失敗',
            message: err.message
          });
        }

        if (this.changes === 0) {
          return res.status(404).json({
            success: false,
            error: '模板不存在',
            message: '指定的小票模板不存在'
          });
        }

        res.json({
          success: true,
          message: '小票模板刪除成功'
        });
      });
    });
  } catch (error) {
    console.error('刪除小票模板錯誤:', error);
    res.status(500).json({
      success: false,
      error: '服務器錯誤',
      message: error.message
    });
  }
});

/**
 * @route GET /api/receipt/templates/store/:store_id
 * @desc 獲取指定分店的小票模板
 * @access Private
 */
router.get('/templates/store/:store_id', authMiddleware.authenticate, (req, res) => {
  try {
    const { store_id } = req.params;
    const employeeRole = req.employee?.role;
    const employeeStoreId = req.employee?.store_id;

    // 檢查權限：員工只能訪問自己分店的模板
    if (employeeRole !== 'admin' && employeeStoreId !== store_id) {
      return res.status(403).json({
        success: false,
        error: '權限不足',
        message: '您只能訪問自己分店的模板'
      });
    }

    const query = `
      SELECT * FROM receipt_templates
      WHERE store_id = ? OR store_id IS NULL
      ORDER BY
        CASE WHEN store_id = ? THEN 0 ELSE 1 END, -- 優先顯示分店專用模板
        is_default DESC,
        created_at DESC
    `;

    db.all(query, [store_id, store_id], (err, templates) => {
      if (err) {
        console.error('查詢分店模板錯誤:', err);
        return res.status(500).json({
          success: false,
          error: '查詢失敗',
          message: err.message
        });
      }

      res.json({
        success: true,
        data: templates
      });
    });
  } catch (error) {
    console.error('獲取分店模板錯誤:', error);
    res.status(500).json({
      success: false,
      error: '服務器錯誤',
      message: error.message
    });
  }
});

// 重印結賬小票
// 暫時移除身份驗證用於調試
router.post('/reprint-checkout', async (req, res) => {
  try {
    const { record_id, store_id: requested_store_id } = req.body;

    if (!record_id) {
      return res.status(400).json({
        success: false,
        error: '參數錯誤',
        message: '請提供記錄ID'
      });
    }

    // 從數據庫獲取結賬記錄
    const record = await new Promise((resolve, reject) => {
      db.get('SELECT * FROM customers WHERE id = ?', [record_id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!record) {
      return res.status(404).json({
        success: false,
        error: '記錄不存在',
        message: '找不到指定的結賬記錄'
      });
    }

    // 獲取訂單項目
    const orderItems = await new Promise((resolve, reject) => {
      db.all(`
        SELECT
          oi.product_id,
          p.name as product_name,
          oi.quantity,
          oi.price_at_time,
          (oi.quantity * oi.price_at_time) as subtotal
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        WHERE oi.customer_id = ?
      `, [record_id], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    console.log('DEBUG reprint-checkout: 結賬記錄store_id =', record.store_id);

    // 構建打印請求體
    const printData = {
      table_number: record.table_number,
      qr_code: record.qr_code || record.id,
      total_amount: record.total_amount || 0,
      checkout_time: record.checkout_time || record.updated_at,
      order_items: orderItems,
      transaction_id: record.id
    };

    // 查找小票模板：優先分店專用，找不到才用全局默認
    let templateConfig = null;
    const storeId = requested_store_id || record.store_id || req.storeContext?.store_id || 'default_store';
    console.log('DEBUG reprint-checkout: 查詢模板, storeId =', storeId);
    try {
      templateConfig = await findReceiptTemplate(storeId);
    } catch (err) {
      console.error('獲取模板配置錯誤:', err);
    }

    console.log('DEBUG reprint-checkout: templateConfig =', templateConfig ? '找到' : '無');

    // 檢查打印機狀態 - 只檢查維護模式，不檢查在線狀態（測試打印成功表明打印機在線）
    // if (printerStatus.status !== 'online') {
    //   return res.status(503).json({
    //     success: false,
    //     error: '打印機離線',
    //     message: '打印機目前離線，無法打印',
    //     user_message: '打印機離線，請檢查連接'
    //   });
    // }

    if (printerStatus.maintenance_mode) {
      return res.status(503).json({
        success: false,
        error: '打印機維護中',
        message: '打印機處於維護模式',
        user_message: '打印機維護中，請稍後再試'
      });
    }

    // 使用現有的打印邏輯
    // 由於我們在同一個文件，可以直接調用打印隊列
    // 但為了代碼清晰，我們模擬一個請求對象
    console.log('DEBUG reprint-checkout: templateConfig before generate =', templateConfig);
    console.log('DEBUG reprint-checkout: printData =', printData);
    const receiptContent = generateCheckoutReceipt(printData, templateConfig);
    console.log('DEBUG reprint-checkout: receiptContent (first 200 chars) =', receiptContent.substring(0, 200));
    console.log('DEBUG reprint-checkout: receiptContent (full):\n' + receiptContent);
    const printJob = {
      type: 'checkout',
      table_number: printData.table_number,
      qr_code: printData.qr_code,
      total_amount: printData.total_amount,
      content: receiptContent,
      created_by: req.ip || 'unknown',
      store_id: storeId,
      template_config: templateConfig || null
    };

    try {
      // 添加到打印隊列
      const queuedJob = printQueue.addJob(printJob);

      // 記錄打印事件
      logPrinterEvent('reprint_queued', {
        job_id: queuedJob.id,
        type: 'checkout',
        table_number: printData.table_number,
        total_amount: printData.total_amount,
        original_record_id: record_id,
        queue_position: printQueue.jobs.length
      }, 'info');

      // 立即處理打印作業
      const result = await printQueue.processNext();

      // 觸發Socket事件（如果io可用）
      try {
        const io = req.app.get('io');
        if (io) {
          io.emit('receipt-printed', {
            type: 'checkout',
            table_number: printData.table_number,
            total_amount: printData.total_amount,
            timestamp: printerStatus.last_print,
            receipt_content: receiptContent,
            job_id: queuedJob.id,
            is_reprint: true
          });
        }
      } catch (ioError) {
        console.warn('無法觸發Socket事件:', ioError.message);
      }

      // 記錄成功事件
      logPrinterEvent('reprint_success', {
        job_id: queuedJob.id,
        type: 'checkout',
        table_number: printData.table_number,
        total_amount: printData.total_amount,
        original_record_id: record_id,
        print_count: printerStatus.print_count
      }, 'success');

      res.json({
        success: true,
        message: '結賬小票重印成功',
        receipt: {
          table_number: printData.table_number,
          total_amount: printData.total_amount,
          printed_at: printerStatus.last_print,
          job_id: queuedJob.id,
          content_preview: receiptContent.substring(0, 200) + '...',
          queue_stats: printQueue.getStats()
        },
        health: {
          score: printerStatus.health_score,
          paper_level: printerStatus.paper_level,
          temperature: printerStatus.temperature
        }
      });
    } catch (queueError) {
      printerStatus.error_count++;
      logPrinterEvent('reprint_failed', {
        error: queueError.message,
        table_number: printData.table_number,
        type: 'checkout',
        total_amount: printData.total_amount,
        original_record_id: record_id
      }, 'error');

      res.status(500).json({
        success: false,
        error: '打印隊列錯誤',
        message: queueError.message,
        user_message: getErrorMessage(queueError.message),
        queue_stats: printQueue.getStats()
      });
    }
  } catch (error) {
    console.error('重印小票錯誤:', error);
    res.status(500).json({
      success: false,
      error: '服務器錯誤',
      message: error.message
    });
  }
});


// 重新打印QR Code小票
router.post('/reprint-qr', async (req, res) => {
  try {
    const { customer_id, store_id: requested_store_id } = req.body;

    if (!customer_id) {
      return res.status(400).json({
        success: false,
        error: '參數錯誤',
        message: '請提供客戶ID'
      });
    }

    // 從數據庫獲取客人記錄
    const customer = await new Promise((resolve, reject) => {
      db.get('SELECT * FROM customers WHERE id = ?', [customer_id], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!customer) {
      return res.status(404).json({
        success: false,
        error: '客戶不存在',
        message: '找不到指定的客戶記錄'
      });
    }

    const storeId = requested_store_id || customer.store_id || req.storeContext?.store_id || 'default_store';
    const tableNumber = customer.table_number;
    const qrCode = customer.qr_code || customer.id;
    const entryTime = customer.entry_time
      ? new Date(customer.entry_time).toLocaleString('zh-TW')
      : new Date().toLocaleString('zh-TW');

    // 查找小票模板
    let templateConfig = null;
    try {
      templateConfig = await findReceiptTemplate(storeId);
    } catch (err) {
      console.error('獲取模板配置錯誤:', err);
    }

    if (printerStatus.maintenance_mode) {
      return res.status(503).json({
        success: false,
        error: '打印機維護中',
        message: '打印機處於維護模式',
        user_message: '打印機維護中，請稍後再試'
      });
    }

    // 生成QR Code重印小票（精簡格式：全部置中，無裝飾線）
    let receiptContent = '';
    receiptContent += centerText(`入場時間: ${entryTime}`) + '\n';
    receiptContent += centerText('二維碼用作離場結賬和購買貓零食, 請保存') + '\n';
    receiptContent += `\$QR_CODE:${qrCode}\$\n`;

    const printJob = {
      type: 'reprint-qr',
      table_number: tableNumber,
      qr_code: qrCode,
      content: receiptContent,
      created_by: req.ip || 'unknown',
      store_id: storeId,
      template_config: templateConfig || null
    };

    try {
      // 添加到打印隊列
      const queuedJob = printQueue.addJob(printJob);

      logPrinterEvent('reprint_qr_queued', {
        job_id: queuedJob.id,
        type: 'entry',
        table_number: tableNumber,
        customer_id: customer_id,
        queue_position: printQueue.jobs.length
      }, 'info');

      // 立即處理打印作業
      await printQueue.processNext();

      // 觸發Socket事件
      try {
        const io = req.app.get('io');
        if (io) {
          io.emit('receipt-printed', {
            type: 'entry',
            table_number: tableNumber,
            timestamp: printerStatus.last_print,
            receipt_content: receiptContent,
            job_id: queuedJob.id,
            is_reprint: true
          });
        }
      } catch (ioError) {
        console.warn('無法觸發Socket事件:', ioError.message);
      }

      logPrinterEvent('reprint_qr_success', {
        job_id: queuedJob.id,
        type: 'entry',
        table_number: tableNumber,
        customer_id: customer_id,
        print_count: printerStatus.print_count
      }, 'success');

      res.json({
        success: true,
        message: 'QR Code小票重印成功',
        receipt: {
          table_number: tableNumber,
          printed_at: printerStatus.last_print,
          job_id: queuedJob.id,
          content_preview: receiptContent.substring(0, 200) + '...',
          queue_stats: printQueue.getStats()
        },
        health: {
          score: printerStatus.health_score,
          paper_level: printerStatus.paper_level,
          temperature: printerStatus.temperature
        }
      });
    } catch (queueError) {
      printerStatus.error_count++;
      logPrinterEvent('reprint_qr_failed', {
        error: queueError.message,
        table_number: tableNumber,
        type: 'entry',
        customer_id: customer_id
      }, 'error');

      res.status(500).json({
        success: false,
        error: '打印隊列錯誤',
        message: queueError.message,
        user_message: getErrorMessage(queueError.message),
        queue_stats: printQueue.getStats()
      });
    }
  } catch (error) {
    console.error('重印QR Code錯誤:', error);
    res.status(500).json({
      success: false,
      error: '服務器錯誤',
      message: error.message
    });
  }
});


// 調試端點：檢查打印機狀態
router.get('/debug-printer-status', (req, res) => {
  res.json({
    success: true,
    printerStatus,
    timestamp: new Date().toISOString()
  });
});

module.exports = router;
module.exports.printerStatus = printerStatus;
module.exports.findReceiptTemplate = findReceiptTemplate;
module.exports.generateCheckoutReceipt = generateCheckoutReceipt;
module.exports.printQueue = printQueue;
module.exports.logPrinterEvent = logPrinterEvent;
module.exports.getErrorMessage = getErrorMessage;