const express = require('express');
const router = express.Router();
const storeAwareMiddleware = require('../middleware/store-aware');
const { v4: uuidv4 } = require('uuid');

// 為所有路由添加分店上下文中間件
router.use(storeAwareMiddleware.initStoreContext);

// 門鎖配置
const DOOR_CONFIG = {
  DEFAULT_OPEN_DURATION: 5000, // 預設開門持續時間（毫秒）
  QR_CODE_VALIDITY: 300000,    // QR Code有效期（5分鐘，毫秒）
  HEARTBEAT_INTERVAL: 30000,   // 心跳間隔（毫秒）
  MAX_ALLOWED_CODES: 100,      // 最大允許QR Code數量
  AUTO_CLOSE_ENABLED: true,    // 啟用自動關門
  EMERGENCY_OVERRIDE: true,    // 啟用緊急覆蓋
  SIMULATE_HARDWARE_ERRORS: false, // 模擬硬件錯誤
};

// 門鎖設備狀態（支持多個門鎖）
let doorLocks = {
  'door-lock-001': {
    device_id: 'door-lock-001',
    status: 'online',
    last_seen: new Date().toISOString(),
    door_open: false,
    last_opened: null,
    last_closed: null,
    allowed_qr_codes: [], // 允許通行的QR Code列表
    ip_address: null,
    location: 'main-entrance', // 入口位置
    hardware_status: {
      motor_ok: true,
      sensor_ok: true,
      power_ok: true,
      communication_ok: true
    },
    stats: {
      total_opens: 0,
      successful_auth: 0,
      failed_auth: 0,
      manual_opens: 0,
      emergency_opens: 0
    },
    config: { ...DOOR_CONFIG }
  }
};

// 門鎖事件日誌
let doorEvents = [];

// 添加門鎖事件記錄
function logDoorEvent(device_id, event_type, details = {}) {
  const event = {
    event_id: uuidv4(),
    device_id: device_id,
    event_type: event_type,
    details: details,
    timestamp: new Date().toISOString()
  };

  doorEvents.unshift(event); // 添加到開頭以便最新事件在前面

  // 保留最近1000個事件
  if (doorEvents.length > 1000) {
    doorEvents = doorEvents.slice(0, 1000);
  }

  // 觸發Socket事件
  try {
    const io = require('../index').io;
    if (io) {
      io.emit('door-event-logged', event);
    }
  } catch (error) {
    console.error('觸發門鎖事件Socket錯誤:', error);
  }

  return event;
}

// 獲取指定門鎖狀態
function getDoorLock(device_id) {
  return doorLocks[device_id] || doorLocks['door-lock-001'];
}

// 模擬硬件錯誤（如果啟用）
function simulateHardwareError(doorLock) {
  if (!DOOR_CONFIG.SIMULATE_HARDWARE_ERRORS) return false;

  // 5% 機率模擬硬件錯誤
  if (Math.random() < 0.05) {
    const errorType = ['motor', 'sensor', 'power', 'communication'][Math.floor(Math.random() * 4)];
    doorLock.hardware_status[`${errorType}_ok`] = false;
    doorLock.status = 'error';
    logDoorEvent(doorLock.device_id, 'hardware_error', { error_type: errorType });
    return true;
  }
  return false;
}

// 檢查門鎖健康狀態
function checkDoorLockHealth(doorLock) {
  const hardwareStatus = doorLock.hardware_status;
  const allOk = Object.values(hardwareStatus).every(status => status === true);

  if (!allOk) {
    doorLock.status = 'error';
    return false;
  }

  // 檢查最後心跳時間
  const lastSeen = new Date(doorLock.last_seen);
  const now = new Date();
  const timeDiff = now - lastSeen;

  if (timeDiff > DOOR_CONFIG.HEARTBEAT_INTERVAL * 2) {
    doorLock.status = 'offline';
    return false;
  }

  doorLock.status = 'online';
  return true;
}

// 門鎖設備註冊/心跳
router.post('/heartbeat', (req, res) => {
  try {
    const { device_id, status, ip_address, location, hardware_status } = req.body;
    const doorId = device_id || 'door-lock-001';

    // 如果門鎖不存在，創建新門鎖
    if (!doorLocks[doorId]) {
      doorLocks[doorId] = {
        device_id: doorId,
        status: 'online',
        last_seen: new Date().toISOString(),
        door_open: false,
        last_opened: null,
        last_closed: null,
        allowed_qr_codes: [],
        ip_address: null,
        location: 'unknown',
        hardware_status: {
          motor_ok: true,
          sensor_ok: true,
          power_ok: true,
          communication_ok: true
        },
        stats: {
          total_opens: 0,
          successful_auth: 0,
          failed_auth: 0,
          manual_opens: 0,
          emergency_opens: 0
        },
        config: { ...DOOR_CONFIG }
      };
    }

    // 更新門鎖狀態
    const doorLock = doorLocks[doorId];
    doorLock.status = status || 'online';
    doorLock.last_seen = new Date().toISOString();
    doorLock.ip_address = ip_address || doorLock.ip_address;
    doorLock.location = location || doorLock.location;

    // 更新硬件狀態（如果提供）
    if (hardware_status && typeof hardware_status === 'object') {
      Object.keys(hardware_status).forEach(key => {
        if (doorLock.hardware_status.hasOwnProperty(key)) {
          doorLock.hardware_status[key] = hardware_status[key];
        }
      });
    }

    // 檢查健康狀態
    checkDoorLockHealth(doorLock);

    // 更新數據庫中的設備狀態
    const db = require('../../database/db').db;
    db.run(
      `INSERT OR REPLACE INTO devices (id, device_type, device_id, status, last_seen, ip_address, location, hardware_status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        uuidv4(),
        'door-lock',
        doorLock.device_id,
        doorLock.status,
        doorLock.last_seen,
        doorLock.ip_address,
        doorLock.location,
        JSON.stringify(doorLock.hardware_status)
      ],
      (err) => {
        if (err) console.error('更新設備狀態錯誤:', err);
      }
    );

    // 記錄心跳事件
    logDoorEvent(doorId, 'heartbeat', {
      status: doorLock.status,
      hardware_status: doorLock.hardware_status
    });

    res.json({
      success: true,
      message: '門鎖心跳接收成功',
      status: {
        device_id: doorLock.device_id,
        status: doorLock.status,
        last_seen: doorLock.last_seen,
        door_open: doorLock.door_open,
        location: doorLock.location,
        hardware_status: doorLock.hardware_status,
        stats: doorLock.stats,
        config: doorLock.config
      }
    });
  } catch (error) {
    console.error('門鎖心跳錯誤:', error);
    res.status(500).json({
      error: '門鎖心跳處理失敗',
      message: error.message
    });
  }
});

// QR Code驗證（門鎖端）
router.post('/verify', (req, res) => {
  try {
    const { qr_code, device_id } = req.body;

    if (!qr_code) {
      return res.status(400).json({ error: '請提供QR Code' });
    }

    const doorId = device_id || 'door-lock-001';
    const doorLock = getDoorLock(doorId);

    // 檢查門鎖狀態
    if (!checkDoorLockHealth(doorLock)) {
      return res.status(503).json({
        success: false,
        valid: false,
        door_open: false,
        message: '門鎖設備故障，請聯繫工作人員',
        error_code: 'DOOR_HARDWARE_ERROR'
      });
    }

    // 模擬硬件錯誤（如果啟用）
    if (simulateHardwareError(doorLock)) {
      return res.status(503).json({
        success: false,
        valid: false,
        door_open: false,
        message: '門鎖設備臨時故障，請稍後重試',
        error_code: 'DOOR_SIMULATED_ERROR'
      });
    }

    // 檢查QR Code是否在允許列表中
    const allowedEntry = doorLock.allowed_qr_codes.find(
      entry => entry.qr_code === qr_code && entry.valid_until > Date.now()
    );

    if (allowedEntry) {
      // 檢查門是否已經打開
      if (doorLock.door_open) {
        return res.json({
          success: true,
          valid: true,
          door_open: true,
          message: '門鎖已開啟，請通行',
          already_open: true,
          duration: doorLock.config.DEFAULT_OPEN_DURATION / 1000
        });
      }

      // 開門
      doorLock.door_open = true;
      doorLock.last_opened = new Date().toISOString();
      doorLock.stats.successful_auth++;
      doorLock.stats.total_opens++;

      // 從允許列表中移除（一次性使用）
      doorLock.allowed_qr_codes = doorLock.allowed_qr_codes.filter(
        entry => entry.qr_code !== qr_code
      );

      // 記錄事件
      const event = logDoorEvent(doorId, 'door_opened', {
        qr_code: qr_code,
        customer_id: allowedEntry.customer_id,
        entry_type: 'qr_verification'
      });

      // 觸發開門事件
      const io = req.app.get('io');
      io.emit('door-opened', {
        qr_code: qr_code,
        device_id: doorLock.device_id,
        timestamp: doorLock.last_opened,
        location: doorLock.location,
        event_id: event.event_id
      });

      // 設定自動關門（如果啟用）
      if (doorLock.config.AUTO_CLOSE_ENABLED) {
        setTimeout(() => {
          if (doorLock.door_open) {
            doorLock.door_open = false;
            doorLock.last_closed = new Date().toISOString();

            const closeEvent = logDoorEvent(doorId, 'door_closed_auto', {
              open_duration: doorLock.config.DEFAULT_OPEN_DURATION
            });

            io.emit('door-closed', {
              device_id: doorLock.device_id,
              timestamp: doorLock.last_closed,
              location: doorLock.location,
              reason: 'auto_close',
              event_id: closeEvent.event_id
            });
          }
        }, doorLock.config.DEFAULT_OPEN_DURATION);
      }

      res.json({
        success: true,
        valid: true,
        door_open: true,
        message: 'QR Code驗證成功，門鎖已開啟',
        duration: doorLock.config.DEFAULT_OPEN_DURATION / 1000,
        location: doorLock.location,
        event_id: event.event_id
      });
    } else {
      // 驗證失敗
      doorLock.stats.failed_auth++;
      logDoorEvent(doorId, 'verification_failed', {
        qr_code: qr_code,
        reason: 'invalid_or_expired'
      });

      res.json({
        success: false,
        valid: false,
        door_open: false,
        message: 'QR Code無效或已過期',
        error_code: 'INVALID_QR_CODE'
      });
    }
  } catch (error) {
    console.error('門鎖驗證錯誤:', error);
    res.status(500).json({
      error: '門鎖驗證失敗',
      message: error.message
    });
  }
});

// 添加允許通行的QR Code（由系統調用）
router.post('/allow-entry', (req, res) => {
  try {
    const { qr_code, valid_until, customer_id, device_id, entry_type } = req.body;

    if (!qr_code) {
      return res.status(400).json({ error: '請提供QR Code' });
    }

    const doorId = device_id || 'door-lock-001';
    const doorLock = getDoorLock(doorId);

    // 檢查允許列表是否已滿
    if (doorLock.allowed_qr_codes.length >= doorLock.config.MAX_ALLOWED_CODES) {
      // 清理過期的條目
      doorLock.allowed_qr_codes = doorLock.allowed_qr_codes.filter(
        entry => entry.valid_until > Date.now()
      );

      // 如果還是滿的，移除最舊的條目
      if (doorLock.allowed_qr_codes.length >= doorLock.config.MAX_ALLOWED_CODES) {
        doorLock.allowed_qr_codes.sort((a, b) => a.added_at - b.added_at);
        doorLock.allowed_qr_codes = doorLock.allowed_qr_codes.slice(-doorLock.config.MAX_ALLOWED_CODES + 1);
      }
    }

    const validUntil = valid_until || Date.now() + doorLock.config.QR_CODE_VALIDITY; // 使用配置的有效期

    // 檢查QR Code是否已存在
    const existingIndex = doorLock.allowed_qr_codes.findIndex(
      entry => entry.qr_code === qr_code
    );

    if (existingIndex >= 0) {
      // 更新現有條目
      doorLock.allowed_qr_codes[existingIndex] = {
        ...doorLock.allowed_qr_codes[existingIndex],
        valid_until: validUntil,
        customer_id: customer_id || doorLock.allowed_qr_codes[existingIndex].customer_id,
        entry_type: entry_type || doorLock.allowed_qr_codes[existingIndex].entry_type,
        updated_at: Date.now()
      };
    } else {
      // 添加到允許列表
      doorLock.allowed_qr_codes.push({
        qr_code,
        valid_until: validUntil,
        customer_id: customer_id,
        entry_type: entry_type || 'entry', // entry, exit, emergency
        added_at: Date.now(),
        updated_at: Date.now()
      });
    }

    // 清理過期的條目
    doorLock.allowed_qr_codes = doorLock.allowed_qr_codes.filter(
      entry => entry.valid_until > Date.now()
    );

    // 記錄事件
    logDoorEvent(doorId, 'qr_code_allowed', {
      qr_code: qr_code,
      customer_id: customer_id,
      valid_until: new Date(validUntil).toISOString(),
      entry_type: entry_type || 'entry',
      device_id: doorId
    });

    res.json({
      success: true,
      message: '已添加允許通行的QR Code',
      qr_code: qr_code,
      valid_until: new Date(validUntil).toISOString(),
      entries_count: doorLock.allowed_qr_codes.length,
      device_id: doorId,
      location: doorLock.location
    });
  } catch (error) {
    console.error('添加允許通行錯誤:', error);
    res.status(500).json({
      error: '添加允許通行失敗',
      message: error.message
    });
  }
});

// 手動開門（測試/緊急用）
router.post('/open', (req, res) => {
  try {
    const { duration, device_id, reason } = req.body;
    const doorId = device_id || 'door-lock-001';
    const doorLock = getDoorLock(doorId);

    // 檢查門鎖狀態
    if (!checkDoorLockHealth(doorLock)) {
      return res.status(503).json({
        success: false,
        message: '門鎖設備故障，無法手動開啟',
        error_code: 'DOOR_HARDWARE_ERROR'
      });
    }

    const openDuration = duration || doorLock.config.DEFAULT_OPEN_DURATION;

    // 檢查門是否已經打開
    if (doorLock.door_open) {
      return res.json({
        success: true,
        message: '門鎖已開啟，無需重複操作',
        already_open: true,
        duration: doorLock.config.DEFAULT_OPEN_DURATION / 1000
      });
    }

    // 開門
    doorLock.door_open = true;
    doorLock.last_opened = new Date().toISOString();
    doorLock.stats.manual_opens++;
    doorLock.stats.total_opens++;

    // 記錄事件
    const event = logDoorEvent(doorId, 'door_manual_open', {
      duration: openDuration,
      reason: reason || 'manual_operation',
      operator: 'system'
    });

    // 觸發開門事件
    const io = req.app.get('io');
    io.emit('door-opened', {
      device_id: doorLock.device_id,
      manual: true,
      timestamp: doorLock.last_opened,
      location: doorLock.location,
      reason: reason || 'manual_operation',
      duration: openDuration,
      event_id: event.event_id
    });

    // 設定自動關門（如果啟用）
    if (doorLock.config.AUTO_CLOSE_ENABLED) {
      setTimeout(() => {
        if (doorLock.door_open) {
          doorLock.door_open = false;
          doorLock.last_closed = new Date().toISOString();

          const closeEvent = logDoorEvent(doorId, 'door_closed_auto', {
            open_duration: openDuration,
            reason: 'manual_open_timeout'
          });

          io.emit('door-closed', {
            device_id: doorLock.device_id,
            timestamp: doorLock.last_closed,
            location: doorLock.location,
            reason: 'auto_close_after_manual',
            event_id: closeEvent.event_id
          });
        }
      }, openDuration);
    }

    res.json({
      success: true,
      message: '門鎖已手動開啟',
      duration: openDuration / 1000,
      door_open: true,
      device_id: doorId,
      location: doorLock.location,
      event_id: event.event_id
    });
  } catch (error) {
    console.error('手動開門錯誤:', error);
    res.status(500).json({
      error: '手動開門失敗',
      message: error.message
    });
  }
});

// 獲取門鎖狀態
router.get('/status', (req, res) => {
  try {
    const { device_id, include_events, include_allowed } = req.query;
    const doorId = device_id || 'door-lock-001';
    const doorLock = getDoorLock(doorId);

    // 檢查健康狀態
    checkDoorLockHealth(doorLock);

    // 清理過期的允許條目
    doorLock.allowed_qr_codes = doorLock.allowed_qr_codes.filter(
      entry => entry.valid_until > Date.now()
    );

    const response = {
      success: true,
      device: {
        device_id: doorLock.device_id,
        status: doorLock.status,
        last_seen: doorLock.last_seen,
        door_open: doorLock.door_open,
        last_opened: doorLock.last_opened,
        last_closed: doorLock.last_closed,
        location: doorLock.location,
        ip_address: doorLock.ip_address,
        hardware_status: doorLock.hardware_status,
        stats: doorLock.stats,
        config: doorLock.config
      },
      allowed_count: doorLock.allowed_qr_codes.length,
      uptime: new Date() - new Date(doorLock.last_seen),
      total_devices: Object.keys(doorLocks).length
    };

    // 包含允許的QR Code列表（如果請求）
    if (include_allowed === 'true') {
      response.allowed_qr_codes = doorLock.allowed_qr_codes.map(entry => ({
        qr_code: entry.qr_code,
        valid_until: new Date(entry.valid_until).toISOString(),
        customer_id: entry.customer_id,
        entry_type: entry.entry_type,
        added_at: new Date(entry.added_at).toISOString()
      }));
    }

    // 包含最近事件（如果請求）
    if (include_events === 'true') {
      const deviceEvents = doorEvents.filter(event => event.device_id === doorId);
      response.recent_events = deviceEvents.slice(0, 20); // 返回最近20個事件
    }

    res.json(response);
  } catch (error) {
    console.error('獲取門鎖狀態錯誤:', error);
    res.status(500).json({
      error: '獲取門鎖狀態失敗',
      message: error.message
    });
  }
});

// 門鎖事件記錄（外部系統記錄事件）
router.post('/event', (req, res) => {
  try {
    const { event_type, qr_code, details, device_id, severity } = req.body;
    const doorId = device_id || 'door-lock-001';
    const doorLock = getDoorLock(doorId);

    const event = logDoorEvent(doorId, event_type || 'unknown', {
      qr_code: qr_code,
      details: details,
      severity: severity || 'info',
      source: 'external'
    });

    // 根據事件類型採取行動
    if (event_type === 'emergency_override') {
      // 緊急覆蓋 - 強制開門
      if (doorLock.config.EMERGENCY_OVERRIDE) {
        doorLock.door_open = true;
        doorLock.last_opened = new Date().toISOString();
        doorLock.stats.emergency_opens++;
        doorLock.stats.total_opens++;

        const io = req.app.get('io');
        io.emit('door-emergency-override', {
          device_id: doorLock.device_id,
          timestamp: doorLock.last_opened,
          location: doorLock.location,
          reason: details?.reason || 'emergency_override',
          event_id: event.event_id
        });

        // 設定30秒後自動關閉（緊急情況下更長）
        setTimeout(() => {
          if (doorLock.door_open) {
            doorLock.door_open = false;
            doorLock.last_closed = new Date().toISOString();

            logDoorEvent(doorId, 'door_closed_emergency', {
              open_duration: 30000,
              reason: 'emergency_timeout'
            });
          }
        }, 30000);
      }
    }

    res.json({
      success: true,
      message: '門鎖事件記錄成功',
      event: event
    });
  } catch (error) {
    console.error('門鎖事件記錄錯誤:', error);
    res.status(500).json({
      error: '門鎖事件記錄失敗',
      message: error.message
    });
  }
});

// 緊急開門（無需驗證，管理員使用）
router.post('/emergency-open', (req, res) => {
  try {
    const { device_id, duration, reason, operator } = req.body;
    const doorId = device_id || 'door-lock-001';
    const doorLock = getDoorLock(doorId);

    // 檢查緊急覆蓋是否啟用
    if (!doorLock.config.EMERGENCY_OVERRIDE) {
      return res.status(403).json({
        success: false,
        message: '緊急開門功能已禁用',
        error_code: 'EMERGENCY_DISABLED'
      });
    }

    const openDuration = duration || 30000; // 緊急情況預設30秒

    // 開門
    doorLock.door_open = true;
    doorLock.last_opened = new Date().toISOString();
    doorLock.stats.emergency_opens++;
    doorLock.stats.total_opens++;

    // 記錄事件
    const event = logDoorEvent(doorId, 'door_emergency_open', {
      duration: openDuration,
      reason: reason || 'emergency_operation',
      operator: operator || 'unknown',
      source: 'emergency_endpoint'
    });

    // 觸發緊急開門事件
    const io = req.app.get('io');
    io.emit('door-emergency-opened', {
      device_id: doorLock.device_id,
      timestamp: doorLock.last_opened,
      location: doorLock.location,
      reason: reason || 'emergency_operation',
      operator: operator || 'unknown',
      duration: openDuration,
      event_id: event.event_id
    });

    // 設定自動關閉
    setTimeout(() => {
      if (doorLock.door_open) {
        doorLock.door_open = false;
        doorLock.last_closed = new Date().toISOString();

        const closeEvent = logDoorEvent(doorId, 'door_closed_emergency', {
          open_duration: openDuration,
          reason: 'emergency_timeout'
        });

        io.emit('door-closed', {
          device_id: doorLock.device_id,
          timestamp: doorLock.last_closed,
          location: doorLock.location,
          reason: 'emergency_auto_close',
          event_id: closeEvent.event_id
        });
      }
    }, openDuration);

    res.json({
      success: true,
      message: '門鎖已緊急開啟',
      duration: openDuration / 1000,
      door_open: true,
      device_id: doorId,
      location: doorLock.location,
      event_id: event.event_id
    });
  } catch (error) {
    console.error('緊急開門錯誤:', error);
    res.status(500).json({
      error: '緊急開門失敗',
      message: error.message
    });
  }
});

// 重置硬件狀態（修復模擬錯誤）
router.post('/reset-hardware', (req, res) => {
  try {
    const { device_id } = req.body;
    const doorId = device_id || 'door-lock-001';
    const doorLock = getDoorLock(doorId);

    // 重置所有硬件狀態為正常
    Object.keys(doorLock.hardware_status).forEach(key => {
      doorLock.hardware_status[key] = true;
    });

    doorLock.status = 'online';

    // 記錄事件
    logDoorEvent(doorId, 'hardware_reset', {
      reset_by: 'system',
      previous_status: doorLock.status
    });

    res.json({
      success: true,
      message: '硬件狀態已重置',
      device_id: doorId,
      hardware_status: doorLock.hardware_status,
      status: doorLock.status
    });
  } catch (error) {
    console.error('重置硬件狀態錯誤:', error);
    res.status(500).json({
      error: '重置硬件狀態失敗',
      message: error.message
    });
  }
});

// 獲取所有門鎖狀態
router.get('/all-status', (req, res) => {
  try {
    const doorStatuses = Object.keys(doorLocks).map(doorId => {
      const doorLock = doorLocks[doorId];
      checkDoorLockHealth(doorLock); // 檢查健康狀態

      // 清理過期的允許條目
      doorLock.allowed_qr_codes = doorLock.allowed_qr_codes.filter(
        entry => entry.valid_until > Date.now()
      );

      return {
        device_id: doorLock.device_id,
        status: doorLock.status,
        last_seen: doorLock.last_seen,
        door_open: doorLock.door_open,
        location: doorLock.location,
        hardware_status: doorLock.hardware_status,
        allowed_count: doorLock.allowed_qr_codes.length,
        stats: doorLock.stats
      };
    });

    const summary = {
      total: doorStatuses.length,
      online: doorStatuses.filter(d => d.status === 'online').length,
      offline: doorStatuses.filter(d => d.status === 'offline').length,
      error: doorStatuses.filter(d => d.status === 'error').length,
      open: doorStatuses.filter(d => d.door_open).length,
      total_allowed_codes: doorStatuses.reduce((sum, d) => sum + d.allowed_count, 0)
    };

    res.json({
      success: true,
      summary: summary,
      doors: doorStatuses
    });
  } catch (error) {
    console.error('獲取所有門鎖狀態錯誤:', error);
    res.status(500).json({
      error: '獲取所有門鎖狀態失敗',
      message: error.message
    });
  }
});

// 門鎖診斷端點
router.get('/diagnostics', (req, res) => {
  try {
    const { device_id } = req.query;
    const doorId = device_id || 'door-lock-001';
    const doorLock = getDoorLock(doorId);

    // 執行診斷檢查
    const diagnostics = {
      device_id: doorLock.device_id,
      timestamp: new Date().toISOString(),
      checks: {
        heartbeat: {
          status: doorLock.last_seen ? 'ok' : 'error',
          last_seen: doorLock.last_seen,
          age_ms: doorLock.last_seen ? new Date() - new Date(doorLock.last_seen) : null
        },
        hardware: {
          status: Object.values(doorLock.hardware_status).every(v => v === true) ? 'ok' : 'error',
          details: doorLock.hardware_status
        },
        door_state: {
          status: doorLock.door_open ? 'open' : 'closed',
          last_opened: doorLock.last_opened,
          last_closed: doorLock.last_closed
        },
        allowed_codes: {
          status: doorLock.allowed_qr_codes.length < doorLock.config.MAX_ALLOWED_CODES ? 'ok' : 'warning',
          count: doorLock.allowed_qr_codes.length,
          max_allowed: doorLock.config.MAX_ALLOWED_CODES,
          expired_count: doorLock.allowed_qr_codes.filter(entry => entry.valid_until <= Date.now()).length
        },
        configuration: {
          status: 'ok',
          auto_close_enabled: doorLock.config.AUTO_CLOSE_ENABLED,
          emergency_override: doorLock.config.EMERGENCY_OVERRIDE,
          default_open_duration: doorLock.config.DEFAULT_OPEN_DURATION
        }
      },
      stats: doorLock.stats,
      recommendations: []
    };

    // 生成建議
    if (diagnostics.checks.heartbeat.age_ms > doorLock.config.HEARTBEAT_INTERVAL * 2) {
      diagnostics.recommendations.push('門鎖心跳超時，請檢查設備連線');
    }

    if (!diagnostics.checks.hardware.status === 'ok') {
      diagnostics.recommendations.push('硬件故障，需要維護');
    }

    if (diagnostics.checks.allowed_codes.expired_count > 10) {
      diagnostics.recommendations.push('過期QR Code過多，建議清理');
    }

    res.json({
      success: true,
      diagnostics: diagnostics
    });
  } catch (error) {
    console.error('門鎖診斷錯誤:', error);
    res.status(500).json({
      error: '門鎖診斷失敗',
      message: error.message
    });
  }
});

// 清除過期QR Code
router.post('/cleanup', (req, res) => {
  try {
    const { device_id } = req.body;
    const doorId = device_id || 'door-lock-001';
    const doorLock = getDoorLock(doorId);

    const beforeCount = doorLock.allowed_qr_codes.length;

    // 清理過期的條目
    doorLock.allowed_qr_codes = doorLock.allowed_qr_codes.filter(
      entry => entry.valid_until > Date.now()
    );

    const afterCount = doorLock.allowed_qr_codes.length;
    const cleanedCount = beforeCount - afterCount;

    // 記錄事件
    if (cleanedCount > 0) {
      logDoorEvent(doorId, 'qr_codes_cleaned', {
        cleaned_count: cleanedCount,
        remaining_count: afterCount
      });
    }

    res.json({
      success: true,
      message: `已清理 ${cleanedCount} 個過期QR Code`,
      before: beforeCount,
      after: afterCount,
      cleaned: cleanedCount,
      device_id: doorId
    });
  } catch (error) {
    console.error('清理QR Code錯誤:', error);
    res.status(500).json({
      error: '清理QR Code失敗',
      message: error.message
    });
  }
});

// 更新門鎖配置
router.post('/config', (req, res) => {
  try {
    const { device_id, config } = req.body;
    const doorId = device_id || 'door-lock-001';
    const doorLock = getDoorLock(doorId);

    if (!config || typeof config !== 'object') {
      return res.status(400).json({ error: '請提供有效的配置對象' });
    }

    // 更新配置（只允許更新特定字段）
    const allowedConfigKeys = [
      'DEFAULT_OPEN_DURATION',
      'QR_CODE_VALIDITY',
      'HEARTBEAT_INTERVAL',
      'MAX_ALLOWED_CODES',
      'AUTO_CLOSE_ENABLED',
      'EMERGENCY_OVERRIDE',
      'SIMULATE_HARDWARE_ERRORS'
    ];

    const oldConfig = { ...doorLock.config };

    allowedConfigKeys.forEach(key => {
      if (config[key] !== undefined) {
        doorLock.config[key] = config[key];
      }
    });

    // 記錄配置更改事件
    logDoorEvent(doorId, 'config_updated', {
      old_config: oldConfig,
      new_config: doorLock.config,
      changed_by: 'api'
    });

    res.json({
      success: true,
      message: '門鎖配置已更新',
      device_id: doorId,
      config: doorLock.config
    });
  } catch (error) {
    console.error('更新門鎖配置錯誤:', error);
    res.status(500).json({
      error: '更新門鎖配置失敗',
      message: error.message
    });
  }
});

module.exports = router;