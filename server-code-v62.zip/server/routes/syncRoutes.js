// 加載環境變量
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../../.env') });

const express = require('express');
const router = express.Router();
// 調試中間件：記錄所有進入 /api/sync 的請求
router.use((req, res, next) => {
    console.log(`[SYNC路由調試] ${req.method} ${req.originalUrl}`, {
        headers: {
            authorization: req.headers.authorization ? 'Bearer [有令牌]' : '無令牌',
            'x-api-key': req.headers['x-api-key'] ? '[有API密鑰]' : '無API密鑰'
        },
        query: req.query,
        body: req.body
    });
    next();
});
const axios = require('axios');
const { v4: uuidv4 } = require('uuid');
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');
const storeAwareMiddleware = require('../middleware/store-aware');

// 上傳管理器
let BillUploadManager;
try {
    BillUploadManager = require('../../upload-bills');
    console.log('✓ upload-bills 模塊加載成功');
} catch (e) {
    console.warn('⚠️ upload-bills 模塊未找到:', e.message);
}

let BillCleanupManager;
try {
    BillCleanupManager = require('../../cleanup-bills');
    console.log('✓ cleanup-bills 模塊加載成功');
} catch (e) {
    console.warn('⚠️ cleanup-bills 模塊未找到，將使用空實現:', e.message);
    BillCleanupManager = class {
        async getCleanupStats() {
            return {
                cleanup_eligible: 0,
                total_uploaded: 0,
                earliest_uploaded: null,
                latest_uploaded: null,
                cleanup_threshold_hours: 48,
                threshold_time: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString()
            };
        }
        async executeCleanup() {
            console.warn('⚠️ 清理功能不可用（cleanup-bills 模塊缺失）');
            return {
                success: true,
                cleaned: 0,
                duration: 0,
                warning: '清理功能不可用（cleanup-bills 模塊缺失）'
            };
        }
    };
}

// 默認密碼哈希（用於同步創建的新員工，密碼為"secret" - 用戶必須在首次登錄後更改）
const DEFAULT_PASSWORD_HASH = '$2a$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW';

/**
 * 同步API認證中間件
 * 支持API密鑰和Bearer令牌認證
 */
const syncAuthMiddleware = (req, res, next) => {
    try {
        const apiKey = req.headers['x-api-key'];
        const authHeader = req.headers['authorization'];

        // 檢查API密鑰
        const expectedApiKey = process.env.ALIYUN_API_KEY || process.env.MAIN_API_KEY;
        if (apiKey && expectedApiKey && apiKey === expectedApiKey) {
            console.log('API密鑰認證成功');
            return next();
        }

        // 檢查Bearer令牌（簡化版本 - 實際應該驗證JWT）
        if (authHeader && authHeader.startsWith('Bearer ')) {
            const token = authHeader.substring(7);
            // 這裡可以添加JWT驗證邏輯
            console.log('Bearer令牌認證（簡化）');
            return next();
        }

        console.warn('同步API認證失敗', {
            hasApiKey: !!apiKey,
            hasAuthHeader: !!authHeader,
            expectedApiKeyExists: !!expectedApiKey
        });

        return res.status(401).json({
            success: false,
            error: '認證失敗',
            message: '需要有效的API密鑰或Bearer令牌'
        });

    } catch (authError) {
        console.error('認證中間件錯誤:', authError);
        return res.status(500).json({
            success: false,
            error: '認證服務器錯誤',
            message: authError.message
        });
    }
};

/**
 * 可選身份驗證中間件
 * 嘗試認證但不失敗 - 用於允許未認證請求使用環境變量STORE_ID的場景
 */
const optionalAuth = (req, res, next) => {
    try {
        const apiKey = req.headers['x-api-key'] || req.headers['X-API-Key'];
        const authHeader = req.headers['authorization'];

        // 檢查API密鑰
        const expectedApiKey = process.env.ALIYUN_API_KEY || process.env.MAIN_API_KEY;
        if (apiKey && expectedApiKey && apiKey === expectedApiKey) {
            console.log('optionalAuth: API密鑰認證成功，設置虛擬員工');
            req.employee = {
                id: 'sync_user',
                username: 'sync_user',
                full_name: '數據同步用戶',
                role: 'staff',
                store_id: 'default_store'
            };
            req.session = {
                id: 'api_key_session',
                token: apiKey
            };
            return next();
        }

        // 檢查Bearer令牌
        if (authHeader && authHeader.startsWith('Bearer ')) {
            const token = authHeader.substring(7);
            console.log('optionalAuth: Bearer令牌存在，嘗試驗證會話，令牌前綴:', token.substring(0, 8) + '...');

            // 檢查數據庫會話（類似authMiddleware但不失敗）
            db.get(
                `SELECT s.*, e.username, e.full_name, e.role, e.is_active, e.store_id
                 FROM sessions s
                 JOIN employees e ON s.employee_id = e.id
                 WHERE s.token = ? AND s.expires_at > ?`,
                [token, new Date().toISOString()],
                (err, session) => {
                    if (err) {
                        console.error('optionalAuth: 會話查詢錯誤:', err.message);
                        // 繼續而不設置req.employee
                        next();
                        return;
                    }

                    if (!session) {
                        console.log('optionalAuth: 會話不存在或已過期');
                        // 繼續而不設置req.employee
                        next();
                        return;
                    }

                    if (session.is_active !== 1) {
                        console.log('optionalAuth: 員工帳戶已停用，員工ID:', session.employee_id);
                        // 繼續而不設置req.employee（帳戶停用但不阻止請求）
                        next();
                        return;
                    }

                    console.log('optionalAuth: 會話驗證成功，員工:', session.employee_id, '分店:', session.store_id);
                    // 設置員工信息
                    req.employee = {
                        id: session.employee_id,
                        username: session.username,
                        full_name: session.full_name,
                        role: session.role,
                        store_id: session.store_id
                    };
                    req.session = {
                        id: session.id,
                        token: session.token
                    };

                    // 更新會話最後活動時間（可選）
                    db.run(
                        `UPDATE sessions SET expires_at = ? WHERE id = ?`,
                        [new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString(), session.id],
                        (updateErr) => {
                            if (updateErr) console.error('optionalAuth: 更新會話時間錯誤:', updateErr);
                        }
                    );

                    next();
                }
            );
            return; // 異步查詢中處理，不要繼續執行下面的next()
        }

        // 如果沒有有效的API密鑰或Bearer令牌，繼續而不設置req.employee
        console.log('optionalAuth: 無認證信息，繼續處理');
        next();

    } catch (authError) {
        console.error('optionalAuth 錯誤:', authError);
        // 可選認證不應失敗，繼續處理
        next();
    }
};

/**
 * 數據同步管理器
 * 用於從阿里雲ECS服務器同步主數據到本地
 */
class DataSyncManager {
    constructor() {
        this.aliyunServer = process.env.ALIYUN_SERVER || 'http://47.239.121.13';
        this.apiKey = process.env.ALIYUN_API_KEY || '';
        this.syncUsername = process.env.ALIYUN_SYNC_USERNAME || '';
        this.syncPassword = process.env.ALIYUN_SYNC_PASSWORD || '';
        this.timeout = 30000; // 30秒超時
        this.maxRetries = 3;
        this.retryDelay = 1000; // 1秒重試延遲
        this.authToken = null;
        this.tokenExpiry = null;

        console.log(`數據同步管理器初始化: 遠程服務器=${this.aliyunServer}`);
        console.log(`認證方式: ${this.syncUsername ? '用戶名/密碼' : this.apiKey ? 'API密鑰' : '無認證'}`);
    }

    /**
     * 認證到遠程服務器（使用用戶名/密碼獲取JWT令牌）
     * @returns {Promise<boolean>} 是否認證成功
     */
    async authenticate() {
        console.log('同步認證調試: syncUsername=', this.syncUsername, 'syncPassword=', this.syncPassword ? '已設置' : '未設置');
        // 如果已有有效令牌，直接返回成功
        if (this.authToken && this.tokenExpiry && new Date(this.tokenExpiry) > new Date()) {
            console.log('使用現有有效令牌');
            return true;
        }

        // 如果沒有用戶名/密碼，嘗試使用API密鑰
        if (!this.syncUsername || !this.syncPassword) {
            console.log('未配置同步用戶名/密碼，使用API密鑰（如果可用）');
            return false; // 讓後續邏輯使用API密鑰
        }

        try {
            console.log('正在認證到遠程服務器...');
            console.log('認證詳情:', {
                server: this.aliyunServer,
                username: this.syncUsername,
                passwordSet: !!this.syncPassword
            });
            const url = this.getRemoteUrl('/api/auth/login');
            console.log('認證URL:', url);
            const response = await axios.post(url, {
                username: this.syncUsername,
                password: this.syncPassword
            }, {
                timeout: this.timeout,
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            });

            console.log('認證響應狀態:', response.status);
            console.log('認證響應數據:', JSON.stringify(response.data, null, 2));

            if (response.data.success && response.data.data && response.data.data.token) {
                this.authToken = response.data.data.token;
                // 設置令牌過期時間（8小時後，從服務器返回的expires_at）
                this.tokenExpiry = response.data.data.expires_at;
                console.log('遠程服務器認證成功，令牌已保存');
                console.log('令牌有效期至:', this.tokenExpiry);
                return true;
            } else {
                console.error('遠程服務器認證失敗:', response.data.message || '未知錯誤');
                return false;
            }
        } catch (error) {
            console.error('遠程服務器認證錯誤:', error.message);
            console.error('錯誤詳情:', error.response?.data || '無響應數據');
            // 如果認證失敗，清空令牌
            this.authToken = null;
            this.tokenExpiry = null;
            return false;
        }
    }

    /**
     * 獲取遠程API的完整URL
     * @param {string} endpoint API端點
     * @returns {string} 完整URL
     */
    getRemoteUrl(endpoint) {
        // 移除結尾的斜槓
        const baseUrl = this.aliyunServer.replace(/\/$/, '');
        // 確保端點以斜槓開頭
        const normalizedEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
        return `${baseUrl}${normalizedEndpoint}`;
    }

    /**
     * 發送HTTP請求到遠程服務器
     * @param {string} endpoint API端點
     * @param {string} method HTTP方法
     * @param {Object} data 請求數據
     * @returns {Promise<Object>} 響應數據
     */
    async fetchFromRemote(endpoint, method = 'GET', data = null) {
        const url = this.getRemoteUrl(endpoint);
        console.log('fetchFromRemote調試:', { endpoint, url, hasApiKey: !!this.apiKey, hasSyncUsername: !!this.syncUsername, hasAuthToken: !!(this.authToken && this.tokenExpiry && new Date(this.tokenExpiry) > new Date()) });

        // 準備請求配置
        const config = {
            method,
            url,
            timeout: this.timeout,
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        };

        // 嘗試認證（如果沒有有效令牌但配置了同步帳號）
        if (!(this.authToken && this.tokenExpiry && new Date(this.tokenExpiry) > new Date())) {
            if (this.syncUsername && this.syncPassword) {
                console.log(`無有效令牌，嘗試使用同步帳號認證...`);
                const authSuccess = await this.authenticate(); // 這將更新this.authToken
                if (authSuccess) {
                    console.log('認證成功，將使用Bearer令牌');
                } else {
                    console.log('認證失敗，將嘗試API密鑰（如果可用）');
                }
            }
        }

        // 添加認證令牌（如果存在）
        if (this.authToken && this.tokenExpiry && new Date(this.tokenExpiry) > new Date()) {
            config.headers['Authorization'] = `Bearer ${this.authToken}`;
            console.log(`請求 ${method} ${url} 使用Bearer令牌認證`);
        } else if (this.apiKey) {
            // 備用：API密鑰
            config.headers['X-API-Key'] = this.apiKey;
            console.log(`請求 ${method} ${url} 使用API密鑰認證`);
        } else {
            console.log(`請求 ${method} ${url} 無認證`);
        }

        if (data) {
            config.data = data;
        }

        let lastError;
        for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
            try {
                console.log(`嘗試 ${attempt}/${this.maxRetries}: 請求 ${method} ${url}`);
                const response = await axios(config);

                if (response.status >= 200 && response.status < 300) {
                    return response.data;
                } else if (response.status === 401) {
                    // 認證失敗，嘗試重新獲取令牌
                    console.log('認證失敗 (401)，嘗試重新認證...');
                    const authSuccess = await this.authenticate();
                    if (authSuccess && attempt < this.maxRetries) {
                        // 更新配置中的令牌
                        config.headers['Authorization'] = `Bearer ${this.authToken}`;
                        console.log('令牌已更新，重試請求...');
                        continue; // 重試當前嘗試
                    } else {
                        throw new Error(`認證失敗: HTTP 401`);
                    }
                } else {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
            } catch (error) {
                lastError = error;
                console.error(`遠程請求失敗 (嘗試 ${attempt}/${this.maxRetries}):`, error.message);

                if (attempt < this.maxRetries) {
                    await new Promise(resolve => setTimeout(resolve, this.retryDelay * attempt));
                }
            }
        }

        throw new Error(`遠程請求失敗: ${lastError.message}`);
    }

    /**
     * 獲取商品數據
     * @returns {Promise<Array>} 商品列表
     */
    async fetchProducts(storeId = null) {
        try {
            console.log(`fetchProducts調用，storeId參數: ${storeId} (類型: ${typeof storeId}, 是否為null: ${storeId === null}, 是否為undefined: ${storeId === undefined})`);

            // 如果沒有提供分店ID，則不獲取商品數據
            if (!storeId) {
                console.log('警告：未提供分店ID，跳過商品同步（需要登入賬號的store_id）');
                return [];
            }

            // 使用傳入的storeId獲取商品
            console.log(`使用分店ID過濾商品: ${storeId} (來源: 參數)`);
            const response = await this.fetchFromRemote(`/api/products?store_id=${storeId}&page_size=1000&ignore_time_restriction=true`);

            console.log(`fetchProducts 響應詳情:`, {
                success: response.success,
                hasData: !!response.data,
                dataType: typeof response.data,
                dataKeys: response.data ? Object.keys(response.data) : 'no data',
                error: response.error,
                message: response.message,
                fullResponseKeys: Object.keys(response)
            });

            if (response.success && response.data && response.data.products) {
                console.log(`成功獲取 ${response.data.products.length} 個商品 (分店: ${storeId})`);
                // 調試：檢查切餅費商品
                const cakeFeeProducts = response.data.products.filter(p => p.name && p.name.includes('切餅費'));
                if (cakeFeeProducts.length > 0) {
                    console.log('切餅費商品詳情:', cakeFeeProducts.map(p => ({
                        id: p.id,
                        name: p.name,
                        price: p.price,
                        store_id: p.store_id
                    })));
                }
                // 確保每個商品都有store_id
                const productsWithStoreId = response.data.products.map(p => ({
                    ...p,
                    store_id: p.store_id || storeId
                }));

                // 調試：檢查前幾個商品的store_id
                if (productsWithStoreId.length > 0) {
                    console.log(`調試: 前3個商品的store_id檢查 (storeId=${storeId}):`);
                    productsWithStoreId.slice(0, 3).forEach((p, i) => {
                        console.log(`  商品${i+1}: id=${p.id}, 原始store_id=${p.store_id}, 最終store_id=${p.store_id || storeId}, name=${p.name?.substring(0, 20)}...`);
                    });
                }

                return productsWithStoreId;
            } else {
                console.error('商品數據格式無效，響應詳情:', JSON.stringify(response, null, 2));
                throw new Error('商品數據格式無效');
            }
        } catch (error) {
            console.error('獲取商品數據失敗:', error.message);
            throw error;
        }
    }

    /**
     * 獲取員工數據
     * @returns {Promise<Array>} 員工列表
     */
    async fetchEmployees() {
        try {
            console.log('開始同步員工數據...');
            console.log('當前認證狀態:', {
                authToken: !!this.authToken,
                tokenExpiry: this.tokenExpiry,
                apiKey: !!this.apiKey
            });
            const response = await this.fetchFromRemote('/api/employees');

            console.log('員工API響應:', {
                success: response.success,
                hasData: !!response.data,
                dataLength: response.data?.length || 0,
                error: response.error,
                message: response.message
            });

            if (response.success && response.data) {
                console.log(`成功獲取 ${response.data.length} 個員工`);
                if (response.data.length > 0) {
                    console.log('員工列表示例:', response.data.slice(0, 2).map(e => ({ id: e.id, username: e.username, name: e.full_name })));
                }
                return response.data;
            } else {
                console.error('員工數據格式無效，完整響應:', JSON.stringify(response, null, 2));
                throw new Error('員工數據格式無效');
            }
        } catch (error) {
            console.error('獲取員工數據失敗:', error.message);
            console.error('錯誤堆疊:', error.stack);
            // 員工數據不是關鍵數據，返回空數組而不是拋出錯誤
            return [];
        }
    }

    /**
     * 獲取分店數據
     * @returns {Promise<Array>} 分店列表
     */
    async fetchStores() {
        try {
            console.log('開始同步分店數據...');
            const response = await this.fetchFromRemote('/api/stores');

            if (response.success && response.data) {
                console.log(`成功獲取 ${response.data.length} 個分店`);
                return response.data;
            } else {
                throw new Error('分店數據格式無效');
            }
        } catch (error) {
            console.error('獲取分店數據失敗:', error.message);
            throw error;
        }
    }

    /**
     * 獲取小票模板數據
     * @returns {Promise<Array>} 小票模板列表
     */
    async fetchReceiptTemplates() {
        try {
            console.log('開始同步小票模板數據...');
            const response = await this.fetchFromRemote('/api/receipt/templates');

            if (response.success && response.data) {
                console.log(`成功獲取 ${response.data.length} 個小票模板`);
                return response.data;
            } else {
                throw new Error('小票模板數據格式無效');
            }
        } catch (error) {
            console.error('獲取小票模板數據失敗:', error.message);
            // 小票模板不是關鍵數據，返回空數組而不是拋出錯誤
            return [];
        }
    }

    /**
     * 獲取節假日數據
     * @returns {Promise<Array>} 節假日列表
     */
    async fetchHolidays() {
        try {
            console.log('開始同步節假日數據...');
            const response = await this.fetchFromRemote('/api/holidays');

            if (response.success && response.data && response.data.holidays) {
                console.log(`成功獲取 ${response.data.holidays.length} 個節假日`);
                return response.data.holidays;
            } else {
                throw new Error('節假日數據格式無效');
            }
        } catch (error) {
            console.error('獲取節假日數據失敗:', error.message);
            // 節假日不是關鍵數據，返回空數組而不是拋出錯誤
            return [];
        }
    }

    /**
     * 同步所有主數據
     * @returns {Promise<Object>} 同步結果
     */
    async syncAllMasterData(storeId = null) {
        const startTime = Date.now();
        console.log(`syncAllMasterData 調用，storeId: ${storeId}`);
        const results = {
            success: false,
            timestamp: new Date().toISOString(),
            duration: 0,
            data: {
                products: [],
                employees: [],
                stores: [],
                receiptTemplates: [],
                holidays: []
            },
            counts: {
                products: 0,
                employees: 0,
                stores: 0,
                receiptTemplates: 0,
                holidays: 0
            },
            errors: []
        };

        try {
            console.log('========== 開始同步所有主數據 ==========');

            // 並行獲取所有數據以提高效率
            const [
                products,
                employees,
                stores,
                receiptTemplates,
                holidays
            ] = await Promise.allSettled([
                this.fetchProducts(storeId),
                this.fetchEmployees(),
                this.fetchStores(),
                this.fetchReceiptTemplates(),
                this.fetchHolidays()
            ]);

            // 處理商品結果
            if (products.status === 'fulfilled') {
                console.log(`syncAllMasterData: 商品獲取成功，數量: ${products.value.length}`);
                results.data.products = products.value;
                results.counts.products = products.value.length;
            } else {
                console.error(`syncAllMasterData: 商品獲取失敗:`, products.reason);
                results.errors.push(`商品: ${products.reason.message}`);
            }

            // 處理員工結果
            if (employees.status === 'fulfilled') {
                results.data.employees = employees.value;
                results.counts.employees = employees.value.length;
            } else {
                results.errors.push(`員工: ${employees.reason.message}`);
            }

            // 處理分店結果
            if (stores.status === 'fulfilled') {
                results.data.stores = stores.value;
                results.counts.stores = stores.value.length;
            } else {
                results.errors.push(`分店: ${stores.reason.message}`);
            }

            // 處理小票模板結果
            if (receiptTemplates.status === 'fulfilled') {
                results.data.receiptTemplates = receiptTemplates.value;
                results.counts.receiptTemplates = receiptTemplates.value.length;
            } else {
                results.errors.push(`小票模板: ${receiptTemplates.reason.message}`);
            }

            // 處理節假日結果
            if (holidays.status === 'fulfilled') {
                results.data.holidays = holidays.value;
                results.counts.holidays = holidays.value.length;
            } else {
                results.errors.push(`節假日: ${holidays.reason.message}`);
            }

            // 檢查是否有關鍵數據失敗
            const criticalErrors = results.errors.filter(error =>
                !error.includes('小票模板') && !error.includes('節假日') && !error.includes('員工')
            );

            if (criticalErrors.length > 0) {
                throw new Error(`關鍵數據同步失敗: ${criticalErrors.join('; ')}`);
            }

            results.success = true;
            results.duration = Date.now() - startTime;

            console.log(`========== 同步完成 (${results.duration}ms) ==========`);
            console.log(`商品: ${results.counts.products} 個`);
            console.log(`員工: ${results.counts.employees} 個`);
            console.log(`分店: ${results.counts.stores} 個`);
            console.log(`小票模板: ${results.counts.receiptTemplates} 個`);
            console.log(`節假日: ${results.counts.holidays} 個`);

            if (results.errors.length > 0) {
                console.warn(`非關鍵錯誤: ${results.errors.join('; ')}`);
            }

        } catch (error) {
            console.error('同步主數據失敗:', error);
            results.errors.push(error.message);
            results.success = false;
            results.duration = Date.now() - startTime;
        }

        return results;
    }

    /**
     * 將分店數據保存到本地數據庫
     * @param {Array} stores 分店數據數組
     * @param {Object} result 結果對象
     * @returns {Promise<void>}
     */
    async saveStoresToDatabase(stores, result) {
        try {
            console.log(`開始保存 ${stores.length} 個分店到本地數據庫...`);

            // 步驟1: 收集遠程分店ID列表
            const remoteStoreIds = stores.map(s => s.id);
            console.log(`遠程分店ID數量: ${remoteStoreIds.length}`);

            // 步驟2: 刪除本地數據庫中不在遠程列表中的分店
            let deleteResult = 0;
            if (remoteStoreIds.length > 0) {
                // 有遠程分店：刪除不在列表中的分店
                deleteResult = await new Promise((resolve, reject) => {
                    db.run(
                        `DELETE FROM stores WHERE id NOT IN (${remoteStoreIds.map(() => '?').join(',')})`,
                        remoteStoreIds,
                        function(err) {
                            if (err) reject(err);
                            else {
                                console.log(`刪除了 ${this.changes} 個不在遠程列表中的分店`);
                                resolve(this.changes);
                            }
                        }
                    );
                });
            } else {
                // 沒有遠程分店：刪除所有分店（謹慎操作，通常不會發生）
                deleteResult = await new Promise((resolve, reject) => {
                    db.run(
                        `DELETE FROM stores`,
                        [],
                        function(err) {
                            if (err) reject(err);
                            else {
                                console.log(`刪除了 ${this.changes} 個分店（全部遠程分店為空）`);
                                resolve(this.changes);
                            }
                        }
                    );
                });
            }

            let savedCount = 0;
            const errors = [];

            // 為每個分店執行插入或更新
            for (const store of stores) {
                try {
                    // 檢查分店是否已存在
                    const exists = await new Promise((resolve, reject) => {
                        db.get(
                            `SELECT id FROM stores WHERE id = ?`,
                            [store.id],
                            (err, row) => {
                                if (err) reject(err);
                                else resolve(!!row);
                            }
                        );
                    });
                    console.log(`分店 ${store.id} 存在? ${exists}`);
                    if (exists) {
                        // 更新現有分店
                        const now = new Date().toISOString();
                        const is_active = (store.status === 'active' || store.status === 'maintenance') ? 1 : 0;

                        await new Promise((resolve, reject) => {
                            db.run(
                                `UPDATE stores SET
                                    store_code = ?,
                                    store_name = ?,
                                    address = ?,
                                    phone = ?,
                                    email = ?,
                                    opening_hours = ?,
                                    description = ?,
                                    timezone = ?,
                                    is_active = ?,
                                    status = ?,
                                    settings = ?,
                                    use_lockers = ?,
                                    updated_at = ?
                                WHERE id = ?`,
                                [
                                    store.store_code || store.code || '',
                                    store.store_name || store.name || '',
                                    store.address || null,
                                    store.phone || null,
                                    store.email || null,
                                    store.opening_hours || null,
                                    store.description || null,
                                    store.timezone || 'Asia/Hong_Kong',
                                    is_active,
                                    store.status || 'active',
                                    store.settings || '{}',
                                    store.use_lockers || 0,
                                    now,
                                    store.id
                                ],
                                function(err) {
                                    if (err) reject(err);
                                    else {
                                        console.log(`✓ 更新分店: ${store.store_code} (${store.store_name})`);
                                        resolve();
                                    }
                                }
                            );
                        });
                    } else {
                        // 插入新分店
                        const now = new Date().toISOString();
                        const is_active = (store.status === 'active' || store.status === 'maintenance') ? 1 : 0;

                        await new Promise((resolve, reject) => {
                            db.run(
                                `INSERT INTO stores (
                                    id, store_code, store_name, address, phone, email,
                                    opening_hours, description, timezone, is_active,
                                    status, settings, use_lockers, created_at, updated_at
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                                [
                                    store.id,
                                    store.store_code || store.code || '',
                                    store.store_name || store.name || '',
                                    store.address || null,
                                    store.phone || null,
                                    store.email || null,
                                    store.opening_hours || null,
                                    store.description || null,
                                    store.timezone || 'Asia/Hong_Kong',
                                    is_active,
                                    store.status || 'active',
                                    store.settings || '{}',
                                    store.use_lockers || 0,
                                    now,
                                    now
                                ],
                                function(err) {
                                    if (err) reject(err);
                                    else {
                                        console.log(`✓ 創建分店: ${store.store_code} (${store.store_name})`);
                                        resolve();
                                    }
                                }
                            );
                        });
                    }

                    savedCount++;
                } catch (storeError) {
                    console.error(`保存分店 ${store.id} (${store.store_code}) 失敗:`, storeError.message);
                    errors.push(`${store.store_code}: ${storeError.message}`);
                }
            }

            result.saved = savedCount;
            result.errors = errors;
            result.deleted = deleteResult || 0;

            console.log(`分店保存完成: ${savedCount}/${stores.length} 個成功, 刪除了 ${result.deleted} 個${errors.length > 0 ? `, ${errors.length} 個失敗` : ''}`);

        } catch (error) {
            console.error('保存分店數據到數據庫失敗:', error);
            result.errors = [error.message];
        }
    }

    /**
     * 將員工數據保存到本地數據庫
     * @param {Array} employees 員工數據數組
     * @param {Object} result 結果對象
     * @returns {Promise<void>}
     */
    /**
     * 將小票模板數據保存到本地數據庫
     * @param {Array} templates 小票模板數據數組
     * @param {Object} result 結果對象
     * @returns {Promise<void>}
     */
    async saveReceiptTemplatesToDatabase(templates, result) {
        try {
            console.log(`開始保存 ${templates.length} 個小票模板到本地數據庫...`);
            if (templates.length > 0) {
                console.log('小票模板範例:', templates.slice(0, 2).map(t => ({ id: t.id, template_name: t.template_name, store_id: t.store_id })));
            }

            // 步驟1: 收集遠程小票模板ID列表
            const remoteTemplateIds = templates.map(t => t.id);
            console.log(`遠程小票模板ID數量: ${remoteTemplateIds.length}`);

            // 步驟2: 刪除本地數據庫中不在遠程列表中的小票模板
            let deleteResult = 0;
            if (remoteTemplateIds.length > 0) {
                // 有遠程小票模板：刪除不在列表中的小票模板
                deleteResult = await new Promise((resolve, reject) => {
                    db.run(
                        `DELETE FROM receipt_templates WHERE id NOT IN (${remoteTemplateIds.map(() => '?').join(',')})`,
                        remoteTemplateIds,
                        function(err) {
                            if (err) reject(err);
                            else {
                                console.log(`刪除了 ${this.changes} 個不在遠程列表中的小票模板`);
                                resolve(this.changes);
                            }
                        }
                    );
                });
            } else {
                // 沒有遠程小票模板：刪除所有小票模板（謹慎操作，通常不會發生）
                deleteResult = await new Promise((resolve, reject) => {
                    db.run(
                        `DELETE FROM receipt_templates`,
                        [],
                        function(err) {
                            if (err) reject(err);
                            else {
                                console.log(`刪除了 ${this.changes} 個小票模板（全部遠程小票模板為空）`);
                                resolve(this.changes);
                            }
                        }
                    );
                });
            }

            let savedCount = 0;
            const errors = [];

            // 為每個小票模板執行插入或更新
            for (const template of templates) {
                try {
                    // 檢查小票模板是否已存在
                    const exists = await new Promise((resolve, reject) => {
                        db.get(
                            `SELECT id FROM receipt_templates WHERE id = ?`,
                            [template.id],
                            (err, row) => {
                                if (err) reject(err);
                                else resolve(!!row);
                            }
                        );
                    });
                    console.log(`小票模板 ${template.id} (${template.template_name}) 存在? ${exists}`);

                    if (exists) {
                        // 更新現有小票模板
                        const now = new Date().toISOString();
                        const is_default = template.is_default ? 1 : 0;
                        const configJson = typeof template.config === 'string' ? template.config : JSON.stringify(template.config || {});

                        await new Promise((resolve, reject) => {
                            db.run(
                                `UPDATE receipt_templates SET
                                    template_name = ?,
                                    store_id = ?,
                                    is_default = ?,
                                    config = ?,
                                    updated_at = ?
                                WHERE id = ?`,
                                [
                                    template.template_name,
                                    template.store_id || null,
                                    is_default,
                                    configJson,
                                    now,
                                    template.id
                                ],
                                function(err) {
                                    if (err) reject(err);
                                    else {
                                        console.log(`✓ 更新小票模板: ${template.template_name} (${template.id})`);
                                        resolve();
                                    }
                                }
                            );
                        });
                    } else {
                        // 插入新小票模板
                        const now = new Date().toISOString();
                        const is_default = template.is_default ? 1 : 0;
                        const configJson = typeof template.config === 'string' ? template.config : JSON.stringify(template.config || {});

                        await new Promise((resolve, reject) => {
                            db.run(
                                `INSERT INTO receipt_templates (
                                    id, template_name, store_id, is_default, config,
                                    created_at, updated_at, created_by
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                                [
                                    template.id,
                                    template.template_name,
                                    template.store_id || null,
                                    is_default,
                                    configJson,
                                    now,
                                    now,
                                    template.created_by || null
                                ],
                                function(err) {
                                    if (err) reject(err);
                                    else {
                                        console.log(`✓ 插入小票模板: ${template.template_name} (${template.id})`);
                                        resolve();
                                    }
                                }
                            );
                        });
                    }
                    savedCount++;
                } catch (templateError) {
                    console.error(`保存小票模板 ${template.id} (${template.template_name}) 失敗:`, templateError.message);
                    errors.push(`${template.template_name}: ${templateError.message}`);
                }
            }

            result.saved = savedCount;
            result.errors = errors;
            result.deleted = deleteResult || 0;

            console.log(`小票模板保存完成: ${savedCount}/${templates.length} 個成功, 刪除了 ${result.deleted} 個${errors.length > 0 ? `, ${errors.length} 個失敗` : ''}`);

        } catch (error) {
            console.error('保存小票模板數據到數據庫失敗:', error);
            result.errors = [error.message];
        }
    }

    /**
     * 將節假日數據保存到本地數據庫
     * @param {Array} holidays 節假日數據數組
     * @param {Object} result 結果對象
     * @returns {Promise<void>}
     */
    async saveHolidaysToDatabase(holidays, result) {
        try {
            console.log(`開始保存 ${holidays.length} 個節假日到本地數據庫...`);
            if (holidays.length > 0) {
                console.log('節假日範例:', holidays.slice(0, 2).map(h => ({ id: h.id, date: h.date, description: h.description })));
            }

            let savedCount = 0;
            const errors = [];

            // 步驟1: 收集遠程節假日的ID列表
            const remoteHolidayIds = holidays.map(h => h.id);
            console.log(`遠程節假日ID數量: ${remoteHolidayIds.length}`);

            // 步驟2: 刪除本地數據庫中不在遠程列表中的節假日（僅限 default_store）
            // 注意：遠程節假日沒有 store_id 字段，所以我們只處理 store_id = 'default_store' 的節假日
            let deleteResult = 0;
            if (remoteHolidayIds.length > 0) {
                // 有遠程節假日：刪除不在列表中的節假日
                deleteResult = await new Promise((resolve, reject) => {
                    db.run(
                        `DELETE FROM holidays WHERE store_id = 'default_store' AND id NOT IN (${remoteHolidayIds.map(() => '?').join(',')})`,
                        remoteHolidayIds,
                        function(err) {
                            if (err) reject(err);
                            else {
                                console.log(`刪除了 ${this.changes} 個不在遠程列表中的節假日 (store_id = 'default_store')`);
                                resolve(this.changes);
                            }
                        }
                    );
                });
            } else {
                // 沒有遠程節假日：刪除所有 default_store 的節假日
                deleteResult = await new Promise((resolve, reject) => {
                    db.run(
                        `DELETE FROM holidays WHERE store_id = 'default_store'`,
                        [],
                        function(err) {
                            if (err) reject(err);
                            else {
                                console.log(`刪除了 ${this.changes} 個節假日 (全部 default_store 節假日)`);
                                resolve(this.changes);
                            }
                        }
                    );
                });
            }

            // 步驟3: 為每個節假日執行插入或更新
            for (const holiday of holidays) {
                try {
                    // 檢查節假日是否已存在
                    const exists = await new Promise((resolve, reject) => {
                        db.get(
                            `SELECT id FROM holidays WHERE id = ?`,
                            [holiday.id],
                            (err, row) => {
                                if (err) reject(err);
                                else resolve(!!row);
                            }
                        );
                    });
                    console.log(`節假日 ${holiday.id} (${holiday.date}) 存在? ${exists}`);

                    if (exists) {
                        // 更新現有節假日
                        const now = new Date().toISOString();

                        await new Promise((resolve, reject) => {
                            db.run(
                                `UPDATE holidays SET
                                    date = ?,
                                    description = ?,
                                    store_id = ?,
                                    created_by = ?
                                WHERE id = ?`,
                                [
                                    holiday.date,
                                    holiday.description || '',
                                    holiday.store_id || 'default_store',
                                    holiday.created_by || null,
                                    holiday.id
                                ],
                                function(err) {
                                    if (err) reject(err);
                                    else {
                                        console.log(`✓ 更新節假日: ${holiday.date} - ${holiday.description}`);
                                        resolve();
                                    }
                                }
                            );
                        });
                    } else {
                        // 插入新節假日
                        const now = new Date().toISOString();

                        await new Promise((resolve, reject) => {
                            db.run(
                                `INSERT INTO holidays (
                                    id, date, description, created_by, store_id, created_at
                                ) VALUES (?, ?, ?, ?, ?, ?)`,
                                [
                                    holiday.id,
                                    holiday.date,
                                    holiday.description || '',
                                    holiday.created_by || null,
                                    holiday.store_id || 'default_store',
                                    now
                                ],
                                function(err) {
                                    if (err) reject(err);
                                    else {
                                        console.log(`✓ 插入節假日: ${holiday.date} - ${holiday.description}`);
                                        resolve();
                                    }
                                }
                            );
                        });
                    }
                    savedCount++;
                } catch (holidayError) {
                    console.error(`保存節假日 ${holiday.id} (${holiday.date}) 失敗:`, holidayError.message);
                    errors.push(`${holiday.date}: ${holidayError.message}`);
                }
            }

            result.saved = savedCount;
            result.errors = errors;
            result.deleted = deleteResult || 0;

            console.log(`節假日保存完成: ${savedCount}/${holidays.length} 個成功, 刪除了 ${result.deleted} 個${errors.length > 0 ? `, ${errors.length} 個失敗` : ''}`);

        } catch (error) {
            console.error('保存節假日數據到數據庫失敗:', error);
            result.errors = [error.message];
        }
    }

    async saveEmployeesToDatabase(employees, result) {
        try {
            console.log(`開始保存 ${employees.length} 個員工到本地數據庫...`);

            // 步驟1: 收集遠程員工ID列表
            const remoteEmployeeIds = employees.map(e => e.id);
            console.log(`遠程員工ID數量: ${remoteEmployeeIds.length}`);

            // 步驟2: 刪除本地數據庫中不在遠程列表中的員工（但保留管理員帳號）
            let deleteResult = 0;
            if (remoteEmployeeIds.length > 0) {
                // 有遠程員工：刪除不在列表中的員工，但排除管理員角色（避免同步刪掉本地 admin）
                deleteResult = await new Promise((resolve, reject) => {
                    db.run(
                        `DELETE FROM employees WHERE id NOT IN (${remoteEmployeeIds.map(() => '?').join(',')}) AND role != 'admin'`,
                        remoteEmployeeIds,
                        function(err) {
                            if (err) reject(err);
                            else {
                                console.log(`刪除了 ${this.changes} 個不在遠程列表中的員工（保留管理員帳號）`);
                                resolve(this.changes);
                            }
                        }
                    );
                });
            } else {
                // 沒有遠程員工：刪除所有員工（謹慎操作，通常不會發生）但保留管理員
                deleteResult = await new Promise((resolve, reject) => {
                    db.run(
                        `DELETE FROM employees WHERE role != 'admin'`,
                        [],
                        function(err) {
                            if (err) reject(err);
                            else {
                                console.log(`刪除了 ${this.changes} 個員工（保留管理員帳號）`);
                                resolve(this.changes);
                            }
                        }
                    );
                });
            }

            let savedCount = 0;
            const errors = [];

            // 步驟3: 為每個員工執行插入或更新
            for (const employee of employees) {
                try {
                    // 檢查員工是否已存在（先用 ID 匹配，再用 username 匹配）
                    const exists = await new Promise((resolve, reject) => {
                        db.get(
                            `SELECT id FROM employees WHERE id = ? OR username = ?`,
                            [employee.id, employee.username],
                            (err, row) => {
                                if (err) reject(err);
                                else resolve(row ? row.id : null);
                            }
                        );
                    });
                    console.log(`員工 ${employee.id} (${employee.username}) 存在? ${exists ? '是 (ID=' + exists + ')' : '否'}`);
                    if (exists) {
                        // 更新現有員工（同步遠端的 password_hash，但使用 COALESCE 確保只有遠端有值時才覆蓋）
                        const now = new Date().toISOString();
                        const remote_active = employee.is_active ? 1 : 0;

                        await new Promise((resolve, reject) => {
                            db.run(
                                `UPDATE employees SET
                                    username = ?,
                                    full_name = ?,
                                    role = ?,
                                    email = ?,
                                    phone = ?,
                                    store_id = ?,
                                    is_active = ?,
                                    password_hash = COALESCE(?, password_hash),
                                    updated_at = ?
                                WHERE id = ?`,
                                [
                                    employee.username,
                                    employee.full_name || '',
                                    employee.role || 'staff',
                                    employee.email || null,
                                    employee.phone || null,
                                    employee.store_id || null,
                                    remote_active,
                                    employee.password_hash || null,  // COALESCE: 若遠端有密碼則更新，否則保留本地
                                    now,
                                    exists // 使用本地 ID（可能與遠程 ID 不同）
                                ],
                                function(err) {
                                    if (err) reject(err);
                                    else {
                                        console.log(`✓ 更新員工: ${employee.username} (${employee.full_name})`);
                                        resolve();
                                    }
                                }
                            );
                        });
                        savedCount++;
                    } else {
                        // 員工不存在，創建新員工（包含來自遠端的密碼，使同步後可直接登入）
                        const now = new Date().toISOString();
                        const remote_active = employee.is_active ? 1 : 0;

                        console.log(`⚠️ 創建新員工: ${employee.username} (${employee.full_name})`);

                        await new Promise((resolve, reject) => {
                            db.run(
                                `INSERT INTO employees (
                                    id, username, password_hash, full_name, role, email, phone,
                                    store_id, is_active, created_at, updated_at
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                                [
                                    employee.id,
                                    employee.username,
                                    employee.password_hash || DEFAULT_PASSWORD_HASH, // 遠端有密碼則用遠端的
                                    employee.full_name || '',
                                    employee.role || 'staff',
                                    employee.email || null,
                                    employee.phone || null,
                                    employee.store_id || null,
                                    remote_active,
                                    now,
                                    now
                                ],
                                function(err) {
                                    if (err) reject(err);
                                    else {
                                        console.log(`✓ 創建新員工: ${employee.username} (${employee.full_name})`);
                                        resolve();
                                    }
                                }
                            );
                        });
                        savedCount++;
                    }
                } catch (employeeError) {
                    console.error(`保存員工 ${employee.id} (${employee.username}) 失敗:`, employeeError.message);
                    errors.push(`${employee.username}: ${employeeError.message}`);
                }
            }

            result.saved = savedCount;
            result.errors = errors;
            result.deleted = deleteResult || 0;

            console.log(`員工保存完成: ${savedCount}/${employees.length} 個成功, 刪除了 ${result.deleted} 個${errors.length > 0 ? `, ${errors.length} 個失敗` : ''}`);

        } catch (error) {
            console.error('保存員工數據到數據庫失敗:', error);
            result.errors = [error.message];
        }
    }

    /**
     * 將商品數據保存到本地數據庫
     * @param {Array} products 商品數據數組
     * @param {Object} result 結果對象
     * @returns {Promise<void>}
     */
    async saveProductsToDatabase(products, result, storeId = null) {
        try {
            console.log(`開始保存 ${products.length} 個商品到本地數據庫...`);
            // 調試：顯示前幾個產品信息
            if (products.length > 0) {
                console.log('產品範例:', products.slice(0, 3).map(p => ({ id: p.id, name: p.name, price: p.price, store_id: p.store_id })));
            }

            // 步驟1: 確保所有商品都有正確的store_id
            // 先確定目標分店ID：優先使用傳入的storeId，否則從商品數據中推斷
            let targetStoreId = storeId;
            if (!targetStoreId && products.length > 0) {
                // 從第一個有store_id的商品獲取store_id（假設所有商品屬於同一分店）
                const productWithStoreId = products.find(p => p.store_id);
                targetStoreId = productWithStoreId ? productWithStoreId.store_id : null;
                if (targetStoreId) {
                    console.log(`從商品數據推斷分店ID: ${targetStoreId}`);
                } else {
                    console.log('警告：無法從商品數據推斷分店ID，使用默認後備邏輯');
                }
            }

            // 修復商品數據中缺失的store_id
            let fixedCount = 0;
            const fixedProducts = products.map(p => {
                if (!p.store_id && targetStoreId) {
                    fixedCount++;
                    return { ...p, store_id: targetStoreId };
                }
                return p;
            });
            if (fixedCount > 0) {
                console.log(`修復了 ${fixedCount} 個商品的store_id (設置為: ${targetStoreId})`);
                // 使用修復後的商品數據
                products = fixedProducts;
            }

            // 步驟2: 收集遠程商品ID列表
            const remoteProductIds = products.map(p => p.id);
            console.log(`遠程商品ID數量: ${remoteProductIds.length}`);

            // 步驟3: 刪除本地數據庫中不在遠程列表中的商品（僅限當前分店）
            let deleteResult = 0;

            if (remoteProductIds.length > 0) {
                // 有遠程商品：刪除不在列表中的商品
                if (targetStoreId) {
                    // 僅刪除當前分店的商品
                    deleteResult = await new Promise((resolve, reject) => {
                        db.run(
                            `DELETE FROM products WHERE store_id = ? AND id NOT IN (${remoteProductIds.map(() => '?').join(',')})`,
                            [targetStoreId, ...remoteProductIds],
                            function(err) {
                                if (err) reject(err);
                                else {
                                    console.log(`刪除了 ${this.changes} 個不在遠程列表中的商品（分店: ${targetStoreId}）`);
                                    resolve(this.changes);
                                }
                            }
                        );
                    });
                } else {
                    // 沒有分店信息，跳過刪除（避免刪除其他分店的商品）
                    console.log('警告：無法確定分店ID，跳過商品刪除操作（避免刪除其他分店的商品）');
                    deleteResult = 0;
                }
            } else {
                // 沒有遠程商品：刪除所有商品（謹慎操作，通常不會發生）
                if (targetStoreId) {
                    // 僅刪除當前分店的所有商品
                    deleteResult = await new Promise((resolve, reject) => {
                        db.run(
                            `DELETE FROM products WHERE store_id = ?`,
                            [targetStoreId],
                            function(err) {
                                if (err) reject(err);
                                else {
                                    console.log(`刪除了 ${this.changes} 個商品（分店: ${targetStoreId}，全部遠程商品為空）`);
                                    resolve(this.changes);
                                }
                            }
                        );
                    });
                } else {
                    // 沒有分店信息，跳過刪除
                    console.log('警告：無法確定分店ID，跳過商品刪除操作');
                    deleteResult = 0;
                }
            }

            let savedCount = 0;
            const errors = [];

            // 為每個商品執行插入或更新
            for (const product of products) {
                try {
                    // 檢查商品是否已存在
                    const exists = await new Promise((resolve, reject) => {
                        db.get(
                            `SELECT id FROM products WHERE id = ?`,
                            [product.id],
                            (err, row) => {
                                if (err) reject(err);
                                else resolve(!!row);
                            }
                        );
                    });
                    console.log(`商品 ${product.id} (${product.name}) 存在? ${exists}, 價格: ${product.price}, 本地價格: ?`);
                    if (exists) {
                        // 更新現有商品
                        const now = new Date().toISOString();
                        const is_available = product.is_available ? 1 : 0;
                        const track_inventory = product.track_inventory || 0;
                        const has_time_restriction = product.has_time_restriction || 0;
                        const is_time_available = product.is_time_available ? 1 : 0;

                        await new Promise((resolve, reject) => {
                            db.run(
                                `UPDATE products SET
                                    name = ?,
                                    description = ?,
                                    price = ?,
                                    stock = ?,
                                    locker_number = ?,
                                    is_available = ?,
                                    category = ?,
                                    min_stock = ?,
                                    supplier = ?,
                                    cost_price = ?,
                                    last_restocked = ?,
                                    track_inventory = ?,
                                    product_order = ?,
                                    has_time_restriction = ?,
                                    weekday_start_time = ?,
                                    weekday_end_time = ?,
                                    holiday_start_time = ?,
                                    holiday_end_time = ?,
                                    weekday_start_time_2 = ?,
                                    weekday_end_time_2 = ?,
                                    holiday_start_time_2 = ?,
                                    holiday_end_time_2 = ?,
                                    is_time_available = ?,
                                    store_id = ?
                                WHERE id = ?`,
                                [
                                    product.name,
                                    product.description || '',
                                    product.price || 0,
                                    product.stock || 0,
                                    product.locker_number || null,
                                    is_available,
                                    product.category || 'general',
                                    product.min_stock || 0,
                                    product.supplier || '',
                                    product.cost_price || null,
                                    product.last_restocked || null,
                                    track_inventory,
                                    product.product_order || 0,
                                    has_time_restriction,
                                    product.weekday_start_time || null,
                                    product.weekday_end_time || null,
                                    product.holiday_start_time || null,
                                    product.holiday_end_time || null,
                                    product.weekday_start_time_2 || null,
                                    product.weekday_end_time_2 || null,
                                    product.holiday_start_time_2 || null,
                                    product.holiday_end_time_2 || null,
                                    is_time_available,
                                    product.store_id || null,
                                    product.id
                                ],
                                function(err) {
                                    if (err) reject(err);
                                    else {
                                        console.log(`✓ 更新商品: ${product.name} ($${product.price}), 影響行數: ${this.changes}`);
                                        resolve();
                                    }
                                }
                            );
                        });
                    } else {
                        // 插入新商品
                        const now = new Date().toISOString();
                        const is_available = product.is_available ? 1 : 0;
                        const track_inventory = product.track_inventory || 0;
                        const has_time_restriction = product.has_time_restriction || 0;
                        const is_time_available = product.is_time_available ? 1 : 0;

                        await new Promise((resolve, reject) => {
                            db.run(
                                `INSERT INTO products (
                                    id, name, description, price, stock, locker_number, is_available,
                                    category, min_stock, supplier, cost_price, last_restocked,
                                    track_inventory, product_order, has_time_restriction,
                                    weekday_start_time, weekday_end_time, holiday_start_time, holiday_end_time,
                                    weekday_start_time_2, weekday_end_time_2, holiday_start_time_2, holiday_end_time_2,
                                    is_time_available, store_id, created_at
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                                [
                                    product.id,
                                    product.name,
                                    product.description || '',
                                    product.price || 0,
                                    product.stock || 0,
                                    product.locker_number || null,
                                    is_available,
                                    product.category || 'general',
                                    product.min_stock || 0,
                                    product.supplier || '',
                                    product.cost_price || null,
                                    product.last_restocked || null,
                                    track_inventory,
                                    product.product_order || 0,
                                    has_time_restriction,
                                    product.weekday_start_time || null,
                                    product.weekday_end_time || null,
                                    product.holiday_start_time || null,
                                    product.holiday_end_time || null,
                                    product.weekday_start_time_2 || null,
                                    product.weekday_end_time_2 || null,
                                    product.holiday_start_time_2 || null,
                                    product.holiday_end_time_2 || null,
                                    is_time_available,
                                    product.store_id || null,
                                    now
                                ],
                                function(err) {
                                    if (err) reject(err);
                                    else {
                                        console.log(`✓ 創建商品: ${product.name} ($${product.price})`);
                                        resolve();
                                    }
                                }
                            );
                        });
                    }

                    savedCount++;
                } catch (productError) {
                    console.error(`保存商品 ${product.id} (${product.name}) 失敗:`, productError.message);
                    errors.push(`${product.name}: ${productError.message}`);
                }
            }

            result.saved = savedCount;
            result.errors = errors;
            result.deleted = deleteResult || 0;

            console.log(`商品保存完成: ${savedCount}/${products.length} 個成功, 刪除了 ${result.deleted} 個${errors.length > 0 ? `, ${errors.length} 個失敗` : ''}`);

        } catch (error) {
            console.error('保存商品數據到數據庫失敗:', error);
            result.errors = [error.message];
        }
    }

    /**
     * 將同步的數據保存到本地數據庫
     * @param {Object} data 同步的數據
     * @returns {Promise<Object>} 保存結果
     */
    async saveToLocalDatabase(data, storeId = null) {
        const saveResults = {
            products: { saved: 0, errors: [] },
            employees: { saved: 0, errors: [] },
            stores: { saved: 0, errors: [] },
            receiptTemplates: { saved: 0, errors: [] },
            holidays: { saved: 0, errors: [] }
        };

        try {
            console.log('開始將同步數據保存到本地數據庫...');

            // 1. 保存分店數據
            if (data.stores && data.stores.length > 0) {
                await this.saveStoresToDatabase(data.stores, saveResults.stores);
            }

            // 2. 保存商品數據
            if (data.products && data.products.length > 0) {
                await this.saveProductsToDatabase(data.products, saveResults.products, storeId);
            }

            // 3. 保存員工數據
            if (data.employees && data.employees.length > 0) {
                await this.saveEmployeesToDatabase(data.employees, saveResults.employees);
            }

            // 4. 保存小票模板數據
            if (data.receiptTemplates && data.receiptTemplates.length > 0) {
                await this.saveReceiptTemplatesToDatabase(data.receiptTemplates, saveResults.receiptTemplates);
            }

            // 5. 保存節假日數據
            if (data.holidays && data.holidays.length > 0) {
                await this.saveHolidaysToDatabase(data.holidays, saveResults.holidays);
            }

            console.log('數據保存完成');

        } catch (error) {
            console.error('保存到本地數據庫失敗:', error);
            // 不拋出錯誤，因為數據已經在內存中可用
        }

        return saveResults;
    }
}

// 創建全局同步管理器實例
const syncManager = new DataSyncManager();

/**
 * @route GET /api/sync/test
 * @desc 測試同步路由是否工作
 * @access Public
 */
router.get('/test', (req, res) => {
    console.log('[SYNC測試路由] 收到測試請求');
    res.json({
        success: true,
        message: '同步路由工作正常',
        timestamp: new Date().toISOString(),
        path: req.originalUrl,
        method: req.method
    });
});

/**
 * @route GET /api/sync/master-data
 * @desc 從阿里雲同步所有主數據到本地
 * @access Public（本地使用）
 */
router.get('/master-data', optionalAuth, storeAwareMiddleware.initStoreContext, async (req, res) => {
    try {
        console.log('收到主數據同步請求');
        console.log('環境變量調試: ENABLE_SYNC=', process.env.ENABLE_SYNC, 'SYNC_MOCK_MODE=', process.env.SYNC_MOCK_MODE);
        console.log('其他環境變量: PORT=', process.env.PORT, 'TZ=', process.env.TZ);
        console.log('所有同步相關環境變量:', {
            ENABLE_SYNC: process.env.ENABLE_SYNC,
            SYNC_MOCK_MODE: process.env.SYNC_MOCK_MODE,
            ALIYUN_SERVER: process.env.ALIYUN_SERVER,
            ALIYUN_API_KEY: process.env.ALIYUN_API_KEY
        });

        // 確定分店ID：優先使用storeContext中的分店，否則使用環境變量
        const storeId = req.employee?.store_id || req.storeContext?.store_id || process.env.STORE_ID || null; // 優先使用員工分店ID，未認證時不同步商品
        console.log(`同步分店商品: ${storeId} (來源: ${req.employee?.store_id ? 'employee' : req.storeContext?.store_id ? 'storeContext' : process.env.STORE_ID ? 'ENV_STORE_ID' : '未認證/無分店'})`);
        console.log('員工信息:', req.employee ? {
            id: req.employee.id,
            username: req.employee.username,
            store_id: req.employee.store_id
        } : '無員工信息');
        console.log('storeContext信息:', req.storeContext || '無storeContext');
        console.log('storeContext詳情:', req.storeContext ? {
            store_id: req.storeContext.store_id,
            store_code: req.storeContext.store_code,
            store_name: req.storeContext.store_name,
            is_admin: req.storeContext.is_admin,
            can_access_all_stores: req.storeContext.can_access_all_stores
        } : '無storeContext');

        // 檢查是否啟用同步功能
        const enableSync = process.env.ENABLE_SYNC !== 'false';
        if (!enableSync) {
            console.log('同步功能已禁用，返回空數據');
            return res.json({
                success: true,
                message: '同步功能已禁用',
                data: {
                    products: [],
                    employees: [],
                    stores: [],
                    receiptTemplates: [],
                    holidays: []
                },
                counts: {
                    products: 0,
                    employees: 0,
                    stores: 0,
                    receiptTemplates: 0,
                    holidays: 0
                },
                syncEnabled: false
            });
        }

        // 檢查是否為模擬模式
        const mockMode = process.env.SYNC_MOCK_MODE === 'true';
        if (mockMode) {
            console.log('模擬模式啟用，返回模擬數據');
            // 返回模擬數據用於測試
            return res.json({
                success: true,
                message: '模擬模式數據',
                data: {
                    products: generateMockProducts(),
                    employees: generateMockEmployees(),
                    stores: generateMockStores(),
                    receiptTemplates: generateMockReceiptTemplates(),
                    holidays: generateMockHolidays()
                },
                counts: {
                    products: 10,
                    employees: 5,
                    stores: 3,
                    receiptTemplates: 2,
                    holidays: 8
                },
                mockMode: true
            });
        }

        // 執行實際同步（傳遞分店ID）
        const syncResults = await syncManager.syncAllMasterData(storeId);

        // 如果同步成功，保存到本地數據庫
        console.log(`同步結果: success=${syncResults.success}, 數據存在? ${!!syncResults.data}, 產品數量: ${syncResults.data?.products?.length || 0}`);
        if (syncResults.success) {
            console.log('開始保存到本地數據庫...');
            await syncManager.saveToLocalDatabase(syncResults.data, storeId);
            console.log('保存到本地數據庫完成');

            // 數據同步成功後，執行48小時結賬單據清理（後台執行，不阻塞響應）
            console.log('啟動48小時結賬單據清理檢查...');
            try {
                const cleanupManager = new BillCleanupManager();
                const cleanupStats = await cleanupManager.getCleanupStats();
                console.log('清理統計:', cleanupStats);

                if (cleanupStats.cleanup_eligible > 0) {
                    console.log(`發現 ${cleanupStats.cleanup_eligible} 個需要清理的記錄，開始清理...`);
                    // 在後台執行清理，不阻塞主響應
                    cleanupManager.executeCleanup().then(result => {
                        if (result.success) {
                            console.log(`✓ 清理任務完成: 清理了 ${result.cleaned || 0} 個結賬單據`);
                        } else {
                            console.warn(`⚠️ 清理任務失敗: ${result.error}`);
                        }
                    }).catch(error => {
                        console.error('清理任務異常:', error);
                    });
                } else {
                    console.log('沒有需要清理的記錄');
                }
            } catch (cleanupError) {
                // 清理錯誤不應影響主同步流程
                console.error('清理檢查異常，但繼續主流程:', cleanupError.message);
            }
        }

        // 返回結果
        const response = {
            success: syncResults.success,
            message: syncResults.success ? '數據同步成功' : '數據同步失敗',
            timestamp: syncResults.timestamp,
            duration: syncResults.duration,
            data: syncResults.data,
            counts: syncResults.counts,
            errors: syncResults.errors,
            debug: {
                authConfigured: !!(syncManager.syncUsername && syncManager.syncPassword),
                authTokenExists: !!syncManager.authToken,
                tokenExpiry: syncManager.tokenExpiry,
                syncUsername: syncManager.syncUsername,
                aliyunServer: syncManager.aliyunServer
            }
        };

        res.json(response);

    } catch (error) {
        console.error('處理同步請求時發生錯誤:', error);
        res.status(500).json({
            success: false,
            error: '同步服務器錯誤',
            message: error.message,
            timestamp: new Date().toISOString()
        });
    }
});

/**
 * @route GET /api/sync/status
 * @desc 獲取同步狀態
 * @access Public
 */
router.get('/status', (req, res) => {
    try {
        const enableSync = process.env.ENABLE_SYNC !== 'false';
        const mockMode = process.env.SYNC_MOCK_MODE === 'true';
        const aliYunServer = process.env.ALIYUN_SERVER || '未設置';

        res.json({
            success: true,
            data: {
                syncEnabled: enableSync,
                mockMode,
                aliYunServer,
                timestamp: new Date().toISOString()
            }
        });
    } catch (error) {
        console.error('獲取同步狀態錯誤:', error);
        res.status(500).json({
            success: false,
            error: '獲取同步狀態失敗',
            message: error.message
        });
    }
});

/**
 * @route POST /api/sync/test-connection
 * @desc 測試與阿里雲服務器的連接
 * @access Public
 */
router.post('/test-connection', async (req, res) => {
    try {
        console.log('測試與阿里雲服務器的連接...');

        const testUrl = syncManager.getRemoteUrl('/api/stores');
        console.log(`測試URL: ${testUrl}`);

        // 嘗試連接
        const response = await axios.get(testUrl, {
            timeout: 10000,
            headers: {
                'Accept': 'application/json'
            }
        }).catch(error => {
            return { status: error.response?.status || 0, error: error.message };
        });

        if (response.status === 200) {
            res.json({
                success: true,
                message: '連接成功',
                server: syncManager.aliyunServer,
                timestamp: new Date().toISOString()
            });
        } else {
            res.json({
                success: false,
                message: '連接失敗',
                server: syncManager.aliyunServer,
                error: response.error || `HTTP狀態碼: ${response.status}`,
                timestamp: new Date().toISOString()
            });
        }
    } catch (error) {
        console.error('測試連接錯誤:', error);
        res.status(500).json({
            success: false,
            error: '測試連接失敗',
            message: error.message,
            timestamp: new Date().toISOString()
        });
    }
});

/**
 * @route POST /api/sync/upload-sensitive-operations
 * @desc 接收從分店上傳的敏感操作數據（刪桌、刪品）
 * @access Private (需要API密鑰或Bearer令牌)
 */
router.post('/upload-sensitive-operations', syncAuthMiddleware, async (req, res) => {
    try {
        console.log('收到敏感操作上傳請求');

        const {
            sensitive_operations,
            store_id,
            timestamp,
            count
        } = req.body;

        // 驗證必填字段
        if (!sensitive_operations || !Array.isArray(sensitive_operations)) {
            return res.status(400).json({
                success: false,
                error: '無效的請求數據',
                message: 'sensitive_operations 必須是一個數組'
            });
        }

        const operationsCount = sensitive_operations.length;
        console.log(`開始處理 ${operationsCount} 個敏感操作 (來自分店: ${store_id || '未知'})`);

        let savedCount = 0;
        const errors = [];

        // 處理每個敏感操作
        for (const operation of sensitive_operations) {
            try {
                // 檢查是否已存在（通過ID）
                const exists = await new Promise((resolve, reject) => {
                    db.get(
                        `SELECT id FROM audit_logs WHERE id = ?`,
                        [operation.id],
                        (err, row) => {
                            if (err) reject(err);
                            else resolve(!!row);
                        }
                    );
                });

                if (exists) {
                    console.log(`敏感操作 ${operation.id} 已存在，跳過`);
                    savedCount++;
                    continue;
                }

                // 解析 action_details（如果已經是字符串則直接使用）
                let actionDetails = operation.action_details;
                if (typeof actionDetails === 'object') {
                    actionDetails = JSON.stringify(actionDetails);
                }

                // 插入新記錄
                await new Promise((resolve, reject) => {
                    db.run(
                        `INSERT INTO audit_logs (
                            id, employee_id, action_type, action_details, ip_address,
                            store_id, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
                        [
                            operation.id,
                            operation.employee_id || null,
                            operation.action_type || 'unknown',
                            actionDetails || '',
                            operation.ip_address || '',
                            operation.store_id || store_id || 'default_store',
                            operation.created_at || new Date().toISOString()
                        ],
                        function(err) {
                            if (err) reject(err);
                            else {
                                console.log(`✓ 保存敏感操作: ${operation.id} (${operation.action_type})`);
                                savedCount++;
                                resolve();
                            }
                        }
                    );
                });

            } catch (operationError) {
                console.error(`處理敏感操作 ${operation.id} 失敗:`, operationError.message);
                errors.push(`${operation.id}: ${operationError.message}`);
            }
        }

        console.log(`敏感操作處理完成: ${savedCount}/${operationsCount} 個成功${errors.length > 0 ? `, ${errors.length} 個失敗` : ''}`);

        res.json({
            success: true,
            message: `成功接收 ${savedCount} 個敏感操作`,
            data: {
                received: operationsCount,
                saved: savedCount,
                errors: errors.length,
                store_id: store_id || 'unknown',
                timestamp: timestamp || new Date().toISOString()
            }
        });

    } catch (error) {
        console.error('處理敏感操作上傳請求錯誤:', error);
        res.status(500).json({
            success: false,
            error: '服務器錯誤',
            message: error.message,
            timestamp: new Date().toISOString()
        });
    }
});

/**
 * @route POST /api/sync/trigger-sensitive-upload
 * @desc 觸發立即上傳未上傳的敏感操作到主機
 * @access Private (需要API密鑰或Bearer令牌)
 */
router.post('/trigger-sensitive-upload', syncAuthMiddleware, async (req, res) => {
    try {
        console.log('收到觸發立即上傳敏感操作請求');

        if (!BillUploadManager) {
            return res.status(500).json({
                success: false,
                error: '上傳模塊未加載',
                message: 'upload-bills 模塊不可用'
            });
        }

        // 創建上傳管理器實例
        const uploadManager = new BillUploadManager();

        // 認證
        const authSuccess = await uploadManager.authenticate();
        if (!authSuccess) {
            return res.status(401).json({
                success: false,
                error: '認證失敗',
                message: '無法認證到主機服務器'
            });
        }

        // 獲取需要上傳的敏感操作
        const sensitiveOperations = await uploadManager.getSensitiveOperationsToUpload();
        console.log(`找到 ${sensitiveOperations.length} 個未上傳的敏感操作`);

        let uploadResult = { success: true, uploaded: 0 };

        // 如果有敏感操作需要上傳，則上傳
        if (sensitiveOperations.length > 0) {
            uploadResult = await uploadManager.uploadSensitiveOperations(sensitiveOperations);
            console.log(`敏感操作上傳結果: ${uploadResult.uploaded || 0}/${sensitiveOperations.length} 個成功`);
        } else {
            console.log('沒有需要上傳的敏感操作');
        }

        res.json({
            success: true,
            message: `立即上傳完成: ${uploadResult.uploaded || 0} 個敏感操作已上傳`,
            data: {
                operations_found: sensitiveOperations.length,
                operations_uploaded: uploadResult.uploaded || 0,
                upload_success: uploadResult.success,
                timestamp: new Date().toISOString()
            }
        });

    } catch (error) {
        console.error('觸發立即上傳敏感操作錯誤:', error);
        res.status(500).json({
            success: false,
            error: '服務器錯誤',
            message: error.message,
            timestamp: new Date().toISOString()
        });
    }
});

// 模擬數據生成函數（用於測試）
function generateMockProducts() {
    return [
        { id: '1', name: '拿鐵咖啡', price: 45, category: '飲品', is_available: true },
        { id: '2', name: '美式咖啡', price: 35, category: '飲品', is_available: true },
        { id: '3', name: '巴斯克芝士蛋糕', price: 65, category: '甜品', is_available: true },
        { id: '4', name: '全日通', price: 180, category: '時段', is_available: true },
        { id: '5', name: '首小時', price: 60, category: '時段', is_available: true }
    ];
}

function generateMockEmployees() {
    return [
        { id: '1', username: 'admin', full_name: '系統管理員', role: 'admin', store_id: null },
        { id: '2', username: 'staff1', full_name: '員工一號', role: 'staff', store_id: 'store_001' },
        { id: '3', username: 'staff2', full_name: '員工二號', role: 'staff', store_id: 'store_001' }
    ];
}

function generateMockStores() {
    return [
        { id: 'store_001', store_code: 'STORE001', store_name: '台北分店', is_active: 1 },
        { id: 'store_002', store_code: 'STORE002', store_name: '台中分店', is_active: 1 },
        { id: 'default_store', store_code: 'DEFAULT', store_name: '默認分店', is_active: 1 }
    ];
}

function generateMockReceiptTemplates() {
    return [
        { id: '1', template_name: '默認小票模板', store_id: 'default_store', is_default: 1 },
        { id: '2', template_name: '台北分店專用模板', store_id: 'store_001', is_default: 0 }
    ];
}

function generateMockHolidays() {
    const currentYear = new Date().getFullYear();
    return [
        { id: '1', date: `${currentYear}-01-01`, description: '元旦' },
        { id: '2', date: `${currentYear}-02-10`, description: '春節' },
        { id: '3', date: `${currentYear}-02-11`, description: '春節' },
        { id: '4', date: `${currentYear}-02-12`, description: '春節' },
        { id: '5', date: `${currentYear}-04-04`, description: '清明節' },
        { id: '6', date: `${currentYear}-05-01`, description: '勞動節' },
        { id: '7', date: `${currentYear}-06-10`, description: '端午節' },
        { id: '8', date: `${currentYear}-10-01`, description: '中秋節' }
    ];
}

module.exports = router;