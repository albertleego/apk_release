/**
 * 阿里雲預約/候位資料 Proxy
 *
 * 作用：
 *   本地主機通過此 Proxy fetch 阿里雲嘅 booking + waitinglist + paused_slots 資料，
 *   暫存到本地 SQLite cache，萬一阿里雲 down 咗都可以睇到最後一次嘅資料。
 *
 *   分機經現有 master-client buildApiUrl() redirect 過嚟，唔使出阿里雲。
 *
 * 暫停時段流程：
 *   本地暫停/恢復 → 即時上傳阿里雲（非阻塞）
 *   阿里雲暫停時段 → 按刷新 fetch 落來，INSERT OR IGNORE 入本地
 *   分機暫停 → master-client redirect → 主機處理 → 上阿里雲
 */

const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../../database/db');
const hongKongTime = require('../utils/hongKongTime');

// ============================================================
// 配置
// ============================================================
const ALIYUN_SERVER = (process.env.ALIYUN_SERVER || 'http://47.239.121.13:3000').replace(/\/$/, '');
const API_KEY = process.env.ALIYUN_API_KEY || process.env.MAIN_API_KEY || '';
const FETCH_TIMEOUT_MS = parseInt(process.env.ALIYUN_PROXY_TIMEOUT || '8000', 10); // 無回應 timeout（預設 8 秒）

// ============================================================
// 狀態
// ============================================================
let _cacheStatus = {
    booking: { lastFetch: null, success: false, count: 0, error: null },
    waitinglist: { lastFetch: null, success: false, count: 0, error: null },
    paused: { lastFetch: null, success: false, count: 0, error: null },
    online: false
};
let _pendingFetch = null;          // 去重用：如果 fetch 緊就等佢完成

// ============================================================
// Helper：fetch 阿里雲 API
// ============================================================
async function fetchFromAliyun(endpoint) {
    const url = `${ALIYUN_SERVER}${endpoint}`;
    const headers = { 'x-api-key': API_KEY };

    // 用 AbortController 做真正嘅 timeout
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);

    try {
        const res = await fetch(url, { headers, signal: controller.signal });
        clearTimeout(timer);
        if (!res.ok) {
            const body = await res.text().catch(() => '');
            throw new Error(`阿里雲回應 ${res.status}: ${body.slice(0, 200)}`);
        }
        return res.json();
    } catch (e) {
        clearTimeout(timer);
        if (e.name === 'AbortError') {
            throw new Error(`阿里雲無回應（超過 ${FETCH_TIMEOUT_MS/1000} 秒）`);
        }
        throw e;
    }
}

// ============================================================
// 提取 booking list + 存入本地 cache table
// ============================================================
async function fetchBookingList(storeId, date) {
    const start = Date.now();
    console.log(`[aliyun-proxy] 提取預約資料 storeId=${storeId} date=${date}`);

    // 先清 cache，確保唔會有舊 record 留低
    try { await clearBookingCache(); } catch (e) { console.warn('[aliyun-proxy] 清 booking cache 失敗:', e.message); }

    let query = '/api/booking/list?';
    if (storeId) query += 'store_id=' + encodeURIComponent(storeId) + '&';
    if (date) query += 'date=' + encodeURIComponent(date) + '&';

    const result = await fetchFromAliyun(query);

    if (!result || !result.success) {
        throw new Error(result ? (result.error || result.message || '提取失敗') : '無回應');
    }

    const data = result.data || [];
    const now = new Date().toISOString();

    // 寫入本地 cache table
    const stmt = db.prepare(`
        INSERT OR REPLACE INTO aliyun_booking_cache
            (id, store_id, booking_date, booking_time, adults, children, phone, notes, status, table_number, lang, created_at, updated_at, cached_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const item of data) {
        stmt.run(
            item.id, item.store_id || storeId, item.booking_date, item.booking_time,
            item.adults || 0, item.children || 0, item.phone || '',
            item.notes || '', item.status || 'confirmed',
            item.table_number || null, item.lang || 'zh-TW',
            item.created_at || now, item.updated_at || now, now
        );
    }
    stmt.finalize();

    // 更新狀態
    _cacheStatus.booking = {
        lastFetch: now,
        success: true,
        count: data.length,
        error: null
    };
    _cacheStatus.online = true;

    console.log(`[aliyun-proxy] 預約提取完成 ${data.length} 條 (${Date.now() - start}ms)`);
    return data;
}

// ============================================================
// 提取 waitinglist + 存入本地 cache table
// ============================================================
async function fetchWaitinglist(storeId) {
    const start = Date.now();
    console.log(`[aliyun-proxy] 提取候位資料 storeId=${storeId}`);

    let query = '/api/waitinglist?';
    if (storeId) query += 'store_id=' + encodeURIComponent(storeId) + '&';

    const result = await fetchFromAliyun(query);

    if (!result || !result.success) {
        throw new Error(result ? (result.error || result.message || '提取失敗') : '無回應');
    }

    const data = result.data || [];
    const now = new Date().toISOString();

    // 寫入本地 cache table
    const stmt = db.prepare(`
        INSERT OR REPLACE INTO aliyun_waitinglist_cache
            (id, store_id, adults, children, phone, notes, status, ref_number, table_number, lang, created_at, updated_at, cached_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const item of data) {
        stmt.run(
            item.id, item.store_id || storeId,
            item.adults || 0, item.children || 0, item.phone || '',
            item.notes || '', item.status || 'waiting',
            item.ref_number || null, item.table_number || null,
            item.lang || 'zh-TW',
            item.created_at || now, item.updated_at || now, now
        );
    }
    stmt.finalize();

    // 更新狀態
    _cacheStatus.waitinglist = {
        lastFetch: now,
        success: true,
        count: data.length,
        error: null
    };
    _cacheStatus.online = true;

    console.log(`[aliyun-proxy] 候位提取完成 ${data.length} 條 (${Date.now() - start}ms)`);
    return data;
}

// ============================================================
// 從本地 cache 讀取（阿里雲 down 時 fallback）
// ============================================================
function getBookingFromCache(storeId, date) {
    return new Promise((resolve, reject) => {
        let sql = `SELECT * FROM aliyun_booking_cache WHERE 1=1`;
        const params = [];
        if (storeId) { sql += ` AND store_id = ?`; params.push(storeId); }
        if (date) { sql += ` AND booking_date = ?`; params.push(date); }
        sql += ` ORDER BY booking_date ASC, booking_time ASC`;

        db.all(sql, params, (err, rows) => {
            if (err) return reject(err);
            resolve({ data: rows || [], cached_at: _cacheStatus.booking.lastFetch });
        });
    });
}

function getWaitinglistFromCache(storeId) {
    return new Promise((resolve, reject) => {
        let sql = `SELECT * FROM aliyun_waitinglist_cache WHERE 1=1`;
        const params = [];
        if (storeId) { sql += ` AND store_id = ?`; params.push(storeId); }
        sql += ` ORDER BY created_at DESC`;

        db.all(sql, params, (err, rows) => {
            if (err) return reject(err);
            resolve({ data: rows || [], cached_at: _cacheStatus.waitinglist.lastFetch });
        });
    });
}

// ============================================================
// 清空 cache table（每次成功 fetch 前畀機會重整）
// ============================================================
function clearBookingCache() {
    return new Promise((resolve, reject) => {
        db.run(`DELETE FROM aliyun_booking_cache`, (err) => {
            if (err) reject(err);
            else resolve();
        });
    });
}

function clearWaitinglistCache() {
    return new Promise((resolve, reject) => {
        db.run(`DELETE FROM aliyun_waitinglist_cache`, (err) => {
            if (err) reject(err);
            else resolve();
        });
    });
}

// ============================================================
// 同時 fetch booking + waitinglist（refresh-all 用）
// ============================================================
async function fetchBoth(storeId, date) {
    // 去重：如果有 pending fetch，等佢完成
    if (_pendingFetch) {
        console.log('[aliyun-proxy] 有 pending fetch，重用結果');
        return _pendingFetch;
    }

    const promise = (async () => {
        // 先清 cache（確保數據一致性）
        try {
            await Promise.all([clearBookingCache(), clearWaitinglistCache()]);
        } catch (e) {
            console.warn('[aliyun-proxy] 清 cache 警告（可忽略）:', e.message);
        }

        const results = { booking: [], waitinglist: [], online: false };
        let hasError = false;

        try {
            results.booking = await fetchBookingList(storeId, date);
        } catch (e) {
            console.error('[aliyun-proxy] fetch 預約失敗:', e.message);
            _cacheStatus.booking = { ..._cacheStatus.booking, success: false, error: e.message };
            hasError = true;
        }

        try {
            results.waitinglist = await fetchWaitinglist(storeId);
        } catch (e) {
            console.error('[aliyun-proxy] fetch 候位失敗:', e.message);
            _cacheStatus.waitinglist = { ..._cacheStatus.waitinglist, success: false, error: e.message };
            hasError = true;
        }

        results.online = !hasError;
        _cacheStatus.online = !hasError;
        return results;
    })();

    _pendingFetch = promise;
    try {
        return await promise;
    } finally {
        _pendingFetch = null;
    }
}

// ============================================================
// 提取阿里雲暫停時段 → merge 入本地 paused_slots
// ============================================================
async function fetchPausedSlots(storeId, fromDate) {
    const start = Date.now();
    console.log(`[aliyun-proxy] 提取暫停時段 storeId=${storeId} fromDate=${fromDate}`);

    // 用上次成功 fetch 時間做保護：
    // 只刪除上次 fetch 之前已經存在嘅記錄，之後新增嘅（可能未 upload）唔會剷走
    const protectAfter = _cacheStatus.paused.lastFetch;

    let query = '/api/booking/paused?store_id=' + encodeURIComponent(storeId);
    if (fromDate) query += '&from_date=' + encodeURIComponent(fromDate);

    const result = await fetchFromAliyun(query);

    if (!result || !result.success) {
        throw new Error(result ? (result.error || result.message || '提取失敗') : '無回應');
    }

    const data = result.data || [];

    // 收集阿里雲回傳嘅日期 + ID
    const aliyunIdsSet = new Set(data.filter(d => d.id).map(d => d.id));
    const aliyunDates = [...new Set(data.filter(d => d.booking_date).map(d => d.booking_date))].sort();

    // 步驟 1：刪除阿里雲有回應嘅日期入面，阿里雲冇咗嘅本地記錄（by ID 比對）
    if (storeId && protectAfter && aliyunDates.length > 0 && aliyunIdsSet.size > 0) {
        const datePlaceholders = aliyunDates.map(() => '?').join(',');
        const idPlaceholders = [...aliyunIdsSet].map(() => '?').join(',');
        await new Promise((resolve) => {
            db.run(
                `DELETE FROM paused_slots WHERE store_id = ? AND booking_date IN (${datePlaceholders}) AND id NOT IN (${idPlaceholders}) AND created_at <= ?`,
                [storeId, ...aliyunDates, ...aliyunIdsSet, protectAfter],
                function(err) {
                    if (err) console.warn('[aliyun-proxy] sync 刪除本地已刪暫停失敗:', err.message);
                    else if (this.changes > 0) console.log(`[aliyun-proxy] sync 已刪除 ${this.changes} 條本地已刪暫停`);
                    resolve();
                }
            );
        });
    }

    // 步驟 2：刪除 >= fromDate 嘅日期入面，阿里雲完全冇返嘅日期
    // 都係只刪 protectAfter 之前嘅記錄
    if (storeId && protectAfter && fromDate) {
        let sql = `DELETE FROM paused_slots WHERE store_id = ? AND booking_date >= ? AND created_at <= ?`;
        const params = [storeId, fromDate, protectAfter];
        if (aliyunDates.length > 0) {
            const dPlaceholders = aliyunDates.map(() => '?').join(',');
            sql += ` AND booking_date NOT IN (${dPlaceholders})`;
            params.push(...aliyunDates);
        }
        await new Promise((resolve) => {
            db.run(sql, params, function(err) {
                if (err) console.warn('[aliyun-proxy] sync 清理已刪日期失敗:', err.message);
                else if (this.changes > 0) console.log(`[aliyun-proxy] sync 已清理 ${this.changes} 條已刪日期暫停`);
                resolve();
            });
        });
    }

    // 插入阿里雲嘅資料
    let insertedCount = 0;
    for (const item of data) {
        if (!item.booking_date || !item.booking_time) continue;
        await new Promise((resolve, reject) => {
            db.run(
                `INSERT OR IGNORE INTO paused_slots (id, store_id, booking_date, booking_time)
                 VALUES (?, ?, ?, ?)`,
                [item.id, item.store_id || storeId, item.booking_date, item.booking_time],
                function(err) {
                    if (err) {
                        reject(err);
                    } else {
                        if (this.changes > 0) insertedCount++;
                        resolve();
                    }
                }
            );
        });
    }

    _cacheStatus.paused = {
        lastFetch: now,
        success: true,
        count: data.length,
        error: null
    };
    _cacheStatus.online = true;

    console.log(`[aliyun-proxy] 暫停時段提取完成 ${data.length} 條（新插入 ${insertedCount} 條）(${Date.now() - start}ms)`);
    return data;
}

// ============================================================
// Upload helpers — 俾 bookingRoutes.js 用完本地 save 後 call
// ============================================================
function uploadPauseToAliyun(storeId, date, timeSlots) {
    if (!ALIYUN_SERVER || !API_KEY) return Promise.resolve();
    const url = `${ALIYUN_SERVER}/api/booking/pause`;
    return fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY },
        body: JSON.stringify({ store_id: storeId, date, time_slots: timeSlots })
    }).then(r => {
        if (!r.ok) console.warn(`[aliyun-proxy] upload pause 失敗: ${r.status}`);
        else console.log(`[aliyun-proxy] upload pause 成功: ${storeId} ${date} ${timeSlots.length} slots`);
    }).catch(e => console.warn(`[aliyun-proxy] upload pause error:`, e.message));
}

function uploadResumeToAliyun(storeId, date) {
    if (!ALIYUN_SERVER || !API_KEY) return Promise.resolve();
    const url = `${ALIYUN_SERVER}/api/booking/resume`;
    return fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY },
        body: JSON.stringify({ store_id: storeId, date })
    }).then(r => {
        if (!r.ok) console.warn(`[aliyun-proxy] upload resume 失敗: ${r.status}`);
        else console.log(`[aliyun-proxy] upload resume 成功: ${storeId} ${date}`);
    }).catch(e => console.warn(`[aliyun-proxy] upload resume error:`, e.message));
}

function uploadDeleteRangeToAliyun(storeId, date, startTime, endTime) {
    if (!ALIYUN_SERVER || !API_KEY) return Promise.resolve();
    const url = `${ALIYUN_SERVER}/api/booking/pause/delete-range`;
    return fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY },
        body: JSON.stringify({ store_id: storeId, date, start_time: startTime, end_time: endTime })
    }).then(r => {
        if (!r.ok) console.warn(`[aliyun-proxy] upload delete-range 失敗: ${r.status}`);
        else console.log(`[aliyun-proxy] upload delete-range 成功: ${storeId} ${date} ${startTime}-${endTime}`);
    }).catch(e => console.warn(`[aliyun-proxy] upload delete-range error:`, e.message));
}

// ============================================================
// Routes
// ============================================================

/**
 * GET /api/aliyun-proxy/booking/list
 * 前端 call 呢個代替原本 /api/booking/list
 */
router.get('/booking/list', async (req, res) => {
    const storeId = req.query.store_id || '';
    const date = req.query.date || '';

    try {
        const data = await fetchBookingList(storeId, date);
        res.json({ success: true, data, source: 'aliyun' });
    } catch (e) {
        console.error(`[aliyun-proxy] booking list 提取失敗，fallback cache:`, e.message);
        try {
            const cached = await getBookingFromCache(storeId, date);
            const offline = !_cacheStatus.booking.lastFetch;
            res.json({
                success: true,
                data: cached.data,
                source: offline ? 'offline-cache' : 'cache',
                cached_at: cached.cached_at,
                warning: offline ? '無法連線阿里雲，顯示離線資料' : '顯示快取資料（最後更新: ' + (cached.cached_at || '-') + '）'
            });
        } catch (cacheErr) {
            res.status(503).json({
                success: false,
                error: '無法連線阿里雲，亦無離線快取',
                message: cacheErr.message
            });
        }
    }
});

/**
 * GET /api/aliyun-proxy/waitinglist
 * 前端 call 呢個代替原本 /api/waitinglist
 */
router.get('/waitinglist', async (req, res) => {
    const storeId = req.query.store_id || '';

    try {
        const data = await fetchWaitinglist(storeId);
        res.json({ success: true, data, source: 'aliyun' });
    } catch (e) {
        console.error(`[aliyun-proxy] waitinglist 提取失敗，fallback cache:`, e.message);
        try {
            const cached = await getWaitinglistFromCache(storeId);
            const offline = !_cacheStatus.waitinglist.lastFetch;
            res.json({
                success: true,
                data: cached.data,
                source: offline ? 'offline-cache' : 'cache',
                cached_at: cached.cached_at,
                warning: offline ? '無法連線阿里雲，顯示離線資料' : '顯示快取資料（最後更新: ' + (cached.cached_at || '-') + '）'
            });
        } catch (cacheErr) {
            res.status(503).json({
                success: false,
                error: '無法連線阿里雲，亦無離線快取',
                message: cacheErr.message
            });
        }
    }
});

/**
 * GET /api/aliyun-proxy/booking/paused
 * 提取阿里雲暫停時段 + merge 入本地 → 回傳本地全部
 */
router.get('/booking/paused', async (req, res) => {
    const storeId = req.query.store_id || '';
    const date = req.query.date || '';
    const fromDate = req.query.from_date || '';

    // 1. 嘗試 fetch 阿里雲暫停時段 → merge 入本地
    if (storeId && (date || fromDate)) {
        try {
            await fetchPausedSlots(storeId, fromDate || date);
        } catch (e) {
            console.error(`[aliyun-proxy] fetch paused 失敗，fallback 本地:`, e.message);
        }
    }

    // 2. 查本地 paused_slots（已包含阿里雲 merge 入來嘅）
    try {
        let sql = `SELECT * FROM paused_slots WHERE store_id = ?`;
        const params = [storeId];
        if (date) {
            sql += ` AND booking_date = ?`;
            params.push(date);
        } else if (fromDate) {
            sql += ` AND booking_date >= ?`;
            params.push(fromDate);
        }
        sql += ` ORDER BY booking_date ASC, booking_time ASC`;

        db.all(sql, params, (err, rows) => {
            if (err) {
                return res.status(500).json({ success: false, error: '查詢錯誤', message: err.message });
            }
            const offline = _cacheStatus.paused.lastFetch && !_cacheStatus.paused.success;
            res.json({
                success: true,
                data: rows || [],
                source: offline ? 'cache' : (_cacheStatus.paused.lastFetch ? 'aliyun+local' : 'local')
            });
        });
    } catch (e) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: e.message });
    }
});

/**
 * POST /api/aliyun-proxy/refresh-all
 * 同時 refresh booking + waitinglist（俾 refresh button call）
 */
router.post('/refresh-all', async (req, res) => {
    const storeId = req.body.store_id || req.query.store_id || '';
    const date = req.body.date || req.query.date || '';

    try {
        const results = await fetchBoth(storeId, date);
        res.json({
            success: true,
            booking: { count: results.booking.length, success: !_cacheStatus.booking.error },
            waitinglist: { count: results.waitinglist.length, success: !_cacheStatus.waitinglist.error },
            online: results.online,
            errors: {
                booking: _cacheStatus.booking.error,
                waitinglist: _cacheStatus.waitinglist.error
            }
        });
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});

/**
 * GET /api/aliyun-proxy/status
 * 睇同步狀態
 */
router.get('/status', (req, res) => {
    res.json({
        success: true,
        data: {
            online: _cacheStatus.online,
            booking: _cacheStatus.booking,
            waitinglist: _cacheStatus.waitinglist,
            paused: _cacheStatus.paused,
            aliyunServer: ALIYUN_SERVER
        }
    });
});

/**
 * GET /api/aliyun-proxy/booking/capacity/config/:store_id
 * 從阿里雲 fetch 座位分配設定 → INSERT OR REPLACE 入本地
 */
router.get('/booking/capacity/config/:store_id', async (req, res) => {
    const storeId = req.params.store_id;
    if (!storeId) return res.status(400).json({ success: false, error: '缺少分店 ID' });

    const start = Date.now();
    console.log(`[aliyun-proxy] 提取座位分配 storeId=${storeId}`);

    try {
        const result = await fetchFromAliyun(`/api/booking/capacity/config/${storeId}`);
        if (!result || !result.success) throw new Error(result ? (result.error || result.message || '提取失敗') : '無回應');
        const data = result.data;
        if (!data) throw new Error('無資料');

        if (data.defaults) {
            Object.keys(data.defaults).forEach(function(dtg) {
                db.run(`INSERT INTO store_capacity (id, store_id, daytype_group, capacity, updated_at) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP) ON CONFLICT(store_id, daytype_group) DO UPDATE SET capacity = ?, updated_at = CURRENT_TIMESTAMP`, [uuidv4(), storeId, dtg, data.defaults[dtg], data.defaults[dtg]]);
            });
        }
        if (data.slots) {
            ['weekday', 'holiday'].forEach(function(dtg) {
                var slotData = data.slots[dtg] || {};
                Object.keys(slotData).forEach(function(time) {
                    db.run(`INSERT INTO store_slot_capacity (id, store_id, daytype_group, booking_time, capacity, updated_at) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP) ON CONFLICT(store_id, daytype_group, booking_time) DO UPDATE SET capacity = ?, updated_at = CURRENT_TIMESTAMP`, [uuidv4(), storeId, dtg, time, slotData[time], slotData[time]]);
                });
            });
        }

        console.log(`[aliyun-proxy] 座位分配提取完成 (${Date.now() - start}ms)`);
        res.json({ success: true, data, source: 'aliyun' });
    } catch (e) {
        console.error(`[aliyun-proxy] 座位分配提取失敗:`, e.message);
        db.all(`SELECT daytype_group, capacity FROM store_capacity WHERE store_id = ?`, [storeId], (err, defaultRows) => {
            if (err) return res.status(502).json({ success: false, error: '無法連線阿里雲', message: e.message });
            var config = { weekday: 20, holiday: 20 };
            (defaultRows || []).forEach(function(r) { config[r.daytype_group] = r.capacity; });
            db.all(`SELECT daytype_group, booking_time, capacity FROM store_slot_capacity WHERE store_id = ? ORDER BY daytype_group, booking_time`, [storeId], (err2, slotRows) => {
                var slotConfig = { weekday: {}, holiday: {} };
                (slotRows || []).forEach(function(r) { slotConfig[r.daytype_group][r.booking_time] = r.capacity; });
                res.json({ success: true, data: { defaults: config, slots: slotConfig }, source: 'local-cache' });
            });
        });
    }
});

console.log(`[aliyun-proxy] 已啟動，目標: ${ALIYUN_SERVER}`);

module.exports = router;
module.exports.uploadPauseToAliyun = uploadPauseToAliyun;
module.exports.uploadResumeToAliyun = uploadResumeToAliyun;
module.exports.uploadDeleteRangeToAliyun = uploadDeleteRangeToAliyun;
