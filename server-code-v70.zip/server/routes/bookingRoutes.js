const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../../database/db');
const authMiddleware = require('../middleware/auth');
const { sendBookingConfirmation } = require('../services/twilioService');
const { uploadPauseToAliyun, uploadResumeToAliyun, uploadDeleteRangeToAliyun } = require('./aliyunProxyRoutes');

// 阿里雲 forward helper：本地搵唔到 record 時 proxy 去阿里雲
const ALIYUN_SERVER = (process.env.ALIYUN_SERVER || 'http://47.239.121.13:3000').replace(/\/$/, '');
const API_KEY = process.env.ALIYUN_API_KEY || process.env.MAIN_API_KEY || '';
const FETCH_TIMEOUT_MS = parseInt(process.env.ALIYUN_PROXY_TIMEOUT || '8000', 10);
function forwardToAliyun(method, endpoint, body) {
    const url = `${ALIYUN_SERVER}${endpoint}`;
    const opts = {
        method,
        headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY }
    };
    if (body) opts.body = JSON.stringify(body);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    opts.signal = controller.signal;
    return fetch(url, opts).then(r => { clearTimeout(timer); return r.json(); }).catch(e => { clearTimeout(timer); throw e; });
}

// Helper: 攞分店對應日期嘅 daytype group ('weekday' / 'holiday')
function getDaytypeGroup(date, callback) {
  db.get(`SELECT COALESCE(daytype, '') as daytype, COALESCE(description, '') as description FROM holidays WHERE date = ? AND store_id = 'default_store'`, [date], (err, row) => {
    var isHoliday = false;
    if (!err && row) {
      // daytype 可能喺 daytype 欄位或者 description 欄位（"daytype=B" 格式）
      var raw = row.daytype || row.description || '';
      // "daytype=B" → extract "B"
      var m = raw.match(/[NHSUB]|daytype=([NHSUB])/);
      var dt = m ? (m[1] || m[0]) : '';
      if (dt === 'H' || dt === 'S' || dt === 'U' || dt === 'B') isHoliday = true;
      else if (dt === 'N' || dt === 'F') isHoliday = false;
    } else {
      var d = new Date(date + 'T00:00+08:00');
      var w = d.getDay();
      isHoliday = (w === 0 || w === 6);
    }
    callback(isHoliday ? 'holiday' : 'weekday');
  });
}

// Helper: 攞分店對應日期 + time slot 嘅 capacity
function getSlotCapacity(storeId, date, time, callback) {
  getDaytypeGroup(date, function(group) {
    // 先 check per-slot capacity
    db.get(`SELECT capacity FROM store_slot_capacity WHERE store_id = ? AND daytype_group = ? AND booking_time = ?`,
      [storeId, group, time], function(err, row) {
        if (!err && row) {
          callback(row.capacity);
        } else {
          // Fallback to daytype default
          db.get(`SELECT capacity FROM store_capacity WHERE store_id = ? AND daytype_group = ?`,
            [storeId, group], function(err2, row2) {
              callback(err2 || !row2 ? 20 : row2.capacity);
            });
        }
      });
  });
}

// Helper: 攞分店對應日期所有 slot capacity map
function getSlotCapacityMap(storeId, date, callback) {
  getDaytypeGroup(date, function(group) {
    db.all(`SELECT booking_time, capacity FROM store_slot_capacity WHERE store_id = ? AND daytype_group = ?`,
      [storeId, group], function(err, slotRows) {
        var defaultCap = 20;
        db.get(`SELECT capacity FROM store_capacity WHERE store_id = ? AND daytype_group = ?`,
          [storeId, group], function(err2, row2) {
            if (!err2 && row2) defaultCap = row2.capacity;
            var map = {};
            (slotRows || []).forEach(function(r) { map[r.booking_time] = r.capacity; });
            callback(map, defaultCap, group);
          });
      });
  });
}

/**
 * @route POST /api/booking
 * @desc 新增預約（公開，客戶使用）
 * @access Public
 */
router.post('/', (req, res) => {
    try {
        const { store_id, booking_date, booking_time, adults, children, phone, notes, lang } = req.body;
        if (!store_id || !booking_date || !booking_time || !phone) {
            return res.status(400).json({ success: false, error: '缺少必要欄位', message: '請填寫分店、日期、時間和聯絡電話' });
        }
        if (!/^\d{4}-\d{2}-\d{2}$/.test(booking_date)) {
            return res.status(400).json({ success: false, error: '日期格式錯誤', message: '日期格式需為 YYYY-MM-DD' });
        }
        if (!/^\d{2}:\d{2}$/.test(booking_time)) {
            return res.status(400).json({ success: false, error: '時間格式錯誤', message: '時間格式需為 HH:MM' });
        }
        forwardToAliyun('POST', '/api/booking', { store_id, booking_date, booking_time, adults, children, phone, notes, lang })
            .then(result => res.status(result && result.success ? 201 : 400).json(result))
            .catch(e => res.status(502).json({ success: false, error: '無法連線阿里雲', message: e.message }));
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

router.get('/list', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { store_id, date, status, phone } = req.query;
        const params = [];
        let query = `SELECT * FROM bookings WHERE 1=1`;

        if (store_id) {
            query += ` AND store_id = ?`;
            params.push(store_id);
        }

        if (date) {
            query += ` AND booking_date = ?`;
            params.push(date);
        } else {
            // 預設今天
            const today = new Date();
            const hkDate = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
            query += ` AND booking_date = ?`;
            params.push(hkDate);
        }

        if (status) {
            query += ` AND status = ?`;
            params.push(status);
        }

        if (phone) {
            query += ` AND phone LIKE ?`;
            params.push(`%${phone}%`);
        }

        query += ` ORDER BY booking_date ASC, booking_time ASC`;

        db.all(query, params, (err, rows) => {
            if (err) {
                console.error('查詢預約列表錯誤:', err);
                return res.status(500).json({
                    success: false,
                    error: '伺服器錯誤',
                    message: err.message
                });
            }

            res.json({
                success: true,
                data: rows || []
            });
        });
    } catch (error) {
        console.error('查詢預約列表錯誤:', error);
        res.status(500).json({
            success: false,
            error: '伺服器錯誤',
            message: error.message
        });
    }
});

/**
 * @route PATCH /api/booking/:id/cancel
 * @desc 取消預約（公開，需 phone 驗證）
 * @access Public
 */
router.patch('/:id/cancel', (req, res) => {
    try {
        const { phone } = req.body;
        const { id } = req.params;

        if (!phone) {
            return res.status(400).json({
                success: false,
                error: '缺少電話號碼',
                message: '請提供預約時使用的電話號碼以驗證身份'
            });
        }

        db.get(
            `SELECT * FROM bookings WHERE id = ? AND status = 'confirmed'`,
            [id],
            (err, booking) => {
                if (err) {
                    return res.status(500).json({
                        success: false,
                        error: '伺服器錯誤',
                        message: err.message
                    });
                }

                if (!booking) {
                    return res.status(404).json({
                        success: false,
                        error: '找不到該預約',
                        message: '預約不存在或已取消'
                    });
                }

                if (booking.phone !== phone) {
                    return res.status(403).json({
                        success: false,
                        error: '電話號碼不符',
                        message: '提供的電話號碼與預約記錄不符'
                    });
                }

                db.run(
                    `UPDATE bookings SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
                    [id],
                    function (updateErr) {
                        if (updateErr) {
                            return res.status(500).json({
                                success: false,
                                error: '取消預約失敗',
                                message: updateErr.message
                            });
                        }

                        res.json({
                            success: true,
                            message: '預約已取消',
                            data: { id }
                        });
                    }
                );
            }
        );
    } catch (error) {
        console.error('取消預約錯誤:', error);
        res.status(500).json({
            success: false,
            error: '伺服器錯誤',
            message: error.message
        });
    }
});

/**
 * @route PATCH /api/booking/:id/edit
 * @desc 編輯預約（公開，需 phone 驗證）
 * @access Public
 */
router.patch('/:id/edit', (req, res) => {
    try {
        const { phone, store_id, booking_date, booking_time, adults, children, notes } = req.body;
        const { id } = req.params;

        if (!phone) {
            return res.status(400).json({
                success: false, error: '缺少電話號碼',
                message: '請提供預約時使用的電話號碼以驗證身份'
            });
        }

        if (!store_id || !booking_date || !booking_time) {
            return res.status(400).json({
                success: false, error: '缺少必要欄位',
                message: '請填寫分店、日期和時間'
            });
        }

        if (!/^\d{4}-\d{2}-\d{2}$/.test(booking_date)) {
            return res.status(400).json({
                success: false, error: '日期格式錯誤',
                message: '日期格式需為 YYYY-MM-DD'
            });
        }

        if (!/^\d{2}:\d{2}$/.test(booking_time)) {
            return res.status(400).json({
                success: false, error: '時間格式錯誤',
                message: '時間格式需為 HH:MM'
            });
        }

        const adultCount = parseInt(adults);
        const childCount = parseInt(children);

        if (isNaN(adultCount) || adultCount < 1 || adultCount > 12) {
            return res.status(400).json({
                success: false, error: '人數超出範圍',
                message: '大人人數需為 1-12 人'
            });
        }
        if (isNaN(childCount) || childCount < 0 || childCount > 8) {
            return res.status(400).json({
                success: false, error: '人數超出範圍',
                message: '小朋友人數需為 0-8 人'
            });
        }

        db.get(`SELECT * FROM bookings WHERE id = ? AND status = 'confirmed'`, [id], (err, booking) => {
            if (err) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });
            if (!booking) return res.status(404).json({ success: false, error: '找不到該預約', message: '預約不存在或已取消' });
            if (booking.phone !== phone) return res.status(403).json({ success: false, error: '電話號碼不符', message: '提供的電話號碼與預約記錄不符' });

            // 檢查兒童陪同比例
            const STORE_NAMES = { store_1:'荃灣店', store_2:'尖沙咀店', store_3:'旺角店', store_4:'銅鑼灣店' };
            const CHILD_RATIO = { store_1:2, store_3:2, store_2:1, store_4:1 };
            const ratio = CHILD_RATIO[store_id] || 2;
            const needed = Math.ceil(childCount / ratio);
            if (childCount > 0 && adultCount < needed) {
                return res.status(400).json({
                    success: false, error: '人數比例不符合要求',
                    message: STORE_NAMES[store_id] + '每 ' + ratio + ' 位小朋友需要 1 位大人陪同，' + childCount + '位小朋友最少需要 ' + needed + ' 位大人'
                });
            }

            // 檢查新時段容量（排除自己，用 per-slot capacity）
            getSlotCapacity(store_id, booking_date, booking_time, function(MAX_CAPACITY) {
            db.get(
                `SELECT COALESCE(SUM(adults + children), 0) as total_booked
                 FROM bookings WHERE store_id = ? AND booking_date = ? AND booking_time = ? AND status = 'confirmed' AND id != ?`,
                [store_id, booking_date, booking_time, id],
                (err, row) => {
                    if (err) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });

                    const booked = row ? row.total_booked : 0;
                    const totalPeople = adultCount + childCount;

                    if (booked + totalPeople > MAX_CAPACITY) {
                        return res.status(409).json({
                            success: false, error: '該時段已滿',
                            message: '該時段尚餘 ' + (MAX_CAPACITY - booked) + ' 個位置，請選擇其他時段'
                        });
                    }

                    // 檢查新時段是否被暫停
                    db.get(`SELECT id FROM paused_slots WHERE store_id = ? AND booking_date = ? AND booking_time = ?`,
                      [store_id, booking_date, booking_time], (err2, paused) => {
                        if (err2) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err2.message });
                        if (paused) {
                          return res.status(409).json({
                            success: false, error: '該時段已暫停',
                            message: '該時段尚餘 0 個位置，請重新載入頁面, 並選擇其他時段'
                          });
                        }

                        // 更新預約
                        db.run(
                            `UPDATE bookings SET store_id = ?, booking_date = ?, booking_time = ?, adults = ?, children = ?, notes = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
                            [store_id, booking_date, booking_time, adultCount, childCount, notes || '', id],
                            function(updateErr) {
                                if (updateErr) return res.status(500).json({ success: false, error: '更新失敗', message: updateErr.message });

                                res.json({
                                    success: true, message: '預約已更新',
                                    data: { id, store_id, booking_date, booking_time, adults: adultCount, children: childCount, total_people: totalPeople, notes: notes || '' }
                                });
                            }
                        );
                    });
                }
            );
        });
    });
    } catch (error) {
        console.error('編輯預約錯誤:', error);
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route PATCH /api/booking/:id/status
 * @desc 更新預約狀態（員工權限）
 * @access Private/Staff
 */
router.patch('/:id/status', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { status, table_number } = req.body;
        const { id } = req.params;
        const validStatuses = ['confirmed', 'cancelled', 'arrived'];

        if (!validStatuses.includes(status)) {
            return res.status(400).json({
                success: false,
                error: '狀態值無效',
                message: `狀態需為: ${validStatuses.join(', ')}`
            });
        }

        db.get(
            `SELECT * FROM bookings WHERE id = ?`,
            [id],
            (err, booking) => {
                if (err) {
                    return res.status(500).json({
                        success: false,
                        error: '伺服器錯誤',
                        message: err.message
                    });
                }

                // 一律 forward 去阿里雲做 update（唔理本地有冇 record）
                forwardToAliyun('PATCH', `/api/booking/${id}/status`, { status, table_number })
                        .then(result => {
                            if (result && result.success) {
                                res.json(result);
                            } else {
                                res.status(404).json({ success: false, error: '找不到該預約', message: '本地及阿里雲均找不到該預約' });
                            }
                        })
                        .catch(e => {
                            res.status(502).json({ success: false, error: '無法連線阿里雲', message: e.message });
                        });
            }
        );
    } catch (error) {
        console.error('更新預約狀態錯誤:', error);
        res.status(500).json({
            success: false,
            error: '伺服器錯誤',
            message: error.message
        });
    }
});

/**
 * @route GET /api/booking/paused
 * @desc 拎已暫停嘅 time slot list（員工權限）
 * @access Private/Staff
 */
router.get('/paused', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { store_id, date, from_date } = req.query;
        if (!store_id || (!date && !from_date)) {
            return res.status(400).json({ success: false, error: '缺少必要參數', message: '請提供 store_id 和 date/from_date' });
        }

        var query, params;
        if (from_date) {
            query = `SELECT * FROM paused_slots WHERE store_id = ? AND booking_date >= ? ORDER BY booking_date ASC, booking_time ASC`;
            params = [store_id, from_date];
        } else {
            query = `SELECT * FROM paused_slots WHERE store_id = ? AND booking_date = ? ORDER BY booking_time ASC`;
            params = [store_id, date];
        }

        db.all(query, params,
            (err, rows) => {
                if (err) {
                    console.error('查詢暫停時段錯誤:', err);
                    return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });
                }
                res.json({ success: true, data: rows || [] });
            }
        );
    } catch (error) {
        console.error('查詢暫停時段錯誤:', error);
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route DELETE /api/booking/pause/:id
 * @desc 刪除單一暫停時段（員工權限）
 * @access Private/Staff
 */
router.delete('/pause/:id', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        db.run(`DELETE FROM paused_slots WHERE id = ?`, [req.params.id], function(err) {
            if (err) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });
            res.json({ success: true, message: '已刪除暫停時段', data: { deleted: this.changes || 0 } });
        });
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route POST /api/booking/pause/delete-range
 * @desc 刪除一段時間範圍內嘅暫停時段（員工權限）
 * @access Private/Staff
 */
router.post('/pause/delete-range', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { store_id, date, start_time, end_time } = req.body;
        if (!store_id || !date || !start_time || !end_time) {
            return res.status(400).json({ success: false, error: '缺少必要參數' });
        }
        db.run(`DELETE FROM paused_slots WHERE store_id = ? AND booking_date = ? AND booking_time >= ? AND booking_time <= ?`,
            [store_id, date, start_time, end_time],
            function(err) {
                if (err) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });
                res.json({ success: true, message: '已刪除 ' + (this.changes || 0) + ' 個暫停時段', data: { deleted: this.changes || 0 } });
                // 非阻塞上傳刪除範圍至阿里雲
                uploadDeleteRangeToAliyun(store_id, date, start_time, end_time);
            }
        );
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

// ==================== 座位容量設定 ====================

/**
 * @route POST /api/booking/capacity/save
 * @desc 設定分店某 daytype group 嘅容量（員工權限）
 * @access Private/Staff
 */
router.post('/capacity/save', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { store_id, daytype_group, capacity } = req.body;
        if (!store_id || !daytype_group || capacity === undefined) {
            return res.status(400).json({ success: false, error: '缺少必要參數', message: '請提供 store_id、daytype_group 和 capacity' });
        }
        if (!['weekday', 'holiday'].includes(daytype_group)) {
            return res.status(400).json({ success: false, error: 'daytype_group 無效', message: 'daytype_group 需為 weekday 或 holiday' });
        }
        var cap = parseInt(capacity);
        if (isNaN(cap) || cap < 1 || cap > 100) {
            return res.status(400).json({ success: false, error: '容量無效', message: '容量需為 1-100' });
        }

        db.run(
            `INSERT INTO store_capacity (id, store_id, daytype_group, capacity, updated_at)
             VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
             ON CONFLICT(store_id, daytype_group) DO UPDATE SET capacity = ?, updated_at = CURRENT_TIMESTAMP`,
            [uuidv4(), store_id, daytype_group, cap, cap],
            function(err) {
                if (err) return res.status(500).json({ success: false, error: '儲存失敗', message: err.message });
                res.json({ success: true, message: '容量已更新', data: { store_id, daytype_group, capacity: cap } });
            }
        );
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route GET /api/booking/capacity/config/:store_id
 * @desc 拎某分店嘅容量設定（含 per-slot）（員工權限）
 * @access Private/Staff
 */
router.get('/capacity/config/:store_id', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        var storeId = req.params.store_id;
        // 拎 daytype default
        db.all(`SELECT daytype_group, capacity FROM store_capacity WHERE store_id = ?`, [storeId], (err, rows) => {
            if (err) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });
            var config = { weekday: 20, holiday: 20 };
            (rows || []).forEach(function(r) { config[r.daytype_group] = r.capacity; });

            // 拎 per-slot settings
            db.all(`SELECT daytype_group, booking_time, capacity FROM store_slot_capacity WHERE store_id = ? ORDER BY daytype_group, booking_time`, [storeId], (err2, slotRows) => {
                if (err2) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err2.message });
                var slotConfig = { weekday: {}, holiday: {} };
                (slotRows || []).forEach(function(r) { slotConfig[r.daytype_group][r.booking_time] = r.capacity; });
                res.json({ success: true, data: { defaults: config, slots: slotConfig } });
            });
        });
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route POST /api/booking/capacity/save-slots
 * @desc 儲存 per-slot capacity（員工權限）
 * @access Private/Staff
 */
router.post('/capacity/save-slots', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { store_id, daytype_group, slots } = req.body;
        if (!store_id || !daytype_group || !slots || typeof slots !== 'object') {
            return res.status(400).json({ success: false, error: '缺少必要參數' });
        }
        if (!['weekday', 'holiday'].includes(daytype_group)) {
            return res.status(400).json({ success: false, error: 'daytype_group 無效' });
        }

        var keys = Object.keys(slots);
        var done = 0;
        var errors = [];
        if (keys.length === 0) return res.json({ success: true, message: '沒有需要更新嘅時段' });

        keys.forEach(function(time) {
            var cap = parseInt(slots[time]);
            if (isNaN(cap) || cap < 0 || cap > 100) {
                errors.push(time);
                done++;
                if (done === keys.length) finish();
                return;
            }
            db.run(
                `INSERT INTO store_slot_capacity (id, store_id, daytype_group, booking_time, capacity, updated_at)
                 VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                 ON CONFLICT(store_id, daytype_group, booking_time) DO UPDATE SET capacity = ?, updated_at = CURRENT_TIMESTAMP`,
                [uuidv4(), store_id, daytype_group, time, cap, cap],
                function(err) {
                    if (err) errors.push(time + '(' + err.message + ')');
                    done++;
                    if (done === keys.length) finish();
                }
            );
        });

        function finish() {
            res.json({
                success: errors.length === 0,
                message: errors.length === 0 ? '已更新 ' + keys.length + ' 個時段容量' : '部分時段儲存失敗',
                data: { updated: keys.length - errors.length, errors: errors }
            });
        }
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route POST /api/booking/capacity/apply-to-all
 * @desc 將某分店嘅容量設定套用至所有分店（管理員專用）
 * @access Private/Admin
 */
router.post('/capacity/apply-to-all', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { store_id } = req.body;
        if (!store_id) {
            return res.status(400).json({ success: false, error: '缺少必要參數', message: '請提供來源分店 ID' });
        }
        if (!store_id.match(/^store_[1-4]$/)) {
            return res.status(400).json({ success: false, error: '無效嘅分店 ID' });
        }

        const targetStores = ['store_1', 'store_2', 'store_3', 'store_4'].filter(s => s !== store_id);

        function dbRun(sql, params) {
            return new Promise((resolve, reject) => {
                db.run(sql, params, function(err) {
                    if (err) reject(err);
                    else resolve(this.changes);
                });
            });
        }

        function loadSettings() {
            return new Promise((resolve, reject) => {
                db.all('SELECT daytype_group, capacity FROM store_capacity WHERE store_id = ?', [store_id], (err, defaultRows) => {
                    if (err) return reject(err);
                    db.all('SELECT daytype_group, booking_time, capacity FROM store_slot_capacity WHERE store_id = ?', [store_id], (err2, slotRows) => {
                        if (err2) return reject(err2);
                        const sources = { defaults: {}, slots: { weekday: {}, holiday: {} } };
                        (defaultRows || []).forEach(r => { sources.defaults[r.daytype_group] = r.capacity; });
                        (slotRows || []).forEach(r => { sources.slots[r.daytype_group][r.booking_time] = r.capacity; });
                        resolve(sources);
                    });
                });
            });
        }

        loadSettings().then(sources => {
            const promises = [];
            targetStores.forEach(targetId => {
                Object.keys(sources.defaults).forEach(dtg => {
                    promises.push(dbRun(
                        `INSERT INTO store_capacity (id, store_id, daytype_group, capacity, updated_at)
                         VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                         ON CONFLICT(store_id, daytype_group) DO UPDATE SET capacity = ?, updated_at = CURRENT_TIMESTAMP`,
                        [uuidv4(), targetId, dtg, sources.defaults[dtg], sources.defaults[dtg]]
                    ));
                });
                ['weekday', 'holiday'].forEach(dtg => {
                    Object.keys(sources.slots[dtg] || {}).forEach(time => {
                        promises.push(dbRun(
                            `INSERT INTO store_slot_capacity (id, store_id, daytype_group, booking_time, capacity, updated_at)
                             VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                             ON CONFLICT(store_id, daytype_group, booking_time) DO UPDATE SET capacity = ?, updated_at = CURRENT_TIMESTAMP`,
                            [uuidv4(), targetId, dtg, time, sources.slots[dtg][time], sources.slots[dtg][time]]
                        ));
                    });
                });
            });
            return Promise.allSettled(promises).then(results => {
                const failed = results.filter(r => r.status === 'rejected');
                res.json({
                    success: failed.length === 0,
                    message: failed.length === 0
                        ? '已將 ' + store_id + ' 嘅容量設定套用到 ' + targetStores.length + ' 間分店'
                        : '套用完成，但有 ' + failed.length + ' 個錯誤',
                    data: { targetStores, errors: failed.map(r => r.reason?.message || '未知錯誤') }
                });
            });
        }).catch(e => {
            res.status(500).json({ success: false, error: '讀取來源分店設定失敗', message: e.message });
        });
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route GET /api/booking/capacity/public
 * @desc 公開端點：拎某分店某日嘅 capacity
 * @access Public
 */
router.get('/capacity/public', (req, res) => {
    try {
        const { store_id, date } = req.query;
        if (!store_id || !date) {
            return res.status(400).json({ success: false, error: '缺少必要參數' });
        }
        getSlotCapacityMap(store_id, date, function(capMap, defaultCap) {
            res.json({ success: true, data: { store_id, date, default_capacity: defaultCap, slot_capacities: capMap } });
        });
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route GET /api/booking/:id
 * @desc 查詢單一預約詳情（公開，用於客戶查詢）
 * @access Public
 */
router.get('/:id', (req, res) => {
    try {
        const { id } = req.params;
        db.get(`SELECT * FROM bookings WHERE id = ?`, [id], (err, booking) => {
            if (err) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });
            if (!booking) return res.status(404).json({ success: false, error: '找不到該預約' });
            res.json({ success: true, data: booking });
        });
    } catch (error) {
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route PUT /api/booking/:id
 * @desc 更新預約內容（員工權限）
 * @access Private/Staff
 */
router.put('/:id', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { id } = req.params;
        const { booking_date, booking_time, adults, children, notes } = req.body;

        db.get(`SELECT * FROM bookings WHERE id = ?`, [id], (err, booking) => {
            if (err) return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });
            if (!booking) return res.status(404).json({ success: false, error: '找不到該預約', message: '預約不存在' });

            var updates = [];
            var params = [];

            if (booking_date) { updates.push('booking_date = ?'); params.push(booking_date); }
            if (booking_time) { updates.push('booking_time = ?'); params.push(booking_time); }
            if (adults !== undefined) { updates.push('adults = ?'); params.push(parseInt(adults)); }
            if (children !== undefined) { updates.push('children = ?'); params.push(parseInt(children)); }
            if (notes !== undefined) { updates.push('notes = ?'); params.push(notes); }

            if (updates.length === 0) {
                return res.status(400).json({ success: false, error: '沒有需要更新的欄位' });
            }

            updates.push("updated_at = CURRENT_TIMESTAMP");
            params.push(id);

            db.run(
                `UPDATE bookings SET ${updates.join(', ')} WHERE id = ?`,
                params,
                function(updateErr) {
                    if (updateErr) return res.status(500).json({ success: false, error: '更新失敗', message: updateErr.message });
                    res.json({ success: true, message: '預約已更新', data: { id } });
                }
            );
        });
    } catch (error) {
        console.error('更新預約錯誤:', error);
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route POST /api/booking/pause
 * @desc 暫停某店某日未來 N 分鐘嘅 time slot（員工權限）
 * @access Private/Staff
 */
router.post('/pause', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { store_id, date, duration_minutes, time_slots, is_full_day } = req.body;
        if (!store_id || !date) {
            return res.status(400).json({ success: false, error: '缺少必要參數', message: '請提供 store_id 和 date' });
        }
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
            return res.status(400).json({ success: false, error: '日期格式錯誤', message: '日期格式需為 YYYY-MM-DD' });
        }

        var affectedSlots = [];

        if (time_slots && Array.isArray(time_slots) && time_slots.length > 0) {
            // 特定時段（未來日期用）
            affectedSlots = time_slots;
        } else if (is_full_day) {
            // 全日暫停（11:30-21:00，所有半小時時段）
            for (var hh = 11; hh <= 21; hh++) {
                for (var mm = 0; mm < 60; mm += 30) {
                    if (hh === 21 && mm === 30) continue; // skip 21:30
                    affectedSlots.push(String(hh).padStart(2,'0') + ':' + String(mm).padStart(2,'0'));
                }
            }
            // filter 11:30 or 13:30 start base on daytype
            // already starts at 11:00, remove 11:00, keep 11:30 onward
            affectedSlots = affectedSlots.filter(function(t) { return t >= '11:30'; });
        } else if (duration_minutes) {
            // 今日暫停（現有模式）
            var now = new Date();
            var currentMinutes = now.getHours() * 60 + now.getMinutes();
            var startSlot = Math.ceil(currentMinutes / 30) * 30;
            var endSlot = startSlot + parseInt(duration_minutes);

            for (var m = startSlot; m < endSlot; m += 30) {
                var h = Math.floor(m / 60);
                var min = m % 60;
                if (h >= 22) break;
                affectedSlots.push(String(h).padStart(2,'0') + ':' + String(min).padStart(2,'0'));
            }
        } else {
            return res.status(400).json({ success: false, error: '缺少參數', message: '請提供 time_slots、is_full_day 或 duration_minutes' });
        }

        if (affectedSlots.length === 0) {
            return res.status(400).json({ success: false, error: '沒有可暫停嘅時段', message: '沒有可暫停嘅時段' });
        }

        // 逐個插入（skip 已存在嘅）
        var inserted = [];
        var done = 0;
        affectedSlots.forEach(function(t) {
            db.run(
                `INSERT OR IGNORE INTO paused_slots (id, store_id, booking_date, booking_time)
                 VALUES (?, ?, ?, ?)`,
                [uuidv4(), store_id, date, t],
                function(err) {
                    if (err) {
                        console.error('暫停時段錯誤:', err);
                    } else if (this.changes > 0) {
                        inserted.push(t);
                    }
                    done++;
                    if (done === affectedSlots.length) {
                        var msg = '已暫停 ' + inserted.length + ' 個時段';
                        if (duration_minutes) {
                            var lastMin = (Math.ceil((new Date(new Date().getTime() + 8*60*60*1000).getHours()*60 + new Date(new Date().getTime() + 8*60*60*1000).getMinutes())/30)*30) + (affectedSlots.length * 30);
                            var lastH = Math.floor(lastMin / 60);
                            var lastM = lastMin % 60;
                            msg += '，暫停到 ' + String(lastH).padStart(2,'0') + ':' + String(lastM).padStart(2,'0');
                        }
                        res.json({
                            success: true,
                            message: msg,
                            data: { slots: inserted }
                        });
                        uploadPauseToAliyun(store_id, date, inserted);
                    }
                }
            );
        });
    } catch (error) {
        console.error('暫停時段錯誤:', error);
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

/**
 * @route POST /api/booking/resume
 * @desc 恢復某店某日所有暫停 slot（員工權限）
 * @access Private/Staff
 */
router.post('/resume', authMiddleware.authenticate, authMiddleware.requireStaff, (req, res) => {
    try {
        const { store_id, date } = req.body;
        if (!store_id || !date) {
            return res.status(400).json({ success: false, error: '缺少必要參數', message: '請提供 store_id 和 date' });
        }

        db.run(`DELETE FROM paused_slots WHERE store_id = ? AND booking_date = ?`,
            [store_id, date],
            function(err) {
                if (err) {
                    console.error('恢復時段錯誤:', err);
                    return res.status(500).json({ success: false, error: '伺服器錯誤', message: err.message });
                }
                res.json({
                    success: true,
                    message: '已恢復 ' + (this.changes || 0) + ' 個暫停時段',
                    data: { deleted: this.changes || 0 }
                });
                uploadResumeToAliyun(store_id, date);
            }
        );
    } catch (error) {
        console.error('恢復時段錯誤:', error);
        res.status(500).json({ success: false, error: '伺服器錯誤', message: error.message });
    }
});

module.exports = router;
